BunnyTL: OCR + terjemahan AI offline (mode akurat, gaya bahasa, glosarium) + Chat AI.

Mesin AI bisa diganti-ganti. Taruh tiap model di foldernya sendiri (COPY, bukan Move):
Android/data/com.niven.mangatl/files/
    Ai 1/gemma-4-E2B-it.litertlm
    Ai 2/Qwen3.5-4B_mixed_int4.litertlm
    Ai 3/...

Nama folder bebas. File .litertlm langsung di folder files/ juga tetap terbaca.
Pilih mesin di menu Opsi > "Mesin AI". Pilihan tersimpan dan berlaku untuk
terjemah, mode game, dan Chat.

Cache: tiap mesin AI punya folder cache sendiri bernama "_cache" di dalam foldernya
(mis. Ai 1/_cache). Aman dihapus kalau mau; nanti dibuat ulang otomatis.

Chat suara: tombol "Mic" di layar Chat. Ketuk, bicara (bahasa Indonesia), jawaban terkirim otomatis.
Ketuk lagi untuk membatalkan. Untuk offline, pasang paket suara Indonesia di
Pengaturan HP > Google > pengenalan suara / Speech Services.

Suara AI (keluar), 100% offline: model Supertonic 3 (sherpa-onnx).
1. Unduh sherpa-onnx-supertonic-3-tts-int8-2026-05-11.tar.bz2 dari
   github.com/k2-fsa/sherpa-onnx/releases/tag/tts-models, lalu ekstrak.
2. Salin folder hasil ekstrak (isi: voice.bin, tts.json, unicode_indexer.bin,
   dan 4 file .onnx) ke Android/data/com.niven.mangatl/files/Suara 1/
3. Opsi > "Suara AI": pilih model suara, pilih Suara 1-6 (1-5 cewek, 6 cowok), tekan "Tes suara".
   Suara 1-5 biasanya cewek (urutan perkiraan, dengar sendiri). 
4. Di Chat: tombol "Suara: mati/nyala" = AI membacakan setiap jawaban.
   Ketuk balon jawaban untuk membacakan satu pesan.
Catatan build: build.yml mengunduh sherpa-onnx-2.0.1.aar ke app/libs/ saat build.

Tahap 4 (mode game lebih cepat):
- Terjemah layar memakai prompt pendek + streaming: hasil muncul bertahap, dialog utama (teks terpanjang) paling dulu.
- Cache per baris di memori: teks yang sama (menu, tombol, dialog berulang) langsung tampil tanpa memanggil model.
  Tombol Reset mengosongkan cache ini.
- Backend (GPU/CPU) yang berhasil diingat per model, jadi muat berikutnya tidak mencoba ulang yang gagal.
- Opsi: slider opasitas kotak terjemahan, dan pilihan ketuk saat hasil tampil
  (tutup + langsung terjemah layar berikutnya, atau cuma tutup).

Tahap 5 (suara ikut teks):
- Chat: suara AI sekarang streaming. Tiap kalimat dibacakan begitu muncul di layar, tidak menunggu jawaban selesai.
- Model suara dimuat saat pesan dikirim (selagi AI mikir), jadi kalimat pertama langsung bunyi.
- Tombol "Berhenti" ikut menghentikan suara.

Tahap 5b:
- Mode LIVE ngobrol: TAHAN tombol Mic. Dengar -> AI jawab bersuara -> dengar lagi otomatis, terus sampai
  Mic diketuk atau "Berhenti" ditekan. Jawaban di mode live dibuat singkat (1-3 kalimat).
- Mic tetap full offline (pengenal on-device); jeda diam dilonggarkan.
- Suara lebih cepat: model dimuat sejak layar Chat dibuka, potongan pertama boleh berhenti di koma, langkah
  generate suara dikurangi (3 untuk potongan pertama, 4 untuk sisanya).

Tahap 5c (perbaikan kualitas suara):
- Langkah generate suara dinaikkan jadi 6 untuk semua potongan (sebelumnya 3/4 = mendem & cempreng, kualitas tiap potongan beda).
- Potongan teks minimal ~28 karakter (sebelumnya 10), sisa potongan pendek digabung, intonasi akhir ditambah tanda baca.
- Pasca-proses: cegah clipping, volume antar potongan disamakan, fade anti-klik, jeda awal 150 ms supaya kata pertama tidak terpotong.
- Kalau masih terlalu tajam: di Voice.kt ubah TAME_TREBLE = true (redam treble). Kalau mau lebih cepat: turunkan STEPS ke 5.
- Saran: pakai model fp32 (bukan int8) kalau ada; int8 sedikit lebih kasar.

Tahap 6 (suara kadang mendem/cempreng):
- Pemutaran menunggu 2 potongan siap dulu (PREBUFFER_CHUNKS) supaya tidak putus kalau pembuatan suara kalah cepat dari pemutaran.
- Jenis audio diganti dari SPEECH ke MUSIC: beberapa HP memasang filter "suara bicara" yang bikin kadang mendem/cempreng.
- Teks dibersihkan lebih banyak (simbol, kutip, singkatan gk/yg/dgn).
- Logcat tag "BunnyVoice" mencatat waktu bikin vs durasi tiap potongan (untuk diagnosa).
- Potongan teks dibatasi MAX_CHUNK = 120 huruf (sebelumnya 220) karena teks panjang bikin suara mendem/cempreng.
- Seimbangkan kecepatan vs kualitas: STEPS 5, PREBUFFER_CHUNKS 1, MIN_CHUNK 24, SPEED 1.05 (suara tidak terlalu ketinggalan dari teks).
- Potongan pertama langsung dibacakan begitu >= 30 huruf (FIRST_FORCE), tanpa nunggu titik/koma, supaya suara mulai bareng teks.
- Awal cepat, belakang natural: potongan pertama 5 langkah (STEPS_FIRST), sisanya 6 langkah (STEPS). Potongan yang terpotong di tengah kalimat diakhiri koma supaya intonasi nyambung.

Tahap 6b: pengaturan "Kecepatan mulai suara" di Opsi (di bawah pilihan Suara 1-6):
- Cepat: suara mulai paling awal (potongan pertama ~24 huruf), risiko agak kasar.
- Seimbang (default): awal cepat, bagian belakang lebih natural.
- Natural: paling jernih, suara mulai agak telat.
Pilihan berlaku untuk suara berikutnya, tidak perlu restart.

Tahap 6c: slider "Jeda koma" dan "Jeda titik" (0-600 ms) di Opsi, di atas tombol Tes suara.
- Jeda dipasang di tiap pergantian potongan. Koma sekarang ikut jadi titik potong (setelah ~28-40 huruf tergantung mode).
- Koma di kalimat pendek (dalam satu potongan) tetap diatur model suara.
- Default: koma 90 ms, titik 90 ms (= suara sebelumnya). Tombol "Kembalikan ke default" mengembalikan mode kecepatan + dua jeda. Potongan yang terpotong di tengah frasa pakai jeda tetap 40 ms.

Tahap 7: Mic offline Whisper (jauh lebih akurat dari pengenal bawaan HP).
1. Unduh sherpa-onnx-whisper-small.tar.bz2 (lebih akurat, ~350 MB) atau sherpa-onnx-whisper-base (lebih cepat, ~150 MB)
   dari github.com/k2-fsa/sherpa-onnx/releases/tag/asr-models, lalu ekstrak.
2. Salin folder hasil ekstrak (isi: *-encoder*.onnx, *-decoder*.onnx, *-tokens.txt) ke
   Android/data/com.niven.mangatl/files/Whisper/   (nama folder bebas).
3. Selesai. Kalau folder ini ada, tombol Mic otomatis pakai Whisper. Kalau belum ada / Whisper error, otomatis pakai mic bawaan.
- Cara kerja: rekam -> berhenti otomatis setelah diam ~1,3 detik (mode live 1,5 detik) -> Whisper ubah jadi teks -> terkirim.
- Ketuk Mic saat sedang merekam = anggap selesai ngomong sekarang. Teks muncul setelah selesai ngomong (bukan sambil ngomong).
- Deteksi diam pakai volume (tanpa file VAD tambahan). Di tempat sangat bising bisa telat berhenti: ketuk Mic untuk menyudahi.
- Log: Logcat tag "BunnyEar" (lama ucapan & lama pengenalan).
- Saat Mic pertama kali diketuk muncul toast "Mic: Whisper (nama folder)" atau "Mic: bawaan HP (...)" supaya jelas mesin mana yang dipakai.
- Whisper base kurang akurat untuk bahasa Indonesia; whisper small jauh lebih baik (tapi lebih berat dan lebih lambat).


Tahap 8: Pemutar musik & video (Media3 / ExoPlayer). Dua tombol terpisah di layar utama: Musik dan Video.

MUSIK (tombol "Musik"):
- Tab: Lagu | Album | Artis | Folder | Playlist, semua dengan cover/thumbnail. Ketuk album/artis/folder untuk masuk, tombol Back untuk keluar.
- Pencarian judul/artis/album. Di dalam daftar ada tombol "Putar" dan "Acak".
- Tahan lagu = menu: putar berikutnya, tambah ke antrean, favorit, tambah ke playlist, hapus dari playlist.
- Playlist: "Favorit" + playlist buatan sendiri (tahan playlist untuk menghapus).
- Mini player di bawah; ketuk = layar "Sedang diputar": cover besar, seek, acak, ulang (mati/semua/satu),
  favorit, sleep timer (15/30/45/60 menit), antrean, kecepatan 0.75x-2x.
- Jalan di latar belakang dengan notifikasi dan kontrol layar kunci.

VIDEO (tombol "Video"):
- Daftar FOLDER (thumbnail video terbaru, jumlah video, total ukuran). Ketuk folder = isi folder.
- Isi folder: thumbnail, durasi, ukuran, bilah progres tontonan, urut terbaru/nama, pencarian.
- Pemutar layar penuh: lanjut ke video berikutnya di folder yang sama, menu gerigi (kecepatan, audio, subtitle),
  geser kiri = kecerahan, geser kanan = volume, ketuk dua kali kiri/kanan = mundur/maju 10 detik,
  posisi terakhir diingat, Picture-in-Picture saat tekan Home.
- "Buka file": pilih satu file dari penyimpanan. BunnyTL juga muncul di "Buka dengan" untuk video dari aplikasi lain.
