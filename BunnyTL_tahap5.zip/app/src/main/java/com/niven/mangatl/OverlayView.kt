package com.niven.mangatl

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Rect
import android.graphics.RectF
import android.text.Layout
import android.text.StaticLayout
import android.text.TextPaint
import android.view.View

/** Layar transparan penuh: menggambar terjemahan tepat di atas posisi teks aslinya. */
class OverlayView(context: Context) : View(context) {

    class Item(val rect: Rect, val text: String, val bg: Int, val fg: Int)

    var items: List<Item> = emptyList()
        private set

    /** Keburaman latar kotak terjemahan, 0..255 (diatur dari Opsi). */
    var bgAlpha: Int = 235

    private val bgPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val tp = TextPaint(Paint.ANTI_ALIAS_FLAG)
    private val density = resources.displayMetrics.density

    fun setItems(list: List<Item>) {
        items = list
        invalidate()
    }

    private fun layoutFor(text: String, w: Int, size: Float): StaticLayout {
        tp.textSize = size
        return StaticLayout.Builder.obtain(text, 0, text.length, tp, w.coerceAtLeast(1))
            .setAlignment(Layout.Alignment.ALIGN_CENTER)
            .setIncludePad(false)
            .build()
    }

    /** Cari ukuran huruf terbesar yang masih muat di kotak. */
    private fun fit(text: String, w: Int, h: Int): StaticLayout {
        val minPx = 9f * density
        var lo = minPx
        var hi = minOf(h.toFloat(), 40f * density).coerceAtLeast(minPx)
        repeat(7) {
            val mid = (lo + hi) / 2f
            if (layoutFor(text, w, mid).height <= h) lo = mid else hi = mid
        }
        return layoutFor(text, w, lo)
    }

    override fun onDraw(canvas: Canvas) {
        val loc = IntArray(2)
        getLocationOnScreen(loc)
        val padX = 6f * density
        val padY = 3f * density
        val inner = 2f * density

        for (it in items) {
            var left = it.rect.left - loc[0] - padX
            val top = it.rect.top - loc[1] - padY
            var boxW = it.rect.width() + 2 * padX
            val boxH = it.rect.height() + 2 * padY
            if (left < 0f) {
                boxW += left
                left = 0f
            }
            if (left + boxW > width) boxW = (width - left).coerceAtLeast(1f)

            tp.color = it.fg
            val layout = fit(it.text, (boxW - 2 * inner).toInt(), (boxH - 2 * inner).toInt())
            val needH = layout.height + 2 * inner
            val drawH = maxOf(boxH, needH)

            bgPaint.color = (it.bg and 0x00FFFFFF) or (bgAlpha.coerceIn(0, 255) shl 24)
            canvas.drawRoundRect(RectF(left, top, left + boxW, top + drawH), 6f * density, 6f * density, bgPaint)

            canvas.save()
            canvas.translate(left + inner, top + (drawH - layout.height) / 2f)
            layout.draw(canvas)
            canvas.restore()
        }
    }
}
