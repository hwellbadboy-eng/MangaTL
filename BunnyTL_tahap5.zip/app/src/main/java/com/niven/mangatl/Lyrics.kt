package com.niven.mangatl

import android.content.Context
import android.net.Uri
import androidx.documentfile.provider.DocumentFile
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.nio.charset.Charset

/**
 * Lirik. Urutan sumber: (1) lirik simpanan/edit sendiri, (2) tag di dalam file (MP3 USLT, FLAC),
 * (3) file .lrc/.txt di folder lirik yang dipilih, (4) online (LRCLIB) kalau diminta / diaktifkan.
 */
object Lyrics {

    /** timeMs = -1 berarti lirik biasa (tanpa waktu). */
    class Line(val timeMs: Long, val text: String)

    class Result(val raw: String, val lines: List<Line>, val synced: Boolean, val source: String)

    private val TAG = Regex("\\[(\\d{1,3}):(\\d{1,2})(?:[.:](\\d{1,3}))?]")

    fun parse(raw: String, source: String): Result? {
        val text = raw.replace("\r\n", "\n").replace('\r', '\n').trim()
        if (text.isEmpty()) return null
        val timed = ArrayList<Line>()
        for (ln in text.split('\n')) {
            val tags = TAG.findAll(ln).toList()
            if (tags.isEmpty()) continue
            val body = ln.substring(tags.last().range.last + 1).trim()
            for (m in tags) {
                val min = m.groupValues[1].toLong()
                val sec = m.groupValues[2].toLong()
                val fracS = m.groupValues[3]
                val ms = if (fracS.isEmpty()) 0L else (fracS.padEnd(3, '0').take(3)).toLong()
                timed.add(Line(min * 60_000 + sec * 1000 + ms, body))
            }
        }
        if (timed.size >= 2) {
            return Result(text, timed.sortedBy { it.timeMs }, true, source)
        }
        val plain = text.split('\n').filter { !it.trim().startsWith("[") || !it.trim().endsWith("]") || it.length > 40 }
            .map { Line(-1, it.trim()) }
        return Result(text, plain, false, source)
    }

    // ---------- simpanan sendiri ----------
    private fun cache(ctx: Context, id: Long) = File(File(ctx.filesDir, "lyrics"), "$id.txt")

    fun save(ctx: Context, id: Long, text: String) {
        val f = cache(ctx, id)
        f.parentFile?.mkdirs()
        f.writeText(text)
    }

    fun clear(ctx: Context, id: Long) {
        cache(ctx, id).delete()
    }

    // ---------- muat dari sumber lokal ----------
    fun loadLocal(ctx: Context, t: Library.Track): Result? {
        val c = cache(ctx, t.id)
        if (c.exists()) parse(c.readText(), "Tersimpan")?.let { return it }
        embedded(ctx, t.uri)?.let { e -> parse(e, "Tag file")?.let { return it } }
        sidecar(ctx, t)?.let { s -> parse(s, "File .lrc")?.let { return it } }
        return null
    }

    // ---------- tag di dalam file ----------
    private fun embedded(ctx: Context, uri: Uri): String? = try {
        ctx.contentResolver.openInputStream(uri)?.use { ins ->
            val head = ByteArray(10)
            var n = 0
            while (n < 10) {
                val r = ins.read(head, n, 10 - n)
                if (r < 0) break
                n += r
            }
            if (n < 4) null
            else if (head[0] == 'I'.code.toByte() && head[1] == 'D'.code.toByte() && head[2] == '3'.code.toByte() && n == 10) {
                id3(ins, head)
            } else if (head[0] == 'f'.code.toByte() && head[1] == 'L'.code.toByte() &&
                head[2] == 'a'.code.toByte() && head[3] == 'C'.code.toByte()
            ) {
                flac(ins, head, n)
            } else null
        }
    } catch (e: Exception) {
        null
    }

    private fun synchsafe(b: ByteArray, o: Int) =
        ((b[o].toInt() and 0x7f) shl 21) or ((b[o + 1].toInt() and 0x7f) shl 14) or
            ((b[o + 2].toInt() and 0x7f) shl 7) or (b[o + 3].toInt() and 0x7f)

    private fun be32(b: ByteArray, o: Int) =
        ((b[o].toInt() and 0xff) shl 24) or ((b[o + 1].toInt() and 0xff) shl 16) or
            ((b[o + 2].toInt() and 0xff) shl 8) or (b[o + 3].toInt() and 0xff)

    private fun readFully(ins: java.io.InputStream, size: Int): ByteArray {
        val out = ByteArray(size)
        var n = 0
        while (n < size) {
            val r = ins.read(out, n, size - n)
            if (r < 0) break
            n += r
        }
        return if (n == size) out else out.copyOf(n)
    }

    private fun id3(ins: java.io.InputStream, head: ByteArray): String? {
        val ver = head[3].toInt()
        val flags = head[5].toInt()
        val size = synchsafe(head, 6)
        if (size <= 0 || size > 16 * 1024 * 1024) return null
        var tag = readFully(ins, size)
        if ((flags and 0x80) != 0 && ver < 4) { // unsynchronisation
            val o = ByteArrayOutputStream()
            var i = 0
            while (i < tag.size) {
                o.write(tag[i].toInt())
                if (tag[i] == 0xFF.toByte() && i + 1 < tag.size && tag[i + 1] == 0.toByte()) i++
                i++
            }
            tag = o.toByteArray()
        }
        var pos = 0
        if ((flags and 0x40) != 0 && tag.size >= 4) { // extended header
            pos = if (ver == 4) synchsafe(tag, 0) else be32(tag, 0) + 4
        }
        val idLen = if (ver == 2) 3 else 4
        val hdr = if (ver == 2) 6 else 10
        while (pos + hdr <= tag.size) {
            if (tag[pos].toInt() == 0) break
            val id = String(tag, pos, idLen, Charsets.ISO_8859_1)
            val fsize = when (ver) {
                2 -> ((tag[pos + 3].toInt() and 0xff) shl 16) or ((tag[pos + 4].toInt() and 0xff) shl 8) or (tag[pos + 5].toInt() and 0xff)
                4 -> synchsafe(tag, pos + 4)
                else -> be32(tag, pos + 4)
            }
            val start = pos + hdr
            if (fsize <= 0 || start + fsize > tag.size) break
            if (id == "USLT" || id == "ULT") {
                return decodeUslt(tag, start, fsize)
            }
            pos = start + fsize
        }
        return null
    }

    private fun decodeUslt(b: ByteArray, start: Int, len: Int): String? {
        if (len < 5) return null
        val enc = b[start].toInt()
        var p = start + 4 // encoding + bahasa(3)
        val end = start + len
        val wide = enc == 1 || enc == 2
        // lewati deskripsi sampai terminator
        if (wide) {
            while (p + 1 < end && !(b[p].toInt() == 0 && b[p + 1].toInt() == 0)) p += 2
            p += 2
        } else {
            while (p < end && b[p].toInt() != 0) p++
            p += 1
        }
        if (p >= end) return null
        val cs: Charset = when (enc) {
            0 -> Charsets.ISO_8859_1
            1 -> Charsets.UTF_16
            2 -> Charsets.UTF_16BE
            else -> Charsets.UTF_8
        }
        return String(b, p, end - p, cs).trim().ifEmpty { null }
    }

    private fun flac(ins: java.io.InputStream, head: ByteArray, n: Int): String? {
        // head = 10 byte pertama: "fLaC" + header blok pertama (4) + 2 byte isi blok
        var pending = head.copyOfRange(8, n.coerceAtMost(10))
        fun take(k: Int): ByteArray {
            val t = minOf(k, pending.size)
            val first = pending.copyOfRange(0, t)
            pending = pending.copyOfRange(t, pending.size)
            return if (t == k) first else first + readFully(ins, k - t)
        }
        fun skip(k: Int): Boolean {
            var left = k
            val t = minOf(left, pending.size)
            pending = pending.copyOfRange(t, pending.size)
            left -= t
            while (left > 0) {
                val s = ins.skip(left.toLong())
                if (s <= 0) {
                    if (ins.read() < 0) return false
                    left -= 1
                } else left -= s.toInt()
            }
            return true
        }
        var hdr = head.copyOfRange(4, 8)
        var guard = 0
        while (guard++ < 60) {
            val last = (hdr[0].toInt() and 0x80) != 0
            val type = hdr[0].toInt() and 0x7f
            val len = ((hdr[1].toInt() and 0xff) shl 16) or ((hdr[2].toInt() and 0xff) shl 8) or (hdr[3].toInt() and 0xff)
            if (type == 4) {
                if (len !in 1..8_000_000) return null
                return vorbisLyrics(take(len))
            }
            if (!skip(len)) return null
            if (last) return null
            hdr = take(4)
            if (hdr.size < 4) return null
        }
        return null
    }

    private fun le32(b: ByteArray, o: Int) =
        (b[o].toInt() and 0xff) or ((b[o + 1].toInt() and 0xff) shl 8) or
            ((b[o + 2].toInt() and 0xff) shl 16) or ((b[o + 3].toInt() and 0xff) shl 24)

    private fun vorbisLyrics(d: ByteArray): String? {
        var p = 0
        if (d.size < 8) return null
        val vlen = le32(d, p); p += 4 + vlen
        if (p + 4 > d.size) return null
        val count = le32(d, p); p += 4
        for (i in 0 until count) {
            if (p + 4 > d.size) break
            val l = le32(d, p); p += 4
            if (l < 0 || p + l > d.size) break
            val s = String(d, p, l, Charsets.UTF_8)
            p += l
            val eq = s.indexOf('=')
            if (eq > 0) {
                val k = s.substring(0, eq).uppercase()
                if (k == "LYRICS" || k == "UNSYNCEDLYRICS" || k == "SYNCEDLYRICS") return s.substring(eq + 1)
            }
        }
        return null
    }

    // ---------- file .lrc di folder pilihan ----------
    private var indexKey: String? = null
    private var index: Map<String, Uri> = emptyMap()

    private fun buildIndex(ctx: Context, tree: String): Map<String, Uri> {
        val m = HashMap<String, Uri>()
        fun walk(dir: DocumentFile, depth: Int) {
            for (f in dir.listFiles()) {
                val n = f.name ?: continue
                if (f.isDirectory) {
                    if (depth < 2) walk(f, depth + 1)
                } else {
                    val l = n.lowercase()
                    if (l.endsWith(".lrc") || l.endsWith(".txt")) {
                        m.putIfAbsent(l.substringBeforeLast('.'), f.uri)
                    }
                }
            }
        }
        DocumentFile.fromTreeUri(ctx, Uri.parse(tree))?.let { walk(it, 0) }
        return m
    }

    /** Paksa baca ulang isi folder lirik (setelah user memilih folder baru). */
    fun resetIndex() {
        indexKey = null
    }

    private fun sidecar(ctx: Context, t: Library.Track): String? {
        val tree = Prefs.str(ctx, "lyrics_tree") ?: return null
        try {
            if (indexKey != tree) {
                index = buildIndex(ctx, tree)
                indexKey = tree
            }
            val keys = listOf(
                t.fileBase.lowercase(),
                "${t.artist} - ${t.title}".lowercase(),
                t.title.lowercase()
            )
            for (k in keys) {
                val u = index[k] ?: continue
                ctx.contentResolver.openInputStream(u)?.use { return it.readBytes().toString(Charsets.UTF_8) }
            }
        } catch (e: Exception) {
        }
        return null
    }

    // ---------- online (LRCLIB) ----------
    private fun get(url: String): String? {
        val c = URL(url).openConnection() as HttpURLConnection
        return try {
            c.connectTimeout = 8000
            c.readTimeout = 8000
            c.setRequestProperty("User-Agent", "BunnyTL/0.7")
            if (c.responseCode != 200) null else c.inputStream.bufferedReader().readText()
        } finally {
            c.disconnect()
        }
    }

    private fun pick(o: JSONObject): String? {
        val s = o.optString("syncedLyrics", "")
        if (s.isNotBlank() && s != "null") return s
        val p = o.optString("plainLyrics", "")
        return if (p.isNotBlank() && p != "null") p else null
    }

    /** Cari di lrclib.net. Mengembalikan teks lirik (LRC kalau ada) atau null. Panggil di thread IO. */
    fun online(t: Library.Track): String? = try {
        fun enc(s: String) = URLEncoder.encode(s, "UTF-8")
        val exact = get(
            "https://lrclib.net/api/get?artist_name=${enc(t.artist)}&track_name=${enc(t.title)}" +
                "&album_name=${enc(t.album)}&duration=${t.durationMs / 1000}"
        )
        var text = exact?.let { pick(JSONObject(it)) }
        if (text == null) {
            val s = get("https://lrclib.net/api/search?q=${enc(t.artist + " " + t.title)}")
            if (s != null) {
                val arr = JSONArray(s)
                for (i in 0 until arr.length()) {
                    text = pick(arr.getJSONObject(i))
                    if (text != null) break
                }
            }
        }
        text
    } catch (e: Exception) {
        null
    }
}
