package com.niven.mangatl

import android.app.PictureInPictureParams
import android.content.Context
import android.content.res.Configuration
import android.media.AudioManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.OpenableColumns
import android.provider.Settings
import android.view.GestureDetector
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.common.Timeline
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import kotlin.math.abs
import kotlin.math.roundToInt

/**
 * Pemutar video layar penuh dengan antrean (video lain di folder yang sama).
 * - Menu gerigi: kecepatan, trek audio, subtitle.
 * - Geser atas/bawah di kiri = kecerahan, kanan = volume.
 * - Ketuk dua kali kiri/kanan = mundur/maju 10 detik.
 * - Posisi terakhir diingat per video. Picture-in-Picture saat tombol Home ditekan.
 */
class VideoActivity : AppCompatActivity() {

    private lateinit var playerView: PlayerView
    private lateinit var hud: TextView
    private lateinit var tvTitle: TextView
    private var player: ExoPlayer? = null
    private var queue: List<Uri> = emptyList()
    private var startIndex = 0

    private val prefs by lazy { getSharedPreferences("player_pos", Context.MODE_PRIVATE) }

    // Daftar video yang sudah selesai ditonton (uri -> true). Posisi parsial ada di "player_pos".
    private val done by lazy { getSharedPreferences("player_done", Context.MODE_PRIVATE) }
    private val handler = Handler(Looper.getMainLooper())
    private val hideHud = Runnable { hud.visibility = View.GONE }

    // Simpan posisi tiap 5 detik selama memutar, supaya tidak hilang kalau aplikasi mati atau keluar lewat PiP.
    private val saver = object : Runnable {
        override fun run() {
            val p = player
            val id = p?.currentMediaItem?.mediaId
            if (p != null && id != null && p.playbackState != Player.STATE_ENDED) {
                saveProgress(id, p.currentPosition, p.duration)
            }
            handler.postDelayed(this, 5000)
        }
    }

    /** Selesai = sisa kurang dari 30 detik atau 5% durasi (mana yang lebih besar), supaya kredit penutup tidak dihitung. */
    private fun saveProgress(id: String, pos: Long, dur: Long) {
        if (dur <= 0L || dur == C.TIME_UNSET || pos < 0L) return
        val doneAt = dur - maxOf(30_000L, dur / 20)
        when {
            pos >= doneAt -> markDone(id)
            pos > 5000L -> {
                if (Prefs.resume(this)) prefs.edit().putLong(id, pos).apply()
                done.edit().remove(id).apply() // ditonton lagi sebagian: bukan "selesai" lagi
            }
            else -> prefs.edit().remove(id).apply()
        }
    }

    private fun markDone(id: String) {
        prefs.edit().remove(id).apply()
        done.edit().putBoolean(id, true).apply()
    }

    private var volF = 0f
    private var brF = 0.5f

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_video)
        playerView = findViewById(R.id.playerView)
        hud = findViewById(R.id.hud)
        tvTitle = findViewById(R.id.tvVideoTitle)

        val arr = intent?.getStringArrayExtra("uris")
        if (arr != null && arr.isNotEmpty()) {
            queue = arr.map { Uri.parse(it) }
            startIndex = intent.getIntExtra("index", 0).coerceIn(0, queue.size - 1)
        } else {
            intent?.data?.let { queue = listOf(it) }
        }
        if (queue.isEmpty()) {
            Toast.makeText(this, "Tidak ada video untuk diputar.", Toast.LENGTH_SHORT).show()
            finish()
            return
        }

        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        WindowInsetsControllerCompat(window, window.decorView).apply {
            systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            hide(WindowInsetsCompat.Type.systemBars())
        }

        playerView.setControllerVisibilityListener(object : PlayerView.ControllerVisibilityListener {
            override fun onVisibilityChanged(visibility: Int) {
                tvTitle.visibility = if (visibility == View.VISIBLE) View.VISIBLE else View.GONE
            }
        })
        setupGestures()
    }

    override fun onStart() {
        super.onStart()
        if (queue.isNotEmpty()) initPlayer()
    }

    override fun onStop() {
        releasePlayer()
        super.onStop()
    }

    override fun onUserLeaveHint() {
        super.onUserLeaveHint()
        if (Build.VERSION.SDK_INT >= 26 && player?.isPlaying == true) {
            try {
                enterPictureInPictureMode(PictureInPictureParams.Builder().build())
            } catch (e: Exception) {
            }
        }
    }

    override fun onPictureInPictureModeChanged(isInPictureInPictureMode: Boolean, newConfig: Configuration) {
        super.onPictureInPictureModeChanged(isInPictureInPictureMode, newConfig)
        playerView.useController = !isInPictureInPictureMode
        if (isInPictureInPictureMode) tvTitle.visibility = View.GONE
    }

    private fun nameOf(u: Uri): String {
        val r: String? = try {
            contentResolver.query(u, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use {
                if (it.moveToFirst()) it.getString(0) else null
            }
        } catch (e: Exception) {
            null
        }
        return r ?: (u.lastPathSegment ?: "Video")
    }

    private var retried = false
    private var forcedPos = -1L

    private fun initPlayer(mode: Int = Prefs.decoder(this)) {
        val p = ExoPlayer.Builder(this, Decoders.factory(this, mode))
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(C.USAGE_MEDIA)
                    .setContentType(C.AUDIO_CONTENT_TYPE_MOVIE)
                    .build(),
                true
            )
            .setHandleAudioBecomingNoisy(true)
            .build()
        val startPos = when {
            forcedPos >= 0 -> forcedPos
            Prefs.resume(this) -> prefs.getLong(queue[startIndex].toString(), 0L)
            else -> 0L
        }
        forcedPos = -1L
        p.setMediaItems(
            queue.map { MediaItem.Builder().setUri(it).setMediaId(it.toString()).build() },
            startIndex,
            startPos
        )
        p.addListener(object : Player.Listener {
            override fun onPlayerError(error: PlaybackException) {
                val dec = error.errorCode == PlaybackException.ERROR_CODE_DECODING_FAILED ||
                    error.errorCode == PlaybackException.ERROR_CODE_DECODER_INIT_FAILED ||
                    error.errorCode == PlaybackException.ERROR_CODE_DECODING_FORMAT_UNSUPPORTED ||
                    error.errorCode == PlaybackException.ERROR_CODE_DECODING_FORMAT_EXCEEDS_CAPABILITIES
                if (dec && !retried && Prefs.decoder(this@VideoActivity) == 0) {
                    retried = true
                    val pl = player
                    val pos = pl?.currentPosition ?: 0L
                    val idx = pl?.currentMediaItemIndex ?: startIndex
                    handler.post {
                        releasePlayer(save = false)
                        startIndex = idx
                        forcedPos = pos
                        Toast.makeText(this@VideoActivity, "Beralih ke decoder FFmpeg...", Toast.LENGTH_SHORT).show()
                        initPlayer(1)
                    }
                    return
                }
                Toast.makeText(
                    this@VideoActivity, "Gagal memutar: ${error.errorCodeName}", Toast.LENGTH_LONG
                ).show()
            }

            override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) {
                mediaItem?.mediaId?.let { tvTitle.text = nameOf(Uri.parse(it)) }
            }

            override fun onPlaybackStateChanged(state: Int) {
                if (state == Player.STATE_ENDED) {
                    player?.currentMediaItem?.mediaId?.let { markDone(it) }
                }
            }

            // Pindah ke video lain di antrean: yang lama selesai (otomatis) atau disimpan posisinya (pindah manual).
            override fun onPositionDiscontinuity(
                oldPosition: Player.PositionInfo,
                newPosition: Player.PositionInfo,
                reason: Int
            ) {
                val oldId = oldPosition.mediaItem?.mediaId ?: return
                if (oldPosition.mediaItemIndex == newPosition.mediaItemIndex) return
                if (reason == Player.DISCONTINUITY_REASON_AUTO_TRANSITION) {
                    markDone(oldId)
                } else {
                    val pl = player ?: return
                    val dur = try {
                        pl.currentTimeline.getWindow(oldPosition.mediaItemIndex, Timeline.Window()).durationMs
                    } catch (e: Exception) {
                        C.TIME_UNSET
                    }
                    saveProgress(oldId, oldPosition.positionMs, dur)
                }
            }
        })
        tvTitle.text = nameOf(queue[startIndex])
        p.prepare()
        p.playWhenReady = true
        playerView.player = p
        player = p
        handler.removeCallbacks(saver)
        handler.postDelayed(saver, 5000)
    }

    private fun releasePlayer(save: Boolean = true) {
        val p = player ?: return
        handler.removeCallbacks(saver)
        val id = p.currentMediaItem?.mediaId
        if (save && id != null && p.playbackState != Player.STATE_ENDED) {
            saveProgress(id, p.currentPosition, p.duration)
        }
        playerView.player = null
        p.release()
        player = null
    }

    private fun showHud(text: String) {
        hud.text = text
        hud.visibility = View.VISIBLE
        handler.removeCallbacks(hideHud)
        handler.postDelayed(hideHud, 700)
    }

    private fun setupGestures() {
        val am = getSystemService(Context.AUDIO_SERVICE) as AudioManager

        val gd = GestureDetector(this, object : GestureDetector.SimpleOnGestureListener() {
            override fun onDown(e: MotionEvent): Boolean {
                volF = am.getStreamVolume(AudioManager.STREAM_MUSIC).toFloat()
                val cur = window.attributes.screenBrightness
                brF = if (cur >= 0f) cur else try {
                    Settings.System.getInt(contentResolver, Settings.System.SCREEN_BRIGHTNESS) / 255f
                } catch (ex: Exception) {
                    0.5f
                }
                return true
            }

            override fun onSingleTapConfirmed(e: MotionEvent): Boolean {
                if (playerView.isControllerFullyVisible) playerView.hideController()
                else playerView.showController()
                return true
            }

            override fun onDoubleTap(e: MotionEvent): Boolean {
                val p = player ?: return true
                val left = e.x < playerView.width / 2f
                val dur = if (p.duration == C.TIME_UNSET) Long.MAX_VALUE else p.duration
                val sec = Prefs.seekSec(this@VideoActivity)
                p.seekTo((p.currentPosition + if (left) -sec * 1000L else sec * 1000L).coerceIn(0L, dur))
                showHud(if (left) "−$sec dtk" else "+$sec dtk")
                return true
            }

            override fun onScroll(
                e1: MotionEvent?, e2: MotionEvent, distanceX: Float, distanceY: Float
            ): Boolean {
                if (!Prefs.gestures(this@VideoActivity)) return false
                if (e1 == null || abs(distanceY) < abs(distanceX)) return false
                val frac = distanceY / playerView.height.toFloat()
                if (e1.x < playerView.width / 2f) {
                    brF = (brF + frac * 1.5f).coerceIn(0.02f, 1f)
                    window.attributes = window.attributes.apply { screenBrightness = brF }
                    showHud("Kecerahan ${(brF * 100).roundToInt()}%")
                } else {
                    val max = am.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
                    volF = (volF + frac * max * 1.5f).coerceIn(0f, max.toFloat())
                    am.setStreamVolume(AudioManager.STREAM_MUSIC, volF.roundToInt(), 0)
                    showHud("Volume ${(volF / max * 100).roundToInt()}%")
                }
                return true
            }
        })
        playerView.setOnTouchListener { _, ev ->
            gd.onTouchEvent(ev)
            true
        }
    }
}
