package com.niven.mangatl

import android.content.Context

/** Pengaturan pemutar (musik & video). Pengaturan ada di dalam layar masing-masing, bukan di launcher. */
object Prefs {
    private fun p(ctx: Context) = ctx.getSharedPreferences("player_settings", Context.MODE_PRIVATE)

    fun int(ctx: Context, k: String, d: Int) = p(ctx).getInt(k, d)
    fun setInt(ctx: Context, k: String, v: Int) = p(ctx).edit().putInt(k, v).apply()
    fun bool(ctx: Context, k: String, d: Boolean) = p(ctx).getBoolean(k, d)
    fun setBool(ctx: Context, k: String, v: Boolean) = p(ctx).edit().putBoolean(k, v).apply()
    fun str(ctx: Context, k: String): String? = p(ctx).getString(k, null)
    fun setStr(ctx: Context, k: String, v: String?) = p(ctx).edit().putString(k, v).apply()

    /** 0 = otomatis (FFmpeg jadi cadangan), 1 = utamakan FFmpeg, 2 = hanya decoder bawaan HP */
    fun decoder(ctx: Context) = int(ctx, "decoder", 0)
    fun seekSec(ctx: Context) = int(ctx, "seek_sec", 10)
    fun gestures(ctx: Context) = bool(ctx, "gestures", true)
    fun resume(ctx: Context) = bool(ctx, "resume", true)
    fun mosaic(ctx: Context) = bool(ctx, "mosaic", true)
    fun thumbAnim(ctx: Context) = bool(ctx, "thumb_anim", true)
    fun subShow(ctx: Context) = bool(ctx, "sub_show", true)
    fun subBg(ctx: Context) = bool(ctx, "sub_bg", false)
    /** Ukuran subtitle dalam persen (50..250). */
    fun subSize(ctx: Context) = int(ctx, "sub_size", 100)
    fun lyricsOnline(ctx: Context) = bool(ctx, "lyrics_online", false)

    // ----- tab musik: urutan & tampil/sembunyi -----
    val TAB_NAMES = arrayOf("Lagu", "Album", "Artis", "Folder", "Playlist")

    fun tabOrder(ctx: Context): List<Int> {
        val saved = str(ctx, "tab_order")?.split(",")?.mapNotNull { it.toIntOrNull() }
            ?.filter { it in TAB_NAMES.indices }?.distinct() ?: emptyList()
        val rest = TAB_NAMES.indices.filter { it !in saved }
        return saved + rest
    }

    fun tabHidden(ctx: Context): Set<Int> =
        (str(ctx, "tab_hidden") ?: "").split(",").mapNotNull { it.toIntOrNull() }.toSet()

    fun saveTabs(ctx: Context, order: List<Int>, hidden: Set<Int>) {
        setStr(ctx, "tab_order", order.joinToString(","))
        setStr(ctx, "tab_hidden", hidden.joinToString(","))
    }

    fun visibleTabs(ctx: Context): List<Int> {
        val h = tabHidden(ctx)
        val v = tabOrder(ctx).filter { it !in h }
        return if (v.isEmpty()) listOf(0) else v
    }
}
