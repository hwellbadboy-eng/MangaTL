package com.niven.mangatl

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.view.MotionEvent
import android.view.View

/**
 * Layar penuh untuk mengatur kotak area terjemahan.
 * Geser di dalam kotak = pindah. Tarik salah satu sudut = ubah ukuran.
 * Posisi disimpan sebagai pecahan layar (0..1) supaya tetap pas di rotasi/resolusi lain.
 */
class AreaEditorView(
    context: Context,
    initial: RectF,
    private val title: String,
    private val onDone: (RectF?) -> Unit
) : View(context) {

    private enum class Drag { NONE, MOVE, TL, TR, BL, BR, SAVE, CANCEL }

    private val d = resources.displayMetrics.density
    private var fl = initial.left
    private var ft = initial.top
    private var fr = initial.right
    private var fb = initial.bottom

    private val dim = Paint().apply {
        color = 0x99000000.toInt()
        style = Paint.Style.FILL
    }
    private val line = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = 0xFF9C7BFF.toInt()
        style = Paint.Style.STROKE
        strokeWidth = 2f * d
    }
    private val handle = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = 0xFF9C7BFF.toInt()
        style = Paint.Style.FILL
    }
    private val btnPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val txt = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        textSize = 16f * d
        isFakeBoldText = true
    }
    private val hint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        textSize = 13f * d
        textAlign = Paint.Align.CENTER
    }
    private val path = Path()
    private val save = RectF()
    private val cancel = RectF()
    private var drag = Drag.NONE
    private var lx = 0f
    private var ly = 0f

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        val cx = w / 2f
        save.set(cx - 128f * d, 72f * d, cx - 8f * d, 120f * d)
        cancel.set(cx + 8f * d, 72f * d, cx + 128f * d, 120f * d)
    }

    private fun pixelRect(): RectF = RectF(fl * width, ft * height, fr * width, fb * height)

    override fun onDraw(c: Canvas) {
        val r = pixelRect()

        // Gelapkan semua bagian di luar kotak.
        path.reset()
        path.fillType = Path.FillType.EVEN_ODD
        path.addRect(0f, 0f, width.toFloat(), height.toFloat(), Path.Direction.CW)
        path.addRect(r, Path.Direction.CW)
        c.drawPath(path, dim)

        c.drawRect(r, line)
        val corners = listOf(
            Pair(r.left, r.top), Pair(r.right, r.top),
            Pair(r.left, r.bottom), Pair(r.right, r.bottom)
        )
        for (p in corners) c.drawCircle(p.first, p.second, 11f * d, handle)

        txt.textAlign = Paint.Align.LEFT
        c.drawText(title, r.left + 14f * d, r.top + 28f * d, txt)

        txt.textAlign = Paint.Align.CENTER
        btnPaint.color = 0xFF2E7D32.toInt()
        c.drawRoundRect(save, 12f * d, 12f * d, btnPaint)
        c.drawText("Simpan", save.centerX(), save.centerY() + 6f * d, txt)
        btnPaint.color = 0xFFB71C1C.toInt()
        c.drawRoundRect(cancel, 12f * d, 12f * d, btnPaint)
        c.drawText("Batal", cancel.centerX(), cancel.centerY() + 6f * d, txt)

        c.drawText("Geser kotak untuk memindah, tarik sudut untuk mengubah ukuran", width / 2f, 148f * d, hint)
    }

    private fun near(x: Float, y: Float, px: Float, py: Float): Boolean {
        val dx = x - px
        val dy = y - py
        return dx * dx + dy * dy < (36f * d) * (36f * d)
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        val x = e.x
        val y = e.y
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                val r = pixelRect()
                drag = when {
                    save.contains(x, y) -> Drag.SAVE
                    cancel.contains(x, y) -> Drag.CANCEL
                    near(x, y, r.left, r.top) -> Drag.TL
                    near(x, y, r.right, r.top) -> Drag.TR
                    near(x, y, r.left, r.bottom) -> Drag.BL
                    near(x, y, r.right, r.bottom) -> Drag.BR
                    r.contains(x, y) -> Drag.MOVE
                    else -> Drag.NONE
                }
                lx = x
                ly = y
            }
            MotionEvent.ACTION_MOVE -> {
                val dx = (x - lx) / width
                val dy = (y - ly) / height
                lx = x
                ly = y
                val min = 0.08f
                when (drag) {
                    Drag.MOVE -> {
                        val w = fr - fl
                        val h = fb - ft
                        fl = (fl + dx).coerceIn(0f, 1f - w)
                        ft = (ft + dy).coerceIn(0f, 1f - h)
                        fr = fl + w
                        fb = ft + h
                    }
                    Drag.TL -> {
                        fl = (fl + dx).coerceIn(0f, fr - min)
                        ft = (ft + dy).coerceIn(0f, fb - min)
                    }
                    Drag.TR -> {
                        fr = (fr + dx).coerceIn(fl + min, 1f)
                        ft = (ft + dy).coerceIn(0f, fb - min)
                    }
                    Drag.BL -> {
                        fl = (fl + dx).coerceIn(0f, fr - min)
                        fb = (fb + dy).coerceIn(ft + min, 1f)
                    }
                    Drag.BR -> {
                        fr = (fr + dx).coerceIn(fl + min, 1f)
                        fb = (fb + dy).coerceIn(ft + min, 1f)
                    }
                    else -> {
                    }
                }
                invalidate()
            }
            MotionEvent.ACTION_UP -> {
                if (drag == Drag.SAVE && save.contains(x, y)) {
                    onDone(RectF(fl, ft, fr, fb))
                } else if (drag == Drag.CANCEL && cancel.contains(x, y)) {
                    onDone(null)
                }
                drag = Drag.NONE
            }
            MotionEvent.ACTION_CANCEL -> {
                drag = Drag.NONE
            }
        }
        return true
    }
}
