package com.niven.mangatl

import android.content.Context
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import android.os.Handler
import android.os.Looper
import android.util.Log
import com.k2fsa.sherpa.onnx.OfflineModelConfig
import com.k2fsa.sherpa.onnx.OfflineRecognizer
import com.k2fsa.sherpa.onnx.OfflineRecognizerConfig
import com.k2fsa.sherpa.onnx.OfflineWhisperModelConfig
import java.io.File
import kotlin.math.sqrt

/**
 * Telinga 100% offline: Whisper lewat sherpa-onnx.
 * Taruh folder model Whisper di folder data app, mis. files/Whisper/ berisi
 * *-encoder*.onnx, *-decoder*.onnx, dan *-tokens.txt (hasil ekstrak sherpa-onnx-whisper-small / base).
 *
 * Alur: rekam -> deteksi berhenti ngomong (berdasarkan volume) -> Whisper ubah jadi teks.
 */
object Ear {

    private const val SR = 16000
    private const val FRAME = 480 // 30 ms
    private const val FRAME_MS = 30
    private const val MAX_SPEECH_MS = 28_000   // batas Whisper 30 detik
    private const val WAIT_SPEECH_MS = 9_000   // nunggu orang mulai ngomong
    private const val MIN_SPEECH_MS = 300      // di bawah ini dianggap bunyi nyasar
    private const val PREROLL_FRAMES = 10      // 300 ms sebelum bicara ikut direkam
    private const val CALIB_FRAMES = 8         // 240 ms awal untuk ukur bising ruangan
    private const val KEEP_TAIL_MS = 300

    const val NOSPEECH = "NOSPEECH"

    private var rec: OfflineRecognizer? = null
    private var recDir: String? = null
    private val lock = Any()
    private val main = Handler(Looper.getMainLooper())

    @Volatile
    private var gen = 0

    @Volatile
    private var phase = 0 // 0 diam, 1 memuat, 2 merekam, 3 mengenali

    @Volatile
    private var finishReq = false

    // ------------------------------------------------------------------ model

    private fun pick(dir: File, key: String, ext: String): File? {
        val c = dir.listFiles()?.filter {
            it.isFile && it.name.contains(key, ignoreCase = true) && it.name.endsWith(ext)
        } ?: return null
        return c.firstOrNull { it.name.contains("int8", ignoreCase = true) } ?: c.firstOrNull()
    }

    private fun isModelDir(d: File): Boolean =
        d.isDirectory && !File(d, "voice.bin").isFile &&
            pick(d, "encoder", ".onnx") != null &&
            pick(d, "decoder", ".onnx") != null &&
            pick(d, "tokens", ".txt") != null

    fun findModel(context: Context): File? {
        val root = context.getExternalFilesDir(null) ?: return null
        return try {
            root.walkTopDown().maxDepth(3).filter { isModelDir(it) }.sortedBy { it.path }.firstOrNull()
        } catch (_: Throwable) {
            null
        }
    }

    fun available(context: Context): Boolean = findModel(context) != null

    private fun ensure(dir: File): OfflineRecognizer {
        synchronized(lock) {
            val cur = rec
            if (cur != null && recDir == dir.absolutePath) return cur
            try {
                cur?.release()
            } catch (_: Throwable) {
            }
            rec = null
            val cfg = OfflineRecognizerConfig(
                modelConfig = OfflineModelConfig(
                    whisper = OfflineWhisperModelConfig(
                        encoder = pick(dir, "encoder", ".onnx")!!.absolutePath,
                        decoder = pick(dir, "decoder", ".onnx")!!.absolutePath,
                        language = "id",
                        task = "transcribe"
                    ),
                    tokens = pick(dir, "tokens", ".txt")!!.absolutePath,
                    numThreads = 4,
                    provider = "cpu",
                    modelType = "whisper"
                )
            )
            val r = OfflineRecognizer(config = cfg)
            rec = r
            recDir = dir.absolutePath
            return r
        }
    }

    /** Muat model di latar belakang supaya ketukan Mic pertama tidak menunggu. */
    fun preload(context: Context) {
        val appCtx = context.applicationContext
        Thread {
            try {
                ensure(findModel(appCtx) ?: return@Thread)
            } catch (_: Throwable) {
            }
        }.start()
    }

    fun release() {
        cancel()
        synchronized(lock) {
            try {
                rec?.release()
            } catch (_: Throwable) {
            }
            rec = null
            recDir = null
        }
    }

    // ------------------------------------------------------------------ kontrol

    /** Batalkan tanpa hasil. */
    fun cancel() {
        gen++
        phase = 0
    }

    /** Berhenti merekam sekarang lalu langsung dikenali. true kalau memang lagi merekam. */
    fun finishNow(): Boolean {
        if (phase == 2) {
            finishReq = true
            return true
        }
        return false
    }

    private val ghosts = listOf(
        "terima kasih telah menonton", "terima kasih sudah menonton",
        "thanks for watching", "amara.org", "subtitles by"
    )

    /** Whisper kadang "mengarang" kalimat dari bunyi bising; buang yang jelas-jelas begitu. */
    private fun isGhost(t: String): Boolean {
        if (t.none { it.isLetterOrDigit() }) return true
        val l = t.lowercase()
        return l.length < 70 && ghosts.any { l.contains(it) }
    }

    // ------------------------------------------------------------------ dengar

    /**
     * Dengar satu ucapan. Callback dipanggil di thread utama.
     * onState: "load" (memuat model), "listen" (merekam), "think" (mengenali).
     * onDone(text, err): text = hasil; err = NOSPEECH kalau tidak ada ucapan, atau pesan error.
     * Kalau dibatalkan lewat cancel(), onDone tidak dipanggil.
     */
    fun listen(
        context: Context,
        silenceMs: Int,
        onState: (String) -> Unit,
        onDone: (String?, String?) -> Unit
    ) {
        val appCtx = context.applicationContext
        cancel()
        val my = ++gen
        finishReq = false
        Thread {
            var text: String? = null
            var err: String? = null
            var audio: AudioRecord? = null
            try {
                val dir = findModel(appCtx) ?: throw IllegalStateException("Model Whisper belum ada")
                phase = 1
                if (rec == null || recDir != dir.absolutePath) main.post { if (gen == my) onState("load") }
                val r = ensure(dir)
                if (gen != my) return@Thread

                val minBuf = AudioRecord.getMinBufferSize(
                    SR, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT
                )
                audio = AudioRecord(
                    MediaRecorder.AudioSource.VOICE_RECOGNITION, SR,
                    AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT,
                    maxOf(minBuf, SR)
                )
                if (audio.state != AudioRecord.STATE_INITIALIZED) {
                    throw IllegalStateException("Mikrofon tidak bisa dibuka")
                }
                audio.startRecording()
                phase = 2
                main.post { if (gen == my) onState("listen") }

                val shorts = ShortArray(FRAME)
                val pre = ArrayDeque<FloatArray>()
                val speech = ArrayList<FloatArray>()
                var started = false
                var voiced = 0
                var silent = 0
                var waited = 0
                var calib = 0
                var calibSum = 0.0
                var floor = 0.004

                while (gen == my) {
                    var got = 0
                    while (got < FRAME) {
                        val n = audio.read(shorts, got, FRAME - got)
                        if (n <= 0) throw IllegalStateException("Mikrofon berhenti")
                        got += n
                    }
                    val f = FloatArray(FRAME) { shorts[it] / 32768f }
                    var sum = 0.0
                    for (v in f) sum += (v * v).toDouble()
                    val rms = sqrt(sum / FRAME)

                    if (finishReq) break

                    if (calib < CALIB_FRAMES) {
                        calibSum += rms
                        calib++
                        pre.addLast(f)
                        if (pre.size > PREROLL_FRAMES) pre.removeFirst()
                        if (calib == CALIB_FRAMES) floor = (calibSum / CALIB_FRAMES).coerceIn(0.002, 0.012)
                        continue
                    }
                    val startThr = (floor * 3.0).coerceIn(0.012, 0.05)
                    val endThr = (floor * 1.8).coerceIn(0.008, 0.03)

                    if (!started) {
                        pre.addLast(f)
                        if (pre.size > PREROLL_FRAMES) pre.removeFirst()
                        if (rms > startThr) {
                            started = true
                            speech.addAll(pre)
                            pre.clear()
                            voiced = 1
                            silent = 0
                        } else {
                            floor = (floor * 0.98 + rms * 0.02).coerceIn(0.002, 0.012)
                            waited += FRAME_MS
                            if (waited > WAIT_SPEECH_MS) break
                        }
                    } else {
                        speech.add(f)
                        if (rms > endThr) {
                            silent = 0
                            if (rms > startThr) voiced++
                        } else {
                            silent += FRAME_MS
                        }
                        if (silent >= silenceMs) break
                        if (speech.size * FRAME_MS > MAX_SPEECH_MS) break
                    }
                }
                if (gen != my) return@Thread

                try {
                    audio.stop()
                } catch (_: Throwable) {
                }

                if (!started || voiced * FRAME_MS < MIN_SPEECH_MS) {
                    err = NOSPEECH
                } else {
                    phase = 3
                    main.post { if (gen == my) onState("think") }
                    val drop = ((silent - KEEP_TAIL_MS) / FRAME_MS).coerceAtLeast(0)
                    val keep = (speech.size - drop).coerceAtLeast(1)
                    val samples = FloatArray(keep * FRAME)
                    for (i in 0 until keep) System.arraycopy(speech[i], 0, samples, i * FRAME, FRAME)

                    val t0 = System.nanoTime()
                    val out = synchronized(lock) {
                        if (rec !== r) {
                            ""
                        } else {
                            val st = r.createStream()
                            try {
                                st.acceptWaveform(samples, SR)
                                r.decode(st)
                                r.getResult(st).text.trim()
                            } finally {
                                try {
                                    st.release()
                                } catch (_: Throwable) {
                                }
                            }
                        }
                    }
                    Log.d(
                        "BunnyEar",
                        "ucapan ${samples.size * 1000L / SR} ms, dikenali ${(System.nanoTime() - t0) / 1_000_000} ms: $out"
                    )
                    if (out.isBlank() || isGhost(out)) err = NOSPEECH else text = out
                }
            } catch (t: Throwable) {
                err = t.message ?: t::class.java.simpleName
            } finally {
                try {
                    audio?.release()
                } catch (_: Throwable) {
                }
                if (gen == my) {
                    phase = 0
                    val tt = text
                    val ee = err
                    main.post { if (gen == my) onDone(tt, ee) }
                }
            }
        }.start()
    }
}
