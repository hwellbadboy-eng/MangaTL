package com.niven.mangatl

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.Rect
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.Image
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.HandlerThread
import android.os.IBinder
import android.os.Looper
import android.os.SystemClock
import android.text.method.ScrollingMovementMethod
import android.util.DisplayMetrics
import android.util.TypedValue
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.TextView
import android.widget.Toast
import androidx.core.app.NotificationCompat
import androidx.core.content.IntentCompat
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import kotlin.math.abs

/**
 * Mode game: tombol "TL" melayang. Ketuk = ambil layar, baca teks (OCR), terjemahkan dengan Gemma,
 * lalu tampilkan hasilnya di atas game. Tekan lama tombol (sekitar 1 detik) = berhenti.
 */
class ScreenService : Service() {

    companion object {
        const val ACTION_STOP = "com.niven.mangatl.STOP"
        private const val CHANNEL = "bunnytl_screen"
        private const val NOTIF_ID = 77

        @Volatile
        var running = false
    }

    private val main = Handler(Looper.getMainLooper())
    private var thread: HandlerThread? = null
    private var cap: Handler? = null
    private var wm: WindowManager? = null
    private var fab: TextView? = null
    private var fabLp: WindowManager.LayoutParams? = null
    private var panel: TextView? = null
    private var panelLp: WindowManager.LayoutParams? = null
    private var ov: OverlayView? = null

    private var projection: MediaProjection? = null
    private var projCb: MediaProjection.Callback? = null
    private var vd: VirtualDisplay? = null
    private var reader: ImageReader? = null
    private var capW = 0
    private var capH = 0
    private var dpi = 320

    @Volatile
    private var wantFrame = false

    @Volatile
    private var busy = false

    private val recognizer by lazy { TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS) }

    private var lastKey = ""
    private var lastMode = -1
    private var lastOut = ""
    private var lastItems: List<OverlayView.Item> = emptyList()

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopSelf()
            return START_NOT_STICKY
        }
        val code = intent?.getIntExtra("code", 0) ?: 0
        val data = intent?.let { IntentCompat.getParcelableExtra(it, "data", Intent::class.java) }
        if (data == null) {
            stopSelf()
            return START_NOT_STICKY
        }

        cleanup()
        startFg()

        try {
            val mpm = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
            val p = mpm.getMediaProjection(code, data)
            val cb = object : MediaProjection.Callback() {
                override fun onStop() {
                    main.post { stopSelf() }
                }
            }
            p.registerCallback(cb, main)
            projection = p
            projCb = cb

            val t = HandlerThread("bunnytl-cap")
            t.start()
            thread = t
            cap = Handler(t.looper)

            wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
            addOverlays()

            running = true

            // Muat model dari awal supaya ketukan pertama tidak lama.
            Thread {
                try {
                    Gemma.findModel(this)?.let { Gemma.warmUp(applicationContext, it) }
                } catch (_: Throwable) {
                }
            }.start()
        } catch (t: Throwable) {
            Toast.makeText(this, "Mode game gagal: ${t.message}", Toast.LENGTH_LONG).show()
            stopSelf()
        }
        return START_NOT_STICKY
    }

    private fun startFg() {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL, "Mode game", NotificationManager.IMPORTANCE_LOW)
        )
        val stop = PendingIntent.getService(
            this, 0,
            Intent(this, ScreenService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val n = NotificationCompat.Builder(this, CHANNEL)
            .setContentTitle("BunnyTL mode game aktif")
            .setContentText("Ketuk tombol TL di layar untuk menerjemahkan")
            .setSmallIcon(android.R.drawable.ic_menu_view)
            .setOngoing(true)
            .addAction(android.R.drawable.ic_menu_close_clear_cancel, "Berhenti", stop)
            .build()
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
        } else {
            startForeground(NOTIF_ID, n)
        }
    }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    @Suppress("DEPRECATION")
    private fun realSize(): IntArray {
        val dm = DisplayMetrics()
        wm!!.defaultDisplay.getRealMetrics(dm)
        return intArrayOf(dm.widthPixels, dm.heightPixels, dm.densityDpi)
    }

    private fun prefs() = getSharedPreferences("mangatl", Context.MODE_PRIVATE)

    // ---------------------------------------------------------------- overlay

    private fun addOverlays() {
        val manager = wm!!

        val o = OverlayView(this)
        val olp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )
        olp.gravity = Gravity.TOP or Gravity.START
        if (Build.VERSION.SDK_INT >= 28) {
            olp.layoutInDisplayCutoutMode =
                WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        }

        val f = TextView(this)
        f.text = "TL"
        f.setTextColor(Color.WHITE)
        f.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14f)
        f.typeface = Typeface.DEFAULT_BOLD
        f.gravity = Gravity.CENTER
        f.setBackgroundResource(R.drawable.bubble_fab)
        f.alpha = 0.85f

        val lp = WindowManager.LayoutParams(
            dp(48), dp(48),
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        )
        lp.gravity = Gravity.TOP or Gravity.START
        lp.x = dp(8)
        lp.y = dp(160)

        f.setOnTouchListener(object : View.OnTouchListener {
            var sx = 0f
            var sy = 0f
            var ox = 0
            var oy = 0
            var moved = false
            var downT = 0L

            override fun onTouch(v: View, e: MotionEvent): Boolean {
                when (e.action) {
                    MotionEvent.ACTION_DOWN -> {
                        sx = e.rawX
                        sy = e.rawY
                        ox = lp.x
                        oy = lp.y
                        moved = false
                        downT = SystemClock.uptimeMillis()
                        return true
                    }
                    MotionEvent.ACTION_MOVE -> {
                        val dx = e.rawX - sx
                        val dy = e.rawY - sy
                        if (!moved && (abs(dx) > dp(8) || abs(dy) > dp(8))) moved = true
                        if (moved) {
                            lp.x = (ox + dx).toInt()
                            lp.y = (oy + dy).toInt()
                            try {
                                manager.updateViewLayout(v, lp)
                            } catch (_: Throwable) {
                            }
                        }
                        return true
                    }
                    MotionEvent.ACTION_UP -> {
                        if (!moved) {
                            if (SystemClock.uptimeMillis() - downT > 900) stopSelf() else onTap()
                        }
                        return true
                    }
                }
                return false
            }
        })

        val p = TextView(this)
        p.setTextColor(Color.WHITE)
        p.setTextSize(TypedValue.COMPLEX_UNIT_SP, 16f)
        p.setPadding(dp(14), dp(10), dp(14), dp(10))
        p.setBackgroundResource(R.drawable.panel_bg)
        p.movementMethod = ScrollingMovementMethod()
        p.visibility = View.GONE
        p.setOnClickListener { p.visibility = View.GONE }

        val plp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT
        )
        plp.gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL

        manager.addView(o, olp)
        manager.addView(p, plp)
        manager.addView(f, lp)
        ov = o

        fab = f
        fabLp = lp
        panel = p
        panelLp = plp
    }

    private fun showPanel(text: String) {
        val p = panel ?: return
        val lp = panelLp ?: return
        val size = realSize()
        val atBottom = prefs().getInt("pos", 0) == 2
        lp.width = (size[0] * 0.9).toInt()
        lp.gravity = (if (atBottom) Gravity.BOTTOM else Gravity.TOP) or Gravity.CENTER_HORIZONTAL
        lp.y = dp(24)
        p.maxHeight = (size[1] * 0.5).toInt()
        p.text = text
        p.scrollTo(0, 0)
        p.visibility = View.VISIBLE
        try {
            wm?.updateViewLayout(p, lp)
        } catch (_: Throwable) {
        }
    }

    private fun overlayShown(): Boolean =
        (ov?.items?.isNotEmpty() == true) || panel?.visibility == View.VISIBLE

    private fun finishCapture() {
        busy = false
        fab?.text = if (overlayShown()) "X" else "TL"
        fab?.visibility = View.VISIBLE
    }

    /** Hapus semua hasil terjemahan dari layar. */
    private fun clearResults() {
        ov?.setItems(emptyList())
        panel?.visibility = View.GONE
        fab?.text = "TL"
    }

    /** Pesan singkat (error / tidak ada teks) yang hilang sendiri. */
    private fun showMessage(msg: String) {
        showPanel(msg)
        finishCapture()
        main.postDelayed({
            if (!busy && ov?.items?.isEmpty() != false) clearResults()
        }, 2500)
    }

    private fun fail(msg: String) {
        main.post { showMessage(msg) }
    }

    // ---------------------------------------------------------------- ambil layar

    private fun onTap() {
        if (busy) {
            Toast.makeText(this, "Masih memproses...", Toast.LENGTH_SHORT).show()
            return
        }
        // Hasil sedang tampil: tutup dulu. Default-nya langsung terjemahkan layar berikutnya (1 ketukan per dialog).
        val hadResult = overlayShown()
        if (hadResult) {
            clearResults()
            if (prefs().getInt("tapnext", 0) == 1) return
        }
        busy = true
        // Sembunyikan tombol supaya tidak ikut terbaca OCR.
        fab?.visibility = View.INVISIBLE
        cap?.postDelayed({ requestFrame() }, if (hadResult) 260L else 160L)
    }

    private val listener = ImageReader.OnImageAvailableListener { r ->
        val img: Image? = try {
            r.acquireLatestImage()
        } catch (_: Throwable) {
            null
        }
        if (img != null) {
            try {
                if (wantFrame) {
                    wantFrame = false
                    process(toBitmap(img))
                }
            } catch (t: Throwable) {
                fail("Gagal ambil layar: ${t.message}")
            } finally {
                img.close()
            }
        }
    }

    private fun ensureDisplay(w: Int, h: Int) {
        if (reader != null && vd != null && w == capW && h == capH) return
        val newReader = ImageReader.newInstance(w, h, PixelFormat.RGBA_8888, 2)
        newReader.setOnImageAvailableListener(listener, cap)
        val old = reader
        val existing = vd
        if (existing == null) {
            vd = projection!!.createVirtualDisplay(
                "bunnytl", w, h, dpi,
                DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
                newReader.surface, null, cap
            )
        } else {
            existing.resize(w, h, dpi)
            existing.setSurface(newReader.surface)
        }
        reader = newReader
        capW = w
        capH = h
        try {
            old?.close()
        } catch (_: Throwable) {
        }
    }

    private fun requestFrame() {
        try {
            val s = realSize()
            dpi = s[2]
            ensureDisplay(s[0], s[1])
            wantFrame = true
            cap?.postDelayed({
                if (wantFrame) {
                    wantFrame = false
                    // Layar statis: coba ambil frame terakhir yang tersedia.
                    val img: Image? = try {
                        reader?.acquireLatestImage()
                    } catch (_: Throwable) {
                        null
                    }
                    if (img != null) {
                        try {
                            process(toBitmap(img))
                        } catch (t: Throwable) {
                            fail("Gagal ambil layar: ${t.message}")
                        } finally {
                            img.close()
                        }
                    } else {
                        fail("Gagal ambil layar, coba ketuk lagi.")
                    }
                }
            }, 1500)
        } catch (t: Throwable) {
            fail("Gagal ambil layar: ${t.message}")
        }
    }

    private fun toBitmap(img: Image): Bitmap {
        val plane = img.planes[0]
        val pixelStride = plane.pixelStride
        val rowPadding = plane.rowStride - pixelStride * img.width
        val wide = Bitmap.createBitmap(
            img.width + rowPadding / pixelStride, img.height, Bitmap.Config.ARGB_8888
        )
        wide.copyPixelsFromBuffer(plane.buffer)
        return if (wide.width == img.width) {
            wide
        } else {
            Bitmap.createBitmap(wide, 0, 0, img.width, img.height)
        }
    }

    // ------------------------------------------------------- OCR + terjemahan

    private fun process(full: Bitmap) {
        // Tombol sudah aman muncul lagi: layar sudah terambil.
        main.post {
            fab?.text = "..."
            fab?.visibility = View.VISIBLE
        }

        val frac = when (prefs().getInt("scan", 0)) {
            1 -> 0.5
            2 -> 0.34
            else -> 1.0
        }
        val top = (full.height * (1.0 - frac)).toInt().coerceIn(0, full.height - 1)
        val crop = if (top == 0) full else Bitmap.createBitmap(full, 0, top, full.width, full.height - top)

        recognizer
            .process(InputImage.fromBitmap(crop, 0))
            .addOnSuccessListener { text ->
                val found = text.textBlocks.mapNotNull { b ->
                    val box = b.boundingBox
                    val t = b.text.replace("\n", " ").trim()
                    if (box == null || t.isEmpty()) null else Pair(box, t)
                }
                val pairs = TextUtil.readingOrderPairs(found)
                    .filter { TextUtil.isTranslatable(TextUtil.normalizeForModel(it.second)) }
                    .take(16)

                if (pairs.isEmpty()) {
                    showMessage("Tidak ada teks terdeteksi.")
                    return@addOnSuccessListener
                }

                val mode = prefs().getInt("pos", 0)
                val alpha = prefs().getInt("ov_alpha", 92).coerceIn(20, 100) * 255 / 100
                main.post { ov?.bgAlpha = alpha }
                val lines = pairs.map { it.second }
                // Posisi di layar = posisi di potongan + jarak potongan dari atas layar.
                val boxes = pairs.map { Rect(it.first.left, it.first.top + top, it.first.right, it.first.bottom + top) }
                val bgs = if (mode == 0) pairs.map { TextUtil.sampleBg(crop, it.first) } else emptyList()

                val key = pairs.joinToString("|") { "${it.second}@${it.first.left / 8},${it.first.top / 8}" }
                if (key == lastKey && mode == lastMode) {
                    if (mode == 0 && lastItems.isNotEmpty()) {
                        ov?.setItems(lastItems)
                        finishCapture()
                        return@addOnSuccessListener
                    }
                    if (mode != 0 && lastOut.isNotEmpty()) {
                        showPanel(lastOut)
                        finishCapture()
                        return@addOnSuccessListener
                    }
                }

                if (mode != 0) showPanel("Menerjemahkan...")
                translateLines(lines, boxes, bgs, key, mode)
            }
            .addOnFailureListener { e ->
                fail("OCR gagal: ${e.message}")
            }
    }

    private fun render(lines: List<String>, tr: List<String?>): String {
        val parts = tr.indices.mapNotNull { i ->
            val t = tr[i]
            if (t == null) null else t.ifBlank { lines.getOrElse(i) { "" } }
        }
        return if (parts.isEmpty()) "Menerjemahkan..." else parts.joinToString("\n")
    }

    /** Susun kotak terjemahan yang menimpa teks asli, warnanya mengikuti latar sekitar teks. */
    private fun buildItems(boxes: List<Rect>, bgs: List<Int>, tr: List<String?>): List<OverlayView.Item> {
        val out = ArrayList<OverlayView.Item>()
        for (i in boxes.indices) {
            val t = tr.getOrNull(i)
            if (t.isNullOrBlank()) continue
            val bg = bgs.getOrElse(i) { Color.BLACK }
            val fg = if (TextUtil.luminance(bg) > 140) 0xFF111111.toInt() else Color.WHITE
            out.add(OverlayView.Item(boxes[i], t, bg, fg))
        }
        return out
    }

    private fun translateLines(lines: List<String>, boxes: List<Rect>, bgs: List<Int>, key: String, mode: Int) {
        val p = prefs()
        val styles = Gemma.Style.values()
        val style = styles[p.getInt("style", 0).coerceIn(0, styles.size - 1)]
        val glossary = p.getString("glossary", "") ?: ""

        Thread {
            try {
                val model = Gemma.findModel(this)
                    ?: throw IllegalStateException("Model .litertlm belum ada")
                // Mode cepat: cache per baris, prompt pendek, hasil muncul bertahap (streaming).
                val res = Gemma.translateFast(
                    applicationContext, model, lines, style, glossary,
                    onProgress = { tr ->
                        main.post {
                            if (mode == 0) ov?.setItems(buildItems(boxes, bgs, tr))
                            else showPanel(render(lines, tr))
                        }
                    }
                )
                lastKey = key
                lastMode = mode
                if (mode == 0) {
                    lastItems = buildItems(boxes, bgs, res.lines)
                    lastOut = ""
                } else {
                    lastOut = render(lines, res.lines)
                    lastItems = emptyList()
                }
                main.post {
                    if (mode == 0) ov?.setItems(lastItems) else showPanel(lastOut)
                    finishCapture()
                }
            } catch (t: Throwable) {
                fail("Gagal: ${t.message}")
            }
        }.start()
    }

    // ---------------------------------------------------------------- bersih-bersih

    private fun cleanup() {
        try {
            fab?.let { wm?.removeView(it) }
        } catch (_: Throwable) {
        }
        try {
            panel?.let { wm?.removeView(it) }
        } catch (_: Throwable) {
        }
        try {
            ov?.let { wm?.removeView(it) }
        } catch (_: Throwable) {
        }
        ov = null
        fab = null
        panel = null
        try {
            vd?.release()
        } catch (_: Throwable) {
        }
        vd = null
        try {
            reader?.close()
        } catch (_: Throwable) {
        }
        reader = null
        capW = 0
        capH = 0
        try {
            projCb?.let { projection?.unregisterCallback(it) }
            projection?.stop()
        } catch (_: Throwable) {
        }
        projection = null
        projCb = null
        try {
            thread?.quitSafely()
        } catch (_: Throwable) {
        }
        thread = null
        cap = null
        busy = false
        wantFrame = false
    }

    override fun onDestroy() {
        running = false
        try {
            recognizer.close()
        } catch (_: Throwable) {
        }
        cleanup()
        super.onDestroy()
    }
}
