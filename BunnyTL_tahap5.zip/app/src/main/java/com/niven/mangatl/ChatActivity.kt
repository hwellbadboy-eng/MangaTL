package com.niven.mangatl

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import androidx.activity.result.contract.ActivityResultContracts
import android.view.Gravity
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import android.widget.Button
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

class ChatActivity : AppCompatActivity() {

    class Msg(val isUser: Boolean, var text: String)

    companion object {
        // Riwayat tetap ada selama app hidup, walau layar chat ditutup lalu dibuka lagi.
        private val store = ArrayList<Msg>()
    }

    private lateinit var list: RecyclerView
    private lateinit var input: EditText
    private lateinit var btnSend: Button
    private lateinit var adapter: MsgAdapter
    private var sending = false
    private lateinit var btnMic: Button
    private lateinit var btnVoice: Button
    private var recognizer: SpeechRecognizer? = null
    private var listening = false

    private val micPerm = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { ok ->
        if (ok) startListening()
        else Toast.makeText(this, "Izin mikrofon ditolak.", Toast.LENGTH_SHORT).show()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_chat)

        list = findViewById(R.id.list)
        input = findViewById(R.id.input)
        btnSend = findViewById(R.id.btnSend)
        btnMic = findViewById(R.id.btnMic)
        btnMic.setOnClickListener { onMic() }
        btnVoice = findViewById(R.id.btnVoice)
        updateVoiceButton()
        btnVoice.setOnClickListener {
            val on = !Voice.autoSpeak(this)
            if (on && Voice.findVoice(this) == null) {
                Toast.makeText(
                    this,
                    "Model suara belum ada. Salin folder model Supertonic ke:\n${getExternalFilesDir(null)}",
                    Toast.LENGTH_LONG
                ).show()
                return@setOnClickListener
            }
            Voice.setAutoSpeak(this, on)
            if (!on) Voice.stop()
            updateVoiceButton()
        }

        adapter = MsgAdapter(store) { m -> speakMsg(m) }
        list.layoutManager = LinearLayoutManager(this).apply { stackFromEnd = true }
        list.adapter = adapter
        if (store.isNotEmpty()) list.scrollToPosition(store.size - 1)

        btnSend.setOnClickListener {
            if (sending) {
                Voice.stop()
                Gemma.chatCancel()
            } else {
                val t = input.text.toString().trim()
                if (t.isNotEmpty()) {
                    input.setText("")
                    send(t)
                }
            }
        }

        input.setOnEditorActionListener { _, actionId, _ ->
            if (actionId == EditorInfo.IME_ACTION_SEND) {
                btnSend.performClick()
                true
            } else {
                false
            }
        }

        findViewById<Button>(R.id.btnExplain).setOnClickListener {
            if (sending) return@setOnClickListener
            if (Gemma.lastPage.isEmpty()) {
                Toast.makeText(this, "Terjemahkan satu halaman dulu.", Toast.LENGTH_SHORT).show()
            } else {
                send(
                    "Jelaskan halaman manga yang terakhir tadi: emosi dan nada tiap karakter, " +
                        "idiom/slang/makna tersembunyi yang tidak boleh diterjemahkan harfiah, " +
                        "dan kasih alternatif terjemahan yang lebih natural untuk baris yang menurutmu kurang pas."
                )
            }
        }

        findViewById<Button>(R.id.btnClear).setOnClickListener {
            if (sending) return@setOnClickListener
            store.clear()
            adapter.notifyDataSetChanged()
        }
    }

    private fun updateVoiceButton() {
        btnVoice.text = if (Voice.autoSpeak(this)) "Suara: nyala" else "Suara: mati"
    }

    /** Ketuk balon AI: bacakan (ketuk lagi saat sedang bicara untuk berhenti). */
    private fun speakMsg(m: Msg) {
        if (Voice.speaking) {
            Voice.stop()
            return
        }
        if (Voice.findVoice(this) == null) {
            Toast.makeText(this, "Model suara belum ada.", Toast.LENGTH_LONG).show()
            return
        }
        Toast.makeText(this, "Membaca...", Toast.LENGTH_SHORT).show()
        Voice.speak(this, m.text) { err ->
            if (err != null) runOnUiThread {
                Toast.makeText(this, "Suara gagal: $err", Toast.LENGTH_LONG).show()
            }
        }
    }

    // ------------------------------------------------------------ suara -> teks

    private fun onMic() {
        if (listening) {
            stopListening()
            return
        }
        if (sending) {
            Toast.makeText(this, "Tunggu jawaban selesai dulu.", Toast.LENGTH_SHORT).show()
            return
        }
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            micPerm.launch(Manifest.permission.RECORD_AUDIO)
            return
        }
        startListening()
    }

    private fun startListening() {
        Voice.stop()
        val r = try {
            if (Build.VERSION.SDK_INT >= 33 && SpeechRecognizer.isOnDeviceRecognitionAvailable(this)) {
                SpeechRecognizer.createOnDeviceSpeechRecognizer(this)
            } else if (SpeechRecognizer.isRecognitionAvailable(this)) {
                SpeechRecognizer.createSpeechRecognizer(this)
            } else {
                null
            }
        } catch (_: Throwable) {
            null
        }
        if (r == null) {
            Toast.makeText(this, "Pengenal suara tidak tersedia di HP ini.", Toast.LENGTH_LONG).show()
            return
        }
        recognizer = r
        r.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) {}
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onEvent(eventType: Int, params: Bundle?) {}

            override fun onPartialResults(partialResults: Bundle?) {
                val t = partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
                if (!t.isNullOrBlank()) input.setText(t)
            }

            override fun onResults(results: Bundle?) {
                val t = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
                stopListening()
                if (!t.isNullOrBlank() && !sending) {
                    input.setText("")
                    send(t.trim())
                }
            }

            override fun onError(error: Int) {
                stopListening()
                val msg = when (error) {
                    6, 7 -> "Suaranya nggak kedengeran, coba lagi."
                    9 -> "Izin mikrofon belum ada."
                    12, 13 -> "Paket bahasa Indonesia untuk suara offline belum terpasang di HP."
                    2, 1, 4 -> "Pengenal suara butuh internet atau paket suara offline."
                    else -> "Gagal mendengar (kode $error)."
                }
                Toast.makeText(this@ChatActivity, msg, Toast.LENGTH_LONG).show()
            }
        })
        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE, "id-ID")
            .putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            .putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, true)
            .putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
        listening = true
        btnMic.text = "Dengar..."
        input.setText("")
        try {
            r.startListening(i)
        } catch (t: Throwable) {
            stopListening()
            Toast.makeText(this, "Gagal mulai mendengar: ${t.message}", Toast.LENGTH_LONG).show()
        }
    }

    private fun stopListening() {
        listening = false
        btnMic.text = "Mic"
        try {
            recognizer?.cancel()
            recognizer?.destroy()
        } catch (_: Throwable) {
        }
        recognizer = null
    }

    private fun send(text: String) {
        Voice.stop()
        val model = Gemma.findModel(this)
        if (model == null) {
            Toast.makeText(this, "Model .litertlm belum ada.", Toast.LENGTH_LONG).show()
            return
        }
        val prefs = getSharedPreferences("mangatl", MODE_PRIVATE)
        val glossary = prefs.getString("glossary", "") ?: ""
        val nick = prefs.getString("nick", "") ?: ""
        val notes = prefs.getString("notes", "") ?: ""

        val hist = store.filter { it.text.isNotBlank() }.map { Pair(it.isUser, it.text) }
        store.add(Msg(true, text))
        val ai = Msg(false, "")
        store.add(ai)
        adapter.notifyItemRangeInserted(store.size - 2, 2)
        list.scrollToPosition(store.size - 1)

        sending = true
        btnSend.text = "Berhenti"

        // Suara ikut streaming: model suara dimuat sekarang (selagi AI mikir), lalu tiap kalimat
        // dibacakan begitu teksnya muncul.
        val stream: Voice.Stream? =
            if (Voice.autoSpeak(this) && Voice.findVoice(this) != null) {
                Voice.startStream(this) { e ->
                    if (e != null) runOnUiThread {
                        Toast.makeText(this, "Suara gagal: $e", Toast.LENGTH_LONG).show()
                    }
                }
            } else {
                null
            }

        Gemma.chat(
            this, model, hist, text, glossary, nick, notes,
            onChunk = { chunk ->
                runOnUiThread {
                    ai.text += chunk
                    stream?.feed(chunk)
                    val pos = store.indexOf(ai)
                    if (pos >= 0) {
                        adapter.notifyItemChanged(pos)
                        list.scrollToPosition(store.size - 1)
                    }
                }
            },
            onFinish = { err ->
                runOnUiThread {
                    sending = false
                    btnSend.text = "Kirim"
                    if (err != null) {
                        ai.text = if (ai.text.isBlank()) "Gagal: $err" else ai.text + "\n\n(Gagal: $err)"
                    } else if (ai.text.isBlank()) {
                        ai.text = "(tidak ada jawaban)"
                    }
                    val pos = store.indexOf(ai)
                    if (pos >= 0) adapter.notifyItemChanged(pos)
                    if (err == null) stream?.finish() else stream?.cancel()
                }
            }
        )
    }

    override fun onDestroy() {
        stopListening()
        Voice.release()
        if (sending) Gemma.chatCancel()
        super.onDestroy()
    }

    class MsgAdapter(
        private val items: List<Msg>,
        private val onTap: (Msg) -> Unit
    ) : RecyclerView.Adapter<MsgAdapter.VH>() {

        class VH(v: View) : RecyclerView.ViewHolder(v) {
            val bubble: TextView = v.findViewById(R.id.bubble)
        }

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
            val v = LayoutInflater.from(parent.context).inflate(R.layout.item_msg, parent, false)
            return VH(v)
        }

        override fun getItemCount(): Int = items.size

        override fun onBindViewHolder(holder: VH, position: Int) {
            val m = items[position]
            val b = holder.bubble
            val lp = b.layoutParams as FrameLayout.LayoutParams
            if (m.isUser) {
                lp.gravity = Gravity.END
                b.setBackgroundResource(R.drawable.bubble_user)
                b.setTextColor(0xFFFFFFFF.toInt())
                b.text = m.text
            } else {
                lp.gravity = Gravity.START
                b.setBackgroundResource(R.drawable.bubble_ai)
                b.setTextColor(0xFFE6E0E9.toInt())
                b.text = if (m.text.isEmpty()) "..." else TextUtil.md(m.text)
            }
            b.layoutParams = lp
            b.setOnClickListener { if (!m.isUser && m.text.isNotBlank()) onTap(m) }
            b.setOnLongClickListener {
                val cm = b.context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                cm.setPrimaryClip(ClipData.newPlainText("chat", m.text))
                Toast.makeText(b.context, "Disalin", Toast.LENGTH_SHORT).show()
                true
            }
        }
    }
}
