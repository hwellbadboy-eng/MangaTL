package com.niven.mangatl

import android.Manifest
import android.content.ComponentName
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.Editable
import android.text.TextWatcher
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.Player
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.tabs.TabLayout
import com.google.common.util.concurrent.ListenableFuture
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/** Layar pustaka: tab Musik / Video, pencarian, dan mini player. */
class LibraryActivity : AppCompatActivity() {

    private class Row(val title: String, val sub: String, val click: () -> Unit)

    private lateinit var list: RecyclerView
    private lateinit var etSearch: EditText
    private lateinit var tabs: TabLayout
    private lateinit var tvEmpty: TextView
    private lateinit var mini: View
    private lateinit var tvNow: TextView
    private lateinit var tvArtist: TextView
    private lateinit var tvTime: TextView
    private lateinit var sbSeek: SeekBar
    private lateinit var btnPlay: Button
    private lateinit var btnShuffle: Button
    private lateinit var btnRepeat: Button

    private var tracks: List<Library.Track> = emptyList()
    private var videos: List<Library.Video> = emptyList()
    private var rows: List<Row> = emptyList()
    private var loaded = false

    private var future: ListenableFuture<MediaController>? = null
    private var controller: MediaController? = null
    private val handler = Handler(Looper.getMainLooper())
    private var dragging = false

    private val tick = object : Runnable {
        override fun run() {
            updateProgress()
            handler.postDelayed(this, 500)
        }
    }

    private val perm = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) {
        // Notifikasi boleh ditolak; yang penting izin baca media.
        if (hasMediaPermission()) loadLibrary() else {
            tvEmpty.text = "Izin baca musik/video ditolak. Beri izin di Pengaturan HP, atau pakai tombol \"Buka file\"."
            tvEmpty.visibility = View.VISIBLE
        }
    }

    private val openFile = registerForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri -> uri?.let { openSingle(it) } }

    private val adapter = object : RecyclerView.Adapter<RecyclerView.ViewHolder>() {
        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
            val v = LayoutInflater.from(parent.context)
                .inflate(android.R.layout.simple_list_item_2, parent, false)
            v.setPadding(8, 14, 8, 14)
            return object : RecyclerView.ViewHolder(v) {}
        }

        override fun getItemCount() = rows.size

        override fun onBindViewHolder(h: RecyclerView.ViewHolder, pos: Int) {
            val r = rows[pos]
            h.itemView.findViewById<TextView>(android.R.id.text1).apply {
                text = r.title
                maxLines = 1
                ellipsize = android.text.TextUtils.TruncateAt.END
            }
            h.itemView.findViewById<TextView>(android.R.id.text2).apply {
                text = r.sub
                maxLines = 1
            }
            h.itemView.setOnClickListener { r.click() }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_library)

        list = findViewById(R.id.list)
        etSearch = findViewById(R.id.etSearch)
        tabs = findViewById(R.id.tabs)
        tvEmpty = findViewById(R.id.tvEmpty)
        mini = findViewById(R.id.mini)
        tvNow = findViewById(R.id.tvNow)
        tvArtist = findViewById(R.id.tvArtist)
        tvTime = findViewById(R.id.tvTime)
        sbSeek = findViewById(R.id.sbSeek)
        btnPlay = findViewById(R.id.btnPlay)
        btnShuffle = findViewById(R.id.btnShuffle)
        btnRepeat = findViewById(R.id.btnRepeat)

        list.layoutManager = LinearLayoutManager(this)
        list.adapter = adapter

        tabs.addTab(tabs.newTab().setText("Musik"))
        tabs.addTab(tabs.newTab().setText("Video"))
        tabs.addOnTabSelectedListener(object : TabLayout.OnTabSelectedListener {
            override fun onTabSelected(tab: TabLayout.Tab?) = refresh()
            override fun onTabUnselected(tab: TabLayout.Tab?) {}
            override fun onTabReselected(tab: TabLayout.Tab?) {}
        })

        etSearch.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun afterTextChanged(s: Editable?) = refresh()
        })

        findViewById<Button>(R.id.btnOpenFile).setOnClickListener {
            openFile.launch(arrayOf("audio/*", "video/*"))
        }

        btnPlay.setOnClickListener {
            controller?.let { if (it.isPlaying) it.pause() else it.play() }
        }
        findViewById<Button>(R.id.btnPrev).setOnClickListener { controller?.seekToPreviousMediaItem() }
        findViewById<Button>(R.id.btnNext).setOnClickListener { controller?.seekToNextMediaItem() }
        btnShuffle.setOnClickListener {
            controller?.let { it.shuffleModeEnabled = !it.shuffleModeEnabled }
        }
        btnRepeat.setOnClickListener {
            controller?.let {
                it.repeatMode = when (it.repeatMode) {
                    Player.REPEAT_MODE_OFF -> Player.REPEAT_MODE_ALL
                    Player.REPEAT_MODE_ALL -> Player.REPEAT_MODE_ONE
                    else -> Player.REPEAT_MODE_OFF
                }
            }
        }

        sbSeek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar?, p: Int, fromUser: Boolean) {
                if (fromUser) tvTime.text = "${Library.fmt(p.toLong())} / ${Library.fmt(sbSeek.max.toLong())}"
            }

            override fun onStartTrackingTouch(sb: SeekBar?) {
                dragging = true
            }

            override fun onStopTrackingTouch(sb: SeekBar?) {
                dragging = false
                controller?.seekTo((sb?.progress ?: 0).toLong())
            }
        })

        ensurePermissionThenLoad()
    }

    override fun onStart() {
        super.onStart()
        val token = SessionToken(this, ComponentName(this, PlayerService::class.java))
        val f = MediaController.Builder(this, token).buildAsync()
        future = f
        f.addListener({
            try {
                val c = f.get()
                controller = c
                c.addListener(object : Player.Listener {
                    override fun onEvents(player: Player, events: Player.Events) = updateUi()
                })
                updateUi()
                handler.post(tick)
            } catch (e: Exception) {
                Toast.makeText(this, "Pemutar gagal tersambung: ${e.message}", Toast.LENGTH_LONG).show()
            }
        }, ContextCompat.getMainExecutor(this))
    }

    override fun onStop() {
        handler.removeCallbacks(tick)
        future?.let { MediaController.releaseFuture(it) }
        future = null
        controller = null
        super.onStop()
    }

    // ---------- izin & muat data ----------

    private fun mediaPermissions(): Array<String> =
        if (Build.VERSION.SDK_INT >= 33) {
            arrayOf(
                Manifest.permission.READ_MEDIA_AUDIO,
                Manifest.permission.READ_MEDIA_VIDEO,
                Manifest.permission.POST_NOTIFICATIONS
            )
        } else {
            arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE)
        }

    private fun hasMediaPermission(): Boolean {
        val need = if (Build.VERSION.SDK_INT >= 33) {
            listOf(Manifest.permission.READ_MEDIA_AUDIO, Manifest.permission.READ_MEDIA_VIDEO)
        } else {
            listOf(Manifest.permission.READ_EXTERNAL_STORAGE)
        }
        return need.all { checkSelfPermission(it) == PackageManager.PERMISSION_GRANTED }
    }

    private fun ensurePermissionThenLoad() {
        if (hasMediaPermission()) loadLibrary() else perm.launch(mediaPermissions())
    }

    private fun loadLibrary() {
        tvEmpty.text = "Memuat..."
        tvEmpty.visibility = View.VISIBLE
        lifecycleScope.launch {
            val (a, v) = withContext(Dispatchers.IO) {
                Pair(Library.audios(this@LibraryActivity), Library.videos(this@LibraryActivity))
            }
            tracks = a
            videos = v
            loaded = true
            refresh()
        }
    }

    // ---------- daftar ----------

    private fun refresh() {
        if (!loaded) return
        val q = etSearch.text.toString().trim().lowercase()
        if (tabs.selectedTabPosition == 0) {
            val shown = tracks.filter {
                q.isEmpty() || it.title.lowercase().contains(q) || it.artist.lowercase().contains(q)
            }
            rows = shown.mapIndexed { i, t ->
                Row(t.title, "${t.artist}  •  ${Library.fmt(t.durationMs)}") { playQueue(shown, i) }
            }
            tvEmpty.text = "Tidak ada lagu ditemukan."
        } else {
            val shown = videos.filter { q.isEmpty() || it.title.lowercase().contains(q) }
            rows = shown.map { v ->
                val mb = v.size / 1024.0 / 1024.0
                Row(v.title, String.format("%s  •  %.1f MB", Library.fmt(v.durationMs), mb)) {
                    openVideo(v.uri)
                }
            }
            tvEmpty.text = "Tidak ada video ditemukan."
        }
        tvEmpty.visibility = if (rows.isEmpty()) View.VISIBLE else View.GONE
        adapter.notifyDataSetChanged()
    }

    // ---------- putar ----------

    private fun trackItem(t: Library.Track): MediaItem {
        val art = Uri.parse("content://media/external/audio/albumart/${t.albumId}")
        return MediaItem.Builder()
            .setMediaId(t.id.toString())
            .setUri(t.uri)
            .setMediaMetadata(
                MediaMetadata.Builder()
                    .setTitle(t.title)
                    .setArtist(t.artist)
                    .setAlbumTitle(t.album)
                    .setArtworkUri(art)
                    .build()
            )
            .build()
    }

    private fun playQueue(queue: List<Library.Track>, index: Int) {
        val c = controller ?: run {
            Toast.makeText(this, "Pemutar belum siap, coba lagi.", Toast.LENGTH_SHORT).show()
            return
        }
        c.setMediaItems(queue.map { trackItem(it) }, index, 0L)
        c.prepare()
        c.play()
    }

    private fun openVideo(uri: Uri) {
        controller?.pause()
        startActivity(
            Intent(this, VideoActivity::class.java)
                .setData(uri)
                .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        )
    }

    private fun openSingle(uri: Uri) {
        val type = contentResolver.getType(uri) ?: ""
        if (type.startsWith("video")) {
            openVideo(uri)
            return
        }
        val c = controller ?: return
        val name = uri.lastPathSegment?.substringAfterLast('/') ?: "File"
        c.setMediaItem(
            MediaItem.Builder().setUri(uri)
                .setMediaMetadata(MediaMetadata.Builder().setTitle(name).build())
                .build()
        )
        c.prepare()
        c.play()
    }

    // ---------- UI mini player ----------

    private fun updateUi() {
        val c = controller ?: return
        mini.visibility = if (c.mediaItemCount > 0) View.VISIBLE else View.GONE
        tvNow.text = c.mediaMetadata.title ?: "—"
        tvArtist.text = c.mediaMetadata.artist ?: ""
        btnPlay.text = if (c.isPlaying) "⏸" else "▶"
        btnShuffle.text = if (c.shuffleModeEnabled) "Acak: nyala" else "Acak: mati"
        btnRepeat.text = when (c.repeatMode) {
            Player.REPEAT_MODE_ALL -> "Ulang: semua"
            Player.REPEAT_MODE_ONE -> "Ulang: satu"
            else -> "Ulang: mati"
        }
        updateProgress()
    }

    private fun updateProgress() {
        val c = controller ?: return
        if (dragging) return
        val dur = c.duration.takeIf { it > 0 } ?: 0L
        sbSeek.max = dur.toInt()
        sbSeek.progress = c.currentPosition.coerceIn(0, dur).toInt()
        tvTime.text = "${Library.fmt(c.currentPosition)} / ${Library.fmt(dur)}"
    }
}
