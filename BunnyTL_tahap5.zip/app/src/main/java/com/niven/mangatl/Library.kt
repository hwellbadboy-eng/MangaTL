package com.niven.mangatl

import android.content.ContentUris
import android.content.Context
import android.net.Uri
import android.provider.MediaStore

/** Baca lagu & video dari MediaStore, plus pengelompokan (album, artis, folder). */
object Library {

    class Track(
        val id: Long,
        val uri: Uri,
        val title: String,
        val artist: String,
        val album: String,
        val durationMs: Long,
        val albumId: Long,
        val folder: String
    )

    class Video(
        val id: Long,
        val uri: Uri,
        val title: String,
        val durationMs: Long,
        val size: Long,
        val bucketId: Long,
        val bucket: String,
        val dateAdded: Long
    )

    class Group(val title: String, val sub: String, val tracks: List<Track>)
    class VFolder(val bucketId: Long, val name: String, val videos: List<Video>)

    @Suppress("DEPRECATION")
    fun audios(ctx: Context): List<Track> {
        val out = ArrayList<Track>()
        val proj = arrayOf(
            MediaStore.Audio.Media._ID,
            MediaStore.Audio.Media.TITLE,
            MediaStore.Audio.Media.ARTIST,
            MediaStore.Audio.Media.ALBUM,
            MediaStore.Audio.Media.DURATION,
            MediaStore.Audio.Media.ALBUM_ID,
            MediaStore.Audio.Media.DATA
        )
        val sel = "${MediaStore.Audio.Media.IS_MUSIC} != 0 AND ${MediaStore.Audio.Media.DURATION} >= 10000"
        ctx.contentResolver.query(
            MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, proj, sel, null,
            "${MediaStore.Audio.Media.TITLE} COLLATE NOCASE ASC"
        )?.use { c ->
            while (c.moveToNext()) {
                val id = c.getLong(0)
                val artist = c.getString(2)?.takeIf { it != "<unknown>" } ?: "Tidak diketahui"
                val path = c.getString(6) ?: ""
                out.add(
                    Track(
                        id,
                        ContentUris.withAppendedId(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, id),
                        c.getString(1) ?: "Tanpa judul",
                        artist,
                        c.getString(3) ?: "",
                        c.getLong(4),
                        c.getLong(5),
                        path.substringBeforeLast('/', "")
                    )
                )
            }
        }
        return out
    }

    fun albums(t: List<Track>): List<Group> =
        t.groupBy { it.albumId }.values.map { l ->
            Group(l[0].album.ifBlank { "Tanpa album" }, "${l[0].artist}  •  ${l.size} lagu", l)
        }.sortedBy { it.title.lowercase() }

    fun artists(t: List<Track>): List<Group> =
        t.groupBy { it.artist }.values.map { l ->
            Group(l[0].artist, "${l.size} lagu", l)
        }.sortedBy { it.title.lowercase() }

    fun folders(t: List<Track>): List<Group> =
        t.groupBy { it.folder }.map { (path, l) ->
            Group(path.substringAfterLast('/').ifBlank { "/" }, "$path  •  ${l.size} lagu", l)
        }.sortedBy { it.title.lowercase() }

    fun videos(ctx: Context, bucket: Long? = null): List<Video> {
        val out = ArrayList<Video>()
        val proj = arrayOf(
            MediaStore.Video.Media._ID,
            MediaStore.Video.Media.DISPLAY_NAME,
            MediaStore.Video.Media.DURATION,
            MediaStore.Video.Media.SIZE,
            MediaStore.Video.Media.BUCKET_ID,
            MediaStore.Video.Media.BUCKET_DISPLAY_NAME,
            MediaStore.Video.Media.DATE_ADDED
        )
        val sel = if (bucket != null) "${MediaStore.Video.Media.BUCKET_ID} = ?" else null
        val args = if (bucket != null) arrayOf(bucket.toString()) else null
        ctx.contentResolver.query(
            MediaStore.Video.Media.EXTERNAL_CONTENT_URI, proj, sel, args,
            "${MediaStore.Video.Media.DATE_ADDED} DESC"
        )?.use { c ->
            while (c.moveToNext()) {
                val id = c.getLong(0)
                out.add(
                    Video(
                        id,
                        ContentUris.withAppendedId(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, id),
                        c.getString(1) ?: "Video",
                        c.getLong(2),
                        c.getLong(3),
                        c.getLong(4),
                        c.getString(5) ?: "Tanpa folder",
                        c.getLong(6)
                    )
                )
            }
        }
        return out
    }

    fun videoFolders(ctx: Context): List<VFolder> =
        videos(ctx).groupBy { it.bucketId }.values.map { l ->
            VFolder(l[0].bucketId, l[0].bucket, l)
        }.sortedBy { it.name.lowercase() }

    fun fmt(ms: Long): String {
        if (ms <= 0) return "0:00"
        val s = ms / 1000
        val h = s / 3600
        val m = (s % 3600) / 60
        val sec = s % 60
        return if (h > 0) String.format("%d:%02d:%02d", h, m, sec) else String.format("%d:%02d", m, sec)
    }

    fun sizeStr(bytes: Long): String {
        val mb = bytes / 1024.0 / 1024.0
        return if (mb >= 1024) String.format("%.1f GB", mb / 1024) else String.format("%.1f MB", mb)
    }
}
