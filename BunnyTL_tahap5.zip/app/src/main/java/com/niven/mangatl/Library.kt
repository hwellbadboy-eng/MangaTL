package com.niven.mangatl

import android.content.ContentUris
import android.content.Context
import android.net.Uri
import android.provider.MediaStore

/** Baca lagu & video dari MediaStore, plus pengelompokan (album, artis, folder). */
object Library {

    class Track(
        val id: Long,
        val uri: Uri,
        val title: String,
        val artist: String,
        val album: String,
        val durationMs: Long,
        val albumId: Long,
        val folder: String,
        val dateAdded: Long,
        val fileBase: String
    )

    class Video(
        val id: Long,
        val uri: Uri,
        val title: String,
        val durationMs: Long,
        val size: Long,
        val bucketId: Long,
        val bucket: String,
        val dateAdded: Long
    )

    class Group(val title: String, val sub: String, val tracks: List<Track>, val date: Long, val big: Long)

    class VFolder(val bucketId: Long, val name: String, val videos: List<Video>) {
        val date: Long get() = videos.maxOfOrNull { it.dateAdded } ?: 0L
        val size: Long get() = videos.sumOf { it.size }
    }

    private val AUDIO_PROJ = arrayOf(
        MediaStore.Audio.Media._ID,
        MediaStore.Audio.Media.TITLE,
        MediaStore.Audio.Media.ARTIST,
        MediaStore.Audio.Media.ALBUM,
        MediaStore.Audio.Media.DURATION,
        MediaStore.Audio.Media.ALBUM_ID,
        MediaStore.Audio.Media.DATA,
        MediaStore.Audio.Media.DATE_ADDED,
        MediaStore.Audio.Media.DISPLAY_NAME
    )

    @Suppress("DEPRECATION")
    private fun queryTracks(ctx: Context, sel: String?, args: Array<String>?, order: String?): List<Track> {
        val out = ArrayList<Track>()
        ctx.contentResolver.query(
            MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, AUDIO_PROJ, sel, args, order
        )?.use { c ->
            while (c.moveToNext()) {
                val id = c.getLong(0)
                val artist = c.getString(2)?.takeIf { it != "<unknown>" } ?: "Tidak diketahui"
                val path = c.getString(6) ?: ""
                val file = c.getString(8) ?: ""
                out.add(
                    Track(
                        id,
                        ContentUris.withAppendedId(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, id),
                        c.getString(1) ?: "Tanpa judul",
                        artist,
                        c.getString(3) ?: "",
                        c.getLong(4),
                        c.getLong(5),
                        path.substringBeforeLast('/', ""),
                        c.getLong(7),
                        file.substringBeforeLast('.', file)
                    )
                )
            }
        }
        return out
    }

    fun audios(ctx: Context): List<Track> = queryTracks(
        ctx,
        "${MediaStore.Audio.Media.IS_MUSIC} != 0 AND ${MediaStore.Audio.Media.DURATION} >= 10000",
        null,
        "${MediaStore.Audio.Media.TITLE} COLLATE NOCASE ASC"
    )

    fun track(ctx: Context, id: Long): Track? =
        queryTracks(ctx, "${MediaStore.Audio.Media._ID} = ?", arrayOf(id.toString()), null).firstOrNull()

    private fun group(title: String, sub: String, l: List<Track>) =
        Group(title, sub, l, l.maxOf { it.dateAdded }, l.sumOf { it.durationMs })

    fun albums(t: List<Track>): List<Group> =
        t.groupBy { it.albumId }.values.map { l ->
            group(l[0].album.ifBlank { "Tanpa album" }, "${l[0].artist}  •  ${l.size} lagu", l)
        }

    fun artists(t: List<Track>): List<Group> =
        t.groupBy { it.artist }.values.map { l -> group(l[0].artist, "${l.size} lagu", l) }

    fun folders(t: List<Track>): List<Group> =
        t.groupBy { it.folder }.map { (path, l) ->
            group(path.substringAfterLast('/').ifBlank { "/" }, "$path  •  ${l.size} lagu", l)
        }

    fun videos(ctx: Context, bucket: Long? = null): List<Video> {
        val out = ArrayList<Video>()
        val proj = arrayOf(
            MediaStore.Video.Media._ID,
            MediaStore.Video.Media.DISPLAY_NAME,
            MediaStore.Video.Media.DURATION,
            MediaStore.Video.Media.SIZE,
            MediaStore.Video.Media.BUCKET_ID,
            MediaStore.Video.Media.BUCKET_DISPLAY_NAME,
            MediaStore.Video.Media.DATE_ADDED
        )
        val sel = if (bucket != null) "${MediaStore.Video.Media.BUCKET_ID} = ?" else null
        val args = if (bucket != null) arrayOf(bucket.toString()) else null
        ctx.contentResolver.query(
            MediaStore.Video.Media.EXTERNAL_CONTENT_URI, proj, sel, args,
            "${MediaStore.Video.Media.DATE_ADDED} DESC"
        )?.use { c ->
            while (c.moveToNext()) {
                val id = c.getLong(0)
                out.add(
                    Video(
                        id,
                        ContentUris.withAppendedId(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, id),
                        c.getString(1) ?: "Video",
                        c.getLong(2),
                        c.getLong(3),
                        c.getLong(4),
                        c.getString(5) ?: "Tanpa folder",
                        c.getLong(6)
                    )
                )
            }
        }
        return out
    }

    fun videoFolders(ctx: Context): List<VFolder> =
        videos(ctx).groupBy { it.bucketId }.values.map { l -> VFolder(l[0].bucketId, l[0].bucket, l) }

    fun fmt(ms: Long): String {
        if (ms <= 0) return "0:00"
        val s = ms / 1000
        val h = s / 3600
        val m = (s % 3600) / 60
        val sec = s % 60
        return if (h > 0) String.format("%d:%02d:%02d", h, m, sec) else String.format("%d:%02d", m, sec)
    }

    fun sizeStr(bytes: Long): String {
        val mb = bytes / 1024.0 / 1024.0
        return if (mb >= 1024) String.format("%.1f GB", mb / 1024) else String.format("%.1f MB", mb)
    }
}
