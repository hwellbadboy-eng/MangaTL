package com.niven.mangatl

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/** Isi satu folder video: thumbnail, durasi, ukuran, dan bilah progres tontonan. */
class VideoListActivity : MediaActivity() {

    override val kind = 2
    override fun deniedView(): TextView = tvEmpty

    private lateinit var adapter: RowAdapter
    private lateinit var etSearch: EditText
    private lateinit var tvEmpty: TextView
    private lateinit var btnSort: Button
    private var videos: List<Library.Video> = emptyList()
    private var loaded = false
    private var byName = false
    private var bucket = 0L

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_list)
        bucket = intent.getLongExtra("bucket", 0L)
        findViewById<TextView>(R.id.tvTitle).text = intent.getStringExtra("name") ?: "Video"
        btnSort = findViewById(R.id.btnAction)
        btnSort.text = "Urut: terbaru"
        btnSort.setOnClickListener {
            byName = !byName
            btnSort.text = if (byName) "Urut: nama" else "Urut: terbaru"
            refresh()
        }
        etSearch = findViewById(R.id.etSearch)
        etSearch.hint = "Cari video"
        tvEmpty = findViewById(R.id.tvEmpty)
        adapter = RowAdapter(lifecycleScope)
        findViewById<RecyclerView>(R.id.list).apply {
            layoutManager = LinearLayoutManager(this@VideoListActivity)
            adapter = this@VideoListActivity.adapter
        }
        etSearch.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun afterTextChanged(s: Editable?) = refresh()
        })
        ensureMedia()
    }

    override fun onStart() {
        super.onStart()
        refresh() // perbarui bilah progres setelah balik dari pemutar
    }

    override fun onMediaReady() {
        tvEmpty.text = "Memuat..."
        tvEmpty.visibility = View.VISIBLE
        lifecycleScope.launch {
            videos = withContext(Dispatchers.IO) { Library.videos(this@VideoListActivity, bucket) }
            loaded = true
            refresh()
        }
    }

    private fun refresh() {
        if (!loaded) return
        val q = etSearch.text.toString().trim().lowercase()
        var shown = videos.filter { q.isEmpty() || it.title.lowercase().contains(q) }
        if (byName) shown = shown.sortedBy { it.title.lowercase() }
        val prefs = getSharedPreferences("player_pos", Context.MODE_PRIVATE)
        val uris = shown.map { it.uri.toString() }.toTypedArray()
        val rows = shown.mapIndexed { i, v ->
            val pos = prefs.getLong(v.uri.toString(), 0L)
            val pr = if (pos > 0 && v.durationMs > 0) (pos * 100 / v.durationMs).toInt().coerceIn(1, 99) else -1
            Row(
                title = v.title,
                sub = Library.sizeStr(v.size),
                thumb = v.uri,
                video = true,
                place = "🎬",
                badge = Library.fmt(v.durationMs),
                progress = pr,
                onClick = {
                    startActivity(
                        Intent(this, VideoActivity::class.java)
                            .putExtra("uris", uris)
                            .putExtra("index", i)
                            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                    )
                }
            )
        }
        adapter.rows = rows
        tvEmpty.text = "Tidak ada video."
        tvEmpty.visibility = if (rows.isEmpty()) View.VISIBLE else View.GONE
    }
}
