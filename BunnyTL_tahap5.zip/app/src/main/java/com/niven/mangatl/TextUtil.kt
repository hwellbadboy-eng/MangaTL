package com.niven.mangatl

import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.Rect
import android.text.Html
import android.text.Spanned

object TextUtil {

    /** Baris layak diterjemahkan kalau punya minimal 2 huruf. Angka/simbol saja dilewati. */
    fun isTranslatable(s: String): Boolean = s.count { it.isLetter() } >= 2

    /** Rapikan hasil OCR dan ubah HURUF KAPITAL (gaya manga) jadi kalimat biasa supaya model paham. */
    fun normalizeForModel(raw: String): String {
        var s = raw.replace("\n", " ")
            .replace('|', 'I')
            .replace(Regex("\\s+"), " ")
            .trim()
        s = fixCaps(s)
        return s
    }

    private fun fixCaps(s: String): String {
        val letters = s.filter { it.isLetter() }
        if (letters.length < 3) return s
        val upper = letters.count { it.isUpperCase() }
        if (upper.toDouble() / letters.length < 0.7) return s

        val sb = StringBuilder()
        var cap = true
        for (ch in s.lowercase()) {
            if (cap && ch.isLetter()) {
                sb.append(ch.uppercaseChar())
                cap = false
            } else {
                sb.append(ch)
            }
            if (ch == '.' || ch == '!' || ch == '?') cap = true
        }
        return sb.toString()
            .replace(Regex("\\bi\\b"), "I")
            .replace(Regex("\\bi'(m|ll|ve|d)\\b"), "I'\$1")
    }

    /** Urutkan blok teks OCR: atas ke bawah, lalu kiri ke kanan dalam baris yang sama. */
    fun readingOrder(items: List<Pair<Rect, String>>): List<String> =
        readingOrderPairs(items).map { it.second }

    fun readingOrderPairs(items: List<Pair<Rect, String>>): List<Pair<Rect, String>> {
        val sorted = items.sortedBy { it.first.top }
        val rows = ArrayList<MutableList<Pair<Rect, String>>>()
        for (item in sorted) {
            val row = rows.lastOrNull()
            if (row != null && item.first.centerY() <= row.minOf { it.first.bottom }) {
                row.add(item)
            } else {
                rows.add(mutableListOf(item))
            }
        }
        return rows.flatMap { row -> row.sortedBy { it.first.left } }
    }

    /** Markdown sederhana (**tebal**, *miring*, bullet) jadi teks berformat. */
    fun md(text: String): Spanned {
        var h = text
            .replace("&", "&amp;")
            .replace("<", "&lt;")
            .replace(">", "&gt;")
        h = h.replace(Regex("\\*\\*(.+?)\\*\\*"), "<b>\$1</b>")
        h = h.replace(Regex("(?<![*\\w])\\*(?!\\s)([^*\\n]+?)(?<!\\s)\\*(?![*\\w])"), "<i>\$1</i>")
        h = h.replace(Regex("(?m)^\\s*[*-]\\s+"), "• ")
        h = h.replace(Regex("(?m)^#{1,6}\\s*(.+)$"), "<b>\$1</b>")
        h = h.replace("\n", "<br>")
        return Html.fromHtml(h, Html.FROM_HTML_MODE_LEGACY)
    }

    /** Kecerahan warna 0..255. */
    fun luminance(c: Int): Double =
        0.299 * Color.red(c) + 0.587 * Color.green(c) + 0.114 * Color.blue(c)

    /** Warna latar di sekeliling kotak teks: ambil warna yang paling dominan di cincin tepi kotak. */
    fun sampleBg(bmp: Bitmap, r: Rect): Int {
        val d = 4
        val l = (r.left - d).coerceIn(0, bmp.width - 1)
        val right = (r.right + d).coerceIn(0, bmp.width - 1)
        val t = (r.top - d).coerceIn(0, bmp.height - 1)
        val b = (r.bottom + d).coerceIn(0, bmp.height - 1)
        val pts = ArrayList<Int>()
        val n = 14
        for (i in 0..n) {
            val x = l + (right - l) * i / n
            val y = t + (b - t) * i / n
            pts.add(bmp.getPixel(x, t))
            pts.add(bmp.getPixel(x, b))
            pts.add(bmp.getPixel(l, y))
            pts.add(bmp.getPixel(right, y))
        }
        val buckets = HashMap<Int, MutableList<Int>>()
        for (p in pts) {
            val key = ((Color.red(p) shr 4) shl 8) or ((Color.green(p) shr 4) shl 4) or (Color.blue(p) shr 4)
            buckets.getOrPut(key) { ArrayList() }.add(p)
        }
        val best = buckets.values.maxByOrNull { it.size } ?: pts
        var rr = 0
        var gg = 0
        var bb = 0
        for (p in best) {
            rr += Color.red(p)
            gg += Color.green(p)
            bb += Color.blue(p)
        }
        val c = best.size.coerceAtLeast(1)
        return Color.rgb(rr / c, gg / c, bb / c)
    }
}
