package com.niven.mangatl

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.view.View
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity

/** Dasar layar pustaka: urus izin baca media. kind: 1 = musik, 2 = video. */
abstract class MediaActivity : AppCompatActivity() {

    protected abstract val kind: Int
    protected abstract fun onMediaReady()
    protected abstract fun deniedView(): TextView

    private val permLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) {
        if (hasMedia()) onMediaReady() else {
            deniedView().apply {
                text = "Izin baca media ditolak. Beri izin di Pengaturan HP > Aplikasi > BunnyTL > Izin."
                visibility = View.VISIBLE
            }
        }
    }

    private fun need(): List<String> =
        if (Build.VERSION.SDK_INT >= 33) {
            if (kind == 1) listOf(Manifest.permission.READ_MEDIA_AUDIO)
            else listOf(Manifest.permission.READ_MEDIA_VIDEO)
        } else listOf(Manifest.permission.READ_EXTERNAL_STORAGE)

    private fun hasMedia() = need().all {
        checkSelfPermission(it) == PackageManager.PERMISSION_GRANTED
    }

    protected fun ensureMedia() {
        if (hasMedia()) {
            onMediaReady()
        } else {
            val p = ArrayList(need())
            if (kind == 1 && Build.VERSION.SDK_INT >= 33) p.add(Manifest.permission.POST_NOTIFICATIONS)
            permLauncher.launch(p.toTypedArray())
        }
    }
}
