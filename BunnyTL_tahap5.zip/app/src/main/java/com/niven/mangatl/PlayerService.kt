package com.niven.mangatl

import android.content.Intent
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.session.MediaSession
import androidx.media3.session.MediaSessionService

/**
 * Pemutar musik di latar belakang (notifikasi + kontrol layar kunci) + sleep timer.
 */
class PlayerService : MediaSessionService() {

    companion object {
        @Volatile
        var instance: PlayerService? = null
    }

    private var session: MediaSession? = null
    private val h = Handler(Looper.getMainLooper())
    private var sleepRun: Runnable? = null

    /** Waktu (elapsedRealtime) timer habis; 0 = timer mati. */
    @Volatile
    var sleepEndAt = 0L
        private set

    fun setSleepTimer(minutes: Int) {
        sleepRun?.let { h.removeCallbacks(it) }
        sleepRun = null
        sleepEndAt = 0L
        if (minutes > 0) {
            val r = Runnable {
                session?.player?.pause()
                sleepEndAt = 0L
            }
            sleepRun = r
            sleepEndAt = SystemClock.elapsedRealtime() + minutes * 60_000L
            h.postDelayed(r, minutes * 60_000L)
        }
    }

    override fun onCreate() {
        super.onCreate()
        instance = this
        val player = ExoPlayer.Builder(this, Decoders.factory(this, Prefs.decoder(this)))
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(C.USAGE_MEDIA)
                    .setContentType(C.AUDIO_CONTENT_TYPE_MUSIC)
                    .build(),
                true
            )
            .setHandleAudioBecomingNoisy(true)
            .build()
        session = MediaSession.Builder(this, player).build()
    }

    override fun onGetSession(controllerInfo: MediaSession.ControllerInfo): MediaSession? = session

    override fun onTaskRemoved(rootIntent: Intent?) {
        val p = session?.player
        if (p == null || !p.playWhenReady || p.mediaItemCount == 0) stopSelf()
    }

    override fun onDestroy() {
        sleepRun?.let { h.removeCallbacks(it) }
        instance = null
        session?.run {
            player.release()
            release()
        }
        session = null
        super.onDestroy()
    }
}
