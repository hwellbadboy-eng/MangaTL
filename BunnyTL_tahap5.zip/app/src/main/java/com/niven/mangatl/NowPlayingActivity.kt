package com.niven.mangatl

import android.content.ComponentName
import android.content.ContentUris
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.provider.MediaStore
import android.widget.Button
import android.widget.ImageView
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import androidx.media3.common.Player
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import com.google.common.util.concurrent.ListenableFuture

/** Layar "Sedang diputar": cover besar, seek, acak/ulang, favorit, sleep timer, antrean, kecepatan. */
class NowPlayingActivity : AppCompatActivity() {

    private lateinit var ivArt: ImageView
    private lateinit var tvTitle: TextView
    private lateinit var tvArtist: TextView
    private lateinit var tvTime: TextView
    private lateinit var sbSeek: SeekBar
    private lateinit var btnPlay: Button
    private lateinit var btnShuffle: Button
    private lateinit var btnRepeat: Button
    private lateinit var btnFav: Button
    private lateinit var btnSleep: Button
    private lateinit var btnSpeed: Button

    private var future: ListenableFuture<MediaController>? = null
    private var controller: MediaController? = null
    private val handler = Handler(Looper.getMainLooper())
    private var dragging = false
    private var lastId: Long? = null
    private val speeds = floatArrayOf(0.75f, 1f, 1.25f, 1.5f, 2f)

    private val tick = object : Runnable {
        override fun run() {
            updateProgress()
            handler.postDelayed(this, 500)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_nowplaying)
        ivArt = findViewById(R.id.ivArt)
        tvTitle = findViewById(R.id.tvTitle)
        tvArtist = findViewById(R.id.tvArtist)
        tvTime = findViewById(R.id.tvTime)
        sbSeek = findViewById(R.id.sbSeek)
        btnPlay = findViewById(R.id.btnPlay)
        btnShuffle = findViewById(R.id.btnShuffle)
        btnRepeat = findViewById(R.id.btnRepeat)
        btnFav = findViewById(R.id.btnFav)
        btnSleep = findViewById(R.id.btnSleep)
        btnSpeed = findViewById(R.id.btnSpeed)

        btnPlay.setOnClickListener { controller?.let { if (it.isPlaying) it.pause() else it.play() } }
        findViewById<Button>(R.id.btnPrev).setOnClickListener { controller?.seekToPreviousMediaItem() }
        findViewById<Button>(R.id.btnNext).setOnClickListener { controller?.seekToNextMediaItem() }
        btnShuffle.setOnClickListener { controller?.let { it.shuffleModeEnabled = !it.shuffleModeEnabled } }
        btnRepeat.setOnClickListener {
            controller?.let {
                it.repeatMode = when (it.repeatMode) {
                    Player.REPEAT_MODE_OFF -> Player.REPEAT_MODE_ALL
                    Player.REPEAT_MODE_ALL -> Player.REPEAT_MODE_ONE
                    else -> Player.REPEAT_MODE_OFF
                }
            }
        }
        btnFav.setOnClickListener {
            val id = controller?.currentMediaItem?.mediaId?.toLongOrNull() ?: return@setOnClickListener
            MusicStore.toggleFav(this, id)
            updateUi()
        }
        btnSleep.setOnClickListener { sleepDialog() }
        findViewById<Button>(R.id.btnQueue).setOnClickListener { queueDialog() }
        btnSpeed.setOnClickListener {
            val c = controller ?: return@setOnClickListener
            val i = speeds.indexOfFirst { it == c.playbackParameters.speed }
            c.setPlaybackSpeed(speeds[(i + 1) % speeds.size])
            updateUi()
        }

        sbSeek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar?, p: Int, fromUser: Boolean) {
                if (fromUser) tvTime.text = "${Library.fmt(p.toLong())} / ${Library.fmt(sbSeek.max.toLong())}"
            }

            override fun onStartTrackingTouch(sb: SeekBar?) {
                dragging = true
            }

            override fun onStopTrackingTouch(sb: SeekBar?) {
                dragging = false
                controller?.seekTo((sb?.progress ?: 0).toLong())
            }
        })
    }

    override fun onStart() {
        super.onStart()
        val token = SessionToken(this, ComponentName(this, PlayerService::class.java))
        val f = MediaController.Builder(this, token).buildAsync()
        future = f
        f.addListener({
            try {
                val c = f.get()
                controller = c
                c.addListener(object : Player.Listener {
                    override fun onEvents(player: Player, events: Player.Events) = updateUi()
                })
                updateUi()
                handler.post(tick)
            } catch (e: Exception) {
                Toast.makeText(this, "Pemutar gagal tersambung", Toast.LENGTH_LONG).show()
            }
        }, ContextCompat.getMainExecutor(this))
    }

    override fun onStop() {
        handler.removeCallbacks(tick)
        future?.let { MediaController.releaseFuture(it) }
        future = null
        controller = null
        super.onStop()
    }

    private fun updateUi() {
        val c = controller ?: return
        tvTitle.text = c.mediaMetadata.title ?: "—"
        tvArtist.text = c.mediaMetadata.artist ?: ""
        btnPlay.text = if (c.isPlaying) "⏸" else "▶"
        btnShuffle.alpha = if (c.shuffleModeEnabled) 1f else 0.4f
        btnRepeat.text = if (c.repeatMode == Player.REPEAT_MODE_ONE) "🔂" else "🔁"
        btnRepeat.alpha = if (c.repeatMode == Player.REPEAT_MODE_OFF) 0.4f else 1f
        val id = c.currentMediaItem?.mediaId?.toLongOrNull()
        btnFav.text = if (id != null && MusicStore.isFav(this, id)) "❤" else "🤍"
        val sp = c.playbackParameters.speed
        btnSpeed.text = if (sp == sp.toInt().toFloat()) "${sp.toInt()}x" else "${sp}x"
        if (id != lastId) {
            lastId = id
            val uri = id?.let { ContentUris.withAppendedId(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, it) }
            Thumbs.load(lifecycleScope, ivArt, uri, 640, false)
        }
        updateProgress()
    }

    private fun updateProgress() {
        val c = controller ?: return
        val left = (PlayerService.instance?.sleepEndAt ?: 0L) - SystemClock.elapsedRealtime()
        btnSleep.text = if (left > 0) "😴 ${(left / 60000) + 1}m" else "😴"
        if (dragging) return
        val dur = c.duration.takeIf { it > 0 } ?: 0L
        sbSeek.max = dur.toInt()
        sbSeek.progress = c.currentPosition.coerceIn(0, dur).toInt()
        tvTime.text = "${Library.fmt(c.currentPosition)} / ${Library.fmt(dur)}"
    }

    private fun sleepDialog() {
        val labels = arrayOf("Mati", "15 menit", "30 menit", "45 menit", "60 menit")
        val mins = intArrayOf(0, 15, 30, 45, 60)
        AlertDialog.Builder(this)
            .setTitle("Sleep timer")
            .setItems(labels) { _, w ->
                PlayerService.instance?.setSleepTimer(mins[w])
                Toast.makeText(
                    this, if (mins[w] == 0) "Timer mati" else "Musik berhenti dalam ${mins[w]} menit",
                    Toast.LENGTH_SHORT
                ).show()
            }
            .show()
    }

    private fun queueDialog() {
        val c = controller ?: return
        val items = Array(c.mediaItemCount) { i ->
            "${i + 1}. ${c.getMediaItemAt(i).mediaMetadata.title ?: "?"}"
        }
        AlertDialog.Builder(this)
            .setTitle("Antrean")
            .setSingleChoiceItems(items, c.currentMediaItemIndex) { d, w ->
                c.seekTo(w, 0L)
                c.play()
                d.dismiss()
            }
            .show()
    }
}
