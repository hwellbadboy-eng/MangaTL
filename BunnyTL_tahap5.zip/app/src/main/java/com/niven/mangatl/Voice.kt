package com.niven.mangatl

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import android.util.Log
import com.k2fsa.sherpa.onnx.GenerationConfig
import com.k2fsa.sherpa.onnx.OfflineTts
import com.k2fsa.sherpa.onnx.OfflineTtsConfig
import com.k2fsa.sherpa.onnx.OfflineTtsModelConfig
import com.k2fsa.sherpa.onnx.OfflineTtsSupertonicModelConfig
import java.io.File
import java.util.concurrent.LinkedBlockingQueue
import java.util.concurrent.TimeUnit

/**
 * Suara keluar 100% offline (Supertonic 3 lewat sherpa-onnx).
 * Taruh folder model suara di folder data app, mis. files/Suara 1/ berisi
 * voice.bin, tts.json, unicode_indexer.bin, dan 4 file .onnx.
 */
object Voice {

    private const val PREF_FILE = "mangatl"
    private const val PREF_VOICE = "voice_dir"
    private const val PREF_SID = "voice_sid"
    const val MAX_SID = 5 // Suara 1-5 cewek, 6 cowok; sisanya sudah dibuang dari app
    private const val PREF_SPEAK = "voice_speak"

    private val END = FloatArray(0)

    // --- Pengaturan kualitas suara (kecepatan mulai ada di Opsi > Kecepatan mulai suara) ---
    // Kecepatan bicara (1.0 normal). 1.1 = sedikit lebih cepat, bantu kalau suara ketinggalan dari teks.
    private const val SPEED = 1.05f

    // Redam sedikit bagian treble yang bikin cempreng (false = mati). Coba true kalau masih terlalu tajam.
    private const val TAME_TREBLE = false
    private const val TAME_HZ = 9000.0
    private const val LEAD_SILENCE_MS = 150 // jeda awal supaya kata pertama tidak terpotong
    private const val SOFT_GAP_MS = 40      // jeda di potongan yang terpotong di tengah frasa
    private const val SOFT = "\u200B"       // penanda internal: potongan terpotong di tengah frasa
    private const val FADE_MS = 8
    private const val PREBUFFER_MAX_WAIT_MS = 2500L
    // Batas panjang satu potongan. Teks panjang yang dibaca sekaligus bikin suara mendem/cempreng,
    // jadi dipecah di koma/spasi. Coba 100-150; makin kecil makin stabil tapi jedanya lebih sering.
    private const val MAX_CHUNK = 120

    private var tts: OfflineTts? = null
    private var ttsDir: String? = null
    private val genLock = Any()

    @Volatile
    private var generation = 0

    @Volatile
    private var track: AudioTrack? = null

    @Volatile
    var speaking = false
        private set

    // ------------------------------------------------------------ pengaturan kecepatan mulai suara

    private const val PREF_MODE = "voice_mode"
    private const val PREF_PAUSE_COMMA = "voice_pause_comma"
    private const val PREF_PAUSE_PERIOD = "voice_pause_period"
    const val PAUSE_MAX_MS = 600
    // Default = suara yang sekarang (jeda 90 ms di tiap pergantian potongan, mode Seimbang).
    const val DEFAULT_MODE = 1
    const val DEFAULT_COMMA_MS = 90
    const val DEFAULT_PERIOD_MS = 90
    const val PAUSE_STEP_MS = 10

    val MODE_LABELS = listOf(
        "Cepat (suara mulai duluan, risiko agak kasar)",
        "Seimbang (disarankan)",
        "Natural (paling jernih, mulai agak telat)"
    )

    /**
     * firstForce: potongan pertama langsung dibacakan kalau sudah segini huruf (tanpa nunggu tanda baca).
     * minFirst: panjang minimal potongan pertama (terlalu pendek = suara mendem).
     * stepsFirst/steps: langkah generate potongan pertama / sisanya (makin tinggi makin jernih, minimal 5 disarankan).
     * prebuffer: jumlah potongan yang disiapkan dulu sebelum mulai bunyi (1 = secepat mungkin).
     */
    class Profile(
        val firstForce: Int,
        val minFirst: Int,
        val minRest: Int,
        val stepsFirst: Int,
        val steps: Int,
        val prebuffer: Int,
        val commaMs: Int,
        val periodMs: Int
    )

    /** Kembalikan kecepatan mulai & jeda koma/titik ke default. */
    fun resetSpeechSettings(context: Context) {
        prefs(context).edit().remove(PREF_MODE).remove(PREF_PAUSE_COMMA).remove(PREF_PAUSE_PERIOD).apply()
    }

    /** Jeda (ms) setelah koma/titik dua/titik koma. */
    fun pauseComma(context: Context): Int =
        prefs(context).getInt(PREF_PAUSE_COMMA, DEFAULT_COMMA_MS).coerceIn(0, PAUSE_MAX_MS)

    fun setPauseComma(context: Context, ms: Int) {
        prefs(context).edit().putInt(PREF_PAUSE_COMMA, ms.coerceIn(0, PAUSE_MAX_MS)).apply()
    }

    /** Jeda (ms) setelah titik/tanda seru/tanda tanya. */
    fun pausePeriod(context: Context): Int =
        prefs(context).getInt(PREF_PAUSE_PERIOD, DEFAULT_PERIOD_MS).coerceIn(0, PAUSE_MAX_MS)

    fun setPausePeriod(context: Context, ms: Int) {
        prefs(context).edit().putInt(PREF_PAUSE_PERIOD, ms.coerceIn(0, PAUSE_MAX_MS)).apply()
    }

    fun mode(context: Context): Int = prefs(context).getInt(PREF_MODE, DEFAULT_MODE).coerceIn(0, 2)

    fun setMode(context: Context, m: Int) {
        prefs(context).edit().putInt(PREF_MODE, m.coerceIn(0, 2)).apply()
    }

    private fun profile(context: Context): Profile {
        val c = pauseComma(context)
        val p = pausePeriod(context)
        return when (mode(context)) {
            0 -> Profile(24, 20, 28, 5, 5, 1, c, p)
            2 -> Profile(45, 28, 40, 6, 6, 2, c, p)
            else -> Profile(30, 24, 40, 5, 6, 1, c, p)
        }
    }

    // ------------------------------------------------------------ model & pilihan

    private fun isVoiceDir(d: File): Boolean =
        d.isDirectory && File(d, "voice.bin").isFile && File(d, "tts.json").isFile &&
            File(d, "unicode_indexer.bin").isFile && part(d, "vector_estimator") != null

    private fun part(dir: File, prefix: String): File? =
        dir.listFiles()?.firstOrNull { it.isFile && it.name.startsWith(prefix) && it.name.endsWith(".onnx") }

    fun listVoices(context: Context): List<File> {
        val root = context.getExternalFilesDir(null) ?: return emptyList()
        return root.walkTopDown().maxDepth(3).filter { isVoiceDir(it) }
            .sortedBy { rel(root, it).lowercase() }.toList()
    }

    fun rel(context: Context, d: File): String {
        val root = context.getExternalFilesDir(null) ?: return d.name
        return rel(root, d)
    }

    private fun rel(root: File, d: File): String =
        try {
            d.relativeTo(root).path.replace(File.separatorChar, '/')
        } catch (_: Throwable) {
            d.name
        }

    fun findVoice(context: Context): File? {
        val all = listVoices(context)
        if (all.isEmpty()) return null
        val want = prefs(context).getString(PREF_VOICE, null)
        return all.firstOrNull { rel(context, it) == want } ?: all.first()
    }

    fun selectVoice(context: Context, d: File) {
        prefs(context).edit().putString(PREF_VOICE, rel(context, d)).apply()
    }

    fun sid(context: Context): Int = prefs(context).getInt(PREF_SID, 0).coerceIn(0, MAX_SID)

    fun setSid(context: Context, sid: Int) {
        prefs(context).edit().putInt(PREF_SID, sid).apply()
    }

    fun autoSpeak(context: Context): Boolean = prefs(context).getBoolean(PREF_SPEAK, false)

    fun setAutoSpeak(context: Context, on: Boolean) {
        prefs(context).edit().putBoolean(PREF_SPEAK, on).apply()
    }

    private fun prefs(context: Context) = context.getSharedPreferences(PREF_FILE, Context.MODE_PRIVATE)

    // ---------------------------------------------------------------- muat model

    private fun ensureTts(dir: File): OfflineTts {
        synchronized(genLock) {
            val cur = tts
            if (cur != null && ttsDir == dir.absolutePath) return cur
            try {
                cur?.free()
            } catch (_: Throwable) {
            }
            tts = null
            fun p(name: String) = File(dir, name).absolutePath
            val cfg = OfflineTtsConfig(
                model = OfflineTtsModelConfig(
                    supertonic = OfflineTtsSupertonicModelConfig(
                        durationPredictor = part(dir, "duration_predictor")!!.absolutePath,
                        textEncoder = part(dir, "text_encoder")!!.absolutePath,
                        vectorEstimator = part(dir, "vector_estimator")!!.absolutePath,
                        vocoder = part(dir, "vocoder")!!.absolutePath,
                        ttsJson = p("tts.json"),
                        unicodeIndexer = p("unicode_indexer.bin"),
                        voiceStyle = p("voice.bin")
                    ),
                    numThreads = 4,
                    provider = "cpu"
                )
            )
            val t = OfflineTts(config = cfg)
            tts = t
            ttsDir = dir.absolutePath
            return t
        }
    }

    /** Muat model suara di latar belakang supaya kalimat pertama tidak menunggu pemuatan. */
    fun preload(context: Context) {
        val appCtx = context.applicationContext
        Thread {
            try {
                ensureTts(findVoice(appCtx) ?: return@Thread)
            } catch (_: Throwable) {
            }
        }.start()
    }

    /** Lepas model dari memori (dipanggil saat tidak dipakai supaya RAM lega). */
    fun release() {
        stop()
        synchronized(genLock) {
            try {
                tts?.free()
            } catch (_: Throwable) {
            }
            tts = null
            ttsDir = null
        }
    }

    // ------------------------------------------------------------------ teks

    private fun cleanForSpeech(raw: String): String {
        var s = raw
        s = s.replace(Regex("(?s)```.*?```"), " ")
        s = s.replace(Regex("https?://\\S+"), " ")
        s = s.replace(Regex("\\[([^\\]]*)]\\([^)]*\\)"), "$1")
        s = s.replace(Regex("[*_#>`~|]+"), " ")
        s = s.replace(Regex("[\\p{So}\\p{Cs}\\p{Cn}]"), " ")
        s = s.replace(Regex("^\\s*[-•]\\s+", RegexOption.MULTILINE), "")
        // Simbol/singkatan yang sering dibaca ngawur oleh model suara.
        s = s.replace("&", " dan ").replace("%", " persen ").replace("+", " tambah ")
        s = s.replace(Regex("\\s*[/\\\\]\\s*"), " atau ")
        s = s.replace(Regex("[(){}\\[\\]<>\"“”«»]"), " ")
        s = s.replace(Regex("\\s+[-–—]+\\s+|\\s*[–—]+\\s*"), ", ") // tanda hubung dalam kata (lain-lain) tetap
        s = s.replace(Regex("\\.{2,}|…"), ".")
        s = s.replace(Regex("([!?.,;:])\\1+"), "$1")
        s = s.replace(Regex("\\bdgn\\b", RegexOption.IGNORE_CASE), "dengan")
            .replace(Regex("\\byg\\b", RegexOption.IGNORE_CASE), "yang")
            .replace(Regex("\\bgk\\b|\\bga\\b|\\bgak\\b", RegexOption.IGNORE_CASE), "tidak")
            .replace(Regex("\\bdll\\b", RegexOption.IGNORE_CASE), "dan lain-lain")
            .replace(Regex("\\bdsb\\b", RegexOption.IGNORE_CASE), "dan sebagainya")
        return s.replace(Regex("[ \\t]+"), " ").trim()
    }

    private fun splitSentences(text: String): List<String> {
        val raw = text.split(Regex("(?<=[.!?…])\\s+|\\n+")).map { it.trim() }.filter { it.isNotEmpty() }
        val out = ArrayList<String>()
        var cur = StringBuilder()
        fun flush() {
            if (cur.isNotBlank()) out.add(cur.toString().trim())
            cur = StringBuilder()
        }
        for (piece in raw) {
            if (piece.length > MAX_CHUNK) {
                flush()
                // pecah kalimat panjang di koma / spasi
                var rest = piece
                while (rest.length > MAX_CHUNK) {
                    var cut = rest.lastIndexOf(',', MAX_CHUNK)
                    if (cut < 40) cut = rest.lastIndexOf(' ', MAX_CHUNK)
                    if (cut < 40) cut = MAX_CHUNK
                    out.add(rest.substring(0, cut + 1).trim())
                    rest = rest.substring(cut + 1).trim()
                }
                if (rest.isNotEmpty()) out.add(rest)
                continue
            }
            if (cur.isNotEmpty()) cur.append(' ')
            cur.append(piece)
            if (cur.length >= 70) flush()
        }
        flush()
        // Sisa potongan yang terlalu pendek digabung ke potongan sebelumnya.
        if (out.size >= 2 && out.last().length < 20 && out[out.size - 2].length + out.last().length < MAX_CHUNK + 20) {
            val tail = out.removeAt(out.size - 1)
            out[out.size - 1] = out.last() + " " + tail
        }
        return out
    }

    /** Pastikan potongan berakhir dengan tanda baca supaya intonasi akhir kalimat turun dengan benar. */
    private fun finishPunct(s: String): String {
        val t = s.trim()
        if (t.isEmpty()) return t
        return if (t.last().isLetterOrDigit()) "$t." else t
    }

    /** Rapikan hasil model: cegah clipping, samakan volume antar potongan, fade anti-klik, jeda. */
    private fun polish(samples: FloatArray, sr: Int, first: Boolean, gapMs: Int): FloatArray {
        var x = samples
        if (x.isEmpty()) return x
        if (TAME_TREBLE) {
            val a = 1.0 - Math.exp(-2.0 * Math.PI * TAME_HZ / sr)
            var y = 0.0
            x = FloatArray(x.size) { i ->
                y += a * (samples[i] - y)
                y.toFloat()
            }
        }
        var peak = 0f
        for (v in x) {
            val a = Math.abs(v)
            if (a > peak) peak = a
        }
        if (peak > 0.0001f) {
            val gain = (0.9f / peak).coerceIn(0.5f, 3f)
            for (i in x.indices) x[i] = x[i] * gain
        }
        val fade = (sr * FADE_MS / 1000).coerceAtMost(x.size / 2)
        for (i in 0 until fade) {
            val g = i / fade.toFloat()
            x[i] *= g
            x[x.size - 1 - i] *= g
        }
        val lead = if (first) sr * LEAD_SILENCE_MS / 1000 else 0
        val gap = sr * gapMs / 1000
        val out = FloatArray(lead + x.size + gap)
        System.arraycopy(x, 0, out, lead, x.size)
        return out
    }

    // ------------------------------------------------------------- bicara

    private const val EOS = "\u0000EOS"

    /**
     * Pembaca streaming: teks dimasukkan sedikit demi sedikit lewat feed() (mis. potongan jawaban AI),
     * tiap kalimat yang sudah lengkap langsung disuarakan tanpa menunggu jawaban selesai.
     * Panggil finish() setelah teks habis.
     */
    class Stream internal constructor(
        private val my: Int,
        private val q: LinkedBlockingQueue<String>,
        private val p: Profile
    ) {
        private val buf = StringBuilder()
        private var first = true
        private val boundary = Regex("[.!?…]+\\s|\\n|[,;:]\\s")
        // Potongan pertama boleh berhenti di koma supaya suara mulai lebih cepat.
        private val boundaryFirst = Regex("[.!?…]+\\s|\\n|[,;:]\\s")

        @Synchronized
        fun feed(chunk: String) {
            if (generation != my || chunk.isEmpty()) return
            buf.append(chunk)
            drain(false)
        }

        @Synchronized
        fun finish() {
            if (generation != my) return
            drain(true)
            q.offer(EOS)
        }

        private fun emit(piece: String, soft: Boolean = false) {
            val t = piece.trimEnd()
            // Potongan yang dipotong di tengah kalimat diakhiri koma, bukan titik, supaya intonasi
            // tidak turun di tengah kalimat dan sambungan ke potongan berikutnya terdengar natural.
            val p = if (soft) (if (t.lastOrNull()?.isLetterOrDigit() == true) "$t,$SOFT" else "$t$SOFT") else t
            for (s in splitSentences(cleanForSpeech(p))) q.offer(s)
        }

        private fun drain(all: Boolean) {
            while (true) {
                val s = buf.toString()
                // Blok kode belum tertutup: tunggu dulu.
                if (!all && Regex("```").findAll(s).count() % 2 == 1) return
                val minLen = if (first) p.minFirst else p.minRest
                var cut = -1
                var soft = false
                for (m in (if (first) boundaryFirst else boundary).findAll(s)) {
                    val end = m.range.last + 1
                    if (end >= minLen) {
                        cut = end
                        break
                    }
                }
                // Potongan pertama: jangan nunggu tanda baca. Begitu sudah cukup panjang, potong di
                // batas kata supaya suara mulai berbarengan dengan teks yang baru muncul.
                if (cut < 0 && !all && first && s.length >= p.firstForce) {
                    val sp = s.lastIndexOf(' ')
                    if (sp >= p.minFirst) {
                        cut = sp + 1
                        soft = true
                    }
                }
                if (cut < 0 && !all && s.length > MAX_CHUNK) {
                    var c = s.lastIndexOf(',', MAX_CHUNK)
                    if (c < 40) c = s.lastIndexOf(' ', MAX_CHUNK)
                    if (c < 40) c = MAX_CHUNK
                    cut = c + 1
                    soft = true
                }
                if (cut < 0) {
                    if (all && s.isNotBlank()) {
                        emit(s)
                        buf.setLength(0)
                    }
                    return
                }
                emit(s.substring(0, cut), soft)
                first = false
                buf.delete(0, cut)
            }
        }

        fun cancel() {
            if (generation == my) stop()
        }
    }

    /** Bacakan teks utuh. onDone dipanggil dari thread latar: null = selesai/dihentikan, selain itu pesan error. */
    fun speak(context: Context, text: String, releaseAfter: Boolean = false, onDone: (String?) -> Unit) {
        val st = startStream(context, releaseAfter, onDone)
        st.feed(text)
        st.finish()
    }

    /**
     * Mulai pembaca streaming. Model suara dimuat di latar belakang saat itu juga (selagi AI masih mikir),
     * jadi suara bisa langsung keluar begitu kalimat pertama selesai.
     */
    fun startStream(context: Context, releaseAfter: Boolean = false, onDone: (String?) -> Unit): Stream {
        stop()
        val appCtx = context.applicationContext
        val my = ++generation
        speaking = true
        val textQ = LinkedBlockingQueue<String>()
        val prof = profile(appCtx)
        val stream = Stream(my, textQ, prof)
        Thread {
            var err: String? = null
            var at: AudioTrack? = null
            try {
                val dir = findVoice(appCtx) ?: throw IllegalStateException("Model suara belum ada")
                val t = ensureTts(dir)
                val sr = t.sampleRate()
                val speakerId = sid(appCtx).coerceAtMost(maxOf(0, t.numSpeakers() - 1))
                val audioQ = LinkedBlockingQueue<FloatArray>(3)
                var idx = 0

                // Penghasil suara: kalimat berikutnya dibuat selagi kalimat sebelumnya diputar.
                val producer = Thread {
                    try {
                        while (generation == my) {
                            val s = textQ.poll(200, TimeUnit.MILLISECONDS) ?: continue
                            if (s == EOS) break
                            val soft = s.endsWith(SOFT)
                            val clean = s.removeSuffix(SOFT)
                            val text = finishPunct(clean)
                            if (text.isEmpty()) continue
                            val gapMs = when {
                                soft -> SOFT_GAP_MS
                                text.last() in ",;:" -> prof.commaMs
                                else -> prof.periodMs
                            }
                            val isFirst = idx == 0
                            val t0 = System.nanoTime()
                            val audio = synchronized(genLock) {
                                if (tts !== t) return@synchronized null
                                t.generateWithConfig(
                                    text,
                                    GenerationConfig(
                                        sid = speakerId,
                                        speed = SPEED,
                                        numSteps = if (isFirst) prof.stepsFirst else prof.steps,
                                        extra = mapOf("lang" to "id")
                                    )
                                )
                            } ?: break
                            idx++
                            val samples = polish(audio.samples, sr, isFirst, gapMs)
                            Log.d(
                                "BunnyVoice",
                                "potongan ${text.length} huruf: bikin ${(System.nanoTime() - t0) / 1_000_000} ms, " +
                                    "durasi suara ${audio.samples.size * 1000L / sr} ms, steps=${if (isFirst) prof.stepsFirst else prof.steps}"
                            )
                            var placed = false
                            while (!placed && generation == my) {
                                placed = audioQ.offer(samples, 200, TimeUnit.MILLISECONDS)
                            }
                        }
                    } catch (_: Throwable) {
                    } finally {
                        var placed = false
                        while (!placed && generation == my) {
                            placed = audioQ.offer(END, 200, TimeUnit.MILLISECONDS)
                        }
                    }
                }
                producer.start()

                val minBuf = AudioTrack.getMinBufferSize(
                    sr, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_FLOAT
                )
                val track = AudioTrack.Builder()
                    .setAudioAttributes(
                        AudioAttributes.Builder()
                            .setUsage(AudioAttributes.USAGE_MEDIA)
                            .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                            .build()
                    )
                    .setAudioFormat(
                        AudioFormat.Builder()
                            .setEncoding(AudioFormat.ENCODING_PCM_FLOAT)
                            .setSampleRate(sr)
                            .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                            .build()
                    )
                    .setBufferSizeInBytes(maxOf(minBuf, sr * 4))
                    .setTransferMode(AudioTrack.MODE_STREAM)
                    .build()
                at = track
                Voice.track = track
                var started = false
                var frames = 0L
                val pending = ArrayList<FloatArray>()
                var firstAt = 0L

                fun writeChunk(c: FloatArray) {
                    var off = 0
                    while (off < c.size && generation == my) {
                        val n = track.write(c, off, c.size - off, AudioTrack.WRITE_BLOCKING)
                        if (n <= 0) break
                        off += n
                    }
                    frames += c.size
                }

                fun startNow() {
                    if (started) return
                    track.play()
                    started = true
                    for (c in pending) writeChunk(c)
                    pending.clear()
                }

                while (generation == my) {
                    val chunk = audioQ.poll(200, TimeUnit.MILLISECONDS)
                    if (chunk == null) {
                        if (!started && pending.isNotEmpty() &&
                            System.currentTimeMillis() - firstAt > PREBUFFER_MAX_WAIT_MS
                        ) startNow()
                        continue
                    }
                    if (chunk === END) {
                        startNow()
                        break
                    }
                    if (started) {
                        writeChunk(chunk)
                    } else {
                        if (pending.isEmpty()) firstAt = System.currentTimeMillis()
                        pending.add(chunk)
                        if (pending.size >= prof.prebuffer) startNow()
                    }
                }
                // Tunggu sisa suara di buffer selesai diputar.
                val deadline = System.currentTimeMillis() + 60_000
                while (generation == my && started && track.playbackHeadPosition < frames &&
                    System.currentTimeMillis() < deadline
                ) {
                    Thread.sleep(50)
                }
            } catch (t: Throwable) {
                err = t.message ?: t::class.java.simpleName
            } finally {
                try {
                    at?.stop()
                } catch (_: Throwable) {
                }
                try {
                    at?.release()
                } catch (_: Throwable) {
                }
                if (track === at) track = null
                if (generation == my) speaking = false
                if (releaseAfter && generation == my) release()
                onDone(err)
            }
        }.start()
        return stream
    }

    /** Hentikan suara yang sedang diputar atau antre. */
    fun stop() {
        generation++
        speaking = false
        try {
            track?.pause()
            track?.flush()
            track?.stop()
        } catch (_: Throwable) {
        }
    }
}
