package com.niven.mangatl

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import com.k2fsa.sherpa.onnx.GenerationConfig
import com.k2fsa.sherpa.onnx.OfflineTts
import com.k2fsa.sherpa.onnx.OfflineTtsConfig
import com.k2fsa.sherpa.onnx.OfflineTtsModelConfig
import com.k2fsa.sherpa.onnx.OfflineTtsSupertonicModelConfig
import java.io.File
import java.util.concurrent.LinkedBlockingQueue
import java.util.concurrent.TimeUnit

/**
 * Suara keluar 100% offline (Supertonic 3 lewat sherpa-onnx).
 * Taruh folder model suara di folder data app, mis. files/Suara 1/ berisi
 * voice.bin, tts.json, unicode_indexer.bin, dan 4 file .onnx.
 */
object Voice {

    private const val PREF_FILE = "mangatl"
    private const val PREF_VOICE = "voice_dir"
    private const val PREF_SID = "voice_sid"
    const val MAX_SID = 5 // Suara 1-5 cewek, 6 cowok; sisanya sudah dibuang dari app
    private const val PREF_SPEAK = "voice_speak"

    private val END = FloatArray(0)

    private var tts: OfflineTts? = null
    private var ttsDir: String? = null
    private val genLock = Any()

    @Volatile
    private var generation = 0

    @Volatile
    private var track: AudioTrack? = null

    @Volatile
    var speaking = false
        private set

    // ------------------------------------------------------------ model & pilihan

    private fun isVoiceDir(d: File): Boolean =
        d.isDirectory && File(d, "voice.bin").isFile && File(d, "tts.json").isFile &&
            File(d, "unicode_indexer.bin").isFile && part(d, "vector_estimator") != null

    private fun part(dir: File, prefix: String): File? =
        dir.listFiles()?.firstOrNull { it.isFile && it.name.startsWith(prefix) && it.name.endsWith(".onnx") }

    fun listVoices(context: Context): List<File> {
        val root = context.getExternalFilesDir(null) ?: return emptyList()
        return root.walkTopDown().maxDepth(3).filter { isVoiceDir(it) }
            .sortedBy { rel(root, it).lowercase() }.toList()
    }

    fun rel(context: Context, d: File): String {
        val root = context.getExternalFilesDir(null) ?: return d.name
        return rel(root, d)
    }

    private fun rel(root: File, d: File): String =
        try {
            d.relativeTo(root).path.replace(File.separatorChar, '/')
        } catch (_: Throwable) {
            d.name
        }

    fun findVoice(context: Context): File? {
        val all = listVoices(context)
        if (all.isEmpty()) return null
        val want = prefs(context).getString(PREF_VOICE, null)
        return all.firstOrNull { rel(context, it) == want } ?: all.first()
    }

    fun selectVoice(context: Context, d: File) {
        prefs(context).edit().putString(PREF_VOICE, rel(context, d)).apply()
    }

    fun sid(context: Context): Int = prefs(context).getInt(PREF_SID, 0).coerceIn(0, MAX_SID)

    fun setSid(context: Context, sid: Int) {
        prefs(context).edit().putInt(PREF_SID, sid).apply()
    }

    fun autoSpeak(context: Context): Boolean = prefs(context).getBoolean(PREF_SPEAK, false)

    fun setAutoSpeak(context: Context, on: Boolean) {
        prefs(context).edit().putBoolean(PREF_SPEAK, on).apply()
    }

    private fun prefs(context: Context) = context.getSharedPreferences(PREF_FILE, Context.MODE_PRIVATE)

    // ---------------------------------------------------------------- muat model

    private fun ensureTts(dir: File): OfflineTts {
        synchronized(genLock) {
            val cur = tts
            if (cur != null && ttsDir == dir.absolutePath) return cur
            try {
                cur?.free()
            } catch (_: Throwable) {
            }
            tts = null
            fun p(name: String) = File(dir, name).absolutePath
            val cfg = OfflineTtsConfig(
                model = OfflineTtsModelConfig(
                    supertonic = OfflineTtsSupertonicModelConfig(
                        durationPredictor = part(dir, "duration_predictor")!!.absolutePath,
                        textEncoder = part(dir, "text_encoder")!!.absolutePath,
                        vectorEstimator = part(dir, "vector_estimator")!!.absolutePath,
                        vocoder = part(dir, "vocoder")!!.absolutePath,
                        ttsJson = p("tts.json"),
                        unicodeIndexer = p("unicode_indexer.bin"),
                        voiceStyle = p("voice.bin")
                    ),
                    numThreads = 4,
                    provider = "cpu"
                )
            )
            val t = OfflineTts(config = cfg)
            tts = t
            ttsDir = dir.absolutePath
            return t
        }
    }

    /** Lepas model dari memori (dipanggil saat tidak dipakai supaya RAM lega). */
    fun release() {
        stop()
        synchronized(genLock) {
            try {
                tts?.free()
            } catch (_: Throwable) {
            }
            tts = null
            ttsDir = null
        }
    }

    // ------------------------------------------------------------------ teks

    private fun cleanForSpeech(raw: String): String {
        var s = raw
        s = s.replace(Regex("(?s)```.*?```"), " ")
        s = s.replace(Regex("https?://\\S+"), " ")
        s = s.replace(Regex("\\[([^\\]]*)]\\([^)]*\\)"), "$1")
        s = s.replace(Regex("[*_#>`~|]+"), " ")
        s = s.replace(Regex("[\\p{So}\\p{Cs}\\p{Cn}]"), " ")
        s = s.replace(Regex("^\\s*[-•]\\s+", RegexOption.MULTILINE), "")
        return s.replace(Regex("[ \\t]+"), " ").trim()
    }

    private fun splitSentences(text: String): List<String> {
        val raw = text.split(Regex("(?<=[.!?…])\\s+|\\n+")).map { it.trim() }.filter { it.isNotEmpty() }
        val out = ArrayList<String>()
        var cur = StringBuilder()
        fun flush() {
            if (cur.isNotBlank()) out.add(cur.toString().trim())
            cur = StringBuilder()
        }
        for (piece in raw) {
            if (piece.length > 220) {
                flush()
                // pecah kalimat panjang di koma / spasi
                var rest = piece
                while (rest.length > 220) {
                    var cut = rest.lastIndexOf(',', 220)
                    if (cut < 60) cut = rest.lastIndexOf(' ', 220)
                    if (cut < 60) cut = 220
                    out.add(rest.substring(0, cut + 1).trim())
                    rest = rest.substring(cut + 1).trim()
                }
                if (rest.isNotEmpty()) out.add(rest)
                continue
            }
            if (cur.isNotEmpty()) cur.append(' ')
            cur.append(piece)
            if (cur.length >= 40) flush()
        }
        flush()
        return out
    }

    // ------------------------------------------------------------- bicara

    private const val EOS = "\u0000EOS"

    /**
     * Pembaca streaming: teks dimasukkan sedikit demi sedikit lewat feed() (mis. potongan jawaban AI),
     * tiap kalimat yang sudah lengkap langsung disuarakan tanpa menunggu jawaban selesai.
     * Panggil finish() setelah teks habis.
     */
    class Stream internal constructor(
        private val my: Int,
        private val q: LinkedBlockingQueue<String>
    ) {
        private val buf = StringBuilder()
        private var first = true
        private val boundary = Regex("[.!?…]+\\s|\\n")

        @Synchronized
        fun feed(chunk: String) {
            if (generation != my || chunk.isEmpty()) return
            buf.append(chunk)
            drain(false)
        }

        @Synchronized
        fun finish() {
            if (generation != my) return
            drain(true)
            q.offer(EOS)
        }

        private fun emit(piece: String) {
            for (s in splitSentences(cleanForSpeech(piece))) q.offer(s)
        }

        private fun drain(all: Boolean) {
            while (true) {
                val s = buf.toString()
                // Blok kode belum tertutup: tunggu dulu.
                if (!all && Regex("```").findAll(s).count() % 2 == 1) return
                val minLen = if (first) 12 else 28
                var cut = -1
                for (m in boundary.findAll(s)) {
                    val end = m.range.last + 1
                    if (end >= minLen) {
                        cut = end
                        break
                    }
                }
                if (cut < 0 && !all && s.length > 200) {
                    var c = s.lastIndexOf(',', 200)
                    if (c < 60) c = s.lastIndexOf(' ', 200)
                    if (c < 60) c = 200
                    cut = c + 1
                }
                if (cut < 0) {
                    if (all && s.isNotBlank()) {
                        emit(s)
                        buf.setLength(0)
                    }
                    return
                }
                emit(s.substring(0, cut))
                first = false
                buf.delete(0, cut)
            }
        }

        fun cancel() {
            if (generation == my) stop()
        }
    }

    /** Bacakan teks utuh. onDone dipanggil dari thread latar: null = selesai/dihentikan, selain itu pesan error. */
    fun speak(context: Context, text: String, releaseAfter: Boolean = false, onDone: (String?) -> Unit) {
        val st = startStream(context, releaseAfter, onDone)
        st.feed(text)
        st.finish()
    }

    /**
     * Mulai pembaca streaming. Model suara dimuat di latar belakang saat itu juga (selagi AI masih mikir),
     * jadi suara bisa langsung keluar begitu kalimat pertama selesai.
     */
    fun startStream(context: Context, releaseAfter: Boolean = false, onDone: (String?) -> Unit): Stream {
        stop()
        val appCtx = context.applicationContext
        val my = ++generation
        speaking = true
        val textQ = LinkedBlockingQueue<String>()
        val stream = Stream(my, textQ)
        Thread {
            var err: String? = null
            var at: AudioTrack? = null
            try {
                val dir = findVoice(appCtx) ?: throw IllegalStateException("Model suara belum ada")
                val t = ensureTts(dir)
                val sr = t.sampleRate()
                val speakerId = sid(appCtx).coerceAtMost(maxOf(0, t.numSpeakers() - 1))
                val audioQ = LinkedBlockingQueue<FloatArray>(3)

                // Penghasil suara: kalimat berikutnya dibuat selagi kalimat sebelumnya diputar.
                val producer = Thread {
                    try {
                        while (generation == my) {
                            val s = textQ.poll(200, TimeUnit.MILLISECONDS) ?: continue
                            if (s == EOS) break
                            val audio = synchronized(genLock) {
                                if (tts !== t) return@synchronized null
                                t.generateWithConfig(
                                    s,
                                    GenerationConfig(
                                        sid = speakerId,
                                        speed = 1.0f,
                                        numSteps = 5,
                                        extra = mapOf("lang" to "id")
                                    )
                                )
                            } ?: break
                            var placed = false
                            while (!placed && generation == my) {
                                placed = audioQ.offer(audio.samples, 200, TimeUnit.MILLISECONDS)
                            }
                        }
                    } catch (_: Throwable) {
                    } finally {
                        var placed = false
                        while (!placed && generation == my) {
                            placed = audioQ.offer(END, 200, TimeUnit.MILLISECONDS)
                        }
                    }
                }
                producer.start()

                val minBuf = AudioTrack.getMinBufferSize(
                    sr, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_FLOAT
                )
                val track = AudioTrack.Builder()
                    .setAudioAttributes(
                        AudioAttributes.Builder()
                            .setUsage(AudioAttributes.USAGE_MEDIA)
                            .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                            .build()
                    )
                    .setAudioFormat(
                        AudioFormat.Builder()
                            .setEncoding(AudioFormat.ENCODING_PCM_FLOAT)
                            .setSampleRate(sr)
                            .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                            .build()
                    )
                    .setBufferSizeInBytes(maxOf(minBuf, sr * 4))
                    .setTransferMode(AudioTrack.MODE_STREAM)
                    .build()
                at = track
                Voice.track = track
                var started = false

                var frames = 0L
                while (generation == my) {
                    val chunk = audioQ.poll(200, TimeUnit.MILLISECONDS) ?: continue
                    if (chunk === END) break
                    if (!started) {
                        track.play()
                        started = true
                    }
                    var off = 0
                    while (off < chunk.size && generation == my) {
                        val n = track.write(chunk, off, chunk.size - off, AudioTrack.WRITE_BLOCKING)
                        if (n <= 0) break
                        off += n
                    }
                    frames += chunk.size
                }
                // Tunggu sisa suara di buffer selesai diputar.
                val deadline = System.currentTimeMillis() + 60_000
                while (generation == my && started && track.playbackHeadPosition < frames &&
                    System.currentTimeMillis() < deadline
                ) {
                    Thread.sleep(50)
                }
            } catch (t: Throwable) {
                err = t.message ?: t::class.java.simpleName
            } finally {
                try {
                    at?.stop()
                } catch (_: Throwable) {
                }
                try {
                    at?.release()
                } catch (_: Throwable) {
                }
                if (track === at) track = null
                if (generation == my) speaking = false
                if (releaseAfter && generation == my) release()
                onDone(err)
            }
        }.start()
        return stream
    }

    /** Hentikan suara yang sedang diputar atau antre. */
    fun stop() {
        generation++
        speaking = false
        try {
            track?.pause()
            track?.flush()
            track?.stop()
        } catch (_: Throwable) {
        }
    }
}
