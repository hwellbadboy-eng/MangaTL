package com.niven.mangatl

import android.content.Context
import androidx.media3.exoplayer.DefaultRenderersFactory

/**
 * Pabrik decoder. Memakai NextRenderersFactory (FFmpeg) kalau ada; dimuat lewat refleksi
 * supaya kalau library-nya tidak ada, pemutar tetap jalan dengan decoder bawaan.
 */
object Decoders {
    private const val NEXT = "io.github.anilbeesetti.nextlib.media3ext.ffdecoder.NextRenderersFactory"

    fun factory(ctx: Context, mode: Int): DefaultRenderersFactory {
        val app = ctx.applicationContext
        val f: DefaultRenderersFactory = if (mode == 2) {
            DefaultRenderersFactory(app)
        } else {
            try {
                Class.forName(NEXT).getConstructor(Context::class.java)
                    .newInstance(app) as DefaultRenderersFactory
            } catch (e: Throwable) {
                DefaultRenderersFactory(app)
            }
        }
        f.setExtensionRendererMode(
            when (mode) {
                1 -> DefaultRenderersFactory.EXTENSION_RENDERER_MODE_PREFER
                2 -> DefaultRenderersFactory.EXTENSION_RENDERER_MODE_OFF
                else -> DefaultRenderersFactory.EXTENSION_RENDERER_MODE_ON
            }
        )
        f.setEnableDecoderFallback(true)
        return f
    }
}
