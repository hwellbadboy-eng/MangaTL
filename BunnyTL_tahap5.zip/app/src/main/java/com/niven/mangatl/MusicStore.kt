package com.niven.mangatl

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/** Favorit dan playlist, disimpan di SharedPreferences. */
object MusicStore {
    private fun p(ctx: Context) = ctx.getSharedPreferences("music", Context.MODE_PRIVATE)

    fun favs(ctx: Context): Set<Long> =
        (p(ctx).getStringSet("favs", emptySet()) ?: emptySet()).mapNotNull { it.toLongOrNull() }.toSet()

    fun isFav(ctx: Context, id: Long) = favs(ctx).contains(id)

    fun toggleFav(ctx: Context, id: Long): Boolean {
        val s = HashSet(p(ctx).getStringSet("favs", emptySet()) ?: emptySet())
        val now = if (s.contains(id.toString())) { s.remove(id.toString()); false } else { s.add(id.toString()); true }
        p(ctx).edit().putStringSet("favs", s).apply()
        return now
    }

    fun playlists(ctx: Context): LinkedHashMap<String, MutableList<Long>> {
        val out = LinkedHashMap<String, MutableList<Long>>()
        try {
            val o = JSONObject(p(ctx).getString("playlists", "{}") ?: "{}")
            val it = o.keys()
            while (it.hasNext()) {
                val name = it.next()
                val arr = o.getJSONArray(name)
                val l = ArrayList<Long>()
                for (i in 0 until arr.length()) l.add(arr.getLong(i))
                out[name] = l
            }
        } catch (e: Exception) {
        }
        return out
    }

    private fun save(ctx: Context, m: Map<String, List<Long>>) {
        val o = JSONObject()
        for ((k, v) in m) o.put(k, JSONArray(v))
        p(ctx).edit().putString("playlists", o.toString()).apply()
    }

    fun create(ctx: Context, name: String) {
        val m = playlists(ctx)
        if (!m.containsKey(name)) m[name] = ArrayList()
        save(ctx, m)
    }

    fun addTo(ctx: Context, name: String, id: Long) {
        val m = playlists(ctx)
        val l = m.getOrPut(name) { ArrayList() }
        if (!l.contains(id)) l.add(id)
        save(ctx, m)
    }

    fun removeFrom(ctx: Context, name: String, id: Long) {
        val m = playlists(ctx)
        m[name]?.remove(id)
        save(ctx, m)
    }

    fun delete(ctx: Context, name: String) {
        val m = playlists(ctx)
        m.remove(name)
        save(ctx, m)
    }
}
