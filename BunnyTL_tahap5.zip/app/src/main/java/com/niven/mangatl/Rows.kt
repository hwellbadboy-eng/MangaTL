package com.niven.mangatl

import android.content.ContentUris
import android.content.Context
import android.graphics.Bitmap
import android.net.Uri
import android.os.Build
import android.provider.MediaStore
import android.util.LruCache
import android.util.Size
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.ProgressBar
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/** Satu baris daftar (lagu, album, folder, video, playlist). */
class Row(
    val title: String,
    val sub: String,
    val thumb: Uri?,
    val video: Boolean,
    val place: String,
    val badge: String? = null,
    val progress: Int = -1,
    val onLong: (() -> Unit)? = null,
    val onClick: () -> Unit
)

/** Pemuat thumbnail dengan cache memori. */
object Thumbs {
    private val cache = object : LruCache<String, Bitmap>(32 * 1024 * 1024) {
        override fun sizeOf(key: String, value: Bitmap) = value.byteCount
    }
    private val miss = HashSet<String>()

    fun load(scope: CoroutineScope, iv: ImageView, uri: Uri?, size: Int, video: Boolean) {
        if (uri == null) {
            iv.tag = null
            iv.setImageDrawable(null)
            return
        }
        val key = "$uri@$size"
        iv.tag = key
        val hit = cache.get(key)
        if (hit != null) {
            iv.setImageBitmap(hit)
            return
        }
        iv.setImageDrawable(null)
        if (miss.contains(key)) return
        scope.launch {
            val bmp = withContext(Dispatchers.IO) { decode(iv.context, uri, size, video) }
            if (bmp != null) {
                cache.put(key, bmp)
                if (iv.tag == key) iv.setImageBitmap(bmp)
            } else {
                miss.add(key)
            }
        }
    }

    @Suppress("DEPRECATION")
    private fun decode(ctx: Context, uri: Uri, size: Int, video: Boolean): Bitmap? = try {
        if (Build.VERSION.SDK_INT >= 29) {
            ctx.contentResolver.loadThumbnail(uri, Size(size, size), null)
        } else if (video) {
            MediaStore.Video.Thumbnails.getThumbnail(
                ctx.contentResolver, ContentUris.parseId(uri),
                MediaStore.Video.Thumbnails.MINI_KIND, null
            )
        } else null
    } catch (e: Exception) {
        null
    }
}

class RowAdapter(private val scope: CoroutineScope) : RecyclerView.Adapter<RowAdapter.VH>() {

    var rows: List<Row> = emptyList()
        set(v) {
            field = v
            notifyDataSetChanged()
        }

    class VH(v: View) : RecyclerView.ViewHolder(v) {
        val wrap: View = v.findViewById(R.id.thumbWrap)
        val place: TextView = v.findViewById(R.id.tvPlace)
        val img: ImageView = v.findViewById(R.id.ivThumb)
        val badge: TextView = v.findViewById(R.id.tvBadge)
        val bar: ProgressBar = v.findViewById(R.id.pbWatch)
        val title: TextView = v.findViewById(R.id.tvTitle)
        val sub: TextView = v.findViewById(R.id.tvSub)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH =
        VH(LayoutInflater.from(parent.context).inflate(R.layout.item_row, parent, false))

    override fun getItemCount() = rows.size

    override fun onBindViewHolder(h: VH, pos: Int) {
        val r = rows[pos]
        val d = h.itemView.resources.displayMetrics.density
        val lp = h.wrap.layoutParams
        lp.width = ((if (r.video) 108 else 64) * d).toInt()
        lp.height = (64 * d).toInt()
        h.wrap.layoutParams = lp

        h.title.text = r.title
        h.sub.text = r.sub
        h.sub.visibility = if (r.sub.isEmpty()) View.GONE else View.VISIBLE
        h.place.text = r.place
        h.badge.visibility = if (r.badge == null) View.GONE else View.VISIBLE
        h.badge.text = r.badge ?: ""
        if (r.progress in 0..100) {
            h.bar.visibility = View.VISIBLE
            h.bar.progress = r.progress
        } else {
            h.bar.visibility = View.GONE
        }
        Thumbs.load(scope, h.img, r.thumb, ((if (r.video) 108 else 64) * d * 2).toInt(), r.video)

        h.itemView.setOnClickListener { r.onClick() }
        val lg = r.onLong
        if (lg != null) {
            h.itemView.setOnLongClickListener { lg(); true }
        } else {
            h.itemView.setOnLongClickListener(null)
            h.itemView.isLongClickable = false
        }
    }
}
