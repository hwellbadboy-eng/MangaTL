package com.niven.mangatl

import android.content.ContentUris
import android.content.Context
import android.graphics.Bitmap
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Build
import android.provider.MediaStore
import android.util.LruCache
import android.util.Size
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import kotlinx.coroutines.withContext

/**
 * Satu baris daftar. Kalau [thumbs] berisi 2+ gambar, ditampilkan mosaik 4 kotak;
 * kalau tidak, satu thumbnail ([thumb]). [icon] jadi pengganti selama thumbnail belum ada.
 */
class Row(
    val title: String,
    val sub: String,
    val icon: Int,
    val thumb: Uri? = null,
    val thumbs: List<Uri> = emptyList(),
    val video: Boolean = false,
    val badge: String? = null,
    val progress: Int = -1,
    val status: String? = null,
    val statusDone: Boolean = false,
    val onLong: (() -> Unit)? = null,
    val onClick: () -> Unit
)

/** Pemuat thumbnail dengan cache memori. Video MKV/frame hitam dicoba ulang lewat MediaMetadataRetriever. */
object Thumbs {
    private val cache = object : LruCache<String, Bitmap>(32 * 1024 * 1024) {
        override fun sizeOf(key: String, value: Bitmap) = value.byteCount
    }
    private val miss = HashSet<String>()
    private val frameCache = object : LruCache<String, List<Bitmap>>(6 * 1024 * 1024) {
        override fun sizeOf(key: String, value: List<Bitmap>) = value.sumOf { it.byteCount }
    }
    private val frameAsked = HashSet<String>()
    private val frameGate = Semaphore(1)

    fun frames(uri: Uri): List<Bitmap>? = frameCache.get(uri.toString())

    /**
     * Ambil 4 frame kecil (keyframe saja, murah) untuk pratinjau bergantian. Satu per satu (Semaphore 1),
     * hanya sekali per video, dan kalau gagal (mis. MKV) tidak dicoba ulang, jadi tidak membebani HP.
     */
    fun requestFrames(scope: CoroutineScope, ctx: Context, uri: Uri, size: Int) {
        val key = uri.toString()
        if (!frameAsked.add(key)) return
        scope.launch {
            val list = withContext(Dispatchers.IO) { frameGate.withPermit { grabPreview(ctx, uri, size) } }
            if (list != null && list.size >= 2) frameCache.put(key, list)
        }
    }

    private fun grabPreview(ctx: Context, uri: Uri, size: Int): List<Bitmap>? {
        val r = MediaMetadataRetriever()
        return try {
            try {
                r.setDataSource(ctx, uri)
            } catch (e: Exception) {
                val pfd = ctx.contentResolver.openFileDescriptor(uri, "r") ?: return null
                pfd.use { r.setDataSource(it.fileDescriptor) }
            }
            val dur = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: return null
            if (dur < 4000) return null
            val out = ArrayList<Bitmap>()
            for (pct in intArrayOf(15, 38, 60, 82)) {
                val f = r.getFrameAtTime(dur * pct * 10L, MediaMetadataRetriever.OPTION_CLOSEST_SYNC) ?: continue
                if (mostlyBlack(f)) continue
                scaleTo(f, size)?.let { out.add(it) }
            }
            out
        } catch (e: Throwable) {
            null
        } finally {
            try { r.release() } catch (e: Throwable) { }
        }
    }
    private val gate = Semaphore(4)
    private val ffGate = Semaphore(2)

    fun load(scope: CoroutineScope, iv: ImageView, uri: Uri?, size: Int, video: Boolean) {
        if (uri == null) {
            iv.tag = null
            iv.setImageDrawable(null)
            return
        }
        val key = "$uri@$size"
        iv.tag = key
        val hit = cache.get(key)
        if (hit != null) {
            iv.setImageBitmap(hit)
            return
        }
        iv.setImageDrawable(null)
        if (miss.contains(key)) return
        scope.launch {
            val bmp = withContext(Dispatchers.IO) { gate.withPermit { decode(iv.context, uri, size, video) } }
            if (bmp != null) {
                cache.put(key, bmp)
                if (iv.tag == key) iv.setImageBitmap(bmp)
            } else {
                miss.add(key)
            }
        }
    }

    @Suppress("DEPRECATION")
    private fun system(ctx: Context, uri: Uri, size: Int, video: Boolean): Bitmap? = try {
        if (Build.VERSION.SDK_INT >= 29) {
            ctx.contentResolver.loadThumbnail(uri, Size(size, size), null)
        } else if (video) {
            MediaStore.Video.Thumbnails.getThumbnail(
                ctx.contentResolver, ContentUris.parseId(uri),
                MediaStore.Video.Thumbnails.MINI_KIND, null
            )
        } else null
    } catch (e: Exception) {
        null
    }

    private fun mostlyBlack(b: Bitmap): Boolean = try {
        val sw = if (Build.VERSION.SDK_INT >= 26 && b.config == Bitmap.Config.HARDWARE) {
            b.copy(Bitmap.Config.ARGB_8888, false)
        } else b
        var sum = 0L
        var n = 0
        for (i in 1..8) for (j in 1..8) {
            val px = sw.getPixel(sw.width * i / 9, sw.height * j / 9)
            sum += ((px shr 16) and 255) + ((px shr 8) and 255) + (px and 255)
            n += 3
        }
        n > 0 && sum / n < 12
    } catch (e: Exception) {
        false
    }

    /** Ambil frame dari tengah-awal video (untuk MKV atau saat frame pertama hitam) lewat decoder bawaan HP. */
    private fun frame(ctx: Context, uri: Uri, size: Int): Bitmap? {
        val r = MediaMetadataRetriever()
        return try {
            try {
                r.setDataSource(ctx, uri)
            } catch (e: Exception) {
                // Beberapa HP gagal membuka content:// langsung; coba lewat file descriptor.
                val pfd = ctx.contentResolver.openFileDescriptor(uri, "r") ?: return null
                pfd.use { r.setDataSource(it.fileDescriptor) }
            }
            val dur = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L
            val times = if (dur > 0) listOf(minOf(dur / 10, 8000L), dur / 2) else listOf(1000L)
            var best: Bitmap? = null
            for (t in times) {
                val f = r.getFrameAtTime(t * 1000, MediaMetadataRetriever.OPTION_CLOSEST_SYNC)
                    ?: r.getFrameAtTime(t * 1000, MediaMetadataRetriever.OPTION_CLOSEST)
                    ?: continue
                best = f
                if (!mostlyBlack(f)) break
            }
            scaleTo(best, size)
        } catch (e: Exception) {
            null
        } finally {
            try { r.release() } catch (e: Exception) { }
        }
    }

    private fun scaleTo(b: Bitmap?, size: Int): Bitmap? {
        if (b == null) return null
        val sc = size.toFloat() / maxOf(b.width, b.height)
        return if (sc < 1f) Bitmap.createScaledBitmap(
            b, (b.width * sc).toInt().coerceAtLeast(1), (b.height * sc).toInt().coerceAtLeast(1), true
        ) else b
    }

    @Suppress("DEPRECATION")
    private fun pathOf(ctx: Context, uri: Uri): String? = try {
        ctx.contentResolver.query(uri, arrayOf(MediaStore.MediaColumns.DATA), null, null, null)?.use { c ->
            if (c.moveToFirst()) c.getString(0) else null
        }
    } catch (e: Exception) {
        null
    }

    /**
     * Cadangan terakhir: ambil frame lewat FFmpeg (library nextlib-mediainfo), jadi codec yang tidak didukung
     * decoder bawaan HP (HEVC 10-bit, dll.) tetap bisa punya thumbnail. Dipanggil lewat refleksi supaya aplikasi
     * tetap jalan (tanpa thumbnail tambahan) kalau library-nya tidak ada.
     */
    /** Buka file lewat descriptor; path /proc/self/fd/N bisa dibaca FFmpeg tanpa izin akses semua file. */
    private fun <T> withFdPath(ctx: Context, uri: Uri, block: (String) -> T?): T? {
        val pfd = try { ctx.contentResolver.openFileDescriptor(uri, "r") } catch (e: Throwable) { null }
        if (pfd != null) {
            try {
                val r = block("/proc/self/fd/${pfd.fd}")
                if (r != null) return r
            } finally {
                try { pfd.close() } catch (e: Throwable) { }
            }
        }
        val path = pathOf(ctx, uri) ?: return null
        return block(path)
    }

    private fun durationMs(ctx: Context, uri: Uri): Long {
        val r = MediaMetadataRetriever()
        return try {
            r.setDataSource(ctx, uri)
            r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L
        } catch (e: Throwable) {
            0L
        } finally {
            try { r.release() } catch (e: Throwable) { }
        }
    }

    /** Cadangan 1: MediaThumbnailRetriever milik nextlib (FFmpeg). Dicoba di beberapa titik waktu sampai dapat frame yang tidak hitam. */
    private fun ffmpegRetriever(ctx: Context, uri: Uri, size: Int): Bitmap? {
        val cls = try {
            Class.forName("io.github.anilbeesetti.nextlib.mediainfo.MediaThumbnailRetriever")
        } catch (e: Throwable) {
            return null
        }
        val dur = durationMs(ctx, uri)
        val secs = if (dur > 0) listOf(minOf(dur / 10, 8000L), dur / 20, dur / 4, dur / 2, 1000L, 0L)
        else listOf(1000L, 3000L, 10000L, 0L)
        return withFdPath(ctx, uri) { path ->
            val r = try { cls.getDeclaredConstructor().newInstance() } catch (e: Throwable) { return@withFdPath null }
            try {
                try {
                    cls.getMethod("setDataSource", String::class.java).invoke(r, path)
                } catch (e: Throwable) {
                    cls.getMethod("setDataSource", Context::class.java, Uri::class.java).invoke(r, ctx, uri)
                }
                var best: Bitmap? = null
                for (ms in secs.distinct()) {
                    val f = grab(cls, r, ms * 1000L) ?: continue
                    best = f
                    if (!mostlyBlack(f)) break
                }
                scaleTo(best, size)
            } catch (e: Throwable) {
                null
            } finally {
                try { cls.getMethod("release").invoke(r) } catch (e: Throwable) { }
            }
        }
    }

    private fun grab(cls: Class<*>, r: Any, us: Long): Bitmap? {
        try {
            return cls.getMethod("getFrameAtTime", Long::class.javaPrimitiveType, Int::class.javaPrimitiveType)
                .invoke(r, us, MediaMetadataRetriever.OPTION_CLOSEST_SYNC) as? Bitmap
        } catch (e: NoSuchMethodException) {
        } catch (e: Throwable) {
            return null
        }
        try {
            return cls.getMethod("getFrameAtTime", Long::class.javaPrimitiveType).invoke(r, us) as? Bitmap
        } catch (e: NoSuchMethodException) {
        } catch (e: Throwable) {
            return null
        }
        return try { cls.getMethod("getFrameAtTime").invoke(r) as? Bitmap } catch (e: Throwable) { null }
    }

    /** Cadangan 2: cara lama lewat MediaInfoBuilder. */
    private fun ffmpegFrame(ctx: Context, uri: Uri, size: Int): Bitmap? {
        return try {
            val cls = Class.forName("io.github.anilbeesetti.nextlib.mediainfo.MediaInfoBuilder")
            val builder = cls.getDeclaredConstructor().newInstance()
            var ready: Any? = null
            try {
                ready = cls.getMethod("from", Context::class.java, Uri::class.java).invoke(builder, ctx, uri)
            } catch (e: Throwable) {
            }
            if (ready == null) {
                val path = pathOf(ctx, uri) ?: return null
                ready = cls.getMethod("from", String::class.java).invoke(builder, path)
            }
            val info = cls.getMethod("build").invoke(ready ?: builder) ?: return null
            try {
                scaleTo(info.javaClass.getMethod("getFrame").invoke(info) as? Bitmap, size)
            } finally {
                try {
                    info.javaClass.getMethod("release").invoke(info)
                } catch (e: Throwable) {
                }
            }
        } catch (e: Throwable) {
            null
        }
    }

    /** Kalau semua cara gagal: kotak gelap dengan ekstensi file, supaya tidak kosong. */
    private fun placeholder(uri: Uri, size: Int): Bitmap {
        val s = size.coerceIn(48, 512)
        val b = Bitmap.createBitmap(s, s * 9 / 16, Bitmap.Config.ARGB_8888)
        val c = android.graphics.Canvas(b)
        c.drawColor(0xFF2A2A33.toInt())
        val ext = (uri.lastPathSegment ?: "").substringAfterLast('.', "VIDEO").take(5).uppercase()
        val p = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG).apply {
            color = 0xFFBBBBCC.toInt()
            textSize = s / 5f
            textAlign = android.graphics.Paint.Align.CENTER
            isFakeBoldText = true
        }
        c.drawText("▶ $ext", b.width / 2f, b.height / 2f + p.textSize / 3f, p)
        return b
    }

    private fun decode(ctx: Context, uri: Uri, size: Int, video: Boolean): Bitmap? {
        var bmp = system(ctx, uri, size, video)
        if (video && (bmp == null || mostlyBlack(bmp))) {
            val f = frame(ctx, uri, size)
            if (f != null && !mostlyBlack(f)) return f
            if (f != null) bmp = f
        }
        if (video && (bmp == null || mostlyBlack(bmp))) {
            // Berat dan lambat, jadi dibatasi 2 sekaligus.
            // Loop: coba tiap cara berurutan sampai ada frame yang bukan hitam.
            val tries = listOf<() -> Bitmap?>(
                { ffmpegRetriever(ctx, uri, size) },
                { ffmpegFrame(ctx, uri, size) }
            )
            for (t in tries) {
                val ff = try {
                    kotlinx.coroutines.runBlocking { ffGate.withPermit { t() } }
                } catch (e: Throwable) {
                    null
                }
                if (ff != null) {
                    bmp = ff
                    if (!mostlyBlack(ff)) break
                }
            }
        }
        if (video && bmp == null) bmp = placeholder(uri, size)
        return bmp
    }
}

class RowAdapter(private val scope: CoroutineScope) : RecyclerView.Adapter<RowAdapter.VH>() {

    var rows: List<Row> = emptyList()
        set(v) {
            field = v
            notifyDataSetChanged()
        }

    class VH(v: View) : RecyclerView.ViewHolder(v) {
        val wrap: View = v.findViewById(R.id.thumbWrap)
        val place: ImageView = v.findViewById(R.id.ivPlace)
        val img: ImageView = v.findViewById(R.id.ivThumb)
        val mosaic: LinearLayout = v.findViewById(R.id.mosaic)
        val tiles: List<ImageView> = listOf(
            v.findViewById(R.id.m0), v.findViewById(R.id.m1),
            v.findViewById(R.id.m2), v.findViewById(R.id.m3)
        )
        val badge: TextView = v.findViewById(R.id.tvBadge)
        val bar: ProgressBar = v.findViewById(R.id.pbWatch)
        val title: TextView = v.findViewById(R.id.tvTitle)
        val sub: TextView = v.findViewById(R.id.tvSub)
        val status: TextView = v.findViewById(R.id.tvStatus)
        var animUri: Uri? = null
        var animSize = 0
    }

    // ----- pratinjau bergantian: satu ticker untuk semua baris, hanya baris yang terlihat, hanya saat tidak scroll -----
    private var rv: RecyclerView? = null
    private val handler = android.os.Handler(android.os.Looper.getMainLooper())
    private var tickN = 0
    private val tick = object : Runnable {
        override fun run() {
            val v = rv ?: return
            if (v.isAttachedToWindow && v.windowVisibility == View.VISIBLE &&
                v.scrollState == RecyclerView.SCROLL_STATE_IDLE && Prefs.thumbAnim(v.context)
            ) {
                tickN++
                for (i in 0 until v.childCount) {
                    val h = v.getChildViewHolder(v.getChildAt(i)) as? VH ?: continue
                    val u = h.animUri ?: continue
                    val fr = Thumbs.frames(u)
                    if (fr == null) Thumbs.requestFrames(scope, v.context, u, h.animSize)
                    else h.img.setImageBitmap(fr[tickN % fr.size])
                }
            }
            handler.postDelayed(this, 1400)
        }
    }

    override fun onAttachedToRecyclerView(recyclerView: RecyclerView) {
        rv = recyclerView
        handler.removeCallbacks(tick)
        handler.postDelayed(tick, 1400)
    }

    override fun onDetachedFromRecyclerView(recyclerView: RecyclerView) {
        handler.removeCallbacks(tick)
        rv = null
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH =
        VH(LayoutInflater.from(parent.context).inflate(R.layout.item_row, parent, false))

    override fun getItemCount() = rows.size

    override fun onBindViewHolder(h: VH, pos: Int) {
        val r = rows[pos]
        val d = h.itemView.resources.displayMetrics.density
        val wDp = if (r.video) 108 else 64
        val lp = h.wrap.layoutParams
        lp.width = (wDp * d).toInt()
        lp.height = (64 * d).toInt()
        h.wrap.layoutParams = lp

        h.title.text = r.title
        h.sub.text = r.sub
        h.sub.visibility = if (r.sub.isEmpty()) View.GONE else View.VISIBLE
        h.place.setImageResource(r.icon)
        h.badge.visibility = if (r.badge == null) View.GONE else View.VISIBLE
        h.badge.text = r.badge ?: ""
        if (r.status != null) {
            h.status.visibility = View.VISIBLE
            h.status.text = r.status
            h.status.setTextColor(if (r.statusDone) 0xFF66BB6A.toInt() else 0xFFFFB74D.toInt())
        } else {
            h.status.visibility = View.GONE
        }
        if (r.progress in 0..100) {
            h.bar.visibility = View.VISIBLE
            h.bar.progress = r.progress
        } else {
            h.bar.visibility = View.GONE
        }

        if (r.thumbs.size >= 2) {
            h.img.visibility = View.GONE
            h.mosaic.visibility = View.VISIBLE
            val tile = (wDp / 2.0 * d * 2).toInt()
            h.tiles.forEachIndexed { i, iv -> Thumbs.load(scope, iv, r.thumbs.getOrNull(i), tile, r.video) }
        } else {
            h.mosaic.visibility = View.GONE
            h.img.visibility = View.VISIBLE
            Thumbs.load(scope, h.img, r.thumb ?: r.thumbs.firstOrNull(), (wDp * d * 2).toInt(), r.video)
        }
        val single = r.thumbs.size < 2
        h.animUri = if (r.video && single) (r.thumb ?: r.thumbs.firstOrNull()) else null
        h.animSize = (wDp * d).toInt()

        h.itemView.setOnClickListener { r.onClick() }
        val lg = r.onLong
        if (lg != null) {
            h.itemView.setOnLongClickListener { lg(); true }
        } else {
            h.itemView.setOnLongClickListener(null)
            h.itemView.isLongClickable = false
        }
    }
}
