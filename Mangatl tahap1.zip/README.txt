MangaTL tahap 1: hanya OCR (uji bahwa build berhasil).
Salin file model gemma-4-E2B-it.litertlm (pakai COPY, bukan Move) ke:
Android/data/com.niven.mangatl/files/
