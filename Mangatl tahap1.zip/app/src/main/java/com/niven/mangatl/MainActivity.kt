package com.niven.mangatl

import android.net.Uri
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions

class MainActivity : AppCompatActivity() {

    private lateinit var status: TextView
    private lateinit var result: TextView

    private val pick = registerForActivityResult(ActivityResultContracts.GetContent()) { uri: Uri? ->
        if (uri != null) runOcr(uri)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        status = findViewById(R.id.status)
        result = findViewById(R.id.result)
        findViewById<Button>(R.id.btnPick).setOnClickListener { pick.launch("image/*") }
    }

    private fun runOcr(uri: Uri) {
        status.text = "Membaca teks..."
        result.text = ""
        val image = try {
            InputImage.fromFilePath(this, uri)
        } catch (e: Exception) {
            status.text = "Gagal membuka gambar: ${e.message}"
            return
        }
        TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
            .process(image)
            .addOnSuccessListener { text ->
                val lines = text.textBlocks
                    .map { it.text.replace("\n", " ").trim() }
                    .filter { it.isNotEmpty() }
                result.text = lines.mapIndexed { i, s -> "${i + 1}. $s" }.joinToString("\n")
                status.text = "${lines.size} blok teks ditemukan."
            }
            .addOnFailureListener { e ->
                status.text = "OCR gagal: ${e.message}"
            }
    }
}
