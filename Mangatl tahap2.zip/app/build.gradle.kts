
plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.niven.mangatl"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.niven.mangatl"
        minSdk = 26
        targetSdk = 34
        versionCode = 1
        versionName = "0.1"

        ndk {
            abiFilters += listOf("arm64-v8a")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
}

kotlin {
    compilerOptions {
        jvmTarget.set(org.jetbrains.kotlin.gradle.dsl.JvmTarget.JVM_17)
    }
}

dependencies {
    implementation("com.google.android.material:material:1.12.0")

    // Gemma AI
    implementation("com.google.ai.edge.litertlm:litertlm-android:0.18.1")

    // OCR manga
    implementation("com.google.mlkit:text-recognition:16.0.1")
}
