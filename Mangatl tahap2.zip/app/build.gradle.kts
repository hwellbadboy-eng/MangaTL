plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.niven.mangatl"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.niven.mangatl"
        minSdk = 26
        targetSdk = 34
        versionCode = 1
        versionName = "0.1"

        ndk {
            abiFilters += listOf("arm64-v8a")
        }
    }
}

dependencies {
    implementation("com.google.android.material:material:1.12.0")
}