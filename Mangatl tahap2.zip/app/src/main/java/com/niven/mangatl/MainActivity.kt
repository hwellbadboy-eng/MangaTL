package com.niven.mangatl

import android.net.Uri
import android.os.Bundle
import android.os.SystemClock
import android.widget.Button
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class MainActivity : AppCompatActivity() {

    private lateinit var status: TextView
    private lateinit var result: TextView

    private val pick = registerForActivityResult(ActivityResultContracts.GetContent()) { uri: Uri? ->
        if (uri != null) runOcr(uri)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        status = findViewById(R.id.status)
        result = findViewById(R.id.result)
        findViewById<Button>(R.id.btnPick).setOnClickListener { pick.launch("image/*") }
        val model = Gemma.findModel(this)
        status.text = if (model != null) {
            "Model ditemukan: ${model.name}"
        } else {
            "Model belum ada. Salin file .litertlm ke:\n${getExternalFilesDir(null)}"
        }
    }

    private fun runOcr(uri: Uri) {
        result.text = ""
        val image = try {
            InputImage.fromFilePath(this, uri)
        } catch (e: Exception) {
            status.text = "Gagal membuka gambar: ${e.message}"
            return
        }
        status.text = "Membaca teks..."
        TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
            .process(image)
            .addOnSuccessListener { text ->
                val lines = text.textBlocks
                    .map { it.text.replace("\n", " ").trim() }
                    .filter { it.isNotEmpty() }
                if (lines.isEmpty()) {
                    status.text = "Tidak ada teks terdeteksi."
                    return@addOnSuccessListener
                }
                result.text = lines.mapIndexed { i, s -> "${i + 1}. $s" }.joinToString("\n")
                translate(lines)
            }
            .addOnFailureListener { e ->
                status.text = "OCR gagal: ${e.message}"
            }
    }

    private fun translate(lines: List<String>) {
        val model = Gemma.findModel(this)
        if (model == null) {
            status.text = "Model belum ada. Salin file .litertlm ke:\n${getExternalFilesDir(null)}"
            return
        }
        status.text = "Memuat Gemma dan menerjemahkan ${lines.size} blok..."
        lifecycleScope.launch {
            val t0 = SystemClock.elapsedRealtime()
            val res = try {
                withContext(Dispatchers.IO) { Gemma.translate(this@MainActivity, model, lines) }
            } catch (t: Throwable) {
                status.text = "Gemma gagal: ${t::class.java.simpleName}: ${t.message}"
                return@launch
            }
            val sec = (SystemClock.elapsedRealtime() - t0) / 1000.0
            result.text = lines.indices.joinToString("\n\n") { i ->
                "${i + 1}. ${lines[i]}\n    -> ${res.lines.getOrElse(i) { "?" }}"
            }
            status.text = "Selesai %.1f detik. Mode: %s. Backend: %s".format(sec, res.mode, Gemma.backendName)
        }
    }
}
