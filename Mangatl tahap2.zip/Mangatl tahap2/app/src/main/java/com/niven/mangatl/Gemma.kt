
package com.niven.mangatl

import android.content.Context
import com.google.ai.edge.litertlm.Backend
import com.google.ai.edge.litertlm.Content
import com.google.ai.edge.litertlm.Contents
import com.google.ai.edge.litertlm.ConversationConfig
import com.google.ai.edge.litertlm.Engine
import com.google.ai.edge.litertlm.EngineConfig
import com.google.ai.edge.litertlm.SamplerConfig
import java.io.File

object Gemma {

    const val SRC = "English"
    const val DST = "Indonesian"

    private const val MODEL_NAME = "gemma-4-E2B-it.litertlm"
    private const val CHUNK = 12

    private const val SYSTEM =
        "You are a professional manga translator. " +
        "Translate meaning naturally into casual Indonesian. " +
        "Use natural everyday expressions, not stiff textbook language. " +
        "Preserve names, numbers, sound effects, and original meaning. " +
        "Do not invent missing text. " +
        "Return translations only, preserving the requested numbering."

    private var engine: Engine? = null
    private var enginePath: String? = null

    var backendName: String = "-"
        private set

    data class Result(val lines: List<String>, val mode: String)

    fun findModel(context: Context): File? {
        val dir = context.getExternalFilesDir(null) ?: return null
        val exact = File(dir, MODEL_NAME)
        if (exact.isFile) return exact
        return dir.listFiles()?.firstOrNull {
            it.isFile && it.name.endsWith(".litertlm")
        }
    }

    @Synchronized
    private fun ensureEngine(context: Context, model: File): Engine {
        val path = model.absolutePath
        val cur = engine

        if (cur != null && enginePath == path) return cur

        try {
            cur?.close()
        } catch (_: Throwable) {
        }

        engine = null

        val cache = context.cacheDir.absolutePath

        val created = try {
            val e = Engine(
                EngineConfig(
                    modelPath = path,
                    backend = Backend.GPU(),
                    maxNumTokens = 2048,
                    cacheDir = cache
                )
            )
            e.initialize()
            backendName = "GPU"
            e
        } catch (t: Throwable) {
            val e = Engine(
                EngineConfig(
                    modelPath = path,
                    backend = Backend.CPU(),
                    maxNumTokens = 2048,
                    cacheDir = cache
                )
            )
            e.initialize()
            backendName = "CPU (GPU gagal: ${t.message})"
            e
        }

        engine = created
        enginePath = path
        return created
    }

    private fun clean(raw: String): String {
        var s = raw
            .replace("<end_of_turn>", "")
            .replace("<start_of_turn>", "")
            .replace("<eos>", "")
            .trim()

        if (s.startsWith("```")) {
            s = s.replaceFirst(
                Regex("^```[a-zA-Z]*\\s*"), ""
            ).replaceFirst(
                Regex("\\s*```$"), ""
            ).trim()
        }

        return s
    }

    private fun ask(eng: Engine, prompt: String): String {
        val conv = eng.createConversation(
            ConversationConfig(
                systemInstruction = Contents.of(SYSTEM),
                samplerConfig = SamplerConfig(
                    topK = 40,
                    topP = 0.9,
                    temperature = 0.3,
                    seed = 0
                )
            )
        )

        try {
            val reply = conv.sendMessage(prompt)
            val sb = StringBuilder()

            for (c in reply.contents.contents) {
                if (c is Content.Text) sb.append(c.text)
            }

            return clean(sb.toString())
        } finally {
            conv.close()
        }
    }

    private fun parseNumbered(reply: String, n: Int): List<String>? {
        val re = Regex(
            "^\\s*(?:[-*]\\s*)?(\\d+)\\s*(?:[.):\\-]|\\*\\*)?\\s*(.*)$"
        )

        val map = HashMap<Int, String>()
        var last = -1

        for (line in reply.lines()) {
            val m = re.find(line)

            if (m != null) {
                val num = m.groupValues[1].toIntOrNull() ?: continue

                if (num in 1..n) {
                    last = num
                    map[last] = m.groupValues[2]
                        .trim()
                        .replace(Regex("^\\*\\*|\\*\\*$"), "")
                        .trim()
                }
            } else if (last != -1 && line.isNotBlank()) {
                map[last] = (
                    (map[last] ?: "") + " " + line.trim()
                ).trim()
            }
        }

        for (i in 1..n) {
            if (map[i].isNullOrBlank()) return null
        }

        return (1..n).map { map[it]!! }
    }

    fun translate(
        context: Context,
        model: File,
        lines: List<String>
    ): Result {
        val eng = ensureEngine(context, model)
        val out = ArrayList<String>()
        var mode = "batch"

        for (chunk in lines.chunked(CHUNK)) {
            val prompt = buildString {
                append(
                    "Translate these numbered manga dialogue lines " +
                    "from $SRC to $DST.\n"
                )
                append(
                    "They belong to the same comic page. " +
                    "Use context between lines.\n"
                )
                append(
                    "Return exactly the same numbers, " +
                    "one translation per number. No explanations.\n\n"
                )

                chunk.forEachIndexed { i, s ->
                    append("${i + 1}. $s\n")
                }
            }

            val reply = ask(eng, prompt)
            val parsed = parseNumbered(reply, chunk.size)

            if (parsed != null) {
                out.addAll(parsed)
            } else {
                mode = "batch (format nomor gagal)"

                // Jangan jalankan ulang satu per satu.
                // Simpan hasil batch agar tidak membuang waktu inference.
                out.addAll(chunk.indices.map { i ->
                    chunk.getOrNull(i) ?: ""
                })
            }
        }

        return Result(out, mode)
    }
}
