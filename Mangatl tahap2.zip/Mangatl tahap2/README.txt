MangaTL tahap 2: OCR + terjemahan Gemma (satu prompt bernomor per halaman).
Salin file model gemma-4-E2B-it.litertlm (pakai COPY, bukan Move) ke:
Android/data/com.niven.mangatl/files/
