package com.niven.mangatl

import android.content.MutableContextWrapper
import android.os.Handler
import android.os.Looper
import android.view.ViewGroup
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import java.lang.ref.WeakReference

/**
 * Menyimpan WebView browser login selama app hidup. Keluar browser (Home / Unduhan / Kembali) tidak lagi
 * membuang halaman: masuk lagi ke situs yang sama = lanjut persis di tempat terakhir (tanpa muat ulang).
 * Beda situs / akun Claude / "Masuk akun" dari galat = halaman baru (dimuat ulang seperti biasa).
 * Proses app dimatikan Android = hilang (itu batas wajar, sesi login tetap aman di cookies).
 */
object WebKeeper {
    private var web: WebView? = null
    private var ownerRef: WeakReference<CookiesActivity>? = null

    /** Penanda halaman yang sedang disimpan ("site:<kunci>" atau "claude:<slot>"). */
    var key: String? = null
    /** User-Agent aktif & status mode desktop saat ditinggal. */
    var ua: String? = null
    var desktop = false

    /** true = WebView yang dikembalikan [obtain] adalah simpanan lama (bukan buatan baru). */
    var reused = false
        private set

    val owner: CookiesActivity? get() = ownerRef?.get()
    fun setOwner(a: CookiesActivity?) { ownerRef = a?.let { WeakReference(it) } }

    /** Ambil WebView simpanan (dipasang ke [a]) atau buat baru. */
    fun obtain(a: CookiesActivity): WebView {
        val old = web
        if (old != null) {
            (old.parent as? ViewGroup)?.removeView(old)
            (old.context as? MutableContextWrapper)?.baseContext = a
            old.onResume()
            reused = true
            return old
        }
        reused = false
        key = null
        val w = WebView(MutableContextWrapper(a))
        w.addJavascriptInterface(BlobProxy(), "BunnyBlob")
        w.addJavascriptInterface(ClaudeProxy(), "BunnyClaude")
        web = w
        return w
    }

    /** Dipanggil dari onDestroy activity: lepas WebView dari layar tapi jangan dibuang. */
    fun park(w: WebView) {
        (w.parent as? ViewGroup)?.removeView(w)
        val app = w.context.applicationContext
        (w.context as? MutableContextWrapper)?.baseContext = app
        // video/audio dihentikan supaya tidak bersuara di latar; halaman & posisi tetap
        w.evaluateJavascript("document.querySelectorAll('video,audio').forEach(function(m){try{m.pause()}catch(e){}})", null)
        w.onPause()
        // lepas rujukan ke activity lama
        w.webViewClient = WebViewClient()
        w.webChromeClient = WebChromeClient()
        w.setDownloadListener(null)
    }

    /** Buang WebView simpanan (mis. setelah cookies dihapus). Tidak menyentuh yang sedang tampil. */
    fun drop() {
        Handler(Looper.getMainLooper()).post {
            val w = web ?: return@post
            if (w.parent != null) return@post
            web = null
            key = null
            w.stopLoading()
            w.destroy()
        }
    }

    /** Jembatan JS dipasang sekali per WebView; diteruskan ke activity yang sedang aktif. */
    class BlobProxy {
        @JavascriptInterface fun save(token: String, dataUrl: String) { owner?.bridgeBlobSave(token, dataUrl) }
        @JavascriptInterface fun fail(token: String) { owner?.bridgeBlobFail(token) }
    }

    class ClaudeProxy {
        @JavascriptInterface fun profile(json: String) { owner?.bridgeClaudeProfile(json) }
    }
}
