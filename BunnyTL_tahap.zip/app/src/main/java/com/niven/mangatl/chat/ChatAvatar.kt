package com.niven.mangatl

import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.Toast

// Layar Chat: avatar (buat/lepas model, ukuran, geser bebas/zoom, sentuh) dan saklar bubble chat. Avatar selalu di belakang chat.
// Tombolnya ada di chat.html.
// Fungsi ekstensi dari ChatActivity; keadaan dan siklus hidup layar tetap di ChatActivity.kt.

internal fun ChatActivity.setupAvatar() {
    rootFrame = findViewById(R.id.rootFrame)
    bgHost = findViewById(R.id.bgHost)
    avatarWanted = prefs().getBoolean("avatar_on", true)
    bubblesOn = prefs().getBoolean("chat_bubbles", true)
    prefs().edit().remove("avatar_front").apply()   // sisa pengaturan mode depan (sudah dihapus)
    cfg = loadCfg(prefs().getString("avatar_model", "avatar"))
    // Decode tekstur di thread latar sekarang juga, supaya siap saat layar GL dibuat.
    if (avatarWanted) AvatarTex.prefetch(this, cfg.texturePaths())

    // Ukuran berubah (mis. keyboard) = tinggi avatar dihitung ulang.
    rootFrame.addOnLayoutChangeListener { _, _, _, _, _, _, _, _, _ -> layoutAvatar() }
    rootFrame.touchFilter = { rx, ry -> pokeAllowed(rx, ry) }
    // Keyboard muncul/hilang dideteksi lewat window insets (setupEdgeToEdge di ChatBg.kt).
    applyAvatar()
}

internal fun ChatActivity.toggleAvatar() {
    avatarWanted = !avatarWanted
    prefs().edit().putBoolean("avatar_on", avatarWanted).apply()
    applyAvatar()
    Toast.makeText(this, if (avatarWanted) "Avatar tampil" else "Avatar disembunyikan", Toast.LENGTH_SHORT).show()
}

/** Saklar bubble chat: mati = daftar chat disembunyikan, layar tinggal avatar + kolom input. */
internal fun ChatActivity.toggleBubbles() {
    bubblesOn = !bubblesOn
    prefs().edit().putBoolean("chat_bubbles", bubblesOn).apply()
    pushState()
    Toast.makeText(this, if (bubblesOn) "Bubble chat dinyalakan" else "Bubble chat dimatikan", Toast.LENGTH_SHORT).show()
}

/** Buat tampilan GL untuk model aktif dan pasang di belakang chat. */
internal fun ChatActivity.createAvatar() {
    val v = AvatarView(this, cfg, true)   // latar tembus: latar chat pilihan pengguna terlihat di belakang avatar
    v.anim.levelSource = { Voice.mouthLevel() }
    v.onError = { msg ->
        if (!avatarErrorShown) {
            avatarErrorShown = true
            Toast.makeText(this, "Avatar gagal dimuat: $msg", Toast.LENGTH_LONG).show()
        }
    }
    val lp = FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
    bgHost.addView(v, lp)
    avatar = v
    // Sentuh badan avatar lalu geser = geser bebas, dua jari = zoom. Posisi & ukuran diingat per model.
    rootFrame.target = v
    val tag = MODE_TAG
    val mid = cfg.id
    v.setUserScale(prefs().getFloat("avatar_scale_${mid}_$tag", 1f))
    v.setDrag(prefs().getFloat("avatar_dx_${mid}_$tag", 0f), prefs().getFloat("avatar_dy_${mid}_$tag", 0f))
    rootFrame.onGestureEnd = { x, y, sc ->
        prefs().edit()
            .putFloat("avatar_scale_${mid}_$tag", sc)
            .putFloat("avatar_dx_${mid}_$tag", x)
            .putFloat("avatar_dy_${mid}_$tag", y)
            .apply()
        pushState()
    }
    AvatarTex.prefetch(this, cfg.texturePaths())
    if (uiActive) v.onResume()
}

/** Hancurkan tampilan GL (konteks + tekstur ikut lepas dari memori GPU). */
internal fun ChatActivity.destroyAvatar() {
    val k = avatar ?: return
    rootFrame.target = null
    k.onPause()
    (k.parent as? ViewGroup)?.removeView(k)
    avatar = null
    AvatarTex.prefetch(this, emptyList())   // buang decode yang menggantung
}

internal fun ChatActivity.switchModel(id: String) {
    if (id == cfg.id) return
    prefs().edit().putString("avatar_model", id).apply()
    destroyAvatar()
    cfg = loadCfg(id)
    avatarErrorShown = false
    if (!avatarWanted) {
        avatarWanted = true
        prefs().edit().putBoolean("avatar_on", true).apply()
    }
    applyAvatar()
    Toast.makeText(this, cfg.name, Toast.LENGTH_SHORT).show()
}

// Akhiran kunci SharedPreferences posisi/ukuran. Tetap "b" supaya posisi & ukuran lama yang sudah tersimpan tidak hilang.
private const val MODE_TAG = "b"

internal fun ChatActivity.avatarScale(): Float =
    avatar?.userScale() ?: prefs().getFloat("avatar_scale_${cfg.id}_$MODE_TAG", 1f)

internal fun ChatActivity.setAvatarScale(sc: Float) {
    val k = avatar ?: return
    k.setUserScale(sc)
    prefs().edit().putFloat("avatar_scale_${cfg.id}_$MODE_TAG", k.userScale()).apply()
    pushState()
}

/** Posisi, ukuran, dan batas pudar chat kembali ke bawaan. */
internal fun ChatActivity.resetAvatarView() {
    val tag = MODE_TAG
    avatar?.setUserScale(1f)
    avatar?.setDrag(0f, 0f)
    prefs().edit()
        .remove("avatar_scale_${cfg.id}_$tag").remove("avatar_dx_${cfg.id}_$tag").remove("avatar_dy_${cfg.id}_$tag")
        .remove("chat_top_${cfg.id}").remove("chat_fade_${cfg.id}")
        .apply()
    pushState()
}

/** Batas pudar chat: posisi garis (pecahan tinggi layar) dan panjang pudar (dp). */
internal fun ChatActivity.setChatFade(line: Float, length: Float) {
    prefs().edit()
        .putFloat("chat_top_${cfg.id}", line.coerceIn(0f, 0.85f))
        .putFloat("chat_fade_${cfg.id}", length.coerceIn(0f, 300f))
        .apply()
    pushState()
}

internal fun ChatActivity.applyAvatar() {
    if (avatarWanted && avatar == null) createAvatar()
    if (!avatarWanted && avatar != null) destroyAvatar()

    // Avatar TETAP tampil saat keyboard muncul. Bubble chat disembunyikan oleh halaman (state "kb").
    bgHost.visibility = if (avatarWanted) View.VISIBLE else View.GONE
    layoutAvatar()
    pushState()
}

/** Avatar digambar seukuran layar penuh TANPA keyboard dan menempel di atas. */
internal fun ChatActivity.layoutAvatar() {
    if (rootFrame.height <= 0) return
    lastFullRootH = maxOf(lastFullRootH, rootFrame.height)
    avatar?.setVirtualHeight(lastFullRootH)
    if (bgMw > 0) layoutBg()
}

/** Geser / reaksi sentuh avatar tidak boleh ikut terpicu saat jari mengetuk tombol, kolom input, menu, atau bubble chat. */
internal fun ChatActivity.pokeAllowed(rx: Float, ry: Float): Boolean {
    if (bgEditing) return false
    val l = IntArray(2)
    web.getLocationOnScreen(l)
    val x = rx - l[0]
    val y = ry - l[1]
    val r = hitRects
    var i = 0
    while (i + 4 < r.size) {
        if (x >= r[i] && x <= r[i + 2] && y >= r[i + 1] && y <= r[i + 3]) return false
        i += 5
    }
    return true
}
