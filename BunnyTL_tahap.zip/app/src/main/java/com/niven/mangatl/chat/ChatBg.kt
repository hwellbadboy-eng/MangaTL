package com.niven.mangatl

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.ImageDecoder
import android.graphics.drawable.BitmapDrawable
import android.graphics.drawable.Drawable
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.util.AttributeSet
import android.view.Gravity
import android.view.MotionEvent
import android.view.ScaleGestureDetector
import android.view.SurfaceHolder
import android.view.SurfaceView
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.FrameLayout
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.core.view.ViewCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.lifecycle.lifecycleScope
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

// Layar Chat: (1) layar penuh edge-to-edge (bar status & navigasi transparan, jam/baterai tetap tampil),
// (2) latar chat pilihan pengguna: video (loop, tanpa suara) / GIF (loop) / foto, dengan geser + zoom untuk memilih bagian yang tampil.
// Latar digambar di SurfaceView DI BAWAH avatar (avatar juga SurfaceView/GL), jadi tetap terlihat di belakang avatar & chat.
// Fungsi ekstensi dari ChatActivity; keadaan (bgS, bgFx, bgFy, ...) ada di ChatActivity.kt.

private const val K_KIND = "chat2_bg_kind"   // 1 = video, 2 = foto/GIF
private const val K_FILE = "chat2_bg_file"
private const val K_S = "chat2_bg_s"
private const val K_FX = "chat2_bg_fx"
private const val K_FY = "chat2_bg_fy"

/** SurfaceView latar. Foto/GIF digambar sendiri (GIF diulang tanpa henti); video digambar oleh ExoPlayer. */
class ChatBgSurface @JvmOverloads constructor(c: Context, a: AttributeSet? = null) :
    SurfaceView(c, a), SurfaceHolder.Callback {

    private var d: Drawable? = null
    private var ready = false
    private val h = Handler(Looper.getMainLooper())
    private val tick = object : Runnable {
        override fun run() {
            drawNow()
            if (ready && isAnimated()) h.postDelayed(this, 33)
        }
    }

    init {
        holder.addCallback(this)
    }

    @SuppressLint("NewApi")
    private fun isAnimated() = Build.VERSION.SDK_INT >= 28 && d is android.graphics.drawable.AnimatedImageDrawable

    @SuppressLint("NewApi")
    fun setImage(x: Drawable?) {
        h.removeCallbacks(tick)
        val old = d
        if (Build.VERSION.SDK_INT >= 28 && old is android.graphics.drawable.AnimatedImageDrawable) old.stop()
        d = x
        if (Build.VERSION.SDK_INT >= 28 && x is android.graphics.drawable.AnimatedImageDrawable) {
            x.repeatCount = android.graphics.drawable.AnimatedImageDrawable.REPEAT_INFINITE
            x.start()
        }
        if (ready && x != null) h.post(tick)
    }

    private fun drawNow() {
        val dd = d ?: return
        val canvas = try {
            if (Build.VERSION.SDK_INT >= 26) holder.lockHardwareCanvas() else holder.lockCanvas()
        } catch (_: Throwable) {
            null
        } ?: return
        try {
            canvas.drawColor(Color.BLACK)
            dd.setBounds(0, 0, canvas.width, canvas.height)
            dd.draw(canvas)
        } finally {
            holder.unlockCanvasAndPost(canvas)
        }
    }

    override fun surfaceCreated(holder: SurfaceHolder) {
        ready = true
        if (d != null) h.post(tick)
    }

    override fun surfaceChanged(holder: SurfaceHolder, format: Int, width: Int, height: Int) {
        if (d != null && !isAnimated()) drawNow()
    }

    override fun surfaceDestroyed(holder: SurfaceHolder) {
        ready = false
        h.removeCallbacks(tick)
    }
}

// ------------------------------------------------------------------ layar penuh

internal fun ChatActivity.setupEdgeToEdge() {
    WindowCompat.setDecorFitsSystemWindows(window, false)
    window.statusBarColor = Color.TRANSPARENT
    window.navigationBarColor = Color.TRANSPARENT
    if (Build.VERSION.SDK_INT >= 29) {
        window.isNavigationBarContrastEnforced = false
        window.isStatusBarContrastEnforced = false
    }
    if (Build.VERSION.SDK_INT >= 28) {
        val lp = window.attributes
        lp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        window.attributes = lp
    }
    val ic = WindowCompat.getInsetsController(window, window.decorView)
    ic.isAppearanceLightStatusBars = false      // ikon jam/baterai tetap putih
    ic.isAppearanceLightNavigationBars = false

    ViewCompat.setOnApplyWindowInsetsListener(rootFrame) { _, ins ->
        val bars = ins.getInsets(WindowInsetsCompat.Type.systemBars() or WindowInsetsCompat.Type.displayCutout())
        val ime = ins.getInsets(WindowInsetsCompat.Type.ime())
        val up = ins.isVisible(WindowInsetsCompat.Type.ime())
        insetTop = bars.top
        insetBottom = if (up) 0 else bars.bottom
        // Keyboard muncul = tampilan chat dipendekkan (dulu dikerjakan adjustResize), latar & avatar tetap layar penuh.
        val lp = web.layoutParams as FrameLayout.LayoutParams
        val bm = if (up) ime.bottom else 0
        if (lp.bottomMargin != bm) {
            lp.bottomMargin = bm
            web.layoutParams = lp
        }
        findViewById<View>(R.id.bgEdit).setPadding(0, bars.top, 0, maxOf(bars.bottom, ime.bottom))
        pushInsets()
        if (up != keyboardUp) {
            keyboardUp = up
            applyAvatar()
        }
        ins
    }
    rootFrame.requestApplyInsets()
}

/** Tinggi bar atas/bawah (dp CSS) dikirim ke halaman supaya header & kolom input tidak tertutup jam / tombol navigasi. */
internal fun ChatActivity.pushInsets() {
    val d = resources.displayMetrics.density
    js("insets(${Math.round(insetTop / d)},${Math.round(insetBottom / d)})")
}

// ------------------------------------------------------------------ latar

internal fun ChatActivity.hasBg(): Boolean =
    prefs().getString(K_FILE, null)?.let { File(filesDir, it).exists() } == true

/** Dialog dari menu "Latar chat". */
internal fun ChatActivity.showBgMenu() {
    val items = if (hasBg()) arrayOf("Pilih video / GIF / foto", "Atur posisi & zoom", "Hapus latar")
    else arrayOf("Pilih video / GIF / foto")
    AlertDialog.Builder(this)
        .setTitle("Latar chat")
        .setItems(items) { _, i ->
            when (i) {
                0 -> pickBg.launch(arrayOf("video/*", "image/*"))
                1 -> startBgEdit()
                2 -> clearBg()
            }
        }
        .show()
}

/** File pilihan disalin ke penyimpanan app, jadi tetap jalan walau file aslinya dihapus / dipindah. */
internal fun ChatActivity.importBg(uri: Uri) {
    val mime = contentResolver.getType(uri) ?: ""
    val kind = when {
        mime.startsWith("video/") -> 1
        mime.startsWith("image/") -> 2
        else -> 0
    }
    if (kind == 0) {
        Toast.makeText(this, "Pilih video, GIF, atau foto.", Toast.LENGTH_SHORT).show()
        return
    }
    val ext = when (mime) {
        "image/gif" -> "gif"
        "image/png" -> "png"
        "image/webp" -> "webp"
        "image/jpeg" -> "jpg"
        else -> if (kind == 1) "mp4" else "img"
    }
    lifecycleScope.launch {
        val name = "chat2_bg_${System.currentTimeMillis()}.$ext"
        val ok = withContext(Dispatchers.IO) {
            try {
                contentResolver.openInputStream(uri)?.use { i ->
                    File(filesDir, name).outputStream().use { o -> i.copyTo(o) }
                } != null
            } catch (_: Throwable) {
                false
            }
        }
        if (!ok) {
            Toast.makeText(this@importBg, "File tidak bisa dibuka.", Toast.LENGTH_SHORT).show()
            return@launch
        }
        deleteBgFile()
        prefs().edit().putInt(K_KIND, kind).putString(K_FILE, name)
            .putFloat(K_S, 1f).putFloat(K_FX, 0f).putFloat(K_FY, 0f).apply()
        applyBg(edit = true)   // langsung masuk mode atur posisi
    }
}

private fun ChatActivity.deleteBgFile() {
    prefs().getString(K_FILE, null)?.let { File(filesDir, it).delete() }
}

internal fun ChatActivity.clearBg() {
    if (bgEditing) endBgEdit(false)
    deleteBgFile()
    prefs().edit().remove(K_KIND).remove(K_FILE).remove(K_S).remove(K_FX).remove(K_FY).apply()
    releaseBg()
    bgMw = 0
    bgMh = 0
    Toast.makeText(this, "Latar dihapus", Toast.LENGTH_SHORT).show()
}

/** Pasang latar dari pengaturan tersimpan. edit = true: setelah tampil, langsung buka mode atur posisi. */
internal fun ChatActivity.applyBg(edit: Boolean = false) {
    releaseBg()
    val p = prefs()
    val surf = findViewById<ChatBgSurface>(R.id.bgSurface)
    val f = p.getString(K_FILE, null)?.let { File(filesDir, it) }?.takeIf { it.exists() }
    if (f == null) {
        surf.visibility = View.GONE
        return
    }
    val kind = p.getInt(K_KIND, 0)
    bgS = p.getFloat(K_S, 1f)
    bgFx = p.getFloat(K_FX, 0f)
    bgFy = p.getFloat(K_FY, 0f)
    val gen = ++bgGen
    lifecycleScope.launch {
        if (kind == 2) {
            val d = withContext(Dispatchers.IO) { loadBgImage(f) }
            if (gen != bgGen) return@launch
            if (d == null || d.intrinsicWidth <= 0 || d.intrinsicHeight <= 0) {
                Toast.makeText(this@applyBg, "Gambar latar tidak bisa dibuka.", Toast.LENGTH_SHORT).show()
                return@launch
            }
            bgMw = d.intrinsicWidth
            bgMh = d.intrinsicHeight
            surf.visibility = View.VISIBLE
            layoutBg()
            surf.setImage(d)
        } else {
            val sz = withContext(Dispatchers.IO) { videoSize(f) }
            if (gen != bgGen) return@launch
            if (sz == null) {
                Toast.makeText(this@applyBg, "Video latar tidak bisa dibuka.", Toast.LENGTH_SHORT).show()
                return@launch
            }
            bgMw = sz.first
            bgMh = sz.second
            surf.visibility = View.VISIBLE
            layoutBg()
            val pl = ExoPlayer.Builder(this@applyBg).build()
            pl.trackSelectionParameters = pl.trackSelectionParameters.buildUpon()
                .setTrackTypeDisabled(C.TRACK_TYPE_AUDIO, true)
                .build()
            pl.volume = 0f
            pl.repeatMode = Player.REPEAT_MODE_ONE   // video diulang terus
            pl.setVideoSurfaceView(surf)
            pl.setMediaItem(MediaItem.fromUri(Uri.fromFile(f)))
            pl.prepare()
            pl.playWhenReady = true
            bgPlayer = pl
        }
        if (edit) startBgEdit()
    }
}

internal fun ChatActivity.releaseBg() {
    bgGen++
    bgPlayer?.let {
        it.clearVideoSurface()
        it.release()
    }
    bgPlayer = null
    val surf = findViewById<ChatBgSurface>(R.id.bgSurface)
    surf.setImage(null)
    surf.visibility = View.GONE
}

/** Foto/GIF dikecilkan maksimal 1920 px supaya hemat memori. GIF jalan sebagai animasi (Android 9 ke atas). */
@SuppressLint("NewApi")
private fun ChatActivity.loadBgImage(f: File): Drawable? = try {
    if (Build.VERSION.SDK_INT >= 28) {
        ImageDecoder.decodeDrawable(ImageDecoder.createSource(f)) { dec, info, _ ->
            val w = info.size.width
            val h = info.size.height
            val big = maxOf(w, h)
            if (big > 1920) {
                val r = 1920f / big
                dec.setTargetSize((w * r).toInt().coerceAtLeast(1), (h * r).toInt().coerceAtLeast(1))
            }
        }
    } else {
        val o = BitmapFactory.Options().apply { inSampleSize = 2 }
        BitmapDrawable(resources, BitmapFactory.decodeFile(f.path, o))
    }
} catch (_: Throwable) {
    null
}

private fun videoSize(f: File): Pair<Int, Int>? = try {
    val r = MediaMetadataRetriever()
    try {
        r.setDataSource(f.path)
        var w = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH)?.toIntOrNull() ?: 0
        var h = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT)?.toIntOrNull() ?: 0
        val rot = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_ROTATION)?.toIntOrNull() ?: 0
        if (rot == 90 || rot == 270) {
            val t = w
            w = h
            h = t
        }
        if (w > 0 && h > 0) Pair(w, h) else null
    } finally {
        r.release()
    }
} catch (_: Throwable) {
    null
}

// ------------------------------------------------------------------ posisi & zoom

private fun ChatActivity.screenW() = rootFrame.width.toFloat()
private fun ChatActivity.screenH() = maxOf(rootFrame.height, lastFullRootH).toFloat()

/**
 * Media diskalakan menutup layar penuh (seperti "cover"), lalu skala (zoom) dan geser pengguna dipasang di atasnya.
 * Ukuran dasar tetap; zoom + geser hanya transformasi (ringan, tidak memuat ulang).
 */
internal fun ChatActivity.layoutBg() {
    val surf = findViewById<ChatBgSurface>(R.id.bgSurface)
    val w = screenW()
    val h = screenH()
    if (w <= 0f || h <= 0f || bgMw <= 0 || bgMh <= 0) return
    val cs = maxOf(w / bgMw, h / bgMh)
    val cw = (bgMw * cs).toInt() + 1
    val ch = (bgMh * cs).toInt() + 1
    val lp = surf.layoutParams as FrameLayout.LayoutParams
    if (lp.width != cw || lp.height != ch || lp.gravity != Gravity.CENTER) {
        lp.width = cw
        lp.height = ch
        lp.gravity = Gravity.CENTER
        surf.layoutParams = lp
    }
    // Penyangga gambar dibatasi supaya video lebar tidak memakan memori besar; sisanya diperbesar oleh sistem.
    val cap = minOf(1f, 2560f / maxOf(cw, ch))
    val fw = (cw * cap).toInt().coerceAtLeast(1)
    val fh = (ch * cap).toInt().coerceAtLeast(1)
    if (fw != bgFixW || fh != bgFixH) {
        bgFixW = fw
        bgFixH = fh
        surf.holder.setFixedSize(fw, fh)
    }
    applyBgTransform()
}

internal fun ChatActivity.applyBgTransform() {
    val surf = findViewById<ChatBgSurface>(R.id.bgSurface)
    val w = screenW()
    val h = screenH()
    val cw = surf.layoutParams.width.toFloat()
    val ch = surf.layoutParams.height.toFloat()
    if (w <= 0f || h <= 0f || cw <= 0f || ch <= 0f) return
    bgS = bgS.coerceIn(1f, 4f)
    // Geser dibatasi supaya tepi media tidak pernah masuk ke layar (tidak ada celah hitam).
    val mx = maxOf(0f, (cw * bgS - w) / 2f)
    val my = maxOf(0f, (ch * bgS - h) / 2f)
    val tx = (bgFx * w).coerceIn(-mx, mx)
    val ty = (bgFy * h).coerceIn(-my, my)
    bgFx = tx / w
    bgFy = ty / h
    surf.scaleX = bgS
    surf.scaleY = bgS
    surf.translationX = tx
    surf.translationY = ty
}

internal fun ChatActivity.startBgEdit() {
    if (!hasBg() || bgMw <= 0) return
    bgEditing = true
    rootFrame.target = null          // avatar tidak ikut tergeser / ter-zoom
    web.alpha = 0f                   // bubble & tombol chat disembunyikan sementara
    js("back()")
    findViewById<View>(R.id.bgEdit).visibility = View.VISIBLE
    backCallback.isEnabled = true
}

internal fun ChatActivity.endBgEdit(save: Boolean) {
    bgEditing = false
    findViewById<View>(R.id.bgEdit).visibility = View.GONE
    web.alpha = 1f
    rootFrame.target = avatar
    val p = prefs()
    if (save) {
        p.edit().putFloat(K_S, bgS).putFloat(K_FX, bgFx).putFloat(K_FY, bgFy).apply()
    } else {
        bgS = p.getFloat(K_S, 1f)
        bgFx = p.getFloat(K_FX, 0f)
        bgFy = p.getFloat(K_FY, 0f)
        applyBgTransform()
    }
}

@SuppressLint("ClickableViewAccessibility")
internal fun ChatActivity.setupBgEdit() {
    val edit = findViewById<View>(R.id.bgEdit)
    findViewById<Button>(R.id.btnBgDone).setOnClickListener { endBgEdit(true) }
    findViewById<Button>(R.id.btnBgReset).setOnClickListener {
        bgS = 1f
        bgFx = 0f
        bgFy = 0f
        applyBgTransform()
    }
    val sgd = ScaleGestureDetector(this, object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
        override fun onScale(detector: ScaleGestureDetector): Boolean {
            bgS = (bgS * detector.scaleFactor).coerceIn(1f, 4f)
            applyBgTransform()
            return true
        }
    })
    var lx = 0f
    var ly = 0f
    var n = 0
    edit.setOnTouchListener { _, e ->
        sgd.onTouchEvent(e)
        val skip = if (e.actionMasked == MotionEvent.ACTION_POINTER_UP) e.actionIndex else -1
        var cx = 0f
        var cy = 0f
        var c = 0
        for (i in 0 until e.pointerCount) {
            if (i == skip) continue
            cx += e.getX(i)
            cy += e.getY(i)
            c++
        }
        if (c > 0) {
            cx /= c
            cy /= c
        }
        if (c != n || e.actionMasked == MotionEvent.ACTION_DOWN) {
            n = c
            lx = cx
            ly = cy
        } else if (e.actionMasked == MotionEvent.ACTION_MOVE) {
            val w = screenW()
            val h = screenH()
            if (w > 0f && h > 0f) {
                bgFx += (cx - lx) / w
                bgFy += (cy - ly) / h
                applyBgTransform()
            }
            lx = cx
            ly = cy
        }
        if (e.actionMasked == MotionEvent.ACTION_UP || e.actionMasked == MotionEvent.ACTION_CANCEL) n = 0
        true
    }
}
