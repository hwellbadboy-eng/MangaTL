package com.niven.mangatl

import android.content.Context
import com.google.ai.edge.litertlm.Backend
import com.google.ai.edge.litertlm.Content
import com.google.ai.edge.litertlm.Contents
import com.google.ai.edge.litertlm.Conversation
import com.google.ai.edge.litertlm.ConversationConfig
import com.google.ai.edge.litertlm.Engine
import com.google.ai.edge.litertlm.EngineConfig
import com.google.ai.edge.litertlm.Message
import com.google.ai.edge.litertlm.MessageCallback
import com.google.ai.edge.litertlm.SamplerConfig
import java.io.File
import java.util.concurrent.Semaphore

object Gemma {

    private const val MODEL_NAME = "gemma-4-E2B-it.litertlm"
    private const val CHUNK_MAX_LINES = 8
    private const val CHUNK_MAX_CHARS = 700

    enum class Style(val label: String, val rule: String) {
        AKU_KAMU(
            "Santai (aku/kamu)",
            "Use casual spoken Indonesian with aku/kamu. Do NOT use gue/lo/lu, and never stiff textbook wording."
        ),
        GUE_LO(
            "Gaul (gue/lo)",
            "Use casual Jakarta street slang with gue/lo and natural particles like sih, dong, deh, kok."
        ),
        SOPAN(
            "Sopan (saya/Anda)",
            "Use polite, neutral Indonesian with saya/Anda, still natural and not stiff."
        )
    }

    // Satu model, satu pemakai pada satu waktu (terjemah ATAU chat).
    private val lock = Semaphore(1)

    private var engine: Engine? = null
    private var enginePath: String? = null

    var backendName: String = "-"
        private set

    // Konteks berkelanjutan antar halaman (4 pasang terakhir) + halaman terakhir untuk chat.
    private val history = ArrayList<Pair<String, String>>()

    @Volatile
    var lastPage: List<Pair<String, String>> = emptyList()
        private set

    @Volatile
    private var currentConv: Conversation? = null

    @Volatile
    private var chatCancelled = false

    data class Result(val lines: List<String>, val mode: String)

    fun resetContext() {
        synchronized(history) { history.clear() }
        lastPage = emptyList()
    }

    fun findModel(context: Context): File? {
        val dir = context.getExternalFilesDir(null) ?: return null
        val exact = File(dir, MODEL_NAME)
        if (exact.isFile) return exact
        return dir.listFiles()?.firstOrNull { it.isFile && it.name.endsWith(".litertlm") }
    }

    /** Muat model di latar belakang supaya terjemahan pertama tidak menunggu lama. */
    fun warmUp(context: Context, model: File) {
        ensureEngine(context.applicationContext, model)
    }

    @Synchronized
    private fun ensureEngine(context: Context, model: File): Engine {
        val path = model.absolutePath
        val cur = engine
        if (cur != null && enginePath == path) return cur
        try {
            cur?.close()
        } catch (_: Throwable) {
        }
        engine = null

        val cache = context.cacheDir.absolutePath
        var firstError: Throwable? = null

        // Urutan: GPU konteks besar -> GPU konteks kecil -> CPU
        val attempts = listOf(
            Triple("GPU", true, 4096),
            Triple("GPU", true, 2048),
            Triple("CPU", false, 2048)
        )
        for ((name, gpu, tokens) in attempts) {
            var e: Engine? = null
            try {
                e = Engine(
                    EngineConfig(
                        modelPath = path,
                        backend = if (gpu) Backend.GPU() else Backend.CPU(),
                        maxNumTokens = tokens,
                        cacheDir = cache
                    )
                )
                e.initialize()
                backendName = if (firstError == null) name else "$name (GPU penuh gagal: ${firstError?.message})"
                engine = e
                enginePath = path
                return e
            } catch (t: Throwable) {
                if (firstError == null) firstError = t
                try {
                    e?.close()
                } catch (_: Throwable) {
                }
            }
        }
        throw IllegalStateException("Model gagal dimuat: ${firstError?.message}", firstError)
    }

    // ---------------------------------------------------------------- prompt

    private fun translatorSystem(style: Style, glossary: String): String = buildString {
        append("You are an expert manga and comic localizer. Translate English into natural, native-sounding Indonesian.\n")
        append("Rules:\n")
        append("1. Translate meaning, emotion and intent, never word for word. Idioms, slang, puns and sarcasm must become the Indonesian expression a native would really say, never a literal rendering.\n")
        append("2. Keep each line's emotion: shouting stays punchy with '!', hesitation keeps '...', stutters like 'W-what' become 'A-apa'. Keep the speaker's attitude (teasing, angry, shy, seductive, sarcastic).\n")
        append("3. Sound effects and laughs (HEH, HAHA, GULP, SIGH...) stay short; use Indonesian onomatopoeia when one exists (GULP = GLEK).\n")
        append("4. Keep names, numbers and honorifics unchanged. Do not censor, soften, explain or add anything.\n")
        append("5. ${style.rule}\n")
        append("6. Output plain text only: no markdown, no asterisks, no quotes around the line.\n")
        if (glossary.isNotBlank()) {
            append("Story context and glossary from the user (follow strictly):\n")
            append(glossary.trim().take(600))
            append("\n")
        }
        append("\nExample input:\n[1] W-What, you're going to...\n[2] Heh heh.\n[3] It's raining cats and dogs!\n[4] You're pulling my leg, aren't you?\n")
        append("Example output:\n[1] A-apa, kamu mau...\n[2] Heh heh.\n[3] Hujannya deres banget!\n[4] Kamu lagi ngerjain aku, kan?")
    }

    private const val ANALYST_SYSTEM =
        "You analyze one comic page. Be brief and concrete. Reply with notes only, no preamble."

    private fun analystPrompt(lines: List<String>): String = buildString {
        append("Dialogue lines of one comic page, in reading order:\n")
        lines.forEachIndexed { i, s -> append("[${i + 1}] $s\n") }
        append("\nIn at most 70 words write notes for the translator: (a) the situation and who talks to whom, ")
        append("(b) the emotion/tone of the lines, (c) every idiom, slang, pun, innuendo or double meaning with its REAL intended meaning. ")
        append("If a line is a sound effect, say so.")
    }

    private fun cleanLine(raw: String): String {
        var s = raw
            .replace("<end_of_turn>", "")
            .replace("<start_of_turn>", "")
            .replace("<eos>", "")
            .replace("**", "")
            .trim()
        if (s.startsWith("```")) {
            s = s.replaceFirst(Regex("^```[a-zA-Z]*\\s*"), "").replaceFirst(Regex("\\s*```$"), "").trim()
        }
        s = s.replace(Regex("^(Translation|Terjemahan)\\s*:\\s*", RegexOption.IGNORE_CASE), "")
        if (s.length >= 2 && s.first() == '"' && s.last() == '"') s = s.substring(1, s.length - 1)
        return s.trim()
    }

    private fun textOf(m: Message): String {
        val sb = StringBuilder()
        for (c in m.contents.contents) {
            if (c is Content.Text) sb.append(c.text)
        }
        return sb.toString()
    }

    private fun ask(eng: Engine, system: String, prompt: String, temperature: Double): String {
        val conv = eng.createConversation(
            ConversationConfig(
                systemInstruction = Contents.of(system),
                samplerConfig = SamplerConfig(topK = 40, topP = 0.9, temperature = temperature, seed = 0)
            )
        )
        try {
            val reply = conv.sendMessage(prompt)
            return textOf(reply)
        } finally {
            try {
                conv.close()
            } catch (_: Throwable) {
            }
        }
    }

    /** Baca balasan bernomor [1] ... [2] ...; kembalikan peta nomor -> teks. */
    private fun parseMarked(reply: String): Map<Int, String> {
        val re = Regex("^\\s*(?:\\[(\\d+)]|(\\d+)[.):])\\s*(.*)$")
        val map = HashMap<Int, String>()
        var last = -1
        for (line in reply.lines()) {
            val m = re.find(line)
            if (m != null) {
                val n = (m.groupValues[1].ifEmpty { m.groupValues[2] }).toInt()
                last = n
                map[n] = m.groupValues[3].trim()
            } else if (last != -1 && line.isNotBlank()) {
                map[last] = ((map[last] ?: "") + " " + line.trim()).trim()
            }
        }
        return map
    }

    private fun makeChunks(idxs: List<Int>, prepared: List<String>): List<List<Int>> {
        val chunks = ArrayList<List<Int>>()
        var cur = ArrayList<Int>()
        var chars = 0
        for (i in idxs) {
            val len = prepared[i].length
            if (cur.isNotEmpty() && (cur.size >= CHUNK_MAX_LINES || chars + len > CHUNK_MAX_CHARS)) {
                chunks.add(cur)
                cur = ArrayList()
                chars = 0
            }
            cur.add(i)
            chars += len
        }
        if (cur.isNotEmpty()) chunks.add(cur)
        return chunks
    }

    // ------------------------------------------------------------ terjemahan

    fun translate(
        context: Context,
        model: File,
        lines: List<String>,
        style: Style,
        accurate: Boolean,
        glossary: String,
        onStatus: (String) -> Unit,
        onProgress: (List<String?>) -> Unit
    ): Result {
        val prepared = lines.map { TextUtil.normalizeForModel(it) }
        val out = arrayOfNulls<String>(lines.size)
        val idxs = ArrayList<Int>()
        for (i in lines.indices) {
            if (TextUtil.isTranslatable(prepared[i])) idxs.add(i) else out[i] = lines[i]
        }
        onProgress(out.toList())

        lock.acquire()
        try {
            onStatus("Memuat model...")
            val eng = ensureEngine(context.applicationContext, model)
            val system = translatorSystem(style, glossary)

            // Analisis konteks (hanya mode akurat, dan kalau ada cukup teks)
            var notes = ""
            val totalChars = idxs.sumOf { prepared[it].length }
            if (accurate && idxs.size >= 2 && totalChars >= 40) {
                onStatus("Menganalisis konteks halaman...")
                try {
                    notes = cleanLine(
                        ask(eng, ANALYST_SYSTEM, analystPrompt(idxs.map { prepared[it] }), 0.2)
                    ).take(700)
                } catch (_: Throwable) {
                    notes = ""
                }
            }

            val prev = synchronized(history) { history.toList() }
            val chunks = makeChunks(idxs, prepared)
            var mode = if (notes.isNotBlank()) "akurat" else "cepat"
            var fallbackUsed = false

            chunks.forEachIndexed { ci, chunk ->
                onStatus("Menerjemahkan ${ci + 1}/${chunks.size}...")
                val prompt = buildString {
                    append("Translate these comic lines from English to Indonesian.\n")
                    append("They are consecutive dialogue lines from ONE page, in reading order; a sentence can continue across lines.\n")
                    if (notes.isNotBlank()) append("Page notes (use them for tone and idioms): $notes\n")
                    if (prev.isNotEmpty()) {
                        append("Previous lines, for continuity only (do not translate again):\n")
                        prev.forEach { append("- ${it.first} => ${it.second}\n") }
                    }
                    append("Reply with the same [n] markers, exactly one line per marker, nothing else.\n\n")
                    chunk.forEachIndexed { n, i -> append("[${n + 1}] ${prepared[i]}\n") }
                }
                val parsed = try {
                    parseMarked(ask(eng, system, prompt, 0.3))
                } catch (_: Throwable) {
                    emptyMap()
                }
                chunk.forEachIndexed { n, i ->
                    var t = cleanLine(parsed[n + 1] ?: "")
                    val suspicious = t.isBlank() ||
                        (t.equals(prepared[i], ignoreCase = true) && prepared[i].split(" ").size > 3)
                    if (suspicious) {
                        fallbackUsed = true
                        t = try {
                            cleanLine(
                                ask(
                                    eng, system,
                                    "Translate this comic line from English to Indonesian.\n" +
                                        (if (notes.isNotBlank()) "Page notes: $notes\n" else "") +
                                        "Output ONLY the translation.\n\n${prepared[i]}",
                                    0.3
                                )
                            )
                        } catch (_: Throwable) {
                            ""
                        }
                    }
                    out[i] = if (t.isBlank()) lines[i] else t
                }
                onProgress(out.toList())
            }
            if (fallbackUsed) mode += " + ulang per baris"

            val pairs = lines.indices.map { Pair(lines[it], out[it] ?: lines[it]) }
            lastPage = pairs
            synchronized(history) {
                pairs.filter { TextUtil.isTranslatable(it.first) }
                    .takeLast(4)
                    .forEach { history.add(Pair(it.first.take(120), it.second.take(120))) }
                while (history.size > 4) history.removeAt(0)
            }
            return Result(out.map { it ?: "" }, mode)
        } finally {
            lock.release()
        }
    }

    // ------------------------------------------------------------------ chat

    private fun chatSystem(glossary: String): String = buildString {
        append("Kamu adalah asisten AI yang ramah, pintar, dan jujur. Jawab dalam bahasa Indonesia santai kecuali diminta bahasa lain. ")
        append("Kamu juga ahli penerjemah manga dan komik: kamu bisa menjelaskan makna idiom, slang, emosi dan nuansa dialog, ")
        append("memberi beberapa alternatif terjemahan yang lebih natural, dan membantu memperbaiki terjemahan. ")
        append("Jawab ringkas dan langsung ke inti.\n")
        if (glossary.isNotBlank()) append("Konteks dari pengguna: ${glossary.trim().take(600)}\n")
        val page = lastPage
        if (page.isNotEmpty()) {
            append("\nHalaman manga terakhir yang diterjemahkan (asli => terjemahan):\n")
            var used = 0
            for ((i, p) in page.withIndex()) {
                val line = "${i + 1}. ${p.first.take(200)} => ${p.second.take(200)}\n"
                if (used + line.length > 1800) break
                append(line)
                used += line.length
            }
        }
    }

    private fun sanitizeHistory(hist: List<Pair<Boolean, String>>): List<Message> {
        // Ambil dari belakang sampai batas karakter, lalu pastikan urutan user/model bergantian.
        val picked = ArrayList<Pair<Boolean, String>>()
        var total = 0
        for (h in hist.asReversed()) {
            if (h.second.isBlank()) continue
            if (total + h.second.length > 3500) break
            picked.add(h)
            total += h.second.length
        }
        picked.reverse()
        val clean = ArrayList<Pair<Boolean, String>>()
        for (h in picked) {
            if (clean.isEmpty() && !h.first) continue
            if (clean.isNotEmpty() && clean.last().first == h.first) continue
            clean.add(h)
        }
        if (clean.isNotEmpty() && clean.last().first) clean.removeAt(clean.size - 1)
        return clean.map { if (it.first) Message.user(it.second) else Message.model(it.second) }
    }

    /**
     * Kirim pesan chat dengan streaming. hist = riwayat SEBELUM pesan ini (true = pengguna).
     * onChunk dan onFinish dipanggil dari thread latar belakang.
     */
    fun chat(
        context: Context,
        model: File,
        hist: List<Pair<Boolean, String>>,
        user: String,
        glossary: String,
        onChunk: (String) -> Unit,
        onFinish: (String?) -> Unit
    ) {
        if (!lock.tryAcquire()) {
            onFinish("Model lagi dipakai buat terjemah, tunggu sebentar ya.")
            return
        }
        chatCancelled = false
        Thread {
            var conv: Conversation? = null
            try {
                val eng = ensureEngine(context.applicationContext, model)
                val c = eng.createConversation(
                    ConversationConfig(
                        systemInstruction = Contents.of(chatSystem(glossary)),
                        initialMessages = sanitizeHistory(hist),
                        samplerConfig = SamplerConfig(topK = 40, topP = 0.95, temperature = 0.7, seed = 0)
                    )
                )
                conv = c
                currentConv = c

                fun finish(err: String?) {
                    Thread {
                        try {
                            c.close()
                        } catch (_: Throwable) {
                        }
                        currentConv = null
                        lock.release()
                        onFinish(err)
                    }.start()
                }

                c.sendMessageAsync(user, object : MessageCallback {
                    override fun onMessage(message: Message) {
                        val t = textOf(message)
                            .replace("<end_of_turn>", "")
                            .replace("<start_of_turn>", "")
                            .replace("<eos>", "")
                        if (t.isNotEmpty()) onChunk(t)
                    }

                    override fun onDone() {
                        finish(null)
                    }

                    override fun onError(throwable: Throwable) {
                        finish(
                            if (chatCancelled) null
                            else (throwable.message ?: throwable::class.java.simpleName)
                        )
                    }
                })
            } catch (t: Throwable) {
                try {
                    conv?.close()
                } catch (_: Throwable) {
                }
                currentConv = null
                lock.release()
                onFinish(t.message ?: t::class.java.simpleName)
            }
        }.start()
    }

    fun chatCancel() {
        chatCancelled = true
        try {
            currentConv?.cancelProcess()
        } catch (_: Throwable) {
        }
    }
}
