package com.niven.mangatl

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.os.Bundle
import android.view.Gravity
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import android.widget.Button
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

class ChatActivity : AppCompatActivity() {

    class Msg(val isUser: Boolean, var text: String)

    companion object {
        // Riwayat tetap ada selama app hidup, walau layar chat ditutup lalu dibuka lagi.
        private val store = ArrayList<Msg>()
    }

    private lateinit var list: RecyclerView
    private lateinit var input: EditText
    private lateinit var btnSend: Button
    private lateinit var adapter: MsgAdapter
    private var sending = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_chat)

        list = findViewById(R.id.list)
        input = findViewById(R.id.input)
        btnSend = findViewById(R.id.btnSend)

        adapter = MsgAdapter(store)
        list.layoutManager = LinearLayoutManager(this).apply { stackFromEnd = true }
        list.adapter = adapter
        if (store.isNotEmpty()) list.scrollToPosition(store.size - 1)

        btnSend.setOnClickListener {
            if (sending) {
                Gemma.chatCancel()
            } else {
                val t = input.text.toString().trim()
                if (t.isNotEmpty()) {
                    input.setText("")
                    send(t)
                }
            }
        }

        input.setOnEditorActionListener { _, actionId, _ ->
            if (actionId == EditorInfo.IME_ACTION_SEND) {
                btnSend.performClick()
                true
            } else {
                false
            }
        }

        findViewById<Button>(R.id.btnExplain).setOnClickListener {
            if (sending) return@setOnClickListener
            if (Gemma.lastPage.isEmpty()) {
                Toast.makeText(this, "Terjemahkan satu halaman dulu.", Toast.LENGTH_SHORT).show()
            } else {
                send(
                    "Jelaskan halaman manga yang terakhir tadi: emosi dan nada tiap karakter, " +
                        "idiom/slang/makna tersembunyi yang tidak boleh diterjemahkan harfiah, " +
                        "dan kasih alternatif terjemahan yang lebih natural untuk baris yang menurutmu kurang pas."
                )
            }
        }

        findViewById<Button>(R.id.btnClear).setOnClickListener {
            if (sending) return@setOnClickListener
            store.clear()
            adapter.notifyDataSetChanged()
        }
    }

    private fun send(text: String) {
        val model = Gemma.findModel(this)
        if (model == null) {
            Toast.makeText(this, "Model .litertlm belum ada.", Toast.LENGTH_LONG).show()
            return
        }
        val prefs = getSharedPreferences("mangatl", MODE_PRIVATE)
        val glossary = prefs.getString("glossary", "") ?: ""
        val nick = prefs.getString("nick", "") ?: ""
        val notes = prefs.getString("notes", "") ?: ""

        val hist = store.filter { it.text.isNotBlank() }.map { Pair(it.isUser, it.text) }
        store.add(Msg(true, text))
        val ai = Msg(false, "")
        store.add(ai)
        adapter.notifyItemRangeInserted(store.size - 2, 2)
        list.scrollToPosition(store.size - 1)

        sending = true
        btnSend.text = "Berhenti"

        Gemma.chat(
            this, model, hist, text, glossary, nick, notes,
            onChunk = { chunk ->
                runOnUiThread {
                    ai.text += chunk
                    val pos = store.indexOf(ai)
                    if (pos >= 0) {
                        adapter.notifyItemChanged(pos)
                        list.scrollToPosition(store.size - 1)
                    }
                }
            },
            onFinish = { err ->
                runOnUiThread {
                    sending = false
                    btnSend.text = "Kirim"
                    if (err != null) {
                        ai.text = if (ai.text.isBlank()) "Gagal: $err" else ai.text + "\n\n(Gagal: $err)"
                    } else if (ai.text.isBlank()) {
                        ai.text = "(tidak ada jawaban)"
                    }
                    val pos = store.indexOf(ai)
                    if (pos >= 0) adapter.notifyItemChanged(pos)
                }
            }
        )
    }

    override fun onDestroy() {
        if (sending) Gemma.chatCancel()
        super.onDestroy()
    }

    class MsgAdapter(private val items: List<Msg>) : RecyclerView.Adapter<MsgAdapter.VH>() {

        class VH(v: View) : RecyclerView.ViewHolder(v) {
            val bubble: TextView = v.findViewById(R.id.bubble)
        }

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
            val v = LayoutInflater.from(parent.context).inflate(R.layout.item_msg, parent, false)
            return VH(v)
        }

        override fun getItemCount(): Int = items.size

        override fun onBindViewHolder(holder: VH, position: Int) {
            val m = items[position]
            val b = holder.bubble
            val lp = b.layoutParams as FrameLayout.LayoutParams
            if (m.isUser) {
                lp.gravity = Gravity.END
                b.setBackgroundResource(R.drawable.bubble_user)
                b.setTextColor(0xFFFFFFFF.toInt())
                b.text = m.text
            } else {
                lp.gravity = Gravity.START
                b.setBackgroundResource(R.drawable.bubble_ai)
                b.setTextColor(0xFFE6E0E9.toInt())
                b.text = if (m.text.isEmpty()) "..." else TextUtil.md(m.text)
            }
            b.layoutParams = lp
            b.setOnLongClickListener {
                val cm = b.context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                cm.setPrimaryClip(ClipData.newPlainText("chat", m.text))
                Toast.makeText(b.context, "Disalin", Toast.LENGTH_SHORT).show()
                true
            }
        }
    }
}
