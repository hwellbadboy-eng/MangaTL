package com.niven.mangatl

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.provider.Settings
import androidx.core.content.ContextCompat
import android.net.Uri
import android.os.Bundle
import android.os.SystemClock
import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.google.android.material.materialswitch.MaterialSwitch
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class MainActivity : AppCompatActivity() {

    private lateinit var status: TextView
    private lateinit var result: TextView
    private lateinit var btnPick: Button
    private lateinit var settingsPanel: View
    private lateinit var spStyle: Spinner
    private lateinit var swAccurate: MaterialSwitch
    private lateinit var etGlossary: EditText
    private lateinit var etNick: EditText
    private lateinit var etNotes: EditText

    private var busy = false
    private var lastLines: List<String> = emptyList()
    private var lastTranslations: List<String?> = emptyList()

    private val prefs by lazy { getSharedPreferences("mangatl", MODE_PRIVATE) }

    private val pick = registerForActivityResult(
        ActivityResultContracts.GetContent()
    ) { uri ->
        uri?.let { runOcr(it) }
    }

    private var askedNotif = false

    private val capture = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { r ->
        val d = r.data
        if (r.resultCode == RESULT_OK && d != null) {
            val i = Intent(this, ScreenService::class.java)
                .putExtra("code", r.resultCode)
                .putExtra("data", d)
            ContextCompat.startForegroundService(this, i)
            Toast.makeText(
                this, "Tombol TL aktif. Buka game, lalu ketuk tombol TL.", Toast.LENGTH_LONG
            ).show()
            moveTaskToBack(true)
        } else {
            Toast.makeText(this, "Izin rekam layar ditolak.", Toast.LENGTH_SHORT).show()
        }
    }

    private val notifPerm = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { startGameMode() }

    private fun startGameMode() {
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(
                this, "Aktifkan izin 'Tampil di atas aplikasi lain' untuk BunnyTL, lalu kembali dan tekan lagi.",
                Toast.LENGTH_LONG
            ).show()
            startActivity(
                Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
            )
            return
        }
        if (Build.VERSION.SDK_INT >= 33 && !askedNotif &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            askedNotif = true
            notifPerm.launch(Manifest.permission.POST_NOTIFICATIONS)
            return
        }
        if (Gemma.findModel(this) == null) {
            Toast.makeText(this, "Model .litertlm belum ada, terjemahan tidak akan jalan.", Toast.LENGTH_LONG).show()
        }
        val mpm = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        capture.launch(mpm.createScreenCaptureIntent())
    }

    private fun setupSpinner(sp: Spinner, key: String, labels: List<String>) {
        sp.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, labels)
        sp.setSelection(prefs.getInt(key, 0).coerceIn(0, labels.size - 1))
        sp.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(p: AdapterView<*>?, v: View?, pos: Int, id: Long) {
                prefs.edit().putInt(key, pos).apply()
            }

            override fun onNothingSelected(p: AdapterView<*>?) {}
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        status = findViewById(R.id.status)
        result = findViewById(R.id.result)
        btnPick = findViewById(R.id.btnPick)
        settingsPanel = findViewById(R.id.settingsPanel)
        spStyle = findViewById(R.id.spStyle)
        swAccurate = findViewById(R.id.swAccurate)
        etGlossary = findViewById(R.id.etGlossary)
        etNick = findViewById(R.id.etNick)
        etNotes = findViewById(R.id.etNotes)

        // Pengaturan tersimpan
        val styles = Gemma.Style.values()
        spStyle.adapter = ArrayAdapter(
            this, android.R.layout.simple_spinner_dropdown_item, styles.map { it.label }
        )
        spStyle.setSelection(prefs.getInt("style", 0).coerceIn(0, styles.size - 1))
        spStyle.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(p: AdapterView<*>?, v: View?, pos: Int, id: Long) {
                prefs.edit().putInt("style", pos).apply()
            }

            override fun onNothingSelected(p: AdapterView<*>?) {}
        }
        swAccurate.isChecked = prefs.getBoolean("accurate", true)
        swAccurate.setOnCheckedChangeListener { _, checked ->
            prefs.edit().putBoolean("accurate", checked).apply()
        }
        etGlossary.setText(prefs.getString("glossary", ""))
        etNick.setText(prefs.getString("nick", ""))
        etNotes.setText(prefs.getString("notes", ""))

        btnPick.setOnClickListener {
            if (busy) {
                Toast.makeText(this, "Masih menerjemahkan...", Toast.LENGTH_SHORT).show()
            } else {
                saveGlossary()
                pick.launch("image/*")
            }
        }

        findViewById<Button>(R.id.btnChat).setOnClickListener {
            saveGlossary()
            startActivity(Intent(this, ChatActivity::class.java))
        }

        findViewById<Button>(R.id.btnSettings).setOnClickListener {
            settingsPanel.visibility =
                if (settingsPanel.visibility == View.VISIBLE) View.GONE else View.VISIBLE
        }

        findViewById<Button>(R.id.btnReset).setOnClickListener {
            Gemma.resetContext()
            Toast.makeText(this, "Konteks antar halaman direset.", Toast.LENGTH_SHORT).show()
        }

        findViewById<Button>(R.id.btnCopy).setOnClickListener {
            val text = lastTranslations.mapIndexedNotNull { i, t ->
                if (t == null) null else t.ifBlank { lastLines.getOrElse(i) { "" } }
            }.joinToString("\n")
            if (text.isBlank()) {
                Toast.makeText(this, "Belum ada hasil.", Toast.LENGTH_SHORT).show()
            } else {
                val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                cm.setPrimaryClip(ClipData.newPlainText("terjemahan", text))
                Toast.makeText(this, "Terjemahan disalin.", Toast.LENGTH_SHORT).show()
            }
        }

        setupSpinner(
            findViewById(R.id.spScan), "scan",
            listOf("Mode game: baca seluruh layar", "Mode game: baca setengah bawah", "Mode game: baca sepertiga bawah")
        )
        setupSpinner(
            findViewById(R.id.spPos), "pos",
            listOf("Hasil terjemahan tampil di atas", "Hasil terjemahan tampil di bawah")
        )
        findViewById<Button>(R.id.btnGame).setOnClickListener {
            saveGlossary()
            startGameMode()
        }

        val model = Gemma.findModel(this)
        if (model == null) {
            status.text = "Model belum ada. Salin file .litertlm ke:\n${getExternalFilesDir(null)}"
        } else {
            status.text = "Model ditemukan: ${model.name}. Memuat..."
            // Muat model sejak awal supaya terjemahan pertama langsung cepat.
            Thread {
                try {
                    Gemma.warmUp(applicationContext, model)
                    runOnUiThread {
                        if (!busy) status.text = "Model siap. Backend: ${Gemma.backendName}"
                    }
                } catch (t: Throwable) {
                    runOnUiThread {
                        if (!busy) status.text = "Model gagal dimuat: ${t.message}"
                    }
                }
            }.start()
        }
    }

    override fun onPause() {
        saveGlossary()
        super.onPause()
    }

    private fun saveGlossary() {
        prefs.edit()
            .putString("glossary", etGlossary.text.toString())
            .putString("nick", etNick.text.toString().trim())
            .putString("notes", etNotes.text.toString().trim())
            .apply()
    }

    private fun runOcr(uri: Uri) {
        result.text = ""

        val image = try {
            InputImage.fromFilePath(this, uri)
        } catch (e: Exception) {
            status.text = "Gagal membuka gambar: ${e.message}"
            return
        }

        status.text = "Membaca teks..."
        busy = true

        TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
            .process(image)
            .addOnSuccessListener { text ->
                val items = text.textBlocks.mapNotNull { b ->
                    val box = b.boundingBox
                    val t = b.text.replace("\n", " ").trim()
                    if (box == null || t.isEmpty()) null else Pair(box, t)
                }
                val lines = TextUtil.readingOrder(items)

                if (lines.isEmpty()) {
                    busy = false
                    status.text = "Tidak ada teks terdeteksi."
                    return@addOnSuccessListener
                }

                lastLines = lines
                lastTranslations = emptyList()
                show(lines, List(lines.size) { null })
                translate(lines)
            }
            .addOnFailureListener { e ->
                busy = false
                status.text = "OCR gagal: ${e.message}"
            }
    }

    private fun show(lines: List<String>, tr: List<String?>) {
        result.text = lines.indices.joinToString("\n\n") { i ->
            val t = tr.getOrNull(i)
            "${i + 1}. ${lines[i]}\n    -> ${t ?: "..."}"
        }
    }

    private fun translate(lines: List<String>) {
        val model = Gemma.findModel(this)

        if (model == null) {
            busy = false
            status.text = "Model belum ada. Salin file .litertlm ke:\n${getExternalFilesDir(null)}"
            return
        }

        val style = Gemma.Style.values()[spStyle.selectedItemPosition.coerceIn(0, Gemma.Style.values().size - 1)]
        val accurate = swAccurate.isChecked
        val glossary = etGlossary.text.toString()

        status.text = "Menerjemahkan ${lines.size} blok..."

        lifecycleScope.launch {
            val t0 = SystemClock.elapsedRealtime()

            val res = try {
                withContext(Dispatchers.IO) {
                    Gemma.translate(
                        this@MainActivity, model, lines, style, accurate, glossary,
                        onStatus = { s -> runOnUiThread { status.text = s } },
                        onProgress = { tr ->
                            runOnUiThread {
                                lastTranslations = tr
                                show(lines, tr)
                            }
                        }
                    )
                }
            } catch (t: Throwable) {
                busy = false
                status.text = "Gemma gagal: ${t::class.java.simpleName}: ${t.message}"
                return@launch
            }

            busy = false
            val sec = (SystemClock.elapsedRealtime() - t0) / 1000.0
            lastTranslations = res.lines
            show(lines, res.lines)

            status.text = "Selesai %.1f detik. Mode: %s. Backend: %s".format(
                sec,
                res.mode,
                Gemma.backendName
            )
        }
    }
}
