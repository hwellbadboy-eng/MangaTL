BunnyTL (tahap 3): OCR + terjemahan Gemma (mode akurat, gaya bahasa, glosarium) + Chat AI.
Salin file model gemma-4-E2B-it.litertlm (pakai COPY, bukan Move) ke:
Android/data/com.niven.mangatl/files/
