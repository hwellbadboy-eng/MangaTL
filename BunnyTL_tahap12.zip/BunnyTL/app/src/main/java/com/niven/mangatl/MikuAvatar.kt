package com.niven.mangatl

import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import kotlin.math.PI
import kotlin.math.log10
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sqrt
import kotlin.random.Random

/**
 * Avatar Miku (Live2D) di layar "Sedang diputar", di kotak kanan-bawah tepat di atas ikon suka / titik tiga.
 * Posisinya mengikuti tombol suka (anchor), jadi tidak pernah menimpa ikon, visualizer, atau seekbar.
 * Gerak: ikut ketukan bass lagu (VisTap), goyang pelan sesuai energi, mulut ikut "bernyanyi",
 * diam santai (kedip + napas) saat lagu dijeda. Ketuk avatar = tersipu.
 */
class MikuAvatar(
    private val act: AppCompatActivity,
    private val root: FrameLayout,
    private val anchor: View
) {
    private val cfg: ModelCfg? = try {
        ModelCfg.load(act, "miku")
    } catch (_: Throwable) {
        null
    }
    private val handler = Handler(Looper.getMainLooper())
    private val d = act.resources.displayMetrics.density

    private var view: KarinView? = null
    private var resumed = false
    private var ready = false
    private var suppressed = false
    private var playing = false
    private var failed = false
    private var registered = false

    // analisis audio
    private val buf = FloatArray(1024)
    private var lpState = 0f
    private var bassAvg = 0.02f
    private var lvl = 0f
    private var mouth = 0f
    private var lastPos = 0
    private var lastMove = 0L
    private var lastBeat = 0L
    private var nextHappy = 0L
    private var nextHeart = 0L
    private var taps = 0

    private val readyRun = Runnable {
        ready = true
        applyVisibility()
    }

    private val tickRun = object : Runnable {
        override fun run() {
            if (!resumed) return
            tick()
            handler.postDelayed(this, 33L)
        }
    }

    /** Pasang view di akar layar. Dipanggil sekali dari onCreate setelah layout jadi. */
    fun attach() {
        val c = cfg ?: return
        if (view != null) return
        val v = KarinView(act, c, true)
        v.anim.levelSource = { mouth }
        v.onError = { msg ->
            if (!failed) {
                failed = true
                Toast.makeText(act, "Avatar Miku gagal dimuat: $msg", Toast.LENGTH_LONG).show()
                detach()
            }
        }
        v.visibility = View.INVISIBLE
        v.setOnTouchListener { _, e ->
            if (e.actionMasked == MotionEvent.ACTION_UP) onTap()
            true
        }
        root.addView(v, FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.TOP or Gravity.START))
        view = v
        KarinTex.prefetch(act, c.texturePaths())
        val l = View.OnLayoutChangeListener { _, _, _, _, _, _, _, _, _ -> relayout() }
        anchor.addOnLayoutChangeListener(l)
        root.addOnLayoutChangeListener(l)
        relayout()
        if (resumed) v.onResume()
    }

    private fun detach() {
        val v = view ?: return
        v.onPause()
        root.removeView(v)
        view = null
        KarinTex.prefetch(act, emptyList())
    }

    /** Kotak avatar: ~196dp x 100dp, rapat kanan, dasarnya tepat di atas tombol suka. */
    private fun relayout() {
        val v = view ?: return
        if (anchor.height <= 0 || root.width <= 0) return
        val rl = IntArray(2)
        val al = IntArray(2)
        root.getLocationOnScreen(rl)
        anchor.getLocationOnScreen(al)
        val w = min((196 * d).toInt(), (root.width * 0.49f).toInt())
        val h = (100 * d).toInt()
        val right = root.width - (8 * d).toInt()
        val left = right - w
        val top = (al[1] - rl[1]) - h
        val lp = v.layoutParams as FrameLayout.LayoutParams
        if (lp.width != w || lp.height != h || lp.leftMargin != left || lp.topMargin != top) {
            lp.width = w
            lp.height = h
            lp.leftMargin = left
            lp.topMargin = top
            v.layoutParams = lp
            v.setFadeBottom((h * 0.32f).toInt())
        }
    }

    fun onResume() {
        resumed = true
        view?.onResume()
        registerTap(true)
        relayout()
        lastMove = SystemClock.uptimeMillis()
        val now = lastMove
        nextHappy = now + 8000L + Random.nextLong(8000L)
        nextHeart = now + 30000L + Random.nextLong(30000L)
        handler.removeCallbacks(tickRun)
        handler.post(tickRun)
        if (!ready) {
            // tunggu animasi masuk layar selesai: permukaan GL tidak ikut bergeser bersama jendela
            handler.removeCallbacks(readyRun)
            handler.postDelayed(readyRun, 380L)
        }
        applyVisibility()
    }

    fun onPause() {
        resumed = false
        handler.removeCallbacks(tickRun)
        handler.removeCallbacks(readyRun)
        ready = false
        registerTap(false)
        view?.visibility = View.INVISIBLE
        view?.onPause()
    }

    fun onDestroy() {
        onPause()
        detach()
    }

    fun setPlaying(p: Boolean) {
        if (p == playing) return
        playing = p
        val a = view?.anim ?: return
        if (p) a.happy(1.2f)
    }

    /** true = sembunyikan (popup efek terbuka di atasnya; permukaan GL ada di atas semua view biasa). */
    fun setSuppressed(s: Boolean) {
        suppressed = s
        applyVisibility()
    }

    /** Lagu ganti: sapaan kecil. */
    fun onTrackChanged() {
        val a = view?.anim ?: return
        a.poke("pat", 0.7f)
        a.happy(1.5f)
    }

    private fun applyVisibility() {
        val v = view ?: return
        v.visibility = if (resumed && ready && !suppressed && !failed) View.VISIBLE else View.INVISIBLE
    }

    private fun registerTap(on: Boolean) {
        if (on == registered) return
        registered = on
        if (on) {
            VisTap.viewers++
            VisTap.forced = true
        } else {
            VisTap.viewers = max(0, VisTap.viewers - 1)
            VisTap.forced = false
        }
    }

    private fun onTap() {
        val a = view?.anim ?: return
        taps++
        a.poke("pat", 1f)
        if (taps % 4 == 0) a.triggerExpr("heartEyes", 3.5f) else a.triggerExpr("blush", 3f)
    }

    private fun tick() {
        val a = view?.anim ?: return
        val now = SystemClock.uptimeMillis()
        val pos = VisTap.pos
        if (pos != lastPos) {
            lastPos = pos
            lastMove = now
        }
        val live = playing && now - lastMove < 300L
        if (live) {
            VisTap.read(buf, buf.size, 2, AudioEngine.meterBufferMs)
            val k = min(1f, (2.0 * PI * 150.0 / VisTap.sampleRate).toFloat())
            var s = 0f
            var sb = 0f
            var y = lpState
            for (x in buf) {
                y += k * (x - y)
                s += x * x
                sb += y * y
            }
            lpState = y
            val rms = sqrt(s / buf.size)
            val bass = sqrt(sb / buf.size)
            val db = 20f * log10(rms + 1e-6f)
            val lv = ((db + 54f) / 40f).coerceIn(0f, 1f)
            lvl += (lv - lvl) * 0.25f
            bassAvg += (bass - bassAvg) * 0.02f
            val ratio = bass / (bassAvg + 0.005f)
            if (ratio > 1.35f && bass > 0.02f && now - lastBeat > 280L) {
                lastBeat = now
                a.poke("beat", ((ratio - 1f) * 1.2f).coerceIn(0.4f, 1.4f))
            }
        } else {
            lvl *= 0.9f
        }
        mouth = if (playing) ((lvl - 0.35f) * 1.6f).coerceIn(0f, 0.7f) else 0f
        a.state = if (playing) KarinState.SPEAKING else KarinState.IDLE
        a.sway = if (playing) 0.25f + 0.75f * lvl else 0f
        a.joy = if (playing) 0.35f + 0.65f * lvl else 0f
        if (playing) {
            if (now > nextHappy) {
                a.happy(2f)
                nextHappy = now + 14000L + Random.nextLong(14000L)
            }
            if (now > nextHeart) {
                a.triggerExpr("heartEyes", 3.5f)
                nextHeart = now + 45000L + Random.nextLong(30000L)
            }
        }
    }
}
