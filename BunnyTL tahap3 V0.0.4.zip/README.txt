BunnyTL: OCR + terjemahan AI offline (mode akurat, gaya bahasa, glosarium) + Chat AI.

Mesin AI bisa diganti-ganti. Taruh tiap model di foldernya sendiri (COPY, bukan Move):
Android/data/com.niven.mangatl/files/
    Ai 1/gemma-4-E2B-it.litertlm
    Ai 2/Qwen3.5-4B_mixed_int4.litertlm
    Ai 3/...

Nama folder bebas. File .litertlm langsung di folder files/ juga tetap terbaca.
Pilih mesin di menu Opsi > "Mesin AI". Pilihan tersimpan dan berlaku untuk
terjemah, mode game, dan Chat.
