package com.niven.mangatl

import android.content.Context
import android.util.TypedValue
import android.view.View
import android.widget.ImageButton
import android.widget.LinearLayout
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView
import androidx.appcompat.app.AlertDialog
import com.google.android.material.materialswitch.MaterialSwitch

/** Pembantu UI untuk dialog pengaturan & urutkan. */
object Ui {
    fun dp(ctx: Context, v: Int) = (v * ctx.resources.displayMetrics.density).toInt()

    fun box(ctx: Context) = LinearLayout(ctx).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(ctx, 20), dp(ctx, 12), dp(ctx, 20), dp(ctx, 8))
    }

    fun scroll(v: View) = ScrollView(v.context).apply { addView(v) }

    fun section(ctx: Context, text: String) = TextView(ctx).apply {
        this.text = text
        textSize = 13f
        alpha = 0.7f
        setPadding(0, dp(ctx, 14), 0, dp(ctx, 4))
    }

    fun switchRow(ctx: Context, text: String, checked: Boolean, onChange: (Boolean) -> Unit) =
        MaterialSwitch(ctx).apply {
            this.text = text
            isChecked = checked
            setOnCheckedChangeListener { _, v -> onChange(v) }
        }

    fun radios(ctx: Context, labels: List<String>, selected: Int, onPick: (Int) -> Unit): RadioGroup {
        val g = RadioGroup(ctx)
        labels.forEachIndexed { i, l ->
            val rb = RadioButton(ctx)
            rb.id = View.generateViewId()
            rb.text = l
            g.addView(rb)
            if (i == selected) rb.isChecked = true
        }
        g.setOnCheckedChangeListener { grp, checkedId ->
            val idx = (0 until grp.childCount).indexOfFirst { grp.getChildAt(it).id == checkedId }
            if (idx >= 0) onPick(idx)
        }
        return g
    }

    fun iconBtn(ctx: Context, res: Int, desc: String, onClick: () -> Unit): ImageButton {
        val b = ImageButton(ctx)
        b.setImageResource(res)
        b.contentDescription = desc
        val tv = TypedValue()
        ctx.theme.resolveAttribute(android.R.attr.selectableItemBackgroundBorderless, tv, true)
        b.setBackgroundResource(tv.resourceId)
        b.setOnClickListener { onClick() }
        return b
    }

    // ----- urutkan -----
    val SORT_VIDEO = arrayOf(
        "Nama (A–Z)", "Nama (Z–A)", "Tanggal (terbaru)", "Tanggal (terlama)",
        "Ukuran (terbesar)", "Ukuran (terkecil)"
    )
    val SORT_MUSIC = arrayOf(
        "Nama (A–Z)", "Nama (Z–A)", "Tanggal ditambah (terbaru)", "Tanggal ditambah (terlama)",
        "Durasi (terpanjang)", "Durasi (terpendek)"
    )

    fun sortDialog(ctx: Context, labels: Array<String>, current: Int, onPick: (Int) -> Unit) {
        AlertDialog.Builder(ctx)
            .setTitle("Urutkan")
            .setSingleChoiceItems(labels, current) { d, w ->
                onPick(w)
                d.dismiss()
            }
            .show()
    }

    /** mode: 0 nama A-Z, 1 nama Z-A, 2 tanggal terbaru, 3 tanggal terlama, 4 besar->kecil, 5 kecil->besar */
    fun <T> sortBy(list: List<T>, mode: Int, name: (T) -> String, date: (T) -> Long, big: (T) -> Long): List<T> =
        when (mode) {
            0 -> list.sortedBy { name(it).lowercase() }
            1 -> list.sortedByDescending { name(it).lowercase() }
            2 -> list.sortedByDescending { date(it) }
            3 -> list.sortedBy { date(it) }
            4 -> list.sortedByDescending { big(it) }
            else -> list.sortedBy { big(it) }
        }
}

/** Pengaturan subtitle (dipakai di dalam pemutar, berlaku langsung, dan di pengaturan video). */
object SubtitleSettings {
    fun addTo(ctx: Context, box: LinearLayout, onChange: () -> Unit) {
        box.addView(Ui.section(ctx, "Subtitle"))
        addToPlain(ctx, box, onChange)
    }

    /** Sama seperti addTo, tanpa judul bagian. */
    fun addToPlain(ctx: Context, box: LinearLayout, onChange: () -> Unit) {
        box.addView(Ui.switchRow(ctx, "Latar hitam di belakang teks", Prefs.subBg(ctx)) {
            Prefs.setBool(ctx, "sub_bg", it)
            onChange()
        })
        val label = TextView(ctx).apply {
            text = "Ukuran: ${Prefs.subSize(ctx)}%"
            setPadding(0, Ui.dp(ctx, 10), 0, 0)
        }
        val bar = SeekBar(ctx).apply {
            max = 200 // 50%..250%
            progress = Prefs.subSize(ctx) - 50
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                    label.text = "Ukuran: ${p + 50}%"
                    if (fromUser) {
                        Prefs.setInt(ctx, "sub_size", p + 50)
                        onChange()
                    }
                }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {}
            })
        }
        box.addView(label)
        box.addView(bar)
    }

    fun show(ctx: Context, onChange: () -> Unit) {
        val box = Ui.box(ctx)
        addTo(ctx, box, onChange)
        AlertDialog.Builder(ctx)
            .setTitle("Pengaturan subtitle")
            .setView(Ui.scroll(box))
            .setPositiveButton("Tutup", null)
            .show()
    }
}

/** Pengaturan video: ada di dalam layar Video. */
object VideoSettings {
    fun show(ctx: Context, onDone: () -> Unit) {
        val box = Ui.box(ctx)
        box.addView(Ui.section(ctx, "Decoder (untuk MKV dan codec yang gagal diputar)"))
        box.addView(
            Ui.radios(
                ctx,
                listOf(
                    "Otomatis (pakai FFmpeg kalau decoder HP gagal)",
                    "Utamakan FFmpeg (software, lebih berat)",
                    "Hanya decoder bawaan HP"
                ),
                Prefs.decoder(ctx)
            ) { Prefs.setInt(ctx, "decoder", it) }
        )
        val secs = listOf(5, 10, 15, 30)
        box.addView(Ui.section(ctx, "Lompat saat ketuk dua kali"))
        box.addView(
            Ui.radios(ctx, secs.map { "$it detik" }, secs.indexOf(Prefs.seekSec(ctx)).coerceAtLeast(0)) {
                Prefs.setInt(ctx, "seek_sec", secs[it])
            }
        )
        box.addView(Ui.section(ctx, "Pemutar"))
        box.addView(Ui.switchRow(ctx, "Geser untuk kecerahan & volume", Prefs.gestures(ctx)) {
            Prefs.setBool(ctx, "gestures", it)
        })
        box.addView(Ui.switchRow(ctx, "Ingat posisi terakhir", Prefs.resume(ctx)) {
            Prefs.setBool(ctx, "resume", it)
        })
        SubtitleSettings.addTo(ctx, box) { }
        box.addView(Ui.section(ctx, "Daftar folder"))
        box.addView(Ui.switchRow(ctx, "Thumbnail bergantian antar frame (hemat, hanya yang terlihat)", Prefs.thumbAnim(ctx)) {
            Prefs.setBool(ctx, "thumb_anim", it)
        })
        box.addView(Ui.switchRow(ctx, "Thumbnail 4 kotak di tiap folder", Prefs.mosaic(ctx)) {
            Prefs.setBool(ctx, "mosaic", it)
        })
        AlertDialog.Builder(ctx)
            .setTitle("Pengaturan video")
            .setView(Ui.scroll(box))
            .setPositiveButton("Tutup", null)
            .setOnDismissListener { onDone() }
            .show()
    }
}
