Tahap 4 (audit Audio Engine): reset state semua efek (Bass, Vokal, Stereo, Crossfeed, Kompresor, Reverb, oversampler) saat flush/seek/ganti lagu/configure; Limiter: puncak akhir <= Ceiling meski Output Gain > 0 dB (juga setelah resample/dither); kuantisasi 16/24-bit simetris (masuk=keluar tanpa efek identik); NaN/Inf dibuang di masukan dan efek yang meledak direset; mono diproses (keluar stereo dual-mono), multikanal dilewati dengan status di layar Audio Engine; normalisasi memakai true peak (cache lama dianalisis ulang) dan mode dinamis memakai PeakGuard lookahead; jalur kering/linear Bass & Vokal ditunda 15 sampel saat oversampling aktif; bit-perfect hanya dianggap aktif bila jalurnya tersedia; badge Hi-Res menampilkan format keluaran aktual. Tes host: tools/dsp_selftest/run.sh.
Avatar Miku (b): fitur "Avatar Miku" di Audio Engine (AudioEngine.AVATAR): Size %, Position X/Y dp, Bottom Fade %, Follow Music, plus saklar on/off. Di pemutar: tahan lama Miku lalu geser = pindah, cubit = besar/kecil, ketuk = tersipu; hasil gesture langsung tersimpan ke pengaturan itu. Tidak dihitung di "N aktif" tab Efek.
Avatar Miku: Miku (Live2D) badan penuh di layar Sedang diputar, kotak kanan-bawah, digambar DI BAWAH ikon suka/titik tiga/visualizer/seekbar (KarinTexView = TextureView, disisipkan sebelum bottomBox; MikuAvatar.kt). Model di assets/models/miku (tekstur 4096->2048, latar disembunyikan via "hideParts", tidak didaftarkan di index.json). Semua fitur dipakai: tangan gantian tiap 7-16 dtk (kosong / kipas buka / kipas dilipat jadi kuas), rok tipis, dada berdenyut di ketukan keras, mata hati, air mata (saat dijeda >6 dtk), taring atas/bawah, pipi, mulut, mata ^_^, anggukan halus terkunci ke tempo lagu (fase kontinu + PLL, bukan sentakan per ketukan), goyang, fisika rambut, motion Standby. Ketuk Miku = tersipu/mata hati. VisTap.forced: sampel audio disalin walau Visualizer mati. Default Visualizer: Height 33.9, Width 43.6, Position X 100, Position Y 81.2, Bar Spacing 35.8 (tekan "Reset fitur").
Tahap 11: pratinjau Visualizer di pengaturan: data tiruan (demoFill) dibuang, sekarang selalu audio asli (putar musik untuk melihat efek Sensitivity, Smoothing, dll). Pratinjau bisa di-zoom: cubit dua jari atau ketuk dua kali (zoom 1x-8x), seret satu jari untuk geser. Area pratinjau selebar layar.
Tahap 10b: perbaikan Visualizer di layar Sedang diputar. Penyebab blok kontrol naik 74dp dan posisi visualizer beda dari pratinjau: visHost.bringToFront() di LinearLayout memindahkan visHost ke dasar urutan anak (di bawah tab). Sekarang visHost tetap di slotnya (di atas baris Hi-Res), digambar paling atas lewat translationZ, dan bottomBox.clipToPadding=false supaya geser X/Y tidak terpotong. Pratinjau di AudioFeatureActivity disesuaikan dengan layout baru (baris kelinci 126dp). Setelah update tekan "Reset fitur" di pengaturan Visualizer, karena nilai Posisi lama dipakai untuk mengimbangi bug.
Tahap 10: kontrol pemutar kelinci di layar Sedang diputar. Prev/Play/Next diganti WebView (BunnyWebView.kt + assets/bunny/bunny_player.html), animasi sama dengan bunny_player_v4. Tombol lama di layout disembunyikan (visibility gone) supaya kode lama tetap jalan. Padding bawah memakai inset systemBars (tanpa IME); log tag "NowPlayingInset".
Tahap 9: editor video: pilihan ukuran video (Asli, 9:16, 16:9, 1:1, 4:5) muncul di awal dan lewat tombol Ukuran, klip utama bisa Pas layar atau Penuh; dialog Atur lagu dihapus dan tombol Potong dihapus. Semua dipotong lewat handle di ujung klip pada timeline (lagu, video utama, lapisan). Timeline bisa di-zoom (cubit dua jari atau tombol - dan +) dengan penggaris waktu, geser dengan dua jari atau seret penggaris. Lagu bisa dipisah, digeser, dihapus per potongan. Lapisan video/foto bisa ditumpuk di atas video utama (tombol Lapisan): tiap lapisan satu baris, geser/ubah ukuran langsung di pratinjau, tombol Pas layar, Penuh, Tengah, Maju, Mundur. Suara video lapisan dimatikan, kecepatan lapisan belum ada. Kurva pudar (awal dan akhir) untuk video utama, lapisan, dan lagu: lingkaran di atas = panjang pudar, titik di garis kurva = lekuk (tarik bebas). Tema hitam pekat (#000000).
Tahap 8: layar Manga Translator dirapikan minimalis: bahasa asli jadi tombol sejajar, kartu Tampilan teks (Font, Gaya huruf + saklar miring di dalam popup), contoh font cuma "contoh text", daftar hasil ringkas, menu hasil bergaya popup baru.

Tahap 7: editor video: video/foto baru disisipkan di posisi garis putih (klip dipecah otomatis), tombol Geser kiri/kanan untuk mengatur urutan, Potong (atur mulai-sampai bebas per klip), lagu bisa diatur mulai di mana dan bagian mana yang dipakai.

Tahap 6: pilih banyak lagu/video sekaligus (tahan lama > Pilih), lalu Pindahkan atau Hapus massal lewat bilah di bawah. Izin sistem diminta sekali untuk semua file.

Tahap 5: popup baru bergaya minimalis (Pilih mesin AI, menu lagu, menu video, ganti nama, pindah folder, edit info lagu, hapus). Menu tahan-lama video: Edit video, Ganti nama, Pindahkan ke folder, Hapus. Editor video baru (VideoEditActivity): pisah, hapus bagian, kecepatan 0,25x-4x, sambung video/foto, tambah lagu, simpan mengikuti resolusi+bitrate asli.

Tahap 4b (samakan dengan referensi): kartu Terjemah layar lebih sempit (weight 0,64 : 1), header utama "Mesin AI mati", Musik: header ikut tergeser saat scroll (AppBarLayout), tab rata kiri, tinggi banner dikurangi (221dp + status bar). Cover tetap 48dp. Saklar kartu bawah tidak terpotong lagi. Musik: ikon urut+pengaturan gaya outline, banner 250dp, parallax saat scroll. Kartu Mesin AI hanya menampilkan nama inti model (mis. gemma-4-E4B-it).

BunnyTL: OCR + terjemahan AI offline (mode akurat, gaya bahasa, glosarium) + Chat AI.

Mesin AI bisa diganti-ganti. Taruh tiap model di foldernya sendiri (COPY, bukan Move):
Android/data/com.niven.mangatl/files/
    Ai 1/gemma-4-E2B-it.litertlm
    Ai 2/Qwen3.5-4B_mixed_int4.litertlm
    Ai 3/...

Nama folder bebas. File .litertlm langsung di folder files/ juga tetap terbaca.
Pilih mesin di menu Opsi > "Mesin AI". Pilihan tersimpan dan berlaku untuk
terjemah, mode game, dan Chat.

Cache: tiap mesin AI punya folder cache sendiri bernama "_cache" di dalam foldernya
(mis. Ai 1/_cache). Aman dihapus kalau mau; nanti dibuat ulang otomatis.

Chat suara: tombol "Mic" di layar Chat. Ketuk, bicara (bahasa Indonesia), jawaban terkirim otomatis.
Ketuk lagi untuk membatalkan. Untuk offline, pasang paket suara Indonesia di
Pengaturan HP > Google > pengenalan suara / Speech Services.

Suara AI (keluar), 100% offline: model Supertonic 3 (sherpa-onnx).
1. Unduh sherpa-onnx-supertonic-3-tts-int8-2026-05-11.tar.bz2 dari
   github.com/k2-fsa/sherpa-onnx/releases/tag/tts-models, lalu ekstrak.
2. Salin folder hasil ekstrak (isi: voice.bin, tts.json, unicode_indexer.bin,
   dan 4 file .onnx) ke Android/data/com.niven.mangatl/files/Suara 1/
3. Opsi > "Suara AI": pilih model suara, pilih Suara 1-6 (1-5 cewek, 6 cowok), tekan "Tes suara".
   Suara 1-5 biasanya cewek (urutan perkiraan, dengar sendiri). 
4. Di Chat: tombol "Suara: mati/nyala" = AI membacakan setiap jawaban.
   Ketuk balon jawaban untuk membacakan satu pesan.
Catatan build: build.yml mengunduh sherpa-onnx-2.0.1.aar ke app/libs/ saat build.

Tahap 4 (mode game lebih cepat):
- Terjemah layar memakai prompt pendek + streaming: hasil muncul bertahap, dialog utama (teks terpanjang) paling dulu.
- Cache per baris di memori: teks yang sama (menu, tombol, dialog berulang) langsung tampil tanpa memanggil model.
  Tombol Reset mengosongkan cache ini.
- Backend (GPU/CPU) yang berhasil diingat per model, jadi muat berikutnya tidak mencoba ulang yang gagal.
- Opsi: slider opasitas kotak terjemahan, dan pilihan ketuk saat hasil tampil
  (tutup + langsung terjemah layar berikutnya, atau cuma tutup).

Tahap 5 (suara ikut teks):
- Chat: suara AI sekarang streaming. Tiap kalimat dibacakan begitu muncul di layar, tidak menunggu jawaban selesai.
- Model suara dimuat saat pesan dikirim (selagi AI mikir), jadi kalimat pertama langsung bunyi.
- Tombol "Berhenti" ikut menghentikan suara.

Tahap 5b:
- Mode LIVE ngobrol: TAHAN tombol Mic. Dengar -> AI jawab bersuara -> dengar lagi otomatis, terus sampai
  Mic diketuk atau "Berhenti" ditekan. Jawaban di mode live dibuat singkat (1-3 kalimat).
- Mic tetap full offline (pengenal on-device); jeda diam dilonggarkan.
- Suara lebih cepat: model dimuat sejak layar Chat dibuka, potongan pertama boleh berhenti di koma, langkah
  generate suara dikurangi (3 untuk potongan pertama, 4 untuk sisanya).

Tahap 5c (perbaikan kualitas suara):
- Langkah generate suara dinaikkan jadi 6 untuk semua potongan (sebelumnya 3/4 = mendem & cempreng, kualitas tiap potongan beda).
- Potongan teks minimal ~28 karakter (sebelumnya 10), sisa potongan pendek digabung, intonasi akhir ditambah tanda baca.
- Pasca-proses: cegah clipping, volume antar potongan disamakan, fade anti-klik, jeda awal 150 ms supaya kata pertama tidak terpotong.
- Kalau masih terlalu tajam: di Voice.kt ubah TAME_TREBLE = true (redam treble). Kalau mau lebih cepat: turunkan STEPS ke 5.
- Saran: pakai model fp32 (bukan int8) kalau ada; int8 sedikit lebih kasar.

Tahap 6 (suara kadang mendem/cempreng):
- Pemutaran menunggu 2 potongan siap dulu (PREBUFFER_CHUNKS) supaya tidak putus kalau pembuatan suara kalah cepat dari pemutaran.
- Jenis audio diganti dari SPEECH ke MUSIC: beberapa HP memasang filter "suara bicara" yang bikin kadang mendem/cempreng.
- Teks dibersihkan lebih banyak (simbol, kutip, singkatan gk/yg/dgn).
- Logcat tag "BunnyVoice" mencatat waktu bikin vs durasi tiap potongan (untuk diagnosa).
- Potongan teks dibatasi MAX_CHUNK = 120 huruf (sebelumnya 220) karena teks panjang bikin suara mendem/cempreng.
- Seimbangkan kecepatan vs kualitas: STEPS 5, PREBUFFER_CHUNKS 1, MIN_CHUNK 24, SPEED 1.05 (suara tidak terlalu ketinggalan dari teks).
- Potongan pertama langsung dibacakan begitu >= 30 huruf (FIRST_FORCE), tanpa nunggu titik/koma, supaya suara mulai bareng teks.
- Awal cepat, belakang natural: potongan pertama 5 langkah (STEPS_FIRST), sisanya 6 langkah (STEPS). Potongan yang terpotong di tengah kalimat diakhiri koma supaya intonasi nyambung.

Tahap 6b: pengaturan "Kecepatan mulai suara" di Opsi (di bawah pilihan Suara 1-6):
- Cepat: suara mulai paling awal (potongan pertama ~24 huruf), risiko agak kasar.
- Seimbang (default): awal cepat, bagian belakang lebih natural.
- Natural: paling jernih, suara mulai agak telat.
Pilihan berlaku untuk suara berikutnya, tidak perlu restart.

Tahap 6c: slider "Jeda koma" dan "Jeda titik" (0-600 ms) di Opsi, di atas tombol Tes suara.
- Jeda dipasang di tiap pergantian potongan. Koma sekarang ikut jadi titik potong (setelah ~28-40 huruf tergantung mode).
- Koma di kalimat pendek (dalam satu potongan) tetap diatur model suara.
- Default: koma 90 ms, titik 90 ms (= suara sebelumnya). Tombol "Kembalikan ke default" mengembalikan mode kecepatan + dua jeda. Potongan yang terpotong di tengah frasa pakai jeda tetap 40 ms.

Tahap 7: Mic offline Whisper (jauh lebih akurat dari pengenal bawaan HP).
1. Unduh sherpa-onnx-whisper-small.tar.bz2 (lebih akurat, ~350 MB) atau sherpa-onnx-whisper-base (lebih cepat, ~150 MB)
   dari github.com/k2-fsa/sherpa-onnx/releases/tag/asr-models, lalu ekstrak.
2. Salin folder hasil ekstrak (isi: *-encoder*.onnx, *-decoder*.onnx, *-tokens.txt) ke
   Android/data/com.niven.mangatl/files/Whisper/   (nama folder bebas).
3. Selesai. Kalau folder ini ada, tombol Mic otomatis pakai Whisper. Kalau belum ada / Whisper error, otomatis pakai mic bawaan.
- Cara kerja: rekam -> berhenti otomatis setelah diam ~1,3 detik (mode live 1,5 detik) -> Whisper ubah jadi teks -> terkirim.
- Ketuk Mic saat sedang merekam = anggap selesai ngomong sekarang. Teks muncul setelah selesai ngomong (bukan sambil ngomong).
- Deteksi diam pakai volume (tanpa file VAD tambahan). Di tempat sangat bising bisa telat berhenti: ketuk Mic untuk menyudahi.
- Log: Logcat tag "BunnyEar" (lama ucapan & lama pengenalan).
- Saat Mic pertama kali diketuk muncul toast "Mic: Whisper (nama folder)" atau "Mic: bawaan HP (...)" supaya jelas mesin mana yang dipakai.
- Whisper base kurang akurat untuk bahasa Indonesia; whisper small jauh lebih baik (tapi lebih berat dan lebih lambat).


Tahap 8: Pemutar musik & video (Media3 / ExoPlayer). Dua tombol terpisah di layar utama: Musik dan Video.
Pengaturan ada DI DALAM layar masing-masing (ikon gerigi), bukan di layar utama.

MUSIK:
- Tab Lagu | Album | Artis | Folder | Playlist dengan cover. Folder/Artis/Playlist menampilkan mosaik 4 cover.
- Ikon gerigi: tampil/sembunyikan tab dan geser urutannya, opsi lirik online otomatis, pilih folder file lirik (.lrc).
- Ikon urutkan: nama A-Z/Z-A, tanggal terbaru/terlama, durasi terpanjang/terpendek.
- Tahan lagu: putar berikutnya, antrean, favorit, playlist. Tahan playlist untuk menghapus.
- Mini player -> layar "Sedang diputar": cover besar, seek, acak, ulang, favorit, sleep timer, antrean, kecepatan.
- LIRIK (ikon lirik di Sedang diputar): sumber berurutan = lirik tersimpan > tag di file (MP3 USLT, FLAC) >
  file .lrc/.txt di folder lirik pilihan > online (LRCLIB, tombol awan atau otomatis di pengaturan).
  Lirik ber-waktu (.lrc) ikut bergulir dan baris bisa diketuk untuk lompat. Bisa pilih file lirik atau tempel/ubah sendiri.

VIDEO:
- Daftar folder dengan mosaik 4 thumbnail; ketuk folder = isi folder (thumbnail, durasi, ukuran, progres tonton).
- Ikon urutkan: nama, tanggal, ukuran (naik/turun) di daftar folder maupun isi folder.
- MKV & codec yang gagal di decoder HP: otomatis pindah ke decoder FFmpeg (NextLib). Pengaturan video:
  Otomatis / Utamakan FFmpeg / Hanya bawaan HP, lompat ketuk dua kali (5-30 dtk), gestur, ingat posisi, mosaik.
- Thumbnail video yang hitam / MKV diambil ulang dari frame di dalam video.
- Pemutar: video berikutnya di folder, menu gerigi (kecepatan, audio, subtitle), geser kiri = kecerahan,
  geser kanan = volume, ketuk dua kali = maju/mundur, Picture-in-Picture saat tekan Home.

CATATAN LISENSI: library FFmpeg (io.github.anilbeesetti:nextlib-media3ext) berlisensi GPL-3.0.
Aman untuk pemakaian pribadi. Kalau APK ini dibagikan ke orang lain, kode sumber proyek juga harus dibagikan (GPL).
Izin INTERNET hanya dipakai untuk lirik online.

Tahap 7 (mode terjemah layar + area + perbaikan "Gagal ambil layar"):
- Opsi > "Mode terjemah layar": (1) Sekali tap = ketuk terjemah, ketuk lagi tutup hasil; (2) Tap berurutan = ketuk tutup hasil
  lalu langsung terjemah layar berikutnya; (3) Auto = terjemah sendiri saat teks di area berubah (ketuk tombol A = jeda/lanjut).
- Kotak area: nyalakan Mode game, lalu Opsi > "Atur kotak area". Geser kotak = pindah, tarik sudut = ubah ukuran, Simpan.
  Area sekali tap dan area auto disimpan terpisah; bisa dimatikan lewat pilihan "ikut pilihan 'baca ...'".
- Auto menyembunyikan hasil sekejap tiap ~1 detik untuk memeriksa layar asli (ada kedip singkat). Ketukan ke game memicu cek lebih cepat.
- Frame layar terakhir disimpan terus, jadi layar yang diam tidak lagi memunculkan "Gagal ambil layar".
- Slider "Opasitas kotak terjemahan" ada di Opsi, di bawah pilihan kotak area.

Tahap 8: TAHAN tombol bubble (sekitar setengah detik) = muncul menu: pilih mode (Sekali tap / Tap berurutan / Auto),
atur kotak area, atau Hentikan layanan. Dulu tahan lama langsung menghentikan layanan; sekarang lewat menu itu
(atau tombol Berhenti di notifikasi). Auto otomatis jeda selama menu terbuka.

Tahap 9 (Auto tanpa kedip):
- Saat terjemahan tampil, Auto tidak lagi memeriksa layar terus-menerus. Pemeriksaan dipicu ketukan ke game
  (hasil lama langsung disembunyikan saat diketuk, lalu layar dibaca setelah teks selesai muncul).
- Opsi > "Auto, periksa ulang": otomatis / hanya saat game diketuk / tiap 4 detik / tiap 2 detik.
  Pemeriksaan berkala hanya perlu untuk game yang maju sendiri (auto-play) dan menyebabkan kedip singkat.
- Kalau teks hasil baca sama dengan sebelumnya (mis. hanya animasi), terjemahan lama dibiarkan, tidak dihapus-tampil ulang,
  dan ambang perubahan dinaikkan otomatis supaya tidak sibuk membaca layar.
- Saat tidak ada terjemahan di layar, Auto memeriksa tiap ~0,8 detik tanpa menyembunyikan apa pun.

Tahap 10: "Hentikan layanan" di menu bubble sekarang dua langkah (ketuk, lalu ketuk lagi untuk konfirmasi).
Tahan lama bubble tidak pernah mematikan layanan; hanya membuka menu. Layanan juga bisa dihentikan dari tombol di notifikasi.

Tahap 11: thumbnail video MKV.
- Urutan mencoba: thumbnail sistem -> MediaMetadataRetriever (kini juga lewat file descriptor dan mode CLOSEST)
  -> FFmpeg (library nextlib-mediainfo, dipanggil lewat refleksi) untuk codec yang tidak didukung decoder bawaan HP.
- Kalau build gagal dengan pesan "Could not find ...nextlib-mediainfo...", hapus baris implementation nextlib-mediainfo di
  app/build.gradle.kts; aplikasi tetap jalan, hanya tanpa cadangan FFmpeg.

Tahap 12: riwayat tontonan video lebih akurat.
- Posisi disimpan tiap 5 detik saat memutar (dan saat berhenti/keluar/PiP), bukan hanya saat layar ditutup.
- Video yang selesai ditandai "Selesai ditonton" (centang di thumbnail). Selesai = sisa kurang dari 30 detik atau 5% durasi.
- Video yang belum habis menampilkan "Berhenti di 12:34 dari 24:10" dan bilah progres.
- Dalam antrean: video yang selesai lalu lanjut otomatis ke berikutnya ikut ditandai selesai; pindah manual menyimpan posisi video sebelumnya.
- Catatan: riwayat lama yang sudah terhapus tidak bisa dipulihkan; hanya tontonan baru yang tercatat dengan benar.

Tahap 12: perbaikan thumbnail MKV.
- Penyebab: cadangan FFmpeg memanggil getFrame() tanpa parameter, padahal fungsinya getFrame(long). Panggilan gagal diam-diam, jadi thumbnail MKV tetap kosong.
- Sekarang dipanggil dengan getFrame(-1) (frame di sepertiga durasi).
- Tombol "Aa" di kanan bawah kontrol video (sebelum gerigi): latar subtitle on/off, ukuran (4 pilihan), posisi naik dari bawah (4 pilihan). Langsung berlaku dan diingat.

Tahap 13: 7 slot System Prompt untuk chat Gemma + chat lebih cepat.
- Tombol "Prompt" di layar chat: 7 slot (Personality, Instruction, Reasoning, Context & Memory, Response Control, Honesty, Mature Behavior).
  Tiap slot punya saklar on/off dan teks yang bisa diedit; "Reset semua" mengembalikan teks bawaan. Slot aktif digabung otomatis ke system prompt chat.
- Penerjemah, OCR, dan suara tidak memakai slot ini (tidak berubah).
- Kecepatan: percakapan chat dipakai ulang antar pesan (system prompt dan riwayat tidak di-prefill ulang tiap giliran),
  dibuat ulang otomatis kalau slot/teks berubah, riwayat dihapus, terjemahan jalan, atau konteks hampir penuh.
  Pesan lama dipangkas 400 karakter, 4 pesan terakhir utuh. System prompt dasar dipersingkat.
- Pengaturan (tombol Opsi): kelompok baru "Prompt & konteks AI" menyatukan Mode akurat, Konteks/glosarium (untuk terjemahan),
  Nama panggilan, Catatan, dan tombol "Atur 7 slot System Prompt" (untuk chat). Masing-masing tetap terpisah, hanya dikelompokkan.
- Revisi: pengaturan prompt chat dipindah dari Opsi utama ke tombol "Prompt" di layar chat. Dialognya berisi Nama panggilan, Catatan,
  dan 7 slot. Di Opsi utama tinggal "Konteks terjemahan" (Mode akurat + glosarium) yang memang khusus terjemahan.

Tahap 14: hapus permanen lagu dan video.
- Musik: tahan lama sebuah lagu > "Hapus dari HP (permanen)...". Video: tahan lama sebuah video di daftar folder.
- Muncul pertanyaan "Yakin?" dari aplikasi, lalu satu konfirmasi lagi dari sistem Android (Android 11+). File benar-benar terhapus dari HP.


Perbaikan terjemah layar (kotak terjemahan):
- Kotak terjemahan tingginya tetap sama dengan teks asli dan tidak lagi membesar ke bawah menimpa kotak lain.
  Kalau terjemahan lebih panjang: huruf mengecil dulu, lalu kotak melebar ke samping hanya sejauh ruang kosong,
  dan kalau tetap tidak muat dipotong dengan "...".
- Latar kotak sekarang pekat penuh secara default (kunci pengaturan baru, jadi nilai opasitas lama diabaikan).
  Slider opasitas 30%-100% di Opsi.
- Opsi > pengaturan terjemah layar: perataan teks (kiri/tengah), "Spasi blok teks", "Perbedaan ukuran teks",
  dan "Daftar abaikan" (satu entri per baris; tanda * di awal/akhir = cocok sebagian).
- Blok OCR dipecah per baris kalau tinggi huruf beda jauh atau jarak baris renggang (nama karakter terpisah dari dialog).
- Simbol/ikon di ujung baris yang terbaca sebagai karakter nyasar dibuang dari teks dan dari kotak.
- Alat uji kotak teks (tombol di Opsi): pilih foto layar game, lihat kotak hasil pembacaan (biru = diterjemahkan,
  merah = diabaikan), dan atur slider langsung. Pengaturannya sama dengan yang dipakai terjemah layar.

--- Layar utama (tampilan baru) ---
Semua tombol di layar utama: tinggi 52dp, sudut 20dp, jarak 10dp.
Kartu Chat AI punya latar yang bisa diganti sendiri. Buka Opsi > "Kartu Chat AI":
  - Pilih latar: video (mp4/webm), GIF (animasi jalan terus), atau foto. File disalin ke penyimpanan aplikasi.
  - Bawaan: kembali ke app/src/main/res/raw/chat_loop.mp4 kalau ada, kalau tidak kartu polos biru gelap.
  - Blur (Android 12 ke atas), Gelapkan (0-80%), Gelap di tepi (0-100%, sisi dan sudut gelap, tengah terang).
Video selalu tanpa suara dan di-loop. Saran video: 480p, beberapa detik. Foto/GIF dikecilkan otomatis maksimal 1080 px.


Tahap 15: Karin (Live2D) jadi tubuh AI di layar Chat.
- Karin tampil besar di atas daftar chat. Gerakannya otomatis (tanpa file motion):
  nunggu = napas + kedip acak + sesekali noleh pelan; mikir (Gemma lagi jawab) = noleh kiri-kanan bergantian, mata melirik atas, alis naik;
  dengar (Mic) = kepala miring + sesekali mengangguk; ngomong = mulut ikut volume suara AI (lip-sync dari audio TTS).
- Sentuh Karin: dia menoleh dan menatap ke arah jari.
- Keyboard muncul = Karin menyingkir sementara. Ketuk judul "Chat AI" = tampil/sembunyikan Karin
  (sembunyi = tekstur dilepas dari memori GPU, aman kalau HP lagi berat karena Gemma).
- Ukuran: di res/layout/activity_chat.xml, FrameLayout "karinWrap" dan RecyclerView "list" sama-sama layout_weight 1.
  Mau Karin lebih besar: naikkan weight karinWrap (mis. 1.4).
- Tekstur Karin diperkecil 4096 -> 2048 (assets/karin/tex). Kalau masih berat: perkecil lagi jadi 1024.
- File: KarinAnim.kt (gerak), KarinModel.kt (model Live2D), KarinView.kt (tampilan GL, 30 fps), tambahan di Voice.kt (mouthLevel/playing)
  dan ChatActivity.kt (state Karin).
- Library: Live2D Cubism SDK for Java 5-r.5. Core = app/libs/Live2DCubismCore.aar. Framework (Java) disalin ke
  app/src/main/java/com/live2d/ + shader di app/src/main/assets/com/live2d/. Lisensi SDK ada di app/libs/ dan folder framework.
  Kalau build.yml membersihkan app/libs atau .gitignore mengabaikan *.aar, pastikan Live2DCubismCore.aar ikut ter-commit.
- Kalau Karin gagal muncul: muncul toast "Karin gagal dimuat: ..." berisi penyebabnya. Logcat tag "Karin".


Tahap 16: tampilan Chat baru + optimasi Karin.
- Tombol (Jelaskan halaman / Hapus chat / Suara / Prompt) jadi pil kecil di kanan atas, menumpuk ke bawah di samping Karin.
- Pembatas Karin dan chat = sobekan kertas (res/drawable-nodpi/tear_edge.png, dibuat prosedural: tepi putih berserat + bayangan).
  Karin digambar naik 14dp dari dasar (KarinView.BOTTOM_RESERVE_DP) supaya potongan badan tertutup sobekan dan dadanya tetap kelihatan.
  Kalau tinggi sobekan (ImageView tearEdge, 48dp) diubah, ubah juga BOTTOM_RESERVE_DP (kira-kira 30% dari tinggi sobekan).
- Keyboard muncul: Karin + tombol menyingkir, tinggal header. Ketuk judul "Chat AI" = tampil/sembunyikan Karin (sembunyi = tombol tetap ada, panggung mengecil).
- Optimasi loading:
  1) Konteks GL dipertahankan saat app ke latar (preserveEGLContextOnPause): balik dari app lain tidak muat ulang tekstur.
  2) Tekstur di-decode paralel di thread latar sejak Chat dibuka (KarinTex), bukan di thread GL.
  3) Muat bertahap: frame pertama moc3 + shader, lalu satu tekstur per frame, sehingga tidak ada satu frame panjang.
  4) Karin muncul dengan fade-in 0,45 detik setelah siap.


Tahap 17: perbaikan chat menimpa Karin.
- Penyebab: root layout pakai clipChildren="false", akibatnya daftar chat tidak dipotong di batas atasnya dan bubble menimpa Karin/sobekan.
  JANGAN pasang clipChildren="false" di parent langsung RecyclerView "list".
- Panggung atas dibuat full-bleed lewat margin negatif -12dp (bukan lewat clipChildren).
- Tepi atas daftar chat memudar halus (fadingEdge) sehingga bubble seperti masuk ke bawah sobekan.
- Kertas gelap di bawah garis putih ditipiskan (sobekan 48dp), jarak ke bubble pertama jadi lebih dekat.


Tahap 18: chat dipotong mengikuti zig-zag sobekan.
- Satu profil zig-zag (res/raw/tear_profile.txt + res/drawable-nodpi/tear_edge.png, dibuat bersama) dipakai oleh tiga hal supaya selalu pas:
  1) TornRecyclerView: daftar chat dipotong (clipPath) di bawah tepi putih, jadi bubble tampak masuk ke bawah robekan.
  2) KarinView (GL): poligon penutup berwarna latar menimpa semua di bawah zig-zag, jadi badan Karin berhenti persis di tepi putih.
  3) ImageView tearEdge: tepi putih berserat + bayangan, digambar paling atas.
- Area chat (FrameLayout chatArea) naik 48dp menimpa dasar panggung (margin -48dp) dan daftar chat diberi paddingTop 48dp supaya pesan pertama
  tidak tertutup saat diam. Tinggi 48dp harus sama di: layout (chatArea/tearEdge/paddingTop), TearProfile.HEIGHT_DP.
- Saat keyboard muncul atau Karin dimatikan: mode sobekan dimatikan (chat biasa, tanpa potongan).
- Kalau ingin mengganti bentuk sobekan: jalankan gen_tear3.py (folder tools/) lalu salin tear_edge.png dan tear_profile.txt ke lokasi di atas.


Tahap 19: banyak model (ganti-ganti), model full body 简 (Jian), ekspresi, avatar di belakang/depan chat.
- Model sekarang berupa folder: app/src/main/assets/models/<id>/ berisi model.json (konfigurasi) + moc3 + physics + tekstur.
  Daftar model: assets/models/index.json. Tambah model baru = salin folder + tambahkan id di index.json.
  model.json: layout ("stage" = bust di panggung + sobekan, "full" = full body di belakang/depan chat), fps, nama file, tekstur,
  frame {zoom, offsetY}, params (peran gerak -> nama parameter model), expressions (kunci -> daftar [parameter, nilai]).
- Ganti model: TAHAN LAMA judul "Chat AI" -> menu Avatar (pilih model, posisi belakang/depan chat, ekspresi, sembunyikan).
  Ketuk judul = tampil/sembunyikan avatar. Pilihan disimpan.
- 简 (Jian): tekstur asli 8192 diperkecil ke 2048 (PNG 1,7 MB, GPU sekitar 21 MB; asli 341 MB). Untuk lebih tajam ganti
  models/jian/tex/texture_00.png dengan versi 3072 (sekitar 48 MB GPU) -- tidak perlu ubah kode.
  Gerak badan 简 dikerjakan physics model (inputnya ParamAngleX/Y/Z), jadi parameter badan sengaja tidak diisi di model.json.
  Efek animasi (air mata, bintang, kilat marah) dari motion.json diputar berulang; ekspresi menyalakan ParamSwitchN.
- Ekspresi otomatis dari emoji di balasan AI (lihat Emotion.kt): mis. 😊 pipi merah, 😠 marah, 😢 air mata, 😍 mata hati, 🤩 mata bintang, 🙄 mata putih.
  Ekspresi tangan (kiri/kanan) hanya manual lewat menu Ekspresi.
- Posisi full body: "di belakang chat" (bawaan, memenuhi seluruh layar, bubble chat menimpa avatar) atau "di depan chat"
  (permukaan transparan, menutupi area chat, sentuhan diteruskan ke chat; header dan kolom input tetap kelihatan).
  Mode "stage" (Karin) tidak berubah: panggung + sobekan.
- Keyboard muncul: avatar menyingkir sementara (semua mode).
- Kode: ModelCfg.kt, Emotion.kt, KarinAnim (slot ekspresi), KarinModel (berbasis konfigurasi + motion), KarinView (mode depan/belakang),
  ChatActivity (menu avatar). Layout: rootFrame > bgHost + chatRoot + frontHost.


Tahap 20: avatar di depan chat sebesar di belakang, bisa digeser; sembunyi avatar lewat ketuk beruntun.
- Mode "di depan chat": permukaan avatar kini seukuran layar penuh (sama besar dengan mode belakang), transparan. Sentuhan biasa
  (scroll, ketuk) tetap diteruskan ke chat. TAHAN LAMA tepat di badan avatar = geser bebas ke mana saja (AvatarDragLayout membaca
  satu piksel dari frame GL untuk memastikan jari ada di badan, bukan di bagian transparan). Posisi diingat per model.
  Menu Avatar punya "Kembalikan posisi avatar ke tengah".
- Sembunyi/tampil avatar: ketuk judul "Chat AI" beruntun 2x (ChatActivity.TITLE_TAPS = 2, ganti 3 kalau masih sering kepencet).
  Tahan lama judul tetap membuka menu Avatar.
- Ekspresi: selain emoji, sekarang juga dari kata kunci (marah, sedih, kaget, malu, tersipu, dll; lihat Emotion.kt).
  Ada notifikasi kecil "Ekspresi: ..." saat terdeteksi (uji coba; matikan di menu Avatar).


Tahap 21: perbaikan layout + reaksi fisik avatar.
- BUG kolom input naik 48dp (mode Karin): penyebabnya margin negatif pada anak LinearLayout berbobot (LinearLayout mengabaikan margin
  negatif saat menghitung sisa ruang tapi tetap memakainya saat menata posisi). Sekarang topStage dan chatArea ditumpuk dalam satu
  FrameLayout "body" dan posisinya dihitung di ChatActivity.layoutBody(). JANGAN pakai margin negatif di LinearLayout.
- Mode full body: daftar chat mulai di garis model.json "chatTop" (pecahan tinggi layar, 0.44 untuk 简) dan memudar menghilang di garis itu
  sepanjang "fadeDp" (90dp) -- bukan terpotong keras.
- Mode di depan chat: kolom input + Mic tetap paling depan. Permukaan avatar berhenti di atas kolom input, tetapi avatar tetap digambar
  seukuran layar penuh (viewport negatif di KarinView.setBottomExtra), jadi ukurannya sama dengan mode belakang.
- Reaksi fisik: ParamAnglePX/PY adalah input physics badan di rig 简 (-> badan -> dada "胸 Y", baju, kaki, ekor).
  * Digeser: kecepatan geser diumpankan ke ParamAnglePX/PY dan sudut kepala, jadi badan/rambut/ekor ikut terayun (KarinAnim.dragMove).
  * Disentuh: model.json "touch" berisi zona (pecahan kanvas) + reaksi: bounce (dada), sway (pinggang), jiggle (paha), pat (kepala + pipi merah).
    Reaksi berupa pegas yang memantul beberapa kali (KarinAnim.poke). Di mode belakang chat, reaksi hanya terpicu di ruang kosong
    (bukan di atas bubble/tombol/kolom input). Koordinat zona bisa disetel di models/jian/model.json.


Tahap 22: perbaikan bug Karin (keyboard), mode depan, geser/zoom, reaksi sentuhan lebih hidup.
- BUG Karin: setelah keyboard dibuka kedua kalinya, daftar chat tinggal setengah dan terpotong (kolom input sudah di posisi benar).
  Penyebab: tinggi panggung & margin chat diubah satu-satu lewat LayoutParams saat mode berganti, dan margin dihitung dari tinggi yang
  masih lama. Sekarang BodyLayout.kt (ViewGroup khusus) menghitung semuanya SEKALIGUS di satu putaran ukur, tanpa nilai basi.
- Mode depan chat: daftar chat normal sampai ke atas (di bawah header + tombol), tanpa garis pudar. Garis pudar hanya untuk
  mode belakang chat.
- Geser: sentuh badan avatar lalu geser = langsung bergerak (tanpa tekan lama). Sentuhan yang mulai di bagian transparan tetap scroll chat.
- Zoom: cubit dua jari (mode depan dan belakang), titik fokus tetap diam. Skala 0,35x - 3,5x. Posisi + skala diingat per model dan per mode.
  Menu Avatar punya "Kembalikan posisi & ukuran avatar".
- Reaksi sentuhan diperkuat dan divariasikan (kekuatan/arah acak tiap sentuhan, ketukan beruntun menumpuk):
  kepala = menunduk + goyang kepala + mata menyipit senang; dada = mantul kuat + kaget malu (alis naik, mulut "ah!", pipi merah);
  pinggang = goyang samping; paha = goyang + mantul; kaki = meloncat kecil.
- Geser avatar: badan/rambut/ekor ikut terayun (kelembaman), mata melirik ke arah geser, alis naik, mulut membulat kalau cepat,
  dan saat dilepas avatar "mendarat" memantul sesuai kecepatan terakhir.
- Notifikasi "Sentuh: <zona> (x=.., y=..)" menunjukkan zona yang kena (matikan di menu Avatar). Zona ada di models/jian/model.json "touch";
  x,y = pecahan kanvas dari kiri-atas.


Tahap 23: bintik putih di wajah, keyboard, chat mode depan.
- Bintik putih di sekitar mulut/hidung 简 (terlihat jelas saat di-zoom). Dua penyebab:
  1) Tekstur diperkecil dengan filter Lanczos pada gambar premultiplied: pinggiran transparan overshoot -> piksel putih di tepi
     bentuk tipis. Sekarang diperkecil dengan rata-rata area (BOX) yang bebas ringing (piksel putih bermasalah turun 9475 -> 673 pada 简;
     Karin juga 7294 -> 148). Skrip: tools/boxdown.py (jalankan lagi kalau mengganti tekstur).
  2) Model ini memakai blend mode (digambar lewat render target offscreen). Ukuran render target tadinya = ukuran permukaan, padahal area
     gambar bisa lebih tinggi (mode depan chat) -> lapisan blend meleset. Sekarang render target selalu disamakan dengan area gambar.
  Tambahan: buffer mask clipping 1024 (model.json "maskSize") supaya tepi mask halus saat di-zoom.
- Keyboard muncul: avatar TETAP tampil dan tidak terdorong / mengecil (digambar seolah tanpa keyboard, menempel di atas:
  KarinView.setVirtualHeight + BodyLayout.virtualH). Yang disembunyikan: bubble chat dan tombol kanan atas. Berlaku untuk Karin maupun 简.
  Kalau avatar dimatikan, chat tetap tampil normal.
- Mode depan chat: daftar chat penuh sampai ke atas body (tanpa terpotong / pudar); header + tombol digambar di atas chat
  (BodyLayout.Mode.TOP mengubah urutan gambar). Garis pudar hanya untuk mode belakang chat.


Tahap 15: Manga Translator (tombol di layar utama, di bawah "Terjemahkan gambar").
- Pilih gambar (jpg/png/webp) atau CBZ/ZIP, pilih bahasa asli (Jepang/Korea/Mandarin/Inggris). Proses otomatis per halaman:
  baca teks (ML Kit per bahasa) -> gabung blok satu balon -> terjemah Gemma (konteks 1 halaman) -> tutup teks asli dengan warna latar -> tulis teks Indonesia.
- Hasil: Android/data/com.niven.mangatl/files/manga/<judul>/out. Tahan judul di daftar: Lanjutkan proses / Ekspor CBZ / Hapus.
- Halaman yang sudah jadi dilewati saat dilanjutkan. Gaya bahasa dan glosarium ikut Opsi layar utama.
- Batasan versi pertama: penghapusan teks hanya isi warna latar (balon putih bagus, teks di atas gambar kurang bagus), OCR Jepang vertikal belum sempurna, teks efek suara ikut dibaca.
- Fungsi lama tidak diubah; satu-satunya tambahan di Gemma.kt adalah fungsi translateComic.

Tahap 16: perbaikan Manga Translator. Hapus teks per goresan (garis balon & gambar sekitar tetap utuh; kalau area penuh tetap tutup kotak),
strip webtoon saling tumpang tindih + buang duplikat, ukuran huruf minimum lebih wajar, catatan waktu per tahap di log.txt,
blocks.txt per judul, dan menu "Ulang halaman tanpa terjemahan".

Tahap 17: balon/kotak bertumpuk (mis. chat di layar HP) dipisah per balon saat OCR (garis pembatas, celah lebar, kolom beda);
blok horizontal tidak digabung lagi; teks tidak lagi dipotong (huruf diperkecil sampai 9 px, tanpa clip).

Tahap 18: pemisah balon lebih ketat (hanya garis tepi tipis; pita teks tidak dihitung) supaya satu balon tidak terpecah; hapus semua teks asli dulu baru gambar terjemahan (blok tetangga tidak saling menimpa).

Tahap 19: alat debug Manga Translator. Menu "Tes halaman tertentu" (mis. 43,44 atau 40-45) memproses ulang hanya halaman itu.
Tiap halaman menyimpan <judul>/debug/NNNN.jpg (kotak merah bernomor = blok yang dibaca) dan NNNN.txt (keputusan pemisahan baris, teks asli, terjemahan).

Tahap 20: teks horizontal dikelompokkan ulang per baris (bertumpuk rapat, kolom sejajar, tinggi huruf mirip, tanpa garis tepi balon di antaranya) menggantikan blok ML Kit yang sering memecah satu balon jadi banyak potongan.

Tahap 21: batas celah antar baris dihitung dari tinggi baris terbesar (baris berhuruf kecil semua seperti "more" tidak lagi gagal digabung).

Tahap 22: teks miring (layar HP/tablet) ikut kemiringan: sudut & poligon baris dari ML Kit (cornerPoints), hapus goresan hanya di dalam poligon lalu isi dari piksel sekitar terdekat, terjemahan digambar dengan sudut yang sama. Blok tidak miring memakai jalur lama.

Tahap 23: penataan teks mengikuti bentuk balon (flood fill bagian dalam balon, bungkus kata baris demi baris sesuai lebar balon di tiap ketinggian, huruf terbesar yang muat). Balon yang dipakai bersama blok lain dibagi dua di tengah celah. Kalau gagal, pakai jalur kotak lama.

Tahap 24: percepat terjemah komik (hanya fungsi translateComic): prompt sistem diringkas (~400 -> ~80 token), riwayat konteks 2 pasang, seruan pendek (Ah/Hmm/Hehe...) tidak lewat model.


=== Perubahan tahap 5 ===
- Font terjemahan: Comic Relief Bold (assets/fonts, lisensi OFL), huruf kapital + miring seperti lettering manhwa.
  Atur lewat SharedPreferences "manga": font = ComicRelief-Bold.ttf | ComicNeue-Bold.ttf | system, caps = true/false, italic = true/false.
- Teks terjemahan tidak lagi meluber ke blok tetangga (kepemilikan pixel per blok), ukuran huruf dibatasi 1,15x huruf asli.
- Teks miring: sudut dihitung berbobot panjang baris dan diperhalus dari gambar, ambang 2 derajat.
- log.txt: tambahan rincian waktu Gemma (muat model, tiap potongan, jumlah panggilan ulang).

=== Perubahan tahap 6 ===
- Huruf kapital adaptif: kalau balon sempit dan hasilnya kecil, otomatis pakai huruf biasa. Kata tidak lagi dipotong di tengah (batas ukuran terkecil 6).
- Batas ukuran huruf SIZE_CAP 1,15 -> 1,35 (teks tidak terlalu kecil).
- Teks dijaga tetap di dalam gambar (balon di tepi halaman).
- Hapus teks asli: isi dari piksel kiri-kanan, bukan satu warna rata (tidak ada lagi kotak abu di latar gradasi).
- Penggabungan baris miring dihitung di bingkai yang ikut kemiringan (pesan chat dua pembicara tidak lagi menyatu).
- OCR ulang blok miring: potongan gambar diluruskan lalu dibaca lagi (contoh "Meat was real cheap today so I'm" yang sebelumnya terbaca "o I'm"). Dicatat di debug sebagai "OCR-ULANG miring". Kalau gagal, blok lama dipakai.
- Terjemahan lebih natural: prompt komik sekarang meminta gaya lisan + 4 contoh pendek, konteks baris sebelumnya 2 -> 4, dan kata kaku yang lolos (sangat, tidak, sudah, hanya, seperti, kirimkan, dst) diganti padanan lisan tanpa waktu model (Gemma.casualize). Tidak aktif untuk gaya Sopan.

Banner Musik (header layar Musik):
- Musik > ikon gerigi > "Banner": pilih foto, GIF, atau video. Setelah dipilih muncul layar "Atur posisi banner"
  (geser kotak terang supaya bagian penting tidak terpotong). Bisa dibuka lagi lewat tombol "Atur posisi".
- Mode putar: Loop, atau Maju-mundur. Maju-mundur untuk video/GIF dibuat dari frame kecil (maks 5 detik pertama,
  sekitar 12 fps), jadi tidak semulus Loop. Foto tidak butuh mode.
- Daftar lagu: cover 48dp (ukuran kompak), durasi tidak ditampilkan.


=== Audio Engine (Pemutar Musik) ===
Layar "Sedang diputar" diganti sesuai desain Pemutar_Musik_Audio_Engine_final.html. Acak, ulang, suka, lirik, timer tidur, kecepatan, antrean ada di menu titik tiga ("Lainnya").
- Layar: NowPlayingActivity (pemutar + 5 tab Bass/3D/Vokal/Reverb/Efek + popup parameter cepat + badge Hi-Res),
  AudioEngineActivity (master, 12 fitur, Reset semua / Simpan / Muat), AudioFeatureActivity (semua parameter: slider + angka, validasi, reset per parameter / fitur).
- AudioEngine.kt: definisi 12 fitur + parameter (min/max/default/satuan/deskripsi), nilai, simpan otomatis + slot Simpan/Muat (SharedPreferences "audio_engine").
- Jalur audio: DspRenderersFactory -> DspAudioSink (membungkus DefaultAudioSink) -> DspChain. Dipasang hanya di PlayerService (pemutar musik); VideoActivity tidak berubah.
  Chain: Normalisasi -> EQ -> Bass -> Vokal -> Stereo -> Spatial -> Crossfeed -> Reverb -> Kompresor -> Limiter -> peta kanal -> resampler -> kuantisasi/dither.
- Normalisasi: Loudness.kt menganalisis lagu di latar belakang (BS.1770 K-weighting, gerbang -70 LUFS / -10 LU), hasil di-cache per lagu (SharedPreferences "audio_loudness").
- Hi-Res: OutputCaps.kt memeriksa DAC USB, laju yang didukung, bit-perfect (Android 14+). Opsi yang tidak tersedia dinonaktifkan di UI beserta alasannya.
- Visualizer: VisualizerView membaca sampel setelah Limiter (VisTap) dan menghitung FFT sungguhan.
Batasan yang disengaja: Head Tracking tidak didukung; Exclusive tidak ada di jalur AudioTrack; Spatial memakai model kepala bola (bukan HRTF terukur);
mode float 24/32-bit tidak mendukung kecepatan putar; reverb dipotong di akhir lagu.
