BunnyTL -- README

Dokumen ini singkat: ringkasan, peta kode, cara pasang model, dan peringatan penting.
Riwayat perubahan per tahap dan catatan teknis lengkap ada di CATATAN.txt (buka hanya kalau perlu).

BunnyTL: OCR + terjemahan AI offline (mode akurat, gaya bahasa, glosarium) + Chat AI.

PETA KODE (cari fitur di sini dulu)
Semua kode Kotlin ada di app/src/main/java/com/niven/mangatl/. Package SEMUA file tetap "com.niven.mangatl" (folder hanya untuk
merapikan, jadi tidak perlu import antar folder dan manifest/layout tidak berubah). File baru taruh di folder fiturnya dan tulis
"package com.niven.mangatl" di baris pertama.

  (root)       MainActivity.kt -- layar utama
  chat/        Chat AI. SELURUH tampilan = assets/chat/chat.html di dalam WebView. Kotlin: ChatActivity (keadaan + onCreate + kirim pesan),
               ChatWeb (WebView + jembatan HTML <-> Kotlin), ChatAvatar (avatar: buat/lepas, posisi, ukuran, sentuh), ChatVoice
               (TTS + Mic/Whisper/mode live), ChatMessages (Msg); PromptSlots (7 slot prompt), Voice (suara AI/TTS), Ear (Mic/Whisper)
  avatar/      Avatar Live2D: AvatarView (GL), AvatarAnim (gerak/ekspresi), AvatarModel (model Live2D), AvatarDragLayout (geser/zoom),
               ModelCfg (baca model.json), Emotion (emoji/kata -> ekspresi), MikuAvatar + ComicAvatar (avatar di layar Sedang diputar)
  translate/   Terjemah layar/mode game: ScreenService (siklus hidup + onStartCommand + notifikasi) dipecah jadi ScreenOverlay
               (tombol/panel/penyunting area/menu), ScreenCapture (tangkap layar), ScreenTranslate (OCR + terjemah),
               ScreenAuto (ketukan + mode otomatis); plus OverlayView, AreaEditorView, Grouping (susun blok OCR),
               MangaActivity, MangaReaderActivity, MangaEngine (API publik: file/impor/ekspor/processPage) + MangaOcr (baca teks,
               kelompok blok, luruskan teks miring) + MangaRender (hapus teks asli, tulis terjemahan)
  audio/       Audio Engine: AudioEngine (definisi fitur), AudioEngineActivity, AudioFeatureActivity, AudioUi, Dsp* (jalur audio:
               DspAudioSink -> DspChain -> DspCore/DspEffects/DspSpace), Loudness, OutputCaps (Hi-Res/DAC), VisualizerView
  music/       Pemutar musik: MusicActivity (keadaan + onCreate + tab + pemutaran mini) dipecah jadi MusicRows (baris daftar, folder/Drill,
               aksi massal), MusicActions (menu satu lagu, antrean), MusicSettings (pengaturan + banner); NowPlayingActivity (keadaan + onCreate + tampilan cover; dipecah jadi NowPlayingLyrics = lirik penuh + mini, NowPlayingTabs = tab Audio
               Engine + popup, NowPlayingDialogs = menu lainnya/kecepatan/timer/antrean), PlayerService, MusicStore, MusicWheelView,
               MusicWidgets, Lyrics, FadeMask (view pemudar cover), Banner + BannerPosView
  video/       Video: VideoActivity (pemutar), VideoFoldersActivity, VideoListActivity, TimelineView.
  download/    Unduh video/musik (mesin yt-dlp dari SnapNet): DlEngine (siapkan+uji mesin), DlUpdater (pembaruan yt-dlp ber-SHA-256 + rollback),
               DlModels (parse info link, daftar resolusi), DlQueue (antrean, perintah yt-dlp, simpan ke MediaStore), DlService (notifikasi progres),
               DlPicker (panel pilih kualitas + playlist), DlCookies/CookiesActivity (login/cookies), DownloadActivity (layar dari menu utama), QuickDownloadActivity (sheet saat Bagikan link).
               Editor: VideoEditActivity (keadaan + onCreate + pemutaran/riwayat) dipecah jadi EditOps (bagi/hapus/geser/kecepatan/
               volume/lagu + dialog), EditOverlays (lapisan overlay, kanvas, panggung), EditExport (komposisi + simpan),
               EditModel (Clip/Seg/Ov/Fadable/Snap), EditEffects (efek Media3 pudar + overlay)
  media/       Dipakai bersama musik + video: MediaActivity (dasar daftar), Rows, Library (baca media HP), Decoders (FFmpeg)
  ai/          Gemma (mesin AI LiteRT-LM), TextUtil
  common/      Dipakai semua fitur: Prefs, Ui, Sheet (popup), Fx (animasi), BunnyWebView, BunnyLogoView, VignetteView
  Resource: res/layout (activity_*.xml per layar), res/drawable, res/values. Aset: assets/models (avatar), assets/fonts, assets/bunny.
  Pola file pecahan (VideoEditActivity, MangaEngine, ScreenService, MusicActivity, NowPlayingActivity, ChatActivity): file Edit*/MangaOcr/MangaRender berisi fungsi ekstensi dari kelas induknya.
               Keadaan tetap di kelas induk; anggota private yang dipakai lintas file ditandai internal.
  tools/       Skrip pembuat aset di komputer (boxdown.py = perkecil tekstur). Bukan bagian APK.

========================================================================
PASANG & PAKAI
========================================================================

Mesin AI bisa diganti-ganti. Taruh tiap model di foldernya sendiri (COPY, bukan Move):
Android/data/com.niven.mangatl/files/
    Ai 1/gemma-4-E2B-it.litertlm
    Ai 2/Qwen3.5-4B_mixed_int4.litertlm
    Ai 3/...

Nama folder bebas. File .litertlm langsung di folder files/ juga tetap terbaca.
Pilih mesin di menu Opsi > "Mesin AI". Pilihan tersimpan dan berlaku untuk
terjemah, mode game, dan Chat.

Cache: tiap mesin AI punya folder cache sendiri bernama "_cache" di dalam foldernya
(mis. Ai 1/_cache). Aman dihapus kalau mau; nanti dibuat ulang otomatis.

Chat suara: tombol "Mic" di layar Chat. Ketuk, bicara (bahasa Indonesia), jawaban terkirim otomatis.
Ketuk lagi untuk membatalkan. Untuk offline, pasang paket suara Indonesia di
Pengaturan HP > Google > pengenalan suara / Speech Services.

Suara AI (keluar), 100% offline: model Supertonic 3 (sherpa-onnx).
1. Unduh sherpa-onnx-supertonic-3-tts-int8-2026-05-11.tar.bz2 dari
   github.com/k2-fsa/sherpa-onnx/releases/tag/tts-models, lalu ekstrak.
2. Salin folder hasil ekstrak (isi: voice.bin, tts.json, unicode_indexer.bin,
   dan 4 file .onnx) ke Android/data/com.niven.mangatl/files/Suara 1/
3. Opsi > "Suara AI": pilih model suara, pilih Suara 1-6 (1-5 cewek, 6 cowok), tekan "Tes suara".
   Suara 1-5 biasanya cewek (urutan perkiraan, dengar sendiri). 
4. Di Chat: tombol "Suara: mati/nyala" = AI membacakan setiap jawaban.
   Ketuk balon jawaban untuk membacakan satu pesan.
Catatan build: build.yml mengunduh sherpa-onnx-2.0.1.aar ke app/libs/ saat build.

Tahap 7: Mic offline Whisper (jauh lebih akurat dari pengenal bawaan HP).
1. Unduh sherpa-onnx-whisper-small.tar.bz2 (lebih akurat, ~350 MB) atau sherpa-onnx-whisper-base (lebih cepat, ~150 MB)
   dari github.com/k2-fsa/sherpa-onnx/releases/tag/asr-models, lalu ekstrak.
2. Salin folder hasil ekstrak (isi: *-encoder*.onnx, *-decoder*.onnx, *-tokens.txt) ke
   Android/data/com.niven.mangatl/files/Whisper/   (nama folder bebas).
3. Selesai. Kalau folder ini ada, tombol Mic otomatis pakai Whisper. Kalau belum ada / Whisper error, otomatis pakai mic bawaan.
- Cara kerja: rekam -> berhenti otomatis setelah diam ~1,3 detik (mode live 1,5 detik) -> Whisper ubah jadi teks -> terkirim.
- Ketuk Mic saat sedang merekam = anggap selesai ngomong sekarang. Teks muncul setelah selesai ngomong (bukan sambil ngomong).
- Deteksi diam pakai volume (tanpa file VAD tambahan). Di tempat sangat bising bisa telat berhenti: ketuk Mic untuk menyudahi.
- Log: Logcat tag "BunnyEar" (lama ucapan & lama pengenalan).
- Saat Mic pertama kali diketuk muncul toast "Mic: Whisper (nama folder)" atau "Mic: bawaan HP (...)" supaya jelas mesin mana yang dipakai.
- Whisper base kurang akurat untuk bahasa Indonesia; whisper small jauh lebih baik (tapi lebih berat dan lebih lambat).

CATATAN LISENSI: library FFmpeg (io.github.anilbeesetti:nextlib-media3ext) berlisensi GPL-3.0.
Aman untuk pemakaian pribadi. Kalau APK ini dibagikan ke orang lain, kode sumber proyek juga harus dibagikan (GPL).
Izin INTERNET hanya dipakai untuk lirik online.

--- Layar utama (tampilan baru) ---
Semua tombol di layar utama: tinggi 52dp, sudut 20dp, jarak 10dp.
Kartu Chat AI punya latar yang bisa diganti sendiri. Buka Opsi > "Kartu Chat AI":
  - Pilih latar: video (mp4/webm), GIF (animasi jalan terus), atau foto. File disalin ke penyimpanan aplikasi.
  - Bawaan: kembali ke app/src/main/res/raw/chat_loop.mp4 kalau ada, kalau tidak kartu polos biru gelap.
  - Blur (Android 12 ke atas), Gelapkan (0-80%), Gelap di tepi (0-100%, sisi dan sudut gelap, tengah terang).
Video selalu tanpa suara dan di-loop. Saran video: 480p, beberapa detik. Foto/GIF dikecilkan otomatis maksimal 1080 px.

========================================================================

PERINGATAN PENTING (jangan dilanggar saat mengedit)
- Layout chat: urutan lapisan hanya bgHost (avatar belakang) -> chatWeb -> frontHost (avatar depan). JANGAN menambah view chat native lagi
  (dulu pernah menumpuk tidak jelas); ubah tampilan di assets/chat/chat.html. Latar halaman harus tetap transparan.
- Tekstur avatar: setelah mengganti tekstur, perkecil dengan tools/boxdown.py (rata-rata area/BOX, bukan Lanczos) supaya tidak muncul
  bintik putih di wajah.
- Live2DCubismCore.aar (app/libs/) harus ikut ter-commit. Kalau build.yml membersihkan app/libs atau .gitignore mengabaikan *.aar, build gagal.
  build.yml juga mengunduh sherpa-onnx-2.0.1.aar ke app/libs/ saat build.
- Library FFmpeg (nextlib-media3ext) berlisensi GPL: aman untuk pemakaian pribadi; kalau APK dibagikan, ikut sertakan kode sumber (lihat CATATAN LISENSI di atas).
- Package semua file Kotlin tetap com.niven.mangatl walau ada di subfolder. File baru: taruh di folder fiturnya dan tulis package itu di baris pertama.
- Menambah fungsi ke editor video / MangaEngine / ScreenService / MusicActivity / NowPlayingActivity / ChatActivity: taruh di file kelompoknya sebagai fungsi ekstensi (internal fun VideoEditActivity.nama() /
  internal fun MangaEngine.nama()). Kalau fungsi itu memakai anggota private/protected kelas induk, ubah anggota itu jadi internal
  (MediaActivity: deleteMedia, updateMedia, renameDialog, moveDialog, moveMany, picked, selecting, startSelect, toggleSelect, exitSelect, onMediaReady sudah internal).
  Anggota companion tidak terlihat dari fungsi ekstensi: tulis NamaKelas.NAMA.
  Fungsi yang memakai
  ::properti.isInitialized harus tetap di dalam kelas (VideoEditActivity.syncOverlays/onPause/onDestroy).
- Lingkungan AI tidak punya kompiler: setelah AI mengubah kode, build di GitHub lalu kirim log kalau ada error.
