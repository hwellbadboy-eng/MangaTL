BunnyTL: OCR + terjemahan AI offline (mode akurat, gaya bahasa, glosarium) + Chat AI.

Mesin AI bisa diganti-ganti. Taruh tiap model di foldernya sendiri (COPY, bukan Move):
Android/data/com.niven.mangatl/files/
    Ai 1/gemma-4-E2B-it.litertlm
    Ai 2/Qwen3.5-4B_mixed_int4.litertlm
    Ai 3/...

Nama folder bebas. File .litertlm langsung di folder files/ juga tetap terbaca.
Pilih mesin di menu Opsi > "Mesin AI". Pilihan tersimpan dan berlaku untuk
terjemah, mode game, dan Chat.

Cache: tiap mesin AI punya folder cache sendiri bernama "_cache" di dalam foldernya
(mis. Ai 1/_cache). Aman dihapus kalau mau; nanti dibuat ulang otomatis.

Chat suara: tombol "Mic" di layar Chat. Ketuk, bicara (bahasa Indonesia), jawaban terkirim otomatis.
Ketuk lagi untuk membatalkan. Untuk offline, pasang paket suara Indonesia di
Pengaturan HP > Google > pengenalan suara / Speech Services.

Suara AI (keluar), 100% offline: model Supertonic 3 (sherpa-onnx).
1. Unduh sherpa-onnx-supertonic-3-tts-int8-2026-05-11.tar.bz2 dari
   github.com/k2-fsa/sherpa-onnx/releases/tag/tts-models, lalu ekstrak.
2. Salin folder hasil ekstrak (isi: voice.bin, tts.json, unicode_indexer.bin,
   dan 4 file .onnx) ke Android/data/com.niven.mangatl/files/Suara 1/
3. Opsi > "Suara AI": pilih model suara, pilih Suara 1-6 (1-5 cewek, 6 cowok), tekan "Tes suara".
   Suara 1-5 biasanya cewek (urutan perkiraan, dengar sendiri). 
4. Di Chat: tombol "Suara: mati/nyala" = AI membacakan setiap jawaban.
   Ketuk balon jawaban untuk membacakan satu pesan.
Catatan build: build.yml mengunduh sherpa-onnx-2.0.1.aar ke app/libs/ saat build.

Tahap 4 (mode game lebih cepat):
- Terjemah layar memakai prompt pendek + streaming: hasil muncul bertahap, dialog utama (teks terpanjang) paling dulu.
- Cache per baris di memori: teks yang sama (menu, tombol, dialog berulang) langsung tampil tanpa memanggil model.
  Tombol Reset mengosongkan cache ini.
- Backend (GPU/CPU) yang berhasil diingat per model, jadi muat berikutnya tidak mencoba ulang yang gagal.
- Opsi: slider opasitas kotak terjemahan, dan pilihan ketuk saat hasil tampil
  (tutup + langsung terjemah layar berikutnya, atau cuma tutup).

Tahap 5 (suara ikut teks):
- Chat: suara AI sekarang streaming. Tiap kalimat dibacakan begitu muncul di layar, tidak menunggu jawaban selesai.
- Model suara dimuat saat pesan dikirim (selagi AI mikir), jadi kalimat pertama langsung bunyi.
- Tombol "Berhenti" ikut menghentikan suara.

Tahap 5b:
- Mode LIVE ngobrol: TAHAN tombol Mic. Dengar -> AI jawab bersuara -> dengar lagi otomatis, terus sampai
  Mic diketuk atau "Berhenti" ditekan. Jawaban di mode live dibuat singkat (1-3 kalimat).
- Mic tetap full offline (pengenal on-device); jeda diam dilonggarkan.
- Suara lebih cepat: model dimuat sejak layar Chat dibuka, potongan pertama boleh berhenti di koma, langkah
  generate suara dikurangi (3 untuk potongan pertama, 4 untuk sisanya).

Tahap 5c (perbaikan kualitas suara):
- Langkah generate suara dinaikkan jadi 6 untuk semua potongan (sebelumnya 3/4 = mendem & cempreng, kualitas tiap potongan beda).
- Potongan teks minimal ~28 karakter (sebelumnya 10), sisa potongan pendek digabung, intonasi akhir ditambah tanda baca.
- Pasca-proses: cegah clipping, volume antar potongan disamakan, fade anti-klik, jeda awal 150 ms supaya kata pertama tidak terpotong.
- Kalau masih terlalu tajam: di Voice.kt ubah TAME_TREBLE = true (redam treble). Kalau mau lebih cepat: turunkan STEPS ke 5.
- Saran: pakai model fp32 (bukan int8) kalau ada; int8 sedikit lebih kasar.

Tahap 6 (suara kadang mendem/cempreng):
- Pemutaran menunggu 2 potongan siap dulu (PREBUFFER_CHUNKS) supaya tidak putus kalau pembuatan suara kalah cepat dari pemutaran.
- Jenis audio diganti dari SPEECH ke MUSIC: beberapa HP memasang filter "suara bicara" yang bikin kadang mendem/cempreng.
- Teks dibersihkan lebih banyak (simbol, kutip, singkatan gk/yg/dgn).
- Logcat tag "BunnyVoice" mencatat waktu bikin vs durasi tiap potongan (untuk diagnosa).
- Potongan teks dibatasi MAX_CHUNK = 120 huruf (sebelumnya 220) karena teks panjang bikin suara mendem/cempreng.
- Seimbangkan kecepatan vs kualitas: STEPS 5, PREBUFFER_CHUNKS 1, MIN_CHUNK 24, SPEED 1.05 (suara tidak terlalu ketinggalan dari teks).
- Potongan pertama langsung dibacakan begitu >= 30 huruf (FIRST_FORCE), tanpa nunggu titik/koma, supaya suara mulai bareng teks.
- Awal cepat, belakang natural: potongan pertama 5 langkah (STEPS_FIRST), sisanya 6 langkah (STEPS). Potongan yang terpotong di tengah kalimat diakhiri koma supaya intonasi nyambung.

Tahap 6b: pengaturan "Kecepatan mulai suara" di Opsi (di bawah pilihan Suara 1-6):
- Cepat: suara mulai paling awal (potongan pertama ~24 huruf), risiko agak kasar.
- Seimbang (default): awal cepat, bagian belakang lebih natural.
- Natural: paling jernih, suara mulai agak telat.
Pilihan berlaku untuk suara berikutnya, tidak perlu restart.

Tahap 6c: slider "Jeda koma" dan "Jeda titik" (0-600 ms) di Opsi, di atas tombol Tes suara.
- Jeda dipasang di tiap pergantian potongan. Koma sekarang ikut jadi titik potong (setelah ~28-40 huruf tergantung mode).
- Koma di kalimat pendek (dalam satu potongan) tetap diatur model suara.
- Default: koma 90 ms, titik 90 ms (= suara sebelumnya). Tombol "Kembalikan ke default" mengembalikan mode kecepatan + dua jeda. Potongan yang terpotong di tengah frasa pakai jeda tetap 40 ms.

Tahap 7: Mic offline Whisper (jauh lebih akurat dari pengenal bawaan HP).
1. Unduh sherpa-onnx-whisper-small.tar.bz2 (lebih akurat, ~350 MB) atau sherpa-onnx-whisper-base (lebih cepat, ~150 MB)
   dari github.com/k2-fsa/sherpa-onnx/releases/tag/asr-models, lalu ekstrak.
2. Salin folder hasil ekstrak (isi: *-encoder*.onnx, *-decoder*.onnx, *-tokens.txt) ke
   Android/data/com.niven.mangatl/files/Whisper/   (nama folder bebas).
3. Selesai. Kalau folder ini ada, tombol Mic otomatis pakai Whisper. Kalau belum ada / Whisper error, otomatis pakai mic bawaan.
- Cara kerja: rekam -> berhenti otomatis setelah diam ~1,3 detik (mode live 1,5 detik) -> Whisper ubah jadi teks -> terkirim.
- Ketuk Mic saat sedang merekam = anggap selesai ngomong sekarang. Teks muncul setelah selesai ngomong (bukan sambil ngomong).
- Deteksi diam pakai volume (tanpa file VAD tambahan). Di tempat sangat bising bisa telat berhenti: ketuk Mic untuk menyudahi.
- Log: Logcat tag "BunnyEar" (lama ucapan & lama pengenalan).
- Saat Mic pertama kali diketuk muncul toast "Mic: Whisper (nama folder)" atau "Mic: bawaan HP (...)" supaya jelas mesin mana yang dipakai.
- Whisper base kurang akurat untuk bahasa Indonesia; whisper small jauh lebih baik (tapi lebih berat dan lebih lambat).


Tahap 8: Pemutar musik & video (Media3 / ExoPlayer). Dua tombol terpisah di layar utama: Musik dan Video.
Pengaturan ada DI DALAM layar masing-masing (ikon gerigi), bukan di layar utama.

MUSIK:
- Tab Lagu | Album | Artis | Folder | Playlist dengan cover. Folder/Artis/Playlist menampilkan mosaik 4 cover.
- Ikon gerigi: tampil/sembunyikan tab dan geser urutannya, opsi lirik online otomatis, pilih folder file lirik (.lrc).
- Ikon urutkan: nama A-Z/Z-A, tanggal terbaru/terlama, durasi terpanjang/terpendek.
- Tahan lagu: putar berikutnya, antrean, favorit, playlist. Tahan playlist untuk menghapus.
- Mini player -> layar "Sedang diputar": cover besar, seek, acak, ulang, favorit, sleep timer, antrean, kecepatan.
- LIRIK (ikon lirik di Sedang diputar): sumber berurutan = lirik tersimpan > tag di file (MP3 USLT, FLAC) >
  file .lrc/.txt di folder lirik pilihan > online (LRCLIB, tombol awan atau otomatis di pengaturan).
  Lirik ber-waktu (.lrc) ikut bergulir dan baris bisa diketuk untuk lompat. Bisa pilih file lirik atau tempel/ubah sendiri.

VIDEO:
- Daftar folder dengan mosaik 4 thumbnail; ketuk folder = isi folder (thumbnail, durasi, ukuran, progres tonton).
- Ikon urutkan: nama, tanggal, ukuran (naik/turun) di daftar folder maupun isi folder.
- MKV & codec yang gagal di decoder HP: otomatis pindah ke decoder FFmpeg (NextLib). Pengaturan video:
  Otomatis / Utamakan FFmpeg / Hanya bawaan HP, lompat ketuk dua kali (5-30 dtk), gestur, ingat posisi, mosaik.
- Thumbnail video yang hitam / MKV diambil ulang dari frame di dalam video.
- Pemutar: video berikutnya di folder, menu gerigi (kecepatan, audio, subtitle), geser kiri = kecerahan,
  geser kanan = volume, ketuk dua kali = maju/mundur, Picture-in-Picture saat tekan Home.

CATATAN LISENSI: library FFmpeg (io.github.anilbeesetti:nextlib-media3ext) berlisensi GPL-3.0.
Aman untuk pemakaian pribadi. Kalau APK ini dibagikan ke orang lain, kode sumber proyek juga harus dibagikan (GPL).
Izin INTERNET hanya dipakai untuk lirik online.

Tahap 7 (mode terjemah layar + area + perbaikan "Gagal ambil layar"):
- Opsi > "Mode terjemah layar": (1) Sekali tap = ketuk terjemah, ketuk lagi tutup hasil; (2) Tap berurutan = ketuk tutup hasil
  lalu langsung terjemah layar berikutnya; (3) Auto = terjemah sendiri saat teks di area berubah (ketuk tombol A = jeda/lanjut).
- Kotak area: nyalakan Mode game, lalu Opsi > "Atur kotak area". Geser kotak = pindah, tarik sudut = ubah ukuran, Simpan.
  Area sekali tap dan area auto disimpan terpisah; bisa dimatikan lewat pilihan "ikut pilihan 'baca ...'".
- Auto menyembunyikan hasil sekejap tiap ~1 detik untuk memeriksa layar asli (ada kedip singkat). Ketukan ke game memicu cek lebih cepat.
- Frame layar terakhir disimpan terus, jadi layar yang diam tidak lagi memunculkan "Gagal ambil layar".
- Slider "Opasitas kotak terjemahan" ada di Opsi, di bawah pilihan kotak area.

Tahap 8: TAHAN tombol bubble (sekitar setengah detik) = muncul menu: pilih mode (Sekali tap / Tap berurutan / Auto),
atur kotak area, atau Hentikan layanan. Dulu tahan lama langsung menghentikan layanan; sekarang lewat menu itu
(atau tombol Berhenti di notifikasi). Auto otomatis jeda selama menu terbuka.

Tahap 9 (Auto tanpa kedip):
- Saat terjemahan tampil, Auto tidak lagi memeriksa layar terus-menerus. Pemeriksaan dipicu ketukan ke game
  (hasil lama langsung disembunyikan saat diketuk, lalu layar dibaca setelah teks selesai muncul).
- Opsi > "Auto, periksa ulang": otomatis / hanya saat game diketuk / tiap 4 detik / tiap 2 detik.
  Pemeriksaan berkala hanya perlu untuk game yang maju sendiri (auto-play) dan menyebabkan kedip singkat.
- Kalau teks hasil baca sama dengan sebelumnya (mis. hanya animasi), terjemahan lama dibiarkan, tidak dihapus-tampil ulang,
  dan ambang perubahan dinaikkan otomatis supaya tidak sibuk membaca layar.
- Saat tidak ada terjemahan di layar, Auto memeriksa tiap ~0,8 detik tanpa menyembunyikan apa pun.

Tahap 10: "Hentikan layanan" di menu bubble sekarang dua langkah (ketuk, lalu ketuk lagi untuk konfirmasi).
Tahan lama bubble tidak pernah mematikan layanan; hanya membuka menu. Layanan juga bisa dihentikan dari tombol di notifikasi.

Tahap 11: thumbnail video MKV.
- Urutan mencoba: thumbnail sistem -> MediaMetadataRetriever (kini juga lewat file descriptor dan mode CLOSEST)
  -> FFmpeg (library nextlib-mediainfo, dipanggil lewat refleksi) untuk codec yang tidak didukung decoder bawaan HP.
- Kalau build gagal dengan pesan "Could not find ...nextlib-mediainfo...", hapus baris implementation nextlib-mediainfo di
  app/build.gradle.kts; aplikasi tetap jalan, hanya tanpa cadangan FFmpeg.

Tahap 12: riwayat tontonan video lebih akurat.
- Posisi disimpan tiap 5 detik saat memutar (dan saat berhenti/keluar/PiP), bukan hanya saat layar ditutup.
- Video yang selesai ditandai "Selesai ditonton" (centang di thumbnail). Selesai = sisa kurang dari 30 detik atau 5% durasi.
- Video yang belum habis menampilkan "Berhenti di 12:34 dari 24:10" dan bilah progres.
- Dalam antrean: video yang selesai lalu lanjut otomatis ke berikutnya ikut ditandai selesai; pindah manual menyimpan posisi video sebelumnya.
- Catatan: riwayat lama yang sudah terhapus tidak bisa dipulihkan; hanya tontonan baru yang tercatat dengan benar.

Tahap 12: perbaikan thumbnail MKV.
- Penyebab: cadangan FFmpeg memanggil getFrame() tanpa parameter, padahal fungsinya getFrame(long). Panggilan gagal diam-diam, jadi thumbnail MKV tetap kosong.
- Sekarang dipanggil dengan getFrame(-1) (frame di sepertiga durasi).
- Tombol "Aa" di kanan bawah kontrol video (sebelum gerigi): latar subtitle on/off, ukuran (4 pilihan), posisi naik dari bawah (4 pilihan). Langsung berlaku dan diingat.

Tahap 13: 7 slot System Prompt untuk chat Gemma + chat lebih cepat.
- Tombol "Prompt" di layar chat: 7 slot (Personality, Instruction, Reasoning, Context & Memory, Response Control, Honesty, Mature Behavior).
  Tiap slot punya saklar on/off dan teks yang bisa diedit; "Reset semua" mengembalikan teks bawaan. Slot aktif digabung otomatis ke system prompt chat.
- Penerjemah, OCR, dan suara tidak memakai slot ini (tidak berubah).
- Kecepatan: percakapan chat dipakai ulang antar pesan (system prompt dan riwayat tidak di-prefill ulang tiap giliran),
  dibuat ulang otomatis kalau slot/teks berubah, riwayat dihapus, terjemahan jalan, atau konteks hampir penuh.
  Pesan lama dipangkas 400 karakter, 4 pesan terakhir utuh. System prompt dasar dipersingkat.
- Pengaturan (tombol Opsi): kelompok baru "Prompt & konteks AI" menyatukan Mode akurat, Konteks/glosarium (untuk terjemahan),
  Nama panggilan, Catatan, dan tombol "Atur 7 slot System Prompt" (untuk chat). Masing-masing tetap terpisah, hanya dikelompokkan.
- Revisi: pengaturan prompt chat dipindah dari Opsi utama ke tombol "Prompt" di layar chat. Dialognya berisi Nama panggilan, Catatan,
  dan 7 slot. Di Opsi utama tinggal "Konteks terjemahan" (Mode akurat + glosarium) yang memang khusus terjemahan.

Tahap 14: hapus permanen lagu dan video.
- Musik: tahan lama sebuah lagu > "Hapus dari HP (permanen)...". Video: tahan lama sebuah video di daftar folder.
- Muncul pertanyaan "Yakin?" dari aplikasi, lalu satu konfirmasi lagi dari sistem Android (Android 11+). File benar-benar terhapus dari HP.


Perbaikan terjemah layar (kotak terjemahan):
- Kotak terjemahan tingginya tetap sama dengan teks asli dan tidak lagi membesar ke bawah menimpa kotak lain.
  Kalau terjemahan lebih panjang: huruf mengecil dulu, lalu kotak melebar ke samping hanya sejauh ruang kosong,
  dan kalau tetap tidak muat dipotong dengan "...".
- Latar kotak sekarang pekat penuh secara default (kunci pengaturan baru, jadi nilai opasitas lama diabaikan).
  Slider opasitas 30%-100% di Opsi.
- Opsi > pengaturan terjemah layar: perataan teks (kiri/tengah), "Spasi blok teks", "Perbedaan ukuran teks",
  dan "Daftar abaikan" (satu entri per baris; tanda * di awal/akhir = cocok sebagian).
- Blok OCR dipecah per baris kalau tinggi huruf beda jauh atau jarak baris renggang (nama karakter terpisah dari dialog).
- Simbol/ikon di ujung baris yang terbaca sebagai karakter nyasar dibuang dari teks dan dari kotak.
- Alat uji kotak teks (tombol di Opsi): pilih foto layar game, lihat kotak hasil pembacaan (biru = diterjemahkan,
  merah = diabaikan), dan atur slider langsung. Pengaturannya sama dengan yang dipakai terjemah layar.

--- Layar utama (tampilan baru) ---
Semua tombol di layar utama: tinggi 52dp, sudut 20dp, jarak 10dp.
Kartu Chat AI punya latar yang bisa diganti sendiri. Buka Opsi > "Kartu Chat AI":
  - Pilih latar: video (mp4/webm), GIF (animasi jalan terus), atau foto. File disalin ke penyimpanan aplikasi.
  - Bawaan: kembali ke app/src/main/res/raw/chat_loop.mp4 kalau ada, kalau tidak kartu polos biru gelap.
  - Blur (Android 12 ke atas), Gelapkan (0-80%), Gelap di tepi (0-100%, sisi dan sudut gelap, tengah terang).
Video selalu tanpa suara dan di-loop. Saran video: 480p, beberapa detik. Foto/GIF dikecilkan otomatis maksimal 1080 px.


Tahap 15: Karin (Live2D) jadi tubuh AI di layar Chat.
- Karin tampil besar di atas daftar chat. Gerakannya otomatis (tanpa file motion):
  nunggu = napas + kedip acak + sesekali noleh pelan; mikir (Gemma lagi jawab) = noleh kiri-kanan bergantian, mata melirik atas, alis naik;
  dengar (Mic) = kepala miring + sesekali mengangguk; ngomong = mulut ikut volume suara AI (lip-sync dari audio TTS).
- Sentuh Karin: dia menoleh dan menatap ke arah jari.
- Keyboard muncul = Karin menyingkir sementara. Ketuk judul "Chat AI" = tampil/sembunyikan Karin
  (sembunyi = tekstur dilepas dari memori GPU, aman kalau HP lagi berat karena Gemma).
- Ukuran: di res/layout/activity_chat.xml, FrameLayout "karinWrap" dan RecyclerView "list" sama-sama layout_weight 1.
  Mau Karin lebih besar: naikkan weight karinWrap (mis. 1.4).
- Tekstur Karin diperkecil 4096 -> 2048 (assets/karin/tex). Kalau masih berat: perkecil lagi jadi 1024.
- File: KarinAnim.kt (gerak), KarinModel.kt (model Live2D), KarinView.kt (tampilan GL, 30 fps), tambahan di Voice.kt (mouthLevel/playing)
  dan ChatActivity.kt (state Karin).
- Library: Live2D Cubism SDK for Java 5-r.5. Core = app/libs/Live2DCubismCore.aar. Framework (Java) disalin ke
  app/src/main/java/com/live2d/ + shader di app/src/main/assets/com/live2d/. Lisensi SDK ada di app/libs/ dan folder framework.
  Kalau build.yml membersihkan app/libs atau .gitignore mengabaikan *.aar, pastikan Live2DCubismCore.aar ikut ter-commit.
- Kalau Karin gagal muncul: muncul toast "Karin gagal dimuat: ..." berisi penyebabnya. Logcat tag "Karin".


Tahap 16: tampilan Chat baru + optimasi Karin.
- Tombol (Jelaskan halaman / Hapus chat / Suara / Prompt) jadi pil kecil di kanan atas, menumpuk ke bawah di samping Karin.
- Pembatas Karin dan chat = sobekan kertas (res/drawable-nodpi/tear_edge.png, dibuat prosedural: tepi putih berserat + bayangan).
  Karin digambar naik 14dp dari dasar (KarinView.BOTTOM_RESERVE_DP) supaya potongan badan tertutup sobekan dan dadanya tetap kelihatan.
  Kalau tinggi sobekan (ImageView tearEdge, 48dp) diubah, ubah juga BOTTOM_RESERVE_DP (kira-kira 30% dari tinggi sobekan).
- Keyboard muncul: Karin + tombol menyingkir, tinggal header. Ketuk judul "Chat AI" = tampil/sembunyikan Karin (sembunyi = tombol tetap ada, panggung mengecil).
- Optimasi loading:
  1) Konteks GL dipertahankan saat app ke latar (preserveEGLContextOnPause): balik dari app lain tidak muat ulang tekstur.
  2) Tekstur di-decode paralel di thread latar sejak Chat dibuka (KarinTex), bukan di thread GL.
  3) Muat bertahap: frame pertama moc3 + shader, lalu satu tekstur per frame, sehingga tidak ada satu frame panjang.
  4) Karin muncul dengan fade-in 0,45 detik setelah siap.


Tahap 17: perbaikan chat menimpa Karin.
- Penyebab: root layout pakai clipChildren="false", akibatnya daftar chat tidak dipotong di batas atasnya dan bubble menimpa Karin/sobekan.
  JANGAN pasang clipChildren="false" di parent langsung RecyclerView "list".
- Panggung atas dibuat full-bleed lewat margin negatif -12dp (bukan lewat clipChildren).
- Tepi atas daftar chat memudar halus (fadingEdge) sehingga bubble seperti masuk ke bawah sobekan.
- Kertas gelap di bawah garis putih ditipiskan (sobekan 48dp), jarak ke bubble pertama jadi lebih dekat.


Tahap 18: chat dipotong mengikuti zig-zag sobekan.
- Satu profil zig-zag (res/raw/tear_profile.txt + res/drawable-nodpi/tear_edge.png, dibuat bersama) dipakai oleh tiga hal supaya selalu pas:
  1) TornRecyclerView: daftar chat dipotong (clipPath) di bawah tepi putih, jadi bubble tampak masuk ke bawah robekan.
  2) KarinView (GL): poligon penutup berwarna latar menimpa semua di bawah zig-zag, jadi badan Karin berhenti persis di tepi putih.
  3) ImageView tearEdge: tepi putih berserat + bayangan, digambar paling atas.
- Area chat (FrameLayout chatArea) naik 48dp menimpa dasar panggung (margin -48dp) dan daftar chat diberi paddingTop 48dp supaya pesan pertama
  tidak tertutup saat diam. Tinggi 48dp harus sama di: layout (chatArea/tearEdge/paddingTop), TearProfile.HEIGHT_DP.
- Saat keyboard muncul atau Karin dimatikan: mode sobekan dimatikan (chat biasa, tanpa potongan).
- Kalau ingin mengganti bentuk sobekan: jalankan gen_tear3.py (folder tools/) lalu salin tear_edge.png dan tear_profile.txt ke lokasi di atas.


Tahap 19: banyak model (ganti-ganti), model full body 简 (Jian), ekspresi, avatar di belakang/depan chat.
- Model sekarang berupa folder: app/src/main/assets/models/<id>/ berisi model.json (konfigurasi) + moc3 + physics + tekstur.
  Daftar model: assets/models/index.json. Tambah model baru = salin folder + tambahkan id di index.json.
  model.json: layout ("stage" = bust di panggung + sobekan, "full" = full body di belakang/depan chat), fps, nama file, tekstur,
  frame {zoom, offsetY}, params (peran gerak -> nama parameter model), expressions (kunci -> daftar [parameter, nilai]).
- Ganti model: TAHAN LAMA judul "Chat AI" -> menu Avatar (pilih model, posisi belakang/depan chat, ekspresi, sembunyikan).
  Ketuk judul = tampil/sembunyikan avatar. Pilihan disimpan.
- 简 (Jian): tekstur asli 8192 diperkecil ke 2048 (PNG 1,7 MB, GPU sekitar 21 MB; asli 341 MB). Untuk lebih tajam ganti
  models/jian/tex/texture_00.png dengan versi 3072 (sekitar 48 MB GPU) -- tidak perlu ubah kode.
  Gerak badan 简 dikerjakan physics model (inputnya ParamAngleX/Y/Z), jadi parameter badan sengaja tidak diisi di model.json.
  Efek animasi (air mata, bintang, kilat marah) dari motion.json diputar berulang; ekspresi menyalakan ParamSwitchN.
- Ekspresi otomatis dari emoji di balasan AI (lihat Emotion.kt): mis. 😊 pipi merah, 😠 marah, 😢 air mata, 😍 mata hati, 🤩 mata bintang, 🙄 mata putih.
  Ekspresi tangan (kiri/kanan) hanya manual lewat menu Ekspresi.
- Posisi full body: "di belakang chat" (bawaan, memenuhi seluruh layar, bubble chat menimpa avatar) atau "di depan chat"
  (permukaan transparan, menutupi area chat, sentuhan diteruskan ke chat; header dan kolom input tetap kelihatan).
  Mode "stage" (Karin) tidak berubah: panggung + sobekan.
- Keyboard muncul: avatar menyingkir sementara (semua mode).
- Kode: ModelCfg.kt, Emotion.kt, KarinAnim (slot ekspresi), KarinModel (berbasis konfigurasi + motion), KarinView (mode depan/belakang),
  ChatActivity (menu avatar). Layout: rootFrame > bgHost + chatRoot + frontHost.
