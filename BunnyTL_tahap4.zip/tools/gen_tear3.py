import numpy as np
from PIL import Image, ImageDraw, ImageFilter
rng = np.random.default_rng(7)
W, H = 2048, 250
BG = np.array([9, 9, 10], np.float32)

def noise1d(scale, amp, n=W):
    k = int(n / scale) + 4
    pts = rng.uniform(-1, 1, k)
    xs = np.arange(n) / scale
    i = np.floor(xs).astype(int); f = xs - i
    f = f * f * (3 - 2 * f)
    return amp * (pts[i] * (1 - f) + pts[i + 1] * f)

x = np.arange(W, dtype=np.float32)
u = x / (W - 1)
bump = np.cos(np.pi * (u - 0.5)) ** 2
bump = np.clip(bump * 1.25, 0, 1) ** 0.9            # tengah lebih turun, sisi naik
y1 = 64 + 74 * bump
for s, a in [(420, 22), (170, 12), (70, 6), (28, 3.4), (11, 2.0), (4, 1.2)]:
    y1 = y1 + noise1d(s, a)
# gigi / sobekan kecil acak
for _ in range(70):
    c = rng.integers(0, W); w = rng.integers(5, 26); h = rng.uniform(-13, 10)
    d = np.clip(1 - np.abs(x - c) / w, 0, 1)
    y1 = y1 + h * d
t = 20 + 20 * (noise1d(110, 1) * .5 + .5) + noise1d(24, 7) + noise1d(7, 3)
t = np.clip(t, 9, 52)
y2 = y1 + t + noise1d(5, 1.6)

Y = np.arange(H, dtype=np.float32)[:, None]

def blur2(a, sx, sy):
    im = Image.fromarray((np.clip(a, 0, 1) * 255).astype(np.uint8))
    im = im.filter(ImageFilter.GaussianBlur(sx))
    return np.asarray(im).astype(np.float32) / 255

grain = rng.random((H, W)).astype(np.float32)
fib_noise = blur2(grain, 1.0, 1.0)
fib_noise = (fib_noise - fib_noise.mean()) / (fib_noise.std() + 1e-6)
streak = blur2(rng.random((H, W)).astype(np.float32), 0.8, 0.8)
streak = (streak - streak.mean()) / (streak.std() + 1e-6)

# ---- Desain baru: HANYA tepi putih berserat (tanpa kertas gelap di bawahnya) + bayangan lembut.
# Di atas tepi = badan Karin (digambar GL), di bawah tepi = daftar chat (dipotong mengikuti zig-zag yang sama).
j1 = fib_noise * 1.3
j2 = fib_noise * 3.2 + streak * 1.2
cov_top = np.clip((Y - (y1[None, :] + j1)) / 1.4 + 0.5, 0, 1)
cov_bot = np.clip((Y - (y2[None, :] + j2)) / 2.2 + 0.5, 0, 1)
rim_a = cov_top * (1 - cov_bot)

depth = np.clip((Y - y1[None, :]) / np.maximum(t[None, :] + 1, 1), 0, 1)
base = np.array([238, 232, 221], np.float32)
shade = 1.0 - 0.18 * depth - 0.06 * np.clip(streak, -2, 2) * 0.5 - 0.05 * np.clip(fib_noise, -2, 2) * 0.5
rim_rgb = base[None, None, :] * shade[..., None]

# bayangan jatuh ke bawah (ke arah chat) dan sedikit ke sekeliling
shifted = np.zeros_like(rim_a)
shifted[6:] = rim_a[:-6]
sh = np.clip(blur2(shifted, 8, 8) * 0.62, 0, 1)

out_a = rim_a + sh * (1 - rim_a)
out_rgb = (rim_rgb * rim_a[..., None]) / np.maximum(out_a[..., None], 1e-4)
out_rgb = np.where((out_a < 0.01)[..., None], 0.0, out_rgb)
rgba = np.dstack([out_rgb, out_a * 255]).clip(0, 255).astype(np.uint8)
img = Image.fromarray(rgba, 'RGBA')

fib = Image.new('RGBA', (W, H), (0, 0, 0, 0))
d = ImageDraw.Draw(fib)
def fibers(n, ycurve, direction_deg, y_off):
    for _ in range(n):
        cx = int(rng.integers(0, W))
        sy = float(ycurve[cx]) + rng.uniform(*y_off)
        ang = np.deg2rad(rng.normal(direction_deg, 38))
        ln = rng.choice([rng.uniform(3, 12), rng.uniform(10, 28)], p=[.8, .2])
        ex, ey = cx + np.cos(ang) * ln, sy + np.sin(ang) * ln
        a = int(rng.uniform(90, 230)); c = int(rng.uniform(215, 248))
        d.line([(cx, sy), (ex, ey)], fill=(c, c - 5, c - 14, a), width=1)
fibers(2200, y1, -90, (-1, 7))      # serat ke atas (sisi badan Karin)
fibers(1500, y2, 90, (-7, 1))       # serat ke bawah (sisi chat)
for _ in range(240):
    cx = int(rng.integers(0, W)); cy = float(y1[cx]) - rng.uniform(2, 16)
    r = rng.uniform(0.6, 1.8)
    d.ellipse([cx - r, cy - r, cx + r, cy + r], fill=(235, 230, 218, int(rng.uniform(110, 210))))
fib = fib.filter(ImageFilter.GaussianBlur(0.55))
img = Image.alpha_composite(img, fib)
img.save('tear_edge.png', optimize=True)

# ---- Profil zig-zag yang dipakai kode: 1024 titik, satuan piksel gambar (tinggi gambar = H).
N = 1024
gl = np.zeros(N, np.float32)    # batas atas poligon penutup di GL (badan Karin berhenti di sini)
cut = np.zeros(N, np.float32)   # garis potong daftar chat (di tengah tebal tepi putih)
for i in range(N):
    a, b = max(0, 2 * i - 1), min(W, 2 * i + 3)
    gl[i] = y1[a:b].max() + 1.5
    c = y1[2 * i] + max(4.0, 0.5 * t[2 * i])
    cut[i] = min(c, y2[2 * i] - 3.0)
with open('tear_profile.txt', 'w') as f:
    for i in range(N):
        f.write('%.2f %.2f\n' % (gl[i], cut[i]))
np.save('profile_y1.npy', y1); np.save('profile_t.npy', t); np.save('profile_y2.npy', y2)
print('H', H, 'y1 min/max', float(y1.min()), float(y1.max()), 'y2 max', float(y2.max()),
      'gl max', float(gl.max()), 'cut max', float(cut.max()))
