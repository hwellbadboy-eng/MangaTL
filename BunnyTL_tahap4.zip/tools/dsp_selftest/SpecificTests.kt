package com.niven.mangatl

import kotlin.math.*

fun fxOut(make: () -> DspFx, os: Int, x: FloatArray, y: FloatArray): Pair<FloatArray, FloatArray> {
    val f = make(); f.update(48000, os)
    val l = x.clone(); val r = y.clone(); f.process(l, r, l.size)
    return Pair(l, r)
}

fun tAlign() {
    T.group("9. Harmonic oversampling: dry/wet sejajar fase")
    val n = 8192
    val x = noise(n, 1e-3, 61); val y = noise(n, 1e-3, 62)
    val cases = listOf<Pair<String, Pair<() -> DspFx, () -> Unit>>>(
        "Bass" to Pair({ BassFx() as DspFx }, { engineReset(); setP(AudioEngine.BASS, "Gain", 6f); setP(AudioEngine.BASS, "Harmonic Enhancement", 100f); setP(AudioEngine.BASS, "Dry/Wet", 60f) }),
        "Vocal" to Pair({ VocalFx() as DspFx }, { vocalCfg(); setP(AudioEngine.VOCAL, "Harmonic Enhancement", 100f); setP(AudioEngine.VOCAL, "De-esser Amount", 0f); setP(AudioEngine.VOCAL, "Dry/Wet", 70f) })
    )
    for ((name, c) in cases) {
        c.second()
        val (a1, _) = fxOut(c.first, 1, x, y)
        val (a4, _) = fxOut(c.first, 4, x, y)
        // sinyal kecil => tanh ~ linear, jadi os4 harus = os1 yang ditunda tepat 15 sampel
        var best = 1e9; var bestLag = 0
        for (lag in 0..20) {
            var e = 0.0; var p = 0.0
            for (i in 100 until n) { val d = (a4[i] - (if (i - lag >= 0) a1[i - lag] else 0f)).toDouble(); e += d * d; p += a1[i - lag].toDouble().pow(2) }
            val rel = e / p
            if (rel < best) { best = rel; bestLag = lag }
        }
        T.check("$name: os 4x == os 1x ditunda 15 sampel (lag terbaik=$bestLag)", bestLag == 15 && db(sqrt(best)) < -35, "galat relatif %.1f dB".format(db(sqrt(best))))
    }
}

fun tMonoChain() {
    T.group("3/5. Mono lewat DspChain (dual-mono) dan konsistensi loudness")
    engineReset(); onlyOn(AudioEngine.EQ)
    val n = 4800
    val m = sine(n, 48000, 440.0, 0.5)
    for (enc in listOf(EF, E16, E24, E32)) {
        val ch = DspChain(ctx); val o = ch.configure(48000, 1, enc)
        T.check("mono enc=$enc dikonfigurasi, keluaran stereo", o != null && o.size >= 3 && o[2] == 2)
        if (o == null) continue
        val acc = ArrayList<Float>()
        val bb = toBuffer(m, m, 0, n, enc, true)
        readOut(ch.process(bb), o[1], acc)
        val sameLR = (0 until acc.size / 2).all { acc[2 * it] == acc[2 * it + 1] }
        T.check("mono enc=$enc: jumlah frame keluaran = masukan, L==R", acc.size / 2 == n && sameLR, "frame=${acc.size / 2}")
        val peak = acc.maxOf { abs(it) }
        T.check("mono enc=$enc: amplitudo terjaga (0,5)", abs(peak - 0.5f) < 0.002f, "puncak %.4f".format(peak))
    }
}

fun tNormStatic() {
    T.group("6. Normalisasi statis memakai true peak")
    engineReset(); onlyOn(AudioEngine.NORM)
    setP(AudioEngine.NORM, "Target Loudness", -14f); setP(AudioEngine.NORM, "True Peak Limit", -1f); setP(AudioEngine.NORM, "Clipping Prevention", 1f)
    setP(AudioEngine.NORM, "Gain Range", 12f); setP(AudioEngine.NORM, "Algorithm", 1f)
    // lufs -20 -> butuh +6 dB; sample peak -3, true peak -0,5
    ctx.getSharedPreferences("audio_loudness", 0).edit().putString("t5", "-20.0,-20.0,-3.0,-0.5").apply()
    AudioEngine.currentTrackId = 5L
    val ch = DspChain(ctx); val o = ch.configure(48000, 2, EF)!!
    runChain(ch, noise(4800, 0.1, 3), noise(4800, 0.1, 4), EF, o[1])
    val gdb = AudioEngine.meterGainDb.toDouble()
    T.check("gain = target - lufs dibatasi true peak (-1 - (-0,5) = -0,5 dB)", abs(gdb + 0.5) < 0.05, "gain %.2f dB".format(gdb))
    AudioEngine.currentTrackId = -1L
}

fun tDynamic() {
    T.group("7. Normalisasi dinamis: transien, pumping")
    val sr = 48000
    engineReset(); onlyOn(AudioEngine.NORM)
    val N = AudioEngine.NORM
    setP(N, "Dynamic Normalization", 1f); setP(N, "Clipping Prevention", 1f); setP(N, "True Peak Limit", -1f)
    setP(N, "Target Loudness", -14f); setP(N, "Gain Range", 12f)
    val secs = 12
    val n = secs * sr
    val l = FloatArray(n); val r = FloatArray(n)
    for (i in 0 until n) {
        var v = 0.03 * sin(2 * PI * 1000.0 * i / sr)           // -30 dBFS
        if ((i % sr) in 0 until (0.004 * sr).toInt() && i > sr) v = 0.95 * sin(2 * PI * 3000.0 * i / sr)   // transien keras tiap detik
        l[i] = v.toFloat(); r[i] = v.toFloat()
    }
    val ch = DspChain(ctx); val o = ch.configure(sr, 2, EF)!!
    val (ol, orr) = runChain(ch, l, r, EF, o[1], 480)
    val cap = 10.0.pow(-1.0 / 20)
    val pk = max(maxAbs(ol), maxAbs(orr))
    T.check("puncak sampel keluaran <= True Peak Limit (-1 dBTP)", pk <= cap + 1e-6, "puncak %.2f dBFS (batas -1,00)".format(db(pk)))
    fun steadyAmp(from: Int, to: Int): Double { var m = 0.0; for (i in from until to) if ((i % sr) > (0.4 * sr).toInt()) m = max(m, abs(ol[i].toDouble())); return m }
    val a1 = steadyAmp(6 * sr, 8 * sr); val a2 = steadyAmp(10 * sr, 12 * sr)
    T.check("tidak pumping: level bagian tenang stabil (±1 dB) antar-periode", abs(db(a1) - db(a2)) < 1.0, "%.2f dB vs %.2f dB".format(db(a1), db(a2)))
    // bagian tenang tidak ikut ditekan guard (hanya transien yang dikurangi): gain tersisa mendekati +12 dB
    T.check("bagian tenang tetap dikoreksi (gain >= +5 dB), hanya transien yang ditekan", db(a2 / 0.03) > 5.0, "gain bagian tenang %.1f dB".format(db(a2 / 0.03)))
}

fun tCeilingResample() {
    T.group("2. Ceiling limiter tetap berlaku setelah resample / dither")
    val sr = 44100
    engineReset(); onlyOn(AudioEngine.LIMIT, AudioEngine.HIRES)
    setP(AudioEngine.LIMIT, "Ceiling", -3f); setP(AudioEngine.LIMIT, "Threshold", -3f)
    setP(AudioEngine.HIRES, "Sample Rate", 2f); setP(AudioEngine.HIRES, "Bit Depth", 1f); setP(AudioEngine.HIRES, "Dither", 1f)
    val (l, r) = limiterSignal(sr)
    val ch = DspChain(ctx); val o = ch.configure(sr, 2, EF)!!
    val (ol, orr) = runChain(ch, l, r, EF, o[1])
    val pk = max(maxAbs(ol), maxAbs(orr))
    T.check("44,1k->48k, 16-bit + dither: puncak <= ceiling -3 dBFS", pk <= 10.0.pow(-3.0 / 20) + 1e-6, "puncak %.2f dBFS, outEnc=${o[1]}".format(db(pk)))
}

fun tDither() {
    T.group("8. Dither TPDF")
    val sr = 48000
    engineReset(); onlyOn(AudioEngine.HIRES)
    setP(AudioEngine.HIRES, "Bit Depth", 1f); setP(AudioEngine.HIRES, "Dither", 1f)
    val x = sine(sr, sr, 1000.0, 0.3)
    val ch = DspChain(ctx); val o = ch.configure(sr, 2, EF)!!
    val (ol, _) = runChain(ch, x, x, EF, o[1])
    var e = 0.0; var m = 0.0; var mx = 0.0
    for (i in x.indices) { val d = (ol[i] - x[i]) * 32768.0; e += d * d; m += d; mx = max(mx, abs(d)) }
    val rms = sqrt(e / x.size); val mean = m / x.size
    T.check("galat dither: rata-rata ~0, puncak <= 2 LSB, rms ~0,8 LSB", abs(mean) < 0.05 && mx <= 2.51 && rms in 0.5..1.2, "mean %.3f rms %.3f max %.2f LSB".format(mean, rms, mx))
}


fun runCompatible() {
    tAlign(); tMonoChain(); tNormStatic(); tDynamic(); tCeilingResample(); tDither()
}
