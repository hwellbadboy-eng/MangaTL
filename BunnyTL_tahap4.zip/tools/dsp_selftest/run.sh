#!/bin/bash
# Tes DSP di JVM host (tanpa Android SDK / Gradle). Butuh: JDK 17+ dan kotlinc (2.0.x) di PATH.
# Pakai stub android.* / org.json minimal di ./stubs (hanya untuk kompilasi di host).
# Jalankan dari folder ini:  ./run.sh
set -e
HERE=$(cd "$(dirname "$0")" && pwd)
SRC=$HERE/../../app/src/main/java/com/niven/mangatl
OUT=$(mktemp -d)
mkdir -p $OUT/stubs $OUT/cls
javac -nowarn -d $OUT/stubs $(find $HERE/stubs -name "*.java")
kotlinc -nowarn -cp $OUT/stubs $SRC/DspCore.kt $SRC/DspEffects.kt $SRC/DspSpace.kt $SRC/AudioEngine.kt \
  $SRC/DspChain.kt $SRC/Loudness.kt $SRC/OutputCaps.kt $HERE/Harness.kt $HERE/CommonTests.kt \
  $HERE/SpecificTests.kt $HERE/NewApiTests.kt -d $OUT/cls
KT_HOME=$(dirname $(dirname $(readlink -f $(which kotlinc))))
kotlin -cp $OUT/cls:$OUT/stubs:$KT_HOME/lib/kotlin-stdlib.jar com.niven.mangatl.CommonTestsKt
kotlin -cp $OUT/cls:$OUT/stubs:$KT_HOME/lib/kotlin-stdlib.jar com.niven.mangatl.NewApiTestsKt
