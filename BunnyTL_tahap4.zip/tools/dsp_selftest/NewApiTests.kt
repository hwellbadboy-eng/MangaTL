package com.niven.mangatl

import kotlin.math.*

fun tLoudMonoNew() {
    T.group("3. Loudness mono: tidak dihitung ganda")
    // loudness: mono sebagai dual-mono = stereo L=R; tidak ada hitung ganda di jalur ReplayGain
    val sr = 48000
    val a = LoudAccumulator(sr); val b = LoudAccumulator(sr)
    for (i in 0 until 6 * sr) { val x = 0.1 * sin(2 * PI * 997 * i / sr); a.push(x, x); b.push(x, x) }
    val ra = a.result()!!; val rb = b.result()!!
    T.check("analisis mono (dual-mono) == stereo L=R", abs(ra.lufs - rb.lufs) < 1e-9 && abs(ra.rg - rb.rg) < 1e-9)
    // satu kanal saja (L only) lebih pelan 3,01 LU
    val c = LoudAccumulator(sr)
    for (i in 0 until 6 * sr) { val x = 0.1 * sin(2 * PI * 997 * i / sr); c.push(x, 0.0) }
    val rc = c.result()!!
    T.check("L-saja lebih pelan 3,01 LU dari dual-mono", abs((ra.lufs - rc.lufs) - 3.0103) < 0.05, "selisih %.3f".format(ra.lufs - rc.lufs))
    // ReplayGain per-kanal: mono dual dan stereo L=R sama, tidak ganda
    T.check("ReplayGain: -20 dBFS sinus dual-mono ~ rata-rata per kanal", abs(ra.rg - (db(0.1 / sqrt(2.0)) + 0.0)) < 1.0, "rg %.2f".format(ra.rg))

}

fun tTruePeak() {
    T.group("6. True Peak")
    val sr = 48000
    // sinus fs/4 fase 45 deg: sample peak 0.707, true peak 1.0
    val acc = LoudAccumulator(sr)
    for (i in 0 until 3 * sr) { val x = sin(2 * PI * (sr / 4.0) * i / sr + PI / 4); acc.push(x, x) }
    val r = acc.result()!!
    T.check("sample peak -3,01 dBFS", abs(r.peakDb + 3.01) < 0.05, "%.2f".format(r.peakDb))
    T.check("true peak ~ 0 dBTP (±0,2)", abs(r.tpDb) < 0.2, "%.3f dBTP".format(r.tpDb))
    // derau pita-terbatas (seperti musik, < 0,35 fs): bandingkan dengan referensi 8x
    val g = Rng(9)
    val raw = DoubleArray(30000) { g.next() }
    val lp = ButterCascade(); lp.design(sr, 0.35 * sr, 8, false)
    val x = FloatArray(raw.size) { (1.6 * lp.process(raw[it])).toFloat() }
    val peak0 = x.maxOf { abs(it) }.toDouble()
    for (i in x.indices) x[i] = (x[i] * (0.9 / peak0)).toFloat()
    val a2 = LoudAccumulator(sr)
    for (v in x) a2.push(v.toDouble(), v.toDouble())
    val ref = db(refTruePeak(x))
    val sp = db(x.maxOf { abs(it) }.toDouble())
    val est = a2.result()!!.tpDb
    T.check("derau pita-terbatas: estimasi TP dekat referensi 8x (selisih <0,3 dB, tidak di bawah sample peak)", abs(est - ref) < 0.3 && est >= sp - 1e-9, "estimasi %.2f, ref %.2f, sample %.2f".format(est, ref, sp))
    for (rate in listOf(44100, 96000, 192000)) {
        val a3 = LoudAccumulator(rate)
        for (i in 0 until 3 * rate) { val v = sin(2 * PI * (rate / 4.0) * i / rate + PI / 4); a3.push(v, v) }
        val rr = a3.result()!!
        T.check("TP @$rate Hz sinus fs/4", abs(rr.tpDb) < 0.25 || (rate >= 192000 && rr.tpDb > -3.2), "%.2f dBTP (sample %.2f)".format(rr.tpDb, rr.peakDb))
    }
}


fun tStatus() {
    T.group("5/10. Status DSP dan bit-perfect")
    engineReset(); onlyOn(AudioEngine.EQ)
    AudioEngine.dspStatus = ""
    val ch = DspChain(ctx)
    val o6 = ch.configure(48000, 6, EF)
    T.check("6 kanal: bypass + status jelas", o6 == null && AudioEngine.dspStatus.contains("6 kanal"), "status='${AudioEngine.dspStatus}'")
    val o1 = ch.configure(48000, 1, EF)
    T.check("mono setelah multikanal: status dibersihkan", o1 != null && AudioEngine.dspStatus.isEmpty(), "status='${AudioEngine.dspStatus}'")
    // bit-perfect dipilih tapi tak tersedia (tanpa DAC): efek tetap jalan + status
    engineReset(); onlyOn(AudioEngine.EQ, AudioEngine.HIRES)
    setP(AudioEngine.EQ, "Preamp", 6f); setP(AudioEngine.HIRES, "Bit-perfect", 1f)
    val c2 = DspChain(ctx); val o = c2.configure(48000, 2, EF)!!
    val x = sine(2400, 48000, 1000.0, 0.2)
    val (ol, _) = runChain(c2, x, x, EF, o[1])
    val pk = maxAbs(ol, 200)
    T.check("bit-perfect tak tersedia: efek tetap berjalan (preamp +6 dB)", abs(db(pk / 0.2) - 6.0) < 0.5, "gain %.2f dB".format(db(pk / 0.2)))
    T.check("status menjelaskan bit-perfect tidak tersedia", AudioEngine.dspStatus.contains("tidak tersedia"), "status='${AudioEngine.dspStatus}'")
    // master dimatikan saat Hi-Res nyala => jalur output disusun ulang
    engineReset(); onlyOn(AudioEngine.HIRES)
    val v0 = AudioEngine.outputVersion
    AudioEngine.setMaster(false)
    T.check("setMaster() dengan Hi-Res nyala memicu susun ulang output", AudioEngine.outputVersion > v0)
    AudioEngine.setMaster(true)
    // info keluaran aktual
    engineReset(); onlyOn(AudioEngine.HIRES)
    setP(AudioEngine.HIRES, "Bit Depth", 2f); setP(AudioEngine.HIRES, "Sample Rate", 4f)
    DspChain(ctx).configure(44100, 2, E16)
    T.check("info keluaran aktual: 24 bit wadah float, 96 kHz", AudioEngine.outputInfo.startsWith("24 bit") && AudioEngine.outputInfo.contains("96.0"), AudioEngine.outputInfo)
}

fun tGuardReset() {
    T.group("7/4. PeakGuard reset")
    val sr = 48000
    val g1 = PeakGuard(sr); val g2 = PeakGuard(sr)
    val x = noise(5000, 1.5, 81); val y = noise(5000, 0.5, 82)
    g1.process(x.clone(), x.clone(), 5000); g1.reset()
    val a = y.clone(); val b = y.clone(); g1.process(a, b, 5000)
    val c = y.clone(); val d = y.clone(); g2.process(c, d, 5000)
    var df = 0.0; for (i in 0 until 5000) df = max(df, abs(a[i] - c[i]).toDouble())
    T.check("PeakGuard.reset() = instans baru", df == 0.0, "%.2e".format(df))
    T.check("PeakGuard menjamin puncak <= ceiling", max(maxAbs(c), maxAbs(d)) <= 1.0 + 1e-9, "%.4f".format(maxAbs(c)))
}

fun main() {
    tStatus(); runCompatible(); tLoudMonoNew(); tTruePeak(); tGuardReset()
    val f = T.summary()
    System.exit(if (f == 0) 0 else 1)
}
