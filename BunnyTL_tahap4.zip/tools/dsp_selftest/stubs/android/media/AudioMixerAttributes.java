package android.media;
public class AudioMixerAttributes { public static final int MIXER_BEHAVIOR_BIT_PERFECT = 1; public int getMixerBehavior() { return 0; } }
