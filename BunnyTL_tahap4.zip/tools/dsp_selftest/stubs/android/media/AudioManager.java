package android.media;
import java.util.List;
public class AudioManager {
    public static final int GET_DEVICES_OUTPUTS = 2;
    public AudioDeviceInfo[] getDevices(int f) { return new AudioDeviceInfo[0]; }
    public List<AudioMixerAttributes> getSupportedMixerAttributes(AudioDeviceInfo d) { return new java.util.ArrayList<>(); }
    public boolean setPreferredMixerAttributes(AudioAttributes a, AudioDeviceInfo d, AudioMixerAttributes m) { return true; }
    public boolean clearPreferredMixerAttributes(AudioAttributes a, AudioDeviceInfo d) { return true; }
}
