package android.media;
public class AudioFormat { public static final int ENCODING_PCM_16BIT = 2; public static final int ENCODING_PCM_FLOAT = 4; }
