package android.media;
import java.nio.ByteBuffer;
public class MediaExtractor {
    public void setDataSource(android.content.Context c, android.net.Uri u, java.util.Map<String,String> h) throws java.io.IOException {}
    public int getTrackCount(){return 0;} public MediaFormat getTrackFormat(int i){return null;} public void selectTrack(int i){}
    public int readSampleData(ByteBuffer b,int o){return -1;} public long getSampleTime(){return 0;} public boolean advance(){return false;} public void release(){}
}
