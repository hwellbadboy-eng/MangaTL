package android.media;
public class AudioDeviceInfo {
    public static final int TYPE_USB_DEVICE = 11; public static final int TYPE_USB_HEADSET = 22;
    public int getType() { return 0; } public CharSequence getProductName() { return ""; } public int[] getSampleRates() { return new int[0]; }
}
