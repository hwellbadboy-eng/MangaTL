package android.media;
import java.nio.ByteBuffer;
public class MediaCodec {
    public static final int BUFFER_FLAG_END_OF_STREAM=4, INFO_OUTPUT_FORMAT_CHANGED=-2;
    public static class BufferInfo { public int offset, size, flags; }
    public static MediaCodec createDecoderByType(String t) throws java.io.IOException { return new MediaCodec(); }
    public void configure(MediaFormat f, Object s, Object c, int fl){} public void start(){} public void stop(){} public void release(){}
    public int dequeueInputBuffer(long t){return -1;} public ByteBuffer getInputBuffer(int i){return null;}
    public void queueInputBuffer(int i,int o,int s,long t,int f){} public int dequeueOutputBuffer(BufferInfo i,long t){return -1;}
    public ByteBuffer getOutputBuffer(int i){return null;} public void releaseOutputBuffer(int i, boolean r){} public MediaFormat getOutputFormat(){return null;}
}
