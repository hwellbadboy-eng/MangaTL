package android.provider;
import android.net.Uri;
public class MediaStore {
    public static class Audio { public static class Media {
        public static final Uri EXTERNAL_CONTENT_URI = new Uri();
        public static final String _ID = "_id";
        public static final String ALBUM_ID = "album_id";
    } }
}
