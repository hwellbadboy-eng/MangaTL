package android.content;
import java.util.HashMap;
public class Context {
    public static final int MODE_PRIVATE = 0;
    public static final String AUDIO_SERVICE = "audio";
    private final HashMap<String, Object> store = new HashMap<>();
    public SharedPreferences getSharedPreferences(String name, int mode) {
        return new SharedPreferences() {
            public String getString(String k, String d) { Object o = store.get(name + k); return o == null ? d : (String) o; }
            public boolean getBoolean(String k, boolean d) { Object o = store.get(name + k); return o == null ? d : (Boolean) o; }
            public Editor edit() {
                return new Editor() {
                    public Editor putString(String k, String v) { store.put(name + k, v); return this; }
                    public Editor putBoolean(String k, boolean v) { store.put(name + k, v); return this; }
                    public Editor clear() { store.clear(); return this; }
                    public void apply() {}
                };
            }
        };
    }
    public Context getApplicationContext() { return this; }
    public ContentResolver getContentResolver() { return new ContentResolver(); }
    public Object getSystemService(String n) { return null; }
}
