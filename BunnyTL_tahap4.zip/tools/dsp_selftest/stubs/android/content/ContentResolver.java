package android.content;
import android.database.Cursor;
import android.net.Uri;
public class ContentResolver {
    public Cursor query(Uri u, String[] p, String s, String[] a, String o) { return null; }
}
