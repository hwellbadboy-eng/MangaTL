package org.json;
import java.util.ArrayList;
public class JSONArray {
    private final ArrayList<Object> l = new ArrayList<>();
    public JSONArray put(double d){ l.add(d); return this; }
    public int length(){ return l.size(); }
    public double optDouble(int i, double d){ return i < l.size() ? (Double) l.get(i) : d; }
}
