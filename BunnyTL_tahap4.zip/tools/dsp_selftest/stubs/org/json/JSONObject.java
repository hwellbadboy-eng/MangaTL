package org.json;
import java.util.HashMap;
public class JSONObject {
    private final HashMap<String,Object> m = new HashMap<>();
    public JSONObject(){}
    public JSONObject(String s) throws JSONException { throw new JSONException("stub"); }
    public JSONObject put(String k, Object v){ m.put(k, v); return this; }
    public JSONObject put(String k, boolean v){ m.put(k, v); return this; }
    public JSONObject put(String k, int v){ m.put(k, v); return this; }
    public boolean optBoolean(String k, boolean d){ return d; }
    public JSONObject optJSONObject(String k){ return null; }
    public JSONArray optJSONArray(String k){ return null; }
    public int optInt(String k, int d){ return d; }
    public String toString(){ return "{}"; }
}
