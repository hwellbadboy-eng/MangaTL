package com.niven.mangatl
fun main() {
    runCompatible()
    val f = T.summary()
    System.exit(if (f == 0) 0 else 1)
}
