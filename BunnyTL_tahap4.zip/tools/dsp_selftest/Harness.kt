package com.niven.mangatl

import android.content.Context
import java.nio.ByteBuffer
import java.nio.ByteOrder
import kotlin.math.*

/** Pelari tes sederhana (tanpa JUnit) untuk dijalankan di JVM host dengan stub Android. */
object T {
    var pass = 0
    var fail = 0
    val failed = ArrayList<String>()
    var group = ""

    fun check(name: String, ok: Boolean, detail: String = "") {
        if (ok) pass++ else { fail++; failed.add("$group :: $name  $detail") }
        println((if (ok) "  PASS " else "  FAIL ") + name + (if (detail.isNotEmpty()) "  [$detail]" else ""))
    }

    fun group(g: String) {
        group = g
        println("== $g")
    }

    fun summary(): Int {
        println()
        println("HASIL: $pass lulus, $fail gagal")
        for (f in failed) println("  GAGAL: $f")
        return fail
    }
}

val ctx = Context()

fun engineReset() {
    AudioEngine.init(ctx)
    AudioEngine.resetAll()
}

fun pidx(fid: String, name: String): Int {
    val i = AudioEngine.feature(fid).params.indexOfFirst { it.name == name }
    require(i >= 0) { "param $name tidak ada di $fid" }
    return i
}

fun setP(fid: String, name: String, v: Float) = AudioEngine.set(fid, pidx(fid, name), v)

fun onlyOn(vararg ids: String) {
    for (f in AudioEngine.features) AudioEngine.setOn(f.id, f.id in ids)
}

fun db(x: Double) = 20.0 * log10(max(x, 1e-12))

/** Generator sinyal. */
class Rng(seed: Long) {
    private var s = seed
    fun next(): Double {
        s = s * 6364136223846793005L + 1442695040888963407L
        return ((s ushr 11).toDouble() / (1L shl 53).toDouble()) * 2.0 - 1.0
    }
}

fun sine(n: Int, sr: Int, f: Double, amp: Double, phase: Double = 0.0, start: Int = 0) =
    FloatArray(n) { (amp * sin(2 * PI * f * (it + start) / sr + phase)).toFloat() }

/** Kirim sinyal float stereo lewat chain per blok; kembalikan keluaran float (stereo) berdasarkan outEnc. */
class Run(val l: FloatArray, val r: FloatArray, val enc: Int)

fun toBuffer(l: FloatArray, r: FloatArray, from: Int, n: Int, enc: Int, mono: Boolean = false): ByteBuffer {
    val ch = if (mono) 1 else 2
    val bps = when (enc) { 2 -> 2; 21 -> 3; else -> 4 }
    val bb = ByteBuffer.allocateDirect(n * ch * bps).order(ByteOrder.nativeOrder())
    for (i in from until from + n) {
        for (c in 0 until ch) {
            val x = if (c == 0) l[i] else r[i]
            when (enc) {
                4 -> bb.putFloat(x)
                2 -> bb.putShort((x * 32768f).roundToInt().coerceIn(-32768, 32767).toShort())
                22 -> bb.putInt((x.toDouble() * 2147483648.0).roundToLong().coerceIn(Int.MIN_VALUE.toLong(), Int.MAX_VALUE.toLong()).toInt())
                21 -> {
                    val v = (x * 8388608f).roundToInt().coerceIn(-8388608, 8388607)
                    bb.put((v and 0xFF).toByte()); bb.put(((v shr 8) and 0xFF).toByte()); bb.put(((v shr 16) and 0xFF).toByte())
                }
            }
        }
    }
    bb.flip()
    return bb
}

fun readOut(bb: ByteBuffer, outEnc: Int, sink: ArrayList<Float>) {
    val d = bb.duplicate().order(ByteOrder.nativeOrder())
    while (d.remaining() >= (if (outEnc == 4) 4 else 2)) {
        if (outEnc == 4) sink.add(d.float) else sink.add(d.short / 32768f)
    }
}

/** Jalankan chain pada sinyal stereo; kembalikan (kiri, kanan) hasil. */
fun runChain(chain: DspChain, l: FloatArray, r: FloatArray, enc: Int, outEnc: Int, blk: Int = 1024): Pair<FloatArray, FloatArray> {
    val acc = ArrayList<Float>()
    var p = 0
    while (p < l.size) {
        val n = min(blk, l.size - p)
        val inb = toBuffer(l, r, p, n, enc)
        val out = chain.process(inb)
        readOut(out, outEnc, acc)
        p += n
    }
    val n = acc.size / 2
    return Pair(FloatArray(n) { acc[2 * it] }, FloatArray(n) { acc[2 * it + 1] })
}

fun maxAbs(a: FloatArray, from: Int = 0, to: Int = a.size): Double {
    var m = 0.0
    for (i in from until to) m = max(m, abs(a[i].toDouble()))
    return m
}

fun allFinite(a: FloatArray): Boolean = a.all { it.isFinite() }

fun noise(n: Int, amp: Double, seed: Long) = Rng(seed).let { g -> FloatArray(n) { (amp * g.next()).toFloat() } }

/** Referensi true-peak offline: interpolasi sinc berjendela (jendela panjang) pada 8x. */
fun refTruePeak(x: FloatArray, os: Int = 8, half: Int = 64): Double {
    var pk = 0.0
    val n = x.size
    for (i in half until n - half) {
        for (p in 0 until os) {
            val t = p.toDouble() / os
            var s = 0.0
            for (k in -half + 1..half) {
                val d = t - k
                val sinc = if (abs(d) < 1e-12) 1.0 else sin(PI * d) / (PI * d)
                val w = 0.5 + 0.5 * cos(PI * d / half) // Hann
                s += x[i + k] * sinc * w
            }
            pk = max(pk, abs(s))
        }
    }
    return pk
}
