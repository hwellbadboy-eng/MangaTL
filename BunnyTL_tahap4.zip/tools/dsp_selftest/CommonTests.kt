package com.niven.mangatl

import kotlin.math.*

const val E16 = 2
const val EF = 4
const val E24 = 21
const val E32 = 22

// ---------- 1. FFT ----------
fun tFft() {
    T.group("1. FFT forward/inverse")
    val n = 1024
    val g = Rng(1)
    val re = DoubleArray(n) { g.next() }
    val im = DoubleArray(n) { g.next() }
    val r0 = re.clone(); val i0 = im.clone()
    Fft.transform(re, im, false)
    Fft.transform(re, im, true)
    var err = 0.0
    for (i in 0 until n) err = max(err, max(abs(re[i] - r0[i]), abs(im[i] - i0[i])))
    T.check("round-trip forward->inverse (n=1024)", err < 1e-12, "galat maks %.3e".format(err))

    // bandingkan dengan DFT naif
    val m = 64
    val a = DoubleArray(m) { g.next() }
    val b = DoubleArray(m) { g.next() }
    val fr = a.clone(); val fi = b.clone()
    Fft.transform(fr, fi, false)
    var e2 = 0.0
    for (k in 0 until m) {
        var sr = 0.0; var si = 0.0
        for (t in 0 until m) {
            val ang = -2 * PI * k * t / m
            sr += a[t] * cos(ang) - b[t] * sin(ang)
            si += a[t] * sin(ang) + b[t] * cos(ang)
        }
        e2 = max(e2, max(abs(sr - fr[k]), abs(si - fi[k])))
    }
    T.check("forward sama dengan DFT naif (n=64)", e2 < 1e-9, "galat maks %.3e".format(e2))

    // sinus murni di bin 5 -> puncak di bin 5 dan n-5
    val sr2 = DoubleArray(m) { cos(2 * PI * 5 * it / m) }
    val si2 = DoubleArray(m)
    Fft.transform(sr2, si2, false)
    T.check("sinus bin 5: magnitudo m/2 di bin 5", abs(hypot(sr2[5], si2[5]) - m / 2.0) < 1e-9)
    // inverse menyatakan pembagian n (bukan 1): impuls -> konstan 1/n
    val ire = DoubleArray(m); ire[0] = 1.0
    val iim = DoubleArray(m)
    Fft.transform(ire, iim, true)
    T.check("inverse impuls = 1/n", abs(ire[3] - 1.0 / m) < 1e-15 && abs(iim[3]) < 1e-15)
    // Parseval
    val pr = DoubleArray(256) { g.next() }; val pi2 = DoubleArray(256) { g.next() }
    var et = 0.0; for (i in 0 until 256) et += pr[i] * pr[i] + pi2[i] * pi2[i]
    Fft.transform(pr, pi2, false)
    var ef = 0.0; for (i in 0 until 256) ef += pr[i] * pr[i] + pi2[i] * pi2[i]
    T.check("Parseval", abs(ef / 256 - et) < 1e-9 * et)
}

// ---------- 2. Resampling ----------
fun fitSine(y: FloatArray, from: Int, to: Int, sr: Int, f: Double): Pair<Double, Double> {
    // kuadrat terkecil a*cos + b*sin ; kembalikan (amplitudo, rasio residu)
    var scc = 0.0; var sss = 0.0; var scs = 0.0; var syc = 0.0; var sys = 0.0; var syy = 0.0
    for (i in from until to) {
        val w = 2 * PI * f * i / sr
        val c = cos(w); val s = sin(w); val v = y[i].toDouble()
        scc += c * c; sss += s * s; scs += c * s; syc += v * c; sys += v * s; syy += v * v
    }
    val det = scc * sss - scs * scs
    val a = (syc * sss - sys * scs) / det
    val b = (sys * scc - syc * scs) / det
    val amp = hypot(a, b)
    var res = 0.0
    for (i in from until to) {
        val w = 2 * PI * f * i / sr
        val d = y[i] - (a * cos(w) + b * sin(w)); res += d * d
    }
    return Pair(amp, sqrt(res / (to - from)) / max(amp, 1e-12))
}

fun resampleAll(inRate: Int, outRate: Int, minPhase: Boolean, l: FloatArray, r: FloatArray, blk: Int): Pair<FloatArray, FloatArray> {
    val rs = Resampler(inRate, outRate, minPhase)
    val ol = ArrayList<Float>(); val orr = ArrayList<Float>()
    var p = 0
    while (p < l.size) {
        val n = min(blk, l.size - p)
        rs.process(l.copyOfRange(p, p + n), r.copyOfRange(p, p + n), n)
        for (i in 0 until rs.outN) { ol.add(rs.outL[i]); orr.add(rs.outR[i]) }
        p += n
    }
    return Pair(ol.toFloatArray(), orr.toFloatArray())
}

fun tResample() {
    T.group("2. Resampling")
    val pairs = listOf(44100 to 48000, 48000 to 44100, 96000 to 48000, 48000 to 96000, 44100 to 88200, 48000 to 192000)
    for ((a, b) in pairs) for (mp in listOf(false, true)) {
        val n = a // 1 detik
        val l = sine(n, a, 1000.0, 0.5)
        val r = sine(n, a, 2000.0, 0.25)
        val (ol, orr) = resampleAll(a, b, mp, l, r, 1000)
        val expect = n.toLong() * b / a
        val cntOk = abs(ol.size - expect) <= 3
        val s0 = (ol.size * 0.2).toInt(); val s1 = (ol.size * 0.8).toInt()
        val (ampL, resL) = fitSine(ol, s0, s1, b, 1000.0)
        val (ampR, resR) = fitSine(orr, s0, s1, b, 2000.0)
        val gl = db(ampL / 0.5); val gr = db(ampR / 0.25)
        val tag = "$a->$b ${if (mp) "min-phase" else "linear"}"
        T.check("$tag jumlah sampel", cntOk, "dapat ${ol.size}, harap ~$expect")
        T.check("$tag gain 1k/2k dalam ±0,1 dB", abs(gl) < 0.1 && abs(gr) < 0.1, "L %.3f dB, R %.3f dB".format(gl, gr))
        T.check("$tag residu < -55 dB", db(resL) < -55 && db(resR) < -55, "L %.1f dB, R %.1f dB".format(db(resL), db(resR)))
        T.check("$tag kanal L/R tidak bocor (frekuensi berbeda)", fitSine(ol, s0, s1, b, 2000.0).first < 0.002)
    }
    // invarian ukuran blok
    val l = noise(8000, 0.5, 5); val r = noise(8000, 0.5, 6)
    val (a1, _) = resampleAll(44100, 48000, false, l, r, 4000)
    val (a2, _) = resampleAll(44100, 48000, false, l, r, 333)
    val m = min(a1.size, a2.size)
    var d = 0.0; for (i in 0 until m) d = max(d, abs(a1[i] - a2[i]).toDouble())
    T.check("keluaran sama untuk ukuran blok berbeda", d < 1e-6 && abs(a1.size - a2.size) <= 1, "selisih maks %.2e".format(d))
}

// ---------- 3. Mono / stereo, 10. bypass ----------
fun tChannels() {
    T.group("3/5. Mono dan stereo di DspChain")
    engineReset()
    val c = DspChain(ctx)
    T.check("stereo 16-bit dikonfigurasi", c.configure(48000, 2, E16) != null)
    T.check("stereo float dikonfigurasi", c.configure(48000, 2, EF) != null)
    T.check("stereo 24-bit dikonfigurasi", c.configure(48000, 2, E24) != null)
    T.check("stereo 32-bit dikonfigurasi", c.configure(48000, 2, E32) != null)
    T.check("MONO dikonfigurasi (tidak dilewati diam-diam)", c.configure(48000, 1, EF) != null)
    T.check("5.1 (6 kanal) ditolak dengan jelas (bypass)", c.configure(48000, 6, EF) == null)
}

fun tBypass() {
    T.group("10. Bypass DSP dan identitas format")
    for (enc in listOf(EF, E16, E24, E32)) {
        val l = noise(5000, 0.8, 11); val r = noise(5000, 0.8, 12)
        // kuantisasi masukan ke grid format supaya perbandingan sah
        val ql = FloatArray(l.size); val qr = FloatArray(r.size)
        val b = toBuffer(l, r, 0, l.size, enc)
        val src = b.duplicate().order(java.nio.ByteOrder.nativeOrder())
        for (i in l.indices) {
            when (enc) {
                EF -> { ql[i] = src.float; qr[i] = src.float }
                E16 -> { ql[i] = src.short / 32768f; qr[i] = src.short / 32768f }
                E32 -> { ql[i] = (src.int / 2147483648.0).toFloat(); qr[i] = (src.int / 2147483648.0).toFloat() }
                else -> for (cc in 0..1) {
                    val b0 = src.get().toInt() and 0xFF; val b1 = src.get().toInt() and 0xFF; val b2 = src.get().toInt()
                    val v = (b2 shl 16) or (b1 shl 8) or b0
                    if (cc == 0) ql[i] = v / 8388608f else qr[i] = v / 8388608f
                }
            }
        }
        // (a) master mati
        engineReset(); AudioEngine.setMaster(false)
        var ch = DspChain(ctx)
        var o = ch.configure(48000, 2, enc)!!
        var (ol, orr) = runChain(ch, l.let { it }, r, enc, o[1])
        var diff = 0.0
        for (i in ql.indices) diff = max(diff, max(abs(ol[i] - ql[i]), abs(orr[i] - qr[i])).toDouble())
        T.check("master mati, enc=$enc: keluaran identik dengan masukan", diff < 1e-6 || (enc == E24 || enc == E32) && diff < 1e-6, "selisih %.2e, outEnc=${o[1]}".format(diff))
        // (b) master hidup tapi semua fitur mati
        engineReset(); onlyOn()
        ch = DspChain(ctx)
        o = ch.configure(48000, 2, enc)!!
        val res = runChain(ch, l, r, enc, o[1]); ol = res.first; orr = res.second
        diff = 0.0
        for (i in ql.indices) diff = max(diff, max(abs(ol[i] - ql[i]), abs(orr[i] - qr[i])).toDouble())
        val tol = if (o[1] == E16) 1e-9 else 1e-6
        T.check("semua fitur mati, enc=$enc: keluaran identik (tanpa selisih kuantisasi)", diff <= tol, "selisih %.2e (%.2f LSB16)".format(diff, diff * 32768))
    }
}

// ---------- 4. Limiter ceiling ----------
fun limiterSignal(sr: Int): Pair<FloatArray, FloatArray> {
    val n = 2 * sr
    val l = FloatArray(n); val r = FloatArray(n)
    val g = Rng(77)
    for (i in 0 until n) {
        val t = i.toDouble() / sr
        val env = when { t < 0.4 -> 1.0; t < 0.8 -> 0.5; t < 1.2 -> 0.0; else -> 1.0 }
        var x = env * sin(2 * PI * 997 * t)
        var y = env * 0.9 * sin(2 * PI * 61 * t + 1)
        if (t >= 1.2 && t < 1.6) { x = g.next().coerceIn(-1.0, 1.0); y = (g.next() * 1.5).coerceIn(-1.0, 1.0) }
        if (t >= 1.6 && i % 3000 == 0) { x = 1.0; y = -1.0 }
        // puncak antar-sampel: sinus fs/4 fase 45 derajat
        if (t >= 0.8 && t < 1.2) { x = sin(2 * PI * (sr / 4.0) * t + PI / 4); y = x }
        l[i] = x.toFloat(); r[i] = y.toFloat()
    }
    return Pair(l, r)
}

fun tLimiter() {
    T.group("2. Limiter: ceiling vs Output Gain / makeup / clamp")
    val sr = 48000
    val (l, r) = limiterSignal(sr)
    var worstOver = -999.0
    var worstCase = ""
    val combos = ArrayList<Triple<Float, Float, Float>>() // thr, ceil, outG
    for (thr in listOf(-24f, -6f, -1f, 0f)) for (ceil in listOf(-12f, -6f, -3f, -1f, 0f)) for (og in listOf(-24f, -6f, 0f, 3f, 6f, 12f, 24f)) combos.add(Triple(thr, ceil, og))
    var viol = 0
    var firstViol = ""
    for ((thr, ceil, og) in combos) {
        engineReset(); onlyOn(AudioEngine.LIMIT)
        setP(AudioEngine.LIMIT, "Threshold", thr); setP(AudioEngine.LIMIT, "Ceiling", ceil); setP(AudioEngine.LIMIT, "Output Gain", og)
        val ch = DspChain(ctx)
        val o = ch.configure(sr, 2, EF)!!
        val (ol, orr) = runChain(ch, l, r, EF, o[1])
        val pk = max(maxAbs(ol), maxAbs(orr))
        val over = db(pk) - ceil
        if (over > worstOver) { worstOver = over; worstCase = "thr=$thr ceil=$ceil outG=$og" }
        if (pk > 10.0.pow(ceil / 20.0) * (1 + 1e-6)) { viol++; if (firstViol.isEmpty()) firstViol = "thr=$thr ceil=$ceil outG=$og puncak=%.2f dBFS".format(db(pk)) }
    }
    T.check("puncak sampel keluaran <= ceiling untuk ${combos.size} kombinasi", viol == 0, "$viol pelanggaran; contoh pertama: $firstViol; terburuk +%.2f dB di %s".format(worstOver, worstCase))
}

// ---------- 5. Loudness ----------
fun measureSine(sr: Int, ampDb: Double, seconds: Int = 6, dualMono: Boolean = true): Pair<Double, Double> {
    val m = LoudMeter(sr)
    val a = 10.0.pow(ampDb / 20.0)
    for (i in 0 until seconds * sr) {
        val x = (a * sin(2 * PI * 997.0 * i / sr)).toFloat()
        m.push(x, if (dualMono) x else 0f)
    }
    return Pair(m.momentary, m.shortTerm)
}

fun tLufs() {
    T.group("3. Loudness (LUFS)")
    for (sr in listOf(48000, 44100, 96000)) {
        val (mo, st) = measureSine(sr, -23.0)
        T.check("sinus 997 Hz -23 dBFS stereo @${sr}: -23,0 LUFS ±0,2", abs(mo + 23.0) < 0.2 && abs(st + 23.0) < 0.2, "momentary %.3f, short-term %.3f".format(mo, st))
    }
    val (a, _) = measureSine(48000, -23.0, 4, true)
    val (b, _) = measureSine(48000, -23.0, 4, false)
    T.check("L=R lebih keras 3,01 LU dari satu kanal (konvensi BS.1770)", abs((a - b) - 3.0103) < 0.05, "selisih %.3f".format(a - b))
}

// ---------- 4/11. Reset state ----------
class FxCase(val name: String, val os: Int, val make: () -> DspFx, val cfg: () -> Unit)

fun fxCases(): List<FxCase> = listOf(
    FxCase("EQ", 1, { EqFx() }) {
        engineReset(); AudioEngine.setOn(AudioEngine.EQ, true)
        val e = AudioEngine.eqBands
        for (b in 0 until 10) { e[b * 5 + 1] = if (b % 2 == 0) 6f else -6f }
        setP(AudioEngine.EQ, "Preamp", -3f)
    },
    FxCase("Bass", 1, { BassFx() }) {
        engineReset(); setP(AudioEngine.BASS, "Gain", 10f); setP(AudioEngine.BASS, "Harmonic Enhancement", 60f)
    },
    FxCase("Bass + oversampling 4x", 4, { BassFx() }) {
        engineReset(); setP(AudioEngine.BASS, "Gain", 10f); setP(AudioEngine.BASS, "Harmonic Enhancement", 60f)
    },
    FxCase("Vocal", 1, { VocalFx() }) { vocalCfg() },
    FxCase("Vocal + oversampling 4x", 4, { VocalFx() }) { vocalCfg() },
    FxCase("Stereo", 1, { StereoFx() }) {
        engineReset(); setP(AudioEngine.STEREO, "Width", 160f); setP(AudioEngine.STEREO, "Frequency-dependent Width", 1f); setP(AudioEngine.STEREO, "Mono Compatibility", 1f)
    },
    FxCase("Spatial", 1, { SpatialFx() }) {
        engineReset(); setP(AudioEngine.SPATIAL, "Intensity", 100f); setP(AudioEngine.SPATIAL, "Room Simulation", 1f); setP(AudioEngine.SPATIAL, "Reflections", 60f)
    },
    FxCase("Crossfeed", 1, { CrossFx() }) {
        engineReset(); setP(AudioEngine.XFEED, "Level", 60f)
    },
    FxCase("Reverb", 1, { ReverbFx() }) {
        engineReset(); setP(AudioEngine.REVERB, "Wet", 60f); setP(AudioEngine.REVERB, "Decay Time", 3f)
    },
    FxCase("Compressor", 1, { CompFx() }) {
        engineReset(); setP(AudioEngine.COMP, "Threshold", -30f); setP(AudioEngine.COMP, "Ratio", 6f); setP(AudioEngine.COMP, "Detector", 1f)
        setP(AudioEngine.COMP, "Sidechain HPF", 120f)
    },
    FxCase("Limiter", 1, { LimitFx() }) {
        engineReset(); setP(AudioEngine.LIMIT, "Threshold", -12f)
    }
)

fun vocalCfg() {
    engineReset()
    val f = AudioEngine.VOCAL
    setP(f, "Vocal Gain", 6f); setP(f, "Presence", 5f); setP(f, "Clarity", 70f); setP(f, "Intensity", 100f)
    setP(f, "Vocal Width", 150f); setP(f, "Harmonic Enhancement", 60f); setP(f, "De-esser Amount", 60f)
}

fun tFxReset() {
    T.group("4/11. Reset state per efek (pergantian lagu / seek)")
    val n = 6000
    val xl = noise(n, 0.7, 21); val xr = noise(n, 0.7, 22)
    val yl = noise(n, 0.5, 23); val yr = noise(n, 0.5, 24)
    for (c in fxCases()) {
        c.cfg()
        val a = c.make(); a.update(48000, c.os)
        val b = c.make(); b.update(48000, c.os)
        // a: proses x, reset, lalu y ; b: baru, hanya y
        a.process(xl.clone(), xr.clone(), n)
        a.reset()
        val al = yl.clone(); val ar = yr.clone(); a.process(al, ar, n)
        val bl = yl.clone(); val br = yr.clone(); b.process(bl, br, n)
        var d = 0.0
        for (i in 0 until n) d = max(d, max(abs(al[i] - bl[i]), abs(ar[i] - br[i])).toDouble())
        T.check("${c.name}: setelah reset() sama dengan instans baru", d < 1e-6, "selisih maks %.3e".format(d))
    }
}

fun configureAllActive() {
    engineReset()
    onlyOn(AudioEngine.EQ, AudioEngine.BASS, AudioEngine.VOCAL, AudioEngine.STEREO, AudioEngine.SPATIAL, AudioEngine.XFEED,
        AudioEngine.REVERB, AudioEngine.COMP, AudioEngine.LIMIT)
    val e = AudioEngine.eqBands
    for (b in 0 until 10) e[b * 5 + 1] = if (b % 2 == 0) 4f else -4f
    setP(AudioEngine.BASS, "Gain", 8f); setP(AudioEngine.BASS, "Harmonic Enhancement", 40f)
    val v = AudioEngine.VOCAL
    setP(v, "Vocal Gain", 4f); setP(v, "Presence", 4f); setP(v, "Clarity", 60f); setP(v, "Intensity", 80f)
    setP(v, "Harmonic Enhancement", 40f); setP(v, "De-esser Amount", 40f); setP(v, "Vocal Width", 130f)
    setP(AudioEngine.STEREO, "Width", 140f)
    setP(AudioEngine.SPATIAL, "Intensity", 60f); setP(AudioEngine.SPATIAL, "Room Simulation", 1f); setP(AudioEngine.SPATIAL, "Reflections", 40f)
    setP(AudioEngine.REVERB, "Wet", 30f)
    setP(AudioEngine.COMP, "Threshold", -24f)
}

fun tChainSeek() {
    T.group("11. Pergantian lagu dan seek pada DspChain (flush)")
    val sr = 48000
    configureAllActive()
    AudioEngine.setOn(AudioEngine.NORM, false)
    val x = noise(sr / 2, 0.8, 31); val x2 = noise(sr / 2, 0.8, 32)
    val y = noise(sr / 2, 0.5, 33); val y2 = noise(sr / 2, 0.5, 34)
    val A = DspChain(ctx); val oa = A.configure(sr, 2, EF)!!
    runChain(A, x, x2, EF, oa[1])
    A.reset()
    val (al, ar) = runChain(A, y, y2, EF, oa[1])
    val B = DspChain(ctx); val ob = B.configure(sr, 2, EF)!!
    val (bl, br) = runChain(B, y, y2, EF, ob[1])
    var d = 0.0
    for (i in al.indices) d = max(d, max(abs(al[i] - bl[i]), abs(ar[i] - br[i])).toDouble())
    T.check("chain.reset() lalu audio baru = chain baru (semua efek aktif)", d < 1e-5, "selisih maks %.3e".format(d))

    // configure ulang (ganti format) tidak boleh membawa sisa state
    val C = DspChain(ctx); val oc = C.configure(sr, 2, EF)!!
    runChain(C, x, x2, EF, oc[1])
    val oc2 = C.configure(sr, 2, EF)!!
    val (cl, cr) = runChain(C, y, y2, EF, oc2[1])
    var d2 = 0.0
    for (i in cl.indices) d2 = max(d2, max(abs(cl[i] - bl[i]), abs(cr[i] - br[i])).toDouble())
    T.check("configure() ulang membersihkan state efek", d2 < 1e-5, "selisih maks %.3e".format(d2))
}

// ---------- 8. NaN / Infinity / clipping ----------
fun tNaN() {
    T.group("8. NaN, Infinity, clipping")
    val sr = 48000
    configureAllActive()
    val n = 20000
    val l = noise(n, 0.3, 41); val r = noise(n, 0.3, 42)
    l[3000] = Float.NaN; r[3000] = Float.NaN
    l[3500] = Float.POSITIVE_INFINITY; r[3600] = Float.NEGATIVE_INFINITY
    val ch = DspChain(ctx); val o = ch.configure(sr, 2, EF)!!
    val (ol, orr) = runChain(ch, l, r, EF, o[1])
    val fin = allFinite(ol) && allFinite(orr)
    val nanCount = ol.count { !it.isFinite() } + orr.count { !it.isFinite() }
    T.check("masukan NaN/Inf tidak meracuni keluaran", fin, "$nanCount sampel keluaran tidak finit")
    val tail = ol.copyOfRange(ol.size - 2000, ol.size)
    T.check("keluaran pulih (finit & ada sinyal) setelah NaN", allFinite(tail) && maxAbs(tail) > 0.01)

    // clipping: gelombang kotak skala penuh, boost besar
    engineReset(); onlyOn(AudioEngine.EQ, AudioEngine.BASS, AudioEngine.LIMIT)
    setP(AudioEngine.EQ, "Preamp", 24f); setP(AudioEngine.BASS, "Gain", 24f)
    val sq = FloatArray(sr) { if ((it / 100) % 2 == 0) 1f else -1f }
    val ch2 = DspChain(ctx); val o2 = ch2.configure(sr, 2, E16)!!
    val (sl, _) = runChain(ch2, sq, sq, EF, EF.let { o2[1] })
    T.check("boost +24 dB pada gelombang kotak: keluaran finit", allFinite(sl))
    T.check("keluaran 16-bit tidak melewati rentang [-1,1]", sl.all { abs(it) <= 1.0f })
}

// ---------- 9. Parameter min / max / nol ----------
fun tParams() {
    T.group("9. Parameter minimum, maksimum, nol, default")
    val sr = 44100
    val n = 16384
    val g = Rng(51)
    val l = FloatArray(n) { (0.6 * sin(2 * PI * 440 * it / sr) + 0.3 * g.next()).toFloat() }
    val r = FloatArray(n) { (0.5 * sin(2 * PI * 3000 * it / sr + 1) + 0.3 * g.next()).toFloat() }
    for (i in 0 until n step 2000) { l[i] = 1f; r[i] = -1f }
    val modes = listOf("min", "max", "default", "nol")
    val targets = AudioEngine.features.map { it.id }.filter { it != AudioEngine.HIRES && it != AudioEngine.VIS }
    var bad = 0
    val badList = ArrayList<String>()
    for (fid in targets) for (mode in modes) {
        engineReset()
        onlyOn(fid)
        // fitur pengujian dinyalakan bersama Limiter agar keluaran terbatas
        val f = AudioEngine.feature(fid)
        for ((i, p) in f.params.withIndex()) {
            when (p) {
                is PNum -> AudioEngine.set(fid, i, when (mode) { "min" -> p.min; "max" -> p.max; "nol" -> 0f; else -> p.def })
                is PSel -> AudioEngine.set(fid, i, when (mode) { "min" -> 0f; "max" -> (p.opts.size - 1).toFloat(); "nol" -> 0f; else -> p.def.toFloat() })
                is PTog -> AudioEngine.set(fid, i, when (mode) { "min" -> 0f; "max" -> 1f; "nol" -> 0f; else -> if (p.def) 1f else 0f })
                else -> {}
            }
        }
        val ch = DspChain(ctx); val o = ch.configure(sr, 2, EF)!!
        val (ol, orr) = runChain(ch, l, r, EF, o[1], 512)
        val ok = allFinite(ol) && allFinite(orr) && max(maxAbs(ol), maxAbs(orr)) < 1e4
        if (!ok) { bad++; badList.add("$fid/$mode (puncak %.3g)".format(max(maxAbs(ol), maxAbs(orr)))) }
    }
    T.check("${targets.size} fitur x ${modes.size} mode: keluaran finit dan terbatas", bad == 0, badList.joinToString("; "))
    // kombinasi: semua nilai ekstrem sekaligus
    for (mode in listOf("min", "max")) {
        engineReset()
        onlyOn(*targets.toTypedArray())
        for (fid in targets) for ((i, p) in AudioEngine.feature(fid).params.withIndex()) when (p) {
            is PNum -> AudioEngine.set(fid, i, if (mode == "min") p.min else p.max)
            is PSel -> AudioEngine.set(fid, i, if (mode == "min") 0f else (p.opts.size - 1).toFloat())
            is PTog -> AudioEngine.set(fid, i, if (mode == "min") 0f else 1f)
            else -> {}
        }
        val ch = DspChain(ctx); val o = ch.configure(sr, 2, EF)!!
        val (ol, orr) = runChain(ch, l, r, EF, o[1], 512)
        T.check("semua fitur sekaligus, semua parameter $mode: finit", allFinite(ol) && allFinite(orr), "puncak %.3g".format(max(maxAbs(ol), maxAbs(orr))))
    }
}

// ---------- Hi-Res: kuantisasi / format ----------
fun tHiRes() {
    T.group("8. Bit depth dan format keluaran (Hi-Res)")
    val sr = 48000
    val n = 4800
    val l = sine(n, sr, 1000.0, 0.9); val r = sine(n, sr, 1500.0, 0.7)
    // 24-bit masuk -> bit depth 24: tanpa efek harus identik
    engineReset(); onlyOn(AudioEngine.HIRES)
    setP(AudioEngine.HIRES, "Bit Depth", 2f)
    val ch = DspChain(ctx); val o = ch.configure(sr, 2, E24)!!
    val (ol, _) = runChain(ch, l, r, E24, o[1])
    var d = 0.0
    for (i in 0 until n) d = max(d, abs(ol[i] - (toBuffer(l, r, i, 1, E24).let { b -> val bb = b.order(java.nio.ByteOrder.nativeOrder()); val b0 = bb.get().toInt() and 0xFF; val b1 = bb.get().toInt() and 0xFF; val b2 = bb.get().toInt(); ((b2 shl 16) or (b1 shl 8) or b0) / 8388608f })).toDouble())
    T.check("24-bit -> 24-bit tanpa efek: sampel identik", d < 1e-9, "selisih maks %.2f LSB24".format(d * 8388608.0))
    T.check("24-bit: format keluaran ke sink = float (bukan integer 24)", o[1] == EF, "outEnc=${o[1]}")
    // 16-bit keluar
    engineReset(); onlyOn(AudioEngine.HIRES); setP(AudioEngine.HIRES, "Bit Depth", 1f)
    val c2 = DspChain(ctx); val o2 = c2.configure(sr, 2, EF)!!
    T.check("bit depth 16 -> keluaran 16-bit integer", o2[1] == E16, "outEnc=${o2[1]}")
    val (ol2, _) = runChain(c2, l, r, EF, o2[1])
    val grid16 = ol2.all { abs(it * 32768f - (it * 32768f).roundToInt()) < 1e-3 }
    T.check("16-bit: sampel jatuh pada grid 1/32768", grid16)
    // upsample 96k
    engineReset(); onlyOn(AudioEngine.HIRES); setP(AudioEngine.HIRES, "Sample Rate", 4f)
    val c3 = DspChain(ctx); val o3 = c3.configure(sr, 2, EF)!!
    T.check("laju keluaran 96 kHz", o3[0] == 96000, "outRate=${o3[0]}")
    val (ol3, _) = runChain(c3, sine(sr, sr, 1000.0, 0.5), sine(sr, sr, 1000.0, 0.5), EF, o3[1])
    T.check("96 kHz: jumlah sampel ~2x", abs(ol3.size - 2 * sr) <= 4, "${ol3.size}")
}

fun runCommon() {
    tFft(); tResample(); tChannels(); tBypass(); tLimiter(); tLufs(); tFxReset(); tChainSeek(); tNaN(); tParams(); tHiRes()
}

fun main() {
    runCommon()
    val f = T.summary()
    System.exit(if (f == 0) 0 else 1)
}
