import numpy as np, sys, glob
from PIL import Image
Image.MAX_IMAGE_PIXELS=None
def box_down(src, dst, size):
    im = Image.open(src).convert('RGBA'); W,H = im.size; f = W//size
    arr = np.asarray(im); del im
    out = np.zeros((size, size, 4), np.float32)
    band = 256*f
    for r in range(0, H, band):
        blk = arr[r:r+band].astype(np.float32)/255.0
        a = blk[...,3:4]
        pm = np.concatenate([blk[...,:3]*a, a], axis=2)         # premultiplied, rata-rata area (BOX) = tanpa ringing
        h = pm.shape[0]//f
        m = pm.reshape(h, f, size, f, 4).mean(axis=(1,3))
        out[r//f : r//f + h] = m
        del blk, pm
    a = out[...,3:4]
    rgb = np.where(a > 1e-5, out[...,:3] / np.maximum(a, 1e-5), 0.0)
    rgb = np.clip(rgb, 0, 1)
    res = np.concatenate([rgb, a], axis=2)
    Image.fromarray((res*255+0.5).astype(np.uint8), 'RGBA').save(dst, optimize=True)
def halo_count(path):
    a = np.asarray(Image.open(path).convert('RGBA')).astype(np.int32)
    al = a[...,3]; mn = a[...,:3].min(axis=2)
    return int(((al > 4) & (al < 250) & (mn >= 250)).sum())
if __name__ == '__main__':
    j = glob.glob('/tmp/jz/*/*.8192/texture_00.png')[0]
    box_down(j, '/tmp/jian_tex_2048_box.png', 2048)
    print('halo putih (alpha parsial & RGB>=250)  Lanczos:', halo_count('/tmp/jian_tex_2048.png'), '  BOX:', halo_count('/tmp/jian_tex_2048_box.png'))
