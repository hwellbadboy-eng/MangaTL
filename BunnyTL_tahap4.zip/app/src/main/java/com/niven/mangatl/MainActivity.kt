package com.niven.mangatl

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.provider.Settings
import androidx.core.content.ContextCompat
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.ImageDecoder
import android.graphics.RenderEffect
import android.graphics.Shader
import android.graphics.drawable.BitmapDrawable
import android.graphics.drawable.Drawable
import android.net.Uri
import android.provider.OpenableColumns
import android.os.Bundle
import android.os.SystemClock
import android.animation.ObjectAnimator
import android.animation.ValueAnimator
import android.annotation.SuppressLint
import android.text.Editable
import android.text.TextWatcher
import android.transition.AutoTransition
import android.transition.TransitionManager
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.animation.AccelerateDecelerateInterpolator
import android.view.animation.DecelerateInterpolator
import android.view.animation.LinearInterpolator
import android.view.animation.OvershootInterpolator
import android.widget.ImageView
import java.io.File
import java.util.Locale
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.SeekBar
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import com.google.android.material.materialswitch.MaterialSwitch
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class MainActivity : AppCompatActivity() {

    private var chatPlayer: ExoPlayer? = null
    private var chatHasBg = false
    private val pickChatBg = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) importChatBg(uri)
    }

    private lateinit var status: TextView
    private lateinit var result: TextView
    private lateinit var btnPick: View
    private lateinit var settingsPanel: View
    private lateinit var spStyle: Spinner
    private lateinit var spModel: Spinner
    private lateinit var spVoiceModel: Spinner
    private lateinit var spVoiceSid: Spinner
    private var voiceDirs: List<File> = emptyList()
    private var modelFiles: List<File> = emptyList()
    private lateinit var swAccurate: MaterialSwitch
    private lateinit var etGlossary: EditText

    private var busy = false
        set(value) {
            field = value
            runOnUiThread { onBusyChanged(value) }
        }
    private lateinit var ivLogo: ImageView
    private lateinit var ivRing: ImageView
    private var floatAnim: ObjectAnimator? = null
    private var ringAnim: ObjectAnimator? = null
    private var lastLines: List<String> = emptyList()
    private var lastTranslations: List<String?> = emptyList()

    private val prefs by lazy { getSharedPreferences("mangatl", MODE_PRIVATE) }

    private val HELP_TEXT: String =
        "Baca seluruh layar / setengah / sepertiga bawah: seberapa luas layar yang dibaca. Tidak dipakai kalau \"pakai kotak area\" dipilih.\n\n" +
            "Hasil: timpa teks asli, atau tampil di kotak atas/bawah layar.\n\n" +
            "Sekali tap: ketuk = terjemah, ketuk lagi = tutup.\n" +
            "Tap berurutan: satu ketukan menutup hasil lama lalu langsung menerjemahkan layar berikutnya.\n" +
            "Auto: terjemah sendiri saat teks berubah.\n\n" +
            "Area sekali tap / auto: kalau \"pakai kotak area\", hanya kotak yang kamu atur yang dibaca. Atur lewat tombol di bawahnya.\n\n" +
            "Periksa ulang (auto): seberapa sering layar dicek. Mode tiap 2/4 detik bikin kedip singkat.\n\n" +
            "Sensitivitas auto: seberapa kecil perubahan di layar (mis. gelembung dialog kecil) yang dianggap dialog baru. Tinggi cocok untuk gelembung kecil; kalau terlalu sering memeriksa ulang, turunkan ke normal. Ketukan ke game selalu memeriksa ulang.\n\n" +
            "Opasitas: kepekatan latar kotak terjemahan. 100% = teks asli tidak tembus.\n\n" +
            "Perataan teks: rata kiri atau tengah di dalam kotak.\n\n" +
            "Teks kepanjangan (terjemahan tidak muat di kotak): bergulir = teks berjalan ke kiri berulang supaya terbaca semua (teks satu baris; yang beberapa baris dikecilkan); mengecil = huruf terus dikecilkan sampai muat; perpanjang = kotak melebar sampai tepi layar lalu memanjang ke bawah (bisa menutupi teks lain).\n\n" +
            "Spasi blok teks: makin kecil, makin gampang teks dipecah jadi kotak terpisah.\n\n" +
            "Perbedaan ukuran teks: makin kecil, makin gampang teks besar dan kecil dipisah.\n\n" +
            "Daftar abaikan: teks yang tidak diterjemahkan (satu per baris, * = cocok sebagian).\n\n" +
            "Teks diabaikan: tekan lama tombol TL > Pilih teks yang diabaikan. Layar dibekukan dan semua kotak teks tampil; ketuk kotak yang tidak mau diterjemahkan (UI seperti Auto, Log), lalu Selesai. Disimpan sebagai teks + posisi, jadi teks lain dan quest tetap diterjemahkan. Pulihkan dengan membuka lagi, ketuk kotak merah, Selesai.\n\n" +
            "Alat uji: pilih foto untuk melihat kotak hasil pembacaan dan atur slider di atas."

    private val pick = registerForActivityResult(
        ActivityResultContracts.GetContent()
    ) { uri ->
        uri?.let { runOcr(it) }
    }

    private var askedNotif = false
    private lateinit var swGame: MaterialSwitch
    private var syncAfter = 0L

    private val capture = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { r ->
        val d = r.data
        if (r.resultCode == RESULT_OK && d != null) {
            val i = Intent(this, ScreenService::class.java)
                .putExtra("code", r.resultCode)
                .putExtra("data", d)
            ContextCompat.startForegroundService(this, i)
            swGame.isChecked = true
            syncAfter = SystemClock.elapsedRealtime() + 4000
            swGame.postDelayed({ swGame.isChecked = ScreenService.running }, 4500)
            Toast.makeText(
                this, "Tombol TL aktif. Buka game, lalu ketuk tombol TL.", Toast.LENGTH_LONG
            ).show()
            moveTaskToBack(true)
        } else {
            swGame.isChecked = false
            Toast.makeText(this, "Izin rekam layar ditolak.", Toast.LENGTH_SHORT).show()
        }
    }

    private val notifPerm = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { startGameMode() }

    private fun startGameMode() {
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(
                this, "Aktifkan izin 'Tampil di atas aplikasi lain' untuk BunnyTL, lalu kembali dan tekan lagi.",
                Toast.LENGTH_LONG
            ).show()
            startActivity(
                Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
            )
            return
        }
        if (Build.VERSION.SDK_INT >= 33 && !askedNotif &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            askedNotif = true
            notifPerm.launch(Manifest.permission.POST_NOTIFICATIONS)
            return
        }
        if (Gemma.findModel(this) == null) {
            Toast.makeText(this, "Model .litertlm belum ada, terjemahan tidak akan jalan.", Toast.LENGTH_LONG).show()
        }
        val mpm = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        capture.launch(mpm.createScreenCaptureIntent())
    }

    private fun setupSpinner(sp: Spinner, key: String, labels: List<String>) {
        sp.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, labels)
        sp.setSelection(prefs.getInt(key, 0).coerceIn(0, labels.size - 1))
        sp.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(p: AdapterView<*>?, v: View?, pos: Int, id: Long) {
                prefs.edit().putInt(key, pos).apply()
            }

            override fun onNothingSelected(p: AdapterView<*>?) {}
        }
    }

    private fun modelLabel(f: File): String {
        val gb = f.length() / 1024.0 / 1024.0 / 1024.0
        val rel = Gemma.relName(this, f).removeSuffix(".litertlm").replace("/", "  /  ")
        return String.format(Locale.US, "%s (%.1f GB)", rel, gb)
    }

    /** Isi ulang daftar model dari folder data app; pilihan mengikuti Gemma.findModel. */
    private fun refreshModels() {
        val files = Gemma.listModels(this)
        if (files.map { it.absolutePath } != modelFiles.map { it.absolutePath }) {
            modelFiles = files
            val labels = if (files.isEmpty()) listOf("(belum ada file .litertlm)") else files.map { modelLabel(it) }
            spModel.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, labels)
        }
        val cur = Gemma.findModel(this)
        val idx = modelFiles.indexOfFirst { it.absolutePath == cur?.absolutePath }
        if (idx >= 0) spModel.setSelection(idx)
    }

    // ------------------------------------------------------------ suara AI

    private fun refreshVoices() {
        val dirs = Voice.listVoices(this)
        if (dirs.map { it.absolutePath } != voiceDirs.map { it.absolutePath }) {
            voiceDirs = dirs
            val labels = if (dirs.isEmpty()) listOf("(belum ada folder model suara)")
            else dirs.map { Voice.rel(this, it).replace("/", "  /  ") }
            spVoiceModel.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, labels)
        }
        val cur = Voice.findVoice(this)
        val idx = voiceDirs.indexOfFirst { it.absolutePath == cur?.absolutePath }
        if (idx >= 0) spVoiceModel.setSelection(idx)
    }

    private fun onModelPicked(pos: Int) {
        val f = modelFiles.getOrNull(pos) ?: return
        if (Gemma.findModel(this)?.absolutePath == f.absolutePath) return
        Gemma.selectModel(this, f)
        Gemma.resetContext()
        status.text = "Ganti mesin ke ${f.name}. Memuat..."
        Thread {
            try {
                Gemma.warmUp(applicationContext, f)
                runOnUiThread { if (!busy) status.text = "Model siap · ${Gemma.backendName}" }
            } catch (t: Throwable) {
                runOnUiThread { if (!busy) status.text = "Model gagal dimuat: ${t.message}" }
            }
        }.start()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        setupUi()
        setupChatBgControls()

        status = findViewById(R.id.status)
        result = findViewById(R.id.result)
        btnPick = findViewById(R.id.btnPick)
        settingsPanel = findViewById(R.id.settingsPanel)
        spStyle = findViewById(R.id.spStyle)
        spModel = findViewById(R.id.spModel)
        spVoiceModel = findViewById(R.id.spVoiceModel)
        spVoiceSid = findViewById(R.id.spVoiceSid)
        swAccurate = findViewById(R.id.swAccurate)
        etGlossary = findViewById(R.id.etGlossary)

        // Pengaturan tersimpan
        val styles = Gemma.Style.values()
        spStyle.adapter = ArrayAdapter(
            this, android.R.layout.simple_spinner_dropdown_item, styles.map { it.label }
        )
        spStyle.setSelection(prefs.getInt("style", 0).coerceIn(0, styles.size - 1))
        spStyle.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(p: AdapterView<*>?, v: View?, pos: Int, id: Long) {
                prefs.edit().putInt("style", pos).apply()
            }

            override fun onNothingSelected(p: AdapterView<*>?) {}
        }
        swAccurate.isChecked = prefs.getBoolean("accurate", true)
        swAccurate.setOnCheckedChangeListener { _, checked ->
            prefs.edit().putBoolean("accurate", checked).apply()
        }
        etGlossary.setText(prefs.getString("glossary", ""))

        btnPick.setOnClickListener {
            if (busy) {
                Toast.makeText(this, "Masih menerjemahkan...", Toast.LENGTH_SHORT).show()
            } else {
                saveGlossary()
                pick.launch("image/*")
            }
        }

        findViewById<Button>(R.id.btnChat).setOnClickListener {
            saveGlossary()
            startActivity(Intent(this, ChatActivity::class.java))
            overridePendingTransition(R.anim.slide_in_right, R.anim.fade_out_soft)
        }

        findViewById<View>(R.id.btnMusic).setOnClickListener {
            startActivity(Intent(this, MusicActivity::class.java))
            overridePendingTransition(R.anim.slide_in_right, R.anim.fade_out_soft)
        }
        findViewById<View>(R.id.btnVideo).setOnClickListener {
            startActivity(Intent(this, VideoFoldersActivity::class.java))
            overridePendingTransition(R.anim.slide_in_right, R.anim.fade_out_soft)
        }

        findViewById<View>(R.id.btnSettings).setOnClickListener {
            TransitionManager.beginDelayedTransition(
                findViewById<ViewGroup>(R.id.content),
                AutoTransition().apply { duration = 280 }
            )
            settingsPanel.visibility =
                if (settingsPanel.visibility == View.VISIBLE) View.GONE else View.VISIBLE
        }

        // Reset sesi: hanya melupakan ingatan antar halaman terjemahan, tampilan hasil tidak disentuh.
        findViewById<Button>(R.id.btnReset).setOnClickListener {
            if (busy) {
                Toast.makeText(this, "Masih menerjemahkan...", Toast.LENGTH_SHORT).show()
            } else {
                Gemma.resetContext()
                Toast.makeText(this, "Ingatan antar halaman direset.", Toast.LENGTH_SHORT).show()
            }
        }

        // Hapus hasil: hanya mengosongkan tampilan hasil, ingatan terjemahan tetap.
        findViewById<Button>(R.id.btnClear).setOnClickListener {
            if (busy) {
                Toast.makeText(this, "Masih menerjemahkan...", Toast.LENGTH_SHORT).show()
            } else {
                result.text = ""
                lastLines = emptyList()
                lastTranslations = emptyList()
                Toast.makeText(this, "Hasil dihapus.", Toast.LENGTH_SHORT).show()
            }
        }

        findViewById<Button>(R.id.btnCopy).setOnClickListener {
            val text = lastTranslations.mapIndexedNotNull { i, t ->
                if (t == null) null else t.ifBlank { lastLines.getOrElse(i) { "" } }
            }.joinToString("\n")
            if (text.isBlank()) {
                Toast.makeText(this, "Belum ada hasil.", Toast.LENGTH_SHORT).show()
            } else {
                val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                cm.setPrimaryClip(ClipData.newPlainText("terjemahan", text))
                Toast.makeText(this, "Terjemahan disalin.", Toast.LENGTH_SHORT).show()
            }
        }

        setupSpinner(
            findViewById(R.id.spScan), "scan",
            listOf("Mode game: baca seluruh layar", "Mode game: baca setengah bawah", "Mode game: baca sepertiga bawah")
        )
        setupSpinner(
            findViewById(R.id.spPos), "pos",
            listOf(
                "Hasil: timpa teks asli (warna mengikuti latar)",
                "Hasil: kotak di atas layar",
                "Hasil: kotak di bawah layar"
            )
        )
        val spMode = findViewById<Spinner>(R.id.spMode)
        spMode.adapter = ArrayAdapter(
            this, android.R.layout.simple_spinner_dropdown_item,
            listOf(
                "Sekali tap: ketuk = terjemah, ketuk lagi = tutup hasil",
                "Tap berurutan: ketuk = tutup hasil + langsung terjemah layar berikutnya",
                "Auto: terjemah sendiri saat teks di layar berubah (ketuk tombol = jeda/lanjut)"
            )
        )
        spMode.setSelection(prefs.getInt("smode", 1).coerceIn(0, 2))
        spMode.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(p: AdapterView<*>?, v: View?, pos: Int, id: Long) {
                prefs.edit().putInt("smode", pos).apply()
            }

            override fun onNothingSelected(p: AdapterView<*>?) {}
        }
        setupSpinner(
            findViewById(R.id.spAreaTap), "area_tap_on",
            listOf(
                "Area sekali tap: ikut pilihan 'baca ...' di atas",
                "Area sekali tap: pakai kotak area (atur dengan tombol di bawah)"
            )
        )
        setupSpinner(
            findViewById(R.id.spAreaAuto), "area_auto_on",
            listOf(
                "Area auto: ikut pilihan 'baca ...' di atas",
                "Area auto: pakai kotak area (atur dengan tombol di bawah)"
            )
        )
        setupSpinner(
            findViewById(R.id.spAutoSens), "auto_sens",
            listOf(
                "Sensitivitas auto: tinggi",
                "Sensitivitas auto: sangat tinggi",
                "Sensitivitas auto: normal",
                "Sensitivitas auto: hanya perubahan besar"
            )
        )
        setupSpinner(
            findViewById(R.id.spAutoPoll), "auto_poll",
            listOf(
                "Auto, periksa ulang: otomatis (diam saat Anda mengetuk game, tanpa kedip)",
                "Auto, periksa ulang: hanya saat game diketuk (tanpa kedip, paling hemat)",
                "Auto, periksa ulang: tiap 4 detik (kedip singkat)",
                "Auto, periksa ulang: tiap 2 detik (kedip singkat, untuk game auto-play)"
            )
        )
        findViewById<Button>(R.id.btnAreaTap).setOnClickListener { openAreaEditor(0) }
        findViewById<Button>(R.id.btnAreaAuto).setOnClickListener { openAreaEditor(1) }
        val sbOpacity = findViewById<SeekBar>(R.id.sbOpacity)
        val tvOpacity = findViewById<TextView>(R.id.tvOpacity)
        // Kunci baru "ov_alpha2": default 100% (pekat penuh) supaya teks asli tidak tembus.
        val a0 = prefs.getInt("ov_alpha2", 100).coerceIn(30, 100)
        sbOpacity.progress = a0 - 30
        tvOpacity.text = "Opasitas kotak terjemahan: $a0%"
        sbOpacity.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                val v = p + 30
                tvOpacity.text = "Opasitas kotak terjemahan: $v%"
                prefs.edit().putInt("ov_alpha2", v).apply()
            }

            override fun onStartTrackingTouch(s: SeekBar?) {}

            override fun onStopTrackingTouch(s: SeekBar?) {}
        })

        // Perataan teks terjemahan di kotak.
        setupSpinner(
            findViewById(R.id.spAlign), "ov_align",
            listOf("Perataan teks: rata kiri", "Perataan teks: rata tengah")
        )

        // Terjemahan lebih panjang dari kotaknya.
        setupSpinner(
            findViewById(R.id.spOverflow), "ov_overflow",
            listOf(
                "Teks kepanjangan: bergulir (loop)",
                "Teks kepanjangan: mengecil",
                "Teks kepanjangan: perpanjang kotak"
            )
        )

        // Pemecahan blok teks (dipakai juga oleh alat uji).
        val tvSpacing = findViewById<TextView>(R.id.tvSpacing)
        val sbSpacing = findViewById<SeekBar>(R.id.sbSpacing)
        val sp0 = prefs.getInt(Grouping.KEY_SPACING, Grouping.SPACING_DEFAULT).coerceIn(0, 20)
        sbSpacing.progress = sp0
        tvSpacing.text = String.format(
            Locale.US, "Spasi blok teks: pisah kalau jarak baris > %.1fx tinggi huruf", Grouping.spacingFactor(sp0)
        )
        sbSpacing.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                tvSpacing.text = String.format(
                    Locale.US, "Spasi blok teks: pisah kalau jarak baris > %.1fx tinggi huruf", Grouping.spacingFactor(p)
                )
                prefs.edit().putInt(Grouping.KEY_SPACING, p).apply()
            }

            override fun onStartTrackingTouch(s: SeekBar?) {}

            override fun onStopTrackingTouch(s: SeekBar?) {}
        })

        val tvSizeDiff = findViewById<TextView>(R.id.tvSizeDiff)
        val sbSizeDiff = findViewById<SeekBar>(R.id.sbSizeDiff)
        val sd0 = prefs.getInt(Grouping.KEY_SIZEDIFF, Grouping.SIZEDIFF_DEFAULT).coerceIn(10, 80)
        sbSizeDiff.progress = sd0 - 10
        tvSizeDiff.text = "Perbedaan ukuran teks: pisah kalau beda > $sd0%"
        sbSizeDiff.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                val v = p + 10
                tvSizeDiff.text = "Perbedaan ukuran teks: pisah kalau beda > $v%"
                prefs.edit().putInt(Grouping.KEY_SIZEDIFF, v).apply()
            }

            override fun onStartTrackingTouch(s: SeekBar?) {}

            override fun onStopTrackingTouch(s: SeekBar?) {}
        })

        // Daftar abaikan: tersimpan otomatis setiap diubah.
        val etIgnore = findViewById<EditText>(R.id.etIgnore)
        etIgnore.setText(prefs.getString(Grouping.KEY_IGNORE, "") ?: "")
        etIgnore.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}

            override fun onTextChanged(s: CharSequence?, st: Int, b: Int, c: Int) {}

            override fun afterTextChanged(s: Editable?) {
                prefs.edit().putString(Grouping.KEY_IGNORE, s?.toString() ?: "").apply()
            }
        })

        findViewById<TextView>(R.id.tvHelp).setOnClickListener {
            AlertDialog.Builder(this)
                .setTitle("Penjelasan pengaturan")
                .setMessage(HELP_TEXT)
                .setPositiveButton("Tutup", null)
                .show()
        }

        findViewById<Button>(R.id.btnBoxTest).setOnClickListener {
            startActivity(Intent(this, BoxTestActivity::class.java))
        }
        swGame = findViewById(R.id.swGame)
        swGame.isChecked = ScreenService.running
        findViewById<View>(R.id.gameCard).setOnClickListener { swGame.performClick() }
        swGame.setOnClickListener {
            if (swGame.isChecked) {
                // Nyalakan: kembalikan dulu ke mati, baru nyala sungguhan setelah semua izin beres.
                swGame.isChecked = false
                saveGlossary()
                startGameMode()
            } else {
                stopService(Intent(this, ScreenService::class.java))
                Toast.makeText(this, "Mode game dimatikan.", Toast.LENGTH_SHORT).show()
            }
        }

        // Suara AI (offline): pilih model suara, pilih suara 1-6, tombol tes.
        val sidLabels = (0..Voice.MAX_SID).map {
            if (it < 5) "Suara ${it + 1} (biasanya cewek)" else "Suara ${it + 1} (biasanya cowok)"
        }
        spVoiceSid.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, sidLabels)
        spVoiceSid.setSelection(Voice.sid(this))
        spVoiceSid.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(p: AdapterView<*>?, v: View?, pos: Int, id: Long) {
                Voice.setSid(this@MainActivity, pos)
            }

            override fun onNothingSelected(p: AdapterView<*>?) {}
        }
        val spSpeed = findViewById<Spinner>(R.id.spVoiceSpeed)
        spSpeed.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, Voice.MODE_LABELS)
        spSpeed.setSelection(Voice.mode(this))
        spSpeed.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(p: AdapterView<*>?, v: View?, pos: Int, id: Long) {
                Voice.setMode(this@MainActivity, pos)
            }

            override fun onNothingSelected(p: AdapterView<*>?) {}
        }
        // Jeda koma & titik (0-600 ms, kelipatan 10).
        fun bindPause(sbId: Int, tvId: Int, label: String, get: () -> Int, set: (Int) -> Unit) {
            val sb = findViewById<SeekBar>(sbId)
            val tv = findViewById<TextView>(tvId)
            val v0 = get()
            sb.progress = v0 / Voice.PAUSE_STEP_MS
            tv.text = "$label: $v0 ms"
            sb.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                    val v = p * Voice.PAUSE_STEP_MS
                    tv.text = "$label: $v ms"
                    set(v)
                }

                override fun onStartTrackingTouch(s: SeekBar?) {}

                override fun onStopTrackingTouch(s: SeekBar?) {}
            })
        }
        bindPause(R.id.sbPauseComma, R.id.tvPauseComma, "Jeda koma",
            { Voice.pauseComma(this) }, { Voice.setPauseComma(this, it) })
        bindPause(R.id.sbPausePeriod, R.id.tvPausePeriod, "Jeda titik",
            { Voice.pausePeriod(this) }, { Voice.setPausePeriod(this, it) })
        findViewById<Button>(R.id.btnVoiceReset).setOnClickListener {
            Voice.resetSpeechSettings(this)
            spSpeed.setSelection(Voice.mode(this))
            findViewById<SeekBar>(R.id.sbPauseComma).progress = Voice.pauseComma(this) / Voice.PAUSE_STEP_MS
            findViewById<SeekBar>(R.id.sbPausePeriod).progress = Voice.pausePeriod(this) / Voice.PAUSE_STEP_MS
            Toast.makeText(this, "Pengaturan suara dikembalikan ke default.", Toast.LENGTH_SHORT).show()
        }
        refreshVoices()
        spVoiceModel.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(p: AdapterView<*>?, v: View?, pos: Int, id: Long) {
                voiceDirs.getOrNull(pos)?.let { Voice.selectVoice(this@MainActivity, it) }
            }

            override fun onNothingSelected(p: AdapterView<*>?) {}
        }
        findViewById<Button>(R.id.btnVoiceTest).setOnClickListener {
            if (Voice.speaking) {
                Voice.stop()
                return@setOnClickListener
            }
            if (Voice.findVoice(this) == null) {
                Toast.makeText(
                    this, "Model suara belum ada. Salin folder model ke:\n${getExternalFilesDir(null)}",
                    Toast.LENGTH_LONG
                ).show()
                return@setOnClickListener
            }
            Toast.makeText(this, "Memuat suara...", Toast.LENGTH_SHORT).show()
            Voice.speak(
                this, "Halo, aku asisten kamu. Ini contoh suaraku untuk menguji jeda, jadi dengarkan baik-baik ya, apakah jedanya sudah pas. Kalau sudah cocok, pakai terus ya.",
                releaseAfter = true
            ) { err ->
                if (err != null) runOnUiThread {
                    Toast.makeText(this, "Suara gagal: $err", Toast.LENGTH_LONG).show()
                }
            }
        }

        refreshModels()
        spModel.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(p: AdapterView<*>?, v: View?, pos: Int, id: Long) {
                onModelPicked(pos)
            }

            override fun onNothingSelected(p: AdapterView<*>?) {}
        }

        val model = Gemma.findModel(this)
        if (model == null) {
            status.text = "Model belum ada. Salin file .litertlm ke:\n${getExternalFilesDir(null)}"
        } else {
            status.text = "Model ditemukan: ${model.name}. Memuat..."
            // Muat model sejak awal supaya terjemahan pertama langsung cepat.
            Thread {
                try {
                    Gemma.warmUp(applicationContext, model)
                    runOnUiThread {
                        if (!busy) status.text = "Model siap · ${Gemma.backendName}"
                    }
                } catch (t: Throwable) {
                    runOnUiThread {
                        if (!busy) status.text = "Model gagal dimuat: ${t.message}"
                    }
                }
            }.start()
        }
    }

    private fun openAreaEditor(which: Int) {
        if (!ScreenService.running) {
            Toast.makeText(this, "Nyalakan Mode game dulu, baru atur kotak area.", Toast.LENGTH_LONG).show()
            return
        }
        startService(
            Intent(this, ScreenService::class.java)
                .setAction(ScreenService.ACTION_EDIT_AREA)
                .putExtra("which", which)
        )
        Toast.makeText(this, "Atur kotak lalu tekan Simpan.", Toast.LENGTH_SHORT).show()
        moveTaskToBack(true)
    }

    override fun onResume() {
        super.onResume()
        // Area bisa berubah dari layar pengatur area (otomatis diaktifkan saat disimpan).
        findViewById<Spinner>(R.id.spMode).setSelection(prefs.getInt("smode", 1).coerceIn(0, 2))
        findViewById<Spinner>(R.id.spAreaTap).setSelection(prefs.getInt("area_tap_on", 0).coerceIn(0, 1))
        findViewById<Spinner>(R.id.spAreaAuto).setSelection(prefs.getInt("area_auto_on", 0).coerceIn(0, 1))
        refreshModels()
        refreshVoices()
        if (SystemClock.elapsedRealtime() >= syncAfter) swGame.isChecked = ScreenService.running
    }

    override fun onStart() {
        super.onStart()
        applyChatBg()
    }

    override fun onStop() {
        releaseChatBg()
        super.onStop()
    }

    // ------------------------------------------------------------ latar kartu Chat AI

    /** Urutan latar: pilihan pengguna (video/GIF/foto) -> res/raw/chat_loop.mp4 -> polos. */
    private fun applyChatBg() {
        releaseChatBg()
        val kind = prefs.getInt("chat_bg_kind", 0)
        val file = prefs.getString("chat_bg_file", null)
            ?.let { File(filesDir, it) }?.takeIf { it.exists() }
        val rawId = resources.getIdentifier("chat_loop", "raw", packageName)
        findViewById<TextView>(R.id.tvChatBgName).text = when {
            file != null -> prefs.getString("chat_bg_name", null) ?: file.name
            rawId != 0 -> "Bawaan (chat_loop)"
            else -> "Polos"
        }
        when {
            file != null && kind == 2 -> showChatImage(file)
            file != null && kind == 1 -> playChatVideo(Uri.fromFile(file))
            rawId != 0 -> playChatVideo(Uri.parse("android.resource://$packageName/$rawId"))
        }
        applyChatEffects()
    }

    private fun playChatVideo(uri: Uri) {
        val view = findViewById<PlayerView>(R.id.chatVideo)
        val p = ExoPlayer.Builder(this).build()
        p.trackSelectionParameters = p.trackSelectionParameters.buildUpon()
            .setTrackTypeDisabled(C.TRACK_TYPE_AUDIO, true)
            .build()
        p.volume = 0f
        p.repeatMode = Player.REPEAT_MODE_ONE
        p.videoScalingMode = C.VIDEO_SCALING_MODE_SCALE_TO_FIT_WITH_CROPPING
        p.setMediaItem(MediaItem.fromUri(uri))
        p.prepare()
        p.playWhenReady = true
        view.visibility = View.VISIBLE
        view.player = p
        chatPlayer = p
        chatHasBg = true
    }

    private fun showChatImage(f: File) {
        val img = findViewById<ImageView>(R.id.chatImage)
        lifecycleScope.launch {
            val d = withContext(Dispatchers.IO) { loadChatImage(f) }
            if (d == null) {
                Toast.makeText(this@MainActivity, "Gambar latar tidak bisa dibuka.", Toast.LENGTH_SHORT).show()
                return@launch
            }
            if (!lifecycle.currentState.isAtLeast(Lifecycle.State.STARTED)) return@launch
            img.setImageDrawable(d)
            img.visibility = View.VISIBLE
            startChatAnim(d)
            chatHasBg = true
            applyChatEffects()
        }
    }

    /** Foto/GIF dikecilkan maksimal 1080 px supaya hemat memori. GIF jalan sebagai animasi (Android 9 ke atas). */
    @SuppressLint("NewApi")
    private fun loadChatImage(f: File): Drawable? = try {
        if (Build.VERSION.SDK_INT >= 28) {
            ImageDecoder.decodeDrawable(ImageDecoder.createSource(f)) { dec, info, _ ->
                val w = info.size.width
                val h = info.size.height
                val big = maxOf(w, h)
                if (big > 1080) {
                    val r = 1080f / big
                    dec.setTargetSize((w * r).toInt().coerceAtLeast(1), (h * r).toInt().coerceAtLeast(1))
                }
            }
        } else {
            val o = BitmapFactory.Options().apply { inSampleSize = 2 }
            BitmapDrawable(resources, BitmapFactory.decodeFile(f.path, o))
        }
    } catch (_: Throwable) {
        null
    }

    @SuppressLint("NewApi")
    private fun startChatAnim(d: Drawable) {
        if (Build.VERSION.SDK_INT >= 28 && d is android.graphics.drawable.AnimatedImageDrawable) {
            d.repeatCount = android.graphics.drawable.AnimatedImageDrawable.REPEAT_INFINITE
            d.start()
        }
    }

    @SuppressLint("NewApi")
    private fun releaseChatBg() {
        val video = findViewById<PlayerView>(R.id.chatVideo)
        video.player = null
        chatPlayer?.release()
        chatPlayer = null
        video.visibility = View.GONE
        val img = findViewById<ImageView>(R.id.chatImage)
        val d = img.drawable
        if (Build.VERSION.SDK_INT >= 28 && d is android.graphics.drawable.AnimatedImageDrawable) d.stop()
        img.setImageDrawable(null)
        img.visibility = View.GONE
        chatHasBg = false
    }

    /** Blur, gelapkan, dan gelap di tepi. Nilai langsung dari slider, tersimpan di prefs. */
    @SuppressLint("NewApi")
    private fun applyChatEffects() {
        val blur = prefs.getInt("chat_blur", 0).coerceIn(0, 25)
        val dim = prefs.getInt("chat_dim", 22).coerceIn(0, 80)
        val vig = prefs.getInt("chat_vig", 35).coerceIn(0, 100)
        val scrim = findViewById<View>(R.id.chatScrim)
        scrim.setBackgroundColor(Color.argb(dim * 255 / 100, 0, 0, 0))
        scrim.visibility = if (chatHasBg && dim > 0) View.VISIBLE else View.GONE
        val vv = findViewById<VignetteView>(R.id.chatVignette)
        vv.strength = vig
        vv.visibility = if (chatHasBg && vig > 0) View.VISIBLE else View.GONE
        if (Build.VERSION.SDK_INT >= 31) {
            val fx = if (blur > 0) {
                val r = blur * resources.displayMetrics.density
                RenderEffect.createBlurEffect(r, r, Shader.TileMode.CLAMP)
            } else null
            findViewById<View>(R.id.chatVideo).setRenderEffect(fx)
            findViewById<View>(R.id.chatImage).setRenderEffect(fx)
        }
    }

    private fun setupChatBgControls() {
        findViewById<Button>(R.id.btnChatBg).setOnClickListener {
            pickChatBg.launch(arrayOf("video/*", "image/*"))
        }
        findViewById<Button>(R.id.btnChatBgClear).setOnClickListener {
            deleteChatBgFile()
            prefs.edit().remove("chat_bg_kind").remove("chat_bg_file").remove("chat_bg_name").apply()
            applyChatBg()
            Toast.makeText(this, "Latar dikembalikan ke bawaan.", Toast.LENGTH_SHORT).show()
        }
        bindChatSlider(R.id.sbChatBlur, R.id.tvChatBlur, "chat_blur", 0) { "Blur: $it" }
        bindChatSlider(R.id.sbChatDim, R.id.tvChatDim, "chat_dim", 22) { "Gelapkan: $it%" }
        bindChatSlider(R.id.sbChatVig, R.id.tvChatVig, "chat_vig", 35) { "Gelap di tepi: $it%" }
        if (Build.VERSION.SDK_INT < 31) {
            findViewById<View>(R.id.llChatBlur).visibility = View.GONE
            findViewById<View>(R.id.tvChatBlurNote).visibility = View.VISIBLE
        }
    }

    private fun bindChatSlider(sbId: Int, tvId: Int, key: String, def: Int, label: (Int) -> String) {
        val sb = findViewById<SeekBar>(sbId)
        val tv = findViewById<TextView>(tvId)
        val v0 = prefs.getInt(key, def).coerceIn(0, sb.max)
        sb.progress = v0
        tv.text = label(v0)
        sb.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                tv.text = label(p)
                prefs.edit().putInt(key, p).apply()
                applyChatEffects()
            }

            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })
    }

    private fun deleteChatBgFile() {
        prefs.getString("chat_bg_file", null)?.let { File(filesDir, it).delete() }
    }

    /** File yang dipilih disalin ke penyimpanan aplikasi, jadi tetap jalan walau file aslinya dihapus/dipindah. */
    private fun importChatBg(uri: Uri) {
        val mime = contentResolver.getType(uri) ?: ""
        val kind = when {
            mime.startsWith("video/") -> 1
            mime.startsWith("image/") -> 2
            else -> 0
        }
        if (kind == 0) {
            Toast.makeText(this, "Pilih video, GIF, atau foto.", Toast.LENGTH_SHORT).show()
            return
        }
        val ext = when (mime) {
            "image/gif" -> "gif"
            "image/png" -> "png"
            "image/webp" -> "webp"
            "video/webm" -> "webm"
            else -> if (kind == 1) "mp4" else "jpg"
        }
        val name = contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)
            ?.use { c -> if (c.moveToFirst()) c.getString(0) else null } ?: "latar.$ext"
        Toast.makeText(this, "Menyalin latar...", Toast.LENGTH_SHORT).show()
        Thread {
            try {
                val out = File(filesDir, "chat_bg_${System.currentTimeMillis()}.$ext")
                contentResolver.openInputStream(uri)!!.use { i ->
                    out.outputStream().use { o -> i.copyTo(o) }
                }
                runOnUiThread {
                    deleteChatBgFile()
                    prefs.edit()
                        .putInt("chat_bg_kind", kind)
                        .putString("chat_bg_file", out.name)
                        .putString("chat_bg_name", name)
                        .apply()
                    applyChatBg()
                }
            } catch (t: Throwable) {
                runOnUiThread {
                    Toast.makeText(this, "Gagal menyalin latar: ${t.message}", Toast.LENGTH_LONG).show()
                }
            }
        }.start()
    }

    override fun onPause() {
        saveGlossary()
        super.onPause()
    }

    override fun onDestroy() {
        releaseChatBg()
        floatAnim?.cancel()
        ringAnim?.cancel()
        super.onDestroy()
    }

    // ------------------------------------------------------------ tampilan & animasi

    private fun dp(v: Float): Float = v * resources.displayMetrics.density

    private fun setupUi() {
        ivLogo = findViewById(R.id.ivLogo)
        ivRing = findViewById(R.id.ivRing)

        intArrayOf(R.id.header, R.id.rowPick, R.id.rowBento, R.id.gameCard, R.id.resultCard)
            .forEachIndexed { i, id ->
                val v = findViewById<View>(id)
                v.alpha = 0f
                v.translationY = dp(16f)
                v.animate().alpha(1f).translationY(0f)
                    .setStartDelay(80L + i * 70L).setDuration(520)
                    .setInterpolator(DecelerateInterpolator(2f)).start()
            }

        ivLogo.alpha = 0f
        ivLogo.scaleX = 0.55f
        ivLogo.scaleY = 0.55f
        ivLogo.rotation = -12f
        ivLogo.animate().alpha(1f).scaleX(1f).scaleY(1f).rotation(0f)
            .setStartDelay(120).setDuration(800)
            .setInterpolator(OvershootInterpolator(1.6f))
            .withEndAction { startFloat() }.start()
        ivLogo.setOnClickListener {
            ivLogo.animate().cancel()
            ivLogo.animate().rotation(-10f).scaleX(0.9f).scaleY(0.9f).setDuration(120).withEndAction {
                ivLogo.animate().rotation(0f).scaleX(1f).scaleY(1f).setDuration(380)
                    .setInterpolator(OvershootInterpolator(3f)).start()
            }.start()
        }

        intArrayOf(R.id.btnPick, R.id.btnChat, R.id.btnMusic, R.id.btnVideo,
            R.id.btnCopy, R.id.btnReset, R.id.btnClear, R.id.btnSettings)
            .forEach { pressScale(findViewById(it)) }

        val res = findViewById<TextView>(R.id.result)
        val empty = findViewById<View>(R.id.tvEmpty)
        res.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}
            override fun onTextChanged(s: CharSequence?, st: Int, b: Int, c: Int) {}
            override fun afterTextChanged(s: Editable?) {
                if (s.isNullOrBlank()) {
                    res.visibility = View.GONE
                    empty.visibility = View.VISIBLE
                } else if (res.visibility != View.VISIBLE) {
                    res.alpha = 0f
                    res.visibility = View.VISIBLE
                    empty.visibility = View.GONE
                    res.animate().alpha(1f).setDuration(300).start()
                }
            }
        })
    }

    private fun startFloat() {
        floatAnim = ObjectAnimator.ofFloat(ivLogo, View.TRANSLATION_Y, 0f, -dp(2.5f)).apply {
            duration = 2000
            repeatMode = ValueAnimator.REVERSE
            repeatCount = ValueAnimator.INFINITE
            interpolator = AccelerateDecelerateInterpolator()
            start()
        }
    }

    /** Cincin ungu berputar di sekitar logo selama proses terjemah. */
    private fun onBusyChanged(b: Boolean) {
        if (!::ivRing.isInitialized) return
        if (b) {
            ivRing.animate().cancel()
            ivRing.animate().alpha(1f).setDuration(250).start()
            if (ringAnim == null) {
                ringAnim = ObjectAnimator.ofFloat(ivRing, View.ROTATION, 0f, 360f).apply {
                    duration = 1000
                    repeatCount = ValueAnimator.INFINITE
                    interpolator = LinearInterpolator()
                    start()
                }
            }
        } else {
            ivRing.animate().cancel()
            ivRing.animate().alpha(0f).setDuration(300).withEndAction {
                if (!busy) {
                    ringAnim?.cancel()
                    ringAnim = null
                }
            }.start()
        }
    }

    @SuppressLint("ClickableViewAccessibility")
    private fun pressScale(v: View) {
        v.setOnTouchListener { view, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN ->
                    view.animate().scaleX(0.96f).scaleY(0.96f).setDuration(110).start()
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL ->
                    view.animate().scaleX(1f).scaleY(1f).setDuration(220)
                        .setInterpolator(OvershootInterpolator(2f)).start()
            }
            false
        }
    }

    private fun saveGlossary() {
        prefs.edit()
            .putString("glossary", etGlossary.text.toString())
            .apply()
    }

    private fun runOcr(uri: Uri) {
        result.text = ""

        val image = try {
            InputImage.fromFilePath(this, uri)
        } catch (e: Exception) {
            status.text = "Gagal membuka gambar: ${e.message}"
            return
        }

        status.text = "Membaca teks..."
        busy = true

        TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
            .process(image)
            .addOnSuccessListener { text ->
                val items = text.textBlocks.mapNotNull { b ->
                    val box = b.boundingBox
                    val t = b.text.replace("\n", " ").trim()
                    if (box == null || t.isEmpty()) null else Pair(box, t)
                }
                val lines = TextUtil.readingOrder(items)

                if (lines.isEmpty()) {
                    busy = false
                    status.text = "Tidak ada teks terdeteksi."
                    return@addOnSuccessListener
                }

                lastLines = lines
                lastTranslations = emptyList()
                show(lines, List(lines.size) { null })
                translate(lines)
            }
            .addOnFailureListener { e ->
                busy = false
                status.text = "OCR gagal: ${e.message}"
            }
    }

    private fun show(lines: List<String>, tr: List<String?>) {
        val muted = Color.parseColor("#8E8E93")
        val flag = android.text.Spanned.SPAN_EXCLUSIVE_EXCLUSIVE
        val sb = android.text.SpannableStringBuilder()
        lines.indices.forEach { i ->
            if (i > 0) sb.append("\n\n")
            // teks asli: kecil dan abu-abu
            val a = sb.length
            sb.append(lines[i])
            sb.setSpan(android.text.style.ForegroundColorSpan(muted), a, sb.length, flag)
            sb.setSpan(android.text.style.RelativeSizeSpan(0.8f), a, sb.length, flag)
            sb.append("\n")
            // terjemahan: tebal dan putih
            val t = tr.getOrNull(i)
            val b = sb.length
            sb.append(t ?: "...")
            if (t != null) {
                sb.setSpan(android.text.style.StyleSpan(android.graphics.Typeface.BOLD), b, sb.length, flag)
                sb.setSpan(android.text.style.ForegroundColorSpan(Color.WHITE), b, sb.length, flag)
            } else {
                sb.setSpan(android.text.style.ForegroundColorSpan(muted), b, sb.length, flag)
            }
        }
        result.text = sb
    }

    private fun translate(lines: List<String>) {
        val model = Gemma.findModel(this)

        if (model == null) {
            busy = false
            status.text = "Model belum ada. Salin file .litertlm ke:\n${getExternalFilesDir(null)}"
            return
        }

        val style = Gemma.Style.values()[spStyle.selectedItemPosition.coerceIn(0, Gemma.Style.values().size - 1)]
        val accurate = swAccurate.isChecked
        val glossary = etGlossary.text.toString()

        status.text = "Menerjemahkan ${lines.size} blok..."

        lifecycleScope.launch {
            val t0 = SystemClock.elapsedRealtime()

            val res = try {
                withContext(Dispatchers.IO) {
                    Gemma.translate(
                        this@MainActivity, model, lines, style, accurate, glossary,
                        onStatus = { s -> runOnUiThread { status.text = s } },
                        onProgress = { tr ->
                            runOnUiThread {
                                lastTranslations = tr
                                show(lines, tr)
                            }
                        }
                    )
                }
            } catch (t: Throwable) {
                busy = false
                status.text = "Gemma gagal: ${t::class.java.simpleName}: ${t.message}"
                return@launch
            }

            busy = false
            val sec = (SystemClock.elapsedRealtime() - t0) / 1000.0
            lastTranslations = res.lines
            show(lines, res.lines)

            status.text = "Selesai %.1f detik. Mode: %s. Backend: %s".format(
                sec,
                res.mode,
                Gemma.backendName
            )
        }
    }
}
