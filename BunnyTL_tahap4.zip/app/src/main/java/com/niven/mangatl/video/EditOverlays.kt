package com.niven.mangatl

import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.MotionEvent
import android.view.ScaleGestureDetector
import android.view.TextureView
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import androidx.media3.common.MediaItem
import androidx.media3.exoplayer.ExoPlayer
import kotlinx.coroutines.launch

// Editor video: lapisan overlay (video/foto di atas video utama), kanvas, dan panggung pratinjau.
// Fungsi ekstensi dari VideoEditActivity; keadaan editor tetap dimiliki activity.

internal fun VideoEditActivity.buildOvBar(): View {
    val row = LinearLayout(this)
    row.orientation = LinearLayout.HORIZONTAL
    fun add(t: String, a: () -> Unit): View {
        val c = chip(t, a)
        row.addView(c, LinearLayout.LayoutParams(-2, -2).apply { marginEnd = dp(8) })
        return c
    }
    add("Pas layar") { ovFit(false) }
    add("Penuh") { ovFit(true) }
    ovExtra = listOf(
        add("Tengah") { ovCenter() },
        add("Maju") { moveLayer(1) },
        add("Mundur") { moveLayer(-1) }
    )
    val hs = HorizontalScrollView(this)
    hs.isHorizontalScrollBarEnabled = false
    hs.addView(row)
    hs.visibility = View.GONE
    hs.layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        .apply { topMargin = dp(8) }
    return hs
}

internal fun VideoEditActivity.updateOvBar() {
    val isOv = selO in ovs.indices
    val mainNeeds = clips.getOrNull(sel)?.let { c ->
        c.w > 0 && c.h > 0 && Math.abs(c.w.toFloat() / c.h - frameAspect()) > 0.02f
    } == true
    ovBar.visibility = if (isOv || mainNeeds) View.VISIBLE else View.GONE
    for (v in ovExtra) v.visibility = if (isOv) View.VISIBLE else View.GONE
}

internal fun VideoEditActivity.addLayer() {
    if (clips.isEmpty()) {
        toast("Tunggu video selesai dimuat.")
        return
    }
    ovPicker.launch(arrayOf("video/*", "image/*"))
}

/** Ukuran hasil (piksel). Asli = klip pertama (video atau foto), selain itu ukuran tetap. */
internal fun VideoEditActivity.canvasSize(): Pair<Int, Int> {
    when (canvasKey) {
        "916" -> return 1080 to 1920
        "169" -> return 1920 to 1080
        "11" -> return 1080 to 1080
        "45" -> return 1080 to 1350
    }
    val f = clips.firstOrNull { it.w > 0 && it.h > 0 }
    var w = f?.w ?: 1080
    var h = f?.h ?: 1920
    w -= w % 2
    h -= h % 2
    return w to h
}

internal fun VideoEditActivity.frameAspect(): Float {
    val (w, h) = canvasSize()
    return w.toFloat() / h
}

internal fun VideoEditActivity.canvasDialog() {
    Sheet.pickList(
        this, "Ukuran video",
        canvasOpts.map { it.second }, canvasOpts.map { it.third }, R.drawable.ic_trim
    ) { i -> applyCanvas(canvasOpts[i].first) }
}

internal fun VideoEditActivity.applyCanvas(key: String) {
    if (key == canvasKey) return
    canvasKey = key
    for (o in ovs) fitOv(o, false)
    layoutStage()
    placeAllOverlays()
    pushTimeline()
}

internal fun VideoEditActivity.ovFrom(c: Clip, start: Long, tot: Long): Ov {
    val room = (tot - start).coerceAtLeast(300L)
    val o = Ov(c.uri, c.photo, c.srcDur, 0L, c.srcDur, 1f, c.w, c.h, 3000L, start)
    if (o.photo) o.photoMs = minOf(3000L, room)
    else if (o.dur() > room) o.srcEnd = room
    return o
}

/** Pas layar: seluruh gambar terlihat. Penuh: layar terisi penuh (bagian lebih terpotong). */
internal fun VideoEditActivity.fitOv(o: Ov, fillScreen: Boolean) {
    val a = o.aspect()
    val f = frameAspect()
    o.wf = if (fillScreen) (if (a >= f) a / f else 1f) else (if (a >= f) 1f else a / f)
    o.cx = 0.5f
    o.cy = 0.5f
}

internal fun VideoEditActivity.ovFit(fillScreen: Boolean) {
    val o = ovs.getOrNull(selO)
    if (o != null) {
        pushHistory()
        fitOv(o, fillScreen)
        placeOverlay(o)
        updateSelBox()
        return
    }
    val c = clips.getOrNull(sel) ?: return
    pushHistory()
    c.fill = fillScreen
    applySpeed()
    pushTimeline()
}

internal fun VideoEditActivity.ovCenter() {
    val o = ovs.getOrNull(selO) ?: return
    pushHistory()
    o.cx = 0.5f
    o.cy = 0.5f
    placeOverlay(o)
    updateSelBox()
}

/** Maju = ke depan (menutupi lapisan lain), mundur = ke belakang. */
internal fun VideoEditActivity.moveLayer(dir: Int) {
    val i = selO
    val j = i + dir
    if (i !in ovs.indices || j !in ovs.indices) {
        toast(if (dir > 0) "Sudah paling depan." else "Sudah paling belakang.")
        return
    }
    pushHistory()
    val t = ovs[i]
    ovs[i] = ovs[j]
    ovs[j] = t
    selO = j
    rebuildOverlays()
    pushTimeline()
}

internal fun VideoEditActivity.setupStage(pv: FrameLayout) {
    stage = FrameLayout(this)
    stage.clipChildren = true
    canvasFrame.addView(stage, FrameLayout.LayoutParams(-1, -1))
    stage.addOnLayoutChangeListener { _, _, _, _, _, _, _, _, _ -> placeAllOverlays() }
    pv.addOnLayoutChangeListener { _, _, _, _, _, _, _, _, _ -> layoutStage() }
    val pinch = ScaleGestureDetector(this, object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
        override fun onScale(d: ScaleGestureDetector): Boolean {
            val o = ovs.getOrNull(selO) ?: return false
            stageHistory()
            o.wf = (o.wf * d.scaleFactor).coerceIn(0.1f, 4f)
            placeOverlay(o)
            updateSelBox()
            return true
        }
    })
    stage.setOnTouchListener { _, e ->
        pinch.onTouchEvent(e)
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                stDownX = e.x
                stDownY = e.y
                stLastX = e.x
                stLastY = e.y
                stMoved = false
                stHist = false
                stHit = hitOverlay(e.x, e.y)
                if (stHit >= 0 && stHit != selO) selectItem(TimelineView.K_OV, stHit)
            }
            MotionEvent.ACTION_MOVE -> {
                if (e.pointerCount > 1) {
                    stMoved = true
                } else if (stHit >= 0 && !pinch.isInProgress) {
                    val far = Math.abs(e.x - stDownX) > dp(6) || Math.abs(e.y - stDownY) > dp(6)
                    val o = ovs.getOrNull(selO)
                    if ((stMoved || far) && o != null && stage.width > 0 && stage.height > 0) {
                        stMoved = true
                        stageHistory()
                        o.cx = (o.cx + (e.x - stLastX) / stage.width).coerceIn(0f, 1f)
                        o.cy = (o.cy + (e.y - stLastY) / stage.height).coerceIn(0f, 1f)
                        placeOverlay(o)
                        updateSelBox()
                    }
                }
                stLastX = e.x
                stLastY = e.y
            }
            MotionEvent.ACTION_UP -> {
                if (!stMoved && stHit < 0) togglePlay()
            }
        }
        true
    }
    val box = View(this)
    box.background = GradientDrawable().apply {
        setColor(Color.TRANSPARENT)
        setStroke(dp(2), Color.WHITE)
    }
    box.visibility = View.GONE
    selBox = box
}

internal fun VideoEditActivity.stageHistory() {
    if (!stHist) {
        stHist = true
        pushHistory()
    }
}

internal fun VideoEditActivity.ovActive(o: Ov): Boolean {
    val rel = playhead - o.start
    return rel >= 0L && rel < o.dur()
}

internal fun VideoEditActivity.hitOverlay(x: Float, y: Float): Int {
    val sw = stage.width.toFloat()
    val sh = stage.height.toFloat()
    for (i in ovs.indices.reversed()) {
        val o = ovs[i]
        if (!ovActive(o)) continue
        val bw = o.wf * sw
        val bh = bw / o.aspect()
        val l = o.cx * sw - bw / 2f
        val t = o.cy * sh - bh / 2f
        if (x >= l && x <= l + bw && y >= t && y <= t + bh) return i
    }
    return -1
}

internal fun VideoEditActivity.layoutStage() {
    val pw = pvBox.width
    val ph = pvBox.height
    if (pw <= 0 || ph <= 0) return
    val f = frameAspect()
    var w = pw.toFloat()
    var h = w / f
    if (h > ph) {
        h = ph.toFloat()
        w = h * f
    }
    val lp = canvasFrame.layoutParams as FrameLayout.LayoutParams
    if (lp.width != w.toInt() || lp.height != h.toInt()) {
        lp.width = w.toInt()
        lp.height = h.toInt()
        lp.gravity = Gravity.CENTER
        canvasFrame.layoutParams = lp
    }
}

internal fun VideoEditActivity.releaseOverlays() {
    for (o in ovs) {
        o.player?.release()
        o.player = null
        o.view = null
        o.running = false
    }
}

internal fun VideoEditActivity.rebuildOverlays() {
    releaseOverlays()
    stage.removeAllViews()
    for (o in ovs) {
        val v: View
        if (o.photo) {
            val iv = ImageView(this)
            iv.scaleType = ImageView.ScaleType.FIT_XY
            iv.setImageURI(o.uri)
            v = iv
        } else {
            val tv = TextureView(this)
            val p = ExoPlayer.Builder(this, Decoders.factory(this, Prefs.decoder(this))).build()
            p.setVideoTextureView(tv)
            p.volume = 0f
            p.setMediaItem(
                MediaItem.Builder().setUri(o.uri)
                    .setClippingConfiguration(
                        MediaItem.ClippingConfiguration.Builder()
                            .setStartPositionMs(o.srcStart)
                            .setEndPositionMs(o.srcEnd)
                            .build()
                    ).build()
            )
            p.setPlaybackSpeed(o.speed)
            p.prepare()
            o.player = p
            v = tv
        }
        v.visibility = View.INVISIBLE
        o.view = v
        stage.addView(v, FrameLayout.LayoutParams(2, 2, Gravity.TOP or Gravity.START))
    }
    selBox?.let { stage.addView(it, FrameLayout.LayoutParams(2, 2, Gravity.TOP or Gravity.START)) }
    placeAllOverlays()
    syncOverlays(true)
}

internal fun VideoEditActivity.placeOverlay(o: Ov) {
    val v = o.view ?: return
    val sw = stage.width.toFloat()
    val sh = stage.height.toFloat()
    if (sw <= 0f || sh <= 0f) return
    val bw = (o.wf * sw).coerceAtLeast(8f)
    val bh = (bw / o.aspect()).coerceAtLeast(8f)
    val lp = v.layoutParams as? FrameLayout.LayoutParams
    if (lp == null || lp.width != bw.toInt() || lp.height != bh.toInt()) {
        v.layoutParams = FrameLayout.LayoutParams(bw.toInt(), bh.toInt(), Gravity.TOP or Gravity.START)
    }
    v.x = o.cx * sw - bw / 2f
    v.y = o.cy * sh - bh / 2f
}

internal fun VideoEditActivity.placeAllOverlays() {
    for (o in ovs) placeOverlay(o)
    updateSelBox()
}

internal fun VideoEditActivity.updateSelBox() {
    val b = selBox ?: return
    val o = ovs.getOrNull(selO)
    val sw = stage.width.toFloat()
    val sh = stage.height.toFloat()
    if (o == null || o.view == null || sw <= 0f || sh <= 0f) {
        b.visibility = View.GONE
        return
    }
    val bw = (o.wf * sw).coerceAtLeast(8f)
    val bh = (bw / o.aspect()).coerceAtLeast(8f)
    val lp = b.layoutParams as? FrameLayout.LayoutParams
    if (lp == null || lp.width != bw.toInt() || lp.height != bh.toInt()) {
        b.layoutParams = FrameLayout.LayoutParams(bw.toInt(), bh.toInt(), Gravity.TOP or Gravity.START)
    }
    b.x = o.cx * sw - bw / 2f
    b.y = o.cy * sh - bh / 2f
    b.visibility = if (ovActive(o)) View.VISIBLE else View.GONE
}
