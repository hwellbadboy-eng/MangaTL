package com.niven.mangatl

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.SurfaceTexture
import android.opengl.EGL14
import android.opengl.GLES20
import android.opengl.GLUtils
import android.os.SystemClock
import android.util.Log
import android.view.TextureView
import org.json.JSONObject
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.FloatBuffer
import java.nio.ShortBuffer
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin

/**
 * Avatar komik (hitam-putih, cewek berheadphone dari samping). Bukan Live2D: satu gambar yang digoyang lewat mesh
 * (napas, badan, kepala mengangguk, rambut berkibar di shader) + kedip + efek (gelombang suara, not, kilau).
 * Aset: assets/models/comic (main.png, lid.png = mata merem, weight.png = bobot rambut, mesh.json = bobot kepala / badan).
 * Digambar di TextureView sendiri supaya bisa berada DI BAWAH ikon & visualizer (sama seperti AvatarTexView).
 */
class ComicTexView(context: Context) : TextureView(context), TextureView.SurfaceTextureListener {

    // ---- masukan dari MikuAvatar (thread utama), dibaca thread GL ----
    @Volatile var playing = false
    @Volatile var bobAmp = 0f       // 0..1, amplitudo anggukan (halus)
    @Volatile var bobPhase = 0f     // fase anggukan (puncak = ketukan)
    @Volatile var effects = true
    @Volatile var fadePx = 0
    @Volatile private var pokeReq = 0
    var onError: ((String) -> Unit)? = null

    private val rend = Rend(context.applicationContext)
    private var glThread: GlThread? = null
    private var paused = true

    init {
        isOpaque = false
        surfaceTextureListener = this
    }

    /** Colek / ketuk: kaget sebentar + kilatan. Aman dari thread mana pun. */
    fun poke() {
        pokeReq++
    }

    fun onResume() {
        paused = false
        glThread?.setPaused(false)
    }

    fun onPause() {
        paused = true
        glThread?.setPaused(true)
    }

    override fun onSurfaceTextureAvailable(st: SurfaceTexture, width: Int, height: Int) {
        glThread?.quitNow()
        val t = GlThread(st, width, height)
        t.setPaused(paused)
        glThread = t
        t.start()
    }

    override fun onSurfaceTextureSizeChanged(st: SurfaceTexture, width: Int, height: Int) {
        glThread?.resize(width, height)
    }

    override fun onSurfaceTextureDestroyed(st: SurfaceTexture): Boolean {
        glThread?.quitNow()
        glThread = null
        return true
    }

    override fun onSurfaceTextureUpdated(st: SurfaceTexture) {}

    private inner class GlThread(private val tex: SurfaceTexture, w0: Int, h0: Int) : Thread("comic-tex") {
        private val lock = Object()
        @Volatile private var quit = false
        @Volatile private var pausedT = true
        @Volatile private var w = w0
        @Volatile private var h = h0
        @Volatile private var sizeDirty = false

        fun setPaused(p: Boolean) {
            synchronized(lock) {
                pausedT = p
                lock.notifyAll()
            }
        }

        fun resize(nw: Int, nh: Int) {
            w = nw
            h = nh
            sizeDirty = true
        }

        fun quitNow() {
            synchronized(lock) {
                quit = true
                lock.notifyAll()
            }
        }

        override fun run() {
            var dpy: android.opengl.EGLDisplay? = null
            var ctx: android.opengl.EGLContext? = null
            var surf: android.opengl.EGLSurface? = null
            try {
                dpy = EGL14.eglGetDisplay(EGL14.EGL_DEFAULT_DISPLAY)
                val ver = IntArray(2)
                if (!EGL14.eglInitialize(dpy, ver, 0, ver, 1)) throw IllegalStateException("EGL init gagal")
                val attr = intArrayOf(
                    EGL14.EGL_RED_SIZE, 8, EGL14.EGL_GREEN_SIZE, 8, EGL14.EGL_BLUE_SIZE, 8, EGL14.EGL_ALPHA_SIZE, 8,
                    EGL14.EGL_DEPTH_SIZE, 0, EGL14.EGL_STENCIL_SIZE, 0,
                    EGL14.EGL_RENDERABLE_TYPE, EGL14.EGL_OPENGL_ES2_BIT, EGL14.EGL_NONE
                )
                val cfgs = arrayOfNulls<android.opengl.EGLConfig>(1)
                val num = IntArray(1)
                if (!EGL14.eglChooseConfig(dpy, attr, 0, cfgs, 0, 1, num, 0) || num[0] <= 0) throw IllegalStateException("EGL config tidak ada")
                ctx = EGL14.eglCreateContext(dpy, cfgs[0], EGL14.EGL_NO_CONTEXT, intArrayOf(EGL14.EGL_CONTEXT_CLIENT_VERSION, 2, EGL14.EGL_NONE), 0)
                surf = EGL14.eglCreateWindowSurface(dpy, cfgs[0], tex, intArrayOf(EGL14.EGL_NONE), 0)
                if (!EGL14.eglMakeCurrent(dpy, surf, surf, ctx)) throw IllegalStateException("EGL makeCurrent gagal")
                rend.create()
                rend.resize(w, h)
                while (!quit) {
                    synchronized(lock) {
                        while (pausedT && !quit) lock.wait(250L)
                    }
                    if (quit) break
                    if (sizeDirty) {
                        sizeDirty = false
                        rend.resize(w, h)
                    }
                    val t0 = SystemClock.uptimeMillis()
                    rend.draw()
                    EGL14.eglSwapBuffers(dpy, surf)
                    val spent = SystemClock.uptimeMillis() - t0
                    if (spent < 33L) sleep(33L - spent)
                }
            } catch (_: InterruptedException) {
            } catch (t: Throwable) {
                Log.e("Comic", "Thread GL gagal: ${t.message}")
                post { onError?.invoke(t.message ?: "EGL gagal") }
            } finally {
                try {
                    if (dpy != null) {
                        EGL14.eglMakeCurrent(dpy, EGL14.EGL_NO_SURFACE, EGL14.EGL_NO_SURFACE, EGL14.EGL_NO_CONTEXT)
                        if (surf != null) EGL14.eglDestroySurface(dpy, surf)
                        if (ctx != null) EGL14.eglDestroyContext(dpy, ctx)
                        EGL14.eglTerminate(dpy)
                    }
                } catch (_: Throwable) {
                }
            }
        }
    }

    // =====================================================================================================
    private inner class Rend(private val app: Context) {
        private val TW = 700
        private val TH = 928
        private val NX = 56
        private val NY = 74
        private val M = 40
        private val CW = TW + 2 * M
        private val CH = TH + 2 * M
        private val nV = (NX + 1) * (NY + 1)
        private val CUPX = 419f
        private val CUPY = 370f
        private val PVX = 350f
        private val PVY = 700f
        // skala pemetaan "unit SVG" mock -> piksel kanvas (178.2 / 780)
        private val K = 4.376f

        private val bx = FloatArray(nV)
        private val by = FloatArray(nV)
        private val wD = FloatArray(nV)
        private val wB = FloatArray(nV)
        private val ph = FloatArray(nV)
        private val cw = FloatArray(nV)
        private val pos = FloatArray(nV * 2)
        private lateinit var posBuf: FloatBuffer
        private lateinit var uvBuf: FloatBuffer
        private lateinit var idxBuf: ShortBuffer
        private var idxCount = 0

        private var prog = 0
        private var aP = 0
        private var aU = 0
        private var uS = 0
        private var uA = 0
        private var uT = 0
        private var uPh = 0
        private var uHp = 0
        private var uHw = 0
        private var uDm = 0
        private var texMain = 0
        private var texLid = 0
        private var texW = 0
        private var texFx = 0

        private var sprProg = 0
        private var sP = 0
        private var sU = 0
        private var sVp = 0
        private var sAl = 0
        private var sTex = 0
        private val sprBuf: FloatBuffer = ByteBuffer.allocateDirect(16 * 4).order(ByteOrder.nativeOrder()).asFloatBuffer()

        private var fadeProg = 0
        private var fadeP = 0
        private var fadeKk = 0
        private val fadeBuf: FloatBuffer = ByteBuffer.allocateDirect(12 * 4).order(ByteOrder.nativeOrder()).asFloatBuffer()

        private var vw = 1
        private var vh = 1
        private var ready = false

        // keadaan gerak
        private var t0 = 0L
        private var lastT = 0f
        private var plS = 1f
        private var sAng = 0f
        private var sVel = 0f
        private var flick = 0f
        private var hl = 0f
        private var prevHead = Float.NaN
        private var pokeDone = 0
        private var burstT = -10f
        private var blinkT = -1f
        private var nextBlink = 1.8f
        private var dbl = false
        private var wasDbl = false

        private fun ss(u0: Float): Float {
            val u = u0.coerceIn(0f, 1f)
            return u * u * (3f - 2f * u)
        }

        private fun compile(type: Int, src: String): Int {
            val s = GLES20.glCreateShader(type)
            GLES20.glShaderSource(s, src)
            GLES20.glCompileShader(s)
            val ok = IntArray(1)
            GLES20.glGetShaderiv(s, GLES20.GL_COMPILE_STATUS, ok, 0)
            if (ok[0] == 0) throw IllegalStateException("shader: " + GLES20.glGetShaderInfoLog(s))
            return s
        }

        private fun link(vs: String, fs: String): Int {
            val p = GLES20.glCreateProgram()
            GLES20.glAttachShader(p, compile(GLES20.GL_VERTEX_SHADER, vs))
            GLES20.glAttachShader(p, compile(GLES20.GL_FRAGMENT_SHADER, fs))
            GLES20.glLinkProgram(p)
            val ok = IntArray(1)
            GLES20.glGetProgramiv(p, GLES20.GL_LINK_STATUS, ok, 0)
            if (ok[0] == 0) throw IllegalStateException("link: " + GLES20.glGetProgramInfoLog(p))
            return p
        }

        private fun upload(bm: Bitmap): Int {
            val id = IntArray(1)
            GLES20.glGenTextures(1, id, 0)
            GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, id[0])
            GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_MIN_FILTER, GLES20.GL_LINEAR)
            GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_MAG_FILTER, GLES20.GL_LINEAR)
            GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_WRAP_S, GLES20.GL_CLAMP_TO_EDGE)
            GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_WRAP_T, GLES20.GL_CLAMP_TO_EDGE)
            GLUtils.texImage2D(GLES20.GL_TEXTURE_2D, 0, bm, 0)
            return id[0]
        }

        private fun asset(name: String): Bitmap {
            val o = BitmapFactory.Options().apply { inPremultiplied = true }
            return app.assets.open("models/comic/$name").use { BitmapFactory.decodeStream(it, null, o) }
                ?: throw IllegalStateException("gagal membaca $name")
        }

        private fun direct(n: Int): FloatBuffer = ByteBuffer.allocateDirect(n * 4).order(ByteOrder.nativeOrder()).asFloatBuffer()

        fun create() {
            // ---- mesh ----
            val js = JSONObject(app.assets.open("models/comic/mesh.json").bufferedReader().use { it.readText() })
            val head = js.getJSONArray("head")
            val body = js.getJSONArray("body")
            val uvs = FloatArray(nV * 2)
            for (j in 0..NY) for (i in 0..NX) {
                val k = j * (NX + 1) + i
                val x = i.toFloat() / NX * (TW - 1)
                val y = j.toFloat() / NY * (TH - 1)
                bx[k] = x
                by[k] = y
                uvs[k * 2] = x / (TW - 1)
                uvs[k * 2 + 1] = y / (TH - 1)
                wD[k] = (head.optDouble(k, 0.0) / 100.0).toFloat()
                wB[k] = (body.optDouble(k, 0.0) / 100.0).toFloat()
                ph[k] = y * 0.012f + x * 0.006f
                val r = hypot(x - CUPX, y - CUPY)
                val tt = ((r - 72f) / 46f).coerceIn(0f, 1f)
                cw[k] = 1f - tt * tt * (3f - 2f * tt)
            }
            val idx = ShortArray(NX * NY * 6)
            var n = 0
            for (j in 0 until NY) for (i in 0 until NX) {
                val a = j * (NX + 1) + i
                val b = a + 1
                val c = a + NX + 1
                val d = c + 1
                idx[n++] = a.toShort(); idx[n++] = b.toShort(); idx[n++] = c.toShort()
                idx[n++] = b.toShort(); idx[n++] = d.toShort(); idx[n++] = c.toShort()
            }
            idxCount = idx.size
            idxBuf = ByteBuffer.allocateDirect(idx.size * 2).order(ByteOrder.nativeOrder()).asShortBuffer().also { it.put(idx); it.position(0) }
            uvBuf = direct(uvs.size).also { it.put(uvs); it.position(0) }
            posBuf = direct(pos.size)

            // ---- shader mesh (sama dengan mock web) ----
            prog = link(
                "attribute vec2 p;attribute vec2 u;varying vec2 v;uniform vec2 s;void main(){v=u;gl_Position=vec4(p.x/s.x*2.-1.,1.-p.y/s.y*2.,0.,1.);}",
                "#ifdef GL_FRAGMENT_PRECISION_HIGH\nprecision highp float;\n#else\nprecision mediump float;\n#endif\nvarying vec2 v;uniform sampler2D t;uniform sampler2D hw;uniform float a;uniform vec3 ph;uniform vec3 hp;uniform vec2 dm;" +
                    "void main(){float w=texture2D(hw,v).r;vec2 p=v*dm;float q=p.y*.012+p.x*.006;float wv=sin(ph.x+q)+.5*sin(ph.y+q*1.7);" +
                    "vec2 d=vec2(hp.x*w*wv+hp.y*w,hp.x*.3*w*sin(ph.z+q));gl_FragColor=texture2D(t,v-d/dm)*a;}"
            )
            aP = GLES20.glGetAttribLocation(prog, "p")
            aU = GLES20.glGetAttribLocation(prog, "u")
            uS = GLES20.glGetUniformLocation(prog, "s")
            uA = GLES20.glGetUniformLocation(prog, "a")
            uT = GLES20.glGetUniformLocation(prog, "t")
            uPh = GLES20.glGetUniformLocation(prog, "ph")
            uHp = GLES20.glGetUniformLocation(prog, "hp")
            uHw = GLES20.glGetUniformLocation(prog, "hw")
            uDm = GLES20.glGetUniformLocation(prog, "dm")

            sprProg = link(
                "attribute vec2 a;attribute vec2 t;varying vec2 v;uniform vec2 vp;void main(){v=t;gl_Position=vec4(a.x/vp.x*2.-1.,1.-a.y/vp.y*2.,0.,1.);}",
                "precision mediump float;varying vec2 v;uniform sampler2D tx;uniform float al;void main(){gl_FragColor=texture2D(tx,v)*al;}"
            )
            sP = GLES20.glGetAttribLocation(sprProg, "a")
            sU = GLES20.glGetAttribLocation(sprProg, "t")
            sVp = GLES20.glGetUniformLocation(sprProg, "vp")
            sAl = GLES20.glGetUniformLocation(sprProg, "al")
            sTex = GLES20.glGetUniformLocation(sprProg, "tx")

            fadeProg = link(
                "attribute vec2 a;attribute float k;varying float vk;void main(){gl_Position=vec4(a,0.0,1.0);vk=k;}",
                "precision mediump float;varying float vk;void main(){float s=clamp(vk,0.0,1.0);s=s*s*(3.0-2.0*s);gl_FragColor=vec4(s,s,s,s);}"
            )
            fadeP = GLES20.glGetAttribLocation(fadeProg, "a")
            fadeKk = GLES20.glGetAttribLocation(fadeProg, "k")

            // ---- tekstur ----
            GLES20.glActiveTexture(GLES20.GL_TEXTURE0)
            bitmapsToTex()
            t0 = SystemClock.uptimeMillis()
            ready = true
        }

        private fun bitmapsToTex() {
            asset("main.png").also { texMain = upload(it); it.recycle() }
            asset("lid.png").also { texLid = upload(it); it.recycle() }
            asset("weight.png").also { texW = upload(it); it.recycle() }
            makeFxAtlas().also { texFx = upload(it); it.recycle() }
        }

        // Atlas efek: 3 sel 144x144 px (4 px per unit SVG): 0 busur gelombang, 1 not, 2 kilau 4 sudut. Warna putih.
        private fun makeFxAtlas(): Bitmap {
            val bm = Bitmap.createBitmap(432, 144, Bitmap.Config.ARGB_8888)
            val c = Canvas(bm)
            val u = 4f
            val st = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFFFFFFFF.toInt(); style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND }
            val fl = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFFFFFFFF.toInt(); style = Paint.Style.FILL }
            // gelombang: busur lingkaran r=19.4 berpusat di pivot, sudut +-55.6 derajat
            c.save(); c.translate(PIV[0][0], PIV[0][1])
            st.strokeWidth = 1.8f * u
            c.drawArc(RectF(-19.4f * u, -19.4f * u, 19.4f * u, 19.4f * u), -55.6f, 111.2f, false, st)
            c.restore()
            // not
            c.save(); c.translate(144f + PIV[1][0], PIV[1][1]); c.scale(u, u)
            c.save(); c.rotate(-20f); c.drawOval(RectF(-3.4f, -2.6f, 3.4f, 2.6f), fl); c.restore()
            st.strokeWidth = 1.5f
            val stem = Path().apply { moveTo(2.9f, -0.8f); lineTo(2.9f, -11f); quadTo(7f, -9.5f, 7f, -5f) }
            c.drawPath(stem, st)
            c.restore()
            // kilau
            c.save(); c.translate(288f + PIV[2][0], PIV[2][1]); c.scale(u, u)
            val sp = Path().apply {
                moveTo(0f, -8f); quadTo(1f, -1f, 8f, 0f); quadTo(1f, 1f, 0f, 8f); quadTo(-1f, 1f, -8f, 0f); quadTo(-1f, -1f, 0f, -8f); close()
            }
            c.drawPath(sp, fl)
            c.restore()
            return bm
        }

        private val PIV = arrayOf(floatArrayOf(24f, 72f), floatArrayOf(48f, 100f), floatArrayOf(72f, 72f))

        fun resize(w: Int, h: Int) {
            vw = max(1, w)
            vh = max(1, h)
        }

        // skala kanvas -> layar: muat tinggi, rapat kanan
        private var sc = 1f
        private var offX = 0f

        /** Gambar satu sprite: sel [cell] atlas, pivot di (cx, cy) piksel kanvas, skala (unit), putar derajat, alpha. */
        private fun sprite(cell: Int, cx: Float, cy: Float, size: Float, rotDeg: Float, alpha: Float, sx: Float = 1f, sy: Float = 1f) {
            if (alpha <= 0.003f) return
            val pv = PIV[cell]
            val r = (rotDeg * PI / 180.0).toFloat()
            val cr = cos(r)
            val sr = sin(r)
            val px = floatArrayOf(0f, 144f, 0f, 144f)
            val py = floatArrayOf(0f, 0f, 144f, 144f)
            for (i in 0 until 4) {
                val lx = (px[i] - pv[0]) / 4f * K * size * sx
                val ly = (py[i] - pv[1]) / 4f * K * size * sy
                val rx = lx * cr - ly * sr
                val ry = lx * sr + ly * cr
                val X = offX + (cx + rx) * sc
                val Y = (cy + ry) * sc
                sprBuf.put(i * 4, X)
                sprBuf.put(i * 4 + 1, Y)
                sprBuf.put(i * 4 + 2, (cell * 144f + px[i]) / 432f)
                sprBuf.put(i * 4 + 3, py[i] / 144f)
            }
            GLES20.glUniform1f(sAl, alpha)
            sprBuf.position(0)
            GLES20.glVertexAttribPointer(sP, 2, GLES20.GL_FLOAT, false, 16, sprBuf)
            sprBuf.position(2)
            GLES20.glVertexAttribPointer(sU, 2, GLES20.GL_FLOAT, false, 16, sprBuf)
            GLES20.glDrawArrays(GLES20.GL_TRIANGLE_STRIP, 0, 4)
        }

        private fun blinkAmt(t: Float): Float {
            if (blinkT < 0f && t > nextBlink) {
                blinkT = t
                dbl = !wasDbl && Math.random() < 0.2
            }
            var b = 0f
            if (blinkT >= 0f) {
                val d = (t - blinkT) * 1000f
                if (d < 70f) b = ss(d / 70f)
                else if (d < 120f) b = 1f
                else if (d < 260f) b = 1f - ss((d - 120f) / 140f)
                else {
                    b = 0f
                    blinkT = -1f
                    wasDbl = dbl
                    nextBlink = if (dbl) t + 0.11f else t + 2.6f + Math.random().toFloat() * 3.2f
                }
            }
            return b
        }

        fun draw() {
            if (!ready) return
            val t = (SystemClock.uptimeMillis() - t0) / 1000f
            val dt = (t - lastT).coerceIn(0.001f, 0.05f)
            lastT = t
            val play = playing
            plS += ((if (play) 1f else 0f) - plS) * min(1f, dt * 4f)

            val pr = pokeReq
            if (pr != pokeDone) {
                pokeDone = pr
                sVel += 380f
                flick = 1f
                burstT = t
            }
            val acc = 130f * (0f - sAng) - 9f * sVel
            sVel += acc * dt
            sAng += sVel * dt
            flick += (0f - flick) * min(1f, dt * 2.2f)

            // denyut / anggukan: ngikut fase musik kalau ada, kalau tidak ayunan santai
            val amp = bobAmp.coerceIn(0f, 1f)
            val c = 0.5f + 0.5f * cos(bobPhase)
            val idle = 0.5f + 0.5f * sin(t * 2f * PI.toFloat() / 1.6f)
            val beat = idle * (1f - amp) + c * c * amp
            val head = (plS * (-0.6f - 2.0f * beat) + (-4.5f) * (1f - plS) - sAng * 0.14f) * PI.toFloat() / 180f
            val hv = if (prevHead.isNaN()) 0f else (head - prevHead) / max(dt, 0.001f)
            prevHead = head
            hl += ((-hv * 30f) - hl) * min(1f, dt * 6f)
            hl = hl.coerceIn(-22f, 22f)
            val ampW = (5f + 11f * plS) + flick * 18f
            val breath = sin(t * 2f * PI.toFloat() / 3.6f)
            val pulse = 0.05f * plS * beat

            for (k in 0 until nV) {
                var x = bx[k]
                var y = by[k]
                val wv = sin(t * 1.7f + ph[k]) + 0.5f * sin(t * 3.1f + ph[k] * 1.7f + 1f)
                val cwk = cw[k]
                if (cwk > 0f) {
                    x = CUPX + (x - CUPX) * (1f + pulse * cwk)
                    y = CUPY + (y - CUPY) * (1f + pulse * cwk)
                }
                val a = head * wD[k]
                if (a != 0f) {
                    val cs = cos(a)
                    val sn = sin(a)
                    val dx = x - PVX
                    val dy = y - PVY
                    x = PVX + dx * cs - dy * sn
                    y = PVY + dx * sn + dy * cs
                }
                val bw = wB[k]
                if (bw > 0f) {
                    val ex = 1f + 0.016f * breath * bw
                    val ey = 1f - 0.03f * breath * bw
                    x = 360f + (x - 360f) * ex
                    y = 928f + (y - 928f) * ey
                    val cl = ss((by[k] - 650f) / 120f)
                    x += bw * (2.2f + flick * 5f) * sin(t * 1.3f + by[k] * 0.016f + ph[k] * 0.3f) + bw * cl * 1.2f * sin(t * 0.8f + bx[k] * 0.01f)
                    y += bw * (1.1f + flick * 2f) * sin(t * 1.1f + bx[k] * 0.014f + 1f)
                }
                y += breath * 2.6f * wD[k]
                pos[k * 2] = x + M
                pos[k * 2 + 1] = y + M
            }
            posBuf.position(0)
            posBuf.put(pos)
            posBuf.position(0)

            var cl = min(1f, (1f - plS) * 3.5f)
            cl = cl * cl * (3f - 2f * cl)
            val bl = max(blinkAmt(t), cl)

            // ---- gambar ----
            GLES20.glBindFramebuffer(GLES20.GL_FRAMEBUFFER, 0)
            GLES20.glDisable(GLES20.GL_DEPTH_TEST)
            GLES20.glDisable(GLES20.GL_CULL_FACE)
            GLES20.glDisable(GLES20.GL_SCISSOR_TEST)
            GLES20.glViewport(0, 0, vw, vh)
            GLES20.glClearColor(0f, 0f, 0f, 0f)
            GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT)
            GLES20.glEnable(GLES20.GL_BLEND)
            GLES20.glBlendFunc(GLES20.GL_ONE, GLES20.GL_ONE_MINUS_SRC_ALPHA)

            sc = vh.toFloat() / CH
            val cwPx = (CW * sc).toInt()
            offX = (vw - cwPx).toFloat()
            GLES20.glViewport(vw - cwPx, 0, cwPx, vh)
            GLES20.glUseProgram(prog)
            GLES20.glUniform2f(uS, CW.toFloat(), CH.toFloat())
            GLES20.glUniform2f(uDm, (TW - 1).toFloat(), (TH - 1).toFloat())
            GLES20.glBindBuffer(GLES20.GL_ARRAY_BUFFER, 0)
            GLES20.glBindBuffer(GLES20.GL_ELEMENT_ARRAY_BUFFER, 0)
            GLES20.glEnableVertexAttribArray(aP)
            GLES20.glEnableVertexAttribArray(aU)
            GLES20.glVertexAttribPointer(aP, 2, GLES20.GL_FLOAT, false, 0, posBuf)
            GLES20.glVertexAttribPointer(aU, 2, GLES20.GL_FLOAT, false, 0, uvBuf)
            val TP = (PI * 2).toFloat()
            GLES20.glUniform3f(uPh, (t * 1.7f) % TP, (t * 3.1f + 1f) % TP, (t * 1.9f + 1f) % TP)
            GLES20.glUniform3f(uHp, ampW, hl, 0f)
            GLES20.glActiveTexture(GLES20.GL_TEXTURE2)
            GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, texW)
            GLES20.glUniform1i(uHw, 2)
            GLES20.glActiveTexture(GLES20.GL_TEXTURE0)
            GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, texMain)
            GLES20.glUniform1i(uT, 0)
            GLES20.glUniform1f(uA, 1f)
            idxBuf.position(0)
            GLES20.glDrawElements(GLES20.GL_TRIANGLES, idxCount, GLES20.GL_UNSIGNED_SHORT, idxBuf)
            if (bl > 0.01f) {
                GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, texLid)
                GLES20.glUniform1f(uA, bl)
                GLES20.glDrawElements(GLES20.GL_TRIANGLES, idxCount, GLES20.GL_UNSIGNED_SHORT, idxBuf)
            }

            // ---- efek ----
            if (effects) {
                GLES20.glViewport(0, 0, vw, vh)
                GLES20.glUseProgram(sprProg)
                GLES20.glUniform2f(sVp, vw.toFloat(), vh.toFloat())
                GLES20.glActiveTexture(GLES20.GL_TEXTURE0)
                GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, texFx)
                GLES20.glUniform1i(sTex, 0)
                GLES20.glEnableVertexAttribArray(sP)
                GLES20.glEnableVertexAttribArray(sU)
                val on = plS
                // gelombang suara dari headphone
                for (i in 0 until 3) {
                    val p = (((t - i * 0.8f) / 2.4f) % 1f + 1f) % 1f
                    val e = 1f - (1f - p) * (1f - p)
                    sprite(0, 459.5f, 410.5f, 1f + 1.3f * e, 0f, 0.85f * (1f - e) * on)
                }
                // not musik terbang
                val nx = floatArrayOf(551f, 604f, 516f)
                val ny = floatArrayOf(254f, 316f, 203f)
                val ndx = floatArrayOf(16f, 24f, 8f)
                for (i in 0 until 3) {
                    val p = (((t - i * 1.2f) / 3.6f) % 1f + 1f) % 1f
                    val e = p * p
                    val al = (if (p < 0.15f) p / 0.15f else 1f - (p - 0.15f) / 0.85f) * on
                    sprite(1, nx[i] + ndx[i] * K * e, ny[i] - 52f * K * e, 1f, 25f * e, al)
                }
                // kilau berkedip
                for (i in 0 until 2) {
                    val ph2 = (((t - i * 1.2f) / 2.4f) % 1f + 1f) % 1f
                    val m = 0.5f - 0.5f * cos(ph2 * 2f * PI.toFloat())
                    val al = 0.9f - 0.55f * m
                    val s = 1f - 0.55f * m
                    if (i == 0) sprite(2, -48f, 203f, s, 60f * m, al) else sprite(2, 697f, 106f, s * 0.75f, 60f * m, al)
                }
                // kilatan saat dicolek
                val bp = (t - burstT) / 0.8f
                if (bp in 0f..1f) {
                    val e = 1f - (1f - bp) * (1f - bp)
                    val al = if (bp < 0.35f) bp / 0.35f else 1f - (bp - 0.35f) / 0.65f
                    val s = if (bp < 0.35f) 0.2f + 1.3f * (bp / 0.35f) else 1.5f - 0.8f * ((bp - 0.35f) / 0.65f)
                    sprite(2, -26f, 360f, s * 1.375f, 180f * e, al)
                }
                GLES20.glDisableVertexAttribArray(sP)
                GLES20.glDisableVertexAttribArray(sU)
            }

            drawFade()
        }

        private fun drawFade() {
            val fp = fadePx
            if (fp <= 0) return
            val top = (fp.toFloat() / vh).coerceAtMost(1f) * 2f - 1f
            fadeBuf.position(0)
            fadeBuf.put(-1f).put(-1f).put(0f)
            fadeBuf.put(1f).put(-1f).put(0f)
            fadeBuf.put(-1f).put(top).put(1f)
            fadeBuf.put(1f).put(top).put(1f)
            GLES20.glViewport(0, 0, vw, vh)
            GLES20.glEnable(GLES20.GL_BLEND)
            GLES20.glBlendFunc(GLES20.GL_ZERO, GLES20.GL_SRC_COLOR)
            GLES20.glUseProgram(fadeProg)
            GLES20.glEnableVertexAttribArray(fadeP)
            GLES20.glEnableVertexAttribArray(fadeKk)
            fadeBuf.position(0)
            GLES20.glVertexAttribPointer(fadeP, 2, GLES20.GL_FLOAT, false, 12, fadeBuf)
            fadeBuf.position(2)
            GLES20.glVertexAttribPointer(fadeKk, 1, GLES20.GL_FLOAT, false, 12, fadeBuf)
            GLES20.glDrawArrays(GLES20.GL_TRIANGLE_STRIP, 0, 4)
            GLES20.glDisableVertexAttribArray(fadeP)
            GLES20.glDisableVertexAttribArray(fadeKk)
            GLES20.glBlendFunc(GLES20.GL_ONE, GLES20.GL_ONE_MINUS_SRC_ALPHA)
        }
    }
}
