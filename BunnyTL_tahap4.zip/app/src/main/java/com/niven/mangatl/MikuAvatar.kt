package com.niven.mangatl

import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.view.Gravity
import android.view.HapticFeedbackConstants
import android.view.ScaleGestureDetector
import android.view.ViewConfiguration
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.log10
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sqrt
import kotlin.random.Random

/**
 * Miku (Live2D, badan penuh dari kanvas modelnya) di kotak kanan-bawah layar "Sedang diputar".
 * Digambar DI BAWAH ikon suka / titik tiga / visualizer / seekbar (view biasa, disisipkan sebelum bottomBox),
 * jadi semua kontrol tetap terlihat dan bisa disentuh di atasnya. Posisi mengikuti tombol suka (anchor).
 *
 * Semua fitur model dipakai: kipas (buka / lipat), kuas, rok tipis, dada, mata hati, air mata, taring atas/bawah,
 * pipi merah, mulut, mata ^_^, ayunan badan + rambut (fisika), efek bawaan (Standby).
 * Sinyal: ketukan bass + energi dari VisTap. Dijeda = diam santai, lama dijeda = menangis kecil.
 */
class MikuAvatar(
    private val act: AppCompatActivity,
    private val root: FrameLayout,
    private val anchor: View,
    /** Avatar disisipkan tepat sebelum view ini (urutan gambar: avatar di bawah view ini dan sesudahnya). */
    private val above: View
) {
    private val cfg: ModelCfg? = try {
        ModelCfg.load(act, "miku")
    } catch (_: Throwable) {
        null
    }
    private val handler = Handler(Looper.getMainLooper())
    private val d = act.resources.displayMetrics.density

    private var view: KarinTexView? = null
    private var resumed = false
    private var playing = false
    private var failed = false
    private var registered = false

    // analisis audio
    private val buf = FloatArray(1024)
    private var lpState = 0f
    private var bassAvg = 0.02f
    private var lvl = 0f
    private var slow = 0f          // energi lambat (bagian lagu: tenang / ramai)
    private var mouth = 0f
    private var lastPos = 0
    private var lastMove = 0L
    private var lastBeat = 0L
    private var pausedSince = 0L
    private var nextHappy = 0L
    private var nextHeart = 0L
    private var nextFang = 0L
    private var dressUntil = 0L
    private var nextDress = 0L
    private var foldOn = false
    // anggukan: fase berkelanjutan yang dikunci ke tempo (bukan sentakan per ketukan)
    private val ivs = FloatArray(8)
    private var ivN = 0
    private var ivI = 0
    private var bobHz = 1.8f
    private var bobPhase = 0f
    private var bobAmp = 0f
    private var lastTick = 0L
    private var handMode = 0       // 0 kosong, 1 kipas terbuka, 2 kipas dilipat (kuas)
    private var handUntil = 0L
    private var taps = 0

    // pengaturan (Audio Engine > Avatar Miku) + nilai sementara selama gesture di pemutar
    private fun p(i: Int): Float = AudioEngine.get(AudioEngine.AVATAR, i)
    private fun enabled(): Boolean = AudioEngine.featureOn(AudioEngine.AVATAR)
    private var liveS: Float? = null
    private var liveX: Float? = null
    private var liveY: Float? = null
    private var dragging = false
    private var scaling = false
    private var moved = false
    private var downX = 0f
    private var downY = 0f
    private var startX = 0f
    private var startY = 0f
    private val slop = ViewConfiguration.get(act).scaledTouchSlop
    private val longRun = Runnable {
        dragging = true
        view?.performHapticFeedback(HapticFeedbackConstants.LONG_PRESS)
        view?.anim?.poke("pat", 0.6f)
    }
    private val scaleDetector = ScaleGestureDetector(act, object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
        override fun onScaleBegin(detector: ScaleGestureDetector): Boolean {
            handler.removeCallbacks(longRun)
            scaling = true
            return true
        }

        override fun onScale(detector: ScaleGestureDetector): Boolean {
            liveS = ((liveS ?: p(0)) * detector.scaleFactor).coerceIn(30f, 250f)
            relayout()
            return true
        }

        override fun onScaleEnd(detector: ScaleGestureDetector) {
            scaling = false
        }
    })

    /** Simpan nilai hasil gesture ke pengaturan. */
    private fun commitLive() {
        liveS?.let { AudioEngine.set(AudioEngine.AVATAR, 0, it) }
        liveX?.let { AudioEngine.set(AudioEngine.AVATAR, 1, it) }
        liveY?.let { AudioEngine.set(AudioEngine.AVATAR, 2, it) }
        liveS = null
        liveX = null
        liveY = null
    }

    private val tickRun = object : Runnable {
        override fun run() {
            if (!resumed) return
            tick()
            handler.postDelayed(this, 33L)
        }
    }

    /** Pasang view di akar layar. Dipanggil sekali dari onCreate setelah layout jadi. */
    fun attach() {
        val c = cfg ?: return
        if (view != null) return
        val v = KarinTexView(act, c)
        v.anim.levelSource = { mouth }
        v.onError = { msg ->
            if (!failed) {
                failed = true
                Toast.makeText(act, "Avatar Miku gagal dimuat: $msg", Toast.LENGTH_LONG).show()
                detach()
            }
        }
        v.setOnTouchListener { _, e -> onTouch(e) }
        val at = root.indexOfChild(above).let { if (it < 0) root.childCount else it }
        root.addView(v, at, FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.TOP or Gravity.START))
        view = v
        KarinTex.prefetch(act, c.texturePaths())
        val l = View.OnLayoutChangeListener { _, _, _, _, _, _, _, _, _ -> relayout() }
        anchor.addOnLayoutChangeListener(l)
        root.addOnLayoutChangeListener(l)
        relayout()
        if (resumed) v.onResume()
    }

    /** Ketuk = tersipu. Tahan lama lalu geser = pindah. Cubit = ukuran. Hasil disimpan di pengaturan. */
    private fun onTouch(e: MotionEvent): Boolean {
        scaleDetector.onTouchEvent(e)
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                downX = e.rawX
                downY = e.rawY
                startX = p(1)
                startY = p(2)
                dragging = false
                moved = false
                handler.removeCallbacks(longRun)
                handler.postDelayed(longRun, 450L)
            }
            MotionEvent.ACTION_POINTER_DOWN -> {
                handler.removeCallbacks(longRun)
                moved = true
            }
            MotionEvent.ACTION_MOVE -> {
                if (!scaling && e.pointerCount == 1) {
                    val dx = e.rawX - downX
                    val dy = e.rawY - downY
                    if (!dragging && (abs(dx) > slop || abs(dy) > slop)) {
                        moved = true
                        handler.removeCallbacks(longRun)
                    }
                    if (dragging) {
                        liveX = (startX + dx / d).coerceIn(-400f, 400f)
                        liveY = (startY + dy / d).coerceIn(-700f, 400f)
                        relayout()
                    }
                }
            }
            MotionEvent.ACTION_UP -> {
                handler.removeCallbacks(longRun)
                if (!dragging && !scaling && !moved) onTap()
                dragging = false
                commitLive()
            }
            MotionEvent.ACTION_CANCEL -> {
                handler.removeCallbacks(longRun)
                dragging = false
                commitLive()
            }
        }
        return true
    }

    private fun detach() {
        val v = view ?: return
        v.onPause()
        root.removeView(v)
        view = null
        KarinTex.prefetch(act, emptyList())
    }

    /**
     * Kotak bawaan: lebar 260dp x tinggi 188dp, rapat kanan, atas 102dp di atas tombol suka (bawah tepat di bawah seekbar).
     * Ukuran (%) membesar ke atas-kiri dari pojok kanan-bawah kotak itu; Posisi X/Y menggeser. Seluruh kanvas model selalu
     * muat di dalam view (zoom 1), jadi badan tidak pernah terpotong.
     */
    private fun relayout() {
        val v = view ?: return
        if (anchor.height <= 0 || root.width <= 0) return
        val rl = IntArray(2)
        val al = IntArray(2)
        root.getLocationOnScreen(rl)
        anchor.getLocationOnScreen(al)
        val s = (liveS ?: p(0)).coerceIn(30f, 250f) / 100f
        val ox = ((liveX ?: p(1)) * d).toInt()
        val oy = ((liveY ?: p(2)) * d).toInt()
        val baseW = min((260 * d).toInt(), (root.width * 0.66f).toInt())
        val baseH = (baseW * 188f / 260f).toInt()
        val w = (baseW * s).toInt().coerceAtLeast(40)
        val h = (baseH * s).toInt().coerceAtLeast(30)
        val right = root.width + ox
        val bottom = (al[1] - rl[1]) - (102 * d).toInt() + baseH + oy
        val left = right - w
        val top = bottom - h
        val lp = v.layoutParams as FrameLayout.LayoutParams
        if (lp.width != w || lp.height != h || lp.leftMargin != left || lp.topMargin != top) {
            lp.width = w
            lp.height = h
            lp.leftMargin = left
            lp.topMargin = top
            v.layoutParams = lp
        }
        v.setFadeBottom((h * p(3).coerceIn(0f, 40f) / 100f).toInt())
    }

    /** Nyalakan / matikan sesuai saklar fitur (dibaca ulang tiap kembali ke layar ini). */
    private fun applyEnabled() {
        val v = view ?: return
        if (enabled() && !failed) {
            v.visibility = View.VISIBLE
            if (resumed) v.onResume()
            registerTap(resumed)
        } else {
            v.visibility = View.INVISIBLE
            v.onPause()
            registerTap(false)
        }
    }

    fun onResume() {
        resumed = true
        relayout()
        applyEnabled()
        val now = SystemClock.uptimeMillis()
        lastMove = now
        pausedSince = now
        nextHappy = now + 8000L + Random.nextLong(8000L)
        nextHeart = now + 30000L + Random.nextLong(30000L)
        nextFang = now + 12000L + Random.nextLong(12000L)
        nextDress = now + 20000L + Random.nextLong(15000L)
        handler.removeCallbacks(tickRun)
        handler.post(tickRun)
    }

    fun onPause() {
        resumed = false
        handler.removeCallbacks(tickRun)
        handler.removeCallbacks(longRun)
        commitLive()
        registerTap(false)
        view?.onPause()
    }

    fun onDestroy() {
        onPause()
        detach()
    }

    fun setPlaying(p: Boolean) {
        if (p == playing) return
        playing = p
        pausedSince = SystemClock.uptimeMillis()
        val a = view?.anim ?: return
        if (p) {
            a.happy(1.2f)
            a.triggerExpr("heartEyes", 2f)   // senang lagu jalan lagi
        }
    }

    /** Tidak dipakai lagi (avatar di bawah semua popup, jadi tidak perlu disembunyikan). */
    fun setSuppressed(s: Boolean) {}

    /** Lagu ganti: sapaan kecil. */
    fun onTrackChanged() {
        val a = view?.anim ?: return
        a.poke("pat", 0.7f)
        a.happy(1.5f)
    }

    private fun registerTap(on: Boolean) {
        if (on == registered) return
        registered = on
        if (on) {
            VisTap.viewers++
            VisTap.forced = true
        } else {
            VisTap.viewers = max(0, VisTap.viewers - 1)
            VisTap.forced = false
        }
    }

    private fun onTap() {
        val a = view?.anim ?: return
        taps++
        a.poke("pat", 1f)
        when (taps % 4) {
            0 -> a.triggerExpr("heartEyes", 3.5f)
            2 -> {
                a.triggerExpr("blush", 3f)
                a.triggerExpr("fang", 1.5f)
            }
            else -> a.triggerExpr("blush", 3f)
        }
    }

    private fun tick() {
        val a = view?.anim ?: return
        val now = SystemClock.uptimeMillis()
        val pos = VisTap.pos
        if (pos != lastPos) {
            lastPos = pos
            lastMove = now
        }
        if (!enabled()) return
        val follow = p(4) >= 0.5f
        val live = playing && now - lastMove < 300L
        var strong = false
        if (live) {
            VisTap.read(buf, buf.size, 2, AudioEngine.meterBufferMs)
            val k = min(1f, (2.0 * PI * 150.0 / VisTap.sampleRate).toFloat())
            var s = 0f
            var sb = 0f
            var y = lpState
            for (x in buf) {
                y += k * (x - y)
                s += x * x
                sb += y * y
            }
            lpState = y
            val rms = sqrt(s / buf.size)
            val bass = sqrt(sb / buf.size)
            val db = 20f * log10(rms + 1e-6f)
            val lv = ((db + 54f) / 40f).coerceIn(0f, 1f)
            lvl += (lv - lvl) * 0.25f
            slow += (lvl - slow) * 0.006f
            bassAvg += (bass - bassAvg) * 0.02f
            val ratio = bass / (bassAvg + 0.005f)
            if (ratio > 1.6f && bass > 0.025f && now - lastBeat > 330L) {
                val dtb = (now - lastBeat).toFloat()
                lastBeat = now
                strong = ratio > 2.2f
                // simpan selang ketukan yang masuk akal, lalu ambil median -> tempo stabil
                if (dtb in 330f..1300f) {
                    ivs[ivI] = dtb; ivI = (ivI + 1) % ivs.size; if (ivN < ivs.size) ivN++
                    if (ivN >= 4) {
                        val srt = ivs.copyOf(ivN).also { it.sort() }
                        var hz = 1000f / srt[ivN / 2]
                        while (hz > 2.2f) hz /= 2f
                        while (hz < 0.8f) hz *= 2f
                        bobHz += (hz - bobHz) * 0.15f
                    }
                }
                // geser fase pelan-pelan supaya puncak anggukan jatuh di ketukan (tanpa lompatan)
                val err = -((bobPhase + PI.toFloat()) % (2f * PI.toFloat()) - PI.toFloat())
                bobPhase += err * 0.12f
            }
        } else {
            lvl *= 0.9f
            slow *= 0.995f
        }
        mouth = if (playing) ((lvl - 0.35f) * 1.6f).coerceIn(0f, 0.7f) else 0f
        a.state = if (playing) KarinState.SPEAKING else KarinState.IDLE
        val dts = if (lastTick == 0L) 0.033f else ((now - lastTick) / 1000f).coerceIn(0.005f, 0.1f)
        lastTick = now
        val tgtAmp = if (playing && follow) 0.35f + 0.65f * slow.coerceIn(0f, 1f).let { it * 0.5f + lvl * 0.5f } else 0f
        bobAmp += (tgtAmp - bobAmp) * min(1f, dts * 1.5f)        // amplitudo naik-turun halus
        if (!live) bobHz += (1.6f - bobHz) * min(1f, dts * 0.3f)  // tidak ada ketukan: tempo santai
        bobPhase += 2f * PI.toFloat() * bobHz * dts
        if (bobPhase > 600f) bobPhase %= (2f * PI.toFloat())
        a.bobAmp = bobAmp
        a.bobPhase = bobPhase
        a.sway = 0f
        a.joy = if (playing) 0.35f + 0.65f * lvl else 0f

        // ---- properti model: kipas, kuas, rok tipis, dada, taring, air mata ----
        // tangan bergantian: kosong / kipas terbuka / kipas dilipat jadi kuas, bukan kipas terus
        if (!playing) {
            handMode = 0
            handUntil = 0L
        } else if (now > handUntil) {
            val r = Random.nextFloat()
            val busy = slow > 0.5f
            val prev = handMode
            handMode = when {
                busy -> if (r < 0.55f) 1 else if (r < 0.8f) 2 else 0
                else -> if (r < 0.3f) 1 else if (r < 0.65f) 2 else 0
            }
            if (handMode == prev) handMode = (prev + 1 + Random.nextInt(2)) % 3
            handUntil = now + 7000L + Random.nextLong(9000L)
        }
        a.setExprHold("fan", handMode != 0)
        a.setExprHold("fanFold", handMode == 2)

        if (playing && now > nextDress) {                      // rok tipis berkibar sesekali
            dressUntil = now + 9000L
            nextDress = now + 24000L + Random.nextLong(16000L)
        }
        a.setExprHold("dress", playing && (now < dressUntil || slow > 0.62f))

        if (strong) a.triggerExpr("chest", 0.35f)              // dada berdenyut di ketukan keras

        if (playing && mouth > 0.4f && now > nextFang) {       // taring saat mulut lebar, atas / bawah bergantian
            a.triggerExpr(if (Random.nextBoolean()) "fang" else "fangDown", 1.4f)
            nextFang = now + 9000L + Random.nextLong(12000L)
        }

        if (playing) {
            if (now > nextHappy) {
                a.happy(2f)
                nextHappy = now + 14000L + Random.nextLong(14000L)
            }
            if (now > nextHeart) {
                a.triggerExpr("heartEyes", 3.5f)
                nextHeart = now + 45000L + Random.nextLong(30000L)
            }
        }
        // dijeda lama: murung, air mata menetes (efek Standby ikut jalan)
        a.setExprHold("tears", !playing && now - pausedSince > 6000L)
    }
}
