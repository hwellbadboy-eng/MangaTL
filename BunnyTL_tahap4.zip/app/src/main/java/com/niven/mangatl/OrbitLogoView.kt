package com.niven.mangatl

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.PorterDuff
import android.graphics.PorterDuffXfermode
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.SweepGradient
import android.util.AttributeSet
import android.view.animation.LinearInterpolator
import androidx.appcompat.widget.AppCompatImageView
import kotlin.math.cos
import kotlin.math.sin

/**
 * Logo kelinci. Saat sibuk, cincin putih di logo meredup dan sebuah meteor (ekor + cahaya di ujung)
 * berputar mengelilingi cincin itu (masuk ke belakang kepala kelinci, lalu muncul lagi).
 */
class OrbitLogoView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : AppCompatImageView(context, attrs) {

    private val ring: Bitmap = BitmapFactory.decodeResource(resources, R.drawable.logo_ring)
    private val dst = RectF()
    private val dimPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        xfermode = PorterDuffXfermode(PorterDuff.Mode.DST_OUT)
    }
    private val ringPaint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
    private val cometPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        xfermode = PorterDuffXfermode(PorterDuff.Mode.SRC_IN)
    }
    private val m = Matrix()
    private var shader: SweepGradient? = null

    // Posisi cincin untuk tiap sudut (0..359 derajat), dipakai menaruh cahaya di ujung meteor.
    private val gx = FloatArray(360)
    private val gy = FloatArray(360)
    private val gv = FloatArray(360)
    private val glowPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private var glowShader: RadialGradient? = null

    init {
        buildTable()
    }

    private fun buildTable() {
        val bw = ring.width
        val bh = ring.height
        val px = IntArray(bw * bh)
        ring.getPixels(px, 0, bw, 0, 0, bw, bh)
        val cxb = bw * 0.5f
        val cyb = bh * 0.586f
        val hit = BooleanArray(360)
        for (a in 0 until 360) {
            val r = Math.toRadians(a.toDouble())
            val dx = cos(r).toFloat()
            val dy = sin(r).toFloat()
            var sx = 0f
            var sy = 0f
            var n = 0
            var s = 0f
            while (s < bw * 1.2f) {
                val x = (cxb + dx * s).toInt()
                val y = (cyb + dy * s).toInt()
                if (x in 0 until bw && y in 0 until bh && (px[y * bw + x] ushr 24) > 128) {
                    sx += x
                    sy += y
                    n++
                }
                s += 1f
            }
            if (n > 0) {
                gx[a] = sx / n / bw
                gy[a] = sy / n / bh
                hit[a] = true
            }
        }
        // sudut yang ketutup kepala kelinci: pinjam posisi dari sudut terdekat yang kena cincin
        for (a in 0 until 360) {
            if (hit[a]) continue
            for (k in 1..180) {
                val l = (a - k + 360) % 360
                val rr = (a + k) % 360
                if (hit[l]) { gx[a] = gx[l]; gy[a] = gy[l]; break }
                if (hit[rr]) { gx[a] = gx[rr]; gy[a] = gy[rr]; break }
            }
        }
        // cahaya memudar halus saat masuk/keluar dari belakang kepala
        for (a in 0 until 360) {
            var t = 0f
            for (k in -6..6) if (hit[(a + k + 360) % 360]) t += 1f
            gv[a] = t / 13f
        }
    }

    private var busy = false
    private var amount = 0f   // 0 = logo biasa, 1 = mode loading penuh
    private var phase = 0f    // 0..1 satu putaran
    private var spin: ValueAnimator? = null
    private var fade: ValueAnimator? = null

    fun setBusy(b: Boolean) {
        busy = b
        fade?.cancel()
        fade = ValueAnimator.ofFloat(amount, if (b) 1f else 0f).apply {
            duration = 300
            addUpdateListener { amount = it.animatedValue as Float; invalidate() }
            start()
        }
        if (b) {
            if (spin == null) {
                spin = ValueAnimator.ofFloat(0f, 1f).apply {
                    duration = 1500
                    repeatCount = ValueAnimator.INFINITE
                    interpolator = LinearInterpolator()
                    addUpdateListener { phase = it.animatedValue as Float; invalidate() }
                    start()
                }
            }
        } else {
            postDelayed({
                if (!busy) {
                    spin?.cancel()
                    spin = null
                }
            }, 350)
        }
    }

    /**
     * Sudut kepala kilatan (derajat, searah jarum jam dari arah jam 3) dengan pusat orbit
     * di tengah kepala kelinci. Bagian cincin yang terlihat ada di sudut 164 sampai -17,
     * sisanya tersembunyi di belakang kepala, jadi dilewati lebih cepat.
     */
    private fun headAngle(p: Float): Float =
        if (p < 0.7f) 164f - 181f * (p / 0.7f) else -17f - 179f * ((p - 0.7f) / 0.3f)

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        shader = null
        glowShader = null
    }

    override fun onDraw(canvas: Canvas) {
        if (amount <= 0.001f) {
            super.onDraw(canvas)
            return
        }
        val w = width.toFloat()
        val h = height.toFloat()
        // area gambar logo (di dalam padding); padding menyisakan ruang buat cahaya meluber keluar
        dst.set(paddingLeft.toFloat(), paddingTop.toFloat(), w - paddingRight, h - paddingBottom)
        val cw = dst.width()
        val ch = dst.height()
        val cx = dst.left + cw * 0.5f
        val cy = dst.top + ch * 0.586f

        val bounds = RectF(0f, 0f, w, h)
        val outer = canvas.saveLayer(bounds, null)
        super.onDraw(canvas)

        // redupkan cincin
        dimPaint.alpha = (190 * amount).toInt()
        canvas.drawBitmap(ring, null, dst, dimPaint)

        // ekor meteor: gradasi sapuan yang dipotong persis mengikuti bentuk cincin
        val inner = canvas.saveLayer(bounds, null)
        canvas.drawBitmap(ring, null, dst, ringPaint)
        val sg = shader ?: SweepGradient(
            cx, cy,
            intArrayOf(0xFFFFFFFF.toInt(), 0x00FFFFFF, 0x00FFFFFF, 0xFFFFFFFF.toInt()),
            floatArrayOf(0f, 0.22f, 0.985f, 1f)
        ).also { shader = it }
        val head = headAngle(phase)
        m.setRotate(head, cx, cy)
        sg.setLocalMatrix(m)
        cometPaint.shader = sg
        cometPaint.alpha = (255 * amount).toInt()
        canvas.drawRect(dst, cometPaint)
        canvas.restoreToCount(inner)

        // cahaya di ujung meteor
        val idx = (((Math.round(head) % 360) + 360) % 360)
        val gAlpha = gv[idx] * amount
        if (gAlpha > 0.01f) {
            val radius = cw * 0.17f
            val gs = glowShader ?: RadialGradient(
                0f, 0f, radius,
                intArrayOf(0xFFFFFFFF.toInt(), 0x80FFFFFF.toInt(), 0x00FFFFFF),
                floatArrayOf(0f, 0.3f, 1f),
                Shader.TileMode.CLAMP
            ).also { glowShader = it }
            glowPaint.shader = gs
            glowPaint.alpha = (255 * gAlpha).toInt()
            val save = canvas.save()
            canvas.translate(dst.left + gx[idx] * cw, dst.top + gy[idx] * ch)
            canvas.drawCircle(0f, 0f, radius, glowPaint)
            canvas.restoreToCount(save)
        }

        canvas.restoreToCount(outer)
    }

    override fun onDetachedFromWindow() {
        spin?.cancel()
        fade?.cancel()
        spin = null
        super.onDetachedFromWindow()
    }
}
