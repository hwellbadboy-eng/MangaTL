package com.niven.mangatl

import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import android.util.Log
import android.webkit.CookieManager
import android.webkit.WebStorage
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.security.KeyStore
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

/** Satu cookie claude.ai yang direkam dari WebView. */
class ClaudeCookie(
    val domain: String, val path: String, val secure: Boolean, val httpOnly: Boolean,
    val expiry: Long, val name: String, val value: String
)

/** Satu slot akun Claude. [dim] = sudah dipakai (redup), [expired] = sesi ditolak Claude (perlu login ulang). */
class ClaudeSlot(
    var name: String = "",
    var email: String = "",
    var cookies: List<ClaudeCookie> = emptyList(),
    var dim: Boolean = false,
    var expired: Boolean = false,
    var alias: String = "" // nama slot buatan pengguna (menang atas nama profil)
) {
    val filled get() = cookies.isNotEmpty()
    val label get() = alias.ifBlank { name }
}

/**
 * Slot akun Claude (web). Tiap slot menyimpan cookies sesi claude.ai miliknya sendiri, terenkripsi (AES-GCM,
 * kunci di Android Keystore). Pilih slot -> cookies claude.ai di WebView diganti dengan milik slot itu,
 * jadi langsung masuk tanpa login ulang. Password tidak pernah disimpan.
 * Cookies claude.ai TIDAK ikut masuk cookies.txt milik yt-dlp (lihat DlCookies).
 */
object ClaudeSlots {
    private const val TAG = "ClaudeSlots"
    const val MIN_SLOTS = 4
    const val MAX_SLOTS = 20
    const val HOME = "https://claude.ai/"
    const val LOGIN = "https://claude.ai/login"
    val SITE = LoginSite("Claude", "claude.ai", LOGIN)

    private const val ALIAS = "bunnytl_claude_slots"
    private const val CHROMIUM_EPOCH = 11_644_473_600L

    private fun sp(ctx: Context) = ctx.getSharedPreferences("claude_slots", Context.MODE_PRIVATE)

    fun isClaudeDomain(d: String): Boolean {
        val h = d.trimStart('.').lowercase()
        return h == "claude.ai" || h.endsWith(".claude.ai")
    }

    // ---------------------------------------------------------------- enkripsi

    private fun key(): SecretKey {
        val ks = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
        (ks.getKey(ALIAS, null) as? SecretKey)?.let { return it }
        val g = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore")
        g.init(
            KeyGenParameterSpec.Builder(ALIAS, KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT)
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                .setKeySize(256)
                .build()
        )
        return g.generateKey()
    }

    private fun encrypt(text: String): String {
        val c = Cipher.getInstance("AES/GCM/NoPadding")
        c.init(Cipher.ENCRYPT_MODE, key())
        val out = c.iv + c.doFinal(text.toByteArray(Charsets.UTF_8))
        return Base64.encodeToString(out, Base64.NO_WRAP)
    }

    private fun decrypt(b64: String): String {
        val raw = Base64.decode(b64, Base64.NO_WRAP)
        val c = Cipher.getInstance("AES/GCM/NoPadding")
        c.init(Cipher.DECRYPT_MODE, key(), GCMParameterSpec(128, raw.copyOfRange(0, 12)))
        return String(c.doFinal(raw, 12, raw.size - 12), Charsets.UTF_8)
    }

    // ---------------------------------------------------------------- penyimpanan slot

    /**
     * Jumlah slot yang tampil: selalu ada satu slot kosong setelah slot terakhir yang terisi/diberi nama
     * (minimal [MIN_SLOTS], maksimal [MAX_SLOTS]). Isi slot terakhir -> slot baru muncul sendiri.
     */
    fun count(ctx: Context): Int {
        val p = sp(ctx)
        var last = -1
        for (i in 0 until MAX_SLOTS) if (p.contains("slot_$i")) last = i
        return (last + 2).coerceIn(MIN_SLOTS, MAX_SLOTS)
    }

    fun active(ctx: Context) = sp(ctx).getInt("active", -1)
    private fun setActive(ctx: Context, i: Int) = sp(ctx).edit().putInt("active", i).apply()

    fun get(ctx: Context, i: Int): ClaudeSlot? {
        val enc = sp(ctx).getString("slot_$i", null) ?: return null
        return runCatching {
            val o = JSONObject(decrypt(enc))
            val arr = o.optJSONArray("c") ?: JSONArray()
            val list = (0 until arr.length()).map {
                val k = arr.getJSONObject(it)
                ClaudeCookie(
                    k.getString("d"), k.optString("p", "/"), k.optBoolean("s", true), k.optBoolean("h", false),
                    k.optLong("t", 0L), k.getString("k"), k.optString("v", "")
                )
            }
            ClaudeSlot(o.optString("n"), o.optString("e"), list, o.optBoolean("x", false), o.optBoolean("z", false), o.optString("a"))
        }.onFailure { Log.w(TAG, "slot $i tidak terbaca", it) }.getOrNull()
    }

    fun put(ctx: Context, i: Int, s: ClaudeSlot): Boolean {
        if (!s.filled && s.alias.isBlank()) { sp(ctx).edit().remove("slot_$i").apply(); return true } // slot kosong tanpa nama = tidak disimpan
        return putEncrypted(ctx, i, s)
    }

    private fun putEncrypted(ctx: Context, i: Int, s: ClaudeSlot): Boolean = runCatching {
        val arr = JSONArray()
        s.cookies.forEach {
            arr.put(JSONObject().put("d", it.domain).put("p", it.path).put("s", it.secure).put("h", it.httpOnly)
                .put("t", it.expiry).put("k", it.name).put("v", it.value))
        }
        val o = JSONObject().put("n", s.name).put("e", s.email).put("x", s.dim).put("z", s.expired).put("a", s.alias).put("c", arr)
        sp(ctx).edit().putString("slot_$i", encrypt(o.toString())).apply()
        true
    }.onFailure { Log.w(TAG, "slot $i gagal disimpan", it) }.getOrDefault(false)

    fun clear(ctx: Context, i: Int) {
        val alias = get(ctx, i)?.alias.orEmpty()
        sp(ctx).edit().remove("slot_$i").apply()
        if (alias.isNotBlank()) put(ctx, i, ClaudeSlot(alias = alias)) // nama slot tetap ada
        if (active(ctx) == i) setActive(ctx, -1)
    }

    /** Slot [i] dibuka: slot aktif sebelumnya jadi redup (sudah dipakai), [i] jadi aktif. */
    fun open(ctx: Context, i: Int) {
        val p = active(ctx)
        if (p in 0 until count(ctx) && p != i) get(ctx, p)?.let { it.dim = true; put(ctx, p, it) }
        setActive(ctx, i)
    }

    /** Tombol Reset: hanya menyalakan lagi tanda redup. Cookies/akun tidak disentuh. */
    fun resetDim(ctx: Context) {
        for (i in 0 until count(ctx)) get(ctx, i)?.let { if (it.dim) { it.dim = false; put(ctx, i, it) } }
    }

    // ---------------------------------------------------------------- cookies WebView

    fun hasSession(list: List<ClaudeCookie>) = list.any { it.name == "sessionKey" && it.value.isNotEmpty() }

    /** Cookies claude.ai yang sekarang ada di WebView (database Chromium + CookieManager untuk nilai terbaru). */
    fun readWebCookies(ctx: Context): List<ClaudeCookie> {
        val cm = CookieManager.getInstance()
        cm.flush()
        val map = LinkedHashMap<String, ClaudeCookie>()
        runCatching { fromDb(ctx) }.onFailure { Log.w(TAG, "baca db cookies gagal", it) }
            .getOrDefault(emptyList()).forEach { map[it.name] = it }
        val far = System.currentTimeMillis() / 1000 + 365L * 24 * 3600
        for (kv in (cm.getCookie("https://claude.ai") ?: "").split(';')) {
            val i = kv.indexOf('=')
            if (i <= 0) continue
            val n = kv.substring(0, i).trim()
            val v = kv.substring(i + 1).trim()
            val old = map[n]
            map[n] = if (old != null) ClaudeCookie(old.domain, old.path, old.secure, old.httpOnly, old.expiry, n, v)
            else ClaudeCookie(".claude.ai", "/", true, false, far, n, v)
        }
        return map.values.toList()
    }

    private fun fromDb(ctx: Context): List<ClaudeCookie> {
        val db = File(ctx.dataDir, "app_webview/Default/Cookies")
        if (!db.isFile) return emptyList()
        val now = System.currentTimeMillis() / 1000
        val far = now + 365L * 24 * 3600
        val out = ArrayList<ClaudeCookie>()
        SQLiteDatabase.openDatabase(db.absolutePath, null, SQLiteDatabase.OPEN_READONLY).use { d ->
            d.query(
                "cookies", arrayOf("host_key", "expires_utc", "path", "name", "value", "is_secure", "is_httponly"),
                null, null, null, null, null
            ).use { c ->
                while (c.moveToNext()) {
                    val host = c.getString(0) ?: continue
                    if (!isClaudeDomain(host)) continue
                    val name = c.getString(3) ?: continue
                    if (name.isEmpty()) continue
                    val raw = c.getLong(1)
                    val exp = if (raw <= 0L) far else raw / 1_000_000L - CHROMIUM_EPOCH
                    if (exp in 1..now) continue
                    out += ClaudeCookie(host, c.getString(2) ?: "/", c.getInt(5) == 1, c.getInt(6) == 1, exp, name, c.getString(4) ?: "")
                }
            }
        }
        return out
    }

    /** Hapus cookies + storage claude.ai dari WebView (akun lain tidak terpengaruh). */
    fun expireWeb() {
        val cm = CookieManager.getInstance()
        val gone = "Thu, 01 Jan 1970 00:00:00 GMT"
        for (u in listOf("https://claude.ai", "https://www.claude.ai")) {
            val raw = cm.getCookie(u) ?: continue
            for (kv in raw.split(';')) {
                val n = kv.substringBefore('=').trim()
                if (n.isEmpty()) continue
                cm.setCookie(u, "$n=; Expires=$gone; Max-Age=0; Path=/")
                cm.setCookie(u, "$n=; Expires=$gone; Max-Age=0; Path=/; Domain=.claude.ai")
            }
        }
        cm.flush()
        runCatching { WebStorage.getInstance().deleteOrigin("https://claude.ai") }
    }

    /** Ganti cookies claude.ai di WebView dengan milik [slot]; [done] dipanggil setelah semuanya terpasang. */
    fun inject(slot: ClaudeSlot, done: () -> Unit) {
        expireWeb()
        val list = slot.cookies
        if (list.isEmpty()) { done(); return }
        val cm = CookieManager.getInstance()
        val fmt = SimpleDateFormat("EEE, dd MMM yyyy HH:mm:ss 'GMT'", Locale.US).apply { timeZone = TimeZone.getTimeZone("GMT") }
        var left = list.size
        for (c in list) {
            val sb = StringBuilder("${c.name}=${c.value}; Path=${c.path.ifEmpty { "/" }}")
            if (c.domain.startsWith(".")) sb.append("; Domain=").append(c.domain)
            if (c.expiry in 1..253_402_300_799L) sb.append("; Expires=").append(fmt.format(Date(c.expiry * 1000)))
            if (c.secure) sb.append("; Secure")
            if (c.httpOnly) sb.append("; HttpOnly")
            cm.setCookie("https://" + c.domain.trimStart('.'), sb.toString()) {
                left--
                if (left == 0) { cm.flush(); done() }
            }
        }
    }
}
