package com.niven.mangatl

import android.content.Context
import android.graphics.Canvas
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.PorterDuff
import android.graphics.PorterDuffXfermode
import android.graphics.Shader
import android.util.AttributeSet
import androidx.recyclerview.widget.RecyclerView

/**
 * Daftar chat yang tepi atasnya bisa dipudarkan: bubble yang naik makin transparan
 * dan hilang tepat di tepi atas daftar (dipakai saat avatar di belakang chat).
 */
class FadeRecyclerView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : RecyclerView(context, attrs) {

    private var fadeTop = 0f
    private val fadePaint = Paint().apply { xfermode = PorterDuffXfermode(PorterDuff.Mode.DST_IN) }

    fun setFadeTop(px: Float) {
        if (px == fadeTop) return
        fadeTop = px
        fadePaint.shader = if (px > 0f) LinearGradient(0f, 0f, 0f, px, 0x00000000, 0xFF000000.toInt(), Shader.TileMode.CLAMP) else null
        invalidate()
    }

    override fun dispatchDraw(canvas: Canvas) {
        val fade = fadeTop > 0f && width > 0 && height > 0
        val layer = if (fade) canvas.saveLayer(0f, 0f, width.toFloat(), height.toFloat(), null) else -1
        super.dispatchDraw(canvas)
        if (fade) {
            canvas.drawRect(0f, 0f, width.toFloat(), fadeTop, fadePaint)
            canvas.restoreToCount(layer)
        }
    }
}
