package com.niven.mangatl

import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.exp
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow
import kotlin.math.sin
import kotlin.math.sqrt

/** Allpass Schroeder untuk difusi masukan reverb. */
class Allpass(size: Int) {
    private val buf = DoubleArray(max(size, 2))
    private var pos = 0
    fun process(x: Double, g: Double): Double {
        val d = buf[pos]
        val y = d - g * x
        buf[pos] = x + g * y
        pos++
        if (pos >= buf.size) pos = 0
        return y
    }
}

// ======================================================================
// Reverb: difusi masukan + pantulan awal + FDN 8 jalur (matriks Hadamard)
// ======================================================================
class ReverbFx : DspFx() {
    private val nLines = 8
    private val base = intArrayOf(1327, 1637, 1949, 2269, 2593, 2927, 3251, 3571)
    private var sr = 0
    private var lines = Array(nLines) { DoubleArray(4) }
    private val lens = IntArray(nLines) { 4 }
    private val pos = IntArray(nLines)
    private val damp = DoubleArray(nLines)
    private val g = DoubleArray(nLines)
    private var dampK = 0.5
    private var apL1 = Allpass(2)
    private var apL2 = Allpass(2)
    private var apR1 = Allpass(2)
    private var apR2 = Allpass(2)
    private var apG = 0.5
    private var preL = DelayLine(8)
    private var preR = DelayLine(8)
    private var early = DelayLine(8)
    private var preSamp = 0.0
    private val erMs = doubleArrayOf(4.3, 7.9, 12.1, 16.6, 22.7, 29.3, 37.1, 45.8)
    private val erG = doubleArrayOf(0.8, 0.7, 0.6, 0.5, 0.42, 0.35, 0.28, 0.22)
    private var erScale = 1.0
    private var earlyLin = 0.0
    private var lateLin = 0.0
    private var wet = 0.0
    private var dry = 1.0
    private var width = 1.0
    private val hp = Array(2) { Biquad() }
    private val lp = Array(2) { Biquad() }
    private val tmp = DoubleArray(8)

    override fun update(sr: Int, os: Int) {
        val v = AudioEngine.raw(AudioEngine.REVERB)
        if (sr != this.sr) {
            this.sr = sr
            val sc = sr / 48000.0
            lines = Array(nLines) { DoubleArray((base[it] * 1.8 * sc).toInt() + 8) }
            apL1 = Allpass((142 * sc).toInt()); apL2 = Allpass((107 * sc).toInt())
            apR1 = Allpass((151 * sc).toInt()); apR2 = Allpass((113 * sc).toInt())
            preL = DelayLine((0.21 * sr).toInt()); preR = DelayLine((0.21 * sr).toInt())
            early = DelayLine((0.35 * sr).toInt())
            for (i in 0 until nLines) pos[i] = 0
        }
        val room = v[0] / 100.0
        val rt = v[1].toDouble()
        val scale = (0.35 + 1.35 * room) * sr / 48000.0
        for (i in 0 until nLines) {
            lens[i] = max(4, min(lines[i].size - 2, (base[i] * scale).toInt()))
            g[i] = 10.0.pow(-3.0 * lens[i] / (sr * rt * 1.25)) // 1,25: kompensasi redaman damping agar RT60 mendekati setelan
        }
        preSamp = v[2] / 1000.0 * sr
        earlyLin = v[3] / 100.0
        lateLin = v[4] / 100.0
        apG = 0.2 + 0.55 * v[5] / 100.0
        dampK = v[6] / 100.0 * 0.85
        Dsg.highpass(hp[0], sr, v[7].toDouble(), 0.7071)
        Dsg.highpass(hp[1], sr, v[7].toDouble(), 0.7071)
        Dsg.lowpass(lp[0], sr, v[8] * 1000.0, 0.7071)
        Dsg.lowpass(lp[1], sr, v[8] * 1000.0, 0.7071)
        wet = v[9] / 100.0
        dry = v[10] / 100.0
        width = v[11] / 100.0
        erScale = (0.4 + 1.2 * room) * sr / 1000.0
        active = wet > 0.001 || abs(dry - 1.0) > 0.001
    }

    override fun process(l: FloatArray, r: FloatArray, n: Int) {
        if (!active) return
        val k = 0.35355339
        for (i in 0 until n) {
            val xl = l[i].toDouble()
            val xr = r[i].toDouble()
            preL.write(xl)
            preR.write(xr)
            early.write((xl + xr) * 0.5)
            val dl = preL.read(preSamp)
            val dr = preR.read(preSamp)
            val a = apL2.process(apL1.process(dl, apG), apG)
            val b = apR2.process(apR1.process(dr, apG), apG)

            var o0 = 0.0
            var o1 = 0.0
            for (j in 0 until nLines) {
                val ln = lines[j]
                var rp = pos[j]
                if (rp >= lens[j]) rp = 0
                val out = ln[rp]
                damp[j] = damp[j] * dampK + out * (1.0 - dampK)
                tmp[j] = damp[j] * g[j]
                // keluaran stereo: pola tanda berbeda untuk kiri dan kanan
                val sl = if ((j / 2) % 2 == 0) 1.0 else -1.0
                val sr2 = if (j % 2 == 0) 1.0 else -1.0
                o0 += out * sl
                o1 += out * sr2
            }
            // Hadamard 8x8 (transformasi Walsh) lalu skala
            var len = 1
            while (len < 8) {
                var s = 0
                while (s < 8) {
                    for (q in s until s + len) {
                        val u = tmp[q]
                        val w = tmp[q + len]
                        tmp[q] = u + w
                        tmp[q + len] = u - w
                    }
                    s += len * 2
                }
                len *= 2
            }
            for (j in 0 until nLines) {
                val ln = lines[j]
                var wp = pos[j]
                if (wp >= lens[j]) wp = 0
                val inj = if (j % 2 == 0) a else b
                ln[wp] = inj * 0.5 + tmp[j] * k
                wp++
                if (wp >= lens[j]) wp = 0
                pos[j] = wp
            }
            val latL = o0 * 0.8 * lateLin
            val latR = o1 * 0.8 * lateLin

            var eL = 0.0
            var eR = 0.0
            if (earlyLin > 0.001) {
                for (t in 0 until 8) {
                    val s = early.read(preSamp + erMs[t] * erScale) * erG[t]
                    if (t % 2 == 0) eL += s else eR += s
                }
                eL *= 0.5 * earlyLin
                eR *= 0.5 * earlyLin
            }
            var wl = hp[0].process(latL + eL)
            var wr = hp[1].process(latR + eR)
            wl = lp[0].process(wl)
            wr = lp[1].process(wr)
            val m = (wl + wr) * 0.5
            val s = (wl - wr) * 0.5 * width
            l[i] = (xl * dry + (m + s) * wet).toFloat()
            r[i] = (xr * dry + (m - s) * wet).toFloat()
        }
    }

    override fun reset() {
        for (ln in lines) java.util.Arrays.fill(ln, 0.0)
        java.util.Arrays.fill(damp, 0.0)
        for (i in 0 until nLines) pos[i] = 0
        preL.clear(); preR.clear(); early.clear()
    }
}

// ======================================================================
// 3D Spatial: dua speaker virtual dirender ke telinga memakai model kepala bola
// (ITD Woodworth, bayangan kepala = lowpass + redaman telinga jauh,
// pelemahan belakang, isyarat ketinggian) + pantulan awal ruangan.
// Ini model aproksimasi, bukan HRTF terukur.
// ======================================================================
class SpatialFx : DspFx() {
    private class Spk {
        val dly = DelayLine(256)
        val rear = Biquad()
        val elev = Biquad()
        val dist = Biquad()
        val far = Biquad()
        var itd = 0.0
        var farG = 1.0
        var rightNear = true
    }

    private val spk = arrayOf(Spk(), Spk())
    private var inten = 0.0
    private var direct = 1.0
    private var spkGain = 0.8
    private var roomOn = false
    private var refl = 0.0
    private var depthRef = 0.0
    private val early = DelayLine(16384)
    private val erMs = doubleArrayOf(9.0, 13.0, 19.0, 26.0, 33.0, 41.0)
    private val erG = doubleArrayOf(0.7, 0.6, 0.5, 0.4, 0.32, 0.25)
    private var erS = 48.0

    override fun update(sr: Int, os: Int) {
        val v = AudioEngine.raw(AudioEngine.SPATIAL)
        inten = v[0] / 100.0
        val half = 30.0 * v[1] / 100.0
        val depth = (v[2] / 100.0 - 0.5) * 2.0
        val far = max(0.0, depth)
        val az = v[4].toDouble()
        val ee = v[5] + v[3] * 0.45
        val a = when (v[6].toInt()) {
            1 -> 0.075
            2 -> 0.10
            else -> 0.0875
        }
        val ang = doubleArrayOf(az - half, az + half)
        for (i in 0..1) {
            val s = spk[i]
            val ph = Math.toRadians(ang[i])
            val sn = sin(ph)
            val cs = cos(ph)
            val th = Math.asin(sn.coerceIn(-1.0, 1.0))
            s.itd = abs(a / 343.0 * (th + sin(th))) * sr
            s.rightNear = sn >= 0
            val lat = abs(sn)
            s.farG = dbToLin(-8.0 * lat)
            Dsg.lowpass1(s.far, sr, 18000.0 * exp(-2.4 * lat))
            val rearAmt = max(0.0, -cs)
            Dsg.lowpass1(s.rear, sr, 18000.0 * exp(-1.0 * rearAmt))
            Dsg.peak(s.elev, sr, 7500.0, 6.0 * sin(Math.toRadians(ee)), 1.5)
            Dsg.lowpass1(s.dist, sr, 20000.0 * exp(-1.8 * far))
        }
        spkGain = 0.8 * dbToLin(-4.0 * far)
        direct = v[9] / 100.0
        roomOn = v[8].toInt() == 1
        refl = v[10] / 100.0 * (0.4 + 0.6 * max(0.0, depth + 0.5))
        erS = sr / 1000.0
        active = inten > 0.001
    }

    override fun process(l: FloatArray, r: FloatArray, n: Int) {
        if (!active) return
        for (i in 0 until n) {
            val xl = l[i].toDouble()
            val xr = r[i].toDouble()
            var eL = 0.0
            var eR = 0.0
            for (c in 0..1) {
                val s = spk[c]
                val x = if (c == 0) xl else xr
                val y = s.dist.process(s.elev.process(s.rear.process(x)))
                s.dly.write(y)
                val nearS = y * spkGain
                val farS = s.far.process(s.dly.read(s.itd)) * s.farG * spkGain
                if (s.rightNear) {
                    eR += nearS
                    eL += farS
                } else {
                    eL += nearS
                    eR += farS
                }
            }
            eL *= direct
            eR *= direct
            if (roomOn && refl > 0.001) {
                early.write((eL + eR) * 0.5)
                var rl = 0.0
                var rr = 0.0
                for (t in 0 until 6) {
                    val s = early.read(erMs[t] * erS) * erG[t]
                    if (t % 2 == 0) rl += s else rr += s
                }
                eL += rl * refl
                eR += rr * refl
            }
            l[i] = (xl * (1 - inten) + eL * inten).toFloat()
            r[i] = (xr * (1 - inten) + eR * inten).toFloat()
        }
    }

    override fun reset() {
        for (s in spk) {
            s.dly.clear(); s.rear.reset(); s.elev.reset(); s.dist.reset(); s.far.reset()
        }
        early.clear()
    }
}
