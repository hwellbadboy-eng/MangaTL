package com.niven.mangatl

import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.text.TextUtils
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.ViewOutlineProvider
import android.widget.CheckBox
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.ScrollView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.google.android.material.button.MaterialButton
import com.yausername.youtubedl_android.YoutubeDL
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.net.URL

/**
 * Panel pilih kualitas: ambil info link -> pilih Video/Musik -> pilih resolusi/format -> tombol Unduh.
 * Link satu video: pilih resolusi tepat. Link playlist: centang item, pilih batas kualitas (default "tertinggi
 * yang dimiliki tiap item"). Dipakai bersama oleh layar Unduh dan sheet "share link" (QuickDownloadActivity).
 */
class DlPicker(private val act: AppCompatActivity, private val onChoose: (List<DlTask>) -> Unit) {

    val root = LinearLayout(act).apply { orientation = LinearLayout.VERTICAL }

    private var url = ""
    private var info: DlInfo? = null
    private var playlist: DlPlaylist? = null
    private var checked = BooleanArray(0)
    private var thumb: Bitmap? = null
    private var audioMode = DlPrefs.lastAudio(act)
    private var compat = DlPrefs.compat(act)
    private var wantSubs = DlPrefs.subs(act)
    private var wantLyrics = DlPrefs.lyrics(act)
    private var wantSquare = DlPrefs.square(act)
    private var audioIdx = DlPrefs.audioFmt(act).coerceIn(0, 2)
    private var videoIdx = 0
    private var capIdx = 0
    private var job: Job? = null

    private fun dp(v: Int) = Ui.dp(act, v)

    // ---------------------------------------------------------------- memuat

    fun load(u: String) {
        url = u
        info = null
        playlist = null
        thumb = null
        videoIdx = 0
        job?.cancel()
        showLoading("Menyiapkan mesin unduh…\n(pertama kali agak lama)")
        job = act.lifecycleScope.launch {
            val res = withContext(Dispatchers.IO) {
                runCatching {
                    DlEngine.ensureReady(act)
                    // Jalur "Bagikan -> BunnyTL" tidak lewat layar Unduh, jadi mesin harus ikut diperbarui di sini
                    // (tiap 12 jam). Tanpa ini yt-dlp tertinggal dan situs seperti Facebook gagal terbaca.
                    if (System.currentTimeMillis() - DlPrefs.lastUpdate(act) > 12L * 3600 * 1000) {
                        act.runOnUiThread { showLoading("Memperbarui mesin unduh…\n(otomatis, tiap 12 jam)") }
                        runCatching { DlUpdater.update(act) }
                        DlPrefs.setLastUpdate(act, System.currentTimeMillis())
                    }
                    act.runOnUiThread { showLoading("Mengambil info link…") }
                    val r = try {
                        YoutubeDL.getInstance().execute(DlCommands.fetch(act, u))
                    } catch (e: Exception) {
                        // Cookies bisa kedaluwarsa/ditolak situs; coba sekali lagi tanpa cookies sebelum menyerah.
                        if (!DlCookies.appliesTo(act, u)) throw e
                        YoutubeDL.getInstance().execute(DlCommands.fetch(act, u, withCookies = false))
                    }
                    DlInfoParser.parseResult(r.out, u)
                }
            }
            res.onSuccess { r ->
                when (r) {
                    is DlResult.Single -> {
                        val i = r.info
                        info = i
                        if (!i.hasVideo) audioMode = true else if (!i.hasAudio) audioMode = false
                        render()
                        loadThumb(i.thumbnail)
                    }
                    is DlResult.Playlist -> {
                        playlist = r.list
                        checked = BooleanArray(r.list.entries.size) { true }
                        capIdx = 0
                        renderPlaylist()
                    }
                }
            }.onFailure { showError(DlEngine.friendlyError(it)) }
        }
    }

    private fun loadThumb(u: String) {
        if (u.isEmpty()) return
        act.lifecycleScope.launch(Dispatchers.IO) {
            val bmp = runCatching {
                URL(u.replaceFirst("http://", "https://")).openStream().use { BitmapFactory.decodeStream(it) }
            }.getOrNull()
            if (bmp != null) withContext(Dispatchers.Main) {
                thumb = bmp
                if (info != null) render()
            }
        }
    }

    private fun updateEngine() {
        showLoading("Memperbarui mesin unduh…")
        job?.cancel()
        job = act.lifecycleScope.launch {
            val msg = withContext(Dispatchers.IO) {
                runCatching {
                    DlEngine.ensureReady(act)
                    val r = DlUpdater.update(act)
                    DlPrefs.setLastUpdate(act, System.currentTimeMillis())
                    DlUpdater.message(r)
                }.getOrElse { DlEngine.friendlyError(it) }
            }
            android.widget.Toast.makeText(act, msg, android.widget.Toast.LENGTH_LONG).show()
            load(url)
        }
    }

    // ---------------------------------------------------------------- bahan tampilan

    private fun text(t: String, size: Float, color: Int, bold: Boolean = false) = TextView(act).apply {
        text = t
        textSize = size
        setTextColor(color)
        if (bold) typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
    }

    private fun button(label: String, onClick: () -> Unit) = MaterialButton(act).apply {
        text = label
        isAllCaps = false
        cornerRadius = dp(24)
        setOnClickListener { onClick() }
    }

    private fun pill(label: String, selected: Boolean, onClick: () -> Unit) = TextView(act).apply {
        text = label
        textSize = 13f
        gravity = Gravity.CENTER
        typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
        setTextColor(if (selected) Color.BLACK else Color.parseColor("#C7C7CC"))
        background = GradientDrawable().apply {
            cornerRadius = dp(18).toFloat()
            setColor(if (selected) Color.WHITE else Color.parseColor("#1C1C1E"))
        }
        setPadding(dp(14), dp(8), dp(14), dp(8))
        isClickable = true
        setOnClickListener { onClick() }
    }

    private fun pillRow(vararg pills: View): LinearLayout = LinearLayout(act).apply {
        orientation = LinearLayout.HORIZONTAL
        setPadding(0, dp(12), 0, dp(4))
        pills.forEachIndexed { i, p ->
            addView(p, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply {
                if (i > 0) marginStart = dp(8)
            })
        }
    }

    private fun wrap() = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)

    private fun showLoading(msg: String) {
        root.removeAllViews()
        val box = LinearLayout(act).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(dp(8), dp(28), dp(8), dp(28))
        }
        box.addView(ProgressBar(act).apply { isIndeterminate = true })
        box.addView(text(msg, 14f, Color.parseColor("#C7C7CC")).apply {
            gravity = Gravity.CENTER
            setPadding(0, dp(14), 0, 0)
        })
        root.addView(box, wrap())
    }

    private fun showError(msg: String) {
        root.removeAllViews()
        root.addView(text(msg, 14f, Color.parseColor("#FF8A80")).apply {
            setLineSpacing(0f, 1.15f)
            setPadding(dp(4), dp(8), dp(4), dp(14))
        })
        val row = LinearLayout(act).apply { orientation = LinearLayout.HORIZONTAL }
        row.addView(button("Coba lagi") { if (url.isNotEmpty()) load(url) },
            LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        row.addView(button("Perbarui mesin") { updateEngine() },
            LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { marginStart = dp(8) })
        root.addView(row)
        if (msg.contains("Masuk akun")) {
            root.addView(button("Masuk akun (cookies)") {
                act.startActivity(Intent(act, CookiesActivity::class.java))
            }, wrap().apply { topMargin = dp(8) })
        }
    }

    private fun switchRow(label: String, on: Boolean, onChange: (Boolean) -> Unit) =
        Ui.switchRow(act, label, on, onChange)

    private fun addRadios(labels: List<String>, selected: Int, onPick: (Int) -> Unit) {
        val group = Ui.radios(act, labels, selected, onPick)
        val scroll = ScrollView(act).apply { isVerticalScrollBarEnabled = false; addView(group) }
        val maxH = dp(264)
        root.addView(scroll, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            if (labels.size * dp(48) > maxH) maxH else ViewGroup.LayoutParams.WRAP_CONTENT
        ).apply { topMargin = dp(4) })
    }

    // ---------------------------------------------------------------- satu video

    private fun render() {
        val i = info ?: return
        root.removeAllViews()

        val head = LinearLayout(act).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val iv = ImageView(act).apply {
            scaleType = ImageView.ScaleType.CENTER_CROP
            background = GradientDrawable().apply { cornerRadius = dp(10).toFloat(); setColor(Color.parseColor("#1C1C1E")) }
            clipToOutline = true
            outlineProvider = ViewOutlineProvider.BACKGROUND
            thumb?.let { setImageBitmap(it) }
        }
        head.addView(iv, LinearLayout.LayoutParams(dp(112), dp(63)))
        val col = LinearLayout(act).apply { orientation = LinearLayout.VERTICAL }
        col.addView(text(i.title, 15f, Color.WHITE, true).apply { maxLines = 2; ellipsize = TextUtils.TruncateAt.END })
        val sub = listOf(i.uploader, DlOptions.duration(i.duration)).filter { it.isNotEmpty() }.joinToString(" · ")
        if (sub.isNotEmpty()) col.addView(text(sub, 12f, Color.parseColor("#8E8E93")).apply {
            maxLines = 1; ellipsize = TextUtils.TruncateAt.END; setPadding(0, dp(3), 0, 0)
        })
        head.addView(col, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { marginStart = dp(12) })
        root.addView(head)

        // link video yang berada di dalam playlist: tawarkan unduh seluruh playlist
        val listId = Regex("[?&]list=([A-Za-z0-9_-]+)").find(url)?.groupValues?.get(1)
        if (listId != null && !listId.startsWith("RD")) {
            root.addView(text("Video ini bagian dari playlist · Lihat seluruh playlist", 13f, Color.WHITE, true).apply {
                setPadding(0, dp(12), 0, dp(2))
                isClickable = true
                setOnClickListener { load("https://www.youtube.com/playlist?list=$listId") }
            })
        }

        if (i.hasVideo && i.hasAudio) {
            root.addView(pillRow(
                pill("Video", !audioMode) { audioMode = false; render() },
                pill("Musik", audioMode) { audioMode = true; render() }
            ))
        }

        var videoOpts: List<VideoOpt> = emptyList()
        if (audioMode) {
            addRadios(DlOptions.AUDIO_LABELS, audioIdx) { audioIdx = it; render() }
            root.addView(switchRow("Ambil lirik otomatis (LRCLIB)", wantLyrics) { wantLyrics = it }, wrap().apply { topMargin = dp(8) })
            if (audioIdx != 2) {
                root.addView(switchRow("Cover persegi", wantSquare) { wantSquare = it }, wrap())
            }
        } else {
            root.addView(pillRow(
                pill("MP4 · kompatibel", compat) { compat = true; videoIdx = 0; render() },
                pill("MKV · kualitas tinggi", !compat) { compat = false; videoIdx = 0; render() }
            ))
            videoOpts = DlOptions.video(i, compat)
            val labels = if (videoOpts.isEmpty()) listOf("Terbaik yang tersedia")
            else videoOpts.map { if (it.detail.isEmpty()) it.label else "${it.label}  ·  ${it.detail}" }
            addRadios(labels, videoIdx.coerceIn(0, labels.size - 1)) { videoIdx = it }
            if (i.hasSubs) {
                val what = if (i.subLangs.isNotEmpty()) "subtitle (${i.subLangs.joinToString(", ")})"
                else "subtitle otomatis (${i.autoLang})"
                root.addView(switchRow("Sertakan $what", wantSubs) { wantSubs = it }, wrap().apply { topMargin = dp(8) })
            }
        }

        root.addView(button("Unduh") { chooseSingle(i, videoOpts) }, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, dp(52)
        ).apply { topMargin = dp(10) })
    }

    private fun savePrefs() {
        DlPrefs.setLastAudio(act, audioMode)
        DlPrefs.setCompat(act, compat)
        DlPrefs.setAudioFmt(act, audioIdx)
        DlPrefs.setSubs(act, wantSubs)
        DlPrefs.setLyrics(act, wantLyrics)
        DlPrefs.setSquare(act, wantSquare)
    }

    private fun chooseSingle(i: DlInfo, videoOpts: List<VideoOpt>) {
        savePrefs()
        val task = if (audioMode) {
            DlTask(
                i.url, i.title, true, "", false, audioIdx,
                lyrics = wantLyrics, artist = i.artist, track = i.track, durationSec = i.duration,
                square = wantSquare
            )
        } else {
            val opt = videoOpts.getOrNull(videoIdx)
            val sel = if (opt != null) DlOptions.selector(opt, compat) else "bv*+ba/b"
            val subs = if (!wantSubs || !i.hasSubs) emptyList()
            else if (i.subLangs.isNotEmpty()) i.subLangs else listOf(i.autoLang)
            DlTask(i.url, i.title, false, sel, compat, 0, subs = subs, autoSubs = i.subLangs.isEmpty() && subs.isNotEmpty())
        }
        onChoose(listOf(task))
    }

    // ---------------------------------------------------------------- playlist

    private val capLabels = listOf(
        "Tertinggi yang dimiliki tiap item", "Sampai 2160p (4K)", "Sampai 1440p",
        "Sampai 1080p", "Sampai 720p", "Sampai 480p", "Sampai 360p"
    )
    private val capValues = listOf(0, 2160, 1440, 1080, 720, 480, 360)

    private fun renderPlaylist() {
        val pl = playlist ?: return
        root.removeAllViews()
        root.addView(text(pl.title, 15f, Color.WHITE, true).apply { maxLines = 2; ellipsize = TextUtils.TruncateAt.END })
        val n = checked.count { it }
        val sub = listOf(pl.uploader, "${pl.entries.size} item", "$n dipilih").filter { it.isNotEmpty() }.joinToString(" · ")
        root.addView(text(sub, 12f, Color.parseColor("#8E8E93")).apply { setPadding(0, dp(3), 0, dp(6)) })

        val bar = LinearLayout(act).apply { orientation = LinearLayout.HORIZONTAL }
        bar.addView(pill("Pilih semua", false) { checked.fill(true); renderPlaylist() },
            LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        bar.addView(pill("Kosongkan", false) { checked.fill(false); renderPlaylist() },
            LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { marginStart = dp(8) })
        root.addView(bar, wrap())

        val box = LinearLayout(act).apply { orientation = LinearLayout.VERTICAL }
        pl.entries.forEachIndexed { idx, e ->
            val dur = DlOptions.duration(e.duration)
            box.addView(CheckBox(act).apply {
                text = if (dur.isEmpty()) e.title else "${e.title}  ·  $dur"
                maxLines = 2
                ellipsize = TextUtils.TruncateAt.END
                textSize = 14f
                isChecked = checked[idx]
                setOnCheckedChangeListener { _, v -> checked[idx] = v; updateCount() }
            })
        }
        root.addView(ScrollView(act).apply { isVerticalScrollBarEnabled = false; addView(box) },
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(220)).apply { topMargin = dp(6) })

        root.addView(pillRow(
            pill("Video", !audioMode) { audioMode = false; renderPlaylist() },
            pill("Musik", audioMode) { audioMode = true; renderPlaylist() }
        ))
        if (audioMode) {
            addRadios(DlOptions.AUDIO_LABELS, audioIdx) { audioIdx = it; renderPlaylist() }
            root.addView(switchRow("Ambil lirik otomatis (LRCLIB)", wantLyrics) { wantLyrics = it }, wrap().apply { topMargin = dp(8) })
            if (audioIdx != 2) root.addView(switchRow("Cover persegi", wantSquare) { wantSquare = it }, wrap())
        } else {
            root.addView(pillRow(
                pill("MP4 · kompatibel", compat) { compat = true; renderPlaylist() },
                pill("MKV · kualitas tinggi", !compat) { compat = false; renderPlaylist() }
            ))
            addRadios(capLabels, capIdx) { capIdx = it }
            root.addView(switchRow("Sertakan subtitle bila ada", wantSubs) { wantSubs = it }, wrap().apply { topMargin = dp(8) })
        }
        root.addView(button("Unduh $n item") { choosePlaylist(pl) }.also { it.tag = "dlbtn" },
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(52)).apply { topMargin = dp(10) })
    }

    private fun updateCount() {
        val n = checked.count { it }
        (root.findViewWithTag<View>("dlbtn") as? MaterialButton)?.text = "Unduh $n item"
    }

    private fun choosePlaylist(pl: DlPlaylist) {
        savePrefs()
        val picked = pl.entries.filterIndexed { i, _ -> checked.getOrElse(i) { false } }
        if (picked.isEmpty()) {
            android.widget.Toast.makeText(act, "Centang minimal satu item.", android.widget.Toast.LENGTH_SHORT).show()
            return
        }
        val cap = capValues[capIdx.coerceIn(0, capValues.size - 1)]
        val sort = when {
            compat && cap == 0 -> "res,vcodec:h264,acodec:m4a"
            compat -> "res:$cap,vcodec:h264,acodec:m4a"
            cap == 0 -> ""
            else -> "res:$cap"
        }
        val selector = if (compat) "bv*+ba[ext=m4a]/bv*+ba/b" else "bv*+ba/b"
        val tasks = picked.map { e ->
            if (audioMode) {
                val artist = if (e.title.contains(" - ")) "" else e.uploader.removeSuffix(" - Topic")
                DlTask(
                    e.url, e.title, true, "", false, audioIdx,
                    lyrics = wantLyrics, artist = artist, durationSec = e.duration, square = wantSquare
                )
            } else {
                DlTask(
                    e.url, e.title, false, selector, compat, 0,
                    subs = if (wantSubs) listOf("id.*", "en.*") else emptyList(), sort = sort
                )
            }
        }
        onChoose(tasks)
    }
}
