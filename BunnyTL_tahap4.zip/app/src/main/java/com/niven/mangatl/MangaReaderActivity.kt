package com.niven.mangatl

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.os.Bundle
import android.view.ViewGroup
import android.widget.ImageView
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

/** Pembaca hasil terjemahan: gulir vertikal (cocok untuk manga & webtoon). */
class MangaReaderActivity : AppCompatActivity() {

    private class VH(val iv: ImageView) : RecyclerView.ViewHolder(iv) { var job: Job? = null }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val title = intent.getStringExtra("title") ?: run { finish(); return }
        val pages = MangaEngine.outPages(File(MangaEngine.root(this), title))
        if (pages.isEmpty()) { finish(); return }
        val minH = (resources.displayMetrics.widthPixels * 1.4f).toInt()

        val rv = RecyclerView(this)
        rv.setBackgroundColor(0xFF000000.toInt())
        rv.layoutManager = LinearLayoutManager(this)
        rv.adapter = object : RecyclerView.Adapter<VH>() {
            override fun getItemCount() = pages.size
            override fun onCreateViewHolder(p: ViewGroup, t: Int): VH {
                val iv = ImageView(p.context)
                iv.layoutParams = RecyclerView.LayoutParams(-1, -2)
                iv.adjustViewBounds = true
                return VH(iv)
            }
            override fun onBindViewHolder(h: VH, pos: Int) {
                h.job?.cancel()
                h.iv.setImageDrawable(null)
                h.iv.minimumHeight = minH
                h.job = lifecycleScope.launch {
                    val bmp = withContext(Dispatchers.IO) { load(pages[pos]) }
                    if (bmp != null) { h.iv.setImageBitmap(bmp); h.iv.minimumHeight = 0 }
                }
            }
            override fun onViewRecycled(h: VH) { h.job?.cancel(); h.iv.setImageDrawable(null) }
        }
        setContentView(rv)
    }

    private fun load(f: File): Bitmap? {
        val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeFile(f.path, o)
        var s = 1
        while ((o.outWidth / s).toLong() * (o.outHeight / s) > 4_000_000L) s *= 2
        return BitmapFactory.decodeFile(f.path, BitmapFactory.Options().apply {
            inSampleSize = s; inPreferredConfig = Bitmap.Config.RGB_565
        })
    }
}
