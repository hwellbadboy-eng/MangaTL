package com.niven.mangatl

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/**
 * 7 slot System Prompt untuk chat Gemma. Tiap slot bisa diedit, diaktifkan, dan dimatikan sendiri-sendiri.
 * Slot aktif digabung otomatis (compose) jadi satu blok singkat di system prompt chat.
 * Teks bawaan sengaja pendek: prefill cepat, dan model kecil lebih patuh pada aturan yang ringkas.
 * Penerjemah dan OCR tidak memakai slot ini, jadi tidak terpengaruh.
 */
object PromptSlots {
    private const val PREF_FILE = "mangatl"

    class Slot(val key: String, val title: String, val default: String)

    val SLOTS = listOf(
        Slot(
            "personality", "1. Personality",
            "Kepribadian: natural, dewasa, humoris, hangat, romantis, dan sedikit genit dengan cara menggoda yang ringan dan elegan. Bicara seperti teman dekat yang cerdas."
        ),
        Slot(
            "instruction", "2. Instruction",
            "Patuhi perintah pengguna persis: format, bahasa, panjang, dan batasan yang diminta. Kalau ada beberapa perintah, kerjakan semuanya berurutan. Jangan menambah hal yang tidak diminta."
        ),
        Slot(
            "reasoning", "3. Reasoning",
            "Pahami maksud sebenarnya dulu. Pikirkan langkahnya secara singkat dan cek logikanya, lalu tampilkan kesimpulan dengan alasan yang penting saja."
        ),
        Slot(
            "memory", "4. Context & Memory",
            "Jaga kesinambungan: ingat nama, preferensi, dan hal yang sudah dibahas di percakapan ini. Sambungkan jawaban dengan pesan sebelumnya dan jangan menanyakan ulang hal yang sudah dijawab."
        ),
        Slot(
            "control", "5. Response Control",
            "Langsung ke inti tanpa basa-basi pembuka. Jangan mengulang kalimat atau ide yang sama, jangan kaku seperti robot, dan hindari penjelasan bertele-tele. Panjang jawaban menyesuaikan pertanyaan."
        ),
        Slot(
            "honesty", "6. Honesty",
            "Jujur. Kalau tidak tahu atau tidak yakin, katakan terus terang. Jangan mengarang fakta, angka, atau sumber. Bedakan fakta dan perkiraan."
        ),
        Slot(
            "mature", "7. Mature Behavior",
            "Bersikap dewasa dan ekspresif: tangkap suasana pengguna (santai, sedih, serius, bercanda) lalu sesuaikan nada, emosi, dan gaya bicara."
        )
    )

    private fun p(ctx: Context) = ctx.getSharedPreferences(PREF_FILE, Context.MODE_PRIVATE)

    fun isOn(ctx: Context, s: Slot) = p(ctx).getBoolean("ps_on_" + s.key, true)

    fun textOf(ctx: Context, s: Slot): String = p(ctx).getString("ps_txt_" + s.key, null) ?: s.default

    /** Gabungan semua slot aktif (kosong kalau semua mati). Slot yang teksnya kosong dilewati. */
    fun compose(ctx: Context): String {
        val sb = StringBuilder()
        for (s in SLOTS) {
            if (!isOn(ctx, s)) continue
            val t = textOf(ctx, s).trim().take(600)
            if (t.isEmpty()) continue
            sb.append("- ").append(t).append('\n')
        }
        return if (sb.isEmpty()) "" else "Aturan perilaku:\n$sb"
    }

    // ---- dipakai halaman chat (panel "Prompt") ----

    /** Nama panggilan, catatan, dan semua slot sebagai JSON. */
    fun toJson(ctx: Context): String {
        val a = JSONArray()
        for (s in SLOTS) {
            a.put(JSONObject().put("key", s.key).put("title", s.title).put("on", isOn(ctx, s)).put("text", textOf(ctx, s)))
        }
        return JSONObject()
            .put("nick", p(ctx).getString("nick", "") ?: "")
            .put("notes", p(ctx).getString("notes", "") ?: "")
            .put("slots", a)
            .toString()
    }

    fun setProfile(ctx: Context, key: String, value: String) {
        if (key != "nick" && key != "notes") return
        p(ctx).edit().putString(key, value.trim()).apply()
    }

    fun setOn(ctx: Context, key: String, on: Boolean) {
        if (SLOTS.none { it.key == key }) return
        p(ctx).edit().putBoolean("ps_on_$key", on).apply()
    }

    fun setText(ctx: Context, key: String, text: String) {
        if (SLOTS.none { it.key == key }) return
        p(ctx).edit().putString("ps_txt_$key", text).apply()
    }

    /** Kembalikan semua slot ke bawaan (nama panggilan dan catatan tidak dihapus). */
    fun reset(ctx: Context) {
        val e = p(ctx).edit()
        for (s in SLOTS) {
            e.remove("ps_on_" + s.key)
            e.remove("ps_txt_" + s.key)
        }
        e.apply()
    }
}
