package com.niven.mangatl

import android.content.Context
import android.media.AudioFormat
import android.provider.MediaStore
import java.nio.ByteBuffer
import java.nio.ByteOrder
import kotlin.math.abs
import kotlin.math.exp
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

/** Cermin sampel keluaran terakhir untuk Visualizer (ditulis thread audio, dibaca UI). */
object VisTap {
    const val SIZE = 32768
    private val l = FloatArray(SIZE)
    private val r = FloatArray(SIZE)
    @Volatile private var wp = 0
    @Volatile var sampleRate = 48000
    @Volatile var enabled = false
    /** Jumlah visualizer yang sedang tampil & berjalan. 0 = tidak ada yang melihat, DSP tidak perlu menyalin sampel. */
    @Volatile var viewers = 0
    val pos: Int get() = wp

    fun write(a: FloatArray, b: FloatArray, n: Int) {
        var p = wp
        for (i in 0 until n) {
            l[p] = a[i]
            r[p] = b[i]
            p = (p + 1) and (SIZE - 1)
        }
        wp = p
    }

    /** Salin n sampel terakhir (digeser mundur lagMs) ke dst. which: 0 kiri, 1 kanan, 2 campuran. */
    fun read(dst: FloatArray, n: Int, which: Int, lagMs: Float) {
        val lag = (lagMs * sampleRate / 1000f).toInt().coerceIn(0, SIZE - n - 1)
        var p = (wp - lag - n) and (SIZE - 1)
        for (i in 0 until n) {
            dst[i] = when (which) {
                0 -> l[p]
                1 -> r[p]
                else -> (l[p] + r[p]) * 0.5f
            }
            p = (p + 1) and (SIZE - 1)
        }
    }
}

/**
 * Rantai DSP: Normalisasi → EQ → Bass → Vokal → Stereo → Spatial → Crossfeed → Reverb →
 * Kompresor → Limiter → (peta kanal) → resampler → kuantisasi/dither.
 * Seluruh pemrosesan memakai float; headroom dijaga Limiter di ujung rantai.
 */
class DspChain(private val ctx: Context) {

    private val e16 = AudioFormat.ENCODING_PCM_16BIT
    private val ef = AudioFormat.ENCODING_PCM_FLOAT
    private val e24 = 21 // AudioFormat.ENCODING_PCM_24BIT_PACKED (= C.ENCODING_PCM_24BIT)
    private val e32 = 22 // AudioFormat.ENCODING_PCM_32BIT (= C.ENCODING_PCM_32BIT)

    private val eq = EqFx()
    private val bass = BassFx()
    private val vocal = VocalFx()
    private val stereo = StereoFx()
    private val spatial = SpatialFx()
    private val xfeed = CrossFx()
    private val reverb = ReverbFx()
    private val comp = CompFx()
    private val limit = LimitFx()

    private val ids = arrayOf(
        AudioEngine.EQ, AudioEngine.BASS, AudioEngine.VOCAL, AudioEngine.STEREO, AudioEngine.SPATIAL,
        AudioEngine.XFEED, AudioEngine.REVERB, AudioEngine.COMP, AudioEngine.LIMIT
    )
    private val fxs: Array<DspFx> = arrayOf(eq, bass, vocal, stereo, spatial, xfeed, reverb, comp, limit)
    private val fxOn = BooleanArray(9)

    private var sr = 48000
    private var inEnc = AudioFormat.ENCODING_PCM_16BIT
    private var outEnc = AudioFormat.ENCODING_PCM_16BIT
    private var outRate = 48000
    private var bits = 0            // 0 auto, 16, 24, 32
    private var dither = false
    private var resampler: Resampler? = null
    private var lastVer = -1
    private var bypass = false
    private var mapMode = 0
    private var mapL = 0
    private var mapR = 0

    private var l = FloatArray(4096)
    private var r = FloatArray(4096)
    private var outBuf: ByteBuffer = ByteBuffer.allocateDirect(8192).order(ByteOrder.nativeOrder())

    private var normG = 1.0
    private var normT = 1.0
    private var normC = 0.0
    private var dynDb = 0.0
    private var peakEnv = 0.0
    private var inMeter: LoudMeter? = null
    private var outMeter: LoudMeter? = null
    private var rnd = 0x1234567
    private var meterCnt = 0
    private var albumIds = HashMap<Long, LongArray>()

    /** Kembalikan [laju, encoding] keluaran, atau null kalau format tidak ditangani (efek mati). */
    fun configure(rate: Int, channels: Int, enc: Int): IntArray? {
        if (channels != 2) return null
        if (enc != e16 && enc != ef && enc != e24 && enc != e32) return null
        sr = rate
        inEnc = enc
        VisTap.sampleRate = rate
        plan()
        lastVer = -1
        inMeter = LoudMeter(rate)
        outMeter = LoudMeter(rate)
        return intArrayOf(outRate, outEnc)
    }

    /** Rencana jalur output dari pengaturan Hi-Res. */
    private fun plan() {
        val hiOn = AudioEngine.isOn(AudioEngine.HIRES)
        val hv = AudioEngine.raw(AudioEngine.HIRES)
        val perfect = hiOn && hv.size > 5 && hv[5].toInt() == 1
        bypass = !AudioEngine.master || perfect
        outRate = sr
        outEnc = if (inEnc == e16) e16 else ef
        bits = 0
        dither = false
        resampler = null
        mapMode = 0
        if (hiOn && !perfect && hv.size > 14) {
            val rates = intArrayOf(0, 44100, 48000, 88200, 96000, 176400, 192000)
            var want = rates[hv[0].toInt().coerceIn(0, 6)]
            if (want == 0) {
                val up = hv[6].toInt()
                if (up > 0) want = min(sr * (1 shl up), 192000)
            }
            if (want > 0 && want != sr && OutputCaps.rateAllowed(want)) outRate = want
            bits = intArrayOf(0, 16, 24, 32)[hv[1].toInt().coerceIn(0, 3)]
            dither = hv[9].toInt() == 1
            when (bits) {
                16 -> outEnc = e16
                24, 32 -> outEnc = ef
            }
            if (outRate != sr) resampler = Resampler(sr, outRate, hv[8].toInt() == 1)
            if (hv[12].toInt() == 1) {
                mapMode = 1
                mapL = hv[13].toInt()
                mapR = hv[14].toInt()
            }
        }
    }

    fun reset() {
        for (f in fxs) f.reset()
        resampler?.reset()
        inMeter?.reset()
        outMeter?.reset()
        normG = normT
    }

    private fun refresh() {
        lastVer = AudioEngine.version
        val os = if (AudioEngine.isOn(AudioEngine.HIRES)) 1 shl AudioEngine.raw(AudioEngine.HIRES)[7].toInt().coerceIn(0, 3) else 1
        for (i in fxs.indices) {
            fxOn[i] = AudioEngine.isOn(ids[i])
            if (fxOn[i]) fxs[i].update(sr, if (os > 1) os else 1) else fxs[i].active = false
        }
        val perfect = AudioEngine.isOn(AudioEngine.HIRES) && AudioEngine.raw(AudioEngine.HIRES)[5].toInt() == 1
        bypass = !AudioEngine.master || perfect
        var lat = 0
        for (f in fxs) if (f.active) lat += f.latencySamples
        var ms = lat * 1000f / sr
        resampler?.let { ms += it.delayInSamples * 1000f / sr }
        AudioEngine.meterLatencyMs = ms
        val bufSel = AudioEngine.raw(AudioEngine.HIRES).getOrElse(10) { 0f }.toInt()
        AudioEngine.meterBufferMs = when (bufSel) {
            1 -> 10f; 2 -> 20f; 3 -> 40f; else -> 250f
        }
        VisTap.enabled = AudioEngine.isOn(AudioEngine.VIS)
    }

    // ---------- normalisasi ----------

    private fun albumLevel(albumId: Long, algo: Int): Double? {
        if (albumId < 0) return null
        val ids = albumIds.getOrPut(albumId) {
            val out = ArrayList<Long>()
            try {
                ctx.contentResolver.query(
                    MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, arrayOf(MediaStore.Audio.Media._ID),
                    "${MediaStore.Audio.Media.ALBUM_ID}=?", arrayOf(albumId.toString()), null
                )?.use { c -> while (c.moveToNext() && out.size < 60) out.add(c.getLong(0)) }
            } catch (e: Exception) {
            }
            out.toLongArray()
        }
        var sum = 0.0
        var n = 0
        for (id in ids) {
            val li = LoudnessCache.get(ctx, id)
            if (li == null) {
                LoudnessCache.request(ctx, id)
            } else {
                sum += Math.pow(10.0, (if (algo == 0) li.rg else li.lufs) / 10.0)
                n++
            }
        }
        if (n == 0) return null
        return 10.0 * Math.log10(sum / n)
    }

    private fun updateNorm(frames: Int) {
        val v = AudioEngine.raw(AudioEngine.NORM)
        if (!AudioEngine.isOn(AudioEngine.NORM) || v.size < 8) {
            normT = 1.0
            AudioEngine.meterGainDb = 0f
            AudioEngine.normStatus = ""
            normC = 1.0 - exp(-1.0 / (0.3 * sr))
            return
        }
        val target = v[0].toDouble()
        val tp = v[1].toDouble()
        val range = v[2].toDouble()
        val album = v[3].toInt() == 1
        val algo = v[4].toInt()
        val dyn = v[5].toInt() == 1
        val clip = v[6].toInt() == 1
        var gainDb = 0.0
        var status = ""
        if (dyn) {
            val st = inMeter?.shortTerm ?: -70.0
            if (st > -55.0) dynDb = (target - st).coerceIn(-range, range)
            gainDb = dynDb
            if (clip) {
                val pk = max(peakEnv, 1e-6)
                gainDb = min(gainDb, tp - linToDb(pk))
            }
            normC = 1.0 - exp(-1.0 / (2.0 * sr))
            status = "dinamis"
        } else {
            val id = AudioEngine.currentTrackId
            val li = LoudnessCache.get(ctx, id)
            if (li == null) {
                if (id >= 0) {
                    if (LoudnessCache.failed(ctx, id)) status = "tidak bisa dianalisis" else {
                        LoudnessCache.request(ctx, id)
                        status = "menganalisis…"
                    }
                }
            } else {
                var level = if (algo == 0) li.rg else li.lufs
                if (album) {
                    val al = albumLevel(AudioEngine.currentAlbumId, algo)
                    if (al != null) level = al
                }
                gainDb = (target - level).coerceIn(-range, range)
                if (clip) gainDb = min(gainDb, tp - li.peakDb)
            }
            normC = 1.0 - exp(-1.0 / (0.3 * sr))
        }
        normT = dbToLin(gainDb)
        AudioEngine.meterGainDb = gainDb.toFloat()
        AudioEngine.normStatus = status
    }

    // ---------- proses ----------

    fun process(inp: ByteBuffer): ByteBuffer {
        val bps = when (inEnc) {
            e16 -> 2
            e24 -> 3
            else -> 4
        }
        val frames = inp.remaining() / (bps * 2)
        outBuf.clear()
        if (frames <= 0) {
            inp.position(inp.limit())
            outBuf.flip()
            return outBuf
        }
        if (lastVer != AudioEngine.version) refresh()

        // jalur cepat: tidak ada yang diubah
        if (bypass && resampler == null && mapMode == 0 && outEnc == inEnc && (inEnc == e16 || inEnc == ef)) {
            ensureOut(frames * bps * 2)
            val d = inp.duplicate()
            d.limit(inp.position() + frames * bps * 2)
            outBuf.put(d)
            inp.position(inp.position() + frames * bps * 2)
            outBuf.flip()
            return outBuf
        }

        if (l.size < frames) {
            l = FloatArray(frames)
            r = FloatArray(frames)
        }
        val src = inp.duplicate().order(ByteOrder.nativeOrder())
        when (inEnc) {
            ef -> for (i in 0 until frames) {
                l[i] = src.float
                r[i] = src.float
            }
            e24 -> for (i in 0 until frames) {
                for (c in 0..1) {
                    val b0 = src.get().toInt() and 0xFF
                    val b1 = src.get().toInt() and 0xFF
                    val b2 = src.get().toInt()
                    val v = (b2 shl 16) or (b1 shl 8) or b0
                    if (c == 0) l[i] = v / 8388608f else r[i] = v / 8388608f
                }
            }
            e32 -> for (i in 0 until frames) {
                l[i] = src.int / 2147483648f
                r[i] = src.int / 2147483648f
            }
            else -> {
                val k = 1f / 32768f
                for (i in 0 until frames) {
                    l[i] = src.short * k
                    r[i] = src.short * k
                }
            }
        }
        inp.position(inp.position() + frames * bps * 2)

        if (!bypass) {
            val dynOn = AudioEngine.isOn(AudioEngine.NORM) && AudioEngine.raw(AudioEngine.NORM)[5].toInt() == 1
            if (dynOn) {
                val m = inMeter
                if (m != null) for (i in 0 until frames) m.push(l[i], r[i])
            }
            updateNorm(frames)
            var pk = peakEnv
            val decay = exp(-1.0 / (5.0 * sr))
            for (i in 0 until frames) {
                val a = abs(l[i]).toDouble()
                val b = abs(r[i]).toDouble()
                pk = max(max(a, b), pk * decay)
                l[i] = (l[i] * normG).toFloat()
                r[i] = (r[i] * normG).toFloat()
                normG += (normT - normG) * normC
            }
            peakEnv = pk
            for (i in fxs.indices) if (fxOn[i] && fxs[i].active) fxs[i].process(l, r, frames)
        }

        if (VisTap.enabled && VisTap.viewers > 0) VisTap.write(l, r, frames)

        val om = outMeter
        if (om != null) {
            for (i in 0 until frames) om.push(l[i], r[i])
            meterCnt += frames
            if (meterCnt >= sr / 4) {
                meterCnt = 0
                AudioEngine.meterLufs = om.momentary.toFloat()
                AudioEngine.meterRmsDb = om.rmsDb.toFloat()
                AudioEngine.meterPeakDb = om.peakDb.toFloat()
            }
        }

        if (mapMode == 1) {
            for (i in 0 until frames) {
                val a = l[i]
                val b = r[i]
                val m = (a + b) * 0.5f
                l[i] = when (mapL) { 1 -> b; 2 -> m; else -> a }
                r[i] = when (mapR) { 1 -> a; 2 -> m; else -> b }
            }
        }

        var outL = l
        var outR = r
        var n = frames
        val rs = resampler
        if (rs != null) {
            rs.process(l, r, frames)
            outL = rs.outL
            outR = rs.outR
            n = rs.outN
        }
        writeOut(outL, outR, n)
        return outBuf
    }

    private fun ensureOut(bytes: Int) {
        if (outBuf.capacity() < bytes) {
            outBuf = ByteBuffer.allocateDirect(bytes + 4096).order(ByteOrder.nativeOrder())
        }
        outBuf.clear()
    }

    private fun rand(): Float {
        rnd = rnd xor (rnd shl 13)
        rnd = rnd xor (rnd ushr 17)
        rnd = rnd xor (rnd shl 5)
        return (rnd and 0xFFFFFF) / 16777216f
    }

    private fun writeOut(a: FloatArray, b: FloatArray, n: Int) {
        val bps = if (outEnc == ef) 4 else 2
        ensureOut(n * bps * 2)
        if (outEnc == ef) {
            if (bits == 24) {
                val q = 8388607f
                for (i in 0 until n) {
                    var x = a[i] * q
                    var y = b[i] * q
                    if (dither) {
                        x += rand() - rand()
                        y += rand() - rand()
                    }
                    outBuf.putFloat((x.roundToInt() / q).coerceIn(-1f, 1f))
                    outBuf.putFloat((y.roundToInt() / q).coerceIn(-1f, 1f))
                }
            } else {
                for (i in 0 until n) {
                    outBuf.putFloat(a[i])
                    outBuf.putFloat(b[i])
                }
            }
        } else {
            for (i in 0 until n) {
                var x = a[i] * 32767f
                var y = b[i] * 32767f
                if (dither) {
                    x += rand() - rand()
                    y += rand() - rand()
                }
                outBuf.putShort(x.roundToInt().coerceIn(-32768, 32767).toShort())
                outBuf.putShort(y.roundToInt().coerceIn(-32768, 32767).toShort())
            }
        }
        outBuf.flip()
    }
}
