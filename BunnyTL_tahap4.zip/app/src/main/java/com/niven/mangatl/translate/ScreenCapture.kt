package com.niven.mangatl

import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.media.Image
import android.media.ImageReader
import android.view.View

// Terjemah layar: tangkap layar (MediaProjection -> ImageReader -> Bitmap) dan pembersihan hasil.
// Fungsi ekstensi dari ScreenService; keadaan dan siklus hidup service tetap di ScreenService.kt.

internal fun ScreenService.dropHeld() {
    synchronized(heldLock) {
        try {
            held?.close()
        } catch (_: Throwable) {
        }
        held = null
    }
}

/** Mengembalikan true kalau layar virtual baru dibuat (frame pertama perlu waktu sebentar). */
internal fun ScreenService.ensureDisplay(w: Int, h: Int): Boolean {
    if (reader != null && vd != null && w == capW && h == capH) return false
    dropHeld()
    val newReader = ImageReader.newInstance(w, h, PixelFormat.RGBA_8888, 3)
    newReader.setOnImageAvailableListener(listener, cap)
    val old = reader
    val existing = vd
    if (existing == null) {
        vd = projection!!.createVirtualDisplay(
            "bunnytl", w, h, dpi,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
            newReader.surface, null, cap
        )
    } else {
        existing.resize(w, h, dpi)
        existing.setSurface(newReader.surface)
    }
    reader = newReader
    capW = w
    capH = h
    try {
        old?.close()
    } catch (_: Throwable) {
    }
    return true
}

internal fun ScreenService.requestFrame() {
    try {
        val s = realSize()
        dpi = s[2]
        val recreated = ensureDisplay(s[0], s[1])
        cap?.postDelayed({ takeFrame(0) }, if (recreated) 400L else 0L)
    } catch (t: Throwable) {
        fail("Gagal ambil layar: ${t.message}")
    }
}

internal fun ScreenService.takeFrame(attempt: Int) {
    val bmp: Bitmap? = synchronized(heldLock) {
        val h = held
        if (h == null) {
            null
        } else {
            try {
                toBitmap(h)
            } catch (_: Throwable) {
                null
            }
        }
    }
    if (bmp != null) {
        try {
            process(bmp, false)
        } catch (t: Throwable) {
            fail("Gagal ambil layar: ${t.message}")
        }
        return
    }
    if (attempt < 10) {
        cap?.postDelayed({ takeFrame(attempt + 1) }, 200)
    } else {
        fail("Gagal ambil layar, coba ketuk lagi.")
    }
}

internal fun ScreenService.toBitmap(img: Image): Bitmap {
    val plane = img.planes[0]
    val pixelStride = plane.pixelStride
    val rowPadding = plane.rowStride - pixelStride * img.width
    val wide = Bitmap.createBitmap(
        img.width + rowPadding / pixelStride, img.height, Bitmap.Config.ARGB_8888
    )
    wide.copyPixelsFromBuffer(plane.buffer)
    return if (wide.width == img.width) {
        wide
    } else {
        Bitmap.createBitmap(wide, 0, 0, img.width, img.height)
    }
}

internal fun ScreenService.finishCapture() {
    busy = false
    fab?.text = fabIdleText()
    fab?.visibility = View.VISIBLE
    if (autoOn) scheduleIdle()
}

/** Hapus semua hasil terjemahan dari layar. */
internal fun ScreenService.clearResults() {
    ov?.setItems(emptyList())
    ov?.alpha = 1f
    panel?.alpha = 1f
    panel?.visibility = View.GONE
    fab?.text = fabIdleText()
}
