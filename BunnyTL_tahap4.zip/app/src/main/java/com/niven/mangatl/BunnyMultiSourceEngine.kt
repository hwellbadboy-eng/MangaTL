package com.niven.mangatl

import android.content.Context
import android.net.Uri
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.util.Locale

/** Declarative, HTTPS-only provider engine. It never executes downloaded code. */
object BunnyMultiSourceEngine {
    private const val PREFS = "bunny_multisource"
    private const val KEY_REGISTRY_URL = "registry_url"
    private const val KEY_REGISTRY_JSON = "registry_json"
    private const val KEY_REGISTRY_TIME = "registry_time"
    private const val REGISTRY_TTL_MS = 6 * 60 * 60 * 1000L

    data class Source(
        val id: String,
        val name: String,
        val searchUrls: List<String>,
        val resultsPath: String,
        val titlePath: String,
        val urlPath: String,
        val subtitleLanguagePath: String,
        val subtitleUrlPath: String,
        val subtitleMimePath: String,
        val qualityPath: String,
        val downloadAllowedPath: String
    )

    data class Result(
        val title: String,
        val sourceId: String,
        val sourceName: String,
        val streamUrl: String,
        val subtitleLanguage: String,
        val subtitleUrl: String?,
        val subtitleMime: String?,
        val quality: String,
        val downloadAllowed: Boolean,
        val rankScore: Int
    )

    data class SearchResponse(val results: List<Result>, val sourceCount: Int, val errors: List<String>)

    fun registryUrl(context: Context): String = prefs(context).getString(KEY_REGISTRY_URL, "") ?: ""

    fun setRegistryUrl(context: Context, value: String) {
        prefs(context).edit().putString(KEY_REGISTRY_URL, value.trim()).apply()
        prefs(context).edit().remove(KEY_REGISTRY_JSON).remove(KEY_REGISTRY_TIME).apply()
    }

    suspend fun search(context: Context, query: String, language: String): SearchResponse = withContext(Dispatchers.IO) {
        require(query.isNotBlank()) { "Masukkan judul yang ingin dicari." }
        val sources = loadRegistry(context)
        if (sources.isEmpty()) return@withContext SearchResponse(emptyList(), 0, listOf("Registry belum berisi sumber aktif."))

        val results = mutableListOf<Result>()
        val errors = mutableListOf<String>()
        for (source in sources) {
            var parsed = false
            var lastError = "Tidak ada hasil"
            for (template in source.searchUrls) {
                try {
                    val encoded = URLEncoder.encode(query, Charsets.UTF_8.name())
                    val endpoint = template.replace("{query}", encoded)
                    requireHttps(endpoint)
                    val body = request(endpoint)
                    val root = parseJson(body)
                    val items = valueAt(root, source.resultsPath) as? JSONArray
                        ?: if (root is JSONArray && source.resultsPath.isBlank()) root else JSONArray()
                    for (i in 0 until items.length()) {
                        val item = items.opt(i) ?: continue
                        val title = valueAt(item, source.titlePath)?.toString()?.takeIf { it.isNotBlank() } ?: continue
                        val stream = valueAt(item, source.urlPath)?.toString()?.takeIf { it.isNotBlank() } ?: continue
                        if (!isHttpUrl(stream)) continue
                        val subLang = valueAt(item, source.subtitleLanguagePath)?.toString().orEmpty()
                        if (language != "all" && !languageMatches(subLang, language)) continue
                        val subUrl = valueAt(item, source.subtitleUrlPath)?.toString()?.takeIf { isHttpUrl(it) }
                        val subMime = valueAt(item, source.subtitleMimePath)?.toString()?.takeIf { it.isNotBlank() }
                        val quality = valueAt(item, source.qualityPath)?.toString().orEmpty()
                        val declaredDownloadAllowed = valueAt(item, source.downloadAllowedPath)?.toString()?.toBooleanStrictOrNull() == true
                        // Android DownloadManager cannot package segmented HLS/DASH streams as a playable file.
                        val segmentedStream = stream.substringBefore('?').substringBefore('#')
                            .endsWith(".m3u8", ignoreCase = true) || segmentedStreamEndsWithDash(stream)
                        val allowed = declaredDownloadAllowed && !segmentedStream
                        results += Result(
                            title = title,
                            sourceId = source.id,
                            sourceName = source.name,
                            streamUrl = stream,
                            subtitleLanguage = subLang,
                            subtitleUrl = subUrl,
                            subtitleMime = subMime,
                            quality = quality,
                            downloadAllowed = allowed,
                            rankScore = rankScore(context, source.id, quality, subLang, language)
                        )
                    }
                    markHealth(context, source.id, true)
                    parsed = true
                    break
                } catch (e: Exception) {
                    lastError = e.message ?: e.javaClass.simpleName
                }
            }
            if (!parsed) {
                markHealth(context, source.id, false)
                errors += "${source.name}: $lastError"
            }
        }
        SearchResponse(results.sortedByDescending { it.rankScore }, sources.size, errors)
    }

    private fun loadRegistry(context: Context): List<Source> {
        val p = prefs(context)
        val now = System.currentTimeMillis()
        var json = p.getString(KEY_REGISTRY_JSON, null)
        val fetched = p.getLong(KEY_REGISTRY_TIME, 0L)
        if (json.isNullOrBlank() || now - fetched > REGISTRY_TTL_MS) {
            val endpoint = registryUrl(context)
            if (endpoint.isBlank()) {
                if (json.isNullOrBlank()) throw IllegalStateException("URL Remote Source Registry belum diatur.")
            } else {
                try {
                    requireHttps(endpoint)
                    val updated = request(endpoint)
                    // Validate before caching; malformed/unavailable updates retain the last known-good copy.
                    parseSources(updated)
                    json = updated
                    p.edit().putString(KEY_REGISTRY_JSON, updated).putLong(KEY_REGISTRY_TIME, now).apply()
                } catch (e: Exception) {
                    if (json.isNullOrBlank()) throw e
                }
            }
        }
        return parseSources(json)
    }

    private fun parseSources(raw: String?): List<Source> {
        val root = JSONObject(raw ?: "{}")
        val array = root.optJSONArray("sources") ?: JSONArray()
        val out = mutableListOf<Source>()
        for (i in 0 until array.length()) {
            val o = array.optJSONObject(i) ?: continue
            if (!o.optBoolean("enabled", true)) continue
            val urls = mutableListOf<String>()
            o.optString("searchUrl").takeIf { it.isNotBlank() }?.let(urls::add)
            val fallback = o.optJSONArray("fallbackSearchUrls")
            if (fallback != null) for (j in 0 until fallback.length()) fallback.optString(j).takeIf { it.isNotBlank() }?.let(urls::add)
            if (urls.isEmpty()) continue
            out += Source(
                id = o.optString("id", "source-$i"),
                name = o.optString("name", "Source ${i + 1}"),
                searchUrls = urls,
                resultsPath = o.optString("resultsPath", "results"),
                titlePath = o.optString("titlePath", "title"),
                urlPath = o.optString("urlPath", "url"),
                subtitleLanguagePath = o.optString("subtitleLanguagePath", "subtitleLanguage"),
                subtitleUrlPath = o.optString("subtitleUrlPath", "subtitleUrl"),
                subtitleMimePath = o.optString("subtitleMimePath", "subtitleMime"),
                qualityPath = o.optString("qualityPath", "quality"),
                downloadAllowedPath = o.optString("downloadAllowedPath", "downloadAllowed")
            )
        }
        return out
    }

    private fun request(address: String): String {
        requireHttps(address)
        val connection = URL(address).openConnection() as HttpURLConnection
        try {
            connection.requestMethod = "GET"
            connection.connectTimeout = 10_000
            connection.readTimeout = 15_000
            connection.setRequestProperty("Accept", "application/json")
            connection.setRequestProperty("User-Agent", "BunnyTL/2.0 MultiSource")
            val code = connection.responseCode
            if (code !in 200..299) throw IllegalStateException("HTTP $code")
            return connection.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() }
        } finally {
            connection.disconnect()
        }
    }

    private fun parseJson(body: String): Any = try {
        JSONObject(body)
    } catch (_: Exception) {
        JSONArray(body)
    }

    private fun valueAt(root: Any?, path: String): Any? {
        if (root == null || path.isBlank()) return root
        var current: Any? = root
        for (part in path.split('.')) {
            current = when (val node = current) {
                is JSONObject -> if (node.has(part)) node.opt(part) else null
                is JSONArray -> part.toIntOrNull()?.let { node.opt(it) }
                else -> null
            }
            if (current == JSONObject.NULL) current = null
            if (current == null) return null
        }
        return current
    }

    private fun rankScore(context: Context, id: String, quality: String, subLang: String, requested: String): Int {
        val height = Regex("(?i)(\\d{3,4})p").find(quality)?.groupValues?.getOrNull(1)?.toIntOrNull() ?: 0
        val qualityScore = when {
            height >= 2160 -> 40
            height >= 1080 -> 32
            height >= 720 -> 24
            height >= 480 -> 16
            height > 0 -> 8
            else -> 0
        }
        val subtitleScore = if (requested == "all" || languageMatches(subLang, requested)) 30 else 0
        val failures = prefs(context).getInt("health_${id}_fail", 0).coerceAtMost(10)
        val stabilityScore = (20 - failures * 2).coerceAtLeast(0)
        return qualityScore + subtitleScore + stabilityScore
    }

    private fun markHealth(context: Context, id: String, ok: Boolean) {
        val p = prefs(context)
        val edit = p.edit().putLong("health_${id}_checked", System.currentTimeMillis())
        if (ok) edit.putInt("health_${id}_fail", 0) else edit.putInt("health_${id}_fail", p.getInt("health_${id}_fail", 0) + 1)
        edit.apply()
    }

    private fun languageMatches(value: String, requested: String): Boolean {
        val v = value.lowercase(Locale.ROOT)
        return when (requested) {
            "id" -> v.contains("indonesia") || v.contains("indo") || v == "id" || v.contains("bahasa indonesia")
            "en" -> v.contains("english") || v == "en"
            "ja" -> v.contains("japanese") || v == "ja" || v.contains("日本語")
            "other" -> v.isNotBlank() && !languageMatches(v, "id") && !languageMatches(v, "en") && !languageMatches(v, "ja")
            else -> v.contains(requested)
        }
    }

    private fun segmentedStreamEndsWithDash(value: String): Boolean {
        val path = value.substringBefore('?').substringBefore('#')
        return path.endsWith(".mpd", ignoreCase = true)
    }

    private fun isHttpUrl(value: String): Boolean = try {
        val scheme = Uri.parse(value).scheme?.lowercase(Locale.ROOT)
        scheme == "https"
    } catch (_: Exception) { false }

    private fun requireHttps(value: String) {
        require(Uri.parse(value).scheme.equals("https", ignoreCase = true)) { "Hanya endpoint HTTPS yang diizinkan." }
    }

    private fun prefs(context: Context) = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
}
