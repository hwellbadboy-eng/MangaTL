package com.niven.mangatl

import android.content.ClipboardManager
import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.LayerDrawable
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.text.InputType
import android.view.Gravity
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import android.view.ViewGroup
import android.view.animation.DecelerateInterpolator
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.webkit.WebView
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.ScrollView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import kotlin.math.abs

/**
 * Layar web login layar penuh: WebView memenuhi layar, semua tombol dilebur jadi satu bubble logo yang bisa digeser
 * (nempel ke sisi kiri/kanan). Ketuk bubble = menu: Mode desktop, Situs, Buka link / cari, Unduh video ini, Layar utama (keluar browser tanpa menyimpan), Simpan.
 * Tahan bubble lalu geser ke salah satu situs (tanpa melepas) = daftar situs muncul di atas & bawah bubble; lepas di salah satu = buka situs itu.
 */
class WebBubble(
    private val act: AppCompatActivity,
    private val webView: WebView,
    private val onSave: () -> Unit,
    private val onSite: (LoginSite) -> Unit,
    private val onGo: (String) -> Unit,
    private val onDesktop: (Boolean) -> Unit,
    private val onBack: () -> Unit,
    private val onReload: () -> Unit,
    private val onHome: () -> Unit,
    private val onDownload: () -> Unit
) {
    val root = FrameLayout(act)

    private val prefs = act.getSharedPreferences("dl_web_bubble", Context.MODE_PRIVATE)
    private val bubble = FrameLayout(act)
    private val logo = BunnyLogoView(act)
    private val menu = LinearLayout(act)
    private val dimView = View(act)
    private val urlBar = LinearLayout(act)
    private val etWeb = EditText(act)
    private val toastView = TextView(act)
    private val progView = View(act)
    private val ui = Handler(Looper.getMainLooper())
    private var hideToast: Runnable? = null
    private var curSite: LoginSite? = null
    private var desktop = false
    private var sitesOpen = false
    private var placed = false
    private val picker = LinearLayout(act)
    private val pickerChips = ArrayList<PickChip>()
    private var pickerHover: LoginSite? = null
    private var sheet: FrameLayout? = null

    private class PickChip(val site: LoginSite, val view: LinearLayout, val icon: ImageView, val label: TextView)

    private val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
    private val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT
    private fun dp(v: Int) = Ui.dp(act, v)
    private val med: Typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)

    init {
        root.setBackgroundColor(Color.BLACK)
        root.addView(webView, FrameLayout.LayoutParams(MATCH, MATCH))

        // lapisan tipis: ketuk di luar menu = tutup
        dimView.visibility = View.GONE
        dimView.setOnClickListener { closeAll() }
        root.addView(dimView, FrameLayout.LayoutParams(MATCH, MATCH))

        // menu di samping bubble
        menu.orientation = LinearLayout.VERTICAL
        menu.visibility = View.GONE
        root.addView(menu, FrameLayout.LayoutParams(WRAP, WRAP))

        picker.orientation = LinearLayout.VERTICAL
        picker.visibility = View.GONE
        picker.elevation = dp(7).toFloat()
        root.addView(picker, FrameLayout.LayoutParams(WRAP, WRAP))

        buildUrlBar()
        buildBubble()
        buildToast()

        progView.setBackgroundColor(Color.WHITE)
        progView.visibility = View.GONE
        root.addView(progView, FrameLayout.LayoutParams(0, dp(2), Gravity.TOP or Gravity.START))

        ViewCompat.setOnApplyWindowInsetsListener(root) { v, wi ->
            v.setPadding(0, 0, 0, wi.getInsets(WindowInsetsCompat.Type.ime()).bottom)
            wi
        }

        root.addOnLayoutChangeListener { _, l, t, r, b, ol, ot, orr, ob ->
            if (r - l > 0 && b - t > 0) {
                if (!placed) {
                    placed = true
                    placeInitial()
                } else if (r - l != orr - ol || b - t != ob - ot) {
                    clampBubble()
                }
            }
        }
    }

    // ---------------------------------------------------------------- API untuk activity

    fun setSite(s: LoginSite?) { curSite = s }

    /** Popup login (window.open) ditaruh di atas WebView utama, di bawah bubble & menu. */
    fun addPopup(v: View) { root.addView(v, 1, FrameLayout.LayoutParams(MATCH, MATCH)) }
    fun removePopup(v: View) { root.removeView(v) }

    /** Menutup menu / bar link kalau ada yang terbuka. true = ada yang ditutup. */
    fun closeAll(): Boolean {
        val was = menu.visibility == View.VISIBLE || urlBar.visibility == View.VISIBLE || sheet != null
        hideSheet()
        hideBar()
        menu.visibility = View.GONE
        dimView.visibility = View.GONE
        if (picker.visibility != View.VISIBLE) auraOff()
        return was
    }

    /**
     * Menu kecil di dekat jari saat gambar ditekan lama: Unduh (kualitas asli) / Salin link gambar.
     * (x, y) = titik sentuh di layar web (sama dengan koordinat root).
     */
    fun showImageMenu(x: Float, y: Float, onDownloadImg: () -> Unit, onCopy: () -> Unit) {
        closeAll()
        bubble.performHapticFeedback(HapticFeedbackConstants.LONG_PRESS)
        menu.removeAllViews()
        menu.gravity = Gravity.START
        fun add(v: View) = menu.addView(v, LinearLayout.LayoutParams(WRAP, dp(36)).apply { topMargin = dp(7); marginEnd = dp(2) })
        add(item(R.drawable.ic_wb_image, "Unduh gambar (asli)", true) { closeAll(); onDownloadImg() })
        add(item(R.drawable.ic_wb_globe, "Salin link gambar", false) { closeAll(); onCopy() })
        dimView.visibility = View.VISIBLE
        menu.alpha = 0f
        menu.visibility = View.VISIBLE
        menu.post {
            val nx = (x - menu.width / 2f).coerceIn(dp(8).toFloat(), (root.width - menu.width - dp(8)).toFloat().coerceAtLeast(dp(8).toFloat()))
            var ny = y - menu.height - dp(28)
            if (ny < dp(8)) ny = y + dp(28)
            menu.x = nx
            menu.y = ny.coerceIn(dp(8).toFloat(), (root.height - menu.height - dp(8)).toFloat().coerceAtLeast(dp(8).toFloat()))
            menu.animate().alpha(1f).setDuration(120).start()
        }
    }

    /** Panel di bawah layar (mis. pilihan kualitas unduh) di atas halaman web; ketuk di luar panel = tutup. */
    fun showSheet(content: View) {
        closeAll()
        (content.parent as? ViewGroup)?.removeView(content)
        val scrim = FrameLayout(act).apply {
            setBackgroundColor(Color.parseColor("#99000000"))
            setOnClickListener { hideSheet() }
            elevation = dp(10).toFloat()
        }
        val panel = ScrollView(act).apply {
            setBackgroundResource(R.drawable.bg_popup)
            isClickable = true
            clipToPadding = false
            setPadding(dp(16), dp(16), dp(16), dp(16))
            addView(content)
        }
        scrim.addView(panel, FrameLayout.LayoutParams(MATCH, WRAP, Gravity.BOTTOM).apply { setMargins(dp(8), dp(24), dp(8), dp(8)) })
        root.addView(scrim, FrameLayout.LayoutParams(MATCH, MATCH))
        sheet = scrim
    }

    fun hideSheet() {
        val v = sheet ?: return
        sheet = null
        (v.getChildAt(0) as? ScrollView)?.removeAllViews()
        root.removeView(v)
    }

    fun progress(p: Int) {
        if (p >= 100) { progView.visibility = View.GONE; return }
        progView.visibility = View.VISIBLE
        val lp = progView.layoutParams
        lp.width = root.width * p.coerceAtLeast(5) / 100
        progView.layoutParams = lp
    }

    fun toast(msg: String, ms: Long = 1400) {
        toastView.text = msg
        toastView.visibility = View.VISIBLE
        toastView.animate().cancel()
        toastView.animate().alpha(1f).setDuration(200).start()
        hideToast?.let { ui.removeCallbacks(it) }
        val r = Runnable {
            toastView.animate().alpha(0f).setDuration(200).withEndAction { toastView.visibility = View.GONE }.start()
        }
        hideToast = r
        ui.postDelayed(r, ms)
    }

    // ---------------------------------------------------------------- gaya komik tipis

    private fun comic(filled: Boolean, radiusDp: Int, oval: Boolean = false): LayerDrawable {
        fun g(fill: Int, stroke: Int, strokeW: Int): GradientDrawable = GradientDrawable().apply {
            if (oval) shape = GradientDrawable.OVAL else cornerRadius = dp(radiusDp).toFloat()
            setColor(fill)
            if (strokeW > 0) setStroke(strokeW, stroke)
        }
        val shadow = g(if (filled) Color.parseColor("#8E8E93") else Color.WHITE, 0, 0)
        val face = g(if (filled) Color.WHITE else Color.BLACK, if (filled) Color.BLACK else Color.WHITE, dp(2))
        return LayerDrawable(arrayOf<Drawable>(shadow, face)).apply {
            setLayerInset(0, dp(2), dp(2), 0, 0)
            setLayerInset(1, 0, 0, dp(2), dp(2))
        }
    }

    // ---------------------------------------------------------------- bubble

    /** Animasi aura logo: terpicu saat tekan lama (pilih situs) atau tap (pilih opsi). */
    private fun auraOn() = logo.setActive(true)
    private fun auraOff() = logo.setActive(false)

    /** Dipanggil dari onResume / onPause / onDestroy activity pemilik. */
    fun resumeLogo() = logo.resumeLogo()
    fun pauseLogo() = logo.pauseLogo()
    fun releaseLogo() = logo.release()

    private fun buildBubble() {
        bubble.background = comic(false, 28, oval = true)
        bubble.elevation = dp(6).toFloat()
        // Logo digeser ke kanan-bawah (margin 6dp) supaya ujung telinga tidak keluar dari lingkaran hitam.
        bubble.addView(logo.apply {
            resolution = 256
            zoom = 1.1f
            setup()
            setActive(false) // state awal: idle (tanpa kilatan); aura menyala saat tekan lama / tap
        }, FrameLayout.LayoutParams(dp(52), dp(52), Gravity.CENTER).apply { setMargins(dp(6), dp(6), 0, 0) })
        root.addView(bubble, FrameLayout.LayoutParams(dp(56), dp(56), Gravity.TOP or Gravity.START))

        val slop = ViewConfiguration.get(act).scaledTouchSlop
        var sx = 0f
        var sy = 0f
        var ox = 0f
        var oy = 0f
        var moved = false
        var longFired = false
        val longPress = Runnable {
            longFired = true
            bubble.performHapticFeedback(HapticFeedbackConstants.LONG_PRESS)
            closeAll()
            showPicker()
            logo.aura()
            auraOn()
        }
        bubble.setOnTouchListener { v, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    sx = e.rawX; sy = e.rawY
                    ox = v.x - e.rawX; oy = v.y - e.rawY
                    moved = false
                    longFired = false
                    v.animate().cancel()
                    ui.postDelayed(longPress, ViewConfiguration.getLongPressTimeout().toLong())
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    if (longFired) {
                        updatePicker(e.rawY)
                        return@setOnTouchListener true
                    }
                    if (!moved && (abs(e.rawX - sx) > slop || abs(e.rawY - sy) > slop)) {
                        moved = true
                        ui.removeCallbacks(longPress)
                        closeAll()
                    }
                    if (moved) {
                        v.x = (e.rawX + ox).coerceIn(0f, (root.width - v.width).toFloat().coerceAtLeast(0f))
                        v.y = (e.rawY + oy).coerceIn(0f, (root.height - v.height).toFloat().coerceAtLeast(0f))
                    }
                    true
                }
                MotionEvent.ACTION_UP -> {
                    ui.removeCallbacks(longPress)
                    if (longFired) {
                        updatePicker(e.rawY)
                        val s = pickerHover
                        hidePicker()
                        if (s != null) pickSite(s)
                    } else if (moved) snap() else toggleMenu()
                    true
                }
                MotionEvent.ACTION_CANCEL -> {
                    ui.removeCallbacks(longPress)
                    if (longFired) hidePicker() else if (moved) snap()
                    true
                }
                else -> false
            }
        }
    }

    private fun placeInitial() {
        val right = prefs.getBoolean("right", true)
        val yf = prefs.getFloat("y", 0.4f).coerceIn(0f, 1f)
        bubble.x = if (right) (root.width - dp(56) - dp(6)).toFloat() else dp(6).toFloat()
        bubble.y = (root.height - dp(56)).coerceAtLeast(0) * yf
    }

    private fun clampBubble() {
        val right = prefs.getBoolean("right", true)
        val yf = prefs.getFloat("y", 0.4f).coerceIn(0f, 1f)
        bubble.x = if (right) (root.width - dp(56) - dp(6)).toFloat() else dp(6).toFloat()
        bubble.y = (root.height - dp(56)).coerceAtLeast(0) * yf
        if (menu.visibility == View.VISIBLE) position()
    }

    private fun onRight() = bubble.x + bubble.width / 2f > root.width / 2f

    private fun snap() {
        val right = onRight()
        val tx = if (right) (root.width - bubble.width - dp(6)).toFloat() else dp(6).toFloat()
        bubble.animate().x(tx).setDuration(200).setInterpolator(DecelerateInterpolator()).start()
        val span = (root.height - bubble.height).coerceAtLeast(1)
        prefs.edit().putBoolean("right", right).putFloat("y", (bubble.y / span).coerceIn(0f, 1f)).apply()
    }

    // ---------------------------------------------------------------- picker situs (tahan lalu geser)

    /**
     * Tahan bubble tanpa melepas -> daftar situs muncul di ATAS dan BAWAH bubble (dibagi rata kalau muat di kedua sisi).
     * Kalau satu sisi kehabisan ruang (bubble dekat tepi), hanya sisa yang tidak muat yang pindah ke sisi lawan.
     * Urutan situs tetap dibaca atas ke bawah; bubble menempati celah di antaranya.
     */
    private fun showPicker() {
        picker.removeAllViews()
        pickerChips.clear()
        pickerHover = null
        picker.gravity = if (onRight()) Gravity.END else Gravity.START

        val sites = DlCookies.SITES
        val n = sites.size
        val chipH = dp(36)
        val itemH = chipH + dp(6)          // tinggi chip + jarak atas
        val gap = dp(6)                    // jarak chip terdekat ke bubble
        val edge = dp(8)                   // jarak minimum ke tepi layar
        val bh = bubble.height

        // kapasitas tiap sisi (jumlah chip yang muat)
        val capAbove = (((bubble.y - edge - gap) / itemH).toInt()).coerceAtLeast(0)
        val capBelow = (((root.height - (bubble.y + bh) - edge) / itemH).toInt()).coerceAtLeast(0)

        // pembagian ideal: rata; lalu geser sisa dari sisi yang sempit ke sisi lawan
        var above = n / 2
        var below = n - above
        if (above > capAbove) { above = capAbove; below = n - above }
        if (below > capBelow) { below = capBelow; above = n - below }
        above = above.coerceIn(0, n)
        below = n - above

        fun addChip(s: LoginSite) {
            val icon = ImageView(act).apply { setImageResource(iconFor(s)); setColorFilter(Color.WHITE) }
            val label = TextView(act).apply {
                text = s.label
                textSize = 13f
                typeface = med
                setTextColor(Color.WHITE)
            }
            val row = LinearLayout(act).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(dp(10), 0, dp(16), 0)
                background = comic(false, 17)
                addView(icon, LinearLayout.LayoutParams(dp(18), dp(18)))
                addView(label, LinearLayout.LayoutParams(WRAP, WRAP).apply { marginStart = dp(7) })
            }
            picker.addView(row, LinearLayout.LayoutParams(WRAP, chipH).apply { topMargin = dp(6); marginEnd = dp(2) })
            pickerChips.add(PickChip(s, row, icon, label))
        }

        for (i in 0 until above) addChip(sites[i])
        // celah untuk bubble (transparan; bubble tetap menerima sentuhan sendiri)
        val topGap = if (above > 0) gap else 0
        picker.addView(View(act), LinearLayout.LayoutParams(dp(1), topGap + bh))
        for (i in above until n) addChip(sites[i])

        val aboveBlock = above * itemH + topGap
        picker.alpha = 0f
        picker.visibility = View.VISIBLE
        picker.post {
            val right = onRight()
            val x = if (right) bubble.x + bubble.width - picker.width else bubble.x
            val y = bubble.y - aboveBlock
            picker.x = x.coerceIn(dp(4).toFloat(), (root.width - picker.width - dp(4)).toFloat().coerceAtLeast(dp(4).toFloat()))
            // hanya terpakai kalau layar terlalu pendek untuk semua situs
            picker.y = y.coerceIn(edge.toFloat(), (root.height - picker.height - edge).toFloat().coerceAtLeast(edge.toFloat()))
            picker.animate().alpha(1f).setDuration(120).start()
        }
    }

    private fun updatePicker(rawY: Float) {
        if (picker.visibility != View.VISIBLE) return
        var hit: PickChip? = null
        val loc = IntArray(2)
        for (c in pickerChips) {
            if (c.view.height <= 0) continue
            c.view.getLocationOnScreen(loc)
            if (rawY >= loc[1] && rawY <= loc[1] + c.view.height) { hit = c; break }
        }
        if (hit?.site?.key == pickerHover?.key) return
        pickerHover = hit?.site
        if (hit != null) bubble.performHapticFeedback(HapticFeedbackConstants.CLOCK_TICK)
        for (c in pickerChips) {
            val on = c === hit
            c.view.background = comic(on, 17)
            val fg = if (on) Color.BLACK else Color.WHITE
            c.icon.setColorFilter(fg)
            c.label.setTextColor(fg)
        }
    }

    private fun hidePicker() {
        picker.animate().cancel()
        picker.visibility = View.GONE
        picker.removeAllViews()
        pickerChips.clear()
        pickerHover = null
        if (menu.visibility != View.VISIBLE) auraOff()
    }

    // ---------------------------------------------------------------- menu

    private fun toggleMenu() {
        if (menu.visibility == View.VISIBLE) closeAll() else { openMenu(); logo.aura(); auraOn() }
    }

    private fun openMenu() {
        hideBar()
        sitesOpen = false
        fillMenu()
        dimView.visibility = View.VISIBLE
        menu.alpha = 0f
        menu.visibility = View.VISIBLE
        menu.post {
            position()
            menu.animate().alpha(1f).setDuration(150).start()
        }
    }

    private fun position() {
        val right = onRight()
        var x = if (right) bubble.x - menu.width - dp(8) else bubble.x + bubble.width + dp(8)
        var y = bubble.y + bubble.height - menu.height
        x = x.coerceIn(dp(4).toFloat(), (root.width - menu.width - dp(4)).toFloat().coerceAtLeast(dp(4).toFloat()))
        y = y.coerceIn(dp(8).toFloat(), (root.height - menu.height - dp(8)).toFloat().coerceAtLeast(dp(8).toFloat()))
        menu.x = x
        menu.y = y
    }

    private fun iconFor(s: LoginSite?): Int = when (s?.key) {
        "youtube.com" -> R.drawable.ic_wb_yt
        "instagram.com" -> R.drawable.ic_wb_ig
        "tiktok.com" -> R.drawable.ic_wb_tt
        "facebook.com" -> R.drawable.ic_wb_fb
        "x.com" -> R.drawable.ic_wb_x
        "threads.com" -> R.drawable.ic_wb_threads
        "reddit.com" -> R.drawable.ic_wb_reddit
        "pinterest.com" -> R.drawable.ic_wb_pinterest
        "snapchat.com" -> R.drawable.ic_wb_snapchat
        else -> R.drawable.ic_wb_globe
    }

    private fun item(icon: Int, label: String, filled: Boolean, onClick: () -> Unit): View {
        val fg = if (filled) Color.BLACK else Color.WHITE
        return LinearLayout(act).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(10), 0, dp(16), 0)
            background = comic(filled, 17)
            isClickable = true
            setOnClickListener { onClick() }
            addView(ImageView(act).apply {
                setImageResource(icon)
                setColorFilter(fg)
            }, LinearLayout.LayoutParams(dp(18), dp(18)))
            addView(TextView(act).apply {
                text = label
                textSize = 13f
                typeface = med
                setTextColor(fg)
            }, LinearLayout.LayoutParams(WRAP, WRAP).apply { marginStart = dp(7) })
        }
    }

    private fun roundBtn(icon: Int, desc: String, onClick: () -> Unit) = ImageView(act).apply {
        setImageResource(icon)
        setColorFilter(Color.WHITE)
        scaleType = ImageView.ScaleType.CENTER
        contentDescription = desc
        background = comic(false, 19, oval = true)
        isClickable = true
        setOnClickListener { onClick() }
    }

    private fun fillMenu() {
        menu.removeAllViews()
        menu.gravity = if (onRight()) Gravity.END else Gravity.START
        fun add(v: View) = menu.addView(v, LinearLayout.LayoutParams(WRAP, dp(36)).apply {
            topMargin = dp(7)
            marginEnd = dp(2)
        })
        val quick = LinearLayout(act).apply { orientation = LinearLayout.HORIZONTAL }
        quick.addView(roundBtn(R.drawable.ic_wb_back, "Kembali") { closeAll(); onBack() }, LinearLayout.LayoutParams(dp(38), dp(38)))
        quick.addView(roundBtn(R.drawable.ic_wb_reload, "Muat ulang") { closeAll(); toast("Memuat ulang…"); onReload() },
            LinearLayout.LayoutParams(dp(38), dp(38)).apply { marginStart = dp(8) })
        menu.addView(quick, LinearLayout.LayoutParams(WRAP, WRAP).apply {
            topMargin = dp(7)
            marginEnd = dp(2)
            bottomMargin = dp(2)
        })
        add(item(R.drawable.ic_wb_download, "Unduh video ini", false) {
            closeAll()
            onDownload()
        })
        add(item(R.drawable.ic_wb_desktop, if (desktop) "Mode desktop · aktif" else "Mode desktop", desktop) { toggleDesktop() })
        if (sitesOpen) {
            DlCookies.SITES.forEach { s ->
                add(item(iconFor(s), s.label, s.key == curSite?.key) { pickSite(s) })
            }
        }
        add(item(iconFor(curSite), if (sitesOpen) "Tutup daftar" else "Pindah situs", false) {
            sitesOpen = !sitesOpen
            fillMenu()
            menu.post { position() }
        })
        add(item(R.drawable.ic_wb_globe, "Buka link / cari", false) { showBar() })
        add(item(R.drawable.ic_wb_home, "Layar utama", false) {
            closeAll()
            onHome()
        })
        add(item(R.drawable.ic_wb_check, "Simpan", true) {
            closeAll()
            onSave()
        })
    }

    private fun toggleDesktop() {
        desktop = !desktop
        closeAll()
        toast(if (desktop) "Mode desktop aktif" else "Mode desktop mati")
        onDesktop(desktop)
    }

    private fun pickSite(s: LoginSite) {
        curSite = s
        closeAll()
        toast("Membuka ${s.label}…")
        onSite(s)
    }

    // ---------------------------------------------------------------- bar link / cari

    private fun buildUrlBar() {
        urlBar.orientation = LinearLayout.HORIZONTAL
        urlBar.gravity = Gravity.CENTER_VERTICAL
        urlBar.background = comic(false, 21)
        urlBar.setPadding(dp(14), 0, dp(8), dp(2))
        urlBar.visibility = View.GONE
        urlBar.elevation = dp(6).toFloat()

        etWeb.hint = "Tempel link atau cari"
        etWeb.setHintTextColor(Color.parseColor("#8E8E93"))
        etWeb.setTextColor(Color.WHITE)
        etWeb.textSize = 14f
        etWeb.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_URI
        etWeb.isSingleLine = true
        etWeb.imeOptions = EditorInfo.IME_ACTION_GO
        etWeb.setBackgroundColor(Color.TRANSPARENT)
        etWeb.setPadding(0, 0, dp(4), 0)
        etWeb.setOnEditorActionListener { _, id, _ ->
            if (id == EditorInfo.IME_ACTION_GO) { goUrl(); true } else false
        }
        urlBar.addView(etWeb, LinearLayout.LayoutParams(0, MATCH, 1f))

        urlBar.addView(ImageView(act).apply {
            setImageResource(R.drawable.ic_dl_paste)
            scaleType = ImageView.ScaleType.CENTER
            contentDescription = "Tempel"
            isClickable = true
            setOnClickListener { paste() }
        }, LinearLayout.LayoutParams(dp(30), dp(30)))

        urlBar.addView(ImageView(act).apply {
            setImageResource(R.drawable.ic_wb_go)
            setColorFilter(Color.BLACK)
            scaleType = ImageView.ScaleType.CENTER
            contentDescription = "Buka"
            background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(Color.WHITE) }
            isClickable = true
            setOnClickListener { goUrl() }
        }, LinearLayout.LayoutParams(dp(30), dp(30)).apply { marginStart = dp(4) })

        val w = minOf(act.resources.displayMetrics.widthPixels - dp(24), dp(340))
        root.addView(urlBar, FrameLayout.LayoutParams(w, dp(42), Gravity.TOP or Gravity.CENTER_HORIZONTAL).apply {
            topMargin = dp(44)
        })
    }

    private fun showBar() {
        menu.visibility = View.GONE
        dimView.visibility = View.VISIBLE
        urlBar.alpha = 0f
        urlBar.visibility = View.VISIBLE
        urlBar.animate().alpha(1f).setDuration(200).start()
        etWeb.requestFocus()
        ui.postDelayed({
            if (urlBar.visibility == View.VISIBLE) {
                (act.getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager)
                    .showSoftInput(etWeb, InputMethodManager.SHOW_IMPLICIT)
            }
        }, 220)
    }

    private fun hideBar() {
        if (urlBar.visibility != View.VISIBLE) return
        (act.getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager)
            .hideSoftInputFromWindow(etWeb.windowToken, 0)
        etWeb.clearFocus()
        urlBar.animate().cancel()
        urlBar.visibility = View.GONE
    }

    private fun paste() {
        val cm = act.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        val t = cm.primaryClip?.takeIf { it.itemCount > 0 }?.getItemAt(0)?.coerceToText(act)?.toString()
        if (t.isNullOrBlank()) {
            toast("Clipboard kosong")
        } else {
            etWeb.setText(t.trim())
            etWeb.setSelection(etWeb.text.length)
        }
    }

    private fun goUrl() {
        val v = etWeb.text.toString().trim()
        if (v.isEmpty()) return
        val hasScheme = Regex("^https?:", RegexOption.IGNORE_CASE).containsMatchIn(v)
        val looksUrl = hasScheme || Regex("^[\\w-]+(\\.[\\w-]+)+(/\\S*)?\$").matches(v)
        val u = when {
            !looksUrl -> "https://www.google.com/search?q=" + Uri.encode(v)
            hasScheme -> v
            else -> "https://$v"
        }
        closeAll()
        toast("Membuka " + u.replace(Regex("^https?://(www\\.)?"), "").take(28) + "…")
        onGo(u)
    }

    // ---------------------------------------------------------------- toast komik di atas

    private fun buildToast() {
        toastView.textSize = 13f
        toastView.typeface = med
        toastView.setTextColor(Color.BLACK)
        toastView.gravity = Gravity.CENTER
        toastView.setPadding(dp(16), dp(8), dp(18), dp(10))
        toastView.background = comic(true, 18)
        toastView.alpha = 0f
        toastView.visibility = View.GONE
        toastView.elevation = dp(8).toFloat()
        root.addView(toastView, FrameLayout.LayoutParams(WRAP, WRAP, Gravity.TOP or Gravity.CENTER_HORIZONTAL).apply {
            topMargin = dp(44)
        })
    }
}
