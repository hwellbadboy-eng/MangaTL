package com.niven.mangatl

import android.annotation.SuppressLint
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.graphics.Color
import android.util.AttributeSet
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.webkit.JavascriptInterface
import android.webkit.RenderProcessGoneDetail
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import org.json.JSONArray
import org.json.JSONObject

// Layar Chat: WebView untuk assets/chat/chat.html dan jembatan dua arah.
//  HTML -> Kotlin : objek "Bunny" (ChatBridge)
//  Kotlin -> HTML : fungsi di window.A (lihat js() di bawah)

/** WebView transparan seukuran layar. Sentuhan juga diintip supaya avatar di belakang tetap bisa menatap jari. */
class ChatWebView @JvmOverloads constructor(context: Context, attrs: AttributeSet? = null) : WebView(context, attrs) {

    var onRawTouch: ((MotionEvent) -> Unit)? = null

    @SuppressLint("ClickableViewAccessibility")
    override fun onTouchEvent(event: MotionEvent): Boolean {
        onRawTouch?.invoke(event)
        return super.onTouchEvent(event)
    }
}

@SuppressLint("SetJavaScriptEnabled")
internal fun ChatActivity.setupWeb() {
    web = findViewById(R.id.chatWeb)
    web.setBackgroundColor(Color.TRANSPARENT)
    web.overScrollMode = WebView.OVER_SCROLL_NEVER
    web.isVerticalScrollBarEnabled = false
    web.isHorizontalScrollBarEnabled = false
    web.isHapticFeedbackEnabled = false
    web.settings.javaScriptEnabled = true
    web.settings.textZoom = 100
    web.settings.setSupportZoom(false)
    web.settings.blockNetworkLoads = true   // halaman sepenuhnya offline
    web.addJavascriptInterface(ChatBridge(this), "Bunny")
    web.webViewClient = object : WebViewClient() {
        override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean = true

        override fun onRenderProcessGone(view: WebView?, detail: RenderProcessGoneDetail?): Boolean {
            webReady = false
            recreate()
            return true
        }
    }
    // Sentuhan di ruang kosong diteruskan ke avatar (dia menoleh ke arah jari).
    var gazing = false
    web.onRawTouch = { e ->
        if (e.actionMasked == MotionEvent.ACTION_DOWN) {
            gazing = pokeAllowed(e.rawX, e.rawY)
        }
        if (gazing) avatar?.onTouchEvent(e)
    }
    web.loadUrl("file:///android_asset/chat/chat.html")
}

/** Panggil window.A.<call> di halaman. Diabaikan selama halaman belum siap (state dikirim ulang saat siap). */
internal fun ChatActivity.js(call: String) {
    if (!webReady || isDestroyed) return
    web.evaluateJavascript("window.A&&A.$call", null)
}

private fun q(s: String) = JSONObject.quote(s)

internal fun ChatActivity.jsAdd(m: Msg) = js("add(${m.id},${m.isUser},${q(m.text)})")
internal fun ChatActivity.jsChunk(m: Msg, chunk: String) = js("chunk(${m.id},${q(chunk)})")

/** plain = true: tampilkan teks apa adanya (galat / jawaban kosong), tanpa mesin ketik. */
internal fun ChatActivity.jsDone(m: Msg, plain: Boolean) = js("done(${m.id},${q(m.text)},$plain)")
internal fun ChatActivity.setInput(text: String) = js("input(${q(text)})")

internal fun ChatActivity.sendHistory(list: List<Msg>) {
    val a = JSONArray()
    for (m in list) {
        val live = sending && !m.isUser && m === list.lastOrNull()
        val t = if (m.text.isEmpty() && !live) "..." else m.text
        a.put(JSONObject().put("id", m.id).put("u", m.isUser).put("t", t).put("live", live))
    }
    js("history($a)")
}

/** Kirim keadaan layar ke halaman. Aman dipanggil sering: hanya dikirim kalau ada yang berubah. */
internal fun ChatActivity.pushState() {
    if (!webReady || isDestroyed) return
    val o = JSONObject()
    o.put(
        "s",
        when {
            Voice.playing -> "speaking"
            sending || Voice.speaking -> "thinking"
            listening -> "listening"
            else -> "idle"
        }
    )
    o.put("sending", sending)
    o.put("stream", sending && streaming)
    o.put("listening", listening)
    o.put("live", live)
    o.put("mic", micStatus ?: "")
    o.put("voice", Voice.autoSpeak(this))
    o.put("bub", bubblesOn)
    o.put("show", avatarWanted)
    o.put("kb", keyboardUp)
    o.put("line", Math.round(chatTopFrac() * 100f).coerceIn(0, 85))
    o.put("fade", Math.round(chatFadeDp()).coerceIn(0, 300))
    o.put("scale", Math.round(avatarScale() * 100f).coerceIn(35, 350))
    val ex = JSONArray()
    val k = avatar
    if (k != null) for (key in cfg.expressions.keys) {
        ex.put(JSONObject().put("k", key).put("n", Emotion.label(key)).put("on", k.anim.isExprHeld(key)))
    }
    o.put("expr", ex)
    val ms = JSONArray()
    for ((id, name) in models) ms.put(JSONObject().put("k", id).put("n", name).put("on", id == cfg.id))
    o.put("models", ms)
    val s = o.toString()
    if (s == lastState) return
    lastState = s
    js("state($s)")
}

/** Daerah milik chat (tombol / menu / balon) yang dilaporkan halaman (piksel CSS) diubah ke piksel layar. */
internal fun ChatActivity.applyLayout(json: String) {
    try {
        val o = JSONObject(json)
        val cssW = o.getDouble("w").toFloat()
        if (cssW <= 0f || web.width <= 0) return
        val k = web.width / cssW
        fun rects(name: String): FloatArray {
            val a = o.getJSONArray(name)
            val out = FloatArray(a.length() * 5)
            for (i in 0 until a.length()) {
                val r = a.getJSONArray(i)
                for (j in 0 until 5) out[i * 5 + j] = r.getDouble(j).toFloat() * k
            }
            return out
        }
        hitRects = rects("hit")
        backCallback.isEnabled = o.getBoolean("overlay") || bgEditing
    } catch (_: Throwable) {
    }
}

/** Fungsi yang dipanggil halaman chat. Dipanggil di thread WebView, jadi semua dipindah ke thread utama. */
internal class ChatBridge(private val a: ChatActivity) {
    private fun ui(f: ChatActivity.() -> Unit) {
        a.runOnUiThread { if (!a.isDestroyed) a.f() }
    }

    @JavascriptInterface fun ready() = ui { onWebReady() }
    @JavascriptInterface fun layout(json: String) = ui { applyLayout(json) }

    @JavascriptInterface fun send(text: String) = ui { submit(text) }
    @JavascriptInterface fun stop() = ui { stopReply() }
    @JavascriptInterface fun mic() = ui { onMic() }
    @JavascriptInterface fun micLong() = ui {
        web.performHapticFeedback(HapticFeedbackConstants.LONG_PRESS, HapticFeedbackConstants.FLAG_IGNORE_VIEW_SETTING)
        onMicLong()
    }

    @JavascriptInterface fun bg() = ui { showBgMenu() }
    @JavascriptInterface fun explain() = ui { explainPage() }
    @JavascriptInterface fun clear() = ui { clearChat() }
    @JavascriptInterface fun voice() = ui { toggleVoice() }
    @JavascriptInterface fun speak(id: Int) = ui { messageById(id)?.let { if (!it.isUser && it.text.isNotBlank()) speakMsg(it) } }
    @JavascriptInterface fun copy(id: Int) = ui {
        val m = messageById(id) ?: return@ui
        val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        cm.setPrimaryClip(ClipData.newPlainText("chat", m.text))
        web.performHapticFeedback(HapticFeedbackConstants.LONG_PRESS, HapticFeedbackConstants.FLAG_IGNORE_VIEW_SETTING)
        Toast.makeText(this, "Disalin", Toast.LENGTH_SHORT).show()
    }

    @JavascriptInterface fun avatarToggle() = ui { toggleAvatar() }
    @JavascriptInterface fun bubbleToggle() = ui { toggleBubbles() }
    @JavascriptInterface fun expr(key: String, on: Boolean) = ui {
        avatar?.anim?.setExprHold(key, on)
        pushState()
    }
    @JavascriptInterface fun scale(percent: Int) = ui { setAvatarScale(percent / 100f) }
    @JavascriptInterface fun fade(line: Int, length: Int) = ui { setChatFade(line / 100f, length.toFloat()) }
    @JavascriptInterface fun resetAvatar() = ui { resetAvatarView() }
    @JavascriptInterface fun model(id: String) = ui { if (models.any { it.first == id }) switchModel(id) }

    // Prompt: hanya membaca / menulis SharedPreferences, aman dari thread mana pun.
    @JavascriptInterface fun prompt(): String = PromptSlots.toJson(a)
    @JavascriptInterface fun profile(key: String, value: String) = PromptSlots.setProfile(a, key, value)
    @JavascriptInterface fun slotOn(key: String, on: Boolean) = PromptSlots.setOn(a, key, on)
    @JavascriptInterface fun slotText(key: String, text: String) = PromptSlots.setText(a, key, text)
    @JavascriptInterface fun resetSlots() = PromptSlots.reset(a)
}
