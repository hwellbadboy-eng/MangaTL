package com.niven.mangatl

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.OpenableColumns
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

/** Layar Manga Translator: pilih halaman/CBZ, proses otomatis, baca hasil, ekspor CBZ. */
class MangaActivity : AppCompatActivity() {

    private val prefs by lazy { getSharedPreferences("mangatl", MODE_PRIVATE) }
    private lateinit var etTitle: EditText
    private lateinit var tvStatus: TextView
    private lateinit var progress: ProgressBar
    private lateinit var btnPick: TextView
    private lateinit var btnCancel: TextView
    private lateinit var btnFont: TextView
    private lateinit var listBox: LinearLayout

    private val fontFiles = arrayOf("ComicRelief-Bold.ttf", "ComicNeue-Bold.ttf", "Bangers-Regular.ttf", "system")
    private val fontLabels = arrayOf("Comic Relief Bold", "Comic Neue Bold", "Bangers (dekoratif)", "Font bawaan HP")
    private var job: Job? = null
    private var lang = 0

    private val picker = registerForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
        if (uris.isNotEmpty()) {
            tvStatus.text = "Memeriksa ${uris.size} file..."
            startImport(uris)
        }
    }

    private fun dp(v: Int) = Ui.dp(this, v)

    private fun button(text: String, hero: Boolean): TextView = TextView(this).apply {
        this.text = text
        gravity = Gravity.CENTER
        textSize = 15f
        setTypeface(typeface, android.graphics.Typeface.BOLD)
        setTextColor(if (hero) 0xFF09090A.toInt() else 0xFFFFFFFF.toInt())
        setBackgroundResource(if (hero) R.drawable.bg_hero else R.drawable.bg_tile)
        isClickable = true
        layoutParams = LinearLayout.LayoutParams(-1, dp(52)).apply { topMargin = dp(10) }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        lang = prefs.getInt("manga_lang", 0).coerceIn(0, MangaEngine.LANG_LABELS.size - 1)

        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(16), dp(16), dp(24))
        }
        col.addView(TextView(this).apply {
            text = "Manga Translator"; textSize = 22f; setTextColor(0xFFFFFFFF.toInt())
            setTypeface(typeface, android.graphics.Typeface.BOLD)
        })
        col.addView(TextView(this).apply {
            text = "Gambar / CBZ / ZIP → baca teks → terjemah Indonesia (Gemma) → hasil bisa dibaca offline. Gaya bahasa & glosarium ikut Opsi layar utama."
            textSize = 13f; setTextColor(getColor(R.color.muted)); setPadding(0, dp(4), 0, dp(8))
        })
        col.addView(Ui.section(this, "Bahasa asli"))
        col.addView(Ui.radios(this, MangaEngine.LANG_LABELS, lang) { lang = it; prefs.edit().putInt("manga_lang", it).apply() })
        btnFont = button("Font terjemahan", false).also { b ->
            b.setOnClickListener { chooseFont() }
        }
        col.addView(btnFont)
        refreshFontButton()
        col.addView(Ui.section(this, "Judul (nama folder hasil)"))
        etTitle = EditText(this).apply {
            hint = "otomatis dari nama file"; setSingleLine(); setTextColor(0xFFFFFFFF.toInt())
            setHintTextColor(getColor(R.color.hint)); setBackgroundResource(R.drawable.bg_input_round)
            setPadding(dp(14), dp(10), dp(14), dp(10))
        }
        col.addView(etTitle)
        btnPick = button("Pilih halaman / CBZ", true).also { b ->
            b.setOnClickListener {
                if (job?.isActive == true) toast("Masih memproses...") else picker.launch(
                    arrayOf("*/*")
                )
            }
        }
        col.addView(btnPick)
        tvStatus = TextView(this).apply { text = "Siap."; textSize = 13f; setTextColor(getColor(R.color.muted)); setPadding(0, dp(10), 0, dp(4)) }
        col.addView(tvStatus)
        progress = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply { visibility = View.GONE }
        col.addView(progress)
        btnCancel = button("Batalkan", false).also { b -> b.visibility = View.GONE; b.setOnClickListener { job?.cancel() } }
        col.addView(btnCancel)
        col.addView(Ui.section(this, "Hasil terjemahan"))
        listBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        col.addView(listBox)

        setContentView(android.widget.ScrollView(this).apply { setBackgroundColor(getColor(R.color.bg)); addView(col) })
        Fx.enter(this)
    }

    override fun onResume() {
        super.onResume()
        refreshList()
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()

    private fun selectedFontIndex(): Int {
        val selected = getSharedPreferences("manga", MODE_PRIVATE)
            .getString("font", "ComicRelief-Bold.ttf") ?: "ComicRelief-Bold.ttf"
        return fontFiles.indexOf(selected).takeIf { it >= 0 } ?: 0
    }

    private fun refreshFontButton() {
        if (!::btnFont.isInitialized) return
        btnFont.text = "Font terjemahan: ${fontLabels[selectedFontIndex()]}  ▾"
    }

    private fun chooseFont() {
        val current = selectedFontIndex()
        AlertDialog.Builder(this)
            .setTitle("Pilih font hasil terjemahan")
            .setSingleChoiceItems(fontLabels, current) { dialog, which ->
                getSharedPreferences("manga", MODE_PRIVATE).edit()
                    .putString("font", fontFiles[which]).apply()
                MangaEngine.initFonts(applicationContext)
                refreshFontButton()
                toast("Font diubah. Proses ulang halaman agar hasil lama ikut berubah.")
                dialog.dismiss()
            }
            .setNegativeButton("Tutup", null)
            .show()
    }


    private fun setBusy(b: Boolean) {
        btnCancel.visibility = if (b) View.VISIBLE else View.GONE
        progress.visibility = if (b) View.VISIBLE else View.GONE
        if (b) window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        else window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        if (!b) refreshList()
    }

    private fun nameOf(uri: Uri): String = try {
        contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use {
            if (it.moveToFirst()) it.getString(0) else null
        } ?: uri.lastPathSegment ?: "file"
    } catch (_: Throwable) { uri.lastPathSegment ?: "file" }

    private fun startImport(uris: List<Uri>) {
        if (job?.isActive == true) return
        val all = uris.map { Pair(it, nameOf(it)) }
        val named = all.filter { p ->
            val n = p.second.lowercase()
            MangaEngine.isImageName(n) || n.endsWith(".zip") || n.endsWith(".cbz")
        }.sortedWith { a, b -> MangaEngine.naturalCompare(a.second, b.second) }
        if (named.isEmpty()) {
            tvStatus.text = "File tidak didukung: ${all.first().second}. Pakai gambar (jpg/png/webp), .cbz, atau .zip."
            return
        }
        var title = etTitle.text.toString().trim()
        if (title.isEmpty()) title = named.first().second.substringBeforeLast('.')
        title = title.replace(Regex("[\\\\/:*?\"<>|]"), "_").take(60).ifBlank { "Manga" }
        val work = File(MangaEngine.root(this), title)
        val src = MangaEngine.srcDir(work)
        job = lifecycleScope.launch {
            setBusy(true)
            try {
                val model = Gemma.findModel(this@MangaActivity)
                if (model == null) {
                    tvStatus.text = "Model .litertlm belum ada. Salin ke:\n${getExternalFilesDir(null)}"
                    return@launch
                }
                tvStatus.text = "Menyalin halaman..."
                val total = withContext(Dispatchers.IO) {
                    src.mkdirs()
                    val base = (src.listFiles()?.mapNotNull { it.name.take(3).toIntOrNull() }?.maxOrNull() ?: -1) + 1
                    var n = 0
                    named.forEachIndexed { i, (u, nm) -> n += MangaEngine.importUri(this@MangaActivity, work, u, nm, base + i) }
                    File(work, "lang.txt").writeText(lang.toString())
                    n
                }
                if (total == 0) { tvStatus.text = "Tidak ada gambar (jpg/png/webp) ditemukan."; return@launch }
                process(work, model)
            } catch (e: CancellationException) {
                tvStatus.text = "Dibatalkan. Halaman yang sudah jadi tersimpan; lanjutkan lewat tahan daftar hasil."
            } catch (t: Throwable) {
                tvStatus.text = "Gagal: ${t::class.java.simpleName}: ${t.message}"
            } finally { setBusy(false) }
        }
    }

    private fun resume(work: File) {
        if (job?.isActive == true) { toast("Masih memproses..."); return }
        job = lifecycleScope.launch {
            setBusy(true)
            try {
                val model = Gemma.findModel(this@MangaActivity)
                if (model == null) { tvStatus.text = "Model .litertlm belum ada."; return@launch }
                lang = File(work, "lang.txt").takeIf { it.exists() }?.readText()?.trim()?.toIntOrNull()
                    ?.coerceIn(0, MangaEngine.LANG_LABELS.size - 1) ?: lang
                process(work, model)
            } catch (e: CancellationException) {
                tvStatus.text = "Dibatalkan."
            } catch (t: Throwable) {
                tvStatus.text = "Gagal: ${t::class.java.simpleName}: ${t.message}"
            } finally { setBusy(false) }
        }
    }

    private suspend fun process(work: File, model: File) {
        val pages = MangaEngine.pages(work)
        val style = Gemma.Style.values()[prefs.getInt("style", 0).coerceIn(0, Gemma.Style.values().size - 1)]
        val glossary = prefs.getString("glossary", "") ?: ""
        val rec = MangaEngine.recognizer(lang)
        val srcName = MangaEngine.LANG_PROMPT[lang]
        MangaEngine.initFonts(applicationContext)
        progress.max = pages.size
        var failed = 0
        var streak = 0
        var lastErr = ""
        try {
            for ((i, f) in pages.withIndex()) {
                currentCoroutineContext().ensureActive()
                val out = MangaEngine.outFile(work, i)
                progress.progress = i
                if (out.exists()) continue
                val head = "Halaman ${i + 1}/${pages.size}: "
                tvStatus.text = head + "mulai..."
                try {
                    var timing = ""
                    val gemmaLog = StringBuffer()
                    val nb = withContext(Dispatchers.IO) {
                        MangaEngine.processPage(f, out, rec, lang,
                            translate = { lines ->
                                Gemma.translateComic(applicationContext, model, lines, srcName, style, glossary,
                                    onLog = { gemmaLog.append(it).append(" | ") }) { s ->
                                    runOnUiThread { tvStatus.text = head + s }
                                }
                            },
                            onStep = { s -> runOnUiThread { tvStatus.text = head + s } },
                            onTiming = { timing = it }, debugDir = File(work, "debug"))
                    }
                    streak = 0
                    try { File(MangaEngine.root(this@MangaActivity), "log.txt").appendText("halaman ${i + 1} (${f.name}): $nb blok teks, $timing | gemma: $gemmaLog\n") } catch (_: Throwable) {}
                    try { File(work, "blocks.txt").appendText("${i + 1} $nb\n") } catch (_: Throwable) {}
                } catch (e: CancellationException) {
                    throw e
                } catch (t: Throwable) {
                    failed++; streak++
                    lastErr = "${t::class.java.simpleName}: ${t.message}"
                    android.util.Log.e("BunnyManga", "halaman ${i + 1} gagal", t)
                    try { File(MangaEngine.root(this@MangaActivity), "log.txt").appendText("${f.name}: ${android.util.Log.getStackTraceString(t)}\n") } catch (_: Throwable) {}
                    tvStatus.text = head + "gagal: " + lastErr
                    if (streak >= 3) { tvStatus.text = "Berhenti: 3 halaman berturut-turut gagal. Error: $lastErr"; return }
                }
            }
            progress.progress = pages.size
            tvStatus.text = "Selesai: ${pages.size} halaman" + if (failed > 0) ". $failed gagal (belum dihitung selesai, bisa diulang lewat tahan judul > Lanjutkan proses). Error: $lastErr" else "."
        } finally {
            try { rec.close() } catch (_: Throwable) {}
        }
    }

    private fun refreshList() {
        listBox.removeAllViews()
        val dirs = MangaEngine.root(this).listFiles()?.filter { it.isDirectory }?.sortedByDescending { it.lastModified() } ?: emptyList()
        if (dirs.isEmpty()) {
            listBox.addView(TextView(this).apply { text = "Belum ada."; setTextColor(getColor(R.color.muted)); textSize = 13f })
            return
        }
        for (d in dirs) {
            val total = MangaEngine.pages(d).size
            val done = MangaEngine.doneCount(d)
            listBox.addView(TextView(this).apply {
                text = "${d.name}\n$done/$total halaman" + if (done < total) "  (belum selesai)" else ""
                textSize = 15f; setTextColor(0xFFFFFFFF.toInt()); setBackgroundResource(R.drawable.bg_card)
                setPadding(dp(14), dp(12), dp(14), dp(12)); isClickable = true
                layoutParams = LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(8) }
                setOnClickListener {
                    if (done > 0) startActivity(Intent(this@MangaActivity, MangaReaderActivity::class.java).putExtra("title", d.name))
                    else toast("Belum ada halaman jadi.")
                }
                setOnLongClickListener { menu(d, done < total); true }
            })
        }
    }

    private fun menu(d: File, canResume: Boolean) {
        val items = arrayListOf("Ekspor CBZ", "Tes halaman tertentu", "Proses ulang semua", "Ulang halaman tanpa terjemahan", "Hapus")
        if (canResume) items.add(0, "Lanjutkan proses")
        AlertDialog.Builder(this).setTitle(d.name).setItems(items.toTypedArray()) { _, w ->
            when (items[w]) {
                "Lanjutkan proses" -> resume(d)
                "Tes halaman tertentu" -> {
                    val et = EditText(this).apply { hint = "mis. 43,44 atau 40-45"; setSingleLine() }
                    AlertDialog.Builder(this).setTitle("Halaman yang diproses ulang").setView(et)
                        .setPositiveButton("Proses") { _, _ ->
                            val want = HashSet<Int>()
                            et.text.toString().split(",").forEach { part ->
                                val q = part.trim().split("-")
                                val a = q.getOrNull(0)?.trim()?.toIntOrNull()
                                val b = q.getOrNull(1)?.trim()?.toIntOrNull() ?: a
                                if (a != null && b != null) for (k in a..minOf(b, a + 200)) want.add(k)
                            }
                            var cnt = 0
                            for (i in MangaEngine.pages(d).indices) if ((i + 1) in want && MangaEngine.outFile(d, i).delete()) cnt++
                            if (cnt == 0) toast("Tidak ada halaman yang cocok.") else resume(d)
                        }.setNegativeButton("Batal", null).show()
                }
                "Proses ulang semua" -> { MangaEngine.outDir(d).deleteRecursively(); resume(d) }
                "Ulang halaman tanpa terjemahan" -> {
                    val bf = File(d, "blocks.txt")
                    if (!bf.exists()) toast("Belum ada catatan halaman. Pakai \"Proses ulang semua\" sekali dulu.") else {
                        val last = HashMap<Int, Int>()
                        bf.readLines().forEach { l ->
                            val q = l.trim().split(" ")
                            if (q.size == 2) { val a = q[0].toIntOrNull(); val b = q[1].toIntOrNull(); if (a != null && b != null) last[a] = b }
                        }
                        var cnt = 0
                        for (i in MangaEngine.pages(d).indices) if ((last[i + 1] ?: 0) == 0 && MangaEngine.outFile(d, i).delete()) cnt++
                        if (cnt == 0) toast("Semua halaman sudah punya terjemahan.") else resume(d)
                    }
                }
                "Ekspor CBZ" -> lifecycleScope.launch {
                    val target = File(MangaEngine.root(this@MangaActivity), d.name + ".cbz")
                    val n = withContext(Dispatchers.IO) { try { MangaEngine.exportCbz(d, target) } catch (_: Throwable) { -1 } }
                    toast(if (n >= 0) "CBZ ($n halaman): Android/data/com.niven.mangatl/files/manga/${target.name}" else "Ekspor gagal.")
                }
                "Hapus" -> AlertDialog.Builder(this).setMessage("Hapus \"${d.name}\" beserta hasilnya?")
                    .setPositiveButton("Hapus") { _, _ -> d.deleteRecursively(); refreshList() }
                    .setNegativeButton("Batal", null).show()
            }
        }.show()
    }
}
