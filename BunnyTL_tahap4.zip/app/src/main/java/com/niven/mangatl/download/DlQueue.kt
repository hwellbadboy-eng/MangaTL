package com.niven.mangatl

import android.content.ContentValues
import android.content.Context
import android.media.MediaScannerConnection
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.provider.MediaStore
import android.util.Log
import com.yausername.youtubedl_android.YoutubeDL
import com.yausername.youtubedl_android.YoutubeDLRequest
import java.io.File
import java.io.IOException
import java.util.Locale
import java.util.UUID
import java.util.concurrent.CopyOnWriteArrayList
import java.util.concurrent.Executors

/** Satu unduhan. Field diubah dari thread latar, dibaca dari UI. */
class DlTask(
    val url: String,
    val title: String,
    val audio: Boolean,
    /** Pemilih format yt-dlp (-f) untuk video. */
    val selector: String,
    /** true = keluaran MP4, false = MKV (video). */
    val mp4: Boolean,
    /** 0 = MP3, 1 = M4A, 2 = Opus (musik). */
    val audioFmt: Int,
    /** Video: bahasa subtitle yang disematkan (kosong = tanpa subtitle). */
    val subs: List<String> = emptyList(),
    /** true = subtitle otomatis (subs berisi satu bahasa). */
    val autoSubs: Boolean = false,
    /** Musik: cari lirik di LRCLIB setelah tersimpan. */
    val lyrics: Boolean = false,
    val artist: String = "",
    val track: String = "",
    val durationSec: Long = 0,
    /** Urutan pilihan format yt-dlp (-S), dipakai playlist untuk "sampai N p". Kosong = tidak dipakai. */
    val sort: String = "",
    /** Musik: potong cover jadi persegi. */
    val square: Boolean = false
) {
    enum class State { QUEUED, RUNNING, DONE, FAILED, CANCELED }

    val id: String = UUID.randomUUID().toString().take(8)

    @Volatile var state: State = State.QUEUED
    @Volatile var progress: Float = 0f
    @Volatile var eta: Long = 0L
    @Volatile var note: String = ""
    @Volatile var error: String? = null
    @Volatile var result: Uri? = null

    val active: Boolean get() = state == State.QUEUED || state == State.RUNNING

    fun fresh() = DlTask(url, title, audio, selector, mp4, audioFmt, subs, autoSubs, lyrics, artist, track, durationSec, sort, square)
}

/** Antrean unduhan di dalam proses (satu per satu). Servis hanya menjaga proses tetap hidup. */
object DlQueue {
    private const val TAG = "DlQueue"

    val tasks = CopyOnWriteArrayList<DlTask>()
    private val listeners = CopyOnWriteArrayList<() -> Unit>()
    private val main = Handler(Looper.getMainLooper())
    private val exec = Executors.newSingleThreadExecutor()

    @Volatile private var lastNotify = 0L

    fun addListener(l: () -> Unit) { listeners.add(l) }
    fun removeListener(l: () -> Unit) { listeners.remove(l) }

    /** Beri tahu UI. Progres dibatasi ~2,5x/detik; perubahan status selalu dikirim (force). */
    fun changed(force: Boolean = false) {
        val now = SystemClock.uptimeMillis()
        if (!force && now - lastNotify < 400) return
        lastNotify = now
        main.post { listeners.forEach { it() } }
    }

    fun hasActive() = tasks.any { it.active }

    fun enqueue(ctx: Context, task: DlTask) {
        val app = ctx.applicationContext
        tasks.add(0, task)
        DlService.start(app)
        changed(true)
        exec.execute { run(app, task) }
    }

    fun retry(ctx: Context, task: DlTask) {
        tasks.remove(task)
        enqueue(ctx, task.fresh())
    }

    fun cancel(id: String) {
        val t = tasks.firstOrNull { it.id == id } ?: return
        when (t.state) {
            DlTask.State.QUEUED -> t.state = DlTask.State.CANCELED
            DlTask.State.RUNNING -> {
                t.state = DlTask.State.CANCELED
                runCatching { YoutubeDL.destroyProcessById(id) }
            }
            else -> return
        }
        changed(true)
    }

    fun remove(task: DlTask) {
        if (task.active) return
        tasks.remove(task)
        changed(true)
    }

    private fun run(ctx: Context, t: DlTask) {
        if (t.state == DlTask.State.CANCELED) { changed(true); return }
        t.state = DlTask.State.RUNNING
        t.note = "Menyiapkan mesin…"
        changed(true)
        val dir = File(ctx.getExternalFilesDir(null) ?: ctx.filesDir, "dl/${t.id}")
        try {
            DlEngine.ensureReady(ctx)
            dir.mkdirs()
            t.note = "Mengunduh…"
            changed(true)
            var square = t.audio && t.square && t.audioFmt != 2
            while (true) {
                try {
                    YoutubeDL.getInstance().execute(DlCommands.download(ctx, t, dir, square), t.id) { p, eta, _ ->
                        if (p >= 0f) { t.progress = p; t.eta = eta }
                        changed()
                    }
                    break
                } catch (e: Exception) {
                    // Crop cover memakai filter ffmpeg; kalau pascaproses gagal, ulang sekali tanpa crop.
                    val m = e.message.orEmpty()
                    val ppFail = m.contains("postprocess", true) || m.contains("ffmpeg", true)
                    if (square && ppFail && t.state != DlTask.State.CANCELED && e !is YoutubeDL.CanceledException) {
                        square = false
                        t.note = "Mengulang tanpa crop cover…"
                        changed(true)
                    } else throw e
                }
            }
            if (t.state == DlTask.State.CANCELED) return
            t.note = "Menyimpan…"
            changed(true)
            val file = DlCommands.pickOutput(dir, t.audio)
                ?: throw IOException("File hasil unduhan tidak ditemukan.")
            val saved = DlStore.publish(ctx, file, t.audio)
            t.result = saved
            if (t.audio && t.lyrics && t.state != DlTask.State.CANCELED) {
                t.note = "Mencari lirik…"
                changed(true)
                DlLyrics.fetchAndSave(ctx, t, saved) // gagal/tak ketemu = lagu tetap tersimpan tanpa lirik
            }
            t.progress = 100f
            t.state = DlTask.State.DONE
        } catch (th: Throwable) {
            if (t.state == DlTask.State.CANCELED || th is YoutubeDL.CanceledException) {
                t.state = DlTask.State.CANCELED
            } else {
                Log.w(TAG, "unduhan gagal", th)
                t.error = DlEngine.friendlyError(th)
                t.state = DlTask.State.FAILED
            }
        } finally {
            runCatching { dir.deleteRecursively() }
            changed(true)
            DlNotify.finished(ctx, t)
        }
    }
}

/** Menyusun perintah yt-dlp. */
object DlCommands {
    private val AUDIO_EXT = setOf("mp3", "m4a", "opus", "ogg", "aac", "flac", "wav", "webm", "mka")
    private val VIDEO_EXT = setOf("mp4", "mkv", "webm", "mov", "avi", "flv", "m4v")

    /** Ambil info + daftar format satu link (tanpa unduh). */
    fun fetch(ctx: Context, url: String): YoutubeDLRequest = YoutubeDLRequest(url).apply {
        addOption("--dump-single-json")
        addOption("--flat-playlist") // hanya berpengaruh ke playlist: daftar ringkas, tidak membuka tiap item
        addOption("--no-playlist")
        addOption("--no-warnings")
        addOption("-R", "1")
        addOption("--socket-timeout", "10")
        DlCookies.apply(ctx, this)
    }

    fun download(ctx: Context, t: DlTask, dir: File, square: Boolean): YoutubeDLRequest = YoutubeDLRequest(t.url).apply {
        DlCookies.apply(ctx, this)
        addOption("--no-playlist")
        addOption("--no-mtime")
        addOption("-P", dir.absolutePath)
        addOption("-o", "%(title)s.%(ext)s")
        addOption("--trim-filenames", "120")
        addOption("-R", "3")
        addOption("--socket-timeout", "15")
        addOption("--concurrent-fragments", "4")
        addOption("--embed-metadata")
        if (t.audio) {
            addOption("-x")
            when (t.audioFmt) {
                0 -> {
                    addOption("-f", "bestaudio/best")
                    addOption("--audio-format", "mp3")
                    addOption("--audio-quality", "0")
                }
                1 -> {
                    addOption("-f", "bestaudio[ext=m4a]/bestaudio/best")
                    addOption("--audio-format", "m4a")
                }
                else -> {
                    addOption("-f", "bestaudio[ext=webm]/bestaudio/best")
                    addOption("--audio-format", "opus")
                }
            }
            // Cover hanya untuk MP3/M4A (Opus butuh mutagen yang tidak ada di mesin ini).
            if (t.audioFmt != 2) {
                addOption("--embed-thumbnail")
                addOption("--convert-thumbnails", "jpg")
                if (square) {
                    val conf = File(dir, "crop.conf")
                    conf.writeText(DlConfig.CROP_ARTWORK)
                    addOption("--config-locations", conf.absolutePath)
                }
            }
        } else {
            addOption("-f", t.selector)
            if (t.sort.isNotEmpty()) addOption("-S", t.sort)
            addOption("--merge-output-format", if (t.mp4) "mp4" else "mkv")
            addOption("--embed-chapters")
            if (t.subs.isNotEmpty()) {
                addOption(if (t.autoSubs) "--write-auto-subs" else "--write-subs")
                addOption("--sub-langs", t.subs.joinToString(","))
                addOption("--convert-subs", "srt")
                addOption("--embed-subs")
            }
        }
    }

    /** File media terbesar di folder kerja unduhan (abaikan .part, gambar, json, dll). */
    fun pickOutput(dir: File, audio: Boolean): File? {
        val ok = if (audio) AUDIO_EXT else VIDEO_EXT
        return dir.listFiles()
            ?.filter { it.isFile && it.extension.lowercase(Locale.ROOT) in ok }
            ?.maxByOrNull { it.length() }
    }
}

/** Menaruh hasil ke Music/BunnyTL atau Movies/BunnyTL lewat MediaStore, jadi langsung muncul di pemutar BunnyTL. */
object DlStore {
    private fun mime(ext: String, audio: Boolean): String = when (ext) {
        "mp3" -> "audio/mpeg"
        "m4a", "aac" -> "audio/mp4"
        "opus", "ogg" -> "audio/ogg"
        "flac" -> "audio/flac"
        "wav" -> "audio/x-wav"
        "mp4", "m4v" -> "video/mp4"
        "mkv" -> "video/x-matroska"
        "webm" -> if (audio) "audio/webm" else "video/webm"
        "mov" -> "video/quicktime"
        else -> if (audio) "audio/*" else "video/*"
    }

    fun folderLabel(audio: Boolean) = if (audio) "Music/BunnyTL" else "Movies/BunnyTL"

    fun publish(ctx: Context, file: File, audio: Boolean): Uri {
        val mime = mime(file.extension.lowercase(Locale.ROOT), audio)
        if (Build.VERSION.SDK_INT >= 29) {
            val cr = ctx.contentResolver
            val coll = if (audio) MediaStore.Audio.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY)
            else MediaStore.Video.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY)
            val cv = ContentValues().apply {
                put(MediaStore.MediaColumns.DISPLAY_NAME, file.name)
                put(MediaStore.MediaColumns.MIME_TYPE, mime)
                put(MediaStore.MediaColumns.RELATIVE_PATH, folderLabel(audio))
                put(MediaStore.MediaColumns.IS_PENDING, 1)
                if (audio) put(MediaStore.Audio.Media.IS_MUSIC, 1)
            }
            val uri = cr.insert(coll, cv) ?: throw IOException("Gagal membuat berkas di penyimpanan.")
            try {
                val out = cr.openOutputStream(uri) ?: throw IOException("Gagal membuka berkas tujuan.")
                out.use { o -> file.inputStream().use { it.copyTo(o, 256 * 1024) } }
                val done = ContentValues().apply { put(MediaStore.MediaColumns.IS_PENDING, 0) }
                cr.update(uri, done, null, null)
            } catch (e: Exception) {
                runCatching { cr.delete(uri, null, null) }
                throw e
            }
            return uri
        }
        // Android 8-9: tulis langsung ke folder publik (izin WRITE_EXTERNAL_STORAGE).
        val base = Environment.getExternalStoragePublicDirectory(
            if (audio) Environment.DIRECTORY_MUSIC else Environment.DIRECTORY_MOVIES
        )
        val dir = File(base, "BunnyTL").apply { mkdirs() }
        var dest = File(dir, file.name)
        var n = 1
        while (dest.exists()) {
            dest = File(dir, "${file.nameWithoutExtension} ($n).${file.extension}")
            n++
        }
        file.copyTo(dest)
        MediaScannerConnection.scanFile(ctx, arrayOf(dest.absolutePath), arrayOf(mime), null)
        return Uri.fromFile(dest)
    }
}

/** Cari lirik (bertanda waktu kalau ada) di LRCLIB lalu simpan ke penyimpanan lirik BunnyTL, jadi tampil di layar lirik pemutar. */
object DlLyrics {
    private const val TAG = "DlLyrics"

    private fun clean(s: String) = s
        .replace(Regex("\\(.*?\\)|\\[.*?]|【.*?】"), " ")
        .replace(Regex("(?i)\\b(official|music video|lyric video|lyrics|audio|mv|hd|4k)\\b"), " ")
        .replace(Regex("\\s+"), " ").trim()

    private fun get(url: String): String? {
        val c = java.net.URL(url).openConnection() as java.net.HttpURLConnection
        return try {
            c.connectTimeout = 8000
            c.readTimeout = 8000
            c.setRequestProperty("User-Agent", "BunnyTL/0.7")
            if (c.responseCode != 200) null else c.inputStream.bufferedReader().readText()
        } finally {
            c.disconnect()
        }
    }

    fun fetchAndSave(ctx: Context, t: DlTask, uri: Uri) {
        runCatching {
            val id = android.content.ContentUris.parseId(uri)
            var artist = t.artist
            var track = t.track
            if (track.isEmpty()) {
                val c = clean(t.title)
                if (artist.isEmpty() && c.contains(" - ")) {
                    artist = c.substringBefore(" - ").trim()
                    track = c.substringAfter(" - ").trim()
                } else track = c
            }
            val q = java.net.URLEncoder.encode("$artist $track".trim(), "UTF-8")
            val body = get("https://lrclib.net/api/search?q=$q") ?: return
            val arr = org.json.JSONArray(body)
            var plain: String? = null
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                val dur = o.optDouble("duration", 0.0)
                // durasi harus mirip (±6 dtk) supaya tidak salah lagu
                if (t.durationSec > 0 && dur > 0 && Math.abs(dur - t.durationSec) > 6) continue
                if (t.durationSec <= 0) continue
                val synced = o.optString("syncedLyrics", "")
                if (synced.isNotBlank() && synced != "null") {
                    Lyrics.save(ctx, id, synced)
                    return
                }
                val p = o.optString("plainLyrics", "")
                if (plain == null && p.isNotBlank() && p != "null") plain = p
            }
            plain?.let { Lyrics.save(ctx, id, it) }
        }.onFailure { Log.w(TAG, "lirik tidak diambil", it) }
    }
}
