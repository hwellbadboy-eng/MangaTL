package com.niven.mangatl

import android.content.Context
import android.util.Log
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.IOException
import java.io.PushbackInputStream
import java.net.ConnectException
import java.net.HttpURLConnection
import java.net.SocketTimeoutException
import java.net.URI
import java.net.URL
import java.net.UnknownHostException
import java.security.MessageDigest
import java.util.zip.ZipInputStream

/**
 * Pembaruan yt-dlp dari dalam app (diport dari SnapNet, tanpa OkHttp/serialization supaya APK tidak nambah).
 * File baru dicek SHA-256 dari rilis resmi GitHub, dites jalan, dan kalau gagal otomatis dikembalikan
 * ke versi sebelumnya (lalu ke salinan bawaan APK). Ukuran APK tidak berubah: file disimpan di data app.
 */
object DlUpdater {
    private const val TAG = "DlUpdater"
    private const val BINARY = "yt-dlp"
    private const val SUMS = "SHA2-256SUMS"
    private const val VERSION_ENTRY = "yt_dlp/version.py"
    private const val REPO = "yt-dlp/yt-dlp"

    enum class Result { UPDATED, ALREADY_UP_TO_DATE, FAILED_ROLLED_BACK, FAILED }

    /** Kode alasan singkat kalau gagal (untuk ditampilkan). */
    @Volatile var lastFailure: String? = null
        private set

    private fun installed(ctx: Context) = File(ctx.noBackupFilesDir, "youtubedl-android/yt-dlp/yt-dlp")

    private fun locate(ctx: Context): File? =
        File(ctx.noBackupFilesDir, "youtubedl-android").takeIf { it.isDirectory }
            ?.walkTopDown()?.firstOrNull { it.isFile && it.name == BINARY }

    private fun backupFile(ctx: Context) = File(File(ctx.noBackupFilesDir, "ytdlp-backup"), BINARY)

    private fun verify(file: File?): Boolean {
        if (file == null || !file.isFile || file.length() <= 0L) return false
        return runCatching { DlZipApp.readEntry(file, VERSION_ENTRY) != null }.getOrDefault(false)
    }

    private fun backup(ctx: Context, binary: File): Boolean = runCatching {
        val b = backupFile(ctx)
        b.parentFile?.mkdirs()
        binary.copyTo(b, overwrite = true)
        verify(b)
    }.getOrDefault(false)

    private fun rollback(ctx: Context): Boolean = runCatching {
        val b = backupFile(ctx)
        if (!verify(b)) return@runCatching false
        val target = locate(ctx) ?: installed(ctx)
        target.parentFile?.mkdirs()
        b.copyTo(target, overwrite = true)
        verify(target)
    }.getOrDefault(false)

    private fun open(url: String, accept: String): HttpURLConnection =
        (URL(url).openConnection() as HttpURLConnection).apply {
            connectTimeout = 15_000
            readTimeout = 60_000
            instanceFollowRedirects = true
            setRequestProperty("Accept", accept)
            setRequestProperty("User-Agent", "BunnyTL")
            setRequestProperty("X-GitHub-Api-Version", "2022-11-28")
        }

    private fun text(url: String, accept: String): String {
        val c = open(url, accept)
        try {
            if (c.responseCode !in 200..299) throw IOException("GitHub returned HTTP ${c.responseCode}")
            return c.inputStream.bufferedReader().use { it.readText() }
        } finally {
            c.disconnect()
        }
    }

    private fun fetch(url: String, dest: File) {
        val c = open(url, "application/octet-stream")
        try {
            if (c.responseCode !in 200..299) throw IOException("GitHub asset download failed with HTTP ${c.responseCode}")
            c.inputStream.use { input -> dest.outputStream().buffered().use { input.copyTo(it) } }
        } finally {
            c.disconnect()
        }
    }

    /** Ambil URL aset rilis dan pastikan benar-benar dari repo yt-dlp di github.com. */
    private fun assetUrl(release: JSONObject, name: String): String {
        val tag = release.optString("tag_name")
        if (tag.isBlank()) throw IOException("release has no tag")
        val assets = release.optJSONArray("assets") ?: throw IOException("release is missing the $name asset")
        var found: String? = null
        for (i in 0 until assets.length()) {
            val a = assets.optJSONObject(i) ?: continue
            if (a.optString("name") == name) {
                if (found != null) throw IOException("release has duplicate $name assets")
                found = a.optString("browser_download_url")
            }
        }
        val url = found?.takeIf { it.isNotBlank() } ?: throw IOException("release is missing the $name asset")
        val uri = runCatching { URI(url) }.getOrNull()
        val prefix = "/$REPO/releases/download/$tag/"
        if (uri?.scheme != "https" || uri.host != "github.com" ||
            uri.path?.startsWith(prefix) != true || uri.path?.substringAfterLast('/') != name
        ) throw IOException("release asset URL is not from the expected GitHub repository")
        return url
    }

    private fun diagnostic(e: Exception): String {
        val m = e.message.orEmpty()
        Regex("(?i)HTTP (\\d{3})").find(m)?.let { return "github_http_${it.groupValues[1]}" }
        return when {
            e is SocketTimeoutException -> "network_timeout"
            e is UnknownHostException -> "network_dns_failure"
            e is ConnectException -> "network_connection_failure"
            m.contains("checksum", true) -> "checksum_verification_failed"
            m.contains("release is missing", true) -> "release_asset_missing"
            e is IOException -> "io_error"
            else -> "update_error_${e.javaClass.simpleName.take(40)}"
        }
    }

    private fun failure(hadWorking: Boolean) = if (hadWorking) Result.FAILED_ROLLED_BACK else Result.FAILED

    private fun install(ctx: Context, asset: File): Boolean {
        val target = locate(ctx) ?: installed(ctx)
        val dir = target.parentFile ?: return false
        if (!dir.exists() && !dir.mkdirs()) return false
        val staged = File(dir, "$BINARY.new")
        val previous = File(dir, "$BINARY.previous")
        if (staged.exists() && !staged.delete()) return false
        if (previous.exists() && !previous.delete()) return false
        asset.copyTo(staged, overwrite = true)
        if (!verify(staged)) { staged.delete(); return false }
        val hadTarget = target.exists()
        if (hadTarget && !target.renameTo(previous)) { staged.delete(); return false }
        if (!staged.renameTo(target)) {
            if (hadTarget) previous.renameTo(target)
            staged.delete()
            return false
        }
        if (!verify(target)) {
            target.delete()
            if (hadTarget) previous.renameTo(target)
            return false
        }
        if (previous.exists()) previous.delete()
        return true
    }

    /** Blokir. Panggil dari thread latar, dan setelah DlEngine.ensureReady(). */
    fun update(ctx: Context): Result {
        lastFailure = null
        val prev = locate(ctx)
        val hadWorking = verify(prev)
        var downloaded: File? = null
        try {
            val release = JSONObject(text("https://api.github.com/repos/$REPO/releases/latest", "application/vnd.github+json"))
            val binaryUrl = assetUrl(release, BINARY)
            val sumsUrl = assetUrl(release, SUMS)
            val expected = DlChecksum.parseManifest(text(sumsUrl, "text/plain"), BINARY)
                ?: throw IOException("release checksum manifest has no unique yt-dlp digest")

            if (hadWorking && prev != null && DlChecksum.matches(prev, expected)) return Result.ALREADY_UP_TO_DATE

            if (hadWorking && prev != null && !backup(ctx, prev)) {
                lastFailure = "safety_backup_failed"
                return Result.FAILED_ROLLED_BACK
            }

            downloaded = File.createTempFile("yt-dlp-", ".download", ctx.cacheDir)
            fetch(binaryUrl, downloaded)
            if (!DlChecksum.matches(downloaded, expected)) {
                lastFailure = "checksum_mismatch"
                return failure(hadWorking)
            }
            if (!verify(downloaded)) {
                lastFailure = "engine_archive_invalid"
                return failure(hadWorking)
            }
            if (!install(ctx, downloaded)) {
                lastFailure = "install_failed"
                return if (hadWorking && rollback(ctx)) Result.FAILED_ROLLED_BACK else Result.FAILED
            }
            if (DlEngine.probe() == null) {
                Log.w(TAG, "yt-dlp baru gagal diuji, mengembalikan versi sebelumnya")
                var ok = hadWorking && rollback(ctx) && DlEngine.probe() != null
                if (!ok) ok = DlEngine.restoreBundled(ctx) && DlEngine.probe() != null
                lastFailure = if (ok) "runtime_probe_failed_restored_previous" else "runtime_probe_and_recovery_failed"
                return if (ok) Result.FAILED_ROLLED_BACK else Result.FAILED
            }
            DlEngine.refreshVersion()
            return Result.UPDATED
        } catch (e: Exception) {
            lastFailure = diagnostic(e)
            Log.w(TAG, "update gagal ($lastFailure)")
            return failure(hadWorking)
        } finally {
            downloaded?.delete()
        }
    }

    fun message(r: Result): String = when (r) {
        Result.UPDATED -> "Mesin unduh diperbarui (${DlEngine.version})."
        Result.ALREADY_UP_TO_DATE -> "Sudah versi terbaru (${DlEngine.version})."
        Result.FAILED_ROLLED_BACK -> "Pembaruan gagal (${lastFailure ?: "?"}); versi lama dipertahankan."
        Result.FAILED -> "Pembaruan gagal (${lastFailure ?: "?"})."
    }
}

/** Cek SHA-256 aset rilis yt-dlp. */
internal object DlChecksum {
    private val line = Regex("^([0-9a-fA-F]{64})\\s+\\*?(.+?)\\s*$")

    fun parseManifest(manifest: String, name: String): String? =
        manifest.lineSequence().mapNotNull { l ->
            val m = line.matchEntire(l.trim()) ?: return@mapNotNull null
            if (m.groupValues[2] == name) m.groupValues[1].lowercase() else null
        }.toList().singleOrNull()

    fun sha256(file: File): String {
        val d = MessageDigest.getInstance("SHA-256")
        file.inputStream().buffered().use { input ->
            val buf = ByteArray(DEFAULT_BUFFER_SIZE)
            while (true) {
                val n = input.read(buf)
                if (n < 0) break
                d.update(buf, 0, n)
            }
        }
        return d.digest().joinToString("") { (it.toInt() and 0xff).toString(16).padStart(2, '0') }
    }

    fun matches(file: File, expected: String): Boolean {
        if (!file.isFile || !expected.matches(Regex("[0-9a-fA-F]{64}"))) return false
        return runCatching { sha256(file).equals(expected, ignoreCase = true) }.getOrDefault(false)
    }
}

/** Baca satu entri dari zipapp Python (yt-dlp) yang bisa diawali shebang. */
internal object DlZipApp {
    private const val MAX_PREAMBLE = 4096
    private const val MAX_ENTRY = 64 * 1024
    private val SIG = byteArrayOf(0x50, 0x4b, 0x03, 0x04)

    fun readEntry(file: File, entryName: String): ByteArray? {
        val input = PushbackInputStream(file.inputStream().buffered(), SIG.size)
        if (!seek(input)) { input.close(); return null }
        return ZipInputStream(input).use { zip ->
            var e = zip.nextEntry
            var content: ByteArray? = null
            while (e != null && content == null) {
                if (e.name == entryName) content = readCurrent(zip) else { zip.closeEntry(); e = zip.nextEntry }
            }
            content
        }
    }

    private fun seek(input: PushbackInputStream): Boolean {
        var p1 = -1; var p2 = -1; var p3 = -1
        var scanned = 0
        while (scanned < MAX_PREAMBLE + SIG.size) {
            val n = input.read()
            if (n == -1) return false
            scanned++
            if (p1 == (SIG[0].toInt() and 0xff) && p2 == (SIG[1].toInt() and 0xff) &&
                p3 == (SIG[2].toInt() and 0xff) && n == (SIG[3].toInt() and 0xff)
            ) { input.unread(SIG); return true }
            p1 = p2; p2 = p3; p3 = n
        }
        return false
    }

    private fun readCurrent(zip: ZipInputStream): ByteArray {
        val out = ByteArrayOutputStream()
        val buf = ByteArray(4096)
        var total = 0
        while (true) {
            val n = zip.read(buf)
            if (n == -1) break
            if (total + n > MAX_ENTRY) throw IOException("yt-dlp version entry exceeds the size limit")
            out.write(buf, 0, n)
            total += n
        }
        return out.toByteArray()
    }
}
