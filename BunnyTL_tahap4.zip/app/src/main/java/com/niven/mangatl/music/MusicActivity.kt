package com.niven.mangatl

import android.annotation.SuppressLint
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.Editable
import android.text.TextWatcher
import android.view.MotionEvent
import android.view.View
import android.view.ViewOutlineProvider
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat
import androidx.core.view.ViewCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.media3.ui.PlayerView
import androidx.lifecycle.lifecycleScope
import androidx.media3.common.Player
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import com.google.common.util.concurrent.ListenableFuture
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlin.math.abs
import kotlin.math.max
import kotlin.random.Random

/**
 * Layar Musik (desain "Versi 3"): daftar melengkung dengan cari cepat di tepi, tab teks, mini player
 * dengan garis seek di atas. Tab (Lagu/Album/Artis/Folder/Playlist) bisa disembunyikan & diurutkan ulang
 * lewat pengaturan. Tombol urutkan: nama, tanggal, durasi (naik/turun).
 */
class MusicActivity : MediaActivity() {

    override val kind = 1
    override fun deniedView(): TextView = tvEmpty

    internal lateinit var wheel: MusicWheelView
    private lateinit var pillNow: TextView
    internal lateinit var etSearch: EditText
    private lateinit var searchRow: View
    private lateinit var tvTitle: TextView
    private lateinit var tvPlLabel: TextView
    internal lateinit var tvBannerLabel: TextView
    private lateinit var topButtons: View
    internal lateinit var bgGlow: View
    internal lateinit var bannerLayer: View
    private lateinit var fade: View
    internal lateinit var tabScroll: View
    private lateinit var tabsBox: LinearLayout
    internal lateinit var tvEmpty: TextView
    internal lateinit var drillBar: View
    internal lateinit var tvDrill: TextView
    private lateinit var mini: View
    private lateinit var swipeInner: View
    private lateinit var tvNow: TextView
    private lateinit var tvArtist: TextView
    private lateinit var ivMini: ImageView
    private lateinit var btnMiniPlay: ImageButton
    private lateinit var seek: SeekLine
    private lateinit var timeRow: View
    private lateinit var tvElapsed: TextView
    private lateinit var tvTotal: TextView
    private lateinit var settingsPop: View
    private lateinit var popScrim: View
    private lateinit var swVideo: PillSwitch
    private lateinit var swCurve: PillSwitch
    private lateinit var swSide: PillSwitch
    private lateinit var backCb: OnBackPressedCallback
    internal lateinit var banner: Banner
    private var statusTop = 0
    private var navBottom = 0
    internal var onBannerChange: (() -> Unit)? = null
    private var searchOpen = false
    private var popOpen = false
    private var tabIndex = 0

    internal val pickBanner = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            Toast.makeText(this, "Menyalin banner...", Toast.LENGTH_SHORT).show()
            updateBannerAspect()
            banner.importFile(uri) { err ->
                if (err != null) Toast.makeText(this, err, Toast.LENGTH_LONG).show()
                applyBanner()
                onBannerChange?.invoke()
                if (banner.has() && err?.startsWith("Maju") != false) positionDialog()
            }
        }
    }

    internal var tracks: List<Library.Track> = emptyList()
    internal var albums: List<Library.Group> = emptyList()
    internal var artists: List<Library.Group> = emptyList()
    internal var folders: List<Library.Group> = emptyList()
    private val byId = HashMap<Long, Library.Track>()
    internal var drill: Drill? = null

    /** Filter playlist di tab Lagu: null = Semua lagu, PL_FAV = Favorit, selain itu nama playlist. */
    internal var plSel: String? = null
    internal var loaded = false
    private var visibleIds: List<Int> = listOf(0)
    private var sortMode = 0

    private var future: ListenableFuture<MediaController>? = null
    internal var controller: MediaController? = null
    private val handler = Handler(Looper.getMainLooper())
    private val tick = object : Runnable {
        override fun run() {
            updateProgress()
            handler.postDelayed(this, 500)
        }
    }

    internal val pickLyricsFolder = registerForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri ->
        if (uri != null) {
            try {
                contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
            } catch (e: Exception) {
            }
            Prefs.setStr(this, "lyrics_tree", uri.toString())
            Lyrics.resetIndex()
            Toast.makeText(this, "Folder lirik dipilih.", Toast.LENGTH_SHORT).show()
        }
    }

    internal fun curTab(): Int = visibleIds.getOrElse(tabIndex) { 0 }

    @SuppressLint("ClickableViewAccessibility")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        window.statusBarColor = android.graphics.Color.TRANSPARENT
        setContentView(R.layout.activity_music)
        Fx.enter(this)

        bannerLayer = findViewById(R.id.bannerLayer)
        // video/foto yang diperbesar tidak boleh bocor ke bawah batas banner
        bannerLayer.outlineProvider = ViewOutlineProvider.BOUNDS
        bannerLayer.clipToOutline = true
        banner = Banner(
            this,
            findViewById<PlayerView>(R.id.bnVideo),
            findViewById<ImageView>(R.id.bnImage),
            bannerLayer
        )

        wheel = findViewById(R.id.wheel)
        etSearch = findViewById(R.id.etSearch)
        searchRow = findViewById(R.id.searchRow)
        tvTitle = findViewById(R.id.tvMusicTitle)
        tvPlLabel = findViewById(R.id.tvPlLabel)
        tvBannerLabel = findViewById(R.id.tvBannerLabel)
        topButtons = findViewById(R.id.topButtons)
        bgGlow = findViewById(R.id.bgGlow)
        fade = findViewById(R.id.fade)
        tabScroll = findViewById(R.id.tabScroll)
        tabsBox = findViewById(R.id.tabsBox)
        tvEmpty = findViewById(R.id.tvEmpty)
        drillBar = findViewById(R.id.drillBar)
        tvDrill = findViewById(R.id.tvDrill)
        mini = findViewById(R.id.mini)
        swipeInner = findViewById(R.id.swipeInner)
        tvNow = findViewById(R.id.tvNow)
        tvArtist = findViewById(R.id.tvArtist)
        ivMini = findViewById(R.id.ivMini)
        btnMiniPlay = findViewById(R.id.btnMiniPlay)
        seek = findViewById(R.id.seek)
        timeRow = findViewById(R.id.timeRow)
        tvElapsed = findViewById(R.id.tvElapsed)
        tvTotal = findViewById(R.id.tvTotal)
        settingsPop = findViewById(R.id.settingsPop)
        popScrim = findViewById(R.id.popScrim)
        swVideo = findViewById(R.id.swVideo)
        swCurve = findViewById(R.id.swCurve)
        swSide = findViewById(R.id.swSide)
        sortMode = Prefs.int(this, "sort_music", 0)

        // huruf desain
        tvTitle.typeface = MusicFonts.face(this, 800)
        tvPlLabel.typeface = MusicFonts.face(this, 600)
        tvBannerLabel.typeface = MusicFonts.face(this, 600)
        etSearch.typeface = MusicFonts.face(this, 600)
        tvNow.typeface = MusicFonts.face(this, 700)
        tvArtist.typeface = MusicFonts.face(this, 400)
        tvDrill.typeface = MusicFonts.face(this, 700)

        // daftar melengkung
        wheel.scope = lifecycleScope
        wheel.onRowClick = { r -> r.onClick() }
        wheel.onPlaylistPick = { i -> pickPlaylistFilter(i) }
        wheel.plSens = Prefs.int(this, "music_pl_sens", 8).coerceIn(1, 10)
        pillNow = findViewById(R.id.pillNow)
        pillNow.setOnClickListener { wheel.recenter() }
        wheel.onBackHint = { show, up ->
            pillNow.visibility = if (show) View.VISIBLE else View.GONE
            pillNow.setCompoundDrawablesRelativeWithIntrinsicBounds(
                if (up) R.drawable.ic_dm_arrow_up else R.drawable.ic_dm_arrow_down, 0, 0, 0
            )
        }
        wheel.onRowLong = { r ->
            val lg = r.onLong
            if (lg != null) {
                lg()
                true
            } else {
                false
            }
        }

        // popup pengaturan cepat (3 saklar desain + jalan ke pengaturan lengkap)
        swVideo.setCheckedNow(Prefs.bool(this, "music_video_bg", true))
        swCurve.setCheckedNow(Prefs.bool(this, "music_curve", true))
        swSide.setCheckedNow(Prefs.bool(this, "music_qs_right", true))
        wheel.setCurved(swCurve.checked, false)
        wheel.setQsRight(swSide.checked)
        findViewById<View>(R.id.rowVideo).setOnClickListener {
            val on = !swVideo.checked
            swVideo.checked = on
            Prefs.setBool(this, "music_video_bg", on)
            applyBanner()
        }
        findViewById<View>(R.id.rowCurve).setOnClickListener {
            val on = !swCurve.checked
            swCurve.checked = on
            Prefs.setBool(this, "music_curve", on)
            wheel.setCurved(on, true)
        }
        findViewById<View>(R.id.rowSide).setOnClickListener {
            val on = !swSide.checked
            swSide.checked = on
            Prefs.setBool(this, "music_qs_right", on)
            wheel.setQsRight(on)
        }
        findViewById<View>(R.id.tvMoreSettings).setOnClickListener {
            setPop(false)
            settingsDialog()
        }
        popScrim.setOnClickListener { setPop(false) }

        rebuildTabs()

        etSearch.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun afterTextChanged(s: Editable?) = refresh()
        })
        etSearch.setOnEditorActionListener { _, actionId, _ ->
            if (actionId == EditorInfo.IME_ACTION_SEARCH) {
                hideKeyboard()
                true
            } else {
                false
            }
        }

        backCb = object : OnBackPressedCallback(false) {
            override fun handleOnBackPressed() {
                if (popOpen) {
                    setPop(false)
                } else if (drill != null) {
                    drill = null
                    refresh()
                } else if (plSel != null) {
                    // tombol kembali bawaan HP: dari playlist/favorit langsung ke Semua lagu
                    pickPlaylistFilter(0)
                }
            }
        }
        onBackPressedDispatcher.addCallback(this, backCb)

        findViewById<View>(R.id.ibSearch).setOnClickListener { toggleSearch() }
        findViewById<View>(R.id.ibSearchClose).setOnClickListener { toggleSearch() }
        findViewById<View>(R.id.ibSort).setOnClickListener {
            setPop(false)
            Ui.sortDialog(this, Ui.SORT_MUSIC, sortMode) {
                sortMode = it
                Prefs.setInt(this, "sort_music", it)
                refresh()
            }
        }
        findViewById<View>(R.id.ibSettings).setOnClickListener { setPop(!popOpen) }

        findViewById<View>(R.id.btnPlayAll).setOnClickListener {
            drill?.let { d -> if (d.tracks.isNotEmpty()) playQueue(sortedTracks(d.tracks), 0, false) }
        }
        findViewById<View>(R.id.btnShufAll).setOnClickListener {
            drill?.let { d ->
                if (d.tracks.isNotEmpty()) playQueue(d.tracks, Random.nextInt(d.tracks.size), true)
            }
        }

        // mini player
        btnMiniPlay.setOnClickListener {
            controller?.let { if (it.isPlaying) it.pause() else it.play() }
        }
        findViewById<View>(R.id.btnMiniNext).setOnClickListener { controller?.seekToNextMediaItem() }
        findViewById<View>(R.id.btnMiniPrev).setOnClickListener { controller?.seekToPreviousMediaItem() }
        setupSwipe()
        setupSeek()

        // dipasang paling akhir: pemanggilan pertamanya memakai semua view di atas
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.musicRoot)) { _, ins ->
            statusTop = ins.getInsets(WindowInsetsCompat.Type.systemBars()).top
            navBottom = ins.getInsets(
                WindowInsetsCompat.Type.systemBars() or WindowInsetsCompat.Type.ime()
            ).bottom
            applyInsets()
            WindowInsetsCompat.CONSUMED
        }

        ensureMedia()
    }

    /** Geser baris judul di mini player: kiri = berikutnya, kanan = sebelumnya, ketuk / geser atas = buka pemutar. */
    @SuppressLint("ClickableViewAccessibility")
    private fun setupSwipe() {
        val area = findViewById<View>(R.id.swipeArea)
        val density = resources.displayMetrics.density
        var sx = 0f
        var sy = 0f
        var moved = false
        var up = false
        var active = false
        area.setOnTouchListener { _, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    sx = e.rawX
                    sy = e.rawY
                    moved = false
                    up = false
                    active = true
                    swipeInner.animate().cancel()
                }

                MotionEvent.ACTION_MOVE -> if (active) {
                    val dx = e.rawX - sx
                    val dy = e.rawY - sy
                    if (abs(dx) > 8f * density || abs(dy) > 8f * density) moved = true
                    if (dy < -40f * density && abs(dx) < 40f * density) up = true
                    swipeInner.translationX = dx
                    swipeInner.alpha = max(0.2f, 1f - abs(dx) / (140f * density))
                }

                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> if (active) {
                    active = false
                    val dx = e.rawX - sx
                    swipeInner.animate().translationX(0f).alpha(1f).setDuration(250L).start()
                    if (e.actionMasked == MotionEvent.ACTION_UP) {
                        if (up || !moved) {
                            startActivity(Intent(this, NowPlayingActivity::class.java))
                        } else if (dx < -60f * density) {
                            controller?.seekToNextMediaItem()
                        } else if (dx > 60f * density) {
                            controller?.seekToPreviousMediaItem()
                        }
                    }
                }
            }
            true
        }
    }

    /** Garis seek mini player: waktu muncul saat disentuh, posisi dikirim saat jari diangkat. */
    private fun setupSeek() {
        seek.onDragStart = {
            timeRow.animate().alpha(1f).setDuration(200L).start()
        }
        seek.onDrag = { p ->
            val dur = (controller?.duration ?: 0L).coerceAtLeast(0L)
            tvElapsed.text = Library.fmt((p * dur).toLong())
            tvTotal.text = Library.fmt(dur)
        }
        seek.onDragEnd = { p, ok ->
            timeRow.animate().alpha(0f).setDuration(200L).start()
            val c = controller
            if (ok && c != null && c.duration > 0) c.seekTo((p * c.duration).toLong())
        }
    }

    // ---------- tata letak & popup ----------

    /** Posisi yang ikut status bar (atas) dan bar navigasi / keyboard (bawah). */
    private fun applyInsets() {
        fun top(v: View, dpv: Int) {
            (v.layoutParams as FrameLayout.LayoutParams).topMargin = Ui.dp(this, dpv) + statusTop
        }
        top(tvBannerLabel, 26)
        top(topButtons, 14)
        top(settingsPop, 62)
        (mini.layoutParams as FrameLayout.LayoutParams).bottomMargin = navBottom
        (fade.layoutParams as FrameLayout.LayoutParams).height = Ui.dp(this, 84) + navBottom
        (pillNow.layoutParams as FrameLayout.LayoutParams).bottomMargin = Ui.dp(this, 92) + navBottom
        findViewById<View>(R.id.musicRoot).requestLayout()
        applyHeaderLayout()
    }

    private fun imm() = getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager

    private fun hideKeyboard() {
        imm().hideSoftInputFromWindow(etSearch.windowToken, 0)
    }

    private fun toggleSearch() {
        searchOpen = !searchOpen
        setPop(false)
        etSearch.setText("")
        searchRow.visibility = if (searchOpen) View.VISIBLE else View.GONE
        tvTitle.visibility = if (searchOpen) View.INVISIBLE else View.VISIBLE
        updatePlLabel()
        if (searchOpen) {
            etSearch.requestFocus()
            imm().showSoftInput(etSearch, InputMethodManager.SHOW_IMPLICIT)
        } else {
            hideKeyboard()
            etSearch.clearFocus()
        }
    }

    /** Label kecil "Playlist: ..." di atas judul, hanya saat tab Lagu difilter ke playlist/favorit. */
    internal fun updatePlLabel() {
        val s = plSel
        val show = s != null && drill == null && curTab() == 0 && !searchOpen
        tvPlLabel.visibility = if (show) View.VISIBLE else View.GONE
        if (show) tvPlLabel.text = "Playlist: " + (if (s == PL_FAV) "Favorit" else s)
    }

    private fun setPop(open: Boolean) {
        popOpen = open
        settingsPop.visibility = if (open) View.VISIBLE else View.GONE
        popScrim.visibility = if (open) View.VISIBLE else View.GONE
        updateBack()
    }

    internal fun updateBack() {
        if (::backCb.isInitialized) backCb.isEnabled = drill != null || popOpen || (plSel != null && curTab() == 0)
    }

    // ---------- banner ----------

    internal fun bannerHeightPx() = Ui.dp(this, 440)

    internal fun videoOn() = Prefs.bool(this, "music_video_bg", true)

    override fun onStart() {
        super.onStart()
        applyBanner()
        val token = SessionToken(this, ComponentName(this, PlayerService::class.java))
        val f = MediaController.Builder(this, token).buildAsync()
        future = f
        f.addListener({
            try {
                val c = f.get()
                controller = c
                c.addListener(object : Player.Listener {
                    override fun onEvents(player: Player, events: Player.Events) = updateMini()
                })
                updateMini()
                handler.post(tick)
            } catch (e: Exception) {
                Toast.makeText(this, "Pemutar gagal tersambung: ${e.message}", Toast.LENGTH_LONG).show()
            }
        }, ContextCompat.getMainExecutor(this))
    }

    override fun onStop() {
        banner.stop()
        handler.removeCallbacks(tick)
        future?.let { MediaController.releaseFuture(it) }
        future = null
        controller = null
        super.onStop()
    }

    // ---------- tab ----------

    internal fun rebuildTabs() {
        visibleIds = Prefs.visibleTabs(this)
        tabIndex = 0
        tabsBox.removeAllViews()
        visibleIds.forEachIndexed { i, id ->
            val t = TabText(this)
            t.text = Prefs.TAB_NAMES[id]
            t.setOnClickListener { selectTab(i) }
            val lp = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT, Ui.dp(this, 36)
            )
            lp.marginEnd = Ui.dp(this, 8)
            tabsBox.addView(t, lp)
        }
        styleTabs()
        drill = null
    }

    private fun selectTab(i: Int) {
        tabIndex = i
        styleTabs()
        drill = null
        refresh()
    }

    private fun styleTabs() {
        for (i in 0 until tabsBox.childCount) {
            (tabsBox.getChildAt(i) as TabText).sel = i == tabIndex
        }
    }

    // ---------- data ----------

    override fun onMediaReady() {
        tvEmpty.text = "Memuat..."
        tvEmpty.visibility = View.VISIBLE
        val first = !loaded
        lifecycleScope.launch {
            val t = withContext(Dispatchers.IO) { Library.audios(this@MusicActivity) }
            tracks = t
            byId.clear()
            t.forEach { byId[it.id] = it }
            drill?.let { d -> d.tracks = d.tracks.mapNotNull { byId[it.id] } }
            albums = Library.albums(t)
            artists = Library.artists(t)
            folders = Library.folders(t)
            loaded = true
            refresh(!first)
            updateMini()
        }
    }

    internal fun match(t: Library.Track, q: String) =
        q.isEmpty() || t.title.lowercase().contains(q) ||
            t.artist.lowercase().contains(q) || t.album.lowercase().contains(q)

    internal fun sortedTracks(l: List<Library.Track>) =
        Ui.sortBy(l, sortMode, { it.title }, { it.dateAdded }, { it.durationMs })

    private fun sortedGroups(l: List<Library.Group>) =
        Ui.sortBy(l, sortMode, { it.title }, { it.date }, { it.big })

    internal var shownIds: List<Long> = emptyList()

    internal fun covers(l: List<Library.Track>): List<Uri> =
        l.distinctBy { it.albumId }.take(4).map { it.uri }

    internal fun groupRows(groups: List<Library.Group>, q: String, icon: Int): List<Row> =
        sortedGroups(
            groups.filter { q.isEmpty() || it.title.lowercase().contains(q) || it.sub.lowercase().contains(q) }
        ).map { g ->
            Row(
                title = g.title,
                sub = g.sub,
                icon = icon,
                thumb = g.tracks.firstOrNull()?.uri,
                thumbs = if (icon == R.drawable.ic_album) emptyList() else covers(g.tracks),
                onClick = {
                    drill = Drill(g.title, g.tracks, 0, null)
                    refresh()
                }
            )
        }

    internal fun playlistTracks(name: String): List<Library.Track> =
        (MusicStore.playlists(this)[name] ?: emptyList<Long>()).mapNotNull { byId[it] }

    // ---------- menu tahan-lama ----------

    // ---------- putar ----------

    // ---------- mini player ----------

    private fun updateMini() {
        val c = controller ?: return
        mini.visibility = if (c.mediaItemCount > 0) View.VISIBLE else View.GONE
        tvNow.text = c.mediaMetadata.title ?: "—"
        tvArtist.text = c.mediaMetadata.artist ?: ""
        btnMiniPlay.setImageResource(if (c.isPlaying) R.drawable.ic_dm_pause else R.drawable.ic_dm_play)
        val id = c.currentMediaItem?.mediaId?.toLongOrNull()
        Thumbs.load(lifecycleScope, ivMini, id?.let { byId[it]?.uri }, 128, false)
        wheel.setPlayingKey(id ?: -1L, false)
        wheel.setPlayingNow(c.isPlaying)
        tvNow.isSelected = c.isPlaying
        updateProgress()
    }

    private fun updateProgress() {
        val c = controller ?: return
        if (seek.dragging) return
        val dur = c.duration
        seek.progress = if (dur > 0) c.currentPosition.coerceIn(0, dur).toFloat() / dur else 0f
    }
}
