package com.niven.mangatl

import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.exp
import kotlin.math.ln
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow
import kotlin.math.sin
import kotlin.math.sqrt
import kotlin.math.tan

/** Filter orde dua (RBJ cookbook), bentuk transposed direct form II. */
class Biquad {
    var b0 = 1.0
    var b1 = 0.0
    var b2 = 0.0
    var a1 = 0.0
    var a2 = 0.0
    private var z1 = 0.0
    private var z2 = 0.0

    fun process(x: Double): Double {
        val y = b0 * x + z1
        z1 = b1 * x - a1 * y + z2
        z2 = b2 * x - a2 * y
        return y
    }

    fun reset() {
        z1 = 0.0
        z2 = 0.0
    }

    fun pass() {
        b0 = 1.0; b1 = 0.0; b2 = 0.0; a1 = 0.0; a2 = 0.0
    }

    fun set(nb0: Double, nb1: Double, nb2: Double, a0: Double, na1: Double, na2: Double) {
        b0 = nb0 / a0; b1 = nb1 / a0; b2 = nb2 / a0; a1 = na1 / a0; a2 = na2 / a0
    }
}

object Dsg {
    private fun fc(f: Double, sr: Int) = f.coerceIn(10.0, sr * 0.45)

    fun peak(q: Biquad, sr: Int, f: Double, gainDb: Double, qf: Double) {
        val w = 2 * PI * fc(f, sr) / sr
        val a = 10.0.pow(gainDb / 40.0)
        val al = sin(w) / (2 * max(qf, 0.05))
        val c = cos(w)
        q.set(1 + al * a, -2 * c, 1 - al * a, 1 + al / a, -2 * c, 1 - al / a)
    }

    fun lowShelf(q: Biquad, sr: Int, f: Double, gainDb: Double, qf: Double) {
        val w = 2 * PI * fc(f, sr) / sr
        val a = 10.0.pow(gainDb / 40.0)
        val c = cos(w)
        val al = sin(w) / (2 * max(qf, 0.05))
        val be = 2 * sqrt(a) * al
        q.set(
            a * ((a + 1) - (a - 1) * c + be), 2 * a * ((a - 1) - (a + 1) * c), a * ((a + 1) - (a - 1) * c - be),
            (a + 1) + (a - 1) * c + be, -2 * ((a - 1) + (a + 1) * c), (a + 1) + (a - 1) * c - be
        )
    }

    fun highShelf(q: Biquad, sr: Int, f: Double, gainDb: Double, qf: Double) {
        val w = 2 * PI * fc(f, sr) / sr
        val a = 10.0.pow(gainDb / 40.0)
        val c = cos(w)
        val al = sin(w) / (2 * max(qf, 0.05))
        val be = 2 * sqrt(a) * al
        q.set(
            a * ((a + 1) + (a - 1) * c + be), -2 * a * ((a - 1) + (a + 1) * c), a * ((a + 1) + (a - 1) * c - be),
            (a + 1) - (a - 1) * c + be, 2 * ((a - 1) - (a + 1) * c), (a + 1) - (a - 1) * c - be
        )
    }

    fun lowpass(q: Biquad, sr: Int, f: Double, qf: Double) {
        val w = 2 * PI * fc(f, sr) / sr
        val c = cos(w)
        val al = sin(w) / (2 * max(qf, 0.05))
        q.set((1 - c) / 2, 1 - c, (1 - c) / 2, 1 + al, -2 * c, 1 - al)
    }

    fun highpass(q: Biquad, sr: Int, f: Double, qf: Double) {
        val w = 2 * PI * fc(f, sr) / sr
        val c = cos(w)
        val al = sin(w) / (2 * max(qf, 0.05))
        q.set((1 + c) / 2, -(1 + c), (1 + c) / 2, 1 + al, -2 * c, 1 - al)
    }

    fun bandpass(q: Biquad, sr: Int, f: Double, qf: Double) {
        val w = 2 * PI * fc(f, sr) / sr
        val c = cos(w)
        val al = sin(w) / (2 * max(qf, 0.05))
        q.set(al, 0.0, -al, 1 + al, -2 * c, 1 - al)
    }

    fun notch(q: Biquad, sr: Int, f: Double, qf: Double) {
        val w = 2 * PI * fc(f, sr) / sr
        val c = cos(w)
        val al = sin(w) / (2 * max(qf, 0.05))
        q.set(1.0, -2 * c, 1.0, 1 + al, -2 * c, 1 - al)
    }

    /** Orde satu (6 dB/oct) lewat transformasi bilinear. */
    fun lowpass1(q: Biquad, sr: Int, f: Double) {
        val k = tan(PI * fc(f, sr) / sr)
        q.set(k, k, 0.0, 1 + k, k - 1, 0.0)
    }

    fun highpass1(q: Biquad, sr: Int, f: Double) {
        val k = tan(PI * fc(f, sr) / sr)
        q.set(1.0, -1.0, 0.0, 1 + k, k - 1, 0.0)
    }

    /** Q tiap seksi Butterworth orde-genap n (n/2 seksi). */
    fun butterQ(n: Int, k: Int): Double = 1.0 / (2.0 * cos(PI * (2 * k - 1) / (2.0 * n)))
}

fun dbToLin(db: Double): Double = 10.0.pow(db / 20.0)
fun linToDb(x: Double): Double = 20.0 * kotlin.math.log10(max(x, 1e-12))

/** Delay line mono dengan pembacaan pecahan (interpolasi linear). */
class DelayLine(maxSamples: Int) {
    private val size: Int
    private val buf: DoubleArray
    private var pos = 0

    init {
        var s = 2
        while (s < maxSamples + 4) s = s shl 1
        size = s
        buf = DoubleArray(s)
    }

    fun write(x: Double) {
        pos = (pos + 1) and (size - 1)
        buf[pos] = x
    }

    /** d = jarak dalam sampel dari sampel terbaru (0 = sampel yang baru ditulis). */
    fun read(d: Double): Double {
        val di = d.toInt()
        val fr = d - di
        val a = buf[(pos - di) and (size - 1)]
        val b = buf[(pos - di - 1) and (size - 1)]
        return a + (b - a) * fr
    }

    fun readInt(d: Int): Double = buf[(pos - d) and (size - 1)]

    fun clear() {
        java.util.Arrays.fill(buf, 0.0)
    }
}

/** FFT radix-2 kompleks berurutan (in-place). n harus pangkat dua. */
object Fft {
    fun transform(re: DoubleArray, im: DoubleArray, inverse: Boolean) {
        val n = re.size
        var j = 0
        for (i in 1 until n) {
            var bit = n shr 1
            while (j and bit != 0) {
                j = j xor bit
                bit = bit shr 1
            }
            j = j xor bit
            if (i < j) {
                val tr = re[i]; re[i] = re[j]; re[j] = tr
                val ti = im[i]; im[i] = im[j]; im[j] = ti
            }
        }
        var len = 2
        while (len <= n) {
            val ang = 2 * PI / len * (if (inverse) 1 else -1)
            val wr = cos(ang)
            val wi = sin(ang)
            var i = 0
            while (i < n) {
                var cr = 1.0
                var ci = 0.0
                for (k in 0 until len / 2) {
                    val ur = re[i + k]
                    val ui = im[i + k]
                    val vr = re[i + k + len / 2] * cr - im[i + k + len / 2] * ci
                    val vi = re[i + k + len / 2] * ci + im[i + k + len / 2] * cr
                    re[i + k] = ur + vr
                    im[i + k] = ui + vi
                    re[i + k + len / 2] = ur - vr
                    im[i + k + len / 2] = ui - vi
                    val nr = cr * wr - ci * wi
                    ci = cr * wi + ci * wr
                    cr = nr
                }
                i += len
            }
            len = len shl 1
        }
        if (inverse) {
            for (i in 0 until n) {
                re[i] /= n
                im[i] /= n
            }
        }
    }
}

object Win {
    fun bessel0(x: Double): Double {
        var s = 1.0
        var t = 1.0
        var k = 1
        while (k < 40) {
            t *= (x / (2.0 * k)) * (x / (2.0 * k))
            s += t
            if (t < 1e-12 * s) break
            k++
        }
        return s
    }

    /** Prototipe lowpass sinc berjendela Kaiser. cut = frekuensi potong ternormalisasi (0..0.5), gain = skala DC. */
    fun kaiserSinc(len: Int, cut: Double, gain: Double, beta: Double): DoubleArray {
        val h = DoubleArray(len)
        val m = (len - 1) / 2.0
        val i0 = bessel0(beta)
        for (i in 0 until len) {
            val x = i - m
            val s = if (abs(x) < 1e-9) 2 * cut else sin(2 * PI * cut * x) / (PI * x)
            val r = x / max(m, 1.0)
            val w = bessel0(beta * sqrt(max(0.0, 1 - r * r))) / i0
            h[i] = s * w * gain
        }
        return h
    }

    /** Ubah filter linear-phase menjadi minimum-phase (metode cepstrum). */
    fun minimumPhase(h: DoubleArray): DoubleArray {
        var n = 1
        while (n < h.size * 4) n = n shl 1
        val re = DoubleArray(n)
        val im = DoubleArray(n)
        for (i in h.indices) re[i] = h[i]
        Fft.transform(re, im, false)
        for (i in 0 until n) {
            re[i] = ln(max(sqrt(re[i] * re[i] + im[i] * im[i]), 1e-9))
            im[i] = 0.0
        }
        Fft.transform(re, im, true)
        for (i in 1 until n / 2) re[i] *= 2.0
        for (i in n / 2 + 1 until n) re[i] = 0.0
        for (i in 0 until n) im[i] = 0.0
        Fft.transform(re, im, false)
        for (i in 0 until n) {
            val m = exp(re[i])
            val a = im[i]
            re[i] = m * cos(a)
            im[i] = m * sin(a)
        }
        Fft.transform(re, im, true)
        return DoubleArray(h.size) { re[it] }
    }
}

/**
 * Oversampling untuk blok nonlinear: naik N kali, bentuk gelombang, turun lagi.
 * Dipakai oleh penambah harmonik bass/vokal (mengurangi alias).
 */
class OsShaper(val factor: Int) {
    private val taps = 16
    private val len = taps * factor
    private val hi: DoubleArray
    private val hd: DoubleArray
    private val xin = DoubleArray(taps + 1)
    private val yhi = DoubleArray(len)
    private var xp = 0
    private var yp = 0

    init {
        hi = Win.kaiserSinc(len, 0.5 / factor * 0.9, factor.toDouble(), 7.0)
        hd = Win.kaiserSinc(len, 0.5 / factor * 0.9, 1.0, 7.0)
    }

    /** Proses satu sampel dengan fungsi bentuk fn. Tundaan sekitar 2*taps sampel. */
    inline fun shape(x: Double, fn: (Double) -> Double): Double {
        push(x)
        for (p in 0 until factor) {
            val v = interp(p)
            pushHi(fn(v))
        }
        return decim()
    }

    fun push(x: Double) {
        xp = (xp + 1) % xin.size
        xin[xp] = x
    }

    fun interp(phase: Int): Double {
        var s = 0.0
        var k = 0
        while (k < taps) {
            val idx = phase + k * factor
            if (idx < len) s += hi[idx] * xin[((xp - k) % xin.size + xin.size) % xin.size]
            k++
        }
        return s
    }

    fun pushHi(v: Double) {
        yp = (yp + 1) % len
        yhi[yp] = v
    }

    fun decim(): Double {
        var s = 0.0
        for (k in 0 until len) s += hd[k] * yhi[((yp - k) % len + len) % len]
        return s
    }

    /**
     * Tundaan total jalur naik-turun (diukur dengan impuls: tepat taps-1 sampel pada 2x/4x/8x, karena
     * pengambilan sampel decimator memakai fase terakhir). Dipakai efek untuk menyelaraskan jalur kering.
     */
    val delaySamples: Int get() = taps - 1

    /** Kosongkan riwayat interpolasi dan decimator (flush / seek / ganti lagu). */
    fun reset() {
        java.util.Arrays.fill(xin, 0.0)
        java.util.Arrays.fill(yhi, 0.0)
        xp = 0
        yp = 0
    }
}

/**
 * Resampler polyphase rasional, stereo. Filter linear-phase atau minimum-phase.
 * Tidak menambah detail baru; hanya mengubah laju sampel.
 */
class Resampler(val inRate: Int, val outRate: Int, minPhase: Boolean) {
    private val l: Int
    private val m: Int
    private val taps: Int
    private val h: FloatArray
    private var hl = FloatArray(0)
    private var hr = FloatArray(0)
    private var p: Long = 0
    val delayInSamples: Float

    init {
        val g = gcd(inRate, outRate)
        l = outRate / g
        m = inRate / g
        taps = if (outRate < inRate) 48 else 32
        val len = taps * l
        // normalisasi di laju tinggi (inRate * l): potong di setengah min(in, out)
        val cut = 0.5 * min(inRate, outRate).toDouble() / (inRate.toDouble() * l) * 0.96
        var proto = Win.kaiserSinc(len, cut, l.toDouble(), 8.0)
        if (minPhase) proto = Win.minimumPhase(proto)
        h = FloatArray(len) { proto[it].toFloat() }
        delayInSamples = if (minPhase) 2f else (len - 1) / 2f / l
        p = (taps - 1).toLong() * l
        hl = FloatArray(taps - 1)
        hr = FloatArray(taps - 1)
    }

    private fun gcd(a: Int, b: Int): Int {
        var x = a
        var y = b
        while (y != 0) {
            val t = x % y
            x = y
            y = t
        }
        return x
    }

    var outL = FloatArray(0)
    var outR = FloatArray(0)
    var outN = 0

    fun reset() {
        java.util.Arrays.fill(hl, 0f)
        java.util.Arrays.fill(hr, 0f)
        p = (taps - 1).toLong() * l
    }

    fun process(inL: FloatArray, inR: FloatArray, n: Int) {
        val len = taps - 1 + n
        val al = FloatArray(len)
        val ar = FloatArray(len)
        System.arraycopy(hl, 0, al, 0, taps - 1)
        System.arraycopy(hr, 0, ar, 0, taps - 1)
        System.arraycopy(inL, 0, al, taps - 1, n)
        System.arraycopy(inR, 0, ar, taps - 1, n)
        val cap = (n.toLong() * l / m + 4).toInt()
        if (outL.size < cap) {
            outL = FloatArray(cap)
            outR = FloatArray(cap)
        }
        var cnt = 0
        while (p / l < len) {
            val b = (p / l).toInt()
            val ph = (p % l).toInt()
            var sl = 0f
            var sr = 0f
            var k = 0
            var hi = ph
            while (k < taps) {
                val c = h[hi]
                val ix = b - k
                if (ix >= 0) {
                    sl += c * al[ix]
                    sr += c * ar[ix]
                }
                hi += l
                k++
            }
            if (cnt < outL.size) {
                outL[cnt] = sl
                outR[cnt] = sr
                cnt++
            }
            p += m
        }
        System.arraycopy(al, len - (taps - 1), hl, 0, taps - 1)
        System.arraycopy(ar, len - (taps - 1), hr, 0, taps - 1)
        p -= (len - (taps - 1)).toLong() * l
        outN = cnt
    }
}

/**
 * Estimasi true-peak (BS.1770 Annex 2): interpolasi polyphase factor-x, lalu ambil puncak mutlak.
 * push() mengembalikan puncak pada selang [m, m+1) dengan m = sampel `lag` langkah sebelum yang baru masuk
 * (sampel m sendiri ikut dihitung), jadi estimasi selalu terlambat `lag` sampel. Panggil flush() di akhir
 * agar selang terakhir ikut terukur.
 */
class TruePeak(val factor: Int) {
    private val taps = 24
    private val m = taps + 1
    val lag: Int = if (factor > 1) taps / 2 else 0
    private val ph: Array<DoubleArray>
    // riwayat ganda (dua salinan berurutan) supaya jendela m sampel terbaru berupa irisan lurus tanpa modulo
    private val buf = DoubleArray(2 * m)
    private var pos = 0

    init {
        if (factor > 1) {
            // prototipe berpanjang ganjil berpusat di sampel hi-rate bulat: fase p jatuh tepat di m + p/factor
            // (fase 0 = sampel itu sendiri, fase factor/2 = titik tengah), jadi puncak di tengah dua sampel tertangkap
            val len = taps * factor + 1
            val proto = Win.kaiserSinc(len, 0.5 / factor, factor.toDouble(), 8.0)
            ph = Array(factor) { p -> DoubleArray(m) { k -> val i = p + k * factor; if (i < len) proto[i] else 0.0 } }
        } else {
            ph = emptyArray()
        }
    }

    fun push(x: Double): Double {
        if (factor <= 1) return abs(x)
        pos = if (pos == 0) m - 1 else pos - 1
        buf[pos] = x
        buf[pos + m] = x
        var pk = abs(buf[pos + lag])
        for (p in 1 until factor) {
            var s = 0.0
            val t = ph[p]
            for (k in 0 until m) s += t[k] * buf[pos + k]
            val a = abs(s)
            if (a > pk) pk = a
        }
        return pk
    }

    /** Dorong nol sebanyak lag+1 supaya selang terakhir terhitung; kembalikan puncak maksimum dari sisa itu. */
    fun flush(): Double {
        var pk = 0.0
        for (i in 0..lag) pk = max(pk, push(0.0))
        return pk
    }

    fun reset() {
        java.util.Arrays.fill(buf, 0.0)
        pos = 0
    }

    companion object {
        /** Faktor oversampling sesuai BS.1770: 4x di bawah 96 kHz, 2x di bawah 192 kHz, selebihnya 1x. */
        fun factorFor(sr: Int): Int = if (sr < 96000) 4 else if (sr < 192000) 2 else 1
    }
}

/**
 * Penjaga puncak lookahead untuk Normalisasi dinamis + Clipping Prevention. Gain dihitung dari estimasi
 * true-peak, memakai jendela-minimum lalu rata-rata kotak selebar w (rampa turun selesai tepat saat puncak
 * tiba), dan audio ditunda lag+w-1 sampel supaya transien tidak lolos meski gain loudness bergerak lambat.
 * Pelepasan satu kutub (~120 ms) mencegah pumping. Puncak sampel keluaran dijamin <= ceiling.
 */
class PeakGuard(private val sr: Int) {
    private val tpL = TruePeak(TruePeak.factorFor(sr))
    private val tpR = TruePeak(TruePeak.factorFor(sr))
    private val w = max(2, (0.002 * sr).toInt())
    val delay = tpL.lag + w - 1
    private val dl = FloatArray(max(delay, 1))
    private val dr = FloatArray(max(delay, 1))
    private var dp = 0
    private val capQ = w + 2
    private val qIdx = LongArray(capQ)
    private val qVal = DoubleArray(capQ)
    private var qh = 0
    private var qt = 0
    private var counter = 0L
    private val mBuf = DoubleArray(w) { 1.0 }
    private var mPos = 0
    private var mSum = w.toDouble()
    private var gs = 1.0
    private val rel = 1.0 - exp(-1.0 / (0.12 * sr))
    var ceilLin = 1.0
    var minGain = 1.0
        private set

    fun reset() {
        tpL.reset(); tpR.reset()
        java.util.Arrays.fill(dl, 0f); java.util.Arrays.fill(dr, 0f)
        dp = 0; qh = 0; qt = 0; counter = 0L
        java.util.Arrays.fill(mBuf, 1.0); mPos = 0; mSum = w.toDouble(); gs = 1.0; minGain = 1.0
    }

    fun process(l: FloatArray, r: FloatArray, n: Int) {
        for (i in 0 until n) {
            val x0 = l[i]; val x1 = r[i]
            val est = max(tpL.push(x0.toDouble()), tpR.push(x1.toDouble()))
            val need = if (est > ceilLin) ceilLin / est else 1.0
            // jendela minimum (deque monoton)
            while (qt != qh && qVal[(qt - 1 + capQ) % capQ] >= need) qt = (qt - 1 + capQ) % capQ
            qIdx[qt] = counter; qVal[qt] = need; qt = (qt + 1) % capQ
            while (qh != qt && qIdx[qh] <= counter - w) qh = (qh + 1) % capQ
            val m = qVal[qh]
            // rata-rata kotak
            mSum += m - mBuf[mPos]
            mBuf[mPos] = m
            mPos = (mPos + 1) % w
            if (mPos == 0) { var s = 0.0; for (v in mBuf) s += v; mSum = s }
            val a = mSum / w
            gs = if (a < gs) a else gs + (a - gs) * rel
            if (gs < minGain) minGain = gs
            counter++
            if (delay > 0) {
                val o0 = dl[dp]; val o1 = dr[dp]
                dl[dp] = x0; dr[dp] = x1
                dp = (dp + 1) % delay
                l[i] = (o0 * gs).toFloat(); r[i] = (o1 * gs).toFloat()
            } else {
                l[i] = (x0 * gs).toFloat(); r[i] = (x1 * gs).toFloat()
            }
        }
    }
}
