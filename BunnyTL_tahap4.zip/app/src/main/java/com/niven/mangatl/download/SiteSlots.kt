package com.niven.mangatl

import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.util.Log
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone

/**
 * Tempat penyimpanan slot akun untuk satu situs. Popup pilih akun (DownloadActivity) hanya bicara lewat antarmuka ini,
 * jadi Claude dan semua situs lain memakai tampilan + perilaku yang sama persis.
 * Satu slot = satu profil login (cookies terenkripsi), bukan satu akun Google.
 */
interface AccountStore {
    val site: LoginSite
    /** Nama kelompok di judul daftar: "Google A · 3/10". */
    val groupName: String
    val perGroup: Int
    val maxSlots: Int
    fun multi(): Boolean
    fun count(ctx: Context): Int
    fun get(ctx: Context, i: Int): ClaudeSlot?
    fun put(ctx: Context, i: Int, s: ClaudeSlot): Boolean
    fun clear(ctx: Context, i: Int)
    fun active(ctx: Context): Int
    fun resetDim(ctx: Context)
    /** Dipanggil sebelum daftar dipakai (mis. memindahkan login lama ke slot). */
    fun prepare(ctx: Context) {}

    /** Slot yang tampil di popup. Tiap jalur (A, B) punya daftar sendiri. Bawaan: semua slot sampai [count]. */
    fun visible(ctx: Context): List<Int> = (0 until count(ctx)).toList()

    fun anyFilled(ctx: Context): Boolean = (0 until count(ctx)).any { get(ctx, it)?.filled == true }
}

/**
 * Aturan tampil yang sama untuk semua situs: tiap jalur menampilkan slot yang terpakai + SATU slot kosong. Slot kosong itu
 * terisi -> muncul slot kosong baru (maks [perGroup] per jalur). Jalur B selalu ada (satu slot kosong) selama HP mendukung profil terpisah.
 */
internal fun growingSlots(groups: Int, perGroup: Int, used: (Int) -> Boolean): List<Int> {
    val out = ArrayList<Int>()
    for (g in 0 until groups) {
        val from = g * perGroup
        var last = -1
        for (j in 0 until perGroup) if (used(from + j)) last = j
        val n = (last + 2).coerceIn(1, perGroup)
        for (j in 0 until n) out += from + j
    }
    return out
}

/** Claude memakai [ClaudeSlots] apa adanya; ini hanya pembungkus supaya UI-nya sama dengan situs lain. */
object ClaudeStore : AccountStore {
    override val site: LoginSite get() = ClaudeSlots.SITE
    override val groupName: String get() = "Google"
    override val perGroup: Int get() = ClaudeSlots.PER_PROFILE
    override val maxSlots: Int get() = ClaudeSlots.MAX_SLOTS
    override fun multi() = ClaudeSlots.multiProfile()
    override fun visible(ctx: Context): List<Int> =
        growingSlots(if (multi()) ClaudeSlots.MAX_SLOTS / ClaudeSlots.PER_PROFILE else 1, ClaudeSlots.PER_PROFILE) { ClaudeSlots.stored(ctx, it) }
    override fun count(ctx: Context) = (visible(ctx).maxOrNull() ?: 0) + 1
    override fun get(ctx: Context, i: Int) = ClaudeSlots.get(ctx, i)
    override fun put(ctx: Context, i: Int, s: ClaudeSlot) = ClaudeSlots.put(ctx, i, s)
    override fun clear(ctx: Context, i: Int) = ClaudeSlots.clear(ctx, i)
    override fun active(ctx: Context) = ClaudeSlots.active(ctx)
    override fun resetDim(ctx: Context) = ClaudeSlots.resetDim(ctx)
}

/**
 * Slot akun untuk situs unduhan / situs buatan sendiri (YouTube, Instagram, TikTok, dst), cara kerjanya sama dengan
 * [ClaudeSlots]: tiap slot menyimpan cookies situs itu (terenkripsi, kunci di Android Keystore). Pilih slot -> cookies situs
 * itu di WebView diganti dengan milik slot, jadi langsung masuk tanpa login ulang. Password tidak pernah disimpan.
 *
 * - Login "dengan Google" tidak istimewa: sesi tiap situs tetap cookies situs itu sendiri, jadi tiap situs punya daftar slot sendiri.
 * - Slot aktif diingat PER SITUS. Cookies slot aktif itulah yang dikirim ke yt-dlp (lihat [exportActive]).
 * - Profil WebView [PROFILES] dipisah dari profil Claude, supaya login Google YouTube tidak menimpa login Google untuk Claude.
 */
class SiteSlots private constructor(override val site: LoginSite) : AccountStore {

    companion object {
        private const val TAG = "SiteSlots"
        const val MAX_SLOTS = 20
        const val PER_PROFILE = 10
        /** Slot 1-10 = Jalur A (profil 0), slot 11-20 = Jalur B (profil 1). */
        val PROFILES = listOf("bunny_w0", "bunny_w1")

        private val cache = HashMap<String, SiteSlots>()
        fun of(site: LoginSite): SiteSlots = synchronized(cache) { cache.getOrPut(site.key) { SiteSlots(site) } }

        fun homeProfile(i: Int): String = PROFILES[(i / PER_PROFILE).coerceIn(0, PROFILES.size - 1)]

        /** Slot yang baru pertama kali tersimpan dan belum diberi nama: ditanyakan nanti di layar Unduh (bukan di tengah login). */
        fun markNamePending(ctx: Context, siteKey: String, slot: Int) {
            ctx.applicationContext.getSharedPreferences("site_slots", Context.MODE_PRIVATE)
                .edit().putString("name_pending", "$siteKey|$slot").apply()
        }

        /** Ambil (dan hapus) penanda nama tertunda: (kunci situs, nomor slot), atau null kalau tidak ada. */
        fun takeNamePending(ctx: Context): Pair<String, Int>? {
            val p = ctx.applicationContext.getSharedPreferences("site_slots", Context.MODE_PRIVATE)
            val v = p.getString("name_pending", null) ?: return null
            p.edit().remove("name_pending").apply()
            val i = v.lastIndexOf('|')
            if (i <= 0) return null
            val slot = v.substring(i + 1).toIntOrNull() ?: return null
            return v.substring(0, i) to slot
        }

        /** Nama cookie yang menandakan benar-benar sudah login. Situs yang tidak ada di sini: slot disimpan manual lewat Simpan. */
        private val SESSION = mapOf(
            "youtube.com" to setOf("SID", "__Secure-3PSID", "LOGIN_INFO", "SAPISID"),
            "instagram.com" to setOf("sessionid"),
            "tiktok.com" to setOf("sessionid", "sid_tt"),
            "facebook.com" to setOf("c_user", "xs"),
            "x.com" to setOf("auth_token"),
            "threads.com" to setOf("sessionid"),
            "reddit.com" to setOf("reddit_session", "token_v2"),
            "pinterest.com" to setOf("_auth", "_pinterest_sess")
        )

        private const val CHROMIUM_EPOCH = 11_644_473_600L
    }

    private fun sp(ctx: Context) = ctx.applicationContext.getSharedPreferences("site_slots", Context.MODE_PRIVATE)
    private fun k(name: String) = "${site.key}|$name"

    override val groupName: String get() = if (site.key == "youtube.com") "Google" else "Jalur"
    override val perGroup: Int get() = PER_PROFILE
    override val maxSlots: Int get() = MAX_SLOTS
    override fun multi() = ClaudeSlots.multiProfile()

    // ---------------------------------------------------------------- domain situs

    private fun domains(): List<String> = DlCookies.siteDomains(site.key)

    /** true = [host] termasuk situs ini (youtube.com, m.youtube.com, accounts.google.com untuk YouTube, dst). */
    fun owns(host: String): Boolean {
        val h = host.trimStart('.').lowercase()
        return domains().any { h == it || h.endsWith(".$it") }
    }

    /** Halaman yang dibuka setelah slot terpasang (bukan halaman login). */
    fun home(): String = when (site.key) {
        "youtube.com" -> "https://www.youtube.com/"
        else -> "https://www.${site.key}/"
    }

    // ---------------------------------------------------------------- penyimpanan slot

    override fun visible(ctx: Context): List<Int> {
        val p = sp(ctx)
        return growingSlots(if (multi()) MAX_SLOTS / PER_PROFILE else 1, PER_PROFILE) { p.contains(k("slot_$it")) }
    }

    /** Batas atas nomor slot yang tampil (+1); dipakai pemanggil yang menelusuri slot satu per satu. */
    override fun count(ctx: Context): Int = (visible(ctx).maxOrNull() ?: 0) + 1

    override fun active(ctx: Context) = sp(ctx).getInt(k("active"), -1)
    private fun setActive(ctx: Context, i: Int) = sp(ctx).edit().putInt(k("active"), i).apply()

    override fun get(ctx: Context, i: Int): ClaudeSlot? {
        val enc = sp(ctx).getString(k("slot_$i"), null) ?: return null
        return ClaudeSlots.decodeSlot(enc)
    }

    override fun put(ctx: Context, i: Int, s: ClaudeSlot): Boolean {
        if (!s.filled && s.alias.isBlank()) { sp(ctx).edit().remove(k("slot_$i")).apply(); return true }
        return runCatching {
            sp(ctx).edit().putString(k("slot_$i"), ClaudeSlots.encodeSlot(s)).apply()
            true
        }.onFailure { Log.w(TAG, "slot $i gagal disimpan", it) }.getOrDefault(false)
    }

    override fun clear(ctx: Context, i: Int) {
        val alias = get(ctx, i)?.alias.orEmpty()
        sp(ctx).edit().remove(k("slot_$i")).apply()
        if (alias.isNotBlank()) put(ctx, i, ClaudeSlot(alias = alias)) // nama slot tetap ada
        if (active(ctx) == i) {
            setActive(ctx, -1)
            File(ctx.filesDir, exportName()).delete()
        }
        ctx.getSharedPreferences("cookies_web", Context.MODE_PRIVATE).edit().remove("page_site:${site.key}:$i").apply()
        // sisa login situs ini di browser app ikut dibersihkan (kecuali profil yang sedang memegang slot lain situs yang sama)
        if (ClaudeSlots.multiProfile()) {
            for (p in WebKeeper.wipeableProfiles(PROFILES, "site:${site.key}:", "site:${site.key}:$i")) runCatching { expireWeb(p) }
        }
        WebKeeper.dropSite(site.key, i)
    }

    /** Slot [i] dibuka: slot aktif sebelumnya jadi redup (sudah dipakai), [i] jadi aktif. */
    fun open(ctx: Context, i: Int) {
        val p = active(ctx)
        if (p in 0 until count(ctx) && p != i) get(ctx, p)?.let { it.dim = true; put(ctx, p, it) }
        setActive(ctx, i)
    }

    override fun resetDim(ctx: Context) {
        for (i in 0 until count(ctx)) get(ctx, i)?.let { if (it.dim) { it.dim = false; put(ctx, i, it) } }
    }

    /** Teks kecil di bawah nama slot untuk slot yang baru disimpan (tanpa nama akun, karena tiap situs beda cara menyebutnya). */
    fun stamp(): String = "Disimpan " + SimpleDateFormat("d MMM HH:mm", Locale("id", "ID")).format(Date())

    // ---------------------------------------------------------------- login lama (Jalur A / B) -> slot

    /**
     * Sekali per situs: login lama di cookies.txt Jalur A jadi slot 1, Jalur B jadi slot 11, dan jalur yang dulu dipilih
     * untuk mengunduh jadi slot aktif. Cookies.txt lama tidak dihapus.
     */
    override fun prepare(ctx: Context) {
        val p = sp(ctx)
        if (p.getBoolean(k("migrated"), false)) return
        p.edit().putBoolean(k("migrated"), true).apply()
        if ((0 until MAX_SLOTS).any { p.contains(k("slot_$it")) }) return
        val a = DlCookies.legacyCookies(ctx, site.key, DlCookies.LANE_A)
        val b = DlCookies.legacyCookies(ctx, site.key, DlCookies.LANE_B)
        if (a.isNotEmpty()) put(ctx, 0, ClaudeSlot(email = "Dari Jalur A lama", cookies = a))
        if (b.isNotEmpty()) put(ctx, PER_PROFILE, ClaudeSlot(email = "Dari Jalur B lama", cookies = b))
        val wantB = DlPrefs.siteLane(ctx, site.key) == DlCookies.LANE_B
        when {
            wantB && b.isNotEmpty() -> setActive(ctx, PER_PROFILE)
            a.isNotEmpty() -> setActive(ctx, 0)
            b.isNotEmpty() -> setActive(ctx, PER_PROFILE)
        }
    }

    // ---------------------------------------------------------------- cookies WebView

    /** true = login situs ini bisa dikenali otomatis (nama cookie sesinya diketahui). Selain itu slot disimpan lewat tombol Simpan. */
    val autoSnapshot: Boolean get() = SESSION.containsKey(site.key)

    fun hasSession(list: List<ClaudeCookie>): Boolean {
        val names = SESSION[site.key] ?: return list.isNotEmpty()
        return list.any { it.name in names && it.value.isNotEmpty() }
    }

    /** Cookies situs ini yang sekarang ada di WebView [profile]. [prev] = cookies slot tersimpan, untuk mewarisi atribut kalau database tak terbaca. */
    fun readWebCookies(ctx: Context, profile: String?, prev: List<ClaudeCookie> = emptyList()): List<ClaudeCookie> {
        val cm = ClaudeSlots.cookieManager(profile)
        cm.flush()
        val map = LinkedHashMap<String, ClaudeCookie>()
        runCatching { fromDb(ctx, profile) }.onFailure { Log.w(TAG, "baca db cookies gagal", it) }
            .getOrDefault(emptyList()).forEach { map[it.domain + "|" + it.path + "|" + it.name] = it }
        val before = prev.associateBy { it.name }
        val far = System.currentTimeMillis() / 1000 + 365L * 24 * 3600
        for (d in domains()) {
            for (u in listOf("https://$d", "https://www.$d")) {
                for (kv in (cm.getCookie(u) ?: "").split(';')) {
                    val i = kv.indexOf('=')
                    if (i <= 0) continue
                    val n = kv.substring(0, i).trim()
                    val v = kv.substring(i + 1).trim()
                    val hit = map.entries.firstOrNull { it.value.name == n }
                    val old = hit?.value ?: before[n]
                    val c = if (old != null) ClaudeCookie(old.domain, old.path, old.secure, old.httpOnly, old.expiry, n, v)
                    else ClaudeCookie(".$d", "/", true, false, far, n, v)
                    map[hit?.key ?: (c.domain + "|" + c.path + "|" + n)] = c
                }
            }
        }
        return map.values.toList()
    }

    private fun fromDb(ctx: Context, profile: String?): List<ClaudeCookie> {
        val db = ClaudeSlots.cookieDb(ctx, profile) ?: return emptyList()
        val now = System.currentTimeMillis() / 1000
        val far = now + 365L * 24 * 3600
        val out = ArrayList<ClaudeCookie>()
        SQLiteDatabase.openDatabase(db.absolutePath, null, SQLiteDatabase.OPEN_READONLY).use { d ->
            d.query(
                "cookies", arrayOf("host_key", "expires_utc", "path", "name", "value", "is_secure", "is_httponly"),
                null, null, null, null, null
            ).use { c ->
                while (c.moveToNext()) {
                    val host = c.getString(0) ?: continue
                    if (!owns(host)) continue
                    val name = c.getString(3) ?: continue
                    if (name.isEmpty()) continue
                    val raw = c.getLong(1)
                    val exp = if (raw <= 0L) far else raw / 1_000_000L - CHROMIUM_EPOCH
                    if (exp in 1..now) continue
                    out += ClaudeCookie(host, c.getString(2) ?: "/", c.getInt(5) == 1, c.getInt(6) == 1, exp, name, c.getString(4) ?: "")
                }
            }
        }
        return out
    }

    /** Hapus cookies + storage situs ini dari WebView [profile] (situs lain di profil yang sama tidak terpengaruh). */
    fun expireWeb(profile: String?) {
        val cm = ClaudeSlots.cookieManager(profile)
        val gone = "Thu, 01 Jan 1970 00:00:00 GMT"
        val hosts = LinkedHashSet<String>()
        for (d in domains()) { hosts += d; hosts += "www.$d"; hosts += "m.$d" }
        if (site.key == "youtube.com") hosts += "accounts.google.com"
        for (h in hosts) {
            val u = "https://$h"
            val raw = cm.getCookie(u) ?: continue
            for (kv in raw.split(';')) {
                val n = kv.substringBefore('=').trim()
                if (n.isEmpty()) continue
                cm.setCookie(u, "$n=; Expires=$gone; Max-Age=0; Path=/")
                for (d in domains()) cm.setCookie(u, "$n=; Expires=$gone; Max-Age=0; Path=/; Domain=.$d")
            }
        }
        cm.flush()
        runCatching {
            val ws = ClaudeSlots.webStorage(profile)
            for (h in hosts) ws.deleteOrigin("https://$h")
        }
    }

    /** Ganti cookies situs ini di WebView [profile] dengan milik [slot]; [done] dipanggil setelah semuanya terpasang. */
    fun inject(slot: ClaudeSlot, profile: String?, done: () -> Unit) {
        expireWeb(profile)
        val list = slot.cookies
        if (list.isEmpty()) { done(); return }
        val cm = ClaudeSlots.cookieManager(profile)
        val fmt = SimpleDateFormat("EEE, dd MMM yyyy HH:mm:ss 'GMT'", Locale.US).apply { timeZone = TimeZone.getTimeZone("GMT") }
        var left = list.size
        for (c in list) {
            val sb = StringBuilder("${c.name}=${c.value}; Path=${c.path.ifEmpty { "/" }}")
            if (c.domain.startsWith(".")) sb.append("; Domain=").append(c.domain)
            if (c.expiry in 1..253_402_300_799L) sb.append("; Expires=").append(fmt.format(Date(c.expiry * 1000)))
            if (c.secure) sb.append("; Secure")
            if (c.httpOnly) sb.append("; HttpOnly")
            cm.setCookie("https://" + c.domain.trimStart('.'), sb.toString()) {
                left--
                if (left == 0) { cm.flush(); done() }
            }
        }
    }

    // ---------------------------------------------------------------- yt-dlp

    private fun exportName() = "cookies_slot_${site.key}.txt"

    /**
     * Cookies slot aktif situs ini sebagai cookies.txt (format Netscape) untuk yt-dlp. Null = tidak ada slot aktif yang sah,
     * pemanggil memakai cookies.txt lama. Hanya cookies situs ini yang ikut, tidak pernah cookies situs lain atau Claude.
     */
    fun exportActive(ctx: Context): File? {
        val a = active(ctx)
        if (a < 0) return null
        val s = get(ctx, a)?.takeIf { it.filled && !it.expired } ?: return null
        val now = System.currentTimeMillis() / 1000
        val lines = s.cookies.filter { it.expiry <= 0 || it.expiry > now }.map { c ->
            listOf(
                c.domain, if (c.domain.startsWith(".")) "TRUE" else "FALSE", c.path.ifEmpty { "/" },
                if (c.secure) "TRUE" else "FALSE", c.expiry.toString(), c.name, c.value
            ).joinToString("\t")
        }
        if (lines.isEmpty()) return null
        return runCatching {
            File(ctx.filesDir, exportName()).also {
                it.writeText("# Netscape HTTP Cookie File\n# Dibuat oleh BunnyTL (slot aktif)\n\n" + lines.joinToString("\n") + "\n")
            }
        }.getOrNull()
    }
}
