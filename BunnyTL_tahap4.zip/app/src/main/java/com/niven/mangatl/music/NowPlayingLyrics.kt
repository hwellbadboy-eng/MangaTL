package com.niven.mangatl

import android.animation.ArgbEvaluator
import android.animation.ValueAnimator
import android.graphics.Color
import android.graphics.Outline
import android.graphics.PorterDuff
import android.graphics.RenderEffect
import android.graphics.Shader
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.ViewOutlineProvider
import android.view.animation.PathInterpolator
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.core.widget.TextViewCompat
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.LinearSmoothScroller
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.bottomsheet.BottomSheetDialog
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

// Layar Sedang diputar: lirik penuh + lirik mini (susun tampilan, gulir, sinkron waktu, muat/cari/edit lirik).
// Fungsi ekstensi dari NowPlayingActivity; keadaan dan siklus hidup layar tetap di NowPlayingActivity.kt.

internal class LineHolder(val row: FrameLayout, val tv: TextView) : RecyclerView.ViewHolder(row)

internal fun NowPlayingActivity.bindLine(h: LineHolder, pos: Int, animate: Boolean) {
    val r = lyrics ?: return
    val l = r.lines[pos]
    h.tv.text = l.text.ifEmpty { "…" }
    h.row.setOnClickListener {
        if (r.synced && l.timeMs >= 0) {
            controller?.seekTo(l.timeMs)
            syncLyric(l.timeMs)
        }
    }
    styleLine(h.tv, lineState(pos), true, animate)
}

internal fun NowPlayingActivity.buildLyricViews() {
    val match = ViewGroup.LayoutParams.MATCH_PARENT
    val wrap = ViewGroup.LayoutParams.WRAP_CONTENT

    // ---- lirik mini: kotak 560 x 132 (2 baris x 66), menumpang di slot 64dp di atas baris Hi-Res ----
    miniWin = FrameLayout(this)
    miniWin.isClickable = true
    miniWin.contentDescription = "Buka layar lirik"
    miniWin.clipChildren = true
    miniWin.clipToOutline = true
    miniWin.outlineProvider = ViewOutlineProvider.BOUNDS
    miniCol = LinearLayout(this)
    miniCol.orientation = LinearLayout.VERTICAL
    miniWin.addView(miniCol, FrameLayout.LayoutParams(match, wrap))
    miniWin.setOnClickListener { if (lyrics != null) setLyricScreen(true) else lyricActionsSheet() }
    // jendela mini tumbuh ke atas dari posisi lamanya; blok bawah tidak boleh memotong gambarnya
    (bottomBox as ViewGroup).clipChildren = false
    (bottomBox as ViewGroup).clipToPadding = false
    findViewById<FrameLayout>(R.id.lyricSlot).addView(
        miniWin, 0, FrameLayout.LayoutParams(mi(560f), mi(264f)).apply { topMargin = mi(24f) + mi(132f) - mi(264f) }
    )

    // ---- layar lirik penuh: 1159 x 1400 di atas cover, di bawah kontrol ----
    lyricOverlay = FrameLayout(this)
    lyricOverlay.visibility = View.GONE
    lyricOverlay.alpha = 0f
    lyricOverlay.isClickable = true

    // latar: cover blur lebih gelap (0,5) + lapisan hitam 35%, memudar di dasar (78% -> 100%)
    val bgMask = FadeMask(this)
    bgMask.setStops(floatArrayOf(0f, 0.78f, 1f), intArrayOf(255, 255, 0))
    val bgInner = FrameLayout(this)
    bgInner.setBackgroundColor(Color.BLACK)
    ovBlur = ImageView(this)
    ovBlur.scaleType = ImageView.ScaleType.CENTER_CROP
    ovBlur.colorFilter = tintFilter(0.5f)
    bgInner.addView(ovBlur, FrameLayout.LayoutParams(mi(2576f), mi(2576f)).apply {
        leftMargin = -mi(708f)
        topMargin = -mi(400f)
    })
    bgInner.addView(View(this).apply { setBackgroundColor(0x59000000) }, FrameLayout.LayoutParams(match, match))
    bgMask.addView(bgInner, FrameLayout.LayoutParams(match, match))
    lyricOverlay.addView(bgMask, FrameLayout.LayoutParams(match, match))
    if (Build.VERSION.SDK_INT >= 31) {
        val blur = RenderEffect.createBlurEffect(m(100f), m(100f), Shader.TileMode.CLAMP)
        ivBlur.setRenderEffect(blur)
        ovBlur.setRenderEffect(blur)
    }

    // kepala: tamnel 150 (sudut 20) di (62,130), judul/artis di x=244 y=160, tombol tutup 120 di kanan
    ovThumb = ImageView(this)
    ovThumb.scaleType = ImageView.ScaleType.CENTER_CROP
    ovThumb.clipToOutline = true
    ovThumb.outlineProvider = object : ViewOutlineProvider() {
        override fun getOutline(v: View, o: Outline) = o.setRoundRect(0, 0, v.width, v.height, m(20f))
    }
    lyricOverlay.addView(ovThumb, FrameLayout.LayoutParams(mi(150f), mi(150f)).apply {
        leftMargin = mi(62f)
        topMargin = mi(130f)
    })
    val head = LinearLayout(this)
    head.orientation = LinearLayout.VERTICAL
    ovTitle = TextView(this).apply {
        setTextSize(TypedValue.COMPLEX_UNIT_PX, m(44f))
        setTypeface(null, Typeface.BOLD)
        setTextColor(Color.WHITE)
        maxLines = 1
        ellipsize = android.text.TextUtils.TruncateAt.END
    }
    ovArtist = TextView(this).apply {
        setTextSize(TypedValue.COMPLEX_UNIT_PX, m(36f))
        setTextColor(0xFFD6D6D6.toInt())
        maxLines = 1
        ellipsize = android.text.TextUtils.TruncateAt.END
    }
    head.addView(ovTitle)
    head.addView(ovArtist, LinearLayout.LayoutParams(match, wrap).apply { topMargin = mi(8f) })
    lyricOverlay.addView(head, FrameLayout.LayoutParams(scaleW.toInt() - mi(244f) - mi(62f + 120f + 24f), wrap).apply {
        leftMargin = mi(244f)
        topMargin = mi(160f)
    })
    val close = ImageButton(this)
    close.setImageResource(R.drawable.ic_down)
    close.setColorFilter(Color.WHITE)
    close.scaleType = ImageView.ScaleType.FIT_CENTER
    close.setPadding(mi(26f), mi(26f), mi(26f), mi(26f))
    close.background = GradientDrawable().apply {
        shape = GradientDrawable.OVAL
        setColor(0x29FFFFFF)
    }
    close.contentDescription = "Tutup lirik"
    close.setOnClickListener { setLyricScreen(false) }
    lyricOverlay.addView(close, FrameLayout.LayoutParams(mi(120f), mi(120f), Gravity.END or Gravity.TOP).apply {
        rightMargin = mi(62f)
        topMargin = mi(115f)
    })

    // daftar lirik: y=330 tinggi 1070, memudar 0-10% dan 78-100%; baris aktif berhenti di y=180 dalam daftar
    val listMask = FadeMask(this)
    listMask.setStops(floatArrayOf(0f, 0.10f, 0.78f, 1f), intArrayOf(0, 255, 255, 0))
    rvLyrics = RecyclerView(this)
    rvLyrics.layoutManager = LinearLayoutManager(this)
    rvLyrics.adapter = lyricAdapter
    rvLyrics.itemAnimator = null
    rvLyrics.overScrollMode = View.OVER_SCROLL_NEVER
    rvLyrics.clipToPadding = false
    rvLyrics.setPadding(0, mi(180f), 0, mi(1070f - 180f - 200f))
    listMask.addView(rvLyrics, FrameLayout.LayoutParams(match, match))
    lyricOverlay.addView(listMask, FrameLayout.LayoutParams(match, mi(1070f)).apply { topMargin = mi(330f) })

    ovEmpty = TextView(this)
    ovEmpty.setTextSize(TypedValue.COMPLEX_UNIT_PX, m(44f))
    ovEmpty.setTextColor(0x99FFFFFF.toInt())
    ovEmpty.gravity = Gravity.CENTER
    ovEmpty.text = lyricStatus
    lyricOverlay.addView(ovEmpty, FrameLayout.LayoutParams(match, wrap).apply {
        topMargin = mi(330f + 400f)
        leftMargin = mi(62f)
        rightMargin = mi(62f)
    })

    npRoot.addView(lyricOverlay, npRoot.indexOfChild(topBox) + 1, FrameLayout.LayoutParams(match, mi(1400f)))
}

/** Buka / tutup layar lirik: layar lirik muncul 0,35 dtk, lirik mini hilang bersamaan. */
internal fun NowPlayingActivity.setLyricScreen(open: Boolean) {
    if (lyricScreenOpen == open) return
    lyricScreenOpen = open
    lyricOverlay.animate().cancel()
    miniWin.animate().cancel()
    if (open) {
        lyricOverlay.visibility = View.VISIBLE
        lyricOverlay.animate().alpha(1f).setDuration(350).start()
        // bagian bawah layar lirik memudar ke transparan; tanpa ini cover tajam di belakangnya kelihatan (tidak ter-blur)
        findViewById<View>(R.id.coverBox).animate().cancel()
        findViewById<View>(R.id.coverBox).animate().alpha(0f).setDuration(350).start()
        miniWin.animate().alpha(0f).setDuration(350).withEndAction { if (lyricScreenOpen) miniWin.visibility = View.INVISIBLE }.start()
        scrollLyricsTo(curLine.coerceAtLeast(0), false)
    } else {
        miniWin.visibility = View.VISIBLE
        miniWin.animate().alpha(1f).setDuration(350).start()
        findViewById<View>(R.id.coverBox).animate().cancel()
        findViewById<View>(R.id.coverBox).animate().alpha(1f).setDuration(350).start()
        lyricOverlay.animate().alpha(0f).setDuration(350).withEndAction { if (!lyricScreenOpen) lyricOverlay.visibility = View.GONE }.start()
    }
}

/** Taruh baris idx di posisi aktif (y=180 dalam daftar); smooth = geser 0,6 dtk. */
internal fun NowPlayingActivity.scrollLyricsTo(idx: Int, smooth: Boolean) {
    if (idx < 0 || idx >= lyricAdapter.itemCount) return
    val lm = rvLyrics.layoutManager as LinearLayoutManager
    if (!smooth) {
        lm.scrollToPositionWithOffset(idx, mi(180f))
        return
    }
    val sc = object : LinearSmoothScroller(this) {
        override fun getVerticalSnapPreference() = SNAP_TO_START
        override fun calculateTimeForScrolling(dx: Int) = 600
        override fun calculateTimeForDeceleration(dx: Int) = 600
    }
    sc.targetPosition = idx
    lm.startSmoothScroll(sc)
}

/**
 * Gaya satu baris lirik. full = layar lirik (redup 0,45, aktif x1,14, redup x0,86, glow 36),
 * bukan full = lirik mini (redup 0,5, aktif x1,15, glow 18). Warna 0,4 dtk, skala 0,6 dtk.
 */
internal fun NowPlayingActivity.styleLine(tv: TextView, state: Int, full: Boolean, animate: Boolean) {
    val on = state == 1
    // lirik mini: hanya baris aktif boleh 2 baris, baris lain 1 baris; "…" baru muncul kalau tidak muat
    if (!full) tv.maxLines = if (on) 2 else 1
    // lirik berikutnya (mini) 5% lebih kecil: 44 -> 41,8 px
    if (!full) tv.setTextSize(TypedValue.COMPLEX_UNIT_PX, m(if (on) 44f else 41.8f))
    val toColor = when (state) {
        1 -> Color.WHITE
        2 -> 0xD9FFFFFF.toInt()
        else -> if (full) 0x73FFFFFF.toInt() else 0x80FFFFFF.toInt()
    }
    val toScale = when {
        on -> if (full) 1.14f else 1.15f
        state == 2 || !full -> 1f
        else -> 0.86f
    }
    val glowR = m(if (full) 36f else 18f)
    val toGlow = if (on) ((if (full) 0.4f else 0.45f) * 255).toInt() else 0
    tv.typeface = if (on || full) Typeface.DEFAULT_BOLD else Typeface.create("sans-serif-medium", Typeface.NORMAL)
    lineAnims.remove(tv)?.cancel()
    tv.animate().cancel()
    if (!animate) {
        tv.scaleX = toScale
        tv.scaleY = toScale
        tv.setTextColor(toColor)
        tv.setShadowLayer(glowR, 0f, 0f, Color.argb(toGlow, 255, 255, 255))
        return
    }
    tv.animate().scaleX(toScale).scaleY(toScale).setDuration(600).setInterpolator(PathInterpolator(0.22f, 1f, 0.36f, 1f)).start()
    val from = tv.currentTextColor
    val fromGlow = Color.alpha(tv.shadowColor)
    val a = ValueAnimator.ofFloat(0f, 1f)
    a.duration = 400
    a.addUpdateListener {
        val t = it.animatedFraction
        tv.setTextColor(ArgbEvaluator().evaluate(t, from, toColor) as Int)
        tv.setShadowLayer(glowR, 0f, 0f, Color.argb((fromGlow + (toGlow - fromGlow) * t).toInt(), 255, 255, 255))
    }
    lineAnims[tv] = a
    a.start()
}

internal fun NowPlayingActivity.miniLine(text: String): TextView {
    val tv = TextView(this)
    tv.setTextSize(TypedValue.COMPLEX_UNIT_PX, m(44f))
    tv.maxLines = 1
    tv.ellipsize = android.text.TextUtils.TruncateAt.END
    // jarak antar baris dipepetin: 54 px untuk teks 44 px (dulu 66)
    TextViewCompat.setLineHeight(tv, mi(54f))
    tv.gravity = Gravity.TOP
    tv.pivotX = 0f
    tv.pivotY = m(27f)
    tv.text = text
    return tv
}

/** Isi ulang lirik mini: satu TextView 480 x 66 per baris, atau satu baris status kalau belum ada lirik. */
internal fun NowPlayingActivity.rebuildMini() {
    miniLines.clear()
    miniCol.removeAllViews()
    val r = lyrics
    if (r == null) {
        val tv = miniLine(lyricStatus)
        styleLine(tv, 0, false, false)
        miniCol.addView(tv, LinearLayout.LayoutParams(mi(480f), ViewGroup.LayoutParams.WRAP_CONTENT))
    } else {
        for ((i, l) in r.lines.withIndex()) {
            val tv = miniLine(l.text.ifEmpty { "…" })
            styleLine(tv, lineState(i), false, false)
            miniCol.addView(tv, LinearLayout.LayoutParams(mi(480f), ViewGroup.LayoutParams.WRAP_CONTENT))
            miniLines.add(tv)
        }
    }
    // tinggi kolom = semua baris; kalau ikut tinggi jendela (132), baris ke-3 dst terpotong dan lirik mini kosong setelah 2 baris pertama
    // tiap lirik bisa 2 baris teks (132), jadi kolom disiapkan selapang itu; posisi baris baru diketahui setelah di-layout
    val rows = maxOf(1, miniCol.childCount)
    miniCol.layoutParams = FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, mi(132f) * rows)
    moveMini(false)
    miniCol.addOnLayoutChangeListener(object : View.OnLayoutChangeListener {
        override fun onLayoutChange(v: View?, l: Int, t: Int, r: Int, b: Int, ol: Int, ot: Int, or2: Int, ob: Int) {
            miniCol.removeOnLayoutChangeListener(this)
            moveMini(false)
        }
    })
}

/**
 * Taruh baris aktif + baris sesudahnya di dasar jendela mini (dasar jendela = posisi lama baris ke-2),
 * jadi blok lirik selalu menempel di atas badge Hi-Res berapa pun tingginya (1-2 baris per lirik).
 * Baris sebelum yang aktif dipudarkan supaya tidak kelihatan di bagian atas jendela.
 */
internal fun NowPlayingActivity.moveMini(animate: Boolean) {
    val winH = mi(264f)
    val start = curLine.coerceAtLeast(0)
    val first = miniLines.getOrNull(start)
    val y = if (first == null) {
        (winH - mi(108f)).toFloat()
    } else {
        val last = miniLines.getOrNull(start + 1) ?: first
        (winH - ((last.top + last.height) - first.top) - first.top).toFloat()
    }
    miniCol.animate().cancel()
    if (animate) {
        miniCol.animate().translationY(y).setDuration(500).setInterpolator(PathInterpolator(0.22f, 0.61f, 0.36f, 1f)).start()
    } else {
        miniCol.translationY = y
    }
    for ((i, tv) in miniLines.withIndex()) {
        fadeAnims.remove(tv)?.cancel()
        val want = if (i < start) 0f else 1f
        if (animate && i == start - 1 && tv.alpha > 0f) {
            val a = android.animation.ObjectAnimator.ofFloat(tv, View.ALPHA, tv.alpha, 0f)
            a.duration = 350
            fadeAnims[tv] = a
            a.start()
        } else {
            tv.alpha = want
        }
    }
}

/** Tinggi baris berubah (aktif 2 baris, lain 1 baris), jadi geser kolom setelah layout selesai. */
internal fun NowPlayingActivity.moveMiniSoon() {
    miniCol.addOnLayoutChangeListener(object : View.OnLayoutChangeListener {
        override fun onLayoutChange(v: View?, l: Int, t: Int, r: Int, b: Int, ol: Int, ot: Int, or2: Int, ob: Int) {
            miniCol.removeOnLayoutChangeListener(this)
            moveMini(true)
        }
    })
    miniCol.requestLayout()
}

internal fun NowPlayingActivity.setLyricStatus(s: String) {
    lyricStatus = s
    ovEmpty.text = s
    if (lyrics == null) rebuildMini()
}

/** Aksi lirik: cari online, pilih file .lrc, tempel / ubah. */
internal fun NowPlayingActivity.lyricActionsSheet() {
    val d = BottomSheetDialog(this)
    val col = LinearLayout(this)
    col.orientation = LinearLayout.VERTICAL
    col.background = GradientDrawable().apply {
        setColor(0xFF1A1A1E.toInt())
        val r = Ui.dp(this@lyricActionsSheet, 24).toFloat()
        cornerRadii = floatArrayOf(r, r, r, r, 0f, 0f, 0f, 0f)
    }
    col.setPadding(Ui.dp(this, 20), Ui.dp(this, 20), Ui.dp(this, 20), Ui.dp(this, 24))
    col.addView(AU.text(this, "Lirik", 20f, Color.WHITE, true))
    fun row(icon: Int, label: String, onClick: () -> Unit) {
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL
        row.minimumHeight = Ui.dp(this, 56)
        val ic = ImageView(this)
        ic.setImageResource(icon)
        ic.setColorFilter(AU.MUT, PorterDuff.Mode.SRC_IN)
        row.addView(ic, LinearLayout.LayoutParams(Ui.dp(this, 22), Ui.dp(this, 22)))
        val lb = AU.text(this, label, 15f, Color.WHITE)
        lb.setPadding(Ui.dp(this, 12), 0, 0, 0)
        row.addView(lb, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        row.setOnClickListener {
            d.dismiss()
            onClick()
        }
        col.addView(row)
    }
    row(R.drawable.ic_cloud, "Cari lirik online") { fetchOnline(true) }
    row(R.drawable.ic_file, "Pilih file lirik") { pickLyricFile.launch(arrayOf("*/*")) }
    row(R.drawable.ic_edit, "Tempel / ubah lirik") { editDialog() }
    d.setContentView(col)
    d.setOnShowListener {
        d.findViewById<View>(com.google.android.material.R.id.design_bottom_sheet)?.setBackgroundColor(Color.TRANSPARENT)
    }
    d.show()
}

internal fun NowPlayingActivity.applyLyrics(r: Lyrics.Result?, status: String = "Belum ada lirik") {
    lyrics = r
    curLine = -1
    lyricAdapter.notifyDataSetChanged()
    rvLyrics.scrollToPosition(0)
    ovEmpty.visibility = if (r == null) View.VISIBLE else View.GONE
    if (r == null) lyricStatus = status
    ovEmpty.text = lyricStatus
    rebuildMini()
}

internal fun NowPlayingActivity.loadTrackLyrics(id: Long?) {
    track = null
    applyLyrics(null, "Memuat lirik...")
    if (id == null) {
        setLyricStatus("Lirik tidak tersedia")
        return
    }
    lifecycleScope.launch {
        val t = withContext(Dispatchers.IO) { Library.track(this@loadTrackLyrics, id) }
        if (lastId != id) return@launch
        track = t
        if (t == null) {
            setLyricStatus("Belum ada lirik")
            return@launch
        }
        val local = withContext(Dispatchers.IO) { Lyrics.loadLocal(this@loadTrackLyrics, t) }
        if (lastId != id) return@launch
        if (local != null) {
            applyLyrics(local)
        } else {
            setLyricStatus("Belum ada lirik")
            if (Prefs.lyricsOnline(this@loadTrackLyrics)) fetchOnline(false)
        }
    }
}

internal fun NowPlayingActivity.fetchOnline(manual: Boolean) {
    val t = track ?: return
    if (lyrics == null) setLyricStatus("Mencari lirik online...")
    lifecycleScope.launch {
        val text = withContext(Dispatchers.IO) { Lyrics.online(t) }
        if (track?.id != t.id) return@launch
        val r = text?.let { Lyrics.parse(it, "LRCLIB") }
        if (r != null) {
            Lyrics.save(this@fetchOnline, t.id, text)
            applyLyrics(r)
        } else {
            if (lyrics == null) setLyricStatus("Belum ada lirik")
            if (manual) Toast.makeText(this@fetchOnline, "Lirik tidak ditemukan / tidak ada internet.", Toast.LENGTH_LONG).show()
        }
    }
}

internal fun NowPlayingActivity.syncLyric(posMs: Long) {
    val r = lyrics ?: return
    if (!r.synced) return
    var idx = -1
    for (i in r.lines.indices) {
        if (r.lines[i].timeMs <= posMs + 250) idx = i else break
    }
    if (idx != curLine) {
        val old = curLine
        curLine = idx
        if (old >= 0) {
            lyricAdapter.notifyItemChanged(old, true)
            miniLines.getOrNull(old)?.let { styleLine(it, 0, false, true) }
        }
        if (idx >= 0) {
            lyricAdapter.notifyItemChanged(idx, true)
            miniLines.getOrNull(idx)?.let { styleLine(it, 1, false, true) }
        }
        moveMiniSoon()
        if (lyricScreenOpen) scrollLyricsTo(idx, true)
    }
}

internal fun NowPlayingActivity.editDialog() {
    val t = track ?: return
    val et = EditText(this)
    et.setText(lyrics?.raw ?: "")
    et.hint = "Tempel lirik di sini (boleh format .lrc dengan waktu [mm:ss.xx])"
    et.minLines = 6
    et.gravity = android.view.Gravity.TOP
    AlertDialog.Builder(this)
        .setTitle("Lirik: ${t.title}")
        .setView(et)
        .setPositiveButton("Simpan") { _, _ ->
            val s = et.text.toString()
            val r = Lyrics.parse(s, "Tersimpan")
            if (r == null) {
                Lyrics.clear(this, t.id)
                applyLyrics(null)
            } else {
                Lyrics.save(this, t.id, s)
                applyLyrics(r)
            }
        }
        .setNeutralButton("Hapus") { _, _ ->
            Lyrics.clear(this, t.id)
            loadTrackLyrics(t.id)
        }
        .setNegativeButton("Batal", null)
        .show()
}
