package com.niven.mangatl

import androidx.media3.common.C
import androidx.media3.common.OverlaySettings
import androidx.media3.common.VideoCompositorSettings
import androidx.media3.common.audio.AudioProcessor
import androidx.media3.common.audio.BaseAudioProcessor
import androidx.media3.common.util.Size
import androidx.media3.effect.Presentation
import androidx.media3.effect.RgbMatrix
import androidx.media3.effect.StaticOverlaySettings
import java.nio.ByteBuffer

// Efek Media3 untuk editor video: pudar gambar (FadeMatrix), pudar suara (FadeVolume), dan pengaturan overlay (OvSpec, OvSettings).

/** Pudar gambar: warna dikalikan pengali kurva (menggelap ke hitam). Waktu = waktu hasil akhir klip. */
internal class FadeMatrix(
    private val durMs: Long,
    private val fade: TimelineView.Fade
) : RgbMatrix {
    override fun getMatrix(presentationTimeUs: Long, useHdr: Boolean): FloatArray {
        val g = TimelineView.fadeGain(presentationTimeUs / 1000L, durMs, fade)
        return floatArrayOf(
            g, 0f, 0f, 0f,
            0f, g, 0f, 0f,
            0f, 0f, g, 0f,
            0f, 0f, 0f, 1f
        )
    }
}

/** Pudar suara lagu: volume mengikuti kurva yang sama dengan di timeline (audio PCM 16-bit). */
internal class FadeVolume(
    private val lenMs: Long,
    private val fade: TimelineView.Fade
) : BaseAudioProcessor() {
    private var frames = 0L

    override fun onConfigure(inputAudioFormat: AudioProcessor.AudioFormat): AudioProcessor.AudioFormat {
        if (inputAudioFormat.encoding != C.ENCODING_PCM_16BIT) {
            throw AudioProcessor.UnhandledAudioFormatException(inputAudioFormat)
        }
        return inputAudioFormat
    }

    override fun queueInput(inputBuffer: ByteBuffer) {
        val ch = inputAudioFormat.channelCount
        val rate = inputAudioFormat.sampleRate
        val n = inputBuffer.remaining() / (2 * ch)
        val out = replaceOutputBuffer(n * 2 * ch)
        for (f in 0 until n) {
            val ms = frames * 1000L / rate
            val g = TimelineView.fadeGain(ms, lenMs, fade)
            for (k in 0 until ch) {
                val v = (inputBuffer.short * g).toInt().coerceIn(-32768, 32767)
                out.putShort(v.toShort())
            }
            frames++
        }
        out.flip()
    }
}

/** Satu input di compositor: waktu tampil, pudar, dan titik tengah (-1..1). hidden = latar penentu waktu (tak terlihat). */
internal class OvSpec(
    val start: Long,
    val len: Long,
    val fade: TimelineView.Fade,
    val ax: Float,
    val ay: Float,
    val hidden: Boolean
)

/**
 * Pengaturan penumpukan. specs[inputId]: null = video utama (frame penuh), hidden = latar kosong,
 * selain itu lapisan: transparansi mengikuti rentang waktu dan kurva pudar. Ukuran lapisan sudah
 * dipatok lewat Presentation, jadi skala 1 = ukuran yang diinginkan.
 */
internal class OvSettings(
    private val specs: List<OvSpec?>,
    private val outW: Int,
    private val outH: Int
) : VideoCompositorSettings {
    override fun getOutputSize(inputSizes: List<Size>): Size = Size(outW, outH)

    override fun getOverlaySettings(inputId: Int, presentationTimeUs: Long): OverlaySettings {
        val s = specs.getOrNull(inputId) ?: return StaticOverlaySettings.Builder().build()
        if (s.hidden) return StaticOverlaySettings.Builder().setAlphaScale(0f).build()
        val t = presentationTimeUs / 1000L - s.start
        val g = if (t < 0L || t >= s.len) 0f else TimelineView.fadeGain(t, s.len, s.fade)
        return StaticOverlaySettings.Builder()
            .setAlphaScale(g)
            .setBackgroundFrameAnchor(s.ax, s.ay)
            .build()
    }
}
