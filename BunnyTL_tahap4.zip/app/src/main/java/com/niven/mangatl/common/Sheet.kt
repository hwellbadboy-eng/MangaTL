package com.niven.mangatl

import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.GradientDrawable
import android.text.Editable
import android.text.InputType
import android.text.TextUtils
import android.text.TextWatcher
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import androidx.appcompat.app.AlertDialog
import androidx.core.content.ContextCompat

/** Popup minimalis sesuai tema BunnyTL: kartu gelap, sudut bulat, tanpa garis bawaan Android. */
object Sheet {

    class Item(
        val label: String,
        val icon: Int,
        val danger: Boolean = false,
        val sub: String? = null,
        val action: () -> Unit
    )

    private val DANGER = Color.parseColor("#FF6B6B")
    private val TEXT = Color.parseColor("#EDEDED")
    private val SEL_BG = Color.parseColor("#1C1C1E")

    private fun dp(ctx: Context, v: Int) = Ui.dp(ctx, v)
    private fun clr(ctx: Context, id: Int) = ContextCompat.getColor(ctx, id)

    private fun panel(ctx: Context) = LinearLayout(ctx).apply {
        orientation = LinearLayout.VERTICAL
        setBackgroundResource(R.drawable.bg_popup)
        setPadding(dp(ctx, 8), dp(ctx, 18), dp(ctx, 8), dp(ctx, 8))
    }

    private fun head(ctx: Context, p: LinearLayout, title: String, sub: String?) {
        p.addView(TextView(ctx).apply {
            text = title
            textSize = 16f
            typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
            setTextColor(Color.WHITE)
            maxLines = 2
            ellipsize = TextUtils.TruncateAt.END
            setPadding(dp(ctx, 12), 0, dp(ctx, 12), dp(ctx, if (sub == null) 10 else 2))
        })
        if (sub != null) {
            p.addView(TextView(ctx).apply {
                text = sub
                textSize = 12f
                setTextColor(clr(ctx, R.color.muted))
                maxLines = 1
                ellipsize = TextUtils.TruncateAt.END
                setPadding(dp(ctx, 12), 0, dp(ctx, 12), dp(ctx, 10))
            })
        }
    }

    private fun message(ctx: Context, p: LinearLayout, text: String) {
        p.addView(TextView(ctx).apply {
            this.text = text
            textSize = 14f
            setTextColor(clr(ctx, R.color.text_soft))
            setLineSpacing(0f, 1.15f)
            setPadding(dp(ctx, 12), 0, dp(ctx, 12), dp(ctx, 8))
        })
    }

    private fun divider(ctx: Context) = View(ctx).apply {
        setBackgroundColor(clr(ctx, R.color.card_stroke))
        layoutParams = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, dp(ctx, 1)
        ).apply { setMargins(dp(ctx, 12), dp(ctx, 6), dp(ctx, 12), dp(ctx, 6)) }
    }

    private fun show(ctx: Context, v: View): AlertDialog {
        val d = AlertDialog.Builder(ctx).setView(v).create()
        d.window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        d.show()
        d.window?.setLayout(
            (ctx.resources.displayMetrics.widthPixels * 0.9f).toInt(),
            WindowManager.LayoutParams.WRAP_CONTENT
        )
        return d
    }

    private fun row(
        ctx: Context, icon: Int, label: String, sub: String?,
        textColor: Int, tint: Int, selected: Boolean, onClick: () -> Unit
    ): View {
        val r = LinearLayout(ctx)
        r.orientation = LinearLayout.HORIZONTAL
        r.gravity = Gravity.CENTER_VERTICAL
        r.setPadding(dp(ctx, 12), dp(ctx, 12), dp(ctx, 12), dp(ctx, 12))
        if (selected) {
            r.background = GradientDrawable().apply {
                setColor(SEL_BG)
                cornerRadius = dp(ctx, 12).toFloat()
            }
        } else {
            val tv = TypedValue()
            ctx.theme.resolveAttribute(android.R.attr.selectableItemBackground, tv, true)
            r.setBackgroundResource(tv.resourceId)
        }
        r.setOnClickListener { onClick() }
        val iv = ImageView(ctx)
        iv.setImageResource(icon)
        iv.setColorFilter(tint)
        iv.layoutParams = LinearLayout.LayoutParams(dp(ctx, 20), dp(ctx, 20))
        r.addView(iv)
        val col = LinearLayout(ctx)
        col.orientation = LinearLayout.VERTICAL
        col.layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            .apply { marginStart = dp(ctx, 14) }
        col.addView(TextView(ctx).apply {
            text = label
            textSize = 15f
            setTextColor(textColor)
        })
        if (sub != null) {
            col.addView(TextView(ctx).apply {
                text = sub
                textSize = 12f
                setTextColor(clr(ctx, R.color.muted))
                maxLines = 1
                ellipsize = TextUtils.TruncateAt.END
            })
        }
        r.addView(col)
        return r
    }

    private fun btn(ctx: Context, label: String, primary: Boolean, danger: Boolean, onClick: () -> Unit) =
        TextView(ctx).apply {
            text = label
            textSize = 14f
            setPadding(dp(ctx, 18), dp(ctx, 10), dp(ctx, 18), dp(ctx, 10))
            if (primary) {
                typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
                setTextColor(if (danger) Color.parseColor("#FF8A8A") else Color.parseColor("#000000"))
                background = GradientDrawable().apply {
                    setColor(if (danger) Color.parseColor("#3A1D1F") else Color.parseColor("#F2F2F2"))
                    cornerRadius = dp(ctx, 14).toFloat()
                }
            } else {
                setTextColor(clr(ctx, R.color.text_soft))
            }
            setOnClickListener { onClick() }
        }

    private fun buttons(ctx: Context, vararg b: View): View = LinearLayout(ctx).apply {
        orientation = LinearLayout.HORIZONTAL
        gravity = Gravity.END or Gravity.CENTER_VERTICAL
        setPadding(dp(ctx, 8), dp(ctx, 8), dp(ctx, 4), dp(ctx, 4))
        b.forEachIndexed { i, v ->
            addView(v)
            if (i < b.size - 1) addView(View(ctx), dp(ctx, 8), 1)
        }
    }

    /** Menu aksi. Item null = garis pemisah. */
    fun menu(ctx: Context, title: String, sub: String?, items: List<Item?>) {
        val p = panel(ctx)
        head(ctx, p, title, sub)
        val box = LinearLayout(ctx)
        box.orientation = LinearLayout.VERTICAL
        var dlg: AlertDialog? = null
        for (item in items) {
            if (item == null) {
                box.addView(divider(ctx))
                continue
            }
            val c = if (item.danger) DANGER else TEXT
            val t = if (item.danger) DANGER else clr(ctx, R.color.text_soft)
            box.addView(row(ctx, item.icon, item.label, item.sub, c, t, false) {
                dlg?.dismiss()
                item.action()
            })
        }
        p.addView(ScrollView(ctx).apply { addView(box) })
        dlg = show(ctx, p)
    }

    /** Pilihan tunggal bergaya radio. rows = (judul, keterangan kecil). */
    fun choice(
        ctx: Context, title: String, sub: String?, rows: List<Pair<String, String?>>,
        selected: Int, onPick: (Int) -> Unit
    ) {
        val p = panel(ctx)
        head(ctx, p, title, sub)
        val box = LinearLayout(ctx)
        box.orientation = LinearLayout.VERTICAL
        var dlg: AlertDialog? = null
        rows.forEachIndexed { i, r ->
            val on = i == selected
            box.addView(
                row(
                    ctx, if (on) R.drawable.ic_radio_on else R.drawable.ic_radio_off,
                    r.first, r.second, TEXT, if (on) Color.WHITE else clr(ctx, R.color.hint), on
                ) {
                    dlg?.dismiss()
                    onPick(i)
                }
            )
        }
        p.addView(ScrollView(ctx).apply { addView(box) })
        p.addView(buttons(ctx, btn(ctx, "Batal", false, false) { dlg?.dismiss() }))
        dlg = show(ctx, p)
    }

    fun confirm(
        ctx: Context, title: String, msg: String, ok: String, danger: Boolean, onOk: () -> Unit
    ) {
        val p = panel(ctx)
        head(ctx, p, title, null)
        message(ctx, p, msg)
        var dlg: AlertDialog? = null
        p.addView(
            buttons(
                ctx,
                btn(ctx, "Batal", false, false) { dlg?.dismiss() },
                btn(ctx, ok, true, danger) {
                    dlg?.dismiss()
                    onOk()
                }
            )
        )
        dlg = show(ctx, p)
    }

    fun input(ctx: Context, title: String, hint: String, initial: String, ok: String, onOk: (String) -> Unit) =
        form(ctx, title, null, listOf(hint to initial), ok) { onOk(it[0]) }

    /** Form beberapa kolom teks. fields = (label, isi awal). */
    fun form(
        ctx: Context, title: String, note: String?, fields: List<Pair<String, String>>,
        ok: String, onOk: (List<String>) -> Unit
    ) {
        val p = panel(ctx)
        head(ctx, p, title, null)
        val ets = ArrayList<EditText>()
        for (f in fields) {
            p.addView(TextView(ctx).apply {
                text = f.first
                textSize = 11f
                setTextColor(clr(ctx, R.color.muted))
                setPadding(dp(ctx, 14), dp(ctx, 4), dp(ctx, 14), dp(ctx, 4))
            })
            val et = EditText(ctx)
            et.setText(f.second)
            et.setSelection(et.text.length)
            et.setSingleLine(true)
            et.inputType = InputType.TYPE_CLASS_TEXT
            et.textSize = 15f
            et.setTextColor(TEXT)
            et.setBackgroundResource(R.drawable.bg_field)
            et.setPadding(dp(ctx, 14), dp(ctx, 12), dp(ctx, 14), dp(ctx, 12))
            et.layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply { setMargins(dp(ctx, 12), 0, dp(ctx, 12), dp(ctx, 8)) }
            p.addView(et)
            ets.add(et)
        }
        if (note != null) message(ctx, p, note)
        var dlg: AlertDialog? = null
        p.addView(
            buttons(
                ctx,
                btn(ctx, "Batal", false, false) { dlg?.dismiss() },
                btn(ctx, ok, true, false) {
                    val v = ets.map { it.text.toString() }
                    dlg?.dismiss()
                    onOk(v)
                }
            )
        )
        val shown = show(ctx, p)
        dlg = shown
        ets.firstOrNull()?.requestFocus()
        shown.window?.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_VISIBLE)
    }

    /** Daftar panjang dengan kolom cari (dipakai untuk memilih lagu). */
    fun pickList(
        ctx: Context, title: String, labels: List<String>, subs: List<String>, icon: Int,
        onPick: (Int) -> Unit
    ) {
        val p = panel(ctx)
        head(ctx, p, title, null)
        val et = EditText(ctx)
        et.hint = "Cari"
        et.setSingleLine(true)
        et.textSize = 15f
        et.setTextColor(TEXT)
        et.setHintTextColor(clr(ctx, R.color.hint))
        et.setBackgroundResource(R.drawable.bg_field)
        et.setPadding(dp(ctx, 14), dp(ctx, 12), dp(ctx, 14), dp(ctx, 12))
        et.layoutParams = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT
        ).apply { setMargins(dp(ctx, 12), 0, dp(ctx, 12), dp(ctx, 8)) }
        p.addView(et)
        val box = LinearLayout(ctx)
        box.orientation = LinearLayout.VERTICAL
        val sv = ScrollView(ctx)
        sv.addView(box)
        sv.layoutParams = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, dp(ctx, 360)
        )
        p.addView(sv)
        var dlg: AlertDialog? = null
        fun fill() {
            box.removeAllViews()
            val q = et.text.toString().trim().lowercase()
            var n = 0
            for (i in labels.indices) {
                if (q.isNotEmpty() && !labels[i].lowercase().contains(q) && !subs[i].lowercase().contains(q)) continue
                box.addView(row(ctx, icon, labels[i], subs[i], TEXT, clr(ctx, R.color.text_soft), false) {
                    dlg?.dismiss()
                    onPick(i)
                })
                if (++n >= 80) break
            }
        }
        et.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun afterTextChanged(s: Editable?) = fill()
        })
        fill()
        p.addView(buttons(ctx, btn(ctx, "Batal", false, false) { dlg?.dismiss() }))
        dlg = show(ctx, p)
    }

    /** Dialog kosong bergaya sama; pemanggil mengisi isinya sendiri. */
    fun custom(ctx: Context, title: String, build: (LinearLayout, () -> Unit) -> Unit): AlertDialog {
        val p = panel(ctx)
        head(ctx, p, title, null)
        var dlg: AlertDialog? = null
        build(p) { dlg?.dismiss() }
        val shown = show(ctx, p)
        dlg = shown
        return shown
    }

    fun button(ctx: Context, label: String, primary: Boolean, onClick: () -> Unit): View =
        btn(ctx, label, primary, false, onClick)

    fun buttonRow(ctx: Context, vararg b: View): View = buttons(ctx, *b)
}
