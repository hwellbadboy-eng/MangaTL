package com.niven.mangatl

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat

/** Menjaga proses tetap hidup (notifikasi progres) selama ada unduhan berjalan. Antreannya sendiri ada di DlQueue. */
class DlService : Service() {
    private var started = false
    private val listener: () -> Unit = { update() }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        DlNotify.ensureChannels(this)
        if (intent?.action == ACTION_CANCEL) {
            intent.getStringExtra(EXTRA_ID)?.let { DlQueue.cancel(it) }
        }
        if (!started) {
            started = true
            val n = DlNotify.progress(this)
            if (Build.VERSION.SDK_INT >= 29) {
                startForeground(NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC)
            } else {
                startForeground(NOTIF_ID, n)
            }
            DlQueue.addListener(listener)
        }
        update()
        return START_NOT_STICKY
    }

    private fun update() {
        if (!DlQueue.hasActive()) {
            stopForeground(STOP_FOREGROUND_REMOVE)
            stopSelf()
            return
        }
        NotificationManagerCompat.from(this).notify(NOTIF_ID, DlNotify.progress(this))
    }

    override fun onDestroy() {
        DlQueue.removeListener(listener)
        super.onDestroy()
    }

    companion object {
        const val NOTIF_ID = 4101
        const val ACTION_CANCEL = "com.niven.mangatl.DL_CANCEL"
        const val EXTRA_ID = "id"

        fun start(ctx: Context) {
            ContextCompat.startForegroundService(ctx, Intent(ctx, DlService::class.java))
        }
    }
}

object DlNotify {
    const val CH_PROGRESS = "bunny_dl_progress"
    const val CH_DONE = "bunny_dl_done"

    fun ensureChannels(ctx: Context) {
        if (Build.VERSION.SDK_INT < 26) return
        val nm = ctx.getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CH_PROGRESS, "Unduhan berjalan", NotificationManager.IMPORTANCE_LOW)
        )
        nm.createNotificationChannel(
            NotificationChannel(CH_DONE, "Unduhan selesai", NotificationManager.IMPORTANCE_DEFAULT)
        )
    }

    private fun openApp(ctx: Context): PendingIntent = PendingIntent.getActivity(
        ctx, 0, Intent(ctx, DownloadActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP),
        PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
    )

    fun progress(ctx: Context): Notification {
        val running = DlQueue.tasks.lastOrNull { it.state == DlTask.State.RUNNING }
        val waiting = DlQueue.tasks.count { it.state == DlTask.State.QUEUED }
        val b = NotificationCompat.Builder(ctx, CH_PROGRESS)
            .setSmallIcon(android.R.drawable.stat_sys_download)
            .setContentTitle(running?.title ?: "Unduhan BunnyTL")
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setContentIntent(openApp(ctx))
        if (running != null) {
            val pct = running.progress.toInt().coerceIn(0, 100)
            val eta = if (running.eta > 0) " · sisa ${DlOptions.duration(running.eta)}" else ""
            val extra = if (waiting > 0) " · +$waiting antre" else ""
            if (running.progress > 0f) {
                val sz = DlOptions.progressText(running.doneBytes, running.totalBytes).let { if (it.isEmpty()) "" else " · $it" }
                val sp = DlOptions.speedText(running.speed).let { if (it.isEmpty()) "" else " · $it" }
                b.setContentText("${running.note} $pct%$sz$sp$eta$extra")
                b.setProgress(100, pct, false)
            } else {
                b.setContentText("${running.note}$extra")
                b.setProgress(0, 0, true)
            }
            val cancel = PendingIntent.getService(
                ctx, running.id.hashCode(),
                Intent(ctx, DlService::class.java).setAction(DlService.ACTION_CANCEL)
                    .putExtra(DlService.EXTRA_ID, running.id),
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            )
            b.addAction(0, "Batal", cancel)
        } else {
            b.setContentText(if (waiting > 0) "$waiting menunggu" else "Menyiapkan…")
            b.setProgress(0, 0, true)
        }
        return b.build()
    }

    fun finished(ctx: Context, t: DlTask) {
        val text = when (t.state) {
            DlTask.State.DONE -> "Selesai · tersimpan di ${DlStore.folderLabel(t.audio)}"
            DlTask.State.FAILED -> "Gagal: ${t.error ?: "tidak diketahui"}"
            else -> return
        }
        ensureChannels(ctx)
        val n = NotificationCompat.Builder(ctx, CH_DONE)
            .setSmallIcon(
                if (t.state == DlTask.State.DONE) android.R.drawable.stat_sys_download_done
                else android.R.drawable.stat_notify_error
            )
            .setContentTitle(t.title)
            .setContentText(text)
            .setStyle(NotificationCompat.BigTextStyle().bigText(text))
            .setAutoCancel(true)
            .setContentIntent(openApp(ctx))
            .build()
        runCatching { NotificationManagerCompat.from(ctx).notify(5000 + (t.id.hashCode() and 0xFFFF), n) }
    }
}
