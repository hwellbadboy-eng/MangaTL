package com.niven.mangatl

import android.content.ContentUris
import android.content.Context
import android.graphics.Bitmap
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Build
import android.provider.MediaStore
import android.util.LruCache
import android.util.Size
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import kotlinx.coroutines.withContext

/**
 * Satu baris daftar. Kalau [thumbs] berisi 2+ gambar, ditampilkan mosaik 4 kotak;
 * kalau tidak, satu thumbnail ([thumb]). [icon] jadi pengganti selama thumbnail belum ada.
 */
class Row(
    val title: String,
    val sub: String,
    val icon: Int,
    val thumb: Uri? = null,
    val thumbs: List<Uri> = emptyList(),
    val video: Boolean = false,
    val badge: String? = null,
    val progress: Int = -1,
    val status: String? = null,
    val statusDone: Boolean = false,
    val onLong: (() -> Unit)? = null,
    val onClick: () -> Unit
)

/** Pemuat thumbnail dengan cache memori. Video MKV/frame hitam dicoba ulang lewat MediaMetadataRetriever. */
object Thumbs {
    private val cache = object : LruCache<String, Bitmap>(32 * 1024 * 1024) {
        override fun sizeOf(key: String, value: Bitmap) = value.byteCount
    }
    private val miss = HashSet<String>()
    private val gate = Semaphore(4)
    private val ffGate = Semaphore(2)

    fun load(scope: CoroutineScope, iv: ImageView, uri: Uri?, size: Int, video: Boolean) {
        if (uri == null) {
            iv.tag = null
            iv.setImageDrawable(null)
            return
        }
        val key = "$uri@$size"
        iv.tag = key
        val hit = cache.get(key)
        if (hit != null) {
            iv.setImageBitmap(hit)
            return
        }
        iv.setImageDrawable(null)
        if (miss.contains(key)) return
        scope.launch {
            val bmp = withContext(Dispatchers.IO) { gate.withPermit { decode(iv.context, uri, size, video) } }
            if (bmp != null) {
                cache.put(key, bmp)
                if (iv.tag == key) iv.setImageBitmap(bmp)
            } else {
                miss.add(key)
            }
        }
    }

    @Suppress("DEPRECATION")
    private fun system(ctx: Context, uri: Uri, size: Int, video: Boolean): Bitmap? = try {
        if (Build.VERSION.SDK_INT >= 29) {
            ctx.contentResolver.loadThumbnail(uri, Size(size, size), null)
        } else if (video) {
            MediaStore.Video.Thumbnails.getThumbnail(
                ctx.contentResolver, ContentUris.parseId(uri),
                MediaStore.Video.Thumbnails.MINI_KIND, null
            )
        } else null
    } catch (e: Exception) {
        null
    }

    private fun mostlyBlack(b: Bitmap): Boolean = try {
        val sw = if (Build.VERSION.SDK_INT >= 26 && b.config == Bitmap.Config.HARDWARE) {
            b.copy(Bitmap.Config.ARGB_8888, false)
        } else b
        var sum = 0L
        var n = 0
        for (i in 1..8) for (j in 1..8) {
            val px = sw.getPixel(sw.width * i / 9, sw.height * j / 9)
            sum += ((px shr 16) and 255) + ((px shr 8) and 255) + (px and 255)
            n += 3
        }
        n > 0 && sum / n < 12
    } catch (e: Exception) {
        false
    }

    /** Ambil frame dari tengah-awal video (untuk MKV atau saat frame pertama hitam) lewat decoder bawaan HP. */
    private fun frame(ctx: Context, uri: Uri, size: Int): Bitmap? {
        val r = MediaMetadataRetriever()
        return try {
            try {
                r.setDataSource(ctx, uri)
            } catch (e: Exception) {
                // Beberapa HP gagal membuka content:// langsung; coba lewat file descriptor.
                val pfd = ctx.contentResolver.openFileDescriptor(uri, "r") ?: return null
                pfd.use { r.setDataSource(it.fileDescriptor) }
            }
            val dur = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L
            val times = if (dur > 0) listOf(minOf(dur / 10, 8000L), dur / 2) else listOf(1000L)
            var best: Bitmap? = null
            for (t in times) {
                val f = r.getFrameAtTime(t * 1000, MediaMetadataRetriever.OPTION_CLOSEST_SYNC)
                    ?: r.getFrameAtTime(t * 1000, MediaMetadataRetriever.OPTION_CLOSEST)
                    ?: continue
                best = f
                if (!mostlyBlack(f)) break
            }
            scaleTo(best, size)
        } catch (e: Exception) {
            null
        } finally {
            try { r.release() } catch (e: Exception) { }
        }
    }

    private fun scaleTo(b: Bitmap?, size: Int): Bitmap? {
        if (b == null) return null
        val sc = size.toFloat() / maxOf(b.width, b.height)
        return if (sc < 1f) Bitmap.createScaledBitmap(
            b, (b.width * sc).toInt().coerceAtLeast(1), (b.height * sc).toInt().coerceAtLeast(1), true
        ) else b
    }

    @Suppress("DEPRECATION")
    private fun pathOf(ctx: Context, uri: Uri): String? = try {
        ctx.contentResolver.query(uri, arrayOf(MediaStore.MediaColumns.DATA), null, null, null)?.use { c ->
            if (c.moveToFirst()) c.getString(0) else null
        }
    } catch (e: Exception) {
        null
    }

    /**
     * Cadangan terakhir: ambil frame lewat FFmpeg (library nextlib-mediainfo), jadi codec yang tidak didukung
     * decoder bawaan HP (HEVC 10-bit, dll.) tetap bisa punya thumbnail. Dipanggil lewat refleksi supaya aplikasi
     * tetap jalan (tanpa thumbnail tambahan) kalau library-nya tidak ada.
     */
    private fun ffmpegFrame(ctx: Context, uri: Uri, size: Int): Bitmap? {
        return try {
            val cls = Class.forName("io.github.anilbeesetti.nextlib.mediainfo.MediaInfoBuilder")
            val builder = cls.getDeclaredConstructor().newInstance()
            var ready: Any? = null
            try {
                ready = cls.getMethod("from", Context::class.java, Uri::class.java).invoke(builder, ctx, uri)
            } catch (e: Throwable) {
            }
            if (ready == null) {
                val path = pathOf(ctx, uri) ?: return null
                ready = cls.getMethod("from", String::class.java).invoke(builder, path)
            }
            val info = cls.getMethod("build").invoke(ready ?: builder) ?: return null
            try {
                scaleTo(grab(info), size)
            } finally {
                try {
                    info.javaClass.getMethod("release").invoke(info)
                } catch (e: Throwable) {
                }
            }
        } catch (e: Throwable) {
            null
        }
    }

    /** MediaInfo.getFrame(long) punya parameter (tidak ada versi tanpa parameter), jadi harus dipanggil dengan -1L (= sepertiga durasi). */
    private fun grab(info: Any): Bitmap? {
        for (name in listOf("getFrame", "getFrameAt")) {
            try {
                val b = info.javaClass.getMethod(name, java.lang.Long.TYPE).invoke(info, -1L) as? Bitmap
                if (b != null) return b
            } catch (e: Throwable) {
            }
        }
        return null
    }

    private fun decode(ctx: Context, uri: Uri, size: Int, video: Boolean): Bitmap? {
        var bmp = system(ctx, uri, size, video)
        if (video && (bmp == null || mostlyBlack(bmp))) {
            val f = frame(ctx, uri, size)
            if (f != null && !mostlyBlack(f)) return f
            if (f != null) bmp = f
        }
        if (video && (bmp == null || mostlyBlack(bmp))) {
            // Berat dan lambat, jadi dibatasi 2 sekaligus.
            val ff = try {
                kotlinx.coroutines.runBlocking { ffGate.withPermit { ffmpegFrame(ctx, uri, size) } }
            } catch (e: Throwable) {
                null
            }
            if (ff != null) bmp = ff
        }
        return bmp
    }
}

class RowAdapter(private val scope: CoroutineScope) : RecyclerView.Adapter<RowAdapter.VH>() {

    /** Ukuran cover/thumbnail (dp). Layar musik memakai yang lebih besar. */
    var coverDp = 64

    var rows: List<Row> = emptyList()
        set(v) {
            field = v
            notifyDataSetChanged()
        }

    class VH(v: View) : RecyclerView.ViewHolder(v) {
        val wrap: View = v.findViewById(R.id.thumbWrap)
        val place: ImageView = v.findViewById(R.id.ivPlace)
        val img: ImageView = v.findViewById(R.id.ivThumb)
        val mosaic: LinearLayout = v.findViewById(R.id.mosaic)
        val tiles: List<ImageView> = listOf(
            v.findViewById(R.id.m0), v.findViewById(R.id.m1),
            v.findViewById(R.id.m2), v.findViewById(R.id.m3)
        )
        val badge: TextView = v.findViewById(R.id.tvBadge)
        val bar: ProgressBar = v.findViewById(R.id.pbWatch)
        val title: TextView = v.findViewById(R.id.tvTitle)
        val sub: TextView = v.findViewById(R.id.tvSub)
        val status: TextView = v.findViewById(R.id.tvStatus)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH =
        VH(LayoutInflater.from(parent.context).inflate(R.layout.item_row, parent, false))

    override fun getItemCount() = rows.size

    override fun onBindViewHolder(h: VH, pos: Int) {
        val r = rows[pos]
        val d = h.itemView.resources.displayMetrics.density
        val wDp = if (r.video) 108 else coverDp
        val lp = h.wrap.layoutParams
        lp.width = (wDp * d).toInt()
        lp.height = (coverDp * d).toInt()
        h.wrap.layoutParams = lp

        h.title.text = r.title
        h.sub.text = r.sub
        h.sub.visibility = if (r.sub.isEmpty()) View.GONE else View.VISIBLE
        h.place.setImageResource(r.icon)
        h.badge.visibility = if (r.badge == null) View.GONE else View.VISIBLE
        h.badge.text = r.badge ?: ""
        if (r.status != null) {
            h.status.visibility = View.VISIBLE
            h.status.text = r.status
            h.status.setTextColor(if (r.statusDone) 0xFF66BB6A.toInt() else 0xFFFFB74D.toInt())
        } else {
            h.status.visibility = View.GONE
        }
        if (r.progress in 0..100) {
            h.bar.visibility = View.VISIBLE
            h.bar.progress = r.progress
        } else {
            h.bar.visibility = View.GONE
        }

        if (r.thumbs.size >= 2) {
            h.img.visibility = View.GONE
            h.mosaic.visibility = View.VISIBLE
            val tile = (wDp / 2.0 * d * 2).toInt()
            h.tiles.forEachIndexed { i, iv -> Thumbs.load(scope, iv, r.thumbs.getOrNull(i), tile, r.video) }
        } else {
            h.mosaic.visibility = View.GONE
            h.img.visibility = View.VISIBLE
            Thumbs.load(scope, h.img, r.thumb ?: r.thumbs.firstOrNull(), (wDp * d * 2).toInt(), r.video)
        }

        h.itemView.setOnClickListener { r.onClick() }
        val lg = r.onLong
        if (lg != null) {
            h.itemView.setOnLongClickListener { lg(); true }
        } else {
            h.itemView.setOnLongClickListener(null)
            h.itemView.isLongClickable = false
        }
    }
}
