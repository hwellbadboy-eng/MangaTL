package com.niven.mangatl

import android.content.Context
import android.text.Editable
import android.text.TextWatcher
import android.view.ViewGroup
import android.widget.EditText
import android.widget.TextView
import androidx.appcompat.app.AlertDialog

/**
 * 7 slot System Prompt untuk chat Gemma. Tiap slot bisa diedit, diaktifkan, dan dimatikan sendiri-sendiri.
 * Slot aktif digabung otomatis (compose) jadi satu blok singkat di system prompt chat.
 * Teks bawaan sengaja pendek: prefill cepat, dan model kecil lebih patuh pada aturan yang ringkas.
 * Penerjemah dan OCR tidak memakai slot ini, jadi tidak terpengaruh.
 */
object PromptSlots {
    private const val PREF_FILE = "mangatl"

    class Slot(val key: String, val title: String, val default: String)

    val SLOTS = listOf(
        Slot(
            "personality", "1. Personality",
            "Kepribadian: natural, dewasa, humoris, hangat, romantis, dan sedikit genit dengan cara menggoda yang ringan dan elegan. Bicara seperti teman dekat yang cerdas."
        ),
        Slot(
            "instruction", "2. Instruction",
            "Patuhi perintah pengguna persis: format, bahasa, panjang, dan batasan yang diminta. Kalau ada beberapa perintah, kerjakan semuanya berurutan. Jangan menambah hal yang tidak diminta."
        ),
        Slot(
            "reasoning", "3. Reasoning",
            "Pahami maksud sebenarnya dulu. Pikirkan langkahnya secara singkat dan cek logikanya, lalu tampilkan kesimpulan dengan alasan yang penting saja."
        ),
        Slot(
            "memory", "4. Context & Memory",
            "Jaga kesinambungan: ingat nama, preferensi, dan hal yang sudah dibahas di percakapan ini. Sambungkan jawaban dengan pesan sebelumnya dan jangan menanyakan ulang hal yang sudah dijawab."
        ),
        Slot(
            "control", "5. Response Control",
            "Langsung ke inti tanpa basa-basi pembuka. Jangan mengulang kalimat atau ide yang sama, jangan kaku seperti robot, dan hindari penjelasan bertele-tele. Panjang jawaban menyesuaikan pertanyaan."
        ),
        Slot(
            "honesty", "6. Honesty",
            "Jujur. Kalau tidak tahu atau tidak yakin, katakan terus terang. Jangan mengarang fakta, angka, atau sumber. Bedakan fakta dan perkiraan."
        ),
        Slot(
            "mature", "7. Mature Behavior",
            "Bersikap dewasa dan ekspresif: tangkap suasana pengguna (santai, sedih, serius, bercanda) lalu sesuaikan nada, emosi, dan gaya bicara."
        )
    )

    private fun p(ctx: Context) = ctx.getSharedPreferences(PREF_FILE, Context.MODE_PRIVATE)

    fun isOn(ctx: Context, s: Slot) = p(ctx).getBoolean("ps_on_" + s.key, true)

    fun textOf(ctx: Context, s: Slot): String = p(ctx).getString("ps_txt_" + s.key, null) ?: s.default

    /** Gabungan semua slot aktif (kosong kalau semua mati). Slot yang teksnya kosong dilewati. */
    fun compose(ctx: Context): String {
        val sb = StringBuilder()
        for (s in SLOTS) {
            if (!isOn(ctx, s)) continue
            val t = textOf(ctx, s).trim().take(600)
            if (t.isEmpty()) continue
            sb.append("- ").append(t).append('\n')
        }
        return if (sb.isEmpty()) "" else "Aturan perilaku:\n$sb"
    }

    private fun estTokens(chars: Int) = (chars / 3.5).toInt()

    fun show(ctx: Context) {
        val box = Ui.box(ctx)
        val total = TextView(ctx).apply { textSize = 13f; alpha = 0.8f }

        fun refreshTotal() {
            val n = estTokens(compose(ctx).length)
            total.text = "Perkiraan: ±$n token untuk semua slot aktif (makin kecil, makin cepat)."
        }

        box.addView(TextView(ctx).apply {
            text = "Nama, catatan, dan slot yang aktif dipakai di chat. Penerjemah tidak terpengaruh."
            textSize = 13f
            alpha = 0.8f
        })
        box.addView(total)

        // Nama panggilan & catatan (dulu di Opsi utama): dibaca chat dari kunci "nick" dan "notes".
        fun field(key: String, hint: String, lines: Int, multi: Boolean) = EditText(ctx).apply {
            this.hint = hint
            setText(p(ctx).getString(key, "") ?: "")
            textSize = 13f
            maxLines = lines
            inputType = if (multi) {
                android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_FLAG_MULTI_LINE
            } else {
                android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_FLAG_CAP_WORDS
            }
            addTextChangedListener(object : TextWatcher {
                override fun beforeTextChanged(a: CharSequence?, b: Int, c: Int, d: Int) {}
                override fun onTextChanged(a: CharSequence?, b: Int, c: Int, d: Int) {}
                override fun afterTextChanged(e: Editable?) {
                    p(ctx).edit().putString(key, e?.toString()?.trim() ?: "").apply()
                }
            })
        }
        box.addView(Ui.section(ctx, "Tentang kamu"))
        box.addView(field("nick", "Nama panggilan (dipakai AI di chat)", 1, false))
        box.addView(field("notes", "Catatan buat AI (hal yang harus selalu diingat tentang kamu)", 4, true))
        box.addView(Ui.section(ctx, "Slot System Prompt"))

        for (s in SLOTS) {
            box.addView(Ui.switchRow(ctx, s.title, isOn(ctx, s)) {
                p(ctx).edit().putBoolean("ps_on_" + s.key, it).apply()
                refreshTotal()
            })
            val et = EditText(ctx).apply {
                setText(textOf(ctx, s))
                textSize = 13f
                minLines = 2
                maxLines = 6
                inputType = android.text.InputType.TYPE_CLASS_TEXT or
                    android.text.InputType.TYPE_TEXT_FLAG_MULTI_LINE or
                    android.text.InputType.TYPE_TEXT_FLAG_CAP_SENTENCES
                layoutParams = ViewGroup.MarginLayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
                )
            }
            et.addTextChangedListener(object : TextWatcher {
                override fun beforeTextChanged(a: CharSequence?, b: Int, c: Int, d: Int) {}
                override fun onTextChanged(a: CharSequence?, b: Int, c: Int, d: Int) {}
                override fun afterTextChanged(e: Editable?) {
                    p(ctx).edit().putString("ps_txt_" + s.key, e?.toString() ?: "").apply()
                    refreshTotal()
                }
            })
            box.addView(et)
        }
        refreshTotal()

        AlertDialog.Builder(ctx)
            .setTitle("Prompt chat")
            .setView(Ui.scroll(box))
            .setPositiveButton("Tutup", null)
            .setNeutralButton("Reset semua") { _, _ ->
                val e = p(ctx).edit()
                for (s in SLOTS) {
                    e.remove("ps_on_" + s.key)
                    e.remove("ps_txt_" + s.key)
                }
                e.apply()
                android.widget.Toast.makeText(ctx, "Semua slot dikembalikan ke bawaan.", android.widget.Toast.LENGTH_SHORT).show()
            }
            .show()
    }
}
