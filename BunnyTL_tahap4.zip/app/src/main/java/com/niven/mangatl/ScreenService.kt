package com.niven.mangatl

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.Rect
import android.graphics.PixelFormat
import android.graphics.RectF
import android.graphics.drawable.GradientDrawable
import android.graphics.Typeface
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.Image
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.HandlerThread
import android.os.IBinder
import android.os.Looper
import android.os.SystemClock
import android.text.method.ScrollingMovementMethod
import android.util.DisplayMetrics
import android.util.TypedValue
import android.view.Gravity
import android.view.MotionEvent
import android.view.HapticFeedbackConstants
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.core.app.NotificationCompat
import androidx.core.content.IntentCompat
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import java.util.Locale
import kotlin.math.abs

/**
 * Mode game: tombol "TL" melayang. Ketuk = ambil layar, baca teks (OCR), terjemahkan dengan Gemma,
 * lalu tampilkan hasilnya di atas game. Tekan lama tombol (sekitar 1 detik) = berhenti.
 */
class ScreenService : Service() {

    companion object {
        const val ACTION_STOP = "com.niven.mangatl.STOP"
        const val ACTION_EDIT_AREA = "com.niven.mangatl.EDIT_AREA"
        private const val CHANNEL = "bunnytl_screen"
        private const val NOTIF_ID = 77

        @Volatile
        var running = false
    }

    private val main = Handler(Looper.getMainLooper())
    private var thread: HandlerThread? = null
    private var cap: Handler? = null
    private var wm: WindowManager? = null
    private var fab: TextView? = null
    private var fabLp: WindowManager.LayoutParams? = null
    private var panel: TextView? = null
    private var panelLp: WindowManager.LayoutParams? = null
    private var ov: OverlayView? = null

    private var projection: MediaProjection? = null
    private var projCb: MediaProjection.Callback? = null
    private var vd: VirtualDisplay? = null
    private var reader: ImageReader? = null
    private var capW = 0
    private var capH = 0
    private var dpi = 320

    @Volatile
    private var wantFrame = false

    @Volatile
    private var busy = false

    private val recognizer by lazy { TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS) }

    private var lastKey = ""
    private var lastMode = -1
    private var lastOut = ""
    private var lastItems: List<OverlayView.Item> = emptyList()

    // Jumlah baris teks asli tiap kotak pada pembacaan terakhir (untuk memperkirakan ukuran huruf).
    @Volatile
    private var curLines: List<Int> = emptyList()

    // ----- mode auto & area
    @Volatile
    private var curAuto = false

    @Volatile
    private var autoOn = false

    @Volatile
    private var autoPaused = false
    private var lastSig: IntArray? = null
    private var candSig: IntArray? = null
    private var changingTicks = 0
    private var editor: AreaEditorView? = null
    private var watcher: View? = null
    private val autoRun = Runnable { autoTick(false) }
    private val autoTouchRun = Runnable { autoTick(true) }

    @Volatile
    private var lastTouchAt = 0L

    @Volatile
    private var touchHideAt = 0L

    @Volatile
    private var sameStreak = 0
    private val prefListener = SharedPreferences.OnSharedPreferenceChangeListener { _, key ->
        if (key == "smode") main.post { applyMode() }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopSelf()
            return START_NOT_STICKY
        }
        if (intent?.action == ACTION_EDIT_AREA) {
            if (running) {
                val which = intent?.getIntExtra("which", 0) ?: 0
                main.post { showAreaEditor(which) }
            } else {
                stopSelf()
            }
            return START_NOT_STICKY
        }
        val code = intent?.getIntExtra("code", 0) ?: 0
        val data = intent?.let { IntentCompat.getParcelableExtra(it, "data", Intent::class.java) }
        if (data == null) {
            stopSelf()
            return START_NOT_STICKY
        }

        cleanup()
        startFg()

        try {
            val mpm = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
            val p = mpm.getMediaProjection(code, data)
            val cb = object : MediaProjection.Callback() {
                override fun onStop() {
                    main.post { stopSelf() }
                }
            }
            p.registerCallback(cb, main)
            projection = p
            projCb = cb

            val t = HandlerThread("bunnytl-cap")
            t.start()
            thread = t
            cap = Handler(t.looper)

            wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
            addOverlays()

            running = true
            prefs().registerOnSharedPreferenceChangeListener(prefListener)
            addWatcher()
            applyMode()

            // Muat model dari awal supaya ketukan pertama tidak lama.
            Thread {
                try {
                    Gemma.findModel(this)?.let { Gemma.warmUp(applicationContext, it) }
                } catch (_: Throwable) {
                }
            }.start()
        } catch (t: Throwable) {
            Toast.makeText(this, "Mode game gagal: ${t.message}", Toast.LENGTH_LONG).show()
            stopSelf()
        }
        return START_NOT_STICKY
    }

    private fun startFg() {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL, "Mode game", NotificationManager.IMPORTANCE_LOW)
        )
        val stop = PendingIntent.getService(
            this, 0,
            Intent(this, ScreenService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val n = NotificationCompat.Builder(this, CHANNEL)
            .setContentTitle("BunnyTL mode game aktif")
            .setContentText("Ketuk tombol TL di layar untuk menerjemahkan")
            .setSmallIcon(android.R.drawable.ic_menu_view)
            .setOngoing(true)
            .addAction(android.R.drawable.ic_menu_close_clear_cancel, "Berhenti", stop)
            .build()
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
        } else {
            startForeground(NOTIF_ID, n)
        }
    }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    @Suppress("DEPRECATION")
    private fun realSize(): IntArray {
        val dm = DisplayMetrics()
        wm!!.defaultDisplay.getRealMetrics(dm)
        return intArrayOf(dm.widthPixels, dm.heightPixels, dm.densityDpi)
    }

    private fun prefs() = getSharedPreferences("mangatl", Context.MODE_PRIVATE)

    // ---------------------------------------------------------------- overlay

    private fun addOverlays() {
        val manager = wm!!

        val o = OverlayView(this)
        val olp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )
        olp.gravity = Gravity.TOP or Gravity.START
        if (Build.VERSION.SDK_INT >= 28) {
            olp.layoutInDisplayCutoutMode =
                WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        }

        val f = TextView(this)
        f.text = "TL"
        f.setTextColor(Color.WHITE)
        f.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14f)
        f.typeface = Typeface.DEFAULT_BOLD
        f.gravity = Gravity.CENTER
        f.setBackgroundResource(R.drawable.bubble_fab)
        f.alpha = 0.85f

        val lp = WindowManager.LayoutParams(
            dp(48), dp(48),
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        )
        lp.gravity = Gravity.TOP or Gravity.START
        lp.x = dp(8)
        lp.y = dp(160)

        f.setOnTouchListener(object : View.OnTouchListener {
            var sx = 0f
            var sy = 0f
            var ox = 0
            var oy = 0
            var moved = false
            var downT = 0L
            var longFired = false
            val longRun = Runnable {
                if (!moved) {
                    longFired = true
                    f.performHapticFeedback(HapticFeedbackConstants.LONG_PRESS)
                    showBubbleMenu()
                }
            }

            override fun onTouch(v: View, e: MotionEvent): Boolean {
                when (e.action) {
                    MotionEvent.ACTION_DOWN -> {
                        sx = e.rawX
                        sy = e.rawY
                        ox = lp.x
                        oy = lp.y
                        moved = false
                        downT = SystemClock.uptimeMillis()
                        longFired = false
                        main.postDelayed(longRun, 550)
                        return true
                    }
                    MotionEvent.ACTION_MOVE -> {
                        val dx = e.rawX - sx
                        val dy = e.rawY - sy
                        if (!moved && (abs(dx) > dp(8) || abs(dy) > dp(8))) {
                            moved = true
                            main.removeCallbacks(longRun)
                        }
                        if (moved) {
                            lp.x = (ox + dx).toInt()
                            lp.y = (oy + dy).toInt()
                            try {
                                manager.updateViewLayout(v, lp)
                            } catch (_: Throwable) {
                            }
                        }
                        return true
                    }
                    MotionEvent.ACTION_UP -> {
                        main.removeCallbacks(longRun)
                        if (!moved && !longFired) onTap()
                        return true
                    }
                    MotionEvent.ACTION_CANCEL -> {
                        main.removeCallbacks(longRun)
                        return true
                    }
                }
                return false
            }
        })

        val p = TextView(this)
        p.setTextColor(Color.WHITE)
        p.setTextSize(TypedValue.COMPLEX_UNIT_SP, 16f)
        p.setPadding(dp(14), dp(10), dp(14), dp(10))
        p.setBackgroundResource(R.drawable.panel_bg)
        p.movementMethod = ScrollingMovementMethod()
        p.visibility = View.GONE
        p.setOnClickListener { p.visibility = View.GONE }

        val plp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT
        )
        plp.gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL

        manager.addView(o, olp)
        manager.addView(p, plp)
        manager.addView(f, lp)
        ov = o

        fab = f
        fabLp = lp
        panel = p
        panelLp = plp
    }

    private fun showPanel(text: String) {
        val p = panel ?: return
        val lp = panelLp ?: return
        val size = realSize()
        val atBottom = prefs().getInt("pos", 0) == 2
        lp.width = (size[0] * 0.9).toInt()
        lp.gravity = (if (atBottom) Gravity.BOTTOM else Gravity.TOP) or Gravity.CENTER_HORIZONTAL
        lp.y = dp(24)
        p.maxHeight = (size[1] * 0.5).toInt()
        p.text = text
        p.scrollTo(0, 0)
        p.visibility = View.VISIBLE
        try {
            wm?.updateViewLayout(p, lp)
        } catch (_: Throwable) {
        }
    }

    private fun overlayShown(): Boolean =
        (ov?.items?.isNotEmpty() == true) || panel?.visibility == View.VISIBLE

    private fun finishCapture() {
        busy = false
        fab?.text = fabIdleText()
        fab?.visibility = View.VISIBLE
        if (autoOn) scheduleIdle()
    }

    /** Hapus semua hasil terjemahan dari layar. */
    private fun clearResults() {
        ov?.setItems(emptyList())
        ov?.alpha = 1f
        panel?.alpha = 1f
        panel?.visibility = View.GONE
        fab?.text = fabIdleText()
    }

    /** Pesan singkat (error / tidak ada teks) yang hilang sendiri. */
    private fun showMessage(msg: String) {
        showPanel(msg)
        finishCapture()
        main.postDelayed({
            if (!busy && ov?.items?.isEmpty() != false) clearResults()
        }, 2500)
    }

    private fun fail(msg: String) {
        main.post { showMessage(msg) }
    }

    // ---------------------------------------------------------------- ambil layar

    private fun onTap() {
        // Mode auto: ketuk tombol = jeda / lanjut.
        if (autoOn) {
            autoPaused = !autoPaused
            if (autoPaused) {
                cap?.removeCallbacks(autoRun)
                clearResults()
            } else {
                lastSig = null
                candSig = null
                changingTicks = 0
                scheduleAuto(200)
            }
            fab?.text = fabIdleText()
            Toast.makeText(this, if (autoPaused) "Auto dijeda." else "Auto lanjut.", Toast.LENGTH_SHORT).show()
            return
        }
        if (busy) {
            Toast.makeText(this, "Masih memproses...", Toast.LENGTH_SHORT).show()
            return
        }
        // Hasil sedang tampil: tutup dulu. Mode 1 (tap berurutan) langsung lanjut terjemahkan layar berikutnya.
        val hadResult = overlayShown()
        if (hadResult) {
            clearResults()
            if (prefs().getInt("smode", 1) == 0) return
        }
        busy = true
        // Sembunyikan tombol supaya tidak ikut terbaca OCR.
        fab?.visibility = View.INVISIBLE
        cap?.postDelayed({ requestFrame() }, if (hadResult) 260L else 160L)
    }

    private val heldLock = Any()
    private var held: Image? = null

    @Volatile
    private var heldAt = 0L

    // Simpan frame terbaru tanpa menutupnya. Layar yang diam tidak menghasilkan frame baru,
    // jadi saat tombol diketuk kita pakai frame terakhir ini, bukan menunggu frame yang tak akan datang
    // (itu penyebab "Gagal ambil layar" setelah ketukan pertama).
    private val listener = ImageReader.OnImageAvailableListener { r ->
        val img: Image? = try {
            r.acquireLatestImage()
        } catch (_: Throwable) {
            null
        }
        if (img != null) {
            synchronized(heldLock) {
                try {
                    held?.close()
                } catch (_: Throwable) {
                }
                held = img
                heldAt = SystemClock.uptimeMillis()
            }
        }
    }

    private fun dropHeld() {
        synchronized(heldLock) {
            try {
                held?.close()
            } catch (_: Throwable) {
            }
            held = null
        }
    }

    /** Mengembalikan true kalau layar virtual baru dibuat (frame pertama perlu waktu sebentar). */
    private fun ensureDisplay(w: Int, h: Int): Boolean {
        if (reader != null && vd != null && w == capW && h == capH) return false
        dropHeld()
        val newReader = ImageReader.newInstance(w, h, PixelFormat.RGBA_8888, 3)
        newReader.setOnImageAvailableListener(listener, cap)
        val old = reader
        val existing = vd
        if (existing == null) {
            vd = projection!!.createVirtualDisplay(
                "bunnytl", w, h, dpi,
                DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
                newReader.surface, null, cap
            )
        } else {
            existing.resize(w, h, dpi)
            existing.setSurface(newReader.surface)
        }
        reader = newReader
        capW = w
        capH = h
        try {
            old?.close()
        } catch (_: Throwable) {
        }
        return true
    }

    private fun requestFrame() {
        try {
            val s = realSize()
            dpi = s[2]
            val recreated = ensureDisplay(s[0], s[1])
            cap?.postDelayed({ takeFrame(0) }, if (recreated) 400L else 0L)
        } catch (t: Throwable) {
            fail("Gagal ambil layar: ${t.message}")
        }
    }

    private fun takeFrame(attempt: Int) {
        val bmp: Bitmap? = synchronized(heldLock) {
            val h = held
            if (h == null) {
                null
            } else {
                try {
                    toBitmap(h)
                } catch (_: Throwable) {
                    null
                }
            }
        }
        if (bmp != null) {
            try {
                process(bmp, false)
            } catch (t: Throwable) {
                fail("Gagal ambil layar: ${t.message}")
            }
            return
        }
        if (attempt < 10) {
            cap?.postDelayed({ takeFrame(attempt + 1) }, 200)
        } else {
            fail("Gagal ambil layar, coba ketuk lagi.")
        }
    }

    private fun toBitmap(img: Image): Bitmap {
        val plane = img.planes[0]
        val pixelStride = plane.pixelStride
        val rowPadding = plane.rowStride - pixelStride * img.width
        val wide = Bitmap.createBitmap(
            img.width + rowPadding / pixelStride, img.height, Bitmap.Config.ARGB_8888
        )
        wide.copyPixelsFromBuffer(plane.buffer)
        return if (wide.width == img.width) {
            wide
        } else {
            Bitmap.createBitmap(wide, 0, 0, img.width, img.height)
        }
    }

    // ------------------------------------------------------- OCR + terjemahan

    private fun process(full: Bitmap, auto: Boolean) {
        curAuto = auto
        // Tombol sudah aman muncul lagi: layar sudah terambil.
        main.post {
            fab?.text = "..."
            fab?.visibility = View.VISIBLE
        }

        val cr = cropRect(full, auto)
        val whole = cr.left == 0 && cr.top == 0 && cr.width() == full.width && cr.height() == full.height
        val crop = if (whole) full else Bitmap.createBitmap(full, cr.left, cr.top, cr.width(), cr.height())

        recognizer
            .process(InputImage.fromBitmap(crop, 0))
            .addOnSuccessListener { text ->
                // Pecah blok per baris (ukuran huruf / jarak), buang sampah ikon dan teks di daftar abaikan.
                val groups = Grouping.translatableGroups(text, Grouping.params(this))
                val lineCountOf = HashMap<Rect, Int>()
                for (g in groups) lineCountOf[g.rect] = g.lines
                val found = groups.map { Pair(it.rect, it.text) }
                val pairs = TextUtil.readingOrderPairs(found)
                    .filter { TextUtil.isTranslatable(TextUtil.normalizeForModel(it.second)) }
                    .take(16)
                curLines = pairs.map { lineCountOf[it.first] ?: 1 }

                if (pairs.isEmpty()) {
                    if (curAuto) finishCapture() else showMessage("Tidak ada teks terdeteksi.")
                    return@addOnSuccessListener
                }

                val mode = prefs().getInt("pos", 0)
                val alpha = prefs().getInt("ov_alpha2", 100).coerceIn(30, 100) * 255 / 100
                val align = prefs().getInt("ov_align", 0).coerceIn(0, 1)
                main.post {
                    ov?.bgAlpha = alpha
                    ov?.align = align
                }
                val lines = pairs.map { it.second }
                // Posisi di layar = posisi di potongan + jarak potongan dari kiri/atas layar.
                val boxes = pairs.map {
                    Rect(
                        it.first.left + cr.left, it.first.top + cr.top,
                        it.first.right + cr.left, it.first.bottom + cr.top
                    )
                }
                val bgs = if (mode == 0) pairs.map { TextUtil.sampleBg(crop, it.first) } else emptyList()

                val key = pairs.joinToString("|") { "${it.second}@${it.first.left / 8},${it.first.top / 8}" }
                if (auto) {
                    if (key == lastKey && mode == lastMode) {
                        sameStreak++
                        main.post {
                            ov?.alpha = 1f
                            panel?.alpha = 1f
                        }
                    } else {
                        // Dialog baru: buang terjemahan lama dan tampilkan lagi lapisannya.
                        sameStreak = 0
                        main.post {
                            ov?.setItems(emptyList())
                            ov?.alpha = 1f
                            panel?.alpha = 1f
                        }
                    }
                }
                if (key == lastKey && mode == lastMode) {
                    if (mode == 0 && lastItems.isNotEmpty()) {
                        ov?.setItems(lastItems)
                        finishCapture()
                        return@addOnSuccessListener
                    }
                    if (mode != 0 && lastOut.isNotEmpty()) {
                        showPanel(lastOut)
                        finishCapture()
                        return@addOnSuccessListener
                    }
                }

                if (mode != 0) showPanel("Menerjemahkan...")
                translateLines(lines, boxes, bgs, key, mode)
            }
            .addOnFailureListener { e ->
                fail("OCR gagal: ${e.message}")
            }
    }

    private fun render(lines: List<String>, tr: List<String?>): String {
        val parts = tr.indices.mapNotNull { i ->
            val t = tr[i]
            if (t == null) null else t.ifBlank { lines.getOrElse(i) { "" } }
        }
        return if (parts.isEmpty()) "Menerjemahkan..." else parts.joinToString("\n")
    }

    /** Susun kotak terjemahan yang menimpa teks asli, warnanya mengikuti latar sekitar teks. */
    private fun buildItems(boxes: List<Rect>, bgs: List<Int>, tr: List<String?>): List<OverlayView.Item> {
        val out = ArrayList<OverlayView.Item>()
        for (i in boxes.indices) {
            val t = tr.getOrNull(i)
            if (t.isNullOrBlank()) continue
            val bg = bgs.getOrElse(i) { Color.BLACK }
            val fg = if (TextUtil.luminance(bg) > 140) 0xFF111111.toInt() else Color.WHITE
            out.add(OverlayView.Item(boxes[i], t, bg, fg, curLines.getOrElse(i) { 1 }))
        }
        return out
    }

    private fun translateLines(lines: List<String>, boxes: List<Rect>, bgs: List<Int>, key: String, mode: Int) {
        val p = prefs()
        val styles = Gemma.Style.values()
        val style = styles[p.getInt("style", 0).coerceIn(0, styles.size - 1)]
        val glossary = p.getString("glossary", "") ?: ""

        Thread {
            try {
                val model = Gemma.findModel(this)
                    ?: throw IllegalStateException("Model .litertlm / .gguf belum ada")
                // Mode cepat: cache per baris, prompt pendek, hasil muncul bertahap (streaming).
                val res = Gemma.translateFast(
                    applicationContext, model, lines, style, glossary,
                    onProgress = { tr ->
                        main.post {
                            if (mode == 0) ov?.setItems(buildItems(boxes, bgs, tr))
                            else showPanel(render(lines, tr))
                        }
                    }
                )
                lastKey = key
                lastMode = mode
                if (mode == 0) {
                    lastItems = buildItems(boxes, bgs, res.lines)
                    lastOut = ""
                } else {
                    lastOut = render(lines, res.lines)
                    lastItems = emptyList()
                }
                main.post {
                    if (mode == 0) ov?.setItems(lastItems) else showPanel(lastOut)
                    finishCapture()
                }
            } catch (t: Throwable) {
                fail("Gagal: ${t.message}")
            }
        }.start()
    }

    // ---------------------------------------------------------------- area & mode auto

    /** Area custom (pecahan layar) untuk mode tap (auto=false) atau auto (auto=true); null = pakai pilihan "baca ...". */
    private fun areaFor(auto: Boolean): RectF? {
        val p = prefs()
        val key = if (auto) "area_auto" else "area_tap"
        if (p.getInt(key + "_on", 0) != 1) return null
        return parseArea(p.getString(key, "")) ?: RectF(0f, 0.62f, 1f, 1f)
    }

    private fun parseArea(raw: String?): RectF? {
        val f = (raw ?: "").split(",").mapNotNull { it.trim().toFloatOrNull() }
        if (f.size != 4) return null
        if (f[2] <= f[0] + 0.02f || f[3] <= f[1] + 0.02f) return null
        return RectF(f[0].coerceIn(0f, 1f), f[1].coerceIn(0f, 1f), f[2].coerceIn(0f, 1f), f[3].coerceIn(0f, 1f))
    }

    private fun cropRect(full: Bitmap, auto: Boolean): Rect {
        val a = areaFor(auto)
        if (a != null) {
            val l = (a.left * full.width).toInt().coerceIn(0, full.width - 2)
            val t = (a.top * full.height).toInt().coerceIn(0, full.height - 2)
            val r = (a.right * full.width).toInt().coerceIn(l + 2, full.width)
            val b = (a.bottom * full.height).toInt().coerceIn(t + 2, full.height)
            return Rect(l, t, r, b)
        }
        val frac = when (prefs().getInt("scan", 0)) {
            1 -> 0.5
            2 -> 0.34
            else -> 1.0
        }
        val top = (full.height * (1.0 - frac)).toInt().coerceIn(0, full.height - 1)
        return Rect(0, top, full.width, full.height)
    }

    private fun showAreaEditor(which: Int) {
        if (editor != null) return
        val manager = wm ?: return
        val key = if (which == 0) "area_tap" else "area_auto"
        val init = parseArea(prefs().getString(key, "")) ?: RectF(0f, 0.62f, 1f, 1f)
        clearResults()
        val v = AreaEditorView(this, init, if (which == 0) "Area sekali tap" else "Area auto") { rect ->
            main.post {
                removeEditor()
                if (rect != null) {
                    val txt = String.format(Locale.US, "%.4f,%.4f,%.4f,%.4f", rect.left, rect.top, rect.right, rect.bottom)
                    prefs().edit().putString(key, txt).putInt(key + "_on", 1).apply()
                    Toast.makeText(this, "Area disimpan dan diaktifkan.", Toast.LENGTH_SHORT).show()
                    lastSig = null
                    candSig = null
                }
            }
        }
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )
        lp.gravity = Gravity.TOP or Gravity.START
        if (Build.VERSION.SDK_INT >= 28) {
            lp.layoutInDisplayCutoutMode =
                WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        }
        try {
            manager.addView(v, lp)
            editor = v
        } catch (t: Throwable) {
            Toast.makeText(this, "Gagal membuka pengatur area: ${t.message}", Toast.LENGTH_LONG).show()
        }
    }

    private fun removeEditor() {
        try {
            editor?.let { wm?.removeView(it) }
        } catch (_: Throwable) {
        }
        editor = null
    }

    /**
     * Jendela 1x1 yang menerima kabar "ada sentuhan di luar" (mis. ketukan ke game).
     * Saat game diketuk: hasil lama disembunyikan, lalu layar diperiksa sebentar kemudian.
     * Ini membuat Auto tidak perlu memeriksa layar terus-menerus (jadi tidak berkedip).
     */
    private fun addWatcher() {
        val manager = wm ?: return
        if (watcher != null) return
        val v = object : View(this) {
            override fun onTouchEvent(event: MotionEvent): Boolean {
                if (event.action == MotionEvent.ACTION_OUTSIDE && autoOn && !autoPaused) {
                    lastTouchAt = SystemClock.uptimeMillis()
                    if (!busy && menu == null && editor == null) {
                        if (overlayShown()) {
                            touchHideAt = lastTouchAt
                            main.post {
                                ov?.alpha = 0f
                                panel?.alpha = 0f
                            }
                        }
                        cap?.removeCallbacks(autoRun)
                        cap?.removeCallbacks(autoTouchRun)
                        cap?.postDelayed(autoTouchRun, 350)
                    }
                }
                return false
            }
        }
        val lp = WindowManager.LayoutParams(
            1, 1,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                WindowManager.LayoutParams.FLAG_WATCH_OUTSIDE_TOUCH,
            PixelFormat.TRANSLUCENT
        )
        lp.gravity = Gravity.TOP or Gravity.START
        try {
            manager.addView(v, lp)
            watcher = v
        } catch (_: Throwable) {
        }
    }

    private fun fabIdleText(): String =
        if (autoOn) (if (autoPaused) "II" else "A") else (if (overlayShown()) "X" else "TL")

    /** Dipanggil saat layanan mulai dan saat pilihan mode di Opsi berubah. */
    private fun applyMode() {
        val auto = prefs().getInt("smode", 1) == 2
        if (auto != autoOn) {
            autoOn = auto
            cap?.removeCallbacks(autoRun)
            clearResults()
            if (auto) {
                autoPaused = false
                lastSig = null
                candSig = null
                changingTicks = 0
                scheduleAuto(600)
            }
        }
        if (!busy) fab?.text = fabIdleText()
    }

    private fun scheduleAuto(ms: Long) {
        cap?.removeCallbacks(autoRun)
        if (autoOn && !autoPaused) cap?.postDelayed(autoRun, ms)
    }

    private fun recentTouch(): Boolean = SystemClock.uptimeMillis() - lastTouchAt < 8000

    /**
     * Jadwal pemeriksaan berikutnya. Kalau terjemahan sedang tampil, pemeriksaan berkala harus menyembunyikannya
     * sekejap (kedip), jadi dijarangkan atau dimatikan sesuai pilihan di Opsi.
     */
    private fun scheduleIdle() {
        if (!overlayShown()) {
            scheduleAuto(800)
            return
        }
        val ms = when (prefs().getInt("auto_poll", 0)) {
            1 -> 0L
            2 -> 4000L
            3 -> 2000L
            else -> if (recentTouch()) 8000L else 3000L
        }
        if (ms > 0L) scheduleAuto(ms)
    }

    private fun restoreOverlay() {
        main.post {
            ov?.alpha = 1f
            panel?.alpha = 1f
        }
    }

    /** Satu putaran auto (thread tangkap layar). touch = dipicu ketukan ke game. */
    private fun autoTick(touch: Boolean) {
        if (!autoOn) return
        try {
            if (autoPaused || busy || editor != null || menu != null) {
                if (touch) restoreOverlay()
                scheduleAuto(600)
                return
            }
            val s = realSize()
            dpi = s[2]
            if (ensureDisplay(s[0], s[1])) {
                scheduleAuto(500)
                return
            }
            if (overlayShown()) {
                val p = prefs().getInt("auto_poll", 0)
                if (!touch && (p == 1 || (p == 0 && recentTouch()))) {
                    // Tidak perlu memeriksa (dan tidak perlu berkedip): tunggu ketukan berikutnya.
                    scheduleIdle()
                    return
                }
                if (touch) {
                    // Hasil sudah disembunyikan saat ketukan terdeteksi.
                    cap?.postDelayed({ autoCapture(touchHideAt, 0) }, 0)
                } else {
                    val hideAt = SystemClock.uptimeMillis()
                    main.post {
                        ov?.alpha = 0f
                        panel?.alpha = 0f
                    }
                    cap?.postDelayed({ autoCapture(hideAt, 0) }, 90)
                }
            } else {
                autoCapture(0L, 0)
            }
        } catch (_: Throwable) {
            restoreOverlay()
            scheduleAuto(1500)
        }
    }

    private fun autoCapture(hideAt: Long, attempt: Int) {
        try {
            if (!autoOn) return
            if (hideAt > 0L && heldAt < hideAt + 30 && attempt < 6) {
                cap?.postDelayed({ autoCapture(hideAt, attempt + 1) }, 60)
                return
            }
            val bmp: Bitmap? = synchronized(heldLock) {
                val h = held
                if (h == null) {
                    null
                } else {
                    try {
                        toBitmap(h)
                    } catch (_: Throwable) {
                        null
                    }
                }
            }
            if (bmp == null) {
                restoreOverlay()
                scheduleIdle()
                return
            }
            val sig = areaSig(bmp)
            val base = lastSig
            // Kalau teks yang sama terus terbaca padahal piksel berubah (animasi), ambang dinaikkan supaya hemat.
            val thr = 3.0 + minOf(sameStreak * 1.5, 6.0)
            if (base != null && sigDiffPct(sig, base) <= thr) {
                candSig = null
                changingTicks = 0
                restoreOverlay()
                scheduleIdle()
                return
            }
            val cand = candSig
            val stable = cand != null && sigDiffPct(sig, cand) <= 2.5
            if (stable || changingTicks >= 6) {
                // Layar sudah berhenti berubah (teks selesai muncul): baca dan terjemahkan.
                candSig = null
                changingTicks = 0
                lastSig = sig
                busy = true
                process(bmp, true)
                return
            }
            // Masih berubah (mis. teks sedang diketik): hasil lama tetap tersembunyi, cek lagi sebentar lagi.
            candSig = sig
            changingTicks++
            scheduleAuto(350)
        } catch (_: Throwable) {
            restoreOverlay()
            scheduleAuto(1500)
        }
    }

    /** Sidik jari kasar isi area: 48x27 sel kecerahan. */
    private fun areaSig(full: Bitmap): IntArray {
        val cr = cropRect(full, true)
        val sub = Bitmap.createBitmap(full, cr.left, cr.top, cr.width(), cr.height())
        val sm = Bitmap.createScaledBitmap(sub, 48, 27, true)
        val px = IntArray(48 * 27)
        sm.getPixels(px, 0, 48, 0, 0, 48, 27)
        val out = IntArray(px.size) {
            val c = px[it]
            (299 * Color.red(c) + 587 * Color.green(c) + 114 * Color.blue(c)) / 1000
        }
        if (sm !== sub) sm.recycle()
        if (sub !== full) sub.recycle()
        return out
    }

    /** Persen sel yang berubah cukup jauh antara dua sidik jari. */
    private fun sigDiffPct(a: IntArray, b: IntArray): Double {
        var n = 0
        for (i in a.indices) if (abs(a[i] - b[i]) > 30) n++
        return n * 100.0 / a.size
    }

    // ---------------------------------------------------------------- menu bubble (tahan lama)

    private var menu: View? = null

    private fun showBubbleMenu() {
        if (menu != null || editor != null) return
        val manager = wm ?: return
        val cur = prefs().getInt("smode", 1).coerceIn(0, 2)

        val root = FrameLayout(this)
        root.setBackgroundColor(0x66000000)
        root.setOnClickListener { removeBubbleMenu() }

        val card = LinearLayout(this)
        card.orientation = LinearLayout.VERTICAL
        card.setPadding(dp(8), dp(8), dp(8), dp(8))
        card.isClickable = true
        card.background = GradientDrawable().apply {
            setColor(0xFF2B2930.toInt())
            cornerRadius = dp(16).toFloat()
        }

        fun label(text: String) {
            val t = TextView(this)
            t.text = text
            t.setTextColor(0xFFB4B4B8.toInt())
            t.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f)
            t.setPadding(dp(14), dp(8), dp(14), dp(4))
            card.addView(t, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        }

        fun item(text: String, selected: Boolean, dismiss: Boolean = true, action: () -> Unit): TextView {
            val t = TextView(this)
            t.text = text
            t.setTextColor(Color.WHITE)
            t.setTextSize(TypedValue.COMPLEX_UNIT_SP, 15f)
            t.setPadding(dp(14), dp(12), dp(14), dp(12))
            if (selected) {
                t.background = GradientDrawable().apply {
                    setColor(0xFF3A3A3E.toInt())
                    cornerRadius = dp(10).toFloat()
                }
            }
            t.setOnClickListener {
                if (dismiss) removeBubbleMenu()
                action()
            }
            card.addView(t, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
            return t
        }

        label("Mode terjemah layar")
        val names = listOf("Sekali tap", "Tap berurutan", "Auto")
        names.forEachIndexed { i, n ->
            item((if (i == cur) "\u2713  " else "     ") + n, i == cur) {
                prefs().edit().putInt("smode", i).apply()
                Toast.makeText(this, "Mode: $n", Toast.LENGTH_SHORT).show()
            }
        }
        label("Area")
        item("Atur kotak area (sekali tap / berurutan)", false) { main.post { showAreaEditor(0) } }
        item("Atur kotak area (auto)", false) { main.post { showAreaEditor(1) } }
        label("Lainnya")
        // Dua langkah supaya tidak kepencet: ketukan pertama hanya meminta konfirmasi.
        var armed = false
        val stopItem = item("Hentikan layanan", false, false) { }
        stopItem.setOnClickListener {
            if (!armed) {
                armed = true
                stopItem.text = "Yakin? Ketuk lagi untuk menghentikan"
                stopItem.setTextColor(0xFFFF8A80.toInt())
            } else {
                removeBubbleMenu()
                stopSelf()
            }
        }
        item("Tutup menu", false) { }

        root.addView(card, FrameLayout.LayoutParams(dp(300), ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.CENTER))

        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )
        lp.gravity = Gravity.TOP or Gravity.START
        if (Build.VERSION.SDK_INT >= 28) {
            lp.layoutInDisplayCutoutMode =
                WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        }
        try {
            manager.addView(root, lp)
            menu = root
        } catch (t: Throwable) {
            Toast.makeText(this, "Gagal membuka menu: ${t.message}", Toast.LENGTH_LONG).show()
        }
    }

    private fun removeBubbleMenu() {
        try {
            menu?.let { wm?.removeView(it) }
        } catch (_: Throwable) {
        }
        menu = null
    }

    // ---------------------------------------------------------------- bersih-bersih

    private fun cleanup() {
        autoOn = false
        cap?.removeCallbacks(autoRun)
        removeEditor()
        removeBubbleMenu()
        try {
            watcher?.let { wm?.removeView(it) }
        } catch (_: Throwable) {
        }
        watcher = null
        try {
            fab?.let { wm?.removeView(it) }
        } catch (_: Throwable) {
        }
        try {
            panel?.let { wm?.removeView(it) }
        } catch (_: Throwable) {
        }
        try {
            ov?.let { wm?.removeView(it) }
        } catch (_: Throwable) {
        }
        ov = null
        fab = null
        panel = null
        try {
            vd?.release()
        } catch (_: Throwable) {
        }
        vd = null
        dropHeld()
        try {
            reader?.close()
        } catch (_: Throwable) {
        }
        reader = null
        capW = 0
        capH = 0
        try {
            projCb?.let { projection?.unregisterCallback(it) }
            projection?.stop()
        } catch (_: Throwable) {
        }
        projection = null
        projCb = null
        try {
            thread?.quitSafely()
        } catch (_: Throwable) {
        }
        thread = null
        cap = null
        busy = false
        wantFrame = false
    }

    override fun onDestroy() {
        running = false
        try {
            prefs().unregisterOnSharedPreferenceChangeListener(prefListener)
        } catch (_: Throwable) {
        }
        try {
            recognizer.close()
        } catch (_: Throwable) {
        }
        cleanup()
        super.onDestroy()
    }
}
