package com.niven.mangatl

import android.content.ContentValues
import android.content.Context
import android.media.MediaScannerConnection
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import android.util.Base64
import android.webkit.CookieManager
import java.io.BufferedInputStream
import java.io.File
import java.io.FileOutputStream
import java.io.InputStream
import java.io.OutputStream
import java.net.HttpURLConnection
import java.net.URL
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Unduh foto / GIF dari web dengan KUALITAS ASLI: byte file disimpan apa adanya (tanpa konversi / kompres ulang),
 * jadi GIF tetap beranimasi dan WebP/PNG/JPG/AVIF/HEIC tidak berubah. Format ditentukan dari isi file, bukan dari
 * ekstensi link. Untuk beberapa CDN, link thumbnail dinaikkan ke versi aslinya dulu (lihat [upgrades]).
 */
object ImgDownloader {

    class Saved(val name: String, val mime: String, val bytes: Long, val where: String)

    private class Sniff(val ext: String, val mime: String)

    /** Coba tiap link berurutan (terbaik dulu) sampai ada yang berhasil. Panggil di thread latar. */
    fun download(
        ctx: Context, urls: List<String>, referer: String, ua: String, nameHint: String? = null,
        cookieFor: ((String) -> String?)? = null
    ): Saved {
        var last: Throwable? = null
        for (raw in urls.distinct()) {
            for (u in (upgrades(raw) + raw).distinct()) {
                try {
                    return fetchOne(ctx, u, referer, ua, nameHint, cookieFor)
                } catch (t: Throwable) {
                    last = t
                }
            }
        }
        throw last ?: IllegalStateException("Tidak ada link gambar.")
    }

    /** Link versi lebih besar / asli untuk CDN yang dikenal (dicoba lebih dulu, kalau gagal pakai link semula). */
    fun upgrades(u: String): List<String> {
        val uri = runCatching { Uri.parse(u) }.getOrNull() ?: return emptyList()
        val host = uri.host?.lowercase() ?: return emptyList()
        val path = uri.path ?: return emptyList()
        val out = ArrayList<String>()
        when {
            host == "pbs.twimg.com" && path.startsWith("/media/") -> {
                val last = path.substringAfterLast('/')
                val ext = if (last.contains('.')) last.substringAfterLast('.') else ""
                val fmt = uri.getQueryParameter("format") ?: ext.ifEmpty { "jpg" }
                val noExt = if (last.contains('.')) path.substringBeforeLast('.') else path
                out += "https://pbs.twimg.com$noExt?format=$fmt&name=orig"
            }
            host.endsWith("pinimg.com") -> {
                val re = Regex("^/(\\d+x\\d*|\\d+x|originals)/")
                if (re.containsMatchIn(path)) out += "https://i.pinimg.com" + path.replaceFirst(re, "/originals/")
            }
            host == "preview.redd.it" -> out += "https://i.redd.it$path"
            host == "upload.wikimedia.org" && path.contains("/thumb/") -> {
                val p = path.replace("/thumb/", "/")
                out += "https://upload.wikimedia.org" + p.substringBeforeLast('/')
            }
            host.endsWith("giphy.com") -> {
                Regex("/media/([^/]+)/").find(path)?.let { out += "https://media.giphy.com/media/${it.groupValues[1]}/giphy.gif" }
            }
        }
        return out.filter { it != u }
    }

    // ---------------------------------------------------------------- unduh satu link

    private fun fetchOne(
        ctx: Context, url: String, referer: String, ua: String, nameHint: String?,
        cookieFor: ((String) -> String?)? = null
    ): Saved {
        if (url.startsWith("data:")) {
            val comma = url.indexOf(',')
            require(comma > 0) { "Data gambar tidak valid." }
            val head = url.substring(5, comma)
            val body = url.substring(comma + 1)
            val bytes = if (head.contains(";base64")) Base64.decode(body, Base64.DEFAULT) else Uri.decode(body).toByteArray()
            return save(ctx, bytes.inputStream(), nameHint ?: "gambar", head.substringBefore(';'))
        }
        require(url.startsWith("http")) { "Link bukan http(s)." }
        val c = URL(url).openConnection() as HttpURLConnection
        try {
            c.connectTimeout = 20_000
            c.readTimeout = 30_000
            c.instanceFollowRedirects = true
            c.setRequestProperty("User-Agent", ua.ifEmpty { "Mozilla/5.0 (Linux; Android 13) AppleWebKit/537.36 Chrome/120 Mobile Safari/537.36" })
            c.setRequestProperty("Accept", "image/*,*/*;q=0.8")
            if (referer.startsWith("http")) c.setRequestProperty("Referer", referer)
            (cookieFor?.invoke(url) ?: CookieManager.getInstance().getCookie(url))?.takeIf { it.isNotBlank() }?.let { c.setRequestProperty("Cookie", it) }
            val code = c.responseCode
            check(code in 200..299) { "HTTP $code" }
            val name = nameHint ?: url.substringBefore('?').substringBefore('#').substringAfterLast('/')
            return c.inputStream.use { save(ctx, it, name, c.contentType ?: "") }
        } finally {
            c.disconnect()
        }
    }

    // ---------------------------------------------------------------- simpan

    private fun sniff(h: ByteArray, n: Int, ctype: String): Sniff? {
        fun at(i: Int, s: String) = n >= i + s.length && String(h, i, s.length, Charsets.ISO_8859_1) == s
        return when {
            at(0, "GIF8") -> Sniff("gif", "image/gif")
            n >= 8 && (h[0].toInt() and 0xFF) == 0x89 && at(1, "PNG") -> Sniff("png", "image/png")
            n >= 3 && (h[0].toInt() and 0xFF) == 0xFF && (h[1].toInt() and 0xFF) == 0xD8 -> Sniff("jpg", "image/jpeg")
            at(0, "RIFF") && at(8, "WEBP") -> Sniff("webp", "image/webp")
            at(4, "ftypavif") || at(4, "ftypavis") -> Sniff("avif", "image/avif")
            at(4, "ftypheic") || at(4, "ftypheix") || at(4, "ftypmif1") || at(4, "ftypheim") -> Sniff("heic", "image/heic")
            at(0, "BM") -> Sniff("bmp", "image/bmp")
            ctype.contains("svg") || at(0, "<svg") || at(0, "<?xml") -> Sniff("svg", "image/svg+xml")
            else -> null
        }
    }

    private fun save(ctx: Context, input: InputStream, rawName: String, ctype: String): Saved {
        val bin = BufferedInputStream(input, 64 * 1024)
        bin.mark(32)
        val head = ByteArray(32)
        val n = bin.read(head).coerceAtLeast(0)
        bin.reset()
        val sn = sniff(head, n, ctype.lowercase())
            ?: throw IllegalStateException("Isinya bukan gambar (${ctype.substringBefore(';').ifEmpty { "tipe tidak diketahui" }}).")

        var base = rawName.substringBeforeLast('.', rawName).replace(Regex("[^A-Za-z0-9._-]"), "_").trim('_', '.')
        if (base.isEmpty()) base = "gambar"
        base = base.take(50)
        val stamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
        val fileName = "${base}_$stamp.${sn.ext}"
        val folder = "BunnyTL"

        var total = 0L
        fun copy(out: OutputStream) {
            val buf = ByteArray(64 * 1024)
            while (true) {
                val r = bin.read(buf)
                if (r < 0) break
                out.write(buf, 0, r)
                total += r
            }
        }

        if (Build.VERSION.SDK_INT >= 29) {
            val coll = if (sn.ext == "svg") MediaStore.Downloads.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY)
            else MediaStore.Images.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY)
            val root = if (sn.ext == "svg") Environment.DIRECTORY_DOWNLOADS else Environment.DIRECTORY_PICTURES
            val cv = ContentValues().apply {
                put(MediaStore.MediaColumns.DISPLAY_NAME, fileName)
                put(MediaStore.MediaColumns.MIME_TYPE, sn.mime)
                put(MediaStore.MediaColumns.RELATIVE_PATH, "$root/$folder")
                put(MediaStore.MediaColumns.IS_PENDING, 1)
            }
            val uri = ctx.contentResolver.insert(coll, cv) ?: throw IllegalStateException("Tidak bisa membuat file di penyimpanan.")
            try {
                ctx.contentResolver.openOutputStream(uri)?.use { copy(it) } ?: throw IllegalStateException("Tidak bisa menulis file.")
                ctx.contentResolver.update(uri, ContentValues().apply { put(MediaStore.MediaColumns.IS_PENDING, 0) }, null, null)
            } catch (t: Throwable) {
                runCatching { ctx.contentResolver.delete(uri, null, null) }
                throw t
            }
            return Saved(fileName, sn.mime, total, "$root/$folder")
        }

        val dir = File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES), folder).apply { mkdirs() }
        val f = File(dir, fileName)
        FileOutputStream(f).use { copy(it) }
        MediaScannerConnection.scanFile(ctx, arrayOf(f.absolutePath), arrayOf(sn.mime), null)
        return Saved(fileName, sn.mime, total, "Pictures/$folder")
    }
}
