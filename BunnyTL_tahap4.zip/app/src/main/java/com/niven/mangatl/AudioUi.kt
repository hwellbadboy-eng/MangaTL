package com.niven.mangatl

import android.content.Context
import android.content.res.ColorStateList
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.text.InputType
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import android.widget.EditText
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.widget.SwitchCompat
import kotlin.math.abs
import kotlin.math.exp
import kotlin.math.ln
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

/** Warna dan potongan UI yang dipakai layar Audio Engine (mengikuti desain). */
object AU {
    const val WHITE = 0xFFFFFFFF.toInt()
    const val BLACK = 0xFF000000.toInt()
    const val MUT = 0xFF9A9AA2.toInt()
    const val LN = 0xFF2A2A2E.toInt()
    const val CD = 0xFF161619.toInt()
    const val ERR = 0xFFFF9A9A.toInt()
    const val SOFT = 0xFFD0D0D6.toInt()

    fun dp(c: Context, v: Int) = Ui.dp(c, v)

    fun shape(color: Int, radiusDp: Float, c: Context, stroke: Int = 0, strokeDp: Int = 0): GradientDrawable =
        GradientDrawable().apply {
            setColor(color)
            cornerRadius = radiusDp * c.resources.displayMetrics.density
            if (strokeDp > 0) setStroke(dp(c, strokeDp), stroke)
        }

    fun text(c: Context, s: String, sp: Float, color: Int = WHITE, bold: Boolean = false): TextView =
        TextView(c).apply {
            text = s
            textSize = sp
            setTextColor(color)
            if (bold) setTypeface(typeface, Typeface.BOLD)
        }

    fun chip(c: Context, s: String, on: Boolean, enabled: Boolean = true, small: Boolean = false): TextView =
        TextView(c).apply {
            text = s
            textSize = if (small) 12f else 13f
            gravity = Gravity.CENTER
            minHeight = dp(c, if (small) 28 else 36)
            setPadding(dp(c, if (small) 10 else 14), 0, dp(c, if (small) 10 else 14), 0)
            style(this, on, enabled)
        }

    fun style(t: TextView, on: Boolean, enabled: Boolean = true) {
        val c = t.context
        if (on) {
            t.background = shape(WHITE, 99f, c, WHITE, 1)
            t.setTextColor(BLACK)
        } else {
            t.background = shape(CD, 99f, c, LN, 1)
            t.setTextColor(WHITE)
        }
        t.alpha = if (enabled) 1f else 0.4f
    }

    fun switch(c: Context, checked: Boolean, enabled: Boolean = true, onChange: (Boolean) -> Unit): SwitchCompat =
        SwitchCompat(c).apply {
            isChecked = checked
            isEnabled = enabled
            alpha = if (enabled) 1f else 0.45f
            val on = intArrayOf(android.R.attr.state_checked)
            val off = intArrayOf(-android.R.attr.state_checked)
            thumbTintList = ColorStateList(arrayOf(on, off), intArrayOf(BLACK, MUT))
            trackTintList = ColorStateList(arrayOf(on, off), intArrayOf(WHITE, LN))
            setOnCheckedChangeListener { _, v -> onChange(v) }
        }

    fun fmt(v: Float): String {
        val a = abs(v)
        val s = when {
            a >= 1000f -> String.format(java.util.Locale.US, "%.0f", v)
            a >= 100f -> String.format(java.util.Locale.US, "%.1f", v)
            else -> String.format(java.util.Locale.US, "%.2f", v)
        }
        return if (s.contains('.')) s.trimEnd('0').trimEnd('.') else s
    }
}

/** Satu baris parameter. compact = versi kecil untuk popup (tanpa deskripsi/reset). */
class ParamRow(
    private val ctx: Context,
    private val fid: String,
    private val idx: Int,
    private val compact: Boolean,
    private val onChanged: () -> Unit
) {
    private val p: P = AudioEngine.feature(fid).params[idx]
    val view = LinearLayout(ctx)
    private var edit: EditText? = null
    private var seek: SeekBar? = null
    private var errTv: TextView? = null
    private var defTv: TextView? = null
    private var meterTv: TextView? = null
    private var noteTv: TextView? = null
    private var chips: List<TextView> = emptyList()
    private var sw: SwitchCompat? = null
    private var updating = false
    private var isLog = false

    init {
        view.orientation = LinearLayout.VERTICAL
        view.setPadding(0, AU.dp(ctx, if (compact) 6 else 10), 0, AU.dp(ctx, if (compact) 6 else 10))
        if (!compact) {
            view.background = android.graphics.drawable.ColorDrawable(0)
        }
        when (p) {
            is PNum -> buildNum(p)
            is PSel -> buildSel(p)
            is PTog -> buildTog(p)
            is PMeter -> buildMeter(p)
        }
        if (!compact && fid == AudioEngine.NORM && idx == 7) {
            val t = AU.text(ctx, "", 13f, AU.WHITE, true)
            t.setPadding(0, AU.dp(ctx, 6), 0, 0)
            meterTv = t
            view.addView(t)
        }
        val note = OutputCaps.note(fid, idx)
        if (note != null && !compact) {
            val t = AU.text(ctx, note, 12f, AU.MUT)
            t.setPadding(0, AU.dp(ctx, 4), 0, 0)
            noteTv = t
            view.addView(t)
        }
        refresh()
    }

    private fun title(extra: String): LinearLayout {
        val row = LinearLayout(ctx)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL
        val name = AU.text(ctx, p.name, if (compact) 13f else 14f, if (compact) AU.SOFT else AU.WHITE, !compact)
        row.addView(name, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        if (extra.isNotEmpty() && !compact) {
            val e = AU.text(ctx, extra, 12f, AU.MUT)
            e.setPadding(0, 0, AU.dp(ctx, 10), 0)
            row.addView(e)
        }
        if (!compact && p !is PMeter) {
            val r = AU.text(ctx, "Reset", 12f, AU.MUT)
            r.setPadding(AU.dp(ctx, 8), AU.dp(ctx, 6), 0, AU.dp(ctx, 6))
            r.setOnClickListener {
                AudioEngine.resetParam(fid, idx)
                refresh()
                onChanged()
            }
            row.addView(r)
        }
        return row
    }

    private fun desc(s: String) {
        if (compact) return
        val t = AU.text(ctx, s, 12f, AU.MUT)
        t.setPadding(0, AU.dp(ctx, 2), 0, 0)
        view.addView(t)
    }

    // ---------- slider + angka ----------

    private fun toProg(v: Float, n: PNum): Int {
        val f = if (isLog) ln(max(v, n.min) / n.min) / ln(n.max / n.min) else (v - n.min) / (n.max - n.min)
        return (f * 1000f).roundToInt().coerceIn(0, 1000)
    }

    private fun fromProg(pr: Int, n: PNum): Float {
        val f = pr / 1000f
        val raw = if (isLog) n.min * exp(f * ln(n.max / n.min)) else n.min + f * (n.max - n.min)
        return snap(raw, n)
    }

    private fun snap(v: Float, n: PNum): Float {
        val r = n.max - n.min
        val step = when {
            abs(v) >= 100f && r >= 100f -> 1f
            r >= 100f -> 0.1f
            r >= 10f -> 0.1f
            else -> 0.01f
        }
        return ((v / step).roundToInt() * step).coerceIn(n.min, n.max)
    }

    private fun buildNum(n: PNum) {
        isLog = n.min > 0f && n.max / n.min >= 50f
        val unit = if (n.unit.isEmpty()) "" else " " + n.unit
        val head = LinearLayout(ctx)
        head.orientation = LinearLayout.HORIZONTAL
        head.gravity = Gravity.CENTER_VERTICAL
        head.addView(
            AU.text(ctx, n.name, if (compact) 13f else 14f, if (compact) AU.SOFT else AU.WHITE, !compact),
            LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        )
        val et = EditText(ctx)
        et.setTextColor(AU.WHITE)
        et.textSize = if (compact) 13f else 14f
        et.setTypeface(et.typeface, Typeface.BOLD)
        et.gravity = Gravity.END or Gravity.CENTER_VERTICAL
        et.maxLines = 1
        et.setSingleLine(true)
        et.imeOptions = EditorInfo.IME_ACTION_DONE
        et.inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL or
            (if (n.min < 0f) InputType.TYPE_NUMBER_FLAG_SIGNED else 0)
        et.setSelectAllOnFocus(true)
        if (compact) {
            et.background = null
            et.setPadding(0, 0, 0, 0)
        } else {
            et.background = AU.shape(AU.CD, 8f, ctx, AU.LN, 1)
            et.setPadding(AU.dp(ctx, 8), AU.dp(ctx, 6), AU.dp(ctx, 8), AU.dp(ctx, 6))
        }
        et.minWidth = AU.dp(ctx, if (compact) 56 else 76)
        et.setOnEditorActionListener { v, a, _ ->
            if (a == EditorInfo.IME_ACTION_DONE) {
                commit(et.text.toString(), n)
                v.clearFocus()
                true
            } else false
        }
        et.setOnFocusChangeListener { _, has -> if (!has) commit(et.text.toString(), n) }
        edit = et
        head.addView(et)
        if (unit.isNotEmpty()) {
            val u = AU.text(ctx, unit, 12f, AU.MUT)
            head.addView(u)
        }
        if (!compact) {
            val r = AU.text(ctx, "Reset", 12f, AU.MUT)
            r.setPadding(AU.dp(ctx, 12), AU.dp(ctx, 6), 0, AU.dp(ctx, 6))
            r.setOnClickListener {
                AudioEngine.resetParam(fid, idx)
                refresh()
                onChanged()
            }
            head.addView(r)
        }
        view.addView(head)
        if (!compact) {
            desc(n.desc)
            val d = AU.text(ctx, "", 11f, AU.MUT)
            d.setPadding(0, AU.dp(ctx, 2), 0, 0)
            defTv = d
            view.addView(d)
        }
        val sb = SeekBar(ctx)
        sb.max = 1000
        sb.progressTintList = ColorStateList.valueOf(AU.WHITE)
        sb.thumbTintList = ColorStateList.valueOf(AU.WHITE)
        sb.progressBackgroundTintList = ColorStateList.valueOf(AU.LN)
        sb.setPadding(AU.dp(ctx, 8), AU.dp(ctx, 6), AU.dp(ctx, 8), AU.dp(ctx, 6))
        sb.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, pr: Int, fromUser: Boolean) {
                if (!fromUser || updating) return
                val v = fromProg(pr, n)
                AudioEngine.set(fid, idx, v)
                updating = true
                edit?.setText(AU.fmt(AudioEngine.get(fid, idx)))
                updating = false
                errTv?.visibility = View.GONE
                onChanged()
            }

            override fun onStartTrackingTouch(s: SeekBar?) {
                s?.parent?.requestDisallowInterceptTouchEvent(true)
            }

            override fun onStopTrackingTouch(s: SeekBar?) {}
        })
        seek = sb
        view.addView(sb)
        val er = AU.text(ctx, "", 12f, AU.ERR)
        er.visibility = View.GONE
        errTv = er
        view.addView(er)
    }

    private fun commit(s: String, n: PNum) {
        if (updating) return
        val x = s.trim().replace(',', '.').toFloatOrNull()
        if (x == null || x < n.min || x > n.max) {
            errTv?.text = "Nilai harus ${AU.fmt(n.min)} sampai ${AU.fmt(n.max)}${if (n.unit.isEmpty()) "" else " " + n.unit}"
            errTv?.visibility = View.VISIBLE
            return
        }
        errTv?.visibility = View.GONE
        AudioEngine.set(fid, idx, x)
        refresh()
        onChanged()
    }

    // ---------- pilihan ----------

    private fun selUnit(): String = when {
        fid == AudioEngine.HIRES && idx == 0 -> "kHz"
        fid == AudioEngine.EQ && idx == 5 -> "dB/oct"
        else -> ""
    }

    private fun buildSel(s: PSel) {
        if (!compact) {
            view.addView(title(selUnit()))
            desc(s.desc)
        } else {
            view.addView(AU.text(ctx, s.name, 13f, AU.SOFT))
        }
        val hs = HorizontalScrollView(ctx)
        hs.isHorizontalScrollBarEnabled = false
        val row = LinearLayout(ctx)
        row.orientation = LinearLayout.HORIZONTAL
        val list = ArrayList<TextView>()
        for ((i, o) in s.opts.withIndex()) {
            val c = AU.chip(ctx, o, false, true, compact)
            val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            lp.rightMargin = AU.dp(ctx, 6)
            c.setOnClickListener {
                if (!OutputCaps.optionEnabled(fid, idx, i)) {
                    Toast.makeText(ctx, OutputCaps.note(fid, idx) ?: "Tidak tersedia di perangkat ini", Toast.LENGTH_LONG).show()
                } else {
                    AudioEngine.set(fid, idx, i.toFloat())
                    refresh()
                    onChanged()
                }
            }
            row.addView(c, lp)
            list.add(c)
        }
        chips = list
        hs.addView(row)
        val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        lp.topMargin = AU.dp(ctx, 8)
        view.addView(hs, lp)
    }

    // ---------- saklar ----------

    private fun buildTog(t: PTog) {
        val row = LinearLayout(ctx)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL
        row.addView(
            AU.text(ctx, t.name, if (compact) 13f else 14f, if (compact) AU.SOFT else AU.WHITE, !compact),
            LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        )
        val enabled = t.supported && OutputCaps.toggleEnabled(fid, idx)
        val s = AU.switch(ctx, false, enabled) { v ->
            if (!updating) {
                AudioEngine.set(fid, idx, if (v) 1f else 0f)
                refresh()
                onChanged()
            }
        }
        sw = s
        if (!compact && t.supported) {
            val r = AU.text(ctx, "Reset", 12f, AU.MUT)
            r.setPadding(AU.dp(ctx, 8), AU.dp(ctx, 6), AU.dp(ctx, 12), AU.dp(ctx, 6))
            r.setOnClickListener {
                AudioEngine.resetParam(fid, idx)
                refresh()
                onChanged()
            }
            row.addView(r)
        }
        row.addView(s)
        view.addView(row)
        desc(t.desc)
    }

    private fun buildMeter(m: PMeter) {
        val row = LinearLayout(ctx)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL
        row.addView(
            AU.text(ctx, m.name, if (compact) 13f else 14f, if (compact) AU.SOFT else AU.WHITE, !compact),
            LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        )
        val v = AU.text(ctx, "", 13f, AU.WHITE, true)
        meterTv = v
        row.addView(v)
        view.addView(row)
        desc(m.desc)
    }

    /** Sinkronkan tampilan dengan nilai terkini (juga dipanggil berkala untuk meter). */
    fun refresh() {
        val raw = AudioEngine.raw(fid)
        view.visibility = if (p.show == null || p.show.invoke(raw)) View.VISIBLE else View.GONE
        updating = true
        when (p) {
            is PNum -> {
                val v = AudioEngine.get(fid, idx)
                if (edit?.hasFocus() != true) edit?.setText(AU.fmt(v))
                seek?.progress = toProg(v, p)
                defTv?.text = "Default ${AU.fmt(AudioEngine.def(fid, idx))}${if (p.unit.isEmpty()) "" else " " + p.unit}  ·  ${AU.fmt(p.min)} sampai ${AU.fmt(p.max)}"
            }
            is PSel -> {
                val cur = AudioEngine.get(fid, idx).toInt()
                for ((i, c) in chips.withIndex()) AU.style(c, i == cur, OutputCaps.optionEnabled(fid, idx, i))
            }
            is PTog -> sw?.isChecked = AudioEngine.get(fid, idx) >= 0.5f
            is PMeter -> meterTv?.text = AudioEngine.meterText(fid, idx)
        }
        if (fid == AudioEngine.NORM && idx == 7 && !compact) meterTv?.text = AudioEngine.normMeterText()
        noteTv?.text = OutputCaps.note(fid, idx) ?: ""
        updating = false
    }

    /** Hanya meter (murah), untuk pewaktu. */
    fun tick() {
        if (p is PMeter) meterTv?.text = AudioEngine.meterText(fid, idx)
        if (fid == AudioEngine.NORM && idx == 7 && !compact) meterTv?.text = AudioEngine.normMeterText()
    }
}

/** Indikator gulir di sisi kanan popup (bisa diseret). */
class RailView(c: Context, private val sv: ScrollView) : View(c) {
    private val track = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0x22FFFFFF }
    private val thumb = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xCCFFFFFF.toInt() }
    private val r = RectF()

    private fun range(): Int {
        val ch = sv.getChildAt(0) ?: return 0
        return max(0, ch.height - sv.height)
    }

    private fun thumbH(): Float {
        val ch = sv.getChildAt(0) ?: return height.toFloat()
        val ratio = if (ch.height <= 0) 1f else min(1f, sv.height.toFloat() / ch.height)
        return max(AU.dp(context, 28).toFloat(), height * ratio)
    }

    override fun onDraw(canvas: Canvas) {
        val cx = width / 2f
        val w = AU.dp(context, 4).toFloat()
        r.set(cx - w / 2, 0f, cx + w / 2, height.toFloat())
        canvas.drawRoundRect(r, w / 2, w / 2, track)
        val rg = range()
        val th = thumbH()
        val y = if (rg == 0) 0f else (height - th) * sv.scrollY / rg
        val tw = AU.dp(context, 8).toFloat()
        r.set(cx - tw / 2, y, cx + tw / 2, y + th)
        canvas.drawRoundRect(r, tw / 2, tw / 2, thumb)
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        parent?.requestDisallowInterceptTouchEvent(true)
        val rg = range()
        if (rg > 0) {
            val th = thumbH()
            val f = ((e.y - th / 2) / max(1f, height - th)).coerceIn(0f, 1f)
            sv.scrollTo(0, (f * rg).toInt())
            invalidate()
        }
        return true
    }
}
