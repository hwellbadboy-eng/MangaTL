package com.niven.mangatl

import android.content.Context

/** Situs mana yang tampil di daftar "tahan lalu geser" pada bubble web. Disembunyikan = hanya hilang dari daftar itu. */
object BubbleSites {
    private fun sp(ctx: Context) = ctx.applicationContext.getSharedPreferences("dl_bubble_sites", Context.MODE_PRIVATE)

    fun hidden(ctx: Context): Set<String> = sp(ctx).getStringSet("hidden", emptySet())?.toSet() ?: emptySet()

    fun setHidden(ctx: Context, key: String, hide: Boolean) {
        val s = hidden(ctx).toMutableSet()
        if (hide) s.add(key) else s.remove(key)
        sp(ctx).edit().putStringSet("hidden", s).apply()
    }

    fun showAll(ctx: Context) = sp(ctx).edit().remove("hidden").apply()

    /** Situs yang tampil di daftar bubble (urutan sama dengan grid: bawaan lalu buatan sendiri). */
    fun visible(ctx: Context): List<LoginSite> {
        val h = hidden(ctx)
        return DlCookies.allSites().filter { it.key !in h }
    }
}
