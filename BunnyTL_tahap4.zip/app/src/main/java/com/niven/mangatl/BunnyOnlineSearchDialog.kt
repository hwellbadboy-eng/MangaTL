package com.niven.mangatl

import android.app.DownloadManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Environment
import android.view.View
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.launch

/** Online search is presented as an overlay from the existing Video screen, not a second Video page. */
object BunnyOnlineSearchDialog {
    fun show(activity: AppCompatActivity) {
        val pad = Ui.dp(activity, 16)
        val root = LinearLayout(activity).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad, pad, pad)
        }
        val query = EditText(activity).apply {
            hint = "Cari anime / film"
            singleLine = true
            setTextColor(0xFFFFFFFF.toInt())
        }
        val language = Spinner(activity).apply {
            adapter = ArrayAdapter(activity, android.R.layout.simple_spinner_dropdown_item,
                listOf("Semua subtitle", "Indonesia", "English", "Japanese", "Bahasa lain"))
        }
        val actions = LinearLayout(activity).apply { orientation = LinearLayout.HORIZONTAL }
        val registryButton = Button(activity).apply { text = "Registry" }
        val searchButton = Button(activity).apply { text = "Cari" }
        actions.addView(registryButton, LinearLayout.LayoutParams(0, -2, 1f))
        actions.addView(searchButton, LinearLayout.LayoutParams(0, -2, 1f))
        val status = TextView(activity).apply { setTextColor(0xFFBBBBBB.toInt()); text = "Atur URL registry sumber terlebih dahulu." }
        val results = LinearLayout(activity).apply { orientation = LinearLayout.VERTICAL }
        val scroll = ScrollView(activity).apply { addView(results) }
        root.addView(query, LinearLayout.LayoutParams(-1, -2))
        root.addView(language, LinearLayout.LayoutParams(-1, -2))
        root.addView(actions, LinearLayout.LayoutParams(-1, -2))
        root.addView(status, LinearLayout.LayoutParams(-1, -2))
        root.addView(scroll, LinearLayout.LayoutParams(-1, Ui.dp(activity, 320)))

        val dialog = AlertDialog.Builder(activity)
            .setTitle("Bunny Multi-Source Search")
            .setView(root)
            .setNegativeButton("Tutup", null)
            .create()

        registryButton.setOnClickListener {
            val input = EditText(activity).apply {
                hint = "https://domain-anda/registry.json"
                setSingleLine(true)
                setText(BunnyMultiSourceEngine.registryUrl(activity))
            }
            AlertDialog.Builder(activity)
                .setTitle("Remote Source Registry")
                .setMessage("Masukkan URL HTTPS registry JSON milik penyedia sumber yang Anda percaya.")
                .setView(input)
                .setNegativeButton("Batal", null)
                .setPositiveButton("Simpan") { _, _ ->
                    val value = input.text.toString().trim()
                    if (value.isNotEmpty() && !value.startsWith("https://", true)) {
                        Toast.makeText(activity, "Registry harus memakai HTTPS.", Toast.LENGTH_LONG).show()
                    } else {
                        BunnyMultiSourceEngine.setRegistryUrl(activity, value)
                        status.text = if (value.isBlank()) "Registry belum diatur." else "Registry tersimpan. Tekan Cari."
                    }
                }.show()
        }

        searchButton.setOnClickListener {
            val q = query.text.toString().trim()
            if (q.isBlank()) {
                query.error = "Masukkan judul"
                return@setOnClickListener
            }
            status.text = "Mencari dari beberapa sumber..."
            results.removeAllViews()
            searchButton.isEnabled = false
            val lang = when (language.selectedItemPosition) { 1 -> "id"; 2 -> "en"; 3 -> "ja"; 4 -> "other"; else -> "all" }
            activity.lifecycleScope.launch {
                try {
                    val response = BunnyMultiSourceEngine.search(activity, q, lang)
                    status.text = "${response.results.size} hasil dari ${response.sourceCount} sumber" +
                        if (response.errors.isNotEmpty()) " · ${response.errors.size} sumber bermasalah" else ""
                    if (response.results.isEmpty()) {
                        addLabel(activity, results, "Tidak ada hasil. Periksa registry dan endpoint provider.")
                    }
                    response.results.forEach { result ->
                        val row = TextView(activity).apply {
                            text = "${result.title}\n${result.sourceName} · ${result.quality.ifBlank { "Kualitas tidak diketahui" }} · ${result.subtitleLanguage.ifBlank { "Subtitle tidak diketahui" }}"
                            setTextColor(0xFFFFFFFF.toInt())
                            textSize = 14f
                            setPadding(Ui.dp(activity, 12), Ui.dp(activity, 12), Ui.dp(activity, 12), Ui.dp(activity, 12))
                            background = activity.getDrawable(R.drawable.bg_input_round)
                            setOnClickListener { showResultActions(activity, result) }
                        }
                        results.addView(row, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = Ui.dp(activity, 8) })
                    }
                    response.errors.take(3).forEach { addLabel(activity, results, it) }
                } catch (e: Exception) {
                    status.text = e.message ?: "Pencarian gagal."
                } finally {
                    searchButton.isEnabled = true
                }
            }
        }
        dialog.show()
    }

    private fun showResultActions(activity: AppCompatActivity, result: BunnyMultiSourceEngine.Result) {
        val actions = mutableListOf("Streaming")
        if (result.downloadAllowed) actions += "Download"
        AlertDialog.Builder(activity)
            .setTitle(result.title)
            .setItems(actions.toTypedArray()) { _, which ->
                if (which == 0) {
                    activity.startActivity(Intent(activity, VideoActivity::class.java)
                        .setData(Uri.parse(result.streamUrl))
                        .putExtra("remote_title", result.title)
                        .putExtra("remote_subtitle_url", result.subtitleUrl)
                        .putExtra("remote_subtitle_mime", result.subtitleMime)
                        .putExtra("remote_subtitle_language", result.subtitleLanguage))
                } else {
                    enqueueDownload(activity, result)
                }
            }
            .setNegativeButton("Batal", null)
            .show()
    }

    private fun enqueueDownload(activity: Context, result: BunnyMultiSourceEngine.Result) {
        try {
            val mediaUri = Uri.parse(result.streamUrl)
            val extension = mediaUri.lastPathSegment?.substringAfterLast('.', "")
                ?.takeIf { it.matches(Regex("[A-Za-z0-9]{2,5}")) }
            val fileName = "BunnyTL_${result.title.replace(Regex("[^A-Za-z0-9._-]"), "_").take(80)}" +
                (extension?.let { ".$it" } ?: "")
            val request = DownloadManager.Request(mediaUri)
                .setTitle(result.title)
                .setDescription("BunnyTL · ${result.sourceName}")
                .setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
                .setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, fileName)
            val manager = activity.getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager
            manager.enqueue(request)
            Toast.makeText(activity, "Download ditambahkan ke antrean.", Toast.LENGTH_SHORT).show()
        } catch (e: Exception) {
            Toast.makeText(activity, "Download gagal: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }

    private fun addLabel(context: Context, parent: LinearLayout, text: String) {
        parent.addView(TextView(context).apply {
            this.text = text
            setTextColor(0xFFBBBBBB.toInt())
            textSize = 12f
            setPadding(Ui.dp(context, 8), Ui.dp(context, 6), Ui.dp(context, 8), Ui.dp(context, 6))
        })
    }
}
