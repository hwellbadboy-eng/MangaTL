package com.niven.mangatl

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioDeviceInfo
import android.media.AudioManager
import android.media.AudioMixerAttributes
import android.os.Build

/**
 * Apa yang benar-benar bisa dilakukan jalur output perangkat ini. Opsi Hi-Res yang tidak
 * didukung ditandai nonaktif di UI beserta alasannya, bukan dipalsukan.
 */
object OutputCaps {
    private var ctx: Context? = null

    fun init(c: Context) {
        ctx = c.applicationContext
    }

    private fun am(): AudioManager? = ctx?.getSystemService(Context.AUDIO_SERVICE) as? AudioManager

    fun usbDac(): AudioDeviceInfo? {
        val a = am() ?: return null
        return try {
            a.getDevices(AudioManager.GET_DEVICES_OUTPUTS).firstOrNull {
                it.type == AudioDeviceInfo.TYPE_USB_DEVICE || it.type == AudioDeviceInfo.TYPE_USB_HEADSET
            }
        } catch (e: Exception) {
            null
        }
    }

    fun dacName(): String? = usbDac()?.productName?.toString()

    /** Perangkat tujuan menurut pengaturan: DAC USB kalau dipilih (atau mode Direct), selain itu default sistem. */
    fun targetDevice(): AudioDeviceInfo? {
        val v = AudioEngine.raw(AudioEngine.HIRES)
        if (!AudioEngine.isOn(AudioEngine.HIRES) || v.size < 5) return null
        return if (v[3].toInt() == 1 || v[4].toInt() == 1) usbDac() else null
    }

    fun rateAllowed(rate: Int): Boolean {
        val d = targetDevice() ?: return true
        val rs = try {
            d.sampleRates
        } catch (e: Exception) {
            IntArray(0)
        }
        return rs.isEmpty() || rs.contains(rate)
    }

    private fun bitPerfectAttrs(dev: AudioDeviceInfo): AudioMixerAttributes? {
        if (Build.VERSION.SDK_INT < 34) return null
        val a = am() ?: return null
        return try {
            a.getSupportedMixerAttributes(dev).firstOrNull {
                it.mixerBehavior == AudioMixerAttributes.MIXER_BEHAVIOR_BIT_PERFECT
            }
        } catch (e: Throwable) {
            null
        }
    }

    fun bitPerfectAvailable(): Boolean {
        val d = usbDac() ?: return false
        return bitPerfectAttrs(d) != null
    }

    private val musicAttrs: AudioAttributes
        get() = AudioAttributes.Builder()
            .setUsage(AudioAttributes.USAGE_MEDIA)
            .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
            .build()

    /** Pasang atau lepas mixer bit-perfect di DAC USB (Android 14+). */
    fun applyBitPerfect(enable: Boolean) {
        if (Build.VERSION.SDK_INT < 34) return
        val a = am() ?: return
        val d = usbDac() ?: return
        try {
            if (enable) {
                val m = bitPerfectAttrs(d) ?: return
                a.setPreferredMixerAttributes(musicAttrs, d, m)
            } else {
                a.clearPreferredMixerAttributes(musicAttrs, d)
            }
        } catch (e: Throwable) {
        }
    }

    // ---------- ketersediaan opsi untuk UI ----------

    fun optionEnabled(fid: String, idx: Int, opt: Int): Boolean {
        if (fid != AudioEngine.HIRES) return true
        return when (idx) {
            0 -> opt == 0 || rateAllowed(intArrayOf(0, 44100, 48000, 88200, 96000, 176400, 192000)[opt])
            3 -> opt == 0 || usbDac() != null
            4 -> when (opt) {
                0 -> true
                1 -> usbDac() != null
                else -> false
            }
            else -> true
        }
    }

    fun toggleEnabled(fid: String, idx: Int): Boolean {
        if (fid == AudioEngine.HIRES && idx == 5) return bitPerfectAvailable()
        return true
    }

    /** Catatan tambahan di bawah baris parameter (alasan tidak tersedia, perangkat terdeteksi). */
    fun note(fid: String, idx: Int): String? {
        if (fid != AudioEngine.HIRES) return null
        return when (idx) {
            0 -> {
                val d = targetDevice()
                if (d == null) "Perangkat default: sistem Android biasanya menyamakan ke laju mixer (sering 48 kHz) kecuali DAC USB."
                else "Laju yang didukung ${d.productName}: " + (d.sampleRates.takeIf { it.isNotEmpty() }?.joinToString(", ") { "${it / 1000.0}" } ?: "tidak dilaporkan")
            }
            3 -> usbDac()?.let { "Terdeteksi: ${it.productName}" } ?: "DAC USB tidak terdeteksi"
            4 -> "Exclusive: Android tidak menyediakannya lewat AudioTrack. Direct butuh DAC USB."
            5 -> when {
                Build.VERSION.SDK_INT < 34 -> "Butuh Android 14 atau lebih baru"
                usbDac() == null -> "Butuh DAC USB tersambung"
                !bitPerfectAvailable() -> "DAC ini tidak melaporkan dukungan bit-perfect"
                else -> "Aktif: semua efek dilewati dan resampling Android dimatikan"
            }
            10 -> "Berlaku setelah pemutar disambung ulang (otomatis saat diubah)"
            else -> null
        }
    }
}
