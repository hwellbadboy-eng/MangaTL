package com.niven.mangatl

import android.content.Intent
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.SwitchCompat

/** Layar "Audio Engine": saklar utama, 12 fitur, reset semua, simpan dan muat konfigurasi. */
class AudioEngineActivity : AppCompatActivity() {

    private lateinit var list: LinearLayout
    private lateinit var warn: View
    private val switches = HashMap<String, SwitchCompat>()
    private lateinit var master: SwitchCompat

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        AudioEngine.init(this)
        OutputCaps.init(this)
        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setBackgroundColor(AU.BLACK)
        val sv = ScrollView(this)
        sv.isFillViewport = true
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(AU.dp(this, 20), AU.dp(this, 24), AU.dp(this, 20), AU.dp(this, 40))
        sv.addView(col)
        root.addView(sv, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        setContentView(root)
        root.setOnApplyWindowInsetsListener { v, ins ->
            v.setPadding(0, ins.systemWindowInsetTop, 0, ins.systemWindowInsetBottom)
            ins
        }

        // header
        val hd = LinearLayout(this)
        hd.orientation = LinearLayout.HORIZONTAL
        hd.gravity = Gravity.CENTER_VERTICAL
        val back = Ui.iconBtn(this, R.drawable.ic_back, "Kembali") { finish() }
        back.background = AU.shape(0, 99f, this, AU.LN, 1)
        hd.addView(back, LinearLayout.LayoutParams(AU.dp(this, 44), AU.dp(this, 44)))
        val title = AU.text(this, "Audio Engine", 24f, AU.WHITE, true)
        title.setPadding(AU.dp(this, 12), 0, 0, 0)
        hd.addView(title, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        master = AU.switch(this, AudioEngine.master) { v ->
            AudioEngine.setMaster(v)
            refresh()
        }
        hd.addView(master)
        col.addView(hd)

        // tombol aksi
        val actions = LinearLayout(this)
        actions.orientation = LinearLayout.HORIZONTAL
        val lpA = { l: LinearLayout.LayoutParams -> l.rightMargin = AU.dp(this, 8); l }
        val bReset = AU.chip(this, "Reset semua", false)
        bReset.setOnClickListener {
            AudioEngine.resetAll()
            refresh()
            Toast.makeText(this, "Semua pengaturan dikembalikan ke default", Toast.LENGTH_SHORT).show()
        }
        val bSave = AU.chip(this, "Simpan", false)
        bSave.setOnClickListener {
            Toast.makeText(
                this, if (AudioEngine.saveSlot()) "Konfigurasi disimpan" else "Gagal menyimpan", Toast.LENGTH_SHORT
            ).show()
        }
        val bLoad = AU.chip(this, "Muat", false)
        bLoad.setOnClickListener {
            if (!AudioEngine.hasSlot()) {
                Toast.makeText(this, "Belum ada konfigurasi tersimpan", Toast.LENGTH_SHORT).show()
            } else if (AudioEngine.loadSlot()) {
                refresh()
                Toast.makeText(this, "Konfigurasi dimuat", Toast.LENGTH_SHORT).show()
            } else {
                Toast.makeText(this, "Gagal memuat", Toast.LENGTH_SHORT).show()
            }
        }
        for (b in listOf(bReset, bSave, bLoad)) {
            actions.addView(b, lpA(LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)))
        }
        val hs = android.widget.HorizontalScrollView(this)
        hs.isHorizontalScrollBarEnabled = false
        hs.addView(actions)
        val lpH = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        lpH.topMargin = AU.dp(this, 14)
        col.addView(hs, lpH)

        val w = AU.text(this, "Engine dimatikan: semua efek dilewati (bypass).", 13f, AU.WHITE)
        w.background = AU.shape(AU.CD, 12f, this, AU.LN, 1)
        w.setPadding(AU.dp(this, 12), AU.dp(this, 10), AU.dp(this, 12), AU.dp(this, 10))
        warn = w
        val lpW = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        lpW.topMargin = AU.dp(this, 12)
        col.addView(w, lpW)

        list = LinearLayout(this)
        list.orientation = LinearLayout.VERTICAL
        col.addView(list, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))

        for (f in AudioEngine.features) {
            val row = LinearLayout(this)
            row.orientation = LinearLayout.HORIZONTAL
            row.gravity = Gravity.CENTER_VERTICAL
            row.setPadding(0, AU.dp(this, 10), 0, AU.dp(this, 10))
            val tx = LinearLayout(this)
            tx.orientation = LinearLayout.VERTICAL
            tx.addView(AU.text(this, f.title, 15f, AU.WHITE, true))
            tx.addView(AU.text(this, f.desc, 12f, AU.MUT))
            row.addView(tx, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
            val s = AU.switch(this, AudioEngine.featureOn(f.id)) { v ->
                AudioEngine.setOn(f.id, v)
                refresh()
            }
            switches[f.id] = s
            row.addView(s)
            row.setOnClickListener {
                startActivity(Intent(this, AudioFeatureActivity::class.java).putExtra("fid", f.id))
            }
            list.addView(row)
            val line = View(this)
            line.setBackgroundColor(0xFF1F1F23.toInt())
            list.addView(line, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 1))
        }

        val note = AU.text(
            this,
            "Urutan chain: Normalisasi → EQ → Bass → Vokal → Stereo → Spatial → Crossfeed → Reverb → " +
                "Kompresor → Limiter → Hi-Res (peta kanal, resample, dither). Limiter di ujung menjaga headroom " +
                "dan mencegah clipping. Visualizer membaca sinyal setelah Limiter. " +
                "Ketuk nama fitur untuk membuka parameter.",
            12f, AU.MUT
        )
        note.setPadding(0, AU.dp(this, 16), 0, 0)
        col.addView(note)
    }

    override fun onResume() {
        super.onResume()
        refresh()
    }

    private fun refresh() {
        master.setOnCheckedChangeListener(null)
        master.isChecked = AudioEngine.master
        master.setOnCheckedChangeListener { _, v ->
            AudioEngine.setMaster(v)
            refresh()
        }
        // alasan efek tidak terdengar: engine mati, atau status aliran (multikanal, bit-perfect, dll.)
        val st = AudioEngine.dspStatus
        val msg = when {
            !AudioEngine.master -> "Engine dimatikan: semua efek dilewati (bypass)."
            st.isNotEmpty() -> st
            else -> ""
        }
        (warn as android.widget.TextView).text = msg
        warn.visibility = if (msg.isEmpty()) View.GONE else View.VISIBLE
        for (f in AudioEngine.features) {
            val s = switches[f.id] ?: continue
            s.setOnCheckedChangeListener(null)
            s.isChecked = AudioEngine.featureOn(f.id)
            s.setOnCheckedChangeListener { _, v ->
                AudioEngine.setOn(f.id, v)
                refresh()
            }
        }
    }
}
