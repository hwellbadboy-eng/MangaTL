package com.niven.mangatl

import android.content.Context
import com.google.ai.edge.litertlm.Backend
import com.google.ai.edge.litertlm.Content
import com.google.ai.edge.litertlm.Contents
import com.google.ai.edge.litertlm.Conversation
import com.google.ai.edge.litertlm.ConversationConfig
import com.google.ai.edge.litertlm.Engine
import com.google.ai.edge.litertlm.EngineConfig
import com.google.ai.edge.litertlm.Message
import com.google.ai.edge.litertlm.MessageCallback
import com.google.ai.edge.litertlm.SamplerConfig
import java.io.File
import java.util.concurrent.CountDownLatch
import java.util.concurrent.Semaphore
import java.util.concurrent.atomic.AtomicReference

object Gemma {

    private const val PREF_FILE = "mangatl"
    private const val PREF_MODEL = "model_file"
    private const val CHUNK_MAX_LINES = 8
    private const val CHUNK_MAX_CHARS = 700

    enum class Style(val label: String, val rule: String) {
        AKU_KAMU(
            "Santai (aku/kamu)",
            "Use casual spoken Indonesian with aku/kamu. Do NOT use gue/lo/lu, and never stiff textbook wording."
        ),
        GUE_LO(
            "Gaul (gue/lo)",
            "Use casual Jakarta street slang with gue/lo and natural particles like sih, dong, deh, kok."
        ),
        SOPAN(
            "Sopan (saya/Anda)",
            "Use polite, neutral Indonesian with saya/Anda, still natural and not stiff."
        )
    }

    // Satu model, satu pemakai pada satu waktu (terjemah ATAU chat).
    private val lock = Semaphore(1)

    private var engine: Engine? = null
    private var enginePath: String? = null

    var backendName: String = "-"
        private set

    // Konteks berkelanjutan antar halaman (4 pasang terakhir) + halaman terakhir untuk chat.
    private val history = ArrayList<Pair<String, String>>()

    @Volatile
    var lastPage: List<Pair<String, String>> = emptyList()
        private set

    @Volatile
    private var currentConv: Conversation? = null

    @Volatile
    private var chatCancelled = false

    // Percakapan chat dipakai ulang antar pesan (KV cache tetap hidup), jadi system prompt dan riwayat
    // tidak di-prefill ulang tiap giliran. Hanya diakses saat memegang [lock].
    private var chatConv: Conversation? = null
    private var chatSig = ""
    private var chatExpect = -1
    private var chatLastUser = ""
    private var chatChars = 0

    private fun dropChat() {
        try {
            chatConv?.close()
        } catch (_: Throwable) {
        }
        chatConv = null
        chatExpect = -1
    }

    data class Result(val lines: List<String>, val mode: String)

    fun resetContext() {
        synchronized(history) { history.clear() }
        synchronized(lineCache) { lineCache.clear() }
        lastPage = emptyList()
    }

    /** Semua file .litertlm di folder data app, termasuk yang ditaruh di subfolder (Ai 1, Ai 2, ...). */
    fun listModels(context: Context): List<File> {
        val dir = context.getExternalFilesDir(null) ?: return emptyList()
        return dir.walkTopDown()
            .maxDepth(3)
            .filter {
                it.isFile && it.name.endsWith(".litertlm", ignoreCase = true) &&
                    !relName(dir, it).split("/").any { part -> part == "_cache" }
            }
            .sortedBy { relName(dir, it).lowercase() }
            .toList()
    }

    /** Path relatif terhadap folder data app, mis. "Ai 1/Qwen3.5-4B_mixed_int4.litertlm". */
    fun relName(context: Context, f: File): String {
        val dir = context.getExternalFilesDir(null) ?: return f.name
        return relName(dir, f)
    }

    private fun relName(dir: File, f: File): String =
        try {
            f.relativeTo(dir).path.replace(File.separatorChar, '/')
        } catch (_: Throwable) {
            f.name
        }

    /** Model terpilih (dari pengaturan). Kalau belum dipilih / file hilang: Gemma dulu, lalu apa saja yang ada. */
    fun findModel(context: Context): File? {
        val all = listModels(context)
        if (all.isEmpty()) return null
        val want = context.getSharedPreferences(PREF_FILE, Context.MODE_PRIVATE).getString(PREF_MODEL, null)
        return all.firstOrNull { relName(context, it) == want }
            ?: all.firstOrNull { it.name == want }
            ?: all.firstOrNull { it.name.contains("gemma", ignoreCase = true) }
            ?: all.first()
    }

    fun selectModel(context: Context, f: File) {
        context.getSharedPreferences(PREF_FILE, Context.MODE_PRIVATE)
            .edit().putString(PREF_MODEL, relName(context, f)).apply()
    }

    /** Muat model di latar belakang supaya terjemahan pertama tidak menunggu lama. */
    fun warmUp(context: Context, model: File) {
        lock.acquire()
        try {
            ensureEngine(context.applicationContext, model)
        } finally {
            lock.release()
        }
    }

    /**
     * Folder cache khusus per model, ditaruh di samping model (mis. "Ai 1/_cache").
     * Kalau modelnya langsung di folder files/, dipakai "_cache/<nama model>".
     * Kalau gagal dibuat, jatuh ke cache internal app.
     */
    private fun cacheDirFor(context: Context, model: File): String {
        val root = context.getExternalFilesDir(null)
        val parent = model.parentFile
        val dir = if (root != null && parent != null && parent.absolutePath != root.absolutePath) {
            File(parent, "_cache")
        } else {
            File(root ?: context.cacheDir, "_cache/" + model.name.removeSuffix(".litertlm"))
        }
        return try {
            if (dir.isDirectory || dir.mkdirs()) dir.absolutePath else context.cacheDir.absolutePath
        } catch (_: Throwable) {
            context.cacheDir.absolutePath
        }
    }

    @Synchronized
    private fun ensureEngine(context: Context, model: File): Engine {
        val path = model.absolutePath
        val cur = engine
        if (cur != null && enginePath == path) return cur
        dropChat()
        try {
            cur?.close()
        } catch (_: Throwable) {
        }
        engine = null

        val cache = cacheDirFor(context, model)
        var firstError: Throwable? = null

        // Urutan: GPU konteks besar -> GPU konteks kecil -> CPU.
        // Backend yang berhasil diingat per model, jadi muat berikutnya tidak mencoba ulang yang gagal.
        val attempts = listOf(
            Triple("GPU", true, 4096),
            Triple("GPU", true, 2048),
            Triple("CPU", false, 2048)
        )
        val sp = context.getSharedPreferences(PREF_FILE, Context.MODE_PRIVATE)
        val beKey = "be_" + model.name
        val startIdx = sp.getInt(beKey, 0).coerceIn(0, attempts.size - 1)
        for (idx in startIdx until attempts.size) {
            val (name, gpu, tokens) = attempts[idx]
            var e: Engine? = null
            try {
                e = Engine(
                    EngineConfig(
                        modelPath = path,
                        backend = if (gpu) Backend.GPU() else Backend.CPU(),
                        maxNumTokens = tokens,
                        cacheDir = cache
                    )
                )
                e.initialize()
                backendName = if (firstError == null) name else "$name (GPU penuh gagal: ${firstError?.message})"
                engine = e
                enginePath = path
                sp.edit().putInt(beKey, idx).apply()
                return e
            } catch (t: Throwable) {
                if (firstError == null) firstError = t
                try {
                    e?.close()
                } catch (_: Throwable) {
                }
            }
        }
        // Semua gagal: lupakan pilihan tersimpan supaya muat berikutnya mencoba dari awal.
        sp.edit().remove(beKey).apply()
        throw IllegalStateException("Model gagal dimuat: ${firstError?.message}", firstError)
    }

    // ---------------------------------------------------------------- prompt

    private fun translatorSystem(style: Style, glossary: String): String = buildString {
        append("You are an expert manga and comic localizer. Translate English into natural, native-sounding Indonesian.\n")
        append("Rules:\n")
        append("1. Translate meaning, emotion and intent, never word for word. Idioms, slang, puns and sarcasm must become the Indonesian expression a native would really say, never a literal rendering.\n")
        append("2. Keep each line's emotion: shouting stays punchy with '!', hesitation keeps '...', stutters like 'W-what' become 'A-apa'. Keep the speaker's attitude (teasing, angry, shy, seductive, sarcastic).\n")
        append("3. Sound effects and laughs (HEH, HAHA, GULP, SIGH...) stay short; use Indonesian onomatopoeia when one exists (GULP = GLEK).\n")
        append("4. Keep names, numbers and honorifics unchanged. Do not censor, soften, explain or add anything.\n")
        append("5. ${style.rule}\n")
        append("6. Output plain text only: no markdown, no asterisks, no quotes around the line.\n")
        if (glossary.isNotBlank()) {
            append("Story context and glossary from the user (follow strictly):\n")
            append(glossary.trim().take(600))
            append("\n")
        }
        append("\nExample input:\n[1] W-What, you're going to...\n[2] Heh heh.\n[3] It's raining cats and dogs!\n[4] You're pulling my leg, aren't you?\n")
        append("Example output:\n[1] A-apa, kamu mau...\n[2] Heh heh.\n[3] Hujannya deres banget!\n[4] Kamu lagi ngerjain aku, kan?")
    }

    private const val ANALYST_SYSTEM =
        "You analyze one comic page. Be brief and concrete. Reply with notes only, no preamble."

    private fun analystPrompt(lines: List<String>): String = buildString {
        append("Dialogue lines of one comic page, in reading order:\n")
        lines.forEachIndexed { i, s -> append("[${i + 1}] $s\n") }
        append("\nIn at most 70 words write notes for the translator: (a) the situation and who talks to whom, ")
        append("(b) the emotion/tone of the lines, (c) every idiom, slang, pun, innuendo or double meaning with its REAL intended meaning. ")
        append("If a line is a sound effect, say so.")
    }

    // ---------------------------------------------- token khusus & mode berpikir
    // Dipakai semua model: Gemma (<end_of_turn>), Qwen (<|im_end|>, <think>...</think>), dll.

    private val SPECIAL_TOKENS = listOf(
        "<end_of_turn>", "<start_of_turn>", "<eos>", "<bos>",
        "<|im_end|>", "<|im_start|>", "<|endoftext|>"
    )

    private fun stripSpecial(t: String): String {
        var s = t
        for (tok in SPECIAL_TOKENS) s = s.replace(tok, "")
        return s
    }

    /** Buang blok <think>...</think> (juga yang tidak ditutup, atau hanya ada penutupnya). */
    private fun stripThink(t: String): String {
        var s = t
        s = s.replace(Regex("(?s)<think>.*?</think>"), "")
        s = s.replace(Regex("(?s)^.*?</think>"), "")
        s = s.replace(Regex("(?s)<think>.*$"), "")
        return s
    }

    /** Panjang ekor teks yang mungkin awal sebuah tag (mis. "<thi") dan perlu ditahan dulu. */
    private fun holdBack(text: String): Int {
        val i = text.lastIndexOf('<')
        if (i < 0) return 0
        if (text.indexOf('>', i) >= 0) return 0
        return if (text.length - i <= 13) text.length - i else 0
    }

    /** Penyaring untuk teks streaming: membuang <think> dan token khusus yang bisa terpotong antar potongan. */
    private class StreamFilter {
        private val buf = StringBuilder()
        private var inThink = false
        private var started = false

        fun feed(piece: String): String {
            buf.append(piece)
            val out = StringBuilder()
            while (true) {
                val text = buf.toString()
                if (inThink) {
                    val end = text.indexOf("</think>")
                    if (end >= 0) {
                        buf.delete(0, end + 8)
                        inThink = false
                        continue
                    }
                    buf.delete(0, text.length - holdBack(text))
                    break
                } else {
                    val st = text.indexOf("<think>")
                    val cl = text.indexOf("</think>")
                    if (cl >= 0 && (st < 0 || cl < st) && !started && out.isEmpty()) {
                        // Template sudah menaruh <think> di awal: buang semua sampai penutupnya.
                        buf.delete(0, cl + 8)
                        continue
                    }
                    if (st >= 0) {
                        out.append(text, 0, st)
                        buf.delete(0, st + 7)
                        inThink = true
                        continue
                    }
                    val keep = holdBack(text)
                    out.append(text, 0, text.length - keep)
                    buf.delete(0, text.length - keep)
                    break
                }
            }
            return emit(out.toString())
        }

        fun flush(): String {
            val rest = if (inThink) "" else buf.toString()
            buf.setLength(0)
            return emit(rest)
        }

        private fun emit(raw: String): String {
            var t = stripSpecial(raw)
            if (!started) {
                t = t.trimStart()
                if (t.isNotEmpty()) started = true
            }
            return t
        }
    }

    private fun cleanLine(raw: String): String {
        var s = stripSpecial(stripThink(raw))
            .replace("**", "")
            .trim()
        if (s.startsWith("```")) {
            s = s.replaceFirst(Regex("^```[a-zA-Z]*\\s*"), "").replaceFirst(Regex("\\s*```$"), "").trim()
        }
        s = s.replace(Regex("^(Translation|Terjemahan)\\s*:\\s*", RegexOption.IGNORE_CASE), "")
        if (s.length >= 2 && s.first() == '"' && s.last() == '"') s = s.substring(1, s.length - 1)
        return s.trim()
    }

    private fun textOf(m: Message): String {
        val sb = StringBuilder()
        for (c in m.contents.contents) {
            if (c is Content.Text) sb.append(c.text)
        }
        return sb.toString()
    }

    private fun ask(eng: Engine, system: String, prompt: String, temperature: Double): String {
        dropChat()
        val conv = eng.createConversation(
            ConversationConfig(
                systemInstruction = Contents.of(system),
                samplerConfig = SamplerConfig(topK = 40, topP = 0.9, temperature = temperature, seed = 0)
            )
        )
        try {
            val reply = conv.sendMessage(prompt)
            return textOf(reply)
        } finally {
            try {
                conv.close()
            } catch (_: Throwable) {
            }
        }
    }

    /** Baca balasan bernomor [1] ... [2] ...; kembalikan peta nomor -> teks. */
    private fun parseMarked(reply: String): Map<Int, String> {
        val re = Regex("^\\s*(?:\\[(\\d+)]|(\\d+)[.):])\\s*(.*)$")
        val map = HashMap<Int, String>()
        var last = -1
        for (line in reply.lines()) {
            val m = re.find(line)
            if (m != null) {
                val n = (m.groupValues[1].ifEmpty { m.groupValues[2] }).toInt()
                last = n
                map[n] = m.groupValues[3].trim()
            } else if (last != -1 && line.isNotBlank()) {
                map[last] = ((map[last] ?: "") + " " + line.trim()).trim()
            }
        }
        return map
    }

    private fun makeChunks(idxs: List<Int>, prepared: List<String>): List<List<Int>> {
        val chunks = ArrayList<List<Int>>()
        var cur = ArrayList<Int>()
        var chars = 0
        for (i in idxs) {
            val len = prepared[i].length
            if (cur.isNotEmpty() && (cur.size >= CHUNK_MAX_LINES || chars + len > CHUNK_MAX_CHARS)) {
                chunks.add(cur)
                cur = ArrayList()
                chars = 0
            }
            cur.add(i)
            chars += len
        }
        if (cur.isNotEmpty()) chunks.add(cur)
        return chunks
    }

    // ------------------------------------------------------------ terjemahan

    fun translate(
        context: Context,
        model: File,
        lines: List<String>,
        style: Style,
        accurate: Boolean,
        glossary: String,
        onStatus: (String) -> Unit,
        onProgress: (List<String?>) -> Unit
    ): Result {
        val prepared = lines.map { TextUtil.normalizeForModel(it) }
        val out = arrayOfNulls<String>(lines.size)
        val idxs = ArrayList<Int>()
        for (i in lines.indices) {
            if (TextUtil.isTranslatable(prepared[i])) idxs.add(i) else out[i] = lines[i]
        }
        onProgress(out.toList())

        lock.acquire()
        try {
            onStatus("Memuat model...")
            val eng = ensureEngine(context.applicationContext, model)
            val system = translatorSystem(style, glossary)

            // Analisis konteks (hanya mode akurat, dan kalau ada cukup teks)
            var notes = ""
            val totalChars = idxs.sumOf { prepared[it].length }
            if (accurate && idxs.size >= 2 && totalChars >= 40) {
                onStatus("Menganalisis konteks halaman...")
                try {
                    notes = cleanLine(
                        ask(eng, ANALYST_SYSTEM, analystPrompt(idxs.map { prepared[it] }), 0.2)
                    ).take(700)
                } catch (_: Throwable) {
                    notes = ""
                }
            }

            val prev = synchronized(history) { history.toList() }
            val chunks = makeChunks(idxs, prepared)
            var mode = if (notes.isNotBlank()) "akurat" else "cepat"
            var fallbackUsed = false

            chunks.forEachIndexed { ci, chunk ->
                onStatus("Menerjemahkan ${ci + 1}/${chunks.size}...")
                val prompt = buildString {
                    append("Translate these comic lines from English to Indonesian.\n")
                    append("They are consecutive dialogue lines from ONE page, in reading order; a sentence can continue across lines.\n")
                    if (notes.isNotBlank()) append("Page notes (use them for tone and idioms): $notes\n")
                    if (prev.isNotEmpty()) {
                        append("Previous lines, for continuity only (do not translate again):\n")
                        prev.forEach { append("- ${it.first} => ${it.second}\n") }
                    }
                    append("Important: translate every numbered line faithfully. Keep the same meaning and emotional intent. Do not merge, omit or add dialogue.\n")
                    append("Reply with the same [n] markers, exactly one line per marker, nothing else.\n\n")
                    chunk.forEachIndexed { n, i -> append("[${n + 1}] ${prepared[i]}\n") }
                }
                val parsed = try {
                    parseMarked(ask(eng, system, prompt, 0.3))
                } catch (_: Throwable) {
                    emptyMap()
                }
                chunk.forEachIndexed { n, i ->
                    var t = cleanLine(parsed[n + 1] ?: "")
                    val suspicious = t.isBlank() ||
                        (t.equals(prepared[i], ignoreCase = true) && prepared[i].split(" ").size > 3)
                    if (suspicious) {
                        fallbackUsed = true
                        t = try {
                            cleanLine(
                                ask(
                                    eng, system,
                                    "Translate this comic line from English to Indonesian.\n" +
                                        (if (notes.isNotBlank()) "Page notes: $notes\n" else "") +
                                        "Output ONLY the translation.\n\n${prepared[i]}",
                                    0.3
                                )
                            )
                        } catch (_: Throwable) {
                            ""
                        }
                    }
                    out[i] = if (t.isBlank()) lines[i] else t
                }
                onProgress(out.toList())
            }
            if (fallbackUsed) mode += " + ulang per baris"

            val pairs = lines.indices.map { Pair(lines[it], out[it] ?: lines[it]) }
            lastPage = pairs
            synchronized(history) {
                pairs.filter { TextUtil.isTranslatable(it.first) }
                    .takeLast(4)
                    .forEach { history.add(Pair(it.first.take(120), it.second.take(120))) }
                while (history.size > 4) history.removeAt(0)
            }
            return Result(out.map { it ?: "" }, mode)
        } finally {
            lock.release()
        }
    }

    // ------------------------------------------------------------ terjemah komik (Manga Translator)

    /** Seruan pendek yang di bahasa Indonesia ditulis sama (Ah, Hmm, Hehe, Nh...): tidak perlu lewat model. */
    private val INTERJ = Regex("^(a+h+|e+h+|o+h+|u+h+|h+m+|m+h*n*|n+h+n*|h+a+h+|h+e+h+e*h*|h+u+h+|ng+h+|u+g+h+)$")

    /**
     * Terjemahkan satu halaman komik dari [srcLang] (nama bahasa dalam bahasa Inggris, mis. "Japanese")
     * ke bahasa Indonesia. Hasil sejajar dengan [lines]. Dipakai Manga Translator; fungsi lain tidak berubah.
     */
    /** Contoh gaya lisan (asli buatan sendiri) supaya model kecil meniru nada percakapan, bukan terjemahan buku. */
    private fun fewShot(style: Style): String {
        if (style == Style.SOPAN) return ""
        val me = if (style == Style.GUE_LO) "gue" else "aku"
        val you = if (style == Style.GUE_LO) "lo" else "kamu"
        return "\nExamples:\n" +
            "\"I haven't heard from him in ages.\" => \"Udah lama banget $me nggak dapet kabar dari dia.\"\n" +
            "\"Would you mind helping me with this?\" => \"Bisa bantuin $me soal ini nggak?\"\n" +
            "\"That is so like you.\" => \"Ya ampun, $you banget deh.\"\n" +
            "\"Don't tell me you forgot!\" => \"Jangan bilang $you lupa!\""
    }

    private val CASUAL_RULES: List<Pair<Regex, String>> = listOf(
        Regex("\\bsangat (\\p{L}+)", RegexOption.IGNORE_CASE) to "$1 banget",
        Regex("\\btidak\\b", RegexOption.IGNORE_CASE) to "nggak",
        Regex("\\bsudah\\b", RegexOption.IGNORE_CASE) to "udah",
        Regex("\\bsaja\\b", RegexOption.IGNORE_CASE) to "aja",
        Regex("\\bhanya\\b", RegexOption.IGNORE_CASE) to "cuma",
        Regex("\\bseperti\\b", RegexOption.IGNORE_CASE) to "kayak",
        Regex("\\bbagaimana\\b", RegexOption.IGNORE_CASE) to "gimana",
        Regex("\\bmengapa\\b", RegexOption.IGNORE_CASE) to "kenapa",
        Regex("\\bberikan\\b", RegexOption.IGNORE_CASE) to "kasih",
        Regex("\\bkirimkan\\b", RegexOption.IGNORE_CASE) to "kirimin",
        Regex("\\btunjukkan\\b", RegexOption.IGNORE_CASE) to "tunjukin",
        Regex("\\bceritakan\\b", RegexOption.IGNORE_CASE) to "ceritain"
    )

    /** Ganti kata kaku yang masih lolos dari model dengan padanan lisan. Tidak dipakai untuk gaya sopan. */
    private fun casualize(text: String, style: Style): String {
        if (style == Style.SOPAN) return text
        var t = text
        for ((re, to) in CASUAL_RULES) {
            t = re.replace(t) { m ->
                val rep = if (to.contains("$1")) to.replace("$1", m.groupValues.getOrElse(1) { "" }) else to
                if (m.value.first().isUpperCase()) rep.replaceFirstChar { it.uppercase() } else rep
            }
        }
        if (style == Style.GUE_LO) {
            t = Regex("\\b(saya|aku)\\b", RegexOption.IGNORE_CASE).replace(t) { m -> if (m.value.first().isUpperCase()) "Gue" else "gue" }
            t = Regex("\\b(kamu|Anda)\\b", RegexOption.IGNORE_CASE).replace(t) { m -> if (m.value.first().isUpperCase()) "Lo" else "lo" }
        } else {
            t = Regex("\\bsaya\\b", RegexOption.IGNORE_CASE).replace(t) { m -> if (m.value.first().isUpperCase()) "Aku" else "aku" }
            t = Regex("\\bAnda\\b", RegexOption.IGNORE_CASE).replace(t) { m -> if (m.value.first().isUpperCase()) "Kamu" else "kamu" }
        }
        return t
    }

    fun translateComic(
        context: Context,
        model: File,
        lines: List<String>,
        srcLang: String,
        style: Style,
        glossary: String,
        onLog: (String) -> Unit = {},
        onStatus: (String) -> Unit
    ): List<String> {
        val prepared = lines.map { it.replace("\n", " ").replace(Regex("\\s+"), " ").trim() }
        val out = arrayOfNulls<String>(lines.size)
        val idxs = ArrayList<Int>()
        for (i in lines.indices) {
            val letters = prepared[i].count { it.isLetter() }
            val cjk = prepared[i].any { it.isLetter() && it.code >= 0x2E80 }
            val core = prepared[i].lowercase().filter { it.isLetter() }
            if (INTERJ.matches(core)) out[i] = lines[i]
            else if (letters >= 2 || (cjk && letters >= 1)) idxs.add(i) else out[i] = lines[i]
        }
        if (idxs.isEmpty()) return lines

        lock.acquire()
        try {
            onStatus("Memuat model...")
            val tAll = System.nanoTime()
            val eng = ensureEngine(context.applicationContext, model)
            val tLoad = (System.nanoTime() - tAll) / 1_000_000
            var retries = 0
            val system = buildString {
                append("Translate $srcLang comic dialogue into natural spoken Indonesian, the way real people talk in a casual drama. ")
                append("Translate the intended meaning, not the literal word order. Use the surrounding dialogue to resolve pronouns, references, idioms, sarcasm and implied meaning. ")
                append("Keep the emotion, attitude and relationship between speakers consistent. Do not invent facts, speakers, gender, relationship details or missing words. ")
                append("If the source is ambiguous, choose the most contextually likely natural meaning without adding an explanation. ")
                append("Keep names, numbers and important terms unchanged; keep sound effects and laughs short. Stutters like 'W-what' become 'A-apa'. ")
                append("Keep each line concise and preserve its original intent. Use one consistent register for the whole page. ${style.rule} ")
                if (style != Style.SOPAN) {
                    append("Write like speech, not like a textbook: nggak, udah, banget, aja, cuma, kayak, gimana, kenapa, kasih; ")
                    append("verbs like kirimin/bantuin; particles (sih, dong, deh, kok, ya, nih) only where a native speaker would. ")
                    append("Avoid stiff words such as sangat, tidak, sudah, hanya, merupakan, tersebut, adalah. ")
                }
                append("Plain text only, no quotes.")
                if (glossary.isNotBlank()) append(" Glossary: ").append(glossary.trim().take(400))
                append(fewShot(style))
            }
            // Rolling context: history from previous pages plus translations from earlier
            // chunks on this page. This prevents context from resetting at every 8-line chunk.
            val rollingContext = ArrayList<Pair<String, String>>()
            rollingContext.addAll(synchronized(history) { history.toList() }.takeLast(8))
            val chunks = makeChunks(idxs, prepared)

            chunks.forEachIndexed { ci, chunk ->
                onStatus("Menerjemahkan ${ci + 1}/${chunks.size}...")
                val tChunk = System.nanoTime()
                val prompt = buildString {
                    append("Translate these comic lines from $srcLang to Indonesian.\n")
                    append("They are dialogue and text lines from ONE page, in reading order; a sentence can continue across lines.\n")
                    if (rollingContext.isNotEmpty()) {
                        append("Recent story dialogue context, oldest first. These are already translated; use them only to understand the scene, speakers, references and tone. Do NOT output them again:\n")
                        rollingContext.takeLast(8).forEach { append("SOURCE: ${it.first}\nINDONESIAN: ${it.second}\n") }
                    }
                    append("Important: translate every numbered line faithfully. Keep the same meaning and emotional intent. Do not merge, omit or add dialogue.\n")
                    append("Reply with the same [n] markers, exactly one line per marker, nothing else.\n\n")
                    chunk.forEachIndexed { n, i -> append("[${n + 1}] ${prepared[i]}\n") }
                }
                val parsed = try {
                    parseMarked(ask(eng, system, prompt, 0.3))
                } catch (_: Throwable) {
                    emptyMap()
                }
                onLog("potongan ${ci + 1}: ${chunk.size} baris, ${(System.nanoTime() - tChunk) / 1_000_000}ms")
                chunk.forEachIndexed { n, i ->
                    var t = cleanLine(parsed[n + 1] ?: "")
                    val suspicious = t.isBlank() ||
                        (t.equals(prepared[i], ignoreCase = true) && prepared[i].split(" ").size > 3)
                    if (suspicious) {
                        retries++
                        t = try {
                            cleanLine(
                                ask(
                                    eng, system,
                                    buildString {
                                        append("Translate this comic line from $srcLang to Indonesian, using the recent context to resolve meaning.\n")
                                        rollingContext.takeLast(8).forEach { append("Previous: ${it.first} => ${it.second}\n") }
                                        append("Output ONLY the translation. Do not explain.\n\n${prepared[i]}")
                                    },
                                    0.3
                                )
                            )
                        } catch (_: Throwable) {
                            ""
                        }
                    }
                    out[i] = if (t.isBlank()) lines[i] else casualize(t, style)
                }
                // Add this completed chunk to the context for the NEXT chunk on this page.
                chunk.forEach { i ->
                    val translated = out[i]?.takeIf { it.isNotBlank() } ?: lines[i]
                    rollingContext.add(Pair(prepared[i].take(180), translated.take(180)))
                }
                while (rollingContext.size > 8) rollingContext.removeAt(0)
            }

            val totalMs = (System.nanoTime() - tAll) / 1_000_000
            onLog("muat=${tLoad}ms total=${totalMs}ms potongan=${chunks.size} ulang=$retries baris=${idxs.size} ~${totalMs / maxOf(1, idxs.size)}ms/baris")
            synchronized(history) {
                idxs.takeLast(8).forEach { i ->
                    history.add(Pair(prepared[i].take(180), (out[i] ?: lines[i]).take(180)))
                }
                while (history.size > 8) history.removeAt(0)
            }
            return lines.indices.map { out[it] ?: lines[it] }
        } finally {
            lock.release()
        }
    }

    // ------------------------------------------------------------ mode cepat (terjemah layar / game)

    private const val CACHE_MAX = 1500

    // Cache terjemahan per baris (teks sama + gaya + glosarium sama = langsung tampil tanpa model).
    private val lineCache = object : LinkedHashMap<String, String>(256, 0.75f, true) {
        override fun removeEldestEntry(eldest: MutableMap.MutableEntry<String, String>?): Boolean =
            size > CACHE_MAX
    }

    private fun cacheKey(style: Style, glossary: String, text: String): String =
        "${style.name}|${glossary.trim().hashCode()}|${text.lowercase()}"

    /** Prompt sistem sependek mungkin: prefill tiap terjemahan jadi jauh lebih cepat. */
    private fun fastSystem(style: Style, glossary: String): String = buildString {
        append("Translate English game/app screen text to natural spoken Indonesian. ")
        append(style.rule).append(" ")
        append("Keep emotion, names and numbers. Short menu/button labels stay short. ")
        append("A sentence can continue across lines: translate by meaning, never word for word. ")
        append("Plain text only. Reply ONLY with the same [n] markers, one line each.\n")
        if (glossary.isNotBlank()) {
            append("Glossary (follow strictly): ").append(glossary.trim().take(400)).append("\n")
        }
        append("Example input:\n[1] Are you sure?\n[2] Check the items first.\n")
        append("Example output:\n[1] Kamu yakin?\n[2] Cek barangnya dulu.")
    }

    /** Kirim prompt dengan streaming; onPartial dipanggil dengan seluruh teks yang sudah jadi. */
    private fun streamAsk(
        eng: Engine,
        system: String,
        prompt: String,
        temperature: Double,
        onPartial: (String) -> Unit
    ): String {
        dropChat()
        val conv = eng.createConversation(
            ConversationConfig(
                systemInstruction = Contents.of(system),
                samplerConfig = SamplerConfig(topK = 40, topP = 0.9, temperature = temperature, seed = 0)
            )
        )
        val done = CountDownLatch(1)
        val filter = StreamFilter()
        val acc = StringBuilder()
        val err = AtomicReference<Throwable?>(null)
        try {
            conv.sendMessageAsync(prompt, object : MessageCallback {
                override fun onMessage(message: Message) {
                    val t = filter.feed(textOf(message))
                    if (t.isNotEmpty()) {
                        acc.append(t)
                        onPartial(acc.toString())
                    }
                }

                override fun onDone() {
                    val rest = filter.flush()
                    if (rest.isNotEmpty()) {
                        acc.append(rest)
                        onPartial(acc.toString())
                    }
                    done.countDown()
                }

                override fun onError(throwable: Throwable) {
                    err.set(throwable)
                    done.countDown()
                }
            })
            done.await()
        } finally {
            try {
                conv.close()
            } catch (_: Throwable) {
            }
        }
        err.get()?.let { throw it }
        return acc.toString()
    }

    /**
     * Terjemahan layar yang dioptimalkan untuk kecepatan:
     * cache per baris, satu panggilan model untuk semua baris baru, hasil muncul bertahap (streaming),
     * dan blok terpanjang (biasanya dialog utama) diterjemahkan paling dulu.
     */
    fun translateFast(
        context: Context,
        model: File,
        lines: List<String>,
        style: Style,
        glossary: String,
        onProgress: (List<String?>) -> Unit
    ): Result {
        val prepared = lines.map { TextUtil.normalizeForModel(it) }
        val out = arrayOfNulls<String>(lines.size)
        val todo = ArrayList<Int>()
        for (i in lines.indices) {
            if (!TextUtil.isTranslatable(prepared[i])) {
                out[i] = lines[i]
                continue
            }
            val hit = synchronized(lineCache) { lineCache[cacheKey(style, glossary, prepared[i])] }
            if (hit != null) out[i] = hit else todo.add(i)
        }
        onProgress(out.toList())
        if (todo.isEmpty()) return Result(out.map { it ?: "" }, "cache")

        // Dialog utama (teks paling panjang) dulu, sisanya menyusul sesuai urutan baca.
        todo.sortWith(compareByDescending<Int> { prepared[it].length }.thenBy { it })

        lock.acquire()
        try {
            val eng = ensureEngine(context.applicationContext, model)
            val system = fastSystem(style, glossary)
            val prev = synchronized(history) { history.takeLast(2) }
            val prompt = buildString {
                if (prev.isNotEmpty()) {
                    append("Earlier lines (context only, do not translate):\n")
                    prev.forEach { append("- ${it.first} => ${it.second}\n") }
                }
                append("Translate:\n")
                todo.forEachIndexed { n, i -> append("[${n + 1}] ${prepared[i]}\n") }
                if (model.name.contains("qwen", ignoreCase = true)) append("/no_think")
            }

            var lastShown = ""
            val raw = streamAsk(eng, system, prompt, 0.2) { partial ->
                val parsed = parseMarked(partial)
                var changed = false
                todo.forEachIndexed { n, i ->
                    val t = parsed[n + 1]
                    if (!t.isNullOrBlank()) {
                        val c = cleanLine(t)
                        if (c.isNotBlank() && c != out[i]) {
                            out[i] = c
                            changed = true
                        }
                    }
                }
                if (changed && partial.length != lastShown.length) {
                    lastShown = partial
                    onProgress(out.toList())
                }
            }

            // Hasil akhir: ambil dari balasan lengkap.
            var parsed = parseMarked(raw)
            if (parsed.isEmpty() && todo.size == 1) parsed = mapOf(1 to raw)
            var retries = 0
            todo.forEachIndexed { n, i ->
                var t = cleanLine(parsed[n + 1] ?: "")
                val suspicious = t.isBlank() ||
                    (t.equals(prepared[i], ignoreCase = true) && prepared[i].split(" ").size > 3)
                if (suspicious && retries < 3) {
                    retries++
                    t = try {
                        cleanLine(
                            ask(
                                eng, system,
                                "Translate to Indonesian. Output ONLY the translation.\n\n${prepared[i]}" +
                                    (if (model.name.contains("qwen", ignoreCase = true)) "\n/no_think" else ""),
                                0.2
                            )
                        )
                    } catch (_: Throwable) {
                        ""
                    }
                }
                out[i] = if (t.isBlank()) lines[i] else t
                if (t.isNotBlank() && !t.equals(prepared[i], ignoreCase = true)) {
                    synchronized(lineCache) { lineCache[cacheKey(style, glossary, prepared[i])] = t }
                }
            }
            onProgress(out.toList())

            val pairs = lines.indices.map { Pair(lines[it], out[it] ?: lines[it]) }
            lastPage = pairs
            synchronized(history) {
                pairs.filter { TextUtil.isTranslatable(it.first) && it.first.length > 12 }
                    .sortedByDescending { it.first.length }
                    .take(2)
                    .forEach { history.add(Pair(it.first.take(120), it.second.take(120))) }
                while (history.size > 4) history.removeAt(0)
            }
            return Result(out.map { it ?: "" }, "cepat" + if (retries > 0) " + ulang" else "")
        } finally {
            lock.release()
        }
    }

    // ------------------------------------------------------------------ chat

    private fun chatSystem(glossary: String, nick: String, notes: String, live: Boolean, slots: String): String = buildString {
        append("Kamu teman ngobrol AI berbahasa Indonesia santai (kecuali diminta bahasa lain), dengan kepribadian sesuai aturan di bawah. ")
        append("Kalau diminta, kamu juga ahli penerjemah manga dan komik: jelaskan idiom, slang, emosi, dan nuansa dialog, beri alternatif terjemahan yang natural, dan bantu perbaiki terjemahan.\n")
        append("Kalau pengguna mengajak roleplay atau main peran: ikut, tetap dalam karakter, dan lanjutkan adegan dengan inisiatifmu sendiri. Jangan keluar karakter, jangan bicara seperti asisten, dan jangan menawarkan ganti topik atau bertanya \"mau bahas apa\".\n")
        if (slots.isNotEmpty()) append(slots) else append("Jawab ringkas dan langsung ke inti.\n")
        if (live) append("MODE NGOBROL LANGSUNG (suara): jawabanmu akan dibacakan. Jawab santai 1-3 kalimat pendek, tanpa markdown, tanpa daftar, tanpa emoji, tanpa tanda bintang.\n")
        if (nick.isNotBlank()) append("Nama panggilan pengguna: ${nick.trim().take(40)}. Cara memakainya: sebut HANYA sesekali (sekitar 1 dari 3 balasan), paling banyak SATU kali per balasan, dan jangan di awal tiap kalimat. Di balasan lain pakai \"kamu\" atau langsung tanpa sebutan. Pakai panggilan itu di momen manis, menggoda, atau menenangkan, bukan sebagai pengisi kalimat.\n")
        if (notes.isNotBlank()) append("Hal yang harus kamu ingat tentang pengguna: ${notes.trim().take(500)}\n")
        if (glossary.isNotBlank()) append("Konteks dari pengguna: ${glossary.trim().take(600)}\n")
        val page = lastPage
        if (page.isNotEmpty()) {
            append("\nHalaman manga terakhir yang diterjemahkan (asli => terjemahan):\n")
            var used = 0
            for ((i, p) in page.withIndex()) {
                val line = "${i + 1}. ${p.first.take(200)} => ${p.second.take(200)}\n"
                if (used + line.length > 1800) break
                append(line)
                used += line.length
            }
        }
    }

    private fun sanitizeHistory(hist: List<Pair<Boolean, String>>): List<Message> {
        // Ambil dari belakang sampai batas karakter, lalu pastikan urutan user/model bergantian.
        val picked = ArrayList<Pair<Boolean, String>>()
        var total = 0
        for (h in hist.asReversed()) {
            if (h.second.isBlank()) continue
            if (total + h.second.length > 5000) break
            picked.add(h)
            total += h.second.length
        }
        picked.reverse()
        // Pesan lama dipangkas (4 terakhir utuh) supaya konteks hemat token tapi alurnya tetap nyambung.
        for (k in 0 until picked.size - 4) {
            if (picked[k].second.length > 600) picked[k] = Pair(picked[k].first, picked[k].second.take(600) + "...")
        }
        val clean = ArrayList<Pair<Boolean, String>>()
        for (h in picked) {
            if (clean.isEmpty() && !h.first) continue
            if (clean.isNotEmpty() && clean.last().first == h.first) continue
            clean.add(h)
        }
        if (clean.isNotEmpty() && clean.last().first) clean.removeAt(clean.size - 1)
        return clean.map { if (it.first) Message.user(it.second) else Message.model(it.second) }
    }

    /**
     * Kirim pesan chat dengan streaming. hist = riwayat SEBELUM pesan ini (true = pengguna).
     * onChunk dan onFinish dipanggil dari thread latar belakang.
     */
    fun chat(
        context: Context,
        model: File,
        hist: List<Pair<Boolean, String>>,
        user: String,
        glossary: String,
        nick: String,
        notes: String,
        live: Boolean,
        onChunk: (String) -> Unit,
        onFinish: (String?) -> Unit
    ) {
        chatCancelled = false
        Thread {
            // Tunggu sampai model selesai dimuat / terjemahan selesai (balon chat menampilkan "...").
            lock.acquireUninterruptibly()
            if (chatCancelled) {
                lock.release()
                onFinish(null)
                return@Thread
            }
            var conv: Conversation? = null
            try {
                val eng = ensureEngine(context.applicationContext, model)
                val system = chatSystem(glossary, nick, notes, live, PromptSlots.compose(context))
                val old = chatConv
                val reuse = old != null && system == chatSig && hist.size == chatExpect &&
                    hist.getOrNull(hist.size - 2)?.second == chatLastUser && chatChars < 8000
                val c: Conversation
                if (reuse) {
                    c = old!!
                } else {
                    dropChat()
                    val initial = sanitizeHistory(hist)
                    c = eng.createConversation(
                        ConversationConfig(
                            systemInstruction = Contents.of(system),
                            initialMessages = initial,
                            samplerConfig = SamplerConfig(topK = 40, topP = 0.95, temperature = 0.85, seed = 0)
                        )
                    )
                    chatConv = c
                    chatSig = system
                    chatChars = system.length + initial.sumOf { textOf(it).length }
                }
                conv = c
                currentConv = c

                fun finish(err: String?) {
                    Thread {
                        val keep = err == null && !chatCancelled && chatConv === c
                        if (keep) {
                            chatExpect = hist.size + 2
                            chatLastUser = user
                        } else {
                            dropChat()
                            try {
                                c.close()
                            } catch (_: Throwable) {
                            }
                        }
                        currentConv = null
                        lock.release()
                        onFinish(err)
                    }.start()
                }

                val filter = StreamFilter()
                c.sendMessageAsync(user, object : MessageCallback {
                    override fun onMessage(message: Message) {
                        val t = filter.feed(textOf(message))
                        if (t.isNotEmpty()) {
                            chatChars += t.length
                            onChunk(t)
                        }
                    }

                    override fun onDone() {
                        val rest = filter.flush()
                        if (rest.isNotEmpty()) {
                            chatChars += rest.length
                            onChunk(rest)
                        }
                        chatChars += user.length
                        finish(null)
                    }

                    override fun onError(throwable: Throwable) {
                        finish(
                            if (chatCancelled) null
                            else (throwable.message ?: throwable::class.java.simpleName)
                        )
                    }
                })
            } catch (t: Throwable) {
                dropChat()
                try {
                    conv?.close()
                } catch (_: Throwable) {
                }
                currentConv = null
                lock.release()
                onFinish(t.message ?: t::class.java.simpleName)
            }
        }.start()
    }

    fun chatCancel() {
        chatCancelled = true
        try {
            currentConv?.cancelProcess()
        } catch (_: Throwable) {
        }
    }
}
