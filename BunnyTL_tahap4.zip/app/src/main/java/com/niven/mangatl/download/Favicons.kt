package com.niven.mangatl

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import java.io.ByteArrayOutputStream
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.ConcurrentHashMap

/**
 * Ikon situs buatan pengguna, diambil langsung dari situsnya (/favicon.ico, atau <link rel="icon"> di halaman login).
 * Hanya disimpan di MEMORI selama app hidup: tidak ditulis ke penyimpanan, hilang saat app ditutup,
 * dan tidak membesarkan ukuran APK. Gagal diambil = kotak tetap berhuruf (tidak dicoba lagi di sesi yang sama).
 */
object Favicons {
    private val mem = ConcurrentHashMap<String, Bitmap>()
    private val tried = ConcurrentHashMap.newKeySet<String>()
    private const val UA = "Mozilla/5.0 (Linux; Android 14; Mobile) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Mobile Safari/537.36"

    fun get(key: String): Bitmap? = mem[key]

    /** Ambil di latar belakang; [onDone] dipanggil (di thread latar) hanya kalau ikon berhasil didapat. */
    fun prefetch(site: LoginSite, onDone: () -> Unit) {
        if (!tried.add(site.key)) return
        Thread {
            val bmp = runCatching { load(site) }.getOrNull()
            if (bmp != null) {
                mem[site.key] = bmp
                onDone()
            }
        }.start()
    }

    /** Situs diubah/dihapus: lupakan ikonnya supaya diambil ulang. */
    fun forget(key: String) {
        mem.remove(key)
        tried.remove(key)
    }

    private fun load(site: LoginSite): Bitmap? {
        val base = Uri.parse(site.loginUrl)
        val host = base.host ?: return null
        val scheme = base.scheme ?: "https"
        decode(fetch("$scheme://$host/favicon.ico", 256 * 1024))?.let { return it }
        // cadangan: cari <link rel="icon"> di halaman login
        val html = fetch(site.loginUrl, 96 * 1024)?.toString(Charsets.UTF_8) ?: return null
        val href = Regex("<link[^>]+rel=[\"'][^\"']*icon[^\"']*[\"'][^>]*>", RegexOption.IGNORE_CASE).findAll(html)
            .mapNotNull { Regex("href=[\"']([^\"']+)[\"']", RegexOption.IGNORE_CASE).find(it.value)?.groupValues?.get(1) }
            .firstOrNull() ?: return null
        return decode(fetch(URL(URL(site.loginUrl), href).toString(), 256 * 1024))
    }

    private fun fetch(url: String, cap: Int): ByteArray? {
        val conn = URL(url).openConnection() as HttpURLConnection
        return try {
            conn.connectTimeout = 4000
            conn.readTimeout = 4000
            conn.instanceFollowRedirects = true
            conn.setRequestProperty("User-Agent", UA)
            if (conn.responseCode != 200) return null
            val out = ByteArrayOutputStream()
            val buf = ByteArray(8192)
            conn.inputStream.use { ins ->
                while (out.size() < cap) {
                    val n = ins.read(buf)
                    if (n < 0) break
                    out.write(buf, 0, n)
                }
            }
            out.toByteArray()
        } finally {
            conn.disconnect()
        }
    }

    private fun decode(bytes: ByteArray?): Bitmap? {
        if (bytes == null || bytes.isEmpty()) return null
        val bmp = BitmapFactory.decodeByteArray(bytes, 0, bytes.size) ?: return null
        if (bmp.width < 8 || bmp.height < 8) return null
        val m = maxOf(bmp.width, bmp.height)
        if (m <= 96) return bmp
        val k = 96f / m
        return Bitmap.createScaledBitmap(bmp, (bmp.width * k).toInt().coerceAtLeast(1), (bmp.height * k).toInt().coerceAtLeast(1), true)
    }
}
