package com.niven.mangatl

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.ImageDecoder
import android.graphics.Paint
import android.graphics.PixelFormat
import android.graphics.PorterDuff
import android.graphics.Rect
import android.graphics.drawable.BitmapDrawable
import android.graphics.drawable.Drawable
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.util.AttributeSet
import android.view.Gravity
import android.view.MotionEvent
import android.view.ScaleGestureDetector
import android.view.SurfaceHolder
import android.view.SurfaceView
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.FrameLayout
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.core.view.ViewCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.lifecycle.lifecycleScope
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

// Layar Chat: (1) layar penuh edge-to-edge (bar status & navigasi transparan, jam/baterai tetap tampil),
// (2) latar chat pilihan pengguna: video (loop, tanpa suara) / GIF (loop) / foto, dengan geser + zoom untuk memilih bagian yang tampil.
// Latar digambar di SurfaceView DI BAWAH avatar (avatar juga SurfaceView/GL), jadi tetap terlihat di belakang avatar & chat.
// Fungsi ekstensi dari ChatActivity; keadaan (bgS, bgFx, bgFy, ...) ada di ChatActivity.kt.

private const val K_KIND = "chat2_bg_kind"   // 1 = video, 2 = foto/GIF
private const val K_FILE = "chat2_bg_file"
private const val K_S = "chat2_bg_s"
private const val K_FX = "chat2_bg_fx"
private const val K_FY = "chat2_bg_fy"
private const val K_DARK = "chat2_bg_dark"
private const val K_BLUR = "chat2_bg_blur"

/** SurfaceView latar. Foto/GIF digambar sendiri (GIF diulang tanpa henti); video digambar oleh ExoPlayer. */
class ChatBgSurface @JvmOverloads constructor(c: Context, a: AttributeSet? = null) :
    SurfaceView(c, a), SurfaceHolder.Callback {

    private var d: Drawable? = null
    private var ready = false
    private var dark = 0                 // 0..90, dipasang langsung di gambar (tidak lewat alpha SurfaceView)
    private var blur = 0                 // 0..100, dikerjakan sendiri di gambar (tidak lewat setFixedSize)
    private var small: Bitmap? = null
    private var smallKey = ""
    private val fp = Paint(Paint.FILTER_BITMAP_FLAG)
    private val h = Handler(Looper.getMainLooper())
    private val tick = object : Runnable {
        override fun run() {
            drawNow()
            if (ready && isAnimated()) h.postDelayed(this, 33)
        }
    }

    init {
        holder.addCallback(this)
    }

    @SuppressLint("NewApi")
    private fun isAnimated() = Build.VERSION.SDK_INT >= 28 && d is android.graphics.drawable.AnimatedImageDrawable

    @SuppressLint("NewApi")
    fun setImage(x: Drawable?) {
        h.removeCallbacks(tick)
        val old = d
        if (Build.VERSION.SDK_INT >= 28 && old is android.graphics.drawable.AnimatedImageDrawable) old.stop()
        d = x
        smallKey = ""
        if (Build.VERSION.SDK_INT >= 28 && x is android.graphics.drawable.AnimatedImageDrawable) {
            x.repeatCount = android.graphics.drawable.AnimatedImageDrawable.REPEAT_INFINITE
            x.start()
        }
        if (ready && x != null) h.post(tick)
    }

    /** Gelap & buram untuk foto/GIF. Digambar ulang langsung (foto diam); GIF ikut di frame berikutnya. */
    fun setFx(dk: Int, bl: Int) {
        val d2 = dk.coerceIn(0, 90)
        val b2 = bl.coerceIn(0, 100)
        if (d2 == dark && b2 == blur) return
        dark = d2
        blur = b2
        if (ready && d != null && !isAnimated()) drawNow()
    }

    private fun drawNow() {
        val dd = d ?: return
        val canvas = try {
            if (Build.VERSION.SDK_INT >= 26) holder.lockHardwareCanvas() else holder.lockCanvas()
        } catch (_: Throwable) {
            null
        } ?: return
        try {
            val cw = canvas.width
            val ch = canvas.height
            canvas.drawColor(Color.BLACK)
            if (blur > 0) {
                drawBlurred(canvas, dd, cw, ch)
            } else {
                dd.setBounds(0, 0, cw, ch)
                dd.draw(canvas)
            }
            if (dark > 0) canvas.drawColor(Color.argb(dark * 255 / 100, 0, 0, 0))
        } finally {
            holder.unlockCanvasAndPost(canvas)
        }
    }

    /** Buram = gambar digambar ke bitmap kecil (makin buram makin kecil), dilembutkan, lalu diperbesar halus. Hasil foto diam disimpan. */
    private fun drawBlurred(canvas: Canvas, dd: Drawable, cw: Int, ch: Int) {
        val div = 1f + blur * 0.3f
        val sw = (cw / div).toInt().coerceAtLeast(8)
        val sh = (ch / div).toInt().coerceAtLeast(8)
        val key = "$blur/$sw/$sh"
        var bmp = small
        if (bmp == null || bmp.width != sw || bmp.height != sh) {
            bmp?.recycle()
            bmp = Bitmap.createBitmap(sw, sh, Bitmap.Config.ARGB_8888)
            small = bmp
            smallKey = ""
        }
        if (smallKey != key || isAnimated()) {
            val c = Canvas(bmp!!)
            c.drawColor(Color.BLACK)
            dd.setBounds(0, 0, sw, sh)
            try {
                dd.draw(c)
            } catch (_: Throwable) {
                // gambar berbasis hardware tidak bisa digambar ke bitmap; sisakan hitam
            }
            if (sw * sh <= 400_000) boxBlur(bmp, 2)
            smallKey = key
        }
        canvas.drawBitmap(bmp!!, null, Rect(0, 0, cw, ch), fp)
    }

    private fun boxBlur(bmp: Bitmap, passes: Int) {
        val w = bmp.width
        val hh = bmp.height
        val a = IntArray(w * hh)
        val b = IntArray(w * hh)
        bmp.getPixels(a, 0, w, 0, 0, w, hh)
        repeat(passes) {
            blur3(a, b, w, hh, true)
            blur3(b, a, w, hh, false)
        }
        bmp.setPixels(a, 0, w, 0, 0, w, hh)
    }

    private fun blur3(src: IntArray, dst: IntArray, w: Int, hh: Int, horiz: Boolean) {
        for (y in 0 until hh) {
            for (x in 0 until w) {
                var r = 0
                var g = 0
                var bl = 0
                for (k in -1..1) {
                    val xx = if (horiz) (x + k).coerceIn(0, w - 1) else x
                    val yy = if (horiz) y else (y + k).coerceIn(0, hh - 1)
                    val p = src[yy * w + xx]
                    r += (p shr 16) and 255
                    g += (p shr 8) and 255
                    bl += p and 255
                }
                dst[y * w + x] = (0xFF shl 24) or ((r / 3) shl 16) or ((g / 3) shl 8) or (bl / 3)
            }
        }
    }

    override fun surfaceCreated(holder: SurfaceHolder) {
        ready = true
        if (d != null) h.post(tick)
    }

    override fun surfaceChanged(holder: SurfaceHolder, format: Int, width: Int, height: Int) {
        if (d != null && !isAnimated()) drawNow()
    }

    override fun surfaceDestroyed(holder: SurfaceHolder) {
        ready = false
        h.removeCallbacks(tick)
    }
}

/**
 * Lapisan gelap untuk VIDEO latar (video digambar ExoPlayer, jadi tidak bisa digelapkan dari dalam).
 * SurfaceView tembus pandang tepat di atas latar dan di bawah avatar; alpha tiap piksel diatur sendiri,
 * tidak bergantung pada alpha SurfaceView yang diabaikan di sebagian HP.
 */
class ChatBgScrim @JvmOverloads constructor(c: Context, a: AttributeSet? = null) :
    SurfaceView(c, a), SurfaceHolder.Callback {

    private var dark = 0
    private var ready = false

    init {
        setZOrderMediaOverlay(true)
        holder.setFormat(PixelFormat.TRANSLUCENT)
        holder.addCallback(this)
    }

    fun setDark(v: Int) {
        val x = v.coerceIn(0, 90)
        if (x == dark) return
        dark = x
        paintNow()
    }

    private fun paintNow() {
        if (!ready) return
        val cv = try {
            holder.lockCanvas()
        } catch (_: Throwable) {
            null
        } ?: return
        try {
            cv.drawColor(Color.argb(dark * 255 / 100, 0, 0, 0), PorterDuff.Mode.SRC)
        } finally {
            holder.unlockCanvasAndPost(cv)
        }
    }

    override fun surfaceCreated(holder: SurfaceHolder) {
        ready = true
        paintNow()
    }

    override fun surfaceChanged(holder: SurfaceHolder, format: Int, width: Int, height: Int) {
        paintNow()
    }

    override fun surfaceDestroyed(holder: SurfaceHolder) {
        ready = false
    }
}

// ------------------------------------------------------------------ layar penuh

internal fun ChatActivity.setupEdgeToEdge() {
    WindowCompat.setDecorFitsSystemWindows(window, false)
    window.statusBarColor = Color.TRANSPARENT
    window.navigationBarColor = Color.TRANSPARENT
    if (Build.VERSION.SDK_INT >= 29) {
        window.isNavigationBarContrastEnforced = false
        window.isStatusBarContrastEnforced = false
    }
    if (Build.VERSION.SDK_INT >= 28) {
        val lp = window.attributes
        lp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        window.attributes = lp
    }
    val ic = WindowCompat.getInsetsController(window, window.decorView)
    ic.isAppearanceLightStatusBars = false      // ikon jam/baterai tetap putih
    ic.isAppearanceLightNavigationBars = false

    ViewCompat.setOnApplyWindowInsetsListener(rootFrame) { _, ins ->
        val bars = ins.getInsets(WindowInsetsCompat.Type.systemBars() or WindowInsetsCompat.Type.displayCutout())
        val ime = ins.getInsets(WindowInsetsCompat.Type.ime())
        val up = ins.isVisible(WindowInsetsCompat.Type.ime())
        insetTop = bars.top
        insetBottom = if (up) 0 else bars.bottom
        // Keyboard muncul = tampilan chat dipendekkan (dulu dikerjakan adjustResize), latar & avatar tetap layar penuh.
        val lp = web.layoutParams as FrameLayout.LayoutParams
        val bm = if (up) ime.bottom else 0
        if (lp.bottomMargin != bm) {
            lp.bottomMargin = bm
            web.layoutParams = lp
        }
        findViewById<View>(R.id.bgEdit).setPadding(0, bars.top, 0, maxOf(bars.bottom, ime.bottom))
        pushInsets()
        if (up != keyboardUp) {
            keyboardUp = up
            applyAvatar()
        }
        ins
    }
    rootFrame.requestApplyInsets()
}

/** Tinggi bar atas/bawah (dp CSS) dikirim ke halaman supaya header & kolom input tidak tertutup jam / tombol navigasi. */
internal fun ChatActivity.pushInsets() {
    val d = resources.displayMetrics.density
    js("insets(${Math.round(insetTop / d)},${Math.round(insetBottom / d)})")
}

// ------------------------------------------------------------------ latar

internal fun ChatActivity.hasBg(): Boolean =
    prefs().getString(K_FILE, null)?.let { File(filesDir, it).exists() } == true

/** true = latar foto/GIF (digambar sendiri), false = video (digambar ExoPlayer). */
internal fun ChatActivity.isImageBg(): Boolean = prefs().getInt(K_KIND, 0) != 1

/** Dialog dari menu "Latar chat". */
internal fun ChatActivity.showBgMenu() {
    val items = if (hasBg()) arrayOf("Pilih video / GIF / foto", "Atur posisi, gelap & buram", "Hapus latar")
    else arrayOf("Pilih video / GIF / foto")
    AlertDialog.Builder(this)
        .setTitle("Latar chat")
        .setItems(items) { _, i ->
            when (i) {
                0 -> pickBg.launch(arrayOf("video/*", "image/*"))
                1 -> startBgEdit()
                2 -> clearBg()
            }
        }
        .show()
}

/** File pilihan disalin ke penyimpanan app, jadi tetap jalan walau file aslinya dihapus / dipindah. */
internal fun ChatActivity.importBg(uri: Uri) {
    val mime = contentResolver.getType(uri) ?: ""
    val kind = when {
        mime.startsWith("video/") -> 1
        mime.startsWith("image/") -> 2
        else -> 0
    }
    if (kind == 0) {
        Toast.makeText(this, "Pilih video, GIF, atau foto.", Toast.LENGTH_SHORT).show()
        return
    }
    val ext = when (mime) {
        "image/gif" -> "gif"
        "image/png" -> "png"
        "image/webp" -> "webp"
        "image/jpeg" -> "jpg"
        else -> if (kind == 1) "mp4" else "img"
    }
    lifecycleScope.launch {
        val name = "chat2_bg_${System.currentTimeMillis()}.$ext"
        val ok = withContext(Dispatchers.IO) {
            try {
                contentResolver.openInputStream(uri)?.use { i ->
                    File(filesDir, name).outputStream().use { o -> i.copyTo(o) }
                } != null
            } catch (_: Throwable) {
                false
            }
        }
        if (!ok) {
            Toast.makeText(this@importBg, "File tidak bisa dibuka.", Toast.LENGTH_SHORT).show()
            return@launch
        }
        deleteBgFile()
        prefs().edit().putInt(K_KIND, kind).putString(K_FILE, name)
            .putFloat(K_S, 1f).putFloat(K_FX, 0f).putFloat(K_FY, 0f)
            .putInt(K_DARK, 18).putInt(K_BLUR, 0).apply()
        applyBg(edit = true)   // langsung masuk mode atur posisi
    }
}

private fun ChatActivity.deleteBgFile() {
    prefs().getString(K_FILE, null)?.let { File(filesDir, it).delete() }
}

internal fun ChatActivity.clearBg() {
    if (bgEditing) endBgEdit(false)
    deleteBgFile()
    prefs().edit().remove(K_KIND).remove(K_FILE).remove(K_S).remove(K_FX).remove(K_FY).remove(K_DARK).remove(K_BLUR).apply()
    releaseBg()
    bgMw = 0
    bgMh = 0
    Toast.makeText(this, "Latar dihapus", Toast.LENGTH_SHORT).show()
}

/** Pasang latar dari pengaturan tersimpan. edit = true: setelah tampil, langsung buka mode atur posisi. */
internal fun ChatActivity.applyBg(edit: Boolean = false) {
    releaseBg()
    val p = prefs()
    val surf = findViewById<ChatBgSurface>(R.id.bgSurface)
    val f = p.getString(K_FILE, null)?.let { File(filesDir, it) }?.takeIf { it.exists() }
    if (f == null) {
        surf.visibility = View.GONE
        return
    }
    val kind = p.getInt(K_KIND, 0)
    bgS = p.getFloat(K_S, 1f)
    bgFx = p.getFloat(K_FX, 0f)
    bgFy = p.getFloat(K_FY, 0f)
    bgDark = p.getInt(K_DARK, 18).coerceIn(0, 90)
    bgBlur = p.getInt(K_BLUR, 0).coerceIn(0, 100)
    val gen = ++bgGen
    lifecycleScope.launch {
        if (kind == 2) {
            val d = withContext(Dispatchers.IO) { loadBgImage(f) }
            if (gen != bgGen) return@launch
            if (d == null || d.intrinsicWidth <= 0 || d.intrinsicHeight <= 0) {
                Toast.makeText(this@applyBg, "Gambar latar tidak bisa dibuka.", Toast.LENGTH_SHORT).show()
                return@launch
            }
            bgMw = d.intrinsicWidth
            bgMh = d.intrinsicHeight
            surf.visibility = View.VISIBLE
            layoutBg()
            surf.setImage(d)
        } else {
            val sz = withContext(Dispatchers.IO) { videoSize(f) }
            if (gen != bgGen) return@launch
            if (sz == null) {
                Toast.makeText(this@applyBg, "Video latar tidak bisa dibuka.", Toast.LENGTH_SHORT).show()
                return@launch
            }
            bgMw = sz.first
            bgMh = sz.second
            surf.visibility = View.VISIBLE
            layoutBg()
            val pl = ExoPlayer.Builder(this@applyBg).build()
            pl.trackSelectionParameters = pl.trackSelectionParameters.buildUpon()
                .setTrackTypeDisabled(C.TRACK_TYPE_AUDIO, true)
                .build()
            pl.volume = 0f
            pl.repeatMode = Player.REPEAT_MODE_ONE   // video diulang terus
            pl.setVideoSurfaceView(surf)
            pl.setMediaItem(MediaItem.fromUri(Uri.fromFile(f)))
            pl.prepare()
            pl.playWhenReady = true
            bgPlayer = pl
        }
        if (edit) startBgEdit()
    }
}

internal fun ChatActivity.releaseBg() {
    bgGen++
    bgPlayer?.let {
        it.clearVideoSurface()
        it.release()
    }
    bgPlayer = null
    val surf = findViewById<ChatBgSurface>(R.id.bgSurface)
    surf.setImage(null)
    surf.visibility = View.GONE
    findViewById<View>(R.id.bgScrim).visibility = View.GONE
}

/** Foto/GIF dikecilkan maksimal 1920 px supaya hemat memori. GIF jalan sebagai animasi (Android 9 ke atas). */
@SuppressLint("NewApi")
private fun ChatActivity.loadBgImage(f: File): Drawable? = try {
    if (Build.VERSION.SDK_INT >= 28) {
        ImageDecoder.decodeDrawable(ImageDecoder.createSource(f)) { dec, info, _ ->
            dec.setAllocator(ImageDecoder.ALLOCATOR_SOFTWARE)   // supaya bisa digambar ulang ke bitmap kecil untuk buram
            val w = info.size.width
            val h = info.size.height
            val big = maxOf(w, h)
            if (big > 1920) {
                val r = 1920f / big
                dec.setTargetSize((w * r).toInt().coerceAtLeast(1), (h * r).toInt().coerceAtLeast(1))
            }
        }
    } else {
        val o = BitmapFactory.Options().apply { inSampleSize = 2 }
        BitmapDrawable(resources, BitmapFactory.decodeFile(f.path, o))
    }
} catch (_: Throwable) {
    null
}

private fun videoSize(f: File): Pair<Int, Int>? = try {
    val r = MediaMetadataRetriever()
    try {
        r.setDataSource(f.path)
        var w = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH)?.toIntOrNull() ?: 0
        var h = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT)?.toIntOrNull() ?: 0
        val rot = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_ROTATION)?.toIntOrNull() ?: 0
        if (rot == 90 || rot == 270) {
            val t = w
            w = h
            h = t
        }
        if (w > 0 && h > 0) Pair(w, h) else null
    } finally {
        r.release()
    }
} catch (_: Throwable) {
    null
}

// ------------------------------------------------------------------ posisi & zoom

private fun ChatActivity.screenW() = rootFrame.width.toFloat()
private fun ChatActivity.screenH() = maxOf(rootFrame.height, lastFullRootH).toFloat()

/**
 * Media diskalakan menutup layar penuh (seperti "cover"), lalu skala (zoom) dan geser pengguna dipasang di atasnya.
 * Ukuran dasar tetap; zoom + geser hanya transformasi (ringan, tidak memuat ulang).
 */
internal fun ChatActivity.layoutBg() {
    val surf = findViewById<ChatBgSurface>(R.id.bgSurface)
    val w = screenW()
    val h = screenH()
    if (w <= 0f || h <= 0f || bgMw <= 0 || bgMh <= 0) return
    val cs = maxOf(w / bgMw, h / bgMh)
    val cw = (bgMw * cs).toInt() + 1
    val ch = (bgMh * cs).toInt() + 1
    val lp = surf.layoutParams as FrameLayout.LayoutParams
    if (lp.width != cw || lp.height != ch || lp.gravity != Gravity.CENTER) {
        lp.width = cw
        lp.height = ch
        lp.gravity = Gravity.CENTER
        surf.layoutParams = lp
    }
    // Penyangga gambar dibatasi supaya video lebar tidak memakan memori besar; sisanya diperbesar oleh sistem.
    // Buram = penyangga gambar dikecilkan lalu diperbesar halus oleh sistem (makin kecil makin buram).
    // Foto/GIF: buram dikerjakan di gambar sendiri (ChatBgSurface.setFx). Hanya video yang memakai trik ukuran penyangga.
    val blurDiv = if (isImageBg()) 1f else 1f + bgBlur * 0.3f
    val cap = minOf(1f, 2560f / maxOf(cw, ch)) / blurDiv
    val fw = (cw * cap).toInt().coerceAtLeast(16)
    val fh = (ch * cap).toInt().coerceAtLeast(16)
    if (fw != bgFixW || fh != bgFixH) {
        bgFixW = fw
        bgFixH = fh
        surf.holder.setFixedSize(fw, fh)
    }
    applyBgTransform()
}

internal fun ChatActivity.applyBgTransform() {
    val surf = findViewById<ChatBgSurface>(R.id.bgSurface)
    val w = screenW()
    val h = screenH()
    val cw = surf.layoutParams.width.toFloat()
    val ch = surf.layoutParams.height.toFloat()
    if (w <= 0f || h <= 0f || cw <= 0f || ch <= 0f) return
    bgS = bgS.coerceIn(1f, 4f)
    // Geser dibatasi supaya tepi media tidak pernah masuk ke layar (tidak ada celah hitam).
    val mx = maxOf(0f, (cw * bgS - w) / 2f)
    val my = maxOf(0f, (ch * bgS - h) / 2f)
    val tx = (bgFx * w).coerceIn(-mx, mx)
    val ty = (bgFy * h).coerceIn(-my, my)
    bgFx = tx / w
    bgFy = ty / h
    surf.alpha = 1f
    val img = isImageBg()
    surf.setFx(if (img) bgDark else 0, if (img) bgBlur else 0)
    val sc = findViewById<ChatBgScrim>(R.id.bgScrim)
    val wantScrim = !img && bgDark > 0
    sc.setDark(if (wantScrim) bgDark else 0)
    val vis = if (wantScrim) View.VISIBLE else View.GONE
    if (sc.visibility != vis) sc.visibility = vis
    surf.scaleX = bgS
    surf.scaleY = bgS
    surf.translationX = tx
    surf.translationY = ty
}

internal fun ChatActivity.startBgEdit() {
    if (!hasBg() || bgMw <= 0) return
    bgEditing = true
    rootFrame.target = null          // avatar tidak ikut tergeser / ter-zoom
    web.alpha = 0f                   // bubble & tombol chat disembunyikan sementara
    js("back()")
    val sbD = findViewById<SeekBar>(R.id.sbBgDark)
    val sbB = findViewById<SeekBar>(R.id.sbBgBlur)
    sbD.progress = bgDark
    sbB.progress = bgBlur
    findViewById<TextView>(R.id.tvBgDark).text = "Gelap: $bgDark%"
    findViewById<TextView>(R.id.tvBgBlur).text = "Buram: $bgBlur"
    findViewById<View>(R.id.bgEdit).visibility = View.VISIBLE
    backCallback.isEnabled = true
}

internal fun ChatActivity.endBgEdit(save: Boolean) {
    bgEditing = false
    findViewById<View>(R.id.bgEdit).visibility = View.GONE
    web.alpha = 1f
    rootFrame.target = avatar
    val p = prefs()
    if (save) {
        p.edit().putFloat(K_S, bgS).putFloat(K_FX, bgFx).putFloat(K_FY, bgFy)
            .putInt(K_DARK, bgDark).putInt(K_BLUR, bgBlur).apply()
    } else {
        bgS = p.getFloat(K_S, 1f)
        bgFx = p.getFloat(K_FX, 0f)
        bgFy = p.getFloat(K_FY, 0f)
        bgDark = p.getInt(K_DARK, 18)
        bgBlur = p.getInt(K_BLUR, 0)
        layoutBg()
    }
}

@SuppressLint("ClickableViewAccessibility")
internal fun ChatActivity.setupBgEdit() {
    val edit = findViewById<View>(R.id.bgEdit)
    findViewById<Button>(R.id.btnBgDone).setOnClickListener { endBgEdit(true) }
    findViewById<Button>(R.id.btnBgReset).setOnClickListener {
        bgS = 1f
        bgFx = 0f
        bgFy = 0f
        bgDark = 18
        bgBlur = 0
        findViewById<SeekBar>(R.id.sbBgDark).progress = bgDark
        findViewById<SeekBar>(R.id.sbBgBlur).progress = bgBlur
        layoutBg()
    }
    findViewById<SeekBar>(R.id.sbBgDark).setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
        override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
            bgDark = p
            findViewById<TextView>(R.id.tvBgDark).text = "Gelap: $p%"
            applyBgTransform()
        }

        override fun onStartTrackingTouch(s: SeekBar?) {}
        override fun onStopTrackingTouch(s: SeekBar?) {}
    })
    // Buram dipasang saat jari dilepas (mengubah ukuran penyangga gambar = agak berat kalau tiap geseran).
    findViewById<SeekBar>(R.id.sbBgBlur).setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
        override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
            findViewById<TextView>(R.id.tvBgBlur).text = "Buram: $p"
        }

        override fun onStartTrackingTouch(s: SeekBar?) {}
        override fun onStopTrackingTouch(s: SeekBar?) {
            bgBlur = s?.progress ?: 0
            layoutBg()
        }
    })
    val sgd = ScaleGestureDetector(this, object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
        override fun onScale(detector: ScaleGestureDetector): Boolean {
            bgS = (bgS * detector.scaleFactor).coerceIn(1f, 4f)
            applyBgTransform()
            return true
        }
    })
    var lx = 0f
    var ly = 0f
    var n = 0
    edit.setOnTouchListener { _, e ->
        sgd.onTouchEvent(e)
        val skip = if (e.actionMasked == MotionEvent.ACTION_POINTER_UP) e.actionIndex else -1
        var cx = 0f
        var cy = 0f
        var c = 0
        for (i in 0 until e.pointerCount) {
            if (i == skip) continue
            cx += e.getX(i)
            cy += e.getY(i)
            c++
        }
        if (c > 0) {
            cx /= c
            cy /= c
        }
        if (c != n || e.actionMasked == MotionEvent.ACTION_DOWN) {
            n = c
            lx = cx
            ly = cy
        } else if (e.actionMasked == MotionEvent.ACTION_MOVE) {
            val w = screenW()
            val h = screenH()
            if (w > 0f && h > 0f) {
                bgFx += (cx - lx) / w
                bgFy += (cy - ly) / h
                applyBgTransform()
            }
            lx = cx
            ly = cy
        }
        if (e.actionMasked == MotionEvent.ACTION_UP || e.actionMasked == MotionEvent.ACTION_CANCEL) n = 0
        true
    }
}
