package com.niven.mangatl

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.Text
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import java.util.Locale

/**
 * Alat uji kotak teks: pilih foto layar game, jalankan OCR yang sama dengan terjemah layar,
 * lalu lihat kotak hasil pengelompokan. Slider di bawah sama dengan yang ada di Opsi
 * (tersimpan langsung), jadi hasil uji berlaku untuk terjemah layar.
 * Biru = akan diterjemahkan, merah = ada di daftar abaikan. Angka kecil = jumlah baris.
 */
class BoxTestActivity : AppCompatActivity() {

    private val prefs by lazy { getSharedPreferences(Grouping.PREF_FILE, Context.MODE_PRIVATE) }
    private val recognizer by lazy { TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS) }

    private lateinit var boxView: BoxView
    private lateinit var info: TextView

    private var ocrText: Text? = null

    private val pick = registerForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) load(uri)
    }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setBackgroundColor(Color.parseColor("#0B0B0B"))
        root.setPadding(dp(12), dp(28), dp(12), dp(12))

        val btn = Button(this)
        btn.text = "Pilih foto layar game"
        btn.setOnClickListener { pick.launch("image/*") }
        root.addView(btn, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT))

        boxView = BoxView(this)
        root.addView(boxView, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f))

        info = TextView(this)
        info.setTextColor(Color.parseColor("#BBBBBB"))
        info.textSize = 12f
        info.text = "Belum ada foto."
        root.addView(info, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT))

        // Slider spasi blok teks (0..20 -> 0.3x..2.3x)
        val tvSpacing = TextView(this)
        tvSpacing.setTextColor(Color.WHITE)
        tvSpacing.textSize = 13f
        val sbSpacing = SeekBar(this)
        sbSpacing.max = 20
        val sp0 = prefs.getInt(Grouping.KEY_SPACING, Grouping.SPACING_DEFAULT).coerceIn(0, 20)
        sbSpacing.progress = sp0
        tvSpacing.text = spacingLabel(sp0)
        sbSpacing.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                tvSpacing.text = spacingLabel(p)
                prefs.edit().putInt(Grouping.KEY_SPACING, p).apply()
                if (fromUser) regroup()
            }

            override fun onStartTrackingTouch(s: SeekBar?) {}

            override fun onStopTrackingTouch(s: SeekBar?) {}
        })

        // Slider perbedaan ukuran teks (0..70 -> 10%..80%)
        val tvDiff = TextView(this)
        tvDiff.setTextColor(Color.WHITE)
        tvDiff.textSize = 13f
        val sbDiff = SeekBar(this)
        sbDiff.max = 70
        val sd0 = prefs.getInt(Grouping.KEY_SIZEDIFF, Grouping.SIZEDIFF_DEFAULT).coerceIn(10, 80)
        sbDiff.progress = sd0 - 10
        tvDiff.text = diffLabel(sd0)
        sbDiff.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                val v = p + 10
                tvDiff.text = diffLabel(v)
                prefs.edit().putInt(Grouping.KEY_SIZEDIFF, v).apply()
                if (fromUser) regroup()
            }

            override fun onStartTrackingTouch(s: SeekBar?) {}

            override fun onStopTrackingTouch(s: SeekBar?) {}
        })

        val lpW = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
        lpW.topMargin = dp(8)
        root.addView(tvSpacing, lpW)
        root.addView(sbSpacing, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT))
        root.addView(tvDiff, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT))
        root.addView(sbDiff, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT))

        setContentView(root)
    }

    private fun spacingLabel(p: Int): String =
        String.format(Locale.US, "Spasi blok teks: pisah kalau jarak baris > %.1fx tinggi huruf", Grouping.spacingFactor(p))

    private fun diffLabel(v: Int): String = "Perbedaan ukuran teks: pisah kalau beda > $v%"

    private fun load(uri: Uri) {
        val bmp = decode(uri)
        if (bmp == null) {
            Toast.makeText(this, "Foto tidak bisa dibuka.", Toast.LENGTH_SHORT).show()
            return
        }
        boxView.bmp = bmp
        boxView.groups = emptyList()
        boxView.invalidate()
        ocrText = null
        info.text = "Membaca teks..."
        recognizer.process(InputImage.fromBitmap(bmp, 0))
            .addOnSuccessListener { t ->
                ocrText = t
                regroup()
            }
            .addOnFailureListener { e ->
                info.text = "OCR gagal: ${e.message}"
            }
    }

    private fun regroup() {
        val t = ocrText ?: return
        val gs = Grouping.group(t, Grouping.params(this))
        boxView.groups = gs
        boxView.invalidate()
        val ign = gs.count { it.ignored }
        info.text = "Kotak: ${gs.size - ign} diterjemahkan, $ign diabaikan (merah)."
    }

    /** Buka foto dan kecilkan kalau terlalu besar (maks sekitar 3000 px sisi terpanjang). */
    private fun decode(uri: Uri): Bitmap? {
        return try {
            val bounds = BitmapFactory.Options()
            bounds.inJustDecodeBounds = true
            contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
            var sample = 1
            val longest = Math.max(bounds.outWidth, bounds.outHeight)
            while (longest / sample > 3000) sample *= 2
            val opts = BitmapFactory.Options()
            opts.inSampleSize = sample
            contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, opts) }
        } catch (_: Throwable) {
            null
        }
    }

    /** Menggambar foto (muat layar) dan kotak hasil pengelompokan di atasnya. */
    private class BoxView(ctx: Context) : View(ctx) {
        var bmp: Bitmap? = null
        var groups: List<Grouping.Group> = emptyList()

        private val boxPaint = Paint(Paint.ANTI_ALIAS_FLAG)
        private val txtPaint = Paint(Paint.ANTI_ALIAS_FLAG)
        private val dst = RectF()

        init {
            boxPaint.style = Paint.Style.STROKE
            boxPaint.strokeWidth = 2f * resources.displayMetrics.density
            txtPaint.color = Color.YELLOW
            txtPaint.textSize = 11f * resources.displayMetrics.density
        }

        override fun onDraw(canvas: Canvas) {
            val b = bmp ?: return
            val s = Math.min(width.toFloat() / b.width, height.toFloat() / b.height)
            val w = b.width * s
            val h = b.height * s
            val dx = (width - w) / 2f
            val dy = (height - h) / 2f
            dst.set(dx, dy, dx + w, dy + h)
            canvas.drawBitmap(b, null, dst, null)
            for (g in groups) {
                boxPaint.color = if (g.ignored) Color.parseColor("#FF5555") else Color.parseColor("#33CCFF")
                val r = RectF(dx + g.rect.left * s, dy + g.rect.top * s, dx + g.rect.right * s, dy + g.rect.bottom * s)
                canvas.drawRect(r, boxPaint)
                canvas.drawText(g.lines.toString(), r.left + 2f, r.top - 2f, txtPaint)
            }
        }
    }
}
