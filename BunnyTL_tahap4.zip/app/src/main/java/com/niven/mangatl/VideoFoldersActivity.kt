package com.niven.mangatl

import android.content.Intent
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.View
import android.widget.EditText
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/** Layar Video: daftar folder dengan mosaik 4 thumbnail, urutkan, dan pengaturan video. */
class VideoFoldersActivity : MediaActivity() {

    override val kind = 2
    override fun deniedView(): TextView = tvEmpty

    private lateinit var adapter: RowAdapter
    private lateinit var etSearch: EditText
    private lateinit var tvEmpty: TextView
    private var folders: List<Library.VFolder> = emptyList()
    private var loaded = false
    private var sortMode = 0

    private val openFile = registerForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri != null) {
            startActivity(
                Intent(this, VideoActivity::class.java)
                    .setData(uri)
                    .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            )
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_list)
        Fx.enter(this)
        findViewById<TextView>(R.id.tvTitle).text = "Video"
        sortMode = Prefs.int(this, "sort_vfolders", 0)

        findViewById<View>(R.id.ibOpen).setOnClickListener { openFile.launch(arrayOf("video/*", "audio/*")) }
        findViewById<View>(R.id.ibSort).setOnClickListener {
            Ui.sortDialog(this, Ui.SORT_VIDEO, sortMode) {
                sortMode = it
                Prefs.setInt(this, "sort_vfolders", it)
                refresh()
            }
        }
        findViewById<View>(R.id.ibSettings).setOnClickListener {
            VideoSettings.show(this) { refresh() }
        }

        etSearch = findViewById(R.id.etSearch)
        etSearch.hint = "Cari folder"
        tvEmpty = findViewById(R.id.tvEmpty)
        adapter = RowAdapter(lifecycleScope)
        findViewById<RecyclerView>(R.id.list).apply {
            layoutManager = LinearLayoutManager(this@VideoFoldersActivity)
            adapter = this@VideoFoldersActivity.adapter
        }
        etSearch.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun afterTextChanged(s: Editable?) = refresh()
        })
        ensureMedia()
    }

    override fun onMediaReady() {
        tvEmpty.text = "Memuat..."
        tvEmpty.visibility = View.VISIBLE
        lifecycleScope.launch {
            folders = withContext(Dispatchers.IO) { Library.videoFolders(this@VideoFoldersActivity) }
            loaded = true
            refresh()
        }
    }

    private fun refresh() {
        if (!loaded) return
        val q = etSearch.text.toString().trim().lowercase()
        val shown = Ui.sortBy(
            folders.filter { q.isEmpty() || it.name.lowercase().contains(q) },
            sortMode, { it.name }, { it.date }, { it.size }
        )
        val mosaic = Prefs.mosaic(this)
        val rows = shown.map { f ->
            Row(
                title = f.name,
                sub = "${f.videos.size} video  •  ${Library.sizeStr(f.size)}",
                icon = R.drawable.ic_folder,
                thumb = f.videos.firstOrNull()?.uri,
                thumbs = if (mosaic) f.videos.take(4).map { it.uri } else emptyList(),
                video = true,
                onClick = {
                    startActivity(
                        Intent(this, VideoListActivity::class.java)
                            .putExtra("bucket", f.bucketId)
                            .putExtra("name", f.name)
                    )
                }
            )
        }
        adapter.rows = rows
        tvEmpty.text = "Tidak ada video ditemukan."
        tvEmpty.visibility = if (rows.isEmpty()) View.VISIBLE else View.GONE
    }
}
