package com.niven.mangatl

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.ServiceInfo
import android.hardware.display.VirtualDisplay
import android.media.Image
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.HandlerThread
import android.os.IBinder
import android.os.Looper
import android.os.SystemClock
import android.util.DisplayMetrics
import android.view.View
import android.view.WindowManager
import android.widget.TextView
import android.widget.Toast
import androidx.core.app.NotificationCompat
import androidx.core.content.IntentCompat
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions

/**
 * Mode game: tombol "TL" melayang. Ketuk = ambil layar, baca teks (OCR), terjemahkan dengan Gemma,
 * lalu tampilkan hasilnya di atas game. Tekan lama tombol (sekitar 1 detik) = berhenti.
 */
class ScreenService : Service() {

    companion object {
        const val ACTION_STOP = "com.niven.mangatl.STOP"
        const val ACTION_EDIT_AREA = "com.niven.mangatl.EDIT_AREA"
        private const val CHANNEL = "bunnytl_screen"
        private const val NOTIF_ID = 77

        @Volatile
        var running = false
    }

    internal val main = Handler(Looper.getMainLooper())
    internal var thread: HandlerThread? = null
    internal var cap: Handler? = null
    internal var wm: WindowManager? = null
    internal var fab: TextView? = null
    internal var panel: TextView? = null
    internal var panelLp: WindowManager.LayoutParams? = null
    internal var ov: OverlayView? = null

    internal var projection: MediaProjection? = null
    private var projCb: MediaProjection.Callback? = null
    internal var vd: VirtualDisplay? = null
    internal var reader: ImageReader? = null
    internal var capW = 0
    internal var capH = 0
    internal var dpi = 320

    @Volatile
    internal var busy = false

    internal val recognizer by lazy { TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS) }

    internal var lastKey = ""
    internal var lastMode = -1
    internal var lastOut = ""
    internal var lastItems: List<OverlayView.Item> = emptyList()

    // Jumlah baris teks asli tiap kotak pada pembacaan terakhir (untuk memperkirakan ukuran huruf).
    @Volatile
    internal var curLines: List<Int> = emptyList()

    // ----- mode auto & area
    @Volatile
    internal var curAuto = false

    @Volatile
    internal var autoOn = false

    @Volatile
    internal var autoPaused = false
    internal var lastSig: IntArray? = null
    internal var candSig: IntArray? = null
    internal var changingTicks = 0
    internal var editor: AreaEditorView? = null
    internal var watcher: View? = null
    internal val autoRun = Runnable { autoTick(false) }
    internal val autoTouchRun = Runnable { autoTick(true) }

    @Volatile
    internal var lastTouchAt = 0L

    @Volatile
    internal var touchHideAt = 0L

    @Volatile
    internal var sameStreak = 0
    private val prefListener = SharedPreferences.OnSharedPreferenceChangeListener { _, key ->
        if (key == "smode") main.post { applyMode() }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopSelf()
            return START_NOT_STICKY
        }
        if (intent?.action == ACTION_EDIT_AREA) {
            if (running) {
                val which = intent?.getIntExtra("which", 0) ?: 0
                main.post { showAreaEditor(which) }
            } else {
                stopSelf()
            }
            return START_NOT_STICKY
        }
        val code = intent?.getIntExtra("code", 0) ?: 0
        val data = intent?.let { IntentCompat.getParcelableExtra(it, "data", Intent::class.java) }
        if (data == null) {
            stopSelf()
            return START_NOT_STICKY
        }

        cleanup()
        startFg()

        try {
            val mpm = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
            val p = mpm.getMediaProjection(code, data)
            val cb = object : MediaProjection.Callback() {
                override fun onStop() {
                    main.post { stopSelf() }
                }
            }
            p.registerCallback(cb, main)
            projection = p
            projCb = cb

            val t = HandlerThread("bunnytl-cap")
            t.start()
            thread = t
            cap = Handler(t.looper)

            wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
            addOverlays()

            running = true
            prefs().registerOnSharedPreferenceChangeListener(prefListener)
            addWatcher()
            applyMode()

            // Muat model dari awal supaya ketukan pertama tidak lama.
            Thread {
                try {
                    Gemma.findModel(this)?.let { Gemma.warmUp(applicationContext, it) }
                } catch (_: Throwable) {
                }
            }.start()
        } catch (t: Throwable) {
            Toast.makeText(this, "Mode game gagal: ${t.message}", Toast.LENGTH_LONG).show()
            stopSelf()
        }
        return START_NOT_STICKY
    }

    private fun startFg() {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL, "Mode game", NotificationManager.IMPORTANCE_LOW)
        )
        val stop = PendingIntent.getService(
            this, 0,
            Intent(this, ScreenService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val n = NotificationCompat.Builder(this, CHANNEL)
            .setContentTitle("BunnyTL mode game aktif")
            .setContentText("Ketuk tombol TL di layar untuk menerjemahkan")
            .setSmallIcon(android.R.drawable.ic_menu_view)
            .setOngoing(true)
            .addAction(android.R.drawable.ic_menu_close_clear_cancel, "Berhenti", stop)
            .build()
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
        } else {
            startForeground(NOTIF_ID, n)
        }
    }

    internal fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    @Suppress("DEPRECATION")
    internal fun realSize(): IntArray {
        val dm = DisplayMetrics()
        wm!!.defaultDisplay.getRealMetrics(dm)
        return intArrayOf(dm.widthPixels, dm.heightPixels, dm.densityDpi)
    }

    internal fun prefs() = getSharedPreferences("mangatl", Context.MODE_PRIVATE)

    // ---------------------------------------------------------------- overlay

    internal fun overlayShown(): Boolean =
        (ov?.items?.isNotEmpty() == true) || panel?.visibility == View.VISIBLE

    // ---------------------------------------------------------------- ambil layar

    internal val heldLock = Any()
    internal var held: Image? = null

    @Volatile
    internal var heldAt = 0L

    // Simpan frame terbaru tanpa menutupnya. Layar yang diam tidak menghasilkan frame baru,
    // jadi saat tombol diketuk kita pakai frame terakhir ini, bukan menunggu frame yang tak akan datang
    // (itu penyebab "Gagal ambil layar" setelah ketukan pertama).
    internal val listener = ImageReader.OnImageAvailableListener { r ->
        val img: Image? = try {
            r.acquireLatestImage()
        } catch (_: Throwable) {
            null
        }
        if (img != null) {
            synchronized(heldLock) {
                try {
                    held?.close()
                } catch (_: Throwable) {
                }
                held = img
                heldAt = SystemClock.uptimeMillis()
            }
        }
    }

    // ------------------------------------------------------- OCR + terjemahan

    // ---------------------------------------------------------------- area & mode auto

    internal fun fabIdleText(): String =
        if (autoOn) (if (autoPaused) "II" else "A") else (if (overlayShown()) "X" else "TL")

    internal fun recentTouch(): Boolean = SystemClock.uptimeMillis() - lastTouchAt < 8000

    // ---------------------------------------------------------------- menu bubble (tahan lama)

    internal var menu: View? = null

    // ---------------------------------------------------------------- bersih-bersih

    private fun cleanup() {
        autoOn = false
        cap?.removeCallbacks(autoRun)
        removeEditor()
        removeBubbleMenu()
        try {
            watcher?.let { wm?.removeView(it) }
        } catch (_: Throwable) {
        }
        watcher = null
        try {
            fab?.let { wm?.removeView(it) }
        } catch (_: Throwable) {
        }
        try {
            panel?.let { wm?.removeView(it) }
        } catch (_: Throwable) {
        }
        try {
            ov?.let { wm?.removeView(it) }
        } catch (_: Throwable) {
        }
        ov = null
        fab = null
        panel = null
        try {
            vd?.release()
        } catch (_: Throwable) {
        }
        vd = null
        dropHeld()
        try {
            reader?.close()
        } catch (_: Throwable) {
        }
        reader = null
        capW = 0
        capH = 0
        try {
            projCb?.let { projection?.unregisterCallback(it) }
            projection?.stop()
        } catch (_: Throwable) {
        }
        projection = null
        projCb = null
        try {
            thread?.quitSafely()
        } catch (_: Throwable) {
        }
        thread = null
        cap = null
        busy = false
    }

    override fun onDestroy() {
        running = false
        try {
            prefs().unregisterOnSharedPreferenceChangeListener(prefListener)
        } catch (_: Throwable) {
        }
        try {
            recognizer.close()
        } catch (_: Throwable) {
        }
        cleanup()
        super.onDestroy()
    }
}
