package com.niven.mangatl

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.ImageDecoder
import android.net.Uri
import android.os.Build
import android.provider.OpenableColumns
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.lifecycle.lifecycleScope
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognizer
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import java.io.ByteArrayOutputStream
import java.nio.charset.Charset
import kotlin.coroutines.resume

// Layar Chat: lampiran.
//  Tahap 2 = gambar: baca teksnya dengan ML Kit OCR (lokal), lalu menu aksi.
//  Tahap 3 = file teks: baca, terjemahkan per bagian, ringkas/jelaskan lewat chat, simpan sebagai .txt.
//  Tahap 4 = ubah isi: cari-ganti / hapus baris / minta AI mengubah per bagian, selalu lewat pratinjau + konfirmasi,
//            hasil default disimpan sebagai SALINAN BARU (menimpa file asli hanya kalau dipilih sendiri).
// Teks hasil baca / isi file TIDAK lewat jalur gambar model; yang masuk ke Gemma hanya teks.

/** Batas teks yang dikirim ke Gemma sekali jalan lewat chat (konteks model kecil terbatas). Lebih dari ini dipotong. */
internal const val ATTACH_CHAT_MAX = 3000

private const val FILE_MAX_BYTES = 2 * 1024 * 1024
private val OCR_NAMES = arrayOf("Jepang", "Korea", "Mandarin", "Latin")

/** Satu teks yang sedang dikerjakan. uri = file asal (null kalau dari gambar / hasil terjemahan: tidak bisa ditimpa). */
private class Doc(val name: String, val uri: Uri?, var orig: String, var text: String)

private var docBusy = false
private var pendingSave: String? = null

// ------------------------------------------------------------------ gambar (tahap 2)

/** Menu "Baca gambar" -> pemilih gambar. */
internal fun ChatActivity.pickImageToRead() {
    if (sending) {
        Toast.makeText(this, "Tunggu jawaban selesai dulu.", Toast.LENGTH_SHORT).show()
        return
    }
    pickImage.launch(arrayOf("image/*"))
}

internal fun ChatActivity.onImagePicked(uri: Uri) {
    Toast.makeText(this, "Membaca gambar...", Toast.LENGTH_SHORT).show()
    lifecycleScope.launch {
        val res = withContext(Dispatchers.Default) { ocrImage(uri) }
        if (isDestroyed) return@launch
        if (res == null) {
            Toast.makeText(this@onImagePicked, "Gambar tidak bisa dibuka.", Toast.LENGTH_LONG).show()
            return@launch
        }
        if (res.first.isBlank()) {
            Toast.makeText(this@onImagePicked, "Tidak ada teks yang terbaca di gambar.", Toast.LENGTH_LONG).show()
            return@launch
        }
        val t = res.first
        showDocMenu(Doc("teks_gambar.txt", null, t, t), "Terbaca sebagai: ${res.second}")
    }
}

/**
 * Baca teks gambar. Latin dulu (cepat); kalau hasilnya sedikit baru coba Jepang / Korea / Mandarin dan ambil yang paling banyak hurufnya.
 * Hasil = (teks, nama aksara) atau null kalau gambar tidak bisa dibuka.
 */
private suspend fun ChatActivity.ocrImage(uri: Uri): Pair<String, String>? {
    val bmp = loadForOcr(uri) ?: return null
    var best = ""
    var bestName = ""
    var bestScore = -1
    for (lang in intArrayOf(3, 0, 1, 2)) {   // Latin, Jepang, Korea, Mandarin
        if (lang != 3 && bestScore >= 40) break   // Latin sudah cukup banyak: tidak perlu mencoba aksara lain
        val rec = MangaEngine.recognizer(lang)
        val t = try {
            rec.read(bmp).trim()
        } catch (_: Throwable) {
            ""
        } finally {
            try {
                rec.close()
            } catch (_: Throwable) {
            }
        }
        val score = t.count { it.isLetterOrDigit() }
        if (score > bestScore) {
            bestScore = score
            best = t
            bestName = OCR_NAMES[lang]
        }
    }
    return Pair(best, bestName)
}

private suspend fun TextRecognizer.read(bmp: Bitmap): String = suspendCancellableCoroutine { c ->
    process(InputImage.fromBitmap(bmp, 0))
        .addOnSuccessListener { t -> if (c.isActive) c.resume(t.text) }
        .addOnFailureListener { if (c.isActive) c.resume("") }
}

/** Gambar dikecilkan maksimal 3000 px (cukup untuk OCR, hemat memori), selalu bitmap software. */
private fun ChatActivity.loadForOcr(uri: Uri): Bitmap? = try {
    if (Build.VERSION.SDK_INT >= 28) {
        ImageDecoder.decodeBitmap(ImageDecoder.createSource(contentResolver, uri)) { dec, info, _ ->
            dec.setAllocator(ImageDecoder.ALLOCATOR_SOFTWARE)
            val big = maxOf(info.size.width, info.size.height)
            if (big > 3000) {
                val r = 3000f / big
                dec.setTargetSize((info.size.width * r).toInt().coerceAtLeast(1), (info.size.height * r).toInt().coerceAtLeast(1))
            }
        }
    } else {
        val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, o) }
        var sample = 1
        while (maxOf(o.outWidth, o.outHeight) / sample > 3000) sample *= 2
        val o2 = BitmapFactory.Options().apply { inSampleSize = sample }
        contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, o2) }
    }
} catch (_: Throwable) {
    null
}

// ------------------------------------------------------------------ file teks (tahap 3)

/** Menu "Baca txt" -> pemilih file. */
internal fun ChatActivity.pickTextToRead() {
    if (sending) {
        Toast.makeText(this, "Tunggu jawaban selesai dulu.", Toast.LENGTH_SHORT).show()
        return
    }
    pickText.launch(arrayOf("*/*"))
}

private class Read(val text: String?, val name: String, val err: String?)

internal fun ChatActivity.onTextPicked(uri: Uri) {
    lifecycleScope.launch {
        val r = withContext(Dispatchers.IO) { readTextFile(uri) }
        if (isDestroyed) return@launch
        if (r.text == null) {
            Toast.makeText(this@onTextPicked, r.err ?: "File tidak bisa dibuka.", Toast.LENGTH_LONG).show()
            return@launch
        }
        if (r.text.isBlank()) {
            Toast.makeText(this@onTextPicked, "File kosong.", Toast.LENGTH_SHORT).show()
            return@launch
        }
        showDocMenu(Doc(r.name, uri, r.text, r.text), null)
    }
}

private fun ChatActivity.displayName(uri: Uri): String = try {
    contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
        if (c.moveToFirst()) c.getString(0) else null
    }
} catch (_: Throwable) {
    null
} ?: "teks.txt"

private fun ChatActivity.readTextFile(uri: Uri): Read {
    val name = displayName(uri)
    return try {
        val buf = ByteArrayOutputStream()
        val tmp = ByteArray(8192)
        var total = 0
        val stream = contentResolver.openInputStream(uri) ?: return Read(null, name, "File tidak bisa dibuka.")
        stream.use { i ->
            while (true) {
                val n = i.read(tmp)
                if (n < 0) break
                total += n
                if (total > FILE_MAX_BYTES) return Read(null, name, "File terlalu besar (maksimal 2 MB).")
                buf.write(tmp, 0, n)
            }
        }
        val bytes = buf.toByteArray()
        val head = minOf(bytes.size, 4000)
        for (k in 0 until head) {
            if (bytes[k].toInt() == 0) return Read(null, name, "Ini bukan file teks.")
        }
        var s = String(bytes, Charsets.UTF_8)
        if (s.startsWith("﻿")) s = s.substring(1)
        val bad = s.count { it == '�' }
        if (bad > 0 && bad * 100 > s.length) s = String(bytes, Charset.forName("windows-1252"))
        s = s.replace("\r\n", "\n").replace('\r', '\n')
        Read(s, name, null)
    } catch (t: Throwable) {
        Read(null, name, "File tidak bisa dibuka.")
    }
}

/** Menu aksi untuk satu teks (dari gambar, file, atau hasil terjemahan). */
private fun ChatActivity.showDocMenu(d: Doc, note: String?) {
    val changed = d.text != d.orig
    val lines = d.text.count { it == '\n' } + 1
    val sub = (note?.let { "$it · " } ?: "") + "${d.text.length} huruf, $lines baris" + if (changed) " · diubah, belum disimpan" else ""
    val items = ArrayList<Sheet.Item?>()
    items.add(Sheet.Item("Salin isi", R.drawable.ic_file) { copyText(d.text) })
    items.add(Sheet.Item("Terjemahkan ke Indonesia", R.drawable.ic_l_languages) { translateDoc(d) })
    items.add(Sheet.Item("Ringkas", R.drawable.ic_l_chat) {
        sendAttached("Ringkas teks dari \"${d.name}\" ini (bisa ada salah baca / salah ketik, abaikan kalau jelas salah):", d.text)
    })
    items.add(Sheet.Item("Jelaskan", R.drawable.ic_l_chat) {
        sendAttached("Jelaskan isi teks dari \"${d.name}\" ini (bisa ada salah baca / salah ketik, perbaiki kalau jelas salah):", d.text)
    })
    items.add(Sheet.Item("Taruh di kolom chat", R.drawable.ic_down) { setInput(d.text.take(ATTACH_CHAT_MAX)) })
    items.add(null)
    items.add(Sheet.Item("Ubah isi...", R.drawable.ic_edit) { showEditMenu(d) })
    items.add(Sheet.Item("Lihat / edit manual", R.drawable.ic_edit) {
        Sheet.editor(this, d.name, d.text, "Pakai") { edited ->
            d.text = edited
            showDocMenu(d, null)
        }
    })
    items.add(null)
    items.add(Sheet.Item("Simpan sebagai salinan (.txt)", R.drawable.ic_down) { saveCopy(d) })
    if (d.uri != null && changed) {
        items.add(Sheet.Item("Timpa file asli", R.drawable.ic_trash, true) { overwriteOriginal(d) })
    }
    if (changed) {
        items.add(Sheet.Item("Kembalikan ke isi awal", R.drawable.ic_undo) {
            d.text = d.orig
            showDocMenu(d, null)
        })
    }
    Sheet.menu(this, d.name, sub, items)
}

/** Kirim instruksi + teks ke chat. Teks terlalu panjang dipotong (konteks model terbatas). */
internal fun ChatActivity.sendAttached(instruction: String, text: String) {
    if (sending) {
        Toast.makeText(this, "Tunggu jawaban selesai dulu.", Toast.LENGTH_SHORT).show()
        return
    }
    val body = if (text.length > ATTACH_CHAT_MAX) text.take(ATTACH_CHAT_MAX) + "\n(...dipotong, teks terlalu panjang)" else text
    send("$instruction\n\n$body")
}

internal fun ChatActivity.copyText(text: String) {
    val cm = getSystemService(android.content.Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager
    cm.setPrimaryClip(android.content.ClipData.newPlainText("BunnyTL", text))
    Toast.makeText(this, "Tersalin.", Toast.LENGTH_SHORT).show()
}

// ------------------------------------------------------------------ simpan

private fun ChatActivity.saveCopy(d: Doc) {
    val base = d.name.substringBeforeLast('.', d.name)
    val fn = if (d.uri == null) d.name else base + (if (d.text != d.orig) "_edit" else "_salinan") + ".txt"
    pendingSave = d.text
    saveText.launch(fn)
}

/** Dipanggil setelah pengguna memilih lokasi simpan. */
internal fun ChatActivity.onSaveTarget(uri: Uri) {
    val t = pendingSave ?: return
    pendingSave = null
    lifecycleScope.launch {
        val ok = withContext(Dispatchers.IO) { writeText(uri, t) }
        Toast.makeText(this@onSaveTarget, if (ok) "Tersimpan." else "Gagal menyimpan.", Toast.LENGTH_LONG).show()
    }
}

private fun ChatActivity.writeText(uri: Uri, t: String): Boolean = try {
    contentResolver.openOutputStream(uri, "wt")?.use { it.write(t.toByteArray(Charsets.UTF_8)) } != null
} catch (_: Throwable) {
    false
}

private fun ChatActivity.overwriteOriginal(d: Doc) {
    val u = d.uri ?: return
    Sheet.confirm(
        this, "Timpa file asli?",
        "Isi \"${d.name}\" akan diganti hasil edit dan tidak bisa dikembalikan. Lebih aman simpan sebagai salinan.",
        "Timpa", true, onCancel = { showDocMenu(d, null) }
    ) {
        lifecycleScope.launch {
            val ok = withContext(Dispatchers.IO) { writeText(u, d.text) }
            if (isDestroyed) return@launch
            if (ok) {
                d.orig = d.text
                showDocMenu(d, "Tersimpan ke file asli")
            } else {
                Toast.makeText(this@overwriteOriginal, "File ini tidak bisa ditulis. Simpan sebagai salinan saja.", Toast.LENGTH_LONG).show()
                showDocMenu(d, null)
            }
        }
    }
}

// ------------------------------------------------------------------ terjemah per bagian

private fun ChatActivity.translateDoc(d: Doc) {
    val glossary = (prefs().getString("glossary", "") ?: "").trim().take(400)
    val system = buildString {
        append("Translate the user's text into natural Indonesian. Keep line breaks, names, numbers, lists and formatting. ")
        append("Translate by meaning, not word for word. Reply ONLY with the translation, no notes or explanations.")
        if (glossary.isNotBlank()) append("\nGlossary (follow strictly): ").append(glossary)
    }
    val base = d.name.substringBeforeLast('.', d.name)
    runChunked(
        "Menerjemahkan...", system, d.text,
        { _, _, p -> "Terjemahkan ke bahasa Indonesia:\n\n$p" },
        sanity = false
    ) { out, _ ->
        showDocMenu(Doc("${base}_id.txt", null, out, out), "Hasil terjemahan")
    }
}

// ------------------------------------------------------------------ ubah isi (tahap 4)

private fun ChatActivity.showEditMenu(d: Doc) {
    Sheet.menu(
        this, "Ubah isi", "Hasil selalu ditampilkan dulu sebelum dipakai",
        listOf(
            Sheet.Item("Cari & ganti", R.drawable.ic_edit, false, "Tepat sama, huruf besar-kecil dibedakan") { findReplace(d) },
            Sheet.Item("Hapus baris yang mengandung...", R.drawable.ic_trash) { deleteLines(d) },
            Sheet.Item("Minta AI mengubah", R.drawable.ic_l_chat, false, "Per bagian: cocok untuk typo, gaya, ejaan") { aiEdit(d) },
            null,
            Sheet.Item("Kembali", R.drawable.ic_back) { showDocMenu(d, null) }
        )
    )
}

private fun ChatActivity.findReplace(d: Doc) {
    Sheet.form(
        this, "Cari & ganti", "Hanya yang sama persis diganti. Hasilnya diperlihatkan dulu.",
        listOf("Cari" to "", "Ganti dengan" to ""), "Lanjut"
    ) { v ->
        val find = v[0]
        if (find.isEmpty()) {
            Toast.makeText(this, "Isi kolom Cari dulu.", Toast.LENGTH_SHORT).show()
            showEditMenu(d)
            return@form
        }
        val count = Regex(Regex.escape(find)).findAll(d.text).count()
        if (count == 0) {
            Toast.makeText(this, "Tidak ketemu.", Toast.LENGTH_SHORT).show()
            showEditMenu(d)
            return@form
        }
        confirmChange(d, d.text.replace(find, v[1]), "$count tempat diganti.")
    }
}

private fun ChatActivity.deleteLines(d: Doc) {
    Sheet.input(this, "Hapus baris yang mengandung", "Kata / potongan teks", "", "Lanjut") { word ->
        if (word.isEmpty()) {
            showEditMenu(d)
            return@input
        }
        val lines = d.text.split("\n")
        val kept = lines.filter { !it.contains(word) }
        val gone = lines.size - kept.size
        if (gone == 0) {
            Toast.makeText(this, "Tidak ada baris yang cocok.", Toast.LENGTH_SHORT).show()
            showEditMenu(d)
            return@input
        }
        confirmChange(d, kept.joinToString("\n"), "$gone baris dihapus.")
    }
}

private fun ChatActivity.aiEdit(d: Doc) {
    Sheet.input(this, "Minta AI mengubah", "Contoh: perbaiki typo dan ejaan", "", "Kerjakan") { instr ->
        val ins = instr.trim()
        if (ins.isEmpty()) {
            showEditMenu(d)
            return@input
        }
        val system = "You edit text. Apply the user's instruction to the given text part and reply ONLY with the full edited text of this part, " +
            "keeping the same language, line breaks and structure unless the instruction says otherwise. No explanations, no quotes, no markdown."
        runChunked(
            "AI mengubah...", system, d.text,
            { _, _, p -> "Instruksi: $ins\n\nTeks:\n$p" },
            sanity = true
        ) { out, skipped ->
            val note = if (skipped > 0) "AI selesai; $skipped bagian dibiarkan asli karena hasilnya tidak wajar." else "AI selesai."
            confirmChange(d, out, note)
        }
    }
}

/** Pratinjau perubahan; baru dipakai kalau pengguna setuju. */
private fun ChatActivity.confirmChange(d: Doc, newText: String, note: String) {
    if (newText == d.text) {
        Toast.makeText(this, "Tidak ada yang berubah.", Toast.LENGTH_SHORT).show()
        showDocMenu(d, null)
        return
    }
    Sheet.confirm(
        this, "Terapkan perubahan?", note + "\n\n" + diffPreview(d.text, newText), "Terapkan", false,
        onCancel = { showDocMenu(d, null) }
    ) {
        d.text = newText
        showDocMenu(d, note)
    }
}

private fun diffPreview(old: String, new: String): String {
    val a = old.split("\n")
    val b = new.split("\n")
    val sb = StringBuilder()
    sb.append("Sebelum: ${old.length} huruf, ${a.size} baris\nSesudah: ${new.length} huruf, ${b.size} baris\n")
    if (a.size == b.size) {
        var n = 0
        var shown = 0
        for (i in a.indices) {
            if (a[i] != b[i]) {
                n++
                if (shown < 4) {
                    shown++
                    sb.append("\n- ").append(a[i].take(140)).append("\n+ ").append(b[i].take(140)).append("\n")
                }
            }
        }
        sb.append("\n$n baris berubah")
        if (n > shown) sb.append(" (contoh $shown di atas)")
    } else {
        sb.append("\nCuplikan hasil:\n").append(new.take(300))
    }
    return sb.toString()
}

// ------------------------------------------------------------------ pemrosesan per bagian

/** Teks dipecah jadi bagian-bagian kecil (di batas baris) + pemisah yang dipasang kembali sebelum tiap bagian. */
private class Pieces(val texts: List<String>, val seps: List<String>, val endsNl: Boolean) {
    fun join(results: List<String>): String {
        val sb = StringBuilder()
        for (i in results.indices) {
            sb.append(seps[i])
            sb.append(results[i])
        }
        if (endsNl) sb.append("\n")
        return sb.toString()
    }
}

private val SENT_ENDS = charArrayOf('.', '!', '?', ';', '。', '！', '？')

private fun splitPieces(text: String): Pieces {
    val max = if (MangaEngine.hasCjk(text.take(2000))) 350 else 800
    val texts = ArrayList<String>()
    val seps = ArrayList<String>()
    val cur = StringBuilder()
    var sep = ""
    fun emit(t: String, next: String) {
        texts.add(t)
        seps.add(sep)
        sep = next
    }
    fun flush() {
        if (cur.isEmpty()) return
        val s = cur.toString()
        val body = s.trimEnd('\n')
        cur.setLength(0)
        if (body.isNotBlank()) emit(body, "\n".repeat(s.length - body.length)) else sep += "\n".repeat(s.length)
    }
    for (line in text.split("\n")) {
        if (line.length > max) {
            // satu baris sangat panjang: dipotong di akhir kalimat / spasi, disambung lagi dengan spasi
            flush()
            var rest = line
            while (rest.length > max) {
                var cut = rest.lastIndexOfAny(SENT_ENDS, max)
                if (cut < max / 3) cut = rest.lastIndexOf(' ', max)
                if (cut < max / 3) cut = max - 1
                val piece = rest.substring(0, cut + 1).trim()
                if (piece.isNotEmpty()) emit(piece, " ")
                rest = rest.substring(cut + 1)
            }
            if (rest.isNotBlank()) emit(rest.trim(), "\n") else sep = "\n"
            continue
        }
        if (cur.isNotEmpty() && cur.length + line.length + 1 > max) flush()
        if (cur.isEmpty() && line.isBlank()) {
            sep += "\n"
            continue
        }
        cur.append(line).append('\n')
    }
    flush()
    return Pieces(texts, seps, text.endsWith("\n"))
}

/**
 * Jalankan Gemma per bagian dengan dialog kemajuan + tombol Batal. sanity = true: hasil yang kosong atau jauh lebih pendek / panjang
 * dari aslinya dianggap tidak wajar dan bagian itu dibiarkan asli. onDone(hasilGabungan, jumlahBagianDilewati).
 */
private fun ChatActivity.runChunked(
    title: String,
    system: String,
    text: String,
    wrap: (Int, Int, String) -> String,
    sanity: Boolean,
    onDone: (String, Int) -> Unit
) {
    if (docBusy) {
        Toast.makeText(this, "Masih ada proses yang berjalan.", Toast.LENGTH_SHORT).show()
        return
    }
    val model = Gemma.findModel(this)
    if (model == null) {
        Toast.makeText(this, "Model .litertlm belum ada.", Toast.LENGTH_LONG).show()
        return
    }
    val pieces = splitPieces(text)
    val n = pieces.texts.size
    if (n == 0) return
    docBusy = true
    val dlg = AlertDialog.Builder(this)
        .setTitle(title)
        .setMessage("Bagian 1 dari $n")
        .setCancelable(false)
        .setNegativeButton("Batal") { _, _ -> Gemma.chatCancel() }
        .show()
    Gemma.processText(
        this, model, system, pieces.texts, wrap,
        onPart = { i, partial ->
            runOnUiThread { dlg.setMessage("Bagian ${i + 1} dari $n (${partial.length} huruf)") }
        },
        onFinish = { results, err ->
            runOnUiThread {
                docBusy = false
                try {
                    dlg.dismiss()
                } catch (_: Throwable) {
                }
                if (isDestroyed) return@runOnUiThread
                when {
                    err != null -> Toast.makeText(this, "Gagal: $err", Toast.LENGTH_LONG).show()
                    results.size < n -> Toast.makeText(this, "Dibatalkan.", Toast.LENGTH_SHORT).show()
                    else -> {
                        var skipped = 0
                        val fixed = results.mapIndexed { i, r ->
                            val src = pieces.texts[i]
                            val bad = sanity && (r.isBlank() || r.length < src.length / 2 || r.length > src.length * 2 + 40)
                            if (bad) {
                                skipped++
                                src
                            } else {
                                r
                            }
                        }
                        onDone(pieces.join(fixed), skipped)
                    }
                }
            }
        }
    )
}
