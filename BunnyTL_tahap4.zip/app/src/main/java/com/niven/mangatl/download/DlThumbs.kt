package com.niven.mangatl

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.os.Handler
import android.os.Looper
import android.util.LruCache
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.Executors

/** Gambar mini untuk daftar unduhan: cache di memori, diambil di latar, UI dikabari lewat callback. */
object DlThumbs {
    private val cache = LruCache<String, Bitmap>(48)
    private val waiting = HashMap<String, MutableList<() -> Unit>>()
    private val failed = HashSet<String>()
    private val main = Handler(Looper.getMainLooper())
    private val pool = Executors.newFixedThreadPool(3)
    private val YT = Regex("""(?:youtube\.com/(?:watch\?(?:.*&)?v=|shorts/|embed/)|youtu\.be/)([A-Za-z0-9_-]{11})""")

    /** Tebak gambar mini dari link YouTube (item playlist tidak membawa gambar). Kosong kalau bukan YouTube. */
    fun guess(url: String): String {
        val id = YT.find(url)?.groupValues?.get(1) ?: return ""
        return "https://i.ytimg.com/vi/$id/mqdefault.jpg"
    }

    fun get(url: String): Bitmap? = cache.get(url)

    fun fetch(url: String, done: () -> Unit) {
        synchronized(this) {
            if (cache.get(url) != null || url in failed) return
            val list = waiting[url]
            if (list != null) { list += done; return }
            waiting[url] = mutableListOf(done)
        }
        pool.execute {
            val bmp = runCatching { decode(url) }.getOrNull()
            val callbacks = synchronized(this) {
                if (bmp != null) cache.put(url, bmp) else failed += url
                waiting.remove(url) ?: mutableListOf()
            }
            if (bmp != null) main.post { callbacks.forEach { it() } }
        }
    }

    private fun decode(url: String): Bitmap? {
        val c = URL(url.replaceFirst("http://", "https://")).openConnection() as HttpURLConnection
        return try {
            c.connectTimeout = 8000
            c.readTimeout = 8000
            val bytes = c.inputStream.use { it.readBytes() }
            val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            BitmapFactory.decodeByteArray(bytes, 0, bytes.size, o)
            var s = 1
            while (o.outWidth / s > 480) s *= 2
            BitmapFactory.decodeByteArray(bytes, 0, bytes.size, BitmapFactory.Options().apply { inSampleSize = s })
        } finally {
            c.disconnect()
        }
    }
}
