package com.niven.mangatl

import android.content.Context
import android.util.AttributeSet
import android.view.View
import android.view.ViewGroup
import android.view.View.MeasureSpec

/**
 * Menumpuk dua anak: [0] topStage (header + tombol + panggung avatar) dan [1] chatArea (daftar chat).
 * Posisi dihitung SEKALIGUS di satu putaran ukur (tanpa mengubah LayoutParams di tengah jalan), sehingga tidak ada
 * nilai basi saat keyboard muncul / mode berganti.
 *
 *  STAGE: panggung = separuh tinggi, chat naik setinggi sobekan (tearPx) menimpa dasar panggung
 *  FULL : chat mulai di garis lineAbsPx (dari atas root) -- dipakai avatar full body di belakang chat
 *  PLAIN: chat langsung di bawah header + tombol
 *
 * Kedua anak dibuat selebar layar (melebar bleedPx ke kiri-kanan, menembus padding induk).
 */
class BodyLayout @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : ViewGroup(context, attrs) {

    enum class Mode { STAGE, FULL, PLAIN }

    var mode = Mode.PLAIN
        set(v) {
            if (field != v) {
                field = v
                requestLayout()
            }
        }
    var tearPx = 0
        set(v) {
            if (field != v) {
                field = v
                requestLayout()
            }
        }
    var lineAbsPx = 0f
        set(v) {
            if (field != v) {
                field = v
                requestLayout()
            }
        }
    var topOffsetPx = 0
    var gapPx = 0
    var bleedPx = 0

    private var chatTop = 0

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        val w = MeasureSpec.getSize(widthMeasureSpec)
        val h = MeasureSpec.getSize(heightMeasureSpec)
        val stage: View? = if (childCount > 0) getChildAt(0) else null
        val chat: View? = if (childCount > 1) getChildAt(1) else null
        val fullW = MeasureSpec.makeMeasureSpec(w + 2 * bleedPx, MeasureSpec.EXACTLY)
        if (stage != null) {
            val hs = if (mode == Mode.STAGE) {
                MeasureSpec.makeMeasureSpec(h / 2, MeasureSpec.EXACTLY)
            } else {
                MeasureSpec.makeMeasureSpec(h, MeasureSpec.AT_MOST)
            }
            stage.measure(fullW, hs)
        }
        val stageH = stage?.measuredHeight ?: 0
        chatTop = when (mode) {
            Mode.STAGE -> h / 2 - tearPx
            Mode.FULL -> maxOf((lineAbsPx - topOffsetPx).toInt(), stageH + gapPx)
            Mode.PLAIN -> stageH + gapPx
        }.coerceIn(0, h)
        chat?.measure(fullW, MeasureSpec.makeMeasureSpec((h - chatTop).coerceAtLeast(0), MeasureSpec.EXACTLY))
        setMeasuredDimension(w, h)
    }

    override fun onLayout(changed: Boolean, l: Int, t: Int, r: Int, b: Int) {
        val w = r - l
        if (childCount > 0) {
            val s = getChildAt(0)
            s.layout(-bleedPx, 0, w + bleedPx, s.measuredHeight)
        }
        if (childCount > 1) {
            val c = getChildAt(1)
            c.layout(-bleedPx, chatTop, w + bleedPx, chatTop + c.measuredHeight)
        }
    }

    override fun shouldDelayChildPressedState(): Boolean = false
}
