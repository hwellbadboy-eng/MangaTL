package com.niven.mangatl

import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.Matrix
import android.graphics.Point
import android.graphics.Rect
import android.graphics.RectF
import com.google.android.gms.tasks.Tasks
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.Text
import com.google.mlkit.vision.text.TextRecognizer

// Manga Translator: membaca teks halaman (ML Kit), mengelompokkan baris jadi blok satu balon, dan meluruskan teks miring.
// Fungsi ekstensi dari MangaEngine; keadaan dan API publik tetap di MangaEngine.kt.

/**
 * Kelompokkan baris-baris teks ke dalam balon/kotak yang sama: bertumpuk rapat, kolom sejajar,
 * tinggi huruf mirip, dan tidak ada garis tepi balon di antaranya.
 */
internal class MangaGeo(val cx: Float, val cy: Float, val w: Float, val h: Float, val ang: Float)

internal fun MangaEngine.usable(s: String): Boolean {
    val letters = s.count { it.isLetter() }
    return letters >= 2 || (letters >= 1 && hasCjk(s))
}

/** Ada garis pembatas (tepi balon/kotak) yang melintang di strip ini? Strip = celah antara dua baris teks. */
internal fun MangaEngine.hasSeparator(img: Bitmap, x0: Int, x1: Int, y0: Int, y1: Int): Boolean {
    val xs = maxOf(0, x0)
    val ys = maxOf(0, y0)
    val w = minOf(img.width, x1) - xs
    val h = minOf(img.height, y1) - ys
    if (w < 8 || h < 5) return false
    val px = IntArray(w * h)
    img.getPixels(px, 0, w, xs, ys, w, h)
    val lum = IntArray(w * h) { (Color.red(px[it]) * 299 + Color.green(px[it]) * 587 + Color.blue(px[it]) * 114) / 1000 }
    val med = lum.sorted()[lum.size / 2]
    var high = 0
    for (row in 0 until h) {
        var cnt = 0
        for (x in 0 until w) if (Math.abs(lum[row * w + x] - med) > 80) cnt++
        if (cnt >= 0.85f * w) high++
    }
    // Garis tepi balon = beberapa baris tipis yang hampir penuh; pita teks tidak dihitung.
    return high in 1..maxOf(4, h / 3)
}

/** Geometri baris dari titik sudutnya (ikut kemiringan). Null kalau ML Kit tidak memberi titik sudut. */
internal fun MangaEngine.geoOf(l: Text.Line): MangaGeo? {
    val cp = l.cornerPoints
    if (cp == null || cp.size != 4) return null
    val w = Math.hypot((cp[1].x - cp[0].x).toDouble(), (cp[1].y - cp[0].y).toDouble()).toFloat()
    val h = Math.hypot((cp[3].x - cp[0].x).toDouble(), (cp[3].y - cp[0].y).toDouble()).toFloat()
    val ang = Math.toDegrees(Math.atan2((cp[1].y - cp[0].y).toDouble(), (cp[1].x - cp[0].x).toDouble())).toFloat()
    return MangaGeo(cp.sumOf { it.x } / 4f, cp.sumOf { it.y } / 4f, w, h, ang)
}

internal fun MangaEngine.clusterLines(img: Bitmap, lines: List<Text.Line>, dbg: StringBuilder?): List<List<Text.Line>> {
    val ls = lines.filter { it.boundingBox != null }
    val n = ls.size
    val parent = IntArray(n) { it }
    fun find(x: Int): Int {
        var r = x
        while (parent[r] != r) r = parent[r]
        var c = x
        while (parent[c] != r) { val nx = parent[c]; parent[c] = r; c = nx }
        return r
    }
    val geos = ls.map { geoOf(it) }
    for (i in 0 until n) for (j in i + 1 until n) {
        val ga = geos[i]
        val gb = geos[j]
        if (ga != null && gb != null && (Math.abs(ga.ang) >= TILT_MIN || Math.abs(gb.ang) >= TILT_MIN)) {
            // Teks miring: bandingkan di bingkai yang ikut kemiringan, bukan di kotak sumbu-X yang membengkak.
            if (Math.abs(ga.ang - gb.ang) > 6f) continue
            val th = Math.toRadians(((ga.ang + gb.ang) / 2f).toDouble())
            val cs = Math.cos(th).toFloat()
            val sn = Math.sin(th).toFloat()
            val ax = ga.cx * cs + ga.cy * sn
            val ay = -ga.cx * sn + ga.cy * cs
            val bx = gb.cx * cs + gb.cy * sn
            val by = -gb.cx * sn + gb.cy * cs
            val lhR = minOf(ga.h, gb.h).coerceAtLeast(1f)
            if (maxOf(ga.h, gb.h) > 2.2f * lhR) continue
            val gapR = Math.abs(ay - by) - (ga.h + gb.h) / 2f
            if (gapR < -0.5f * lhR || gapR > 0.7f * maxOf(ga.h, gb.h)) continue
            val oxR = minOf(ax + ga.w / 2f, bx + gb.w / 2f) - maxOf(ax - ga.w / 2f, bx - gb.w / 2f)
            if (oxR < 0.4f * minOf(ga.w, gb.w)) continue
            val wMaxR = maxOf(ga.w, gb.w)
            val alignedR = Math.abs(ax - bx) <= 0.3f * wMaxR ||
                Math.abs((ax - ga.w / 2f) - (bx - gb.w / 2f)) <= 0.6f * lhR ||
                Math.abs((ax + ga.w / 2f) - (bx + gb.w / 2f)) <= 0.6f * lhR
            if (!alignedR) continue
            dbg?.append("  GABUNG(miring) [${ls[i].text.take(20)}] + [${ls[j].text.take(20)}] gap=${gapR.toInt()}\n")
            val rA = find(i)
            val rB = find(j)
            if (rA != rB) parent[rB] = rA
            continue
        }
        val a = ls[i].boundingBox!!
        val b = ls[j].boundingBox!!
        val lh = minOf(a.height(), b.height()).coerceAtLeast(1)
        if (maxOf(a.height(), b.height()) > 2.2f * lh) continue
        val gap = maxOf(a.top, b.top) - minOf(a.bottom, b.bottom)
        if (gap < -0.5f * lh || gap > 0.7f * maxOf(a.height(), b.height())) continue
        val ox = minOf(a.right, b.right) - maxOf(a.left, b.left)
        if (ox < 0.4f * minOf(a.width(), b.width())) continue
        val wMax = maxOf(a.width(), b.width())
        val aligned = Math.abs(a.centerX() - b.centerX()) <= 0.3f * wMax ||
            Math.abs(a.left - b.left) <= 0.6f * lh || Math.abs(a.right - b.right) <= 0.6f * lh
        if (!aligned) continue
        if (gap >= 6 && hasSeparator(img, maxOf(a.left, b.left), minOf(a.right, b.right), minOf(a.bottom, b.bottom), maxOf(a.top, b.top))) {
            dbg?.append("  PISAH(garis pembatas) [${ls[i].text.take(20)}] | [${ls[j].text.take(20)}] gap=$gap\n")
            continue
        }
        dbg?.append("  GABUNG [${ls[i].text.take(20)}] + [${ls[j].text.take(20)}] gap=$gap ox=$ox lh=$lh\n")
        val ra = find(i)
        val rb = find(j)
        if (ra != rb) parent[rb] = ra
    }
    val groups = LinkedHashMap<Int, MutableList<Text.Line>>()
    for (i in 0 until n) groups.getOrPut(find(i)) { mutableListOf() }.add(ls[i])
    return groups.values.map { g -> g.sortedWith(compareBy({ it.boundingBox!!.top }, { it.boundingBox!!.left })) }
}

/**
 * Baca teks per potongan tinggi. Gambar kecil diperbesar dulu (teks kecil sering lolos OCR).
 * Potongan sengaja saling tumpang tindih supaya teks di garis potong tidak terbelah; duplikat dibuang.
 */
internal fun MangaEngine.readBlocks(rec: TextRecognizer, bmp: Bitmap, lang: Int, dbg: StringBuilder? = null): List<Block> {
    val all = ArrayList<Block>()
    val joiner = if (lang == 0 || lang == 2) "" else " "
    val scale = when {
        bmp.width <= 1100 -> 2f
        bmp.width <= 1700 -> 1.5f
        else -> 1f
    }
    val stripH = (STRIP_H / scale).toInt()
    val overlap = 160
    var y = 0
    while (true) {
        var h = minOf(stripH, bmp.height - y)
        if (bmp.height - (y + h) in 1..300) h = bmp.height - y
        val strip = Bitmap.createBitmap(bmp, 0, y, bmp.width, h)
        val big = if (scale == 1f) strip
        else Bitmap.createScaledBitmap(strip, (bmp.width * scale).toInt(), (h * scale).toInt(), true)
        try {
            val t = Tasks.await(rec.process(InputImage.fromBitmap(big, 0)))
            // Teks horizontal: kelompokkan ulang per BARIS (blok ML Kit sering memecah satu balon jadi banyak potongan).
            val groupList: List<List<Text.Line>> =
                if (lang == 0) t.textBlocks.map { it.lines }
                else clusterLines(big, t.textBlocks.flatMap { it.lines }, dbg)
            run {
                for (g in groupList) {
                    val box = Rect()
                    var first = true
                    for (ln in g) {
                        val lb = ln.boundingBox ?: continue
                        if (first) { box.set(lb); first = false } else box.union(lb)
                    }
                    if (first) continue
                    val txt = g.joinToString(joiner) { it.text.trim() }.trim()
                    if (!usable(txt)) continue
                    val pts = ArrayList<Point>()
                    val angs = ArrayList<Pair<Double, Double>>()
                    for (ln in g) {
                        val cp = ln.cornerPoints
                        if (cp != null && cp.size == 4) {
                            for (p in cp) pts.add(Point((p.x / scale).toInt(), (p.y / scale).toInt() + y))
                            val dx = (cp[1].x - cp[0].x).toDouble()
                            val dy = (cp[1].y - cp[0].y).toDouble()
                            angs.add(Pair(Math.toDegrees(Math.atan2(dy, dx)), Math.hypot(dx, dy)))
                        }
                    }
                    val hs = g.mapNotNull { it.boundingBox?.height() }.sorted()
                    val lineH = if (lang == 0 || hs.isEmpty()) 0 else (hs[hs.size / 2] / scale).toInt()
                    val ang0 = weightedMedian(angs)
                    val rectOrig = Rect(
                        (box.left / scale).toInt(), (box.top / scale).toInt() + y,
                        (box.right / scale).toInt(), (box.bottom / scale).toInt() + y
                    )
                    val tilted = lang != 0 && pts.size >= 4 && Math.abs(ang0) >= TILT_MIN && Math.abs(ang0) <= 60f
                    // Sudut ML Kit untuk baris pendek sering meleset; perhalus dari piksel gambar asli.
                    val ang = if (tilted) refineAngle(bmp, rectOrig, ang0) else ang0
                    val tiltedFinal = tilted && Math.abs(ang) >= TILT_MIN
                    all.add(
                        Block(
                            rectOrig, txt, if (tiltedFinal) ang else 0f, if (tiltedFinal) pts else emptyList(), lineH
                        )
                    )
                }
            }
        } finally {
            if (big !== strip) big.recycle()
            if (strip !== bmp) strip.recycle()
        }
        if (y + h >= bmp.height) break
        y += maxOf(1, h - overlap)
    }
    if (all.size < 2) return all.map { reReadTilted(rec, bmp, it, lang, scale, dbg) }
    // Buang duplikat dari area tumpang tindih: simpan yang teksnya paling lengkap.
    val kept = ArrayList<Block>()
    for (b in all.sortedByDescending { it.text.length }) {
        val dup = kept.any { k ->
            val ix = minOf(k.rect.right, b.rect.right) - maxOf(k.rect.left, b.rect.left)
            val iy = minOf(k.rect.bottom, b.rect.bottom) - maxOf(k.rect.top, b.rect.top)
            if (ix <= 0 || iy <= 0) false
            else ix.toLong() * iy > 0.5 * minOf(k.rect.width().toLong() * k.rect.height(), b.rect.width().toLong() * b.rect.height())
        }
        if (!dup) kept.add(b)
    }
    return kept.map { reReadTilted(rec, bmp, it, lang, scale, dbg) }
}

/**
 * Teks miring sering terbaca terpotong ("Meat was real cheap today so I'm" hanya terbaca "o I'm").
 * Luruskan potongan gambar di sekitar blok miring, baca ulang, dan pakai hasilnya kalau lebih lengkap.
 * Titik sudut baris hasil baca ulang dipetakan balik ke gambar asli supaya penghapusan teks ikut menutup baris yang tadi terlewat.
 * Kalau apa pun gagal, blok lama dipakai apa adanya.
 */
internal fun MangaEngine.reReadTilted(rec: TextRecognizer, bmp: Bitmap, b: Block, lang: Int, scale: Float, dbg: StringBuilder?): Block {
    if (lang == 0 || b.angle == 0f || b.pts.size < 4) return b
    try {
        val padX = maxOf(20, b.rect.width() / 4)
        val padY = maxOf(20, b.rect.height() / 2)
        val sub = clampRect(Rect(b.rect.left - padX, b.rect.top - padY, b.rect.right + padX, b.rect.bottom + padY), bmp)
        val w = sub.width()
        val h = sub.height()
        if (w < 30 || h < 20 || w.toLong() * h > 1_500_000L) return b
        val m = Matrix()
        m.postRotate(-b.angle, w / 2f, h / 2f)
        m.postScale(scale, scale)
        val dev = RectF(0f, 0f, w.toFloat(), h.toFloat())
        m.mapRect(dev)
        val rot = Bitmap.createBitmap(bmp, sub.left, sub.top, w, h, m, true)
        try {
            val inv = Matrix()
            if (!m.invert(inv)) return b
            val t = Tasks.await(rec.process(InputImage.fromBitmap(rot, 0)))
            val lines = t.textBlocks.flatMap { it.lines }
            if (lines.isEmpty()) return b
            val groups = clusterLines(rot, lines, null)
            // pusat blok lama di koordinat gambar yang sudah diluruskan
            val c = floatArrayOf(b.rect.centerX() - sub.left.toFloat(), b.rect.centerY() - sub.top.toFloat())
            m.mapPoints(c)
            c[0] -= dev.left
            c[1] -= dev.top
            val g = groups.minByOrNull { grp ->
                val bb = Rect()
                var f = true
                for (ln in grp) { val lb = ln.boundingBox ?: continue; if (f) { bb.set(lb); f = false } else bb.union(lb) }
                val dx = bb.centerX() - c[0]
                val dy = bb.centerY() - c[1]
                dx * dx + dy * dy
            } ?: return b
            val txt = g.joinToString(" ") { it.text.trim() }.trim()
            if (!usable(txt) || txt.length < b.text.length + 8) return b
            val pts = ArrayList<Point>()
            val hs = ArrayList<Int>()
            for (ln in g) {
                val cp = ln.cornerPoints ?: continue
                if (cp.size != 4) continue
                for (pnt in cp) {
                    val q = floatArrayOf(pnt.x + dev.left, pnt.y + dev.top)
                    inv.mapPoints(q)
                    pts.add(Point((q[0] + sub.left).toInt(), (q[1] + sub.top).toInt()))
                }
                hs.add((Math.hypot((cp[3].x - cp[0].x).toDouble(), (cp[3].y - cp[0].y).toDouble()) / scale).toInt())
            }
            if (pts.size < 4) return b
            val r = Rect(pts[0].x, pts[0].y, pts[0].x, pts[0].y)
            for (pnt in pts) r.union(pnt.x, pnt.y)
            r.union(b.rect)
            hs.sort()
            dbg?.append("  OCR-ULANG miring ${b.angle.toInt()}deg: [${b.text.take(30)}] -> [${txt.take(50)}]\n")
            return Block(r, txt, b.angle, pts, if (hs.isEmpty()) b.lineH else hs[hs.size / 2])
        } finally {
            rot.recycle()
        }
    } catch (_: Throwable) {
        return b
    }
}

/** Median dengan bobot (sudut, panjang baris). Baris panjang lebih dipercaya daripada kata pendek. */
internal fun MangaEngine.weightedMedian(v: List<Pair<Double, Double>>): Float {
    if (v.isEmpty()) return 0f
    val sorted = v.sortedBy { it.first }
    val total = sorted.sumOf { it.second }
    var acc = 0.0
    for (p in sorted) {
        acc += p.second
        if (acc >= total / 2) return p.first.toFloat()
    }
    return sorted.last().first.toFloat()
}

/**
 * Perhalus sudut teks dari piksel gambar asli: coba sudut di sekitar tebakan ML Kit (+-8 derajat) dan
 * pilih yang membuat goresan tinta paling mengumpul di baris-baris (proyeksi baris paling "tajam").
 * Kalau buktinya lemah (tinta terlalu sedikit/penuh, atau tidak lebih baik dari tebakan), pakai tebakan.
 */
internal fun MangaEngine.refineAngle(bmp: Bitmap, r: Rect, guess: Float): Float {
    val c = clampRect(r, bmp)
    val w = c.width()
    val h = c.height()
    if (w < 30 || h < 20 || w.toLong() * h > 500_000L) return guess
    val px = IntArray(w * h)
    bmp.getPixels(px, 0, w, c.left, c.top, w, h)
    val xs = IntArray(w * h)
    val ys = IntArray(w * h)
    var n = 0
    for (y in 0 until h) for (x in 0 until w) {
        val p = px[y * w + x]
        if ((Color.red(p) * 299 + Color.green(p) * 587 + Color.blue(p) * 114) / 1000 < 110) {
            xs[n] = x; ys[n] = y; n++
        }
    }
    if (n < 150 || n > w.toLong() * h * 0.5) return guess
    val off = w + h + 2
    val bins = IntArray(2 * off + h + 2)
    fun score(a: Float): Double {
        java.util.Arrays.fill(bins, 0)
        val th = Math.toRadians(a.toDouble())
        val s = Math.sin(th).toFloat()
        val co = Math.cos(th).toFloat()
        for (k in 0 until n) {
            val yy = (-xs[k] * s + ys[k] * co).toInt() + off
            if (yy >= 0 && yy < bins.size) bins[yy]++
        }
        var sum = 0.0
        for (b in bins) sum += b.toDouble() * b
        return sum
    }
    val base = score(guess)
    var best = guess
    var bestScore = base
    var a = guess - 8f
    while (a <= guess + 8f) {
        val sc = score(a)
        if (sc > bestScore) { bestScore = sc; best = a }
        a += 0.5f
    }
    return if (bestScore > base * 1.03) best else guess
}

internal fun MangaEngine.close(a: Rect, b: Rect, lang: Int): Boolean {
    if (lang != 0) return false // teks horizontal: pemisahan per balon sudah ditangani saat OCR
    val dimA = minOf(a.width(), a.height())
    val dimB = minOf(b.width(), b.height())
    val gap = (minOf(dimA, dimB) * 0.6f).toInt().coerceIn(6, 20)
    val ra = Rect(a.left - gap, a.top - gap, a.right + gap, a.bottom + gap)
    return Rect.intersects(ra, b)
}

/** Urutan baca dua blok: manga Jepang kolom kanan dulu, lainnya atas dulu. */
internal fun MangaEngine.firstIsBefore(a: Rect, b: Rect, lang: Int): Boolean {
    val sameRow = Math.abs(a.centerY() - b.centerY()) < maxOf(a.height(), b.height()) * 0.6f
    return if (lang == 0 && sameRow) a.centerX() > b.centerX() else a.top < b.top ||
        (a.top == b.top && a.left < b.left)
}

internal fun MangaEngine.merge(blocks: List<Block>, lang: Int): List<Block> {
    val joiner = if (lang == 0 || lang == 2) "" else " "
    val list = blocks.toMutableList()
    var changed = true
    while (changed) {
        changed = false
        loop@ for (i in list.indices) {
            for (j in i + 1 until list.size) {
                val a = list[i]
                val b = list[j]
                if (close(a.rect, b.rect, lang)) {
                    val first = if (firstIsBefore(a.rect, b.rect, lang)) a else b
                    val second = if (first === a) b else a
                    val r = Rect(a.rect)
                    r.union(b.rect)
                    list[i] = Block(r, first.text + joiner + second.text, 0f, emptyList(), maxOf(a.lineH, b.lineH))
                    list.removeAt(j)
                    changed = true
                    break@loop
                }
            }
        }
    }
    // urutan baca antar balon
    val rtl = lang == 0
    val sorted = list.sortedBy { it.rect.top }
    val rows = ArrayList<MutableList<Block>>()
    for (b in sorted) {
        val row = rows.lastOrNull()
        if (row != null && b.rect.centerY() <= row.minOf { it.rect.bottom }) row.add(b) else rows.add(mutableListOf(b))
    }
    return rows.flatMap { row ->
        if (rtl) row.sortedByDescending { it.rect.right } else row.sortedBy { it.rect.left }
    }
}
