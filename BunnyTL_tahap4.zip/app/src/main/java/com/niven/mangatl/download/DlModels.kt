package com.niven.mangatl

import org.json.JSONObject
import java.util.Locale

/** Satu format yang ditawarkan situs (hasil `yt-dlp --dump-single-json`). */
class DlFormat(
    val id: String,
    val ext: String,
    val vcodec: String,
    val acodec: String,
    val width: Int,
    val height: Int,
    val fps: Int,
    val tbr: Double,
    val size: Long
) {
    /**
     * Facebook (dan beberapa situs lain) memberi format gabungan tanpa info codec/tinggi (vcodec & acodec null).
     * Itu tetap video selama tidak ditandai "none" dan ekstensinya wadah video.
     */
    val hasVideo: Boolean get() = vcodec != "none" &&
        (vcodec.isNotEmpty() || height > 0 || (acodec != "none" && ext.lowercase(Locale.ROOT) in VIDEO_EXT))
    val hasAudio: Boolean get() = acodec != "none"
    val audioOnly: Boolean get() = vcodec == "none" && acodec != "none"

    /** Sisi pendek (1080 untuk 1920x1080 maupun 1080x1920), sama seperti penamaan YouTube. */
    val res: Int get() = if (width > 0 && height > 0) minOf(width, height) else height

    val isAvc: Boolean get() = vcodec.startsWith("avc") || vcodec.startsWith("h264")

    private companion object {
        val VIDEO_EXT = setOf("mp4", "webm", "mkv", "mov", "m4v", "flv", "3gp")
    }

    val codecName: String
        get() = when {
            isAvc -> "H.264"
            vcodec.startsWith("vp09") || vcodec.startsWith("vp9") -> "VP9"
            vcodec.startsWith("av01") -> "AV1"
            vcodec.startsWith("hev") || vcodec.startsWith("hvc") || vcodec.startsWith("h265") -> "H.265"
            vcodec.isEmpty() || vcodec == "none" -> ""
            else -> vcodec.substringBefore('.').uppercase(Locale.ROOT)
        }
}

class DlInfo(
    val title: String,
    val uploader: String,
    val duration: Long,
    val thumbnail: String,
    val url: String,
    val formats: List<DlFormat>,
    /** Metadata musik (kalau situs menyediakan) untuk mencari lirik. */
    val artist: String = "",
    val track: String = "",
    val album: String = "",
    /** Bahasa subtitle buatan manusia yang akan disematkan (maks 6). */
    val subLangs: List<String> = emptyList(),
    /** Bahasa subtitle otomatis (hanya dipakai kalau tidak ada subtitle buatan manusia). */
    val autoLang: String = ""
) {
    val hasSubs: Boolean get() = subLangs.isNotEmpty() || autoLang.isNotEmpty()

    val hasVideo: Boolean get() = formats.any { it.hasVideo }
    val hasAudio: Boolean get() = formats.any { it.audioOnly || (it.hasVideo && it.hasAudio) }
}

/** Satu item playlist (data ringkas dari --flat-playlist). */
class PlEntry(val url: String, val title: String, val duration: Long, val uploader: String)

class DlPlaylist(val title: String, val uploader: String, val entries: List<PlEntry>)

/** Hasil ambil info: satu video, atau satu playlist. */
sealed class DlResult {
    class Single(val info: DlInfo) : DlResult()
    class Playlist(val list: DlPlaylist) : DlResult()
}

object DlInfoParser {
    private fun s(o: JSONObject, k: String) = if (o.isNull(k)) "" else o.optString(k, "")
    private fun i(o: JSONObject, k: String) = if (o.isNull(k)) 0 else o.optInt(k, 0)
    private fun l(o: JSONObject, k: String) = if (o.isNull(k)) 0L else o.optLong(k, 0L)
    private fun keys(o: JSONObject?): List<String> {
        val out = ArrayList<String>()
        val it = o?.keys() ?: return out
        while (it.hasNext()) out += it.next()
        return out
    }

    private fun d(o: JSONObject, k: String) = if (o.isNull(k)) 0.0 else o.optDouble(k, 0.0)

    /** Pintu masuk: tentukan single atau playlist. */
    fun parseResult(json: String, inputUrl: String): DlResult {
        val o = JSONObject(json)
        if (s(o, "_type") != "playlist") return DlResult.Single(parse(json, inputUrl))
        val arr = o.optJSONArray("entries") ?: throw IllegalStateException("Playlist ini kosong.")
        val list = ArrayList<PlEntry>()
        for (n in 0 until arr.length()) {
            val e = arr.optJSONObject(n) ?: continue
            val url = listOf(s(e, "url"), s(e, "webpage_url")).firstOrNull { it.startsWith("http") } ?: continue
            val up = listOf("uploader", "channel").map { s(e, it) }.firstOrNull { it.isNotEmpty() } ?: ""
            list += PlEntry(
                url, s(e, "title").ifEmpty { "Item ${n + 1}" },
                e.optDouble("duration", 0.0).let { if (it.isNaN()) 0L else it.toLong() }, up
            )
        }
        if (list.isEmpty()) throw IllegalStateException("Tidak ada item yang bisa diunduh di playlist ini (mungkin privat atau kosong).")
        val up = listOf("uploader", "channel").map { s(o, it) }.firstOrNull { it.isNotEmpty() } ?: ""
        return DlResult.Playlist(DlPlaylist(s(o, "title").ifEmpty { "Playlist" }, up, list))
    }

    fun parse(json: String, inputUrl: String): DlInfo {
        val o = JSONObject(json)
        val list = ArrayList<DlFormat>()
        val arr = o.optJSONArray("formats")
        if (arr != null) {
            for (n in 0 until arr.length()) {
                val f = arr.optJSONObject(n) ?: continue
                val id = s(f, "format_id")
                if (id.isEmpty()) continue
                val v = s(f, "vcodec")
                val a = s(f, "acodec")
                if (v == "none" && a == "none") continue // storyboard dsb
                list += DlFormat(
                    id, s(f, "ext"), v, a, i(f, "width"), i(f, "height"), i(f, "fps"),
                    d(f, "tbr"), maxOf(l(f, "filesize"), l(f, "filesize_approx"))
                )
            }
        }
        if (list.isEmpty()) throw IllegalStateException("Tidak ada format yang bisa diunduh dari link ini.")
        val uploader = listOf("uploader", "channel", "creator").map { s(o, it) }.firstOrNull { it.isNotEmpty() } ?: ""
        val manual = keys(o.optJSONObject("subtitles")).filter { it != "live_chat" }
        // utamakan Indonesia & Inggris, sisanya urut apa adanya, maksimal 6 supaya menu subtitle pemutar tidak penuh
        val subs = (manual.filter { it.startsWith("id") } + manual.filter { it.startsWith("en") } +
            manual.filter { !it.startsWith("id") && !it.startsWith("en") }).distinct().take(6)
        val auto = keys(o.optJSONObject("automatic_captions"))
        val autoLang = if (subs.isNotEmpty()) "" else
            auto.firstOrNull { it.endsWith("-orig") } ?: auto.firstOrNull { it == "id" } ?: auto.firstOrNull { it == "en" } ?: ""
        return DlInfo(
            title = s(o, "title").ifEmpty { "Tanpa judul" },
            uploader = uploader,
            duration = o.optDouble("duration", 0.0).let { if (it.isNaN()) 0L else it.toLong() },
            thumbnail = s(o, "thumbnail"),
            url = s(o, "webpage_url").ifEmpty { inputUrl },
            formats = list,
            artist = listOf("artist", "creator").map { s(o, it) }.firstOrNull { it.isNotEmpty() } ?: "",
            track = s(o, "track"),
            album = s(o, "album"),
            subLangs = subs,
            autoLang = autoLang
        )
    }
}

/** Satu baris pilihan kualitas video. */
class VideoOpt(val label: String, val detail: String, val formatId: String, val combined: Boolean)

object DlOptions {
    val AUDIO_LABELS = listOf(
        "MP3 · terbaik (dikonversi)",
        "M4A · AAC (tanpa konversi bila ada)",
        "Opus · kualitas asli, tanpa konversi"
    )

    fun sizeText(bytes: Long): String = when {
        bytes <= 0 -> ""
        bytes >= 1024L * 1024 * 1024 -> String.format(Locale.US, "~%.2f GB", bytes / 1073741824.0)
        else -> String.format(Locale.US, "~%.0f MB", bytes / 1048576.0)
    }

    fun duration(sec: Long): String {
        if (sec <= 0) return ""
        val h = sec / 3600
        val m = (sec % 3600) / 60
        val s = sec % 60
        return if (h > 0) String.format(Locale.US, "%d:%02d:%02d", h, m, s) else String.format(Locale.US, "%d:%02d", m, s)
    }

    /**
     * Daftar resolusi yang benar-benar ada di link ini, dari tertinggi ke terendah.
     * compat = true: tiap resolusi utamakan H.264 (jalan di semua pemutar); false: ambil bitrate tertinggi.
     */
    fun video(info: DlInfo, compat: Boolean): List<VideoOpt> {
        val videos = info.formats.filter { it.hasVideo && it.res > 0 }
        val audios = info.formats.filter { it.audioOnly }
        val pool = if (compat) audios.filter { it.ext == "m4a" }.ifEmpty { audios } else audios
        val audioSize = pool.maxByOrNull { maxOf(it.tbr, it.size.toDouble()) }?.size ?: 0L
        val order = compareBy<DlFormat>({ it.tbr }, { it.size })

        data class Row(val res: Int, val fps: Int, val opt: VideoOpt)

        val rows = videos.groupBy { it.res to (it.fps >= 50) }.map { (key, list) ->
            val cand = if (compat) list.filter { it.isAvc }.ifEmpty { list } else list
            val rep = cand.maxWith(order)
            val label = if (key.second) "${key.first}p${rep.fps}" else "${key.first}p"
            val size = rep.size + (if (rep.hasAudio) 0L else audioSize)
            val detail = listOf(rep.codecName, sizeText(size)).filter { it.isNotEmpty() }.joinToString(" · ")
            Row(key.first, if (key.second) rep.fps else 0, VideoOpt(label, detail, rep.id, rep.hasAudio))
        }
        if (rows.isEmpty()) return noResolutionOptions(info)
        return rows.sortedWith(compareByDescending<Row> { it.res }.thenByDescending { it.fps }).map { it.opt }
    }

    /**
     * Situs seperti Facebook kadang hanya memberi format "sd"/"hd" tanpa info resolusi. Tampilkan sebagai
     * pilihan bernama (HD di atas SD) supaya kualitas tetap bisa dipilih, bukan cuma "Terbaik yang tersedia".
     */
    private fun noResolutionOptions(info: DlInfo): List<VideoOpt> {
        fun rank(id: String): Int {
            val l = id.lowercase(Locale.ROOT)
            return when {
                Regex("(^|[^a-z])hd([^a-z]|$)").containsMatchIn(l) -> 2
                Regex("(^|[^a-z])sd([^a-z]|$)").containsMatchIn(l) -> 1
                else -> 0
            }
        }
        fun name(id: String) = when (rank(id)) { 2 -> "HD"; 1 -> "SD"; else -> id }
        val vids = info.formats.filter { it.hasVideo }
            .sortedWith(compareByDescending<DlFormat> { rank(it.id) }.thenByDescending { it.tbr }.thenByDescending { it.size })
        if (vids.size < 2) return emptyList() // satu saja: cukup "Terbaik yang tersedia"
        return vids.distinctBy { it.id }.map { f ->
            VideoOpt(name(f.id), listOf("resolusi tidak diberitahu situs", sizeText(f.size)).filter { it.isNotEmpty() }.joinToString(" · "), f.id, f.hasAudio)
        }
    }

    /** Pemilih format untuk yt-dlp (-f). Video-only digabung dengan audio terbaik. */
    fun selector(opt: VideoOpt, compat: Boolean): String {
        val v = opt.formatId
        return when {
            opt.combined -> v
            compat -> "$v+ba[ext=m4a]/$v+ba/$v"
            else -> "$v+ba/$v"
        }
    }
}
