package com.niven.mangatl

import org.json.JSONObject
import java.util.Locale

/** Satu format yang ditawarkan situs (hasil `yt-dlp --dump-single-json`). */
class DlFormat(
    val id: String,
    val ext: String,
    val vcodec: String,
    val acodec: String,
    val width: Int,
    val height: Int,
    val fps: Int,
    val tbr: Double,
    val size: Long
) {
    val hasVideo: Boolean get() = vcodec != "none" && (vcodec.isNotEmpty() || height > 0)
    val hasAudio: Boolean get() = acodec != "none"
    val audioOnly: Boolean get() = vcodec == "none" && acodec != "none"

    /** Sisi pendek (1080 untuk 1920x1080 maupun 1080x1920), sama seperti penamaan YouTube. */
    val res: Int get() = if (width > 0 && height > 0) minOf(width, height) else height

    val isAvc: Boolean get() = vcodec.startsWith("avc") || vcodec.startsWith("h264")

    val codecName: String
        get() = when {
            isAvc -> "H.264"
            vcodec.startsWith("vp09") || vcodec.startsWith("vp9") -> "VP9"
            vcodec.startsWith("av01") -> "AV1"
            vcodec.startsWith("hev") || vcodec.startsWith("hvc") || vcodec.startsWith("h265") -> "H.265"
            vcodec.isEmpty() || vcodec == "none" -> ""
            else -> vcodec.substringBefore('.').uppercase(Locale.ROOT)
        }
}

class DlInfo(
    val title: String,
    val uploader: String,
    val duration: Long,
    val thumbnail: String,
    val url: String,
    val formats: List<DlFormat>,
    /** Metadata musik (kalau situs menyediakan) untuk mencari lirik. */
    val artist: String = "",
    val track: String = "",
    val album: String = "",
    /** Bahasa subtitle buatan manusia yang akan disematkan (maks 6). */
    val subLangs: List<String> = emptyList(),
    /** Bahasa subtitle otomatis (hanya dipakai kalau tidak ada subtitle buatan manusia). */
    val autoLang: String = ""
) {
    val hasSubs: Boolean get() = subLangs.isNotEmpty() || autoLang.isNotEmpty()

    val hasVideo: Boolean get() = formats.any { it.hasVideo }
    val hasAudio: Boolean get() = formats.any { it.audioOnly || (it.hasVideo && it.hasAudio) }
}

/** Satu item playlist (data ringkas dari --flat-playlist). */
class PlEntry(val url: String, val title: String, val duration: Long, val uploader: String)

class DlPlaylist(val title: String, val uploader: String, val entries: List<PlEntry>)

/** Hasil ambil info: satu video, atau satu playlist. */
sealed class DlResult {
    class Single(val info: DlInfo) : DlResult()
    class Playlist(val list: DlPlaylist) : DlResult()
}

object DlInfoParser {
    private fun s(o: JSONObject, k: String) = if (o.isNull(k)) "" else o.optString(k, "")
    private fun i(o: JSONObject, k: String) = if (o.isNull(k)) 0 else o.optInt(k, 0)
    private fun l(o: JSONObject, k: String) = if (o.isNull(k)) 0L else o.optLong(k, 0L)
    private fun keys(o: JSONObject?): List<String> {
        val out = ArrayList<String>()
        val it = o?.keys() ?: return out
        while (it.hasNext()) out += it.next()
        return out
    }

    private fun d(o: JSONObject, k: String) = if (o.isNull(k)) 0.0 else o.optDouble(k, 0.0)

    /** Pintu masuk: tentukan single atau playlist. */
    fun parseResult(json: String, inputUrl: String): DlResult {
        val o = JSONObject(json)
        if (s(o, "_type") != "playlist") return DlResult.Single(parse(json, inputUrl))
        val arr = o.optJSONArray("entries") ?: throw IllegalStateException("Playlist ini kosong.")
        val list = ArrayList<PlEntry>()
        for (n in 0 until arr.length()) {
            val e = arr.optJSONObject(n) ?: continue
            val url = listOf(s(e, "url"), s(e, "webpage_url")).firstOrNull { it.startsWith("http") } ?: continue
            val up = listOf("uploader", "channel").map { s(e, it) }.firstOrNull { it.isNotEmpty() } ?: ""
            list += PlEntry(
                url, s(e, "title").ifEmpty { "Item ${n + 1}" },
                e.optDouble("duration", 0.0).let { if (it.isNaN()) 0L else it.toLong() }, up
            )
        }
        if (list.isEmpty()) throw IllegalStateException("Tidak ada item yang bisa diunduh di playlist ini (mungkin privat atau kosong).")
        val up = listOf("uploader", "channel").map { s(o, it) }.firstOrNull { it.isNotEmpty() } ?: ""
        return DlResult.Playlist(DlPlaylist(s(o, "title").ifEmpty { "Playlist" }, up, list))
    }

    /**
     * Facebook/Instagram mencantumkan "tbr" yang jauh terlalu tinggi di daftar format (mis. 4.1 Mbps untuk file ~0.96 Mbps),
     * sehingga perkiraan ukuran membengkak ~4x. Bitrate asli ada di parameter "efg" pada link media (base64 JSON, kunci "bitrate").
     */
    private fun efgBitrateKbps(url: String): Double? = runCatching {
        val efg = android.net.Uri.parse(url).getQueryParameter("efg") ?: return@runCatching null
        val raw = efg.replace('-', '+').replace('_', '/')
        val txt = String(android.util.Base64.decode(raw, android.util.Base64.DEFAULT), Charsets.UTF_8)
        val bps = JSONObject(txt).optLong("bitrate", 0L)
        if (bps > 0) bps / 1000.0 else null
    }.getOrNull()

    fun parse(json: String, inputUrl: String): DlInfo {
        val o = JSONObject(json)
        val list = ArrayList<DlFormat>()
        val arr = o.optJSONArray("formats")
        if (arr != null) {
            for (n in 0 until arr.length()) {
                val f = arr.optJSONObject(n) ?: continue
                val id = s(f, "format_id")
                if (id.isEmpty()) continue
                val v = s(f, "vcodec")
                val a = s(f, "acodec")
                if (v == "none" && a == "none") continue // storyboard dsb
                list += DlFormat(
                    id, s(f, "ext"), v, a, i(f, "width"), i(f, "height"), i(f, "fps"),
                    efgBitrateKbps(s(f, "url")) ?: d(f, "tbr"), maxOf(l(f, "filesize"), l(f, "filesize_approx"))
                )
            }
        }
        if (list.isEmpty()) throw IllegalStateException("Tidak ada format yang bisa diunduh dari link ini.")
        val uploader = listOf("uploader", "channel", "creator").map { s(o, it) }.firstOrNull { it.isNotEmpty() } ?: ""
        val manual = keys(o.optJSONObject("subtitles")).filter { it != "live_chat" }
        // utamakan Indonesia & Inggris, sisanya urut apa adanya, maksimal 6 supaya menu subtitle pemutar tidak penuh
        val subs = (manual.filter { it.startsWith("id") } + manual.filter { it.startsWith("en") } +
            manual.filter { !it.startsWith("id") && !it.startsWith("en") }).distinct().take(6)
        val auto = keys(o.optJSONObject("automatic_captions"))
        val autoLang = if (subs.isNotEmpty()) "" else
            auto.firstOrNull { it.endsWith("-orig") } ?: auto.firstOrNull { it == "id" } ?: auto.firstOrNull { it == "en" } ?: ""
        return DlInfo(
            title = s(o, "title").ifEmpty { "Tanpa judul" },
            uploader = uploader,
            duration = o.optDouble("duration", 0.0).let { if (it.isNaN()) 0L else it.toLong() },
            thumbnail = s(o, "thumbnail"),
            url = s(o, "webpage_url").ifEmpty { inputUrl },
            formats = list,
            artist = listOf("artist", "creator").map { s(o, it) }.firstOrNull { it.isNotEmpty() } ?: "",
            track = s(o, "track"),
            album = s(o, "album"),
            subLangs = subs,
            autoLang = autoLang
        )
    }
}

/** Satu baris pilihan kualitas video. [bytes] = perkiraan ukuran total (video + audio), [quality] = teks untuk daftar unduhan. */
class VideoOpt(
    val label: String, val detail: String, val formatId: String, val combined: Boolean,
    val bytes: Long = 0L, val quality: String = ""
)

/** Satu baris pilihan musik: [title] = nama format, [detail] = kualitas (kbps) + ukuran (MB). */
class AudioOpt(val title: String, val detail: String, val bytes: Long, val quality: String)

object DlOptions {
    val AUDIO_LABELS = listOf(
        "MP3 · terbaik (dikonversi)",
        "M4A · AAC (tanpa konversi bila ada)",
        "Opus · kualitas asli, tanpa konversi"
    )
    val AUDIO_FMT = listOf("MP3", "M4A", "OPUS")

    /** Ukuran perkiraan, selalu diawali ~ (angka dari situs pun hanya perkiraan). */
    fun sizeText(bytes: Long): String = when {
        bytes <= 0 -> ""
        bytes >= 1024L * 1024 * 1024 -> String.format(Locale.US, "~%.2f GB", bytes / 1073741824.0)
        else -> String.format(Locale.US, "~%.1f MB", bytes / 1048576.0)
    }

    /** Ukuran pasti (file yang sudah jadi). */
    fun sizeExact(bytes: Long): String = when {
        bytes <= 0 -> ""
        bytes >= 1024L * 1024 * 1024 -> String.format(Locale.US, "%.2f GB", bytes / 1073741824.0)
        bytes >= 1024L * 1024 -> String.format(Locale.US, "%.1f MB", bytes / 1048576.0)
        else -> String.format(Locale.US, "%.0f KB", bytes / 1024.0)
    }

    /** "12.4 / 50.2 MB" (satuan ikut ukuran total). */
    fun progressText(done: Long, total: Long): String {
        if (done <= 0 && total <= 0) return ""
        if (total <= 0) return sizeExact(done)
        val gb = total >= 1024L * 1024 * 1024
        val div = if (gb) 1073741824.0 else 1048576.0
        val fmt = if (gb) "%.2f / %.2f GB" else "%.1f / %.1f MB"
        return String.format(Locale.US, fmt, done.coerceAtMost(total) / div, total / div)
    }

    fun speedText(bytesPerSec: Long): String = when {
        bytesPerSec <= 0 -> ""
        bytesPerSec >= 1024L * 1024 -> String.format(Locale.US, "%.1f MB/s", bytesPerSec / 1048576.0)
        else -> String.format(Locale.US, "%.0f KB/s", bytesPerSec / 1024.0)
    }

    /** Bitrate: 128 kbps, atau 2.4 Mbps untuk video. */
    fun rateText(kbps: Double): String = when {
        kbps <= 0 -> ""
        kbps >= 1000 -> String.format(Locale.US, "%.1f Mbps", kbps / 1000)
        else -> String.format(Locale.US, "%.0f kbps", kbps)
    }

    fun duration(sec: Long): String {
        if (sec <= 0) return ""
        val h = sec / 3600
        val m = (sec % 3600) / 60
        val s = sec % 60
        return if (h > 0) String.format(Locale.US, "%d:%02d:%02d", h, m, s) else String.format(Locale.US, "%d:%02d", m, s)
    }

    /** Jam selesai: "21:34" kalau hari ini, selain itu "23 Nov 21:34". */
    fun clock(ms: Long): String {
        if (ms <= 0) return ""
        val c = java.util.Calendar.getInstance().apply { timeInMillis = ms }
        val n = java.util.Calendar.getInstance()
        val today = c.get(java.util.Calendar.YEAR) == n.get(java.util.Calendar.YEAR) &&
            c.get(java.util.Calendar.DAY_OF_YEAR) == n.get(java.util.Calendar.DAY_OF_YEAR)
        val f = java.text.SimpleDateFormat(if (today) "HH:mm" else "d MMM HH:mm", Locale("id", "ID"))
        return f.format(java.util.Date(ms))
    }

    /** Ukuran satu format: angka dari situs, kalau tak ada dihitung dari bitrate x durasi. */
    fun estBytes(f: DlFormat, durSec: Long): Long = when {
        f.size > 0 -> f.size
        f.tbr > 0 && durSec > 0 -> (f.tbr * 1000.0 / 8.0 * durSec).toLong()
        else -> 0L
    }

    private fun audioCodec(a: String): String = when {
        a.startsWith("mp4a") || a == "aac" -> "AAC"
        a.startsWith("opus") -> "Opus"
        a.startsWith("vorbis") -> "Vorbis"
        a.startsWith("mp3") -> "MP3"
        a.isEmpty() || a == "none" -> ""
        else -> a.substringBefore('.').uppercase(Locale.ROOT)
    }

    /**
     * Pilihan musik. Kualitas (kbps) dan ukuran (MB) ditampilkan terpisah:
     * kbps = seberapa bagus suaranya, MB = durasi x kbps. Info null (playlist) = angka nominal saja.
     */
    fun audio(info: DlInfo?): List<AudioOpt> {
        val dur = info?.duration ?: 0L
        val srcs = info?.formats?.filter { it.audioOnly } ?: emptyList()
        val order = compareBy<DlFormat>({ it.tbr }, { it.size })
        val m4a = srcs.filter { it.ext == "m4a" }.maxWithOrNull(order)
        val opus = srcs.filter { it.ext == "webm" || it.acodec.startsWith("opus") }.maxWithOrNull(order)
        val best = srcs.maxWithOrNull(order)
        fun bytesFor(kbps: Double) = if (dur > 0 && kbps > 0) (kbps * 1000.0 / 8.0 * dur).toLong() else 0L
        fun join(vararg p: String) = p.filter { it.isNotEmpty() }.joinToString(" · ")

        // MP3: VBR kualitas tertinggi (V0) rata-rata sekitar 245 kbps. Kualitas nyata tetap dibatasi sumbernya.
        val mp3Bytes = bytesFor(245.0)
        val mp3 = AudioOpt(
            AUDIO_LABELS[0],
            join("VBR ±245 kbps", sizeText(mp3Bytes), if (best != null) "sumber ${audioCodec(best.acodec)} ${rateText(best.tbr)}".trim() else ""),
            mp3Bytes, "VBR ±245 kbps"
        )
        val m4aOpt = if (m4a != null) {
            val b = estBytes(m4a, dur)
            val q = "AAC ${rateText(m4a.tbr)}".trim()
            AudioOpt(AUDIO_LABELS[1], join(q, sizeText(b), "tanpa konversi"), b, q)
        } else {
            val b = bytesFor(128.0)
            AudioOpt(AUDIO_LABELS[1], join("AAC ±128 kbps", sizeText(b), if (info != null) "AAC asli tidak ada, dikonversi" else "tergantung sumber"), b, "AAC ±128 kbps")
        }
        val opusOpt = if (opus != null) {
            val b = estBytes(opus, dur)
            val q = "Opus ${rateText(opus.tbr)}".trim()
            AudioOpt(AUDIO_LABELS[2], join(q, sizeText(b), "tanpa konversi"), b, q)
        } else {
            val b = bytesFor(130.0)
            AudioOpt(AUDIO_LABELS[2], join("Opus ±130 kbps", sizeText(b), if (info != null) "Opus asli tidak ada, dikonversi" else "tergantung sumber"), b, "Opus ±130 kbps")
        }
        return listOf(mp3, m4aOpt, opusOpt)
    }

    /**
     * Daftar resolusi yang benar-benar ada di link ini, dari tertinggi ke terendah.
     * compat = true: tiap resolusi utamakan H.264 (jalan di semua pemutar); false: ambil bitrate tertinggi.
     * Tiap baris: codec, bitrate total (video + audio), perkiraan ukuran total.
     */
    fun video(info: DlInfo, compat: Boolean): List<VideoOpt> {
        val videos = info.formats.filter { it.hasVideo && it.res > 0 }
        val audios = info.formats.filter { it.audioOnly }
        val pool = if (compat) audios.filter { it.ext == "m4a" }.ifEmpty { audios } else audios
        val order = compareBy<DlFormat>({ it.tbr }, { it.size })
        val bestA = pool.maxWithOrNull(order)
        val audioBytes = bestA?.let { estBytes(it, info.duration) } ?: 0L
        val audioRate = bestA?.tbr ?: 0.0

        data class Row(val res: Int, val fps: Int, val opt: VideoOpt)

        val rows = videos.groupBy { it.res to (it.fps >= 50) }.map { (key, list) ->
            val cand = if (compat) list.filter { it.isAvc }.ifEmpty { list } else list
            val rep = cand.maxWith(order)
            val label = if (key.second) "${key.first}p${rep.fps}" else "${key.first}p"
            val total = estBytes(rep, info.duration) + (if (rep.hasAudio) 0L else audioBytes)
            val rate = rep.tbr + (if (rep.hasAudio) 0.0 else audioRate)
            val codec = rep.codecName + if (compat && !rep.isAvc && rep.codecName.isNotEmpty()) " (bukan H.264)" else ""
            val size = sizeText(total).ifEmpty { "ukuran tidak diketahui" }
            val detail = listOf(codec, rateText(rate), size).filter { it.isNotEmpty() }.joinToString(" · ")
            val quality = listOf(label, rep.codecName).filter { it.isNotEmpty() }.joinToString(" · ")
            Row(key.first, if (key.second) rep.fps else 0, VideoOpt(label, detail, rep.id, rep.hasAudio, total, quality))
        }
        return rows.sortedWith(compareByDescending<Row> { it.res }.thenByDescending { it.fps }).map { it.opt }
    }

    /** Pemilih format untuk yt-dlp (-f). Video-only digabung dengan audio terbaik. */
    fun selector(opt: VideoOpt, compat: Boolean): String {
        val v = opt.formatId
        return when {
            opt.combined -> v
            compat -> "$v+ba[ext=m4a]/$v+ba/$v"
            else -> "$v+ba/$v"
        }
    }
}
