package com.niven.mangatl

import android.content.Context
import android.os.Handler
import androidx.annotation.OptIn
import androidx.media3.common.Format
import androidx.media3.common.MimeTypes
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.DefaultRenderersFactory
import androidx.media3.exoplayer.Renderer
import androidx.media3.exoplayer.audio.AudioRendererEventListener
import androidx.media3.exoplayer.audio.AudioSink
import androidx.media3.exoplayer.audio.DefaultAudioSink
import androidx.media3.exoplayer.audio.DefaultAudioTrackBufferSizeProvider
import androidx.media3.exoplayer.audio.ForwardingAudioSink
import androidx.media3.exoplayer.audio.MediaCodecAudioRenderer
import androidx.media3.exoplayer.metadata.MetadataOutput
import androidx.media3.exoplayer.text.TextOutput
import androidx.media3.exoplayer.video.VideoRendererEventListener
import java.nio.ByteBuffer

/**
 * Memproses PCM lewat DspChain sebelum diteruskan ke DefaultAudioSink. Dipasang di sini
 * (bukan sebagai AudioProcessor) supaya masukan 24-bit / float tidak diturunkan ke 16-bit
 * dulu oleh ExoPlayer, dan agar laju sampel/encoding keluaran bisa berbeda dari sumber.
 */
@OptIn(UnstableApi::class)
class DspAudioSink(inner: AudioSink, private val chain: DspChain) : ForwardingAudioSink(inner) {

    private var active = false
    private var pendingIn: ByteBuffer? = null
    private var pendingOut: ByteBuffer? = null

    override fun configure(inputFormat: Format, specifiedBufferSize: Int, outputChannels: IntArray?) {
        active = false
        pendingIn = null
        pendingOut = null
        if (inputFormat.sampleMimeType == MimeTypes.AUDIO_RAW) {
            // mono dan stereo diproses (mono keluar sebagai stereo dual-mono); selain itu dilewati dengan status jelas
            val o = chain.configure(inputFormat.sampleRate, inputFormat.channelCount, inputFormat.pcmEncoding)
            if (o != null) {
                active = true
                val nf = inputFormat.buildUpon().setSampleRate(o[0]).setPcmEncoding(o[1]).setChannelCount(o[2]).build()
                super.configure(nf, 0, if (inputFormat.channelCount == 2) outputChannels else null)
                return
            }
        } else {
            chain.markUnsupported("aliran bukan PCM mentah (passthrough/terkompresi)")
        }
        super.configure(inputFormat, specifiedBufferSize, outputChannels)
    }

    override fun handleBuffer(buffer: ByteBuffer, presentationTimeUs: Long, encodedAccessUnitCount: Int): Boolean {
        if (!active) return super.handleBuffer(buffer, presentationTimeUs, encodedAccessUnitCount)
        if (pendingIn !== buffer || pendingOut == null) {
            pendingOut = chain.process(buffer)
            pendingIn = buffer
        }
        val out = pendingOut!!
        if (!out.hasRemaining()) {
            pendingIn = null
            pendingOut = null
            return true
        }
        val done = super.handleBuffer(out, presentationTimeUs, encodedAccessUnitCount)
        if (done) {
            pendingIn = null
            pendingOut = null
        }
        return done
    }

    override fun flush() {
        pendingIn = null
        pendingOut = null
        if (active) chain.reset()
        super.flush()
    }

    override fun reset() {
        pendingIn = null
        pendingOut = null
        active = false
        super.reset()
    }
}

/**
 * Renderer untuk pemutar musik: sama seperti Decoders.factory (FFmpeg kalau ada) tetapi
 * sink audionya dibungkus DspAudioSink.
 */
@OptIn(UnstableApi::class)
class DspRenderersFactory(
    private val appCtx: Context,
    private val decoderMode: Int,
    private val chain: DspChain,
    private val bufferSel: Int
) : DefaultRenderersFactory(appCtx) {

    private var sink: AudioSink? = null

    init {
        setExtensionRendererMode(
            when (decoderMode) {
                1 -> EXTENSION_RENDERER_MODE_PREFER
                2 -> EXTENSION_RENDERER_MODE_OFF
                else -> EXTENSION_RENDERER_MODE_ON
            }
        )
        setEnableDecoderFallback(true)
    }

    override fun buildAudioSink(
        context: Context,
        enableFloatOutput: Boolean,
        enableAudioTrackPlaybackParams: Boolean
    ): AudioSink? {
        val b = DefaultAudioSink.Builder(context)
            .setEnableFloatOutput(true)
            .setEnableAudioTrackPlaybackParams(enableAudioTrackPlaybackParams)
        val ms = intArrayOf(0, 10, 20, 40)[bufferSel.coerceIn(0, 3)]
        if (ms > 0) {
            b.setAudioTrackBufferSizeProvider(
                DefaultAudioTrackBufferSizeProvider.Builder()
                    .setMinPcmBufferDurationUs(ms * 1000)
                    .setMaxPcmBufferDurationUs(1_000_000)
                    .setPcmBufferMultiplicationFactor(1)
                    .build()
            )
        }
        val s = DspAudioSink(b.build(), chain)
        sink = s
        return s
    }

    override fun createRenderers(
        eventHandler: Handler,
        videoRendererEventListener: VideoRendererEventListener,
        audioRendererEventListener: AudioRendererEventListener,
        textRendererOutput: TextOutput,
        metadataRendererOutput: MetadataOutput
    ): Array<Renderer> {
        val base = super.createRenderers(
            eventHandler, videoRendererEventListener, audioRendererEventListener,
            textRendererOutput, metadataRendererOutput
        )
        if (decoderMode == 2) return base
        val s = sink ?: return base
        val ff: Renderer? = try {
            Class.forName("io.github.anilbeesetti.nextlib.media3ext.ffdecoder.FfmpegAudioRenderer")
                .getConstructor(Handler::class.java, AudioRendererEventListener::class.java, AudioSink::class.java)
                .newInstance(eventHandler, audioRendererEventListener, s) as Renderer
        } catch (e: Throwable) {
            null
        }
        if (ff == null) return base
        val list = ArrayList<Renderer>()
        for (r in base) list.add(r)
        var idx = list.indexOfFirst { it is MediaCodecAudioRenderer }
        idx = when {
            idx < 0 -> list.size
            decoderMode == 1 -> idx
            else -> idx + 1
        }
        list.add(idx, ff)
        return list.toTypedArray()
    }
}
