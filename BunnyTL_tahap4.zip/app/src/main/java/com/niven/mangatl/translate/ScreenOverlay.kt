package com.niven.mangatl

import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.RectF
import android.graphics.drawable.GradientDrawable
import android.graphics.Typeface
import android.os.Build
import android.os.SystemClock
import android.text.method.ScrollingMovementMethod
import android.util.TypedValue
import android.view.Gravity
import android.view.MotionEvent
import android.view.HapticFeedbackConstants
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import java.util.Locale
import kotlin.math.abs

// Terjemah layar: tampilan overlay (tombol melayang, panel hasil, penyunting area, menu gelembung).
// Fungsi ekstensi dari ScreenService; keadaan dan siklus hidup service tetap di ScreenService.kt.

internal fun ScreenService.addOverlays() {
    val manager = wm!!

    val o = OverlayView(this)
    val olp = WindowManager.LayoutParams(
        WindowManager.LayoutParams.MATCH_PARENT,
        WindowManager.LayoutParams.MATCH_PARENT,
        WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
            WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
            WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
        PixelFormat.TRANSLUCENT
    )
    olp.gravity = Gravity.TOP or Gravity.START
    if (Build.VERSION.SDK_INT >= 28) {
        olp.layoutInDisplayCutoutMode =
            WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
    }

    val f = TextView(this)
    f.text = "TL"
    f.setTextColor(Color.WHITE)
    f.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14f)
    f.typeface = Typeface.DEFAULT_BOLD
    f.gravity = Gravity.CENTER
    f.setBackgroundResource(R.drawable.bubble_fab)
    f.alpha = 0.85f

    val lp = WindowManager.LayoutParams(
        dp(48), dp(48),
        WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
        PixelFormat.TRANSLUCENT
    )
    lp.gravity = Gravity.TOP or Gravity.START
    lp.x = dp(8)
    lp.y = dp(160)

    f.setOnTouchListener(object : View.OnTouchListener {
        var sx = 0f
        var sy = 0f
        var ox = 0
        var oy = 0
        var moved = false
        var longFired = false
        val longRun = Runnable {
            if (!moved) {
                longFired = true
                f.performHapticFeedback(HapticFeedbackConstants.LONG_PRESS)
                showBubbleMenu()
            }
        }

        override fun onTouch(v: View, e: MotionEvent): Boolean {
            when (e.action) {
                MotionEvent.ACTION_DOWN -> {
                    sx = e.rawX
                    sy = e.rawY
                    ox = lp.x
                    oy = lp.y
                    moved = false
                    longFired = false
                    main.postDelayed(longRun, 550)
                    return true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = e.rawX - sx
                    val dy = e.rawY - sy
                    if (!moved && (abs(dx) > dp(8) || abs(dy) > dp(8))) {
                        moved = true
                        main.removeCallbacks(longRun)
                    }
                    if (moved) {
                        lp.x = (ox + dx).toInt()
                        lp.y = (oy + dy).toInt()
                        try {
                            manager.updateViewLayout(v, lp)
                        } catch (_: Throwable) {
                        }
                    }
                    return true
                }
                MotionEvent.ACTION_UP -> {
                    main.removeCallbacks(longRun)
                    if (!moved && !longFired) onTap()
                    return true
                }
                MotionEvent.ACTION_CANCEL -> {
                    main.removeCallbacks(longRun)
                    return true
                }
            }
            return false
        }
    })

    val p = TextView(this)
    p.setTextColor(Color.WHITE)
    p.setTextSize(TypedValue.COMPLEX_UNIT_SP, 16f)
    p.setPadding(dp(14), dp(10), dp(14), dp(10))
    p.setBackgroundResource(R.drawable.panel_bg)
    p.movementMethod = ScrollingMovementMethod()
    p.visibility = View.GONE
    p.setOnClickListener { p.visibility = View.GONE }

    val plp = WindowManager.LayoutParams(
        WindowManager.LayoutParams.WRAP_CONTENT,
        WindowManager.LayoutParams.WRAP_CONTENT,
        WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
        PixelFormat.TRANSLUCENT
    )
    plp.gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL

    manager.addView(o, olp)
    manager.addView(p, plp)
    manager.addView(f, lp)
    ov = o

    fab = f
    panel = p
    panelLp = plp
}

internal fun ScreenService.showPanel(text: String) {
    val p = panel ?: return
    val lp = panelLp ?: return
    val size = realSize()
    val atBottom = prefs().getInt("pos", 0) == 2
    lp.width = (size[0] * 0.9).toInt()
    lp.gravity = (if (atBottom) Gravity.BOTTOM else Gravity.TOP) or Gravity.CENTER_HORIZONTAL
    lp.y = dp(24)
    p.maxHeight = (size[1] * 0.5).toInt()
    p.text = text
    p.scrollTo(0, 0)
    p.visibility = View.VISIBLE
    try {
        wm?.updateViewLayout(p, lp)
    } catch (_: Throwable) {
    }
}

/** Pesan singkat (error / tidak ada teks) yang hilang sendiri. */
internal fun ScreenService.showMessage(msg: String) {
    showPanel(msg)
    finishCapture()
    main.postDelayed({
        if (!busy && ov?.items?.isEmpty() != false) clearResults()
    }, 2500)
}

internal fun ScreenService.fail(msg: String) {
    main.post { showMessage(msg) }
}

internal fun ScreenService.removeEditor() {
    try {
        editor?.let { wm?.removeView(it) }
    } catch (_: Throwable) {
    }
    editor = null
}

internal fun ScreenService.showAreaEditor(which: Int) {
    if (editor != null) return
    val manager = wm ?: return
    val key = if (which == 0) "area_tap" else "area_auto"
    val init = parseArea(prefs().getString(key, "")) ?: RectF(0f, 0.62f, 1f, 1f)
    clearResults()
    val v = AreaEditorView(this, init, if (which == 0) "Area sekali tap" else "Area auto") { rect ->
        main.post {
            removeEditor()
            if (rect != null) {
                val txt = String.format(Locale.US, "%.4f,%.4f,%.4f,%.4f", rect.left, rect.top, rect.right, rect.bottom)
                prefs().edit().putString(key, txt).putInt(key + "_on", 1).apply()
                Toast.makeText(this, "Area disimpan dan diaktifkan.", Toast.LENGTH_SHORT).show()
                lastSig = null
                candSig = null
            }
        }
    }
    val lp = WindowManager.LayoutParams(
        WindowManager.LayoutParams.MATCH_PARENT,
        WindowManager.LayoutParams.MATCH_PARENT,
        WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
            WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
        PixelFormat.TRANSLUCENT
    )
    lp.gravity = Gravity.TOP or Gravity.START
    if (Build.VERSION.SDK_INT >= 28) {
        lp.layoutInDisplayCutoutMode =
            WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
    }
    try {
        manager.addView(v, lp)
        editor = v
    } catch (t: Throwable) {
        Toast.makeText(this, "Gagal membuka pengatur area: ${t.message}", Toast.LENGTH_LONG).show()
    }
}

/**
 * Jendela 1x1 yang menerima kabar "ada sentuhan di luar" (mis. ketukan ke game).
 * Saat game diketuk: hasil lama disembunyikan, lalu layar diperiksa sebentar kemudian.
 * Ini membuat Auto tidak perlu memeriksa layar terus-menerus (jadi tidak berkedip).
 */
internal fun ScreenService.addWatcher() {
    val manager = wm ?: return
    if (watcher != null) return
    val v = object : View(this) {
        override fun onTouchEvent(event: MotionEvent): Boolean {
            if (event.action == MotionEvent.ACTION_OUTSIDE && autoOn && !autoPaused) {
                lastTouchAt = SystemClock.uptimeMillis()
                if (!busy && menu == null && editor == null) {
                    if (overlayShown()) {
                        touchHideAt = lastTouchAt
                        main.post {
                            ov?.alpha = 0f
                            panel?.alpha = 0f
                        }
                    }
                    cap?.removeCallbacks(autoRun)
                    cap?.removeCallbacks(autoTouchRun)
                    cap?.postDelayed(autoTouchRun, 350)
                }
            }
            return false
        }
    }
    val lp = WindowManager.LayoutParams(
        1, 1,
        WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
            WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
            WindowManager.LayoutParams.FLAG_WATCH_OUTSIDE_TOUCH,
        PixelFormat.TRANSLUCENT
    )
    lp.gravity = Gravity.TOP or Gravity.START
    try {
        manager.addView(v, lp)
        watcher = v
    } catch (_: Throwable) {
    }
}

internal fun ScreenService.showBubbleMenu() {
    if (menu != null || editor != null) return
    val manager = wm ?: return
    val cur = prefs().getInt("smode", 1).coerceIn(0, 2)

    val root = FrameLayout(this)
    root.setBackgroundColor(0x66000000)
    root.setOnClickListener { removeBubbleMenu() }

    val card = LinearLayout(this)
    card.orientation = LinearLayout.VERTICAL
    card.setPadding(dp(8), dp(8), dp(8), dp(8))
    card.isClickable = true
    card.background = GradientDrawable().apply {
        setColor(0xFF2B2930.toInt())
        cornerRadius = dp(16).toFloat()
    }

    fun label(text: String) {
        val t = TextView(this)
        t.text = text
        t.setTextColor(0xFFB4B4B8.toInt())
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f)
        t.setPadding(dp(14), dp(8), dp(14), dp(4))
        card.addView(t, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
    }

    fun item(text: String, selected: Boolean, dismiss: Boolean = true, action: () -> Unit): TextView {
        val t = TextView(this)
        t.text = text
        t.setTextColor(Color.WHITE)
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, 15f)
        t.setPadding(dp(14), dp(12), dp(14), dp(12))
        if (selected) {
            t.background = GradientDrawable().apply {
                setColor(0xFF3A3A3E.toInt())
                cornerRadius = dp(10).toFloat()
            }
        }
        t.setOnClickListener {
            if (dismiss) removeBubbleMenu()
            action()
        }
        card.addView(t, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        return t
    }

    label("Mode terjemah layar")
    val names = listOf("Sekali tap", "Tap berurutan", "Auto")
    names.forEachIndexed { i, n ->
        item((if (i == cur) "\u2713  " else "     ") + n, i == cur) {
            prefs().edit().putInt("smode", i).apply()
            Toast.makeText(this, "Mode: $n", Toast.LENGTH_SHORT).show()
        }
    }
    label("Area")
    item("Atur kotak area (sekali tap / berurutan)", false) { main.post { showAreaEditor(0) } }
    item("Atur kotak area (auto)", false) { main.post { showAreaEditor(1) } }
    label("Lainnya")
    // Dua langkah supaya tidak kepencet: ketukan pertama hanya meminta konfirmasi.
    var armed = false
    val stopItem = item("Hentikan layanan", false, false) { }
    stopItem.setOnClickListener {
        if (!armed) {
            armed = true
            stopItem.text = "Yakin? Ketuk lagi untuk menghentikan"
            stopItem.setTextColor(0xFFFF8A80.toInt())
        } else {
            removeBubbleMenu()
            stopSelf()
        }
    }
    item("Tutup menu", false) { }

    root.addView(card, FrameLayout.LayoutParams(dp(300), ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.CENTER))

    val lp = WindowManager.LayoutParams(
        WindowManager.LayoutParams.MATCH_PARENT,
        WindowManager.LayoutParams.MATCH_PARENT,
        WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
            WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
        PixelFormat.TRANSLUCENT
    )
    lp.gravity = Gravity.TOP or Gravity.START
    if (Build.VERSION.SDK_INT >= 28) {
        lp.layoutInDisplayCutoutMode =
            WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
    }
    try {
        manager.addView(root, lp)
        menu = root
    } catch (t: Throwable) {
        Toast.makeText(this, "Gagal membuka menu: ${t.message}", Toast.LENGTH_LONG).show()
    }
}

internal fun ScreenService.removeBubbleMenu() {
    try {
        menu?.let { wm?.removeView(it) }
    } catch (_: Throwable) {
    }
    menu = null
}

internal fun ScreenService.restoreOverlay() {
    main.post {
        ov?.alpha = 1f
        panel?.alpha = 1f
    }
}
