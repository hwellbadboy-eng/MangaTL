package com.niven.mangatl

import android.app.Activity
import android.app.ActivityManager
import android.app.ApplicationExitInfo
import android.content.Context
import android.os.Build
import android.widget.Toast
import java.io.File

/**
 * Penangkap jejak ANR ("BunnyTL tidak menanggapi"). Android menyimpan jejak thread saat app dimatikan karena ANR;
 * di sini jejak terakhir disalin ke file supaya bisa dikirim: <folder data app>/files/anr_trace.txt
 */
object Diag {
    fun saveLastAnr(act: Activity) {
        if (Build.VERSION.SDK_INT < 30) return
        Thread {
            try {
                val am = act.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
                val e = am.getHistoricalProcessExitReasons(act.packageName, 0, 8)
                    .firstOrNull { it.reason == ApplicationExitInfo.REASON_ANR } ?: return@Thread
                val sp = act.getSharedPreferences("mangatl", Context.MODE_PRIVATE)
                if (sp.getLong("anr_seen", 0L) == e.timestamp) return@Thread
                val dir = act.getExternalFilesDir(null) ?: act.filesDir
                val f = File(dir, "anr_trace.txt")
                var txt = e.traceInputStream?.bufferedReader()?.use { it.readText() } ?: "(tidak ada jejak)"
                if (txt.length > 400_000) txt = txt.substring(0, 400_000)
                f.writeText("waktu=${e.timestamp}\n${e.description}\n\n$txt")
                sp.edit().putLong("anr_seen", e.timestamp).apply()
                act.runOnUiThread {
                    Toast.makeText(act, "Jejak ANR disimpan: ${f.absolutePath}", Toast.LENGTH_LONG).show()
                }
            } catch (_: Throwable) {
            }
        }.start()
    }
}
