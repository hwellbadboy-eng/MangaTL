package com.niven.mangatl

// Layar Chat: model pesan. Balonnya digambar oleh assets/chat/chat.html.

internal class Msg(val isUser: Boolean, var text: String) {
    /** Penanda balon di halaman chat. */
    val id: Int = nextId++

    private companion object {
        var nextId = 1
    }
}
