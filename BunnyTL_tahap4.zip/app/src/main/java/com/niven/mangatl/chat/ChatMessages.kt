package com.niven.mangatl

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.view.Gravity
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.TextView
import android.widget.Toast
import androidx.recyclerview.widget.RecyclerView

// Layar Chat: model pesan (Msg) dan adapter daftar chat (MsgAdapter).

internal class Msg(val isUser: Boolean, var text: String)

internal class MsgAdapter(
    private val items: List<Msg>,
    private val onTap: (Msg) -> Unit
) : RecyclerView.Adapter<MsgAdapter.VH>() {

    class VH(v: View) : RecyclerView.ViewHolder(v) {
        val bubble: TextView = v.findViewById(R.id.bubble)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val v = LayoutInflater.from(parent.context).inflate(R.layout.item_msg, parent, false)
        return VH(v)
    }

    override fun getItemCount(): Int = items.size

    override fun onBindViewHolder(holder: VH, position: Int) {
        val m = items[position]
        val b = holder.bubble
        val lp = b.layoutParams as FrameLayout.LayoutParams
        if (m.isUser) {
            lp.gravity = Gravity.END
            b.setBackgroundResource(R.drawable.bubble_user)
            b.setTextColor(0xFF000000.toInt())
            b.text = m.text
        } else {
            lp.gravity = Gravity.START
            b.setBackgroundResource(R.drawable.bubble_ai)
            b.setTextColor(0xFFEDEDED.toInt())
            b.text = if (m.text.isEmpty()) "..." else TextUtil.md(m.text)
        }
        b.layoutParams = lp
        b.setOnClickListener { if (!m.isUser && m.text.isNotBlank()) onTap(m) }
        b.setOnLongClickListener {
            val cm = b.context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            cm.setPrimaryClip(ClipData.newPlainText("chat", m.text))
            Toast.makeText(b.context, "Disalin", Toast.LENGTH_SHORT).show()
            true
        }
    }
}
