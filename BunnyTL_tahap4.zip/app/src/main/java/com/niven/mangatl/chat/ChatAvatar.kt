package com.niven.mangatl

import android.graphics.Rect
import android.widget.LinearLayout
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.os.SystemClock
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.TextView
import android.widget.SeekBar
import android.widget.Toast
import kotlin.math.roundToInt
import androidx.appcompat.app.AlertDialog

// Layar Chat: avatar (buat/lepas model, menu, posisi depan/belakang, tata letak body, geser/zoom, sentuh).
// Fungsi ekstensi dari ChatActivity; keadaan dan siklus hidup layar tetap di ChatActivity.kt.

internal fun ChatActivity.setupAvatar() {
    rootFrame = findViewById(R.id.rootFrame)
    bgHost = findViewById(R.id.bgHost)
    frontHost = findViewById(R.id.frontHost)
    body = findViewById(R.id.body)
    inputBar = findViewById(R.id.inputBar)
    chatRoot = findViewById(R.id.chatRoot)
    chipRow = findViewById(R.id.chipRow)

    avatarWanted = prefs().getBoolean("avatar_on", true)
    avatarFront = prefs().getBoolean("avatar_front", false)
    cfg = loadCfg(prefs().getString("avatar_model", "avatar"))
    // Decode tekstur di thread latar sekarang juga, supaya siap saat layar GL dibuat.
    if (avatarWanted) AvatarTex.prefetch(this, cfg.texturePaths())

    // Ketuk judul "Chat AI" = tampil/sembunyikan avatar. Tahan lama = menu (model, posisi, ekspresi).
    val title = findViewById<View>(R.id.tvTitle)
    title.setOnClickListener {
        // Sembunyi/tampil avatar butuh KETUK BERUNTUN (TITLE_TAPS kali) supaya tidak mudah kepencet.
        val now = SystemClock.uptimeMillis()
        if (now - lastTitleTap > 450L) titleTaps = 0
        lastTitleTap = now
        if (++titleTaps >= ChatActivity.TITLE_TAPS) {
            titleTaps = 0
            toggleAvatar()
        }
    }
    title.setOnLongClickListener {
        showAvatarMenu()
        true
    }
    // Tata letak body (panggung / garis pudar chat) dihitung ulang tiap ukuran berubah.
    rootFrame.addOnLayoutChangeListener { _, _, _, _, _, _, _, _, _ -> layoutBody() }
    inputBar.addOnLayoutChangeListener { _, _, _, _, _, _, _, _, _ -> layoutBody() }
    rootFrame.pokeFilter = { rx, ry -> pokeAllowed(rx, ry) }
    // Keyboard muncul = avatar menyingkir sementara supaya daftar chat tetap lega.
    val decor = window.decorView
    decor.viewTreeObserver.addOnGlobalLayoutListener {
        val r = Rect()
        decor.getWindowVisibleDisplayFrame(r)
        val full = decor.rootView.height
        val up = full > 0 && (full - r.bottom) > full * 0.15f
        if (up != keyboardUp) {
            keyboardUp = up
            applyAvatar()
        }
    }
    applyAvatar()
    // Animasi masuk (Fx.enter) menggeser kolom input ke atas selama ~0,7 dtk tanpa mengubah ukuran,
    // jadi posisi lubang avatar diperbarui terus selama itu supaya pas dengan kolom input.
    val t0 = android.os.SystemClock.uptimeMillis()
    val follow = object : Runnable {
        override fun run() {
            updateHoles()
            if (android.os.SystemClock.uptimeMillis() - t0 < 1100L) handler.postDelayed(this, 16L)
        }
    }
    handler.post(follow)
}

internal fun ChatActivity.toggleAvatar() {
    avatarWanted = !avatarWanted
    prefs().edit().putBoolean("avatar_on", avatarWanted).apply()
    applyAvatar()
    Toast.makeText(this, if (avatarWanted) "Avatar tampil" else "Avatar disembunyikan", Toast.LENGTH_SHORT).show()
}

/** Buat tampilan GL untuk model aktif dan pasang di tempat yang sesuai (belakang chat / depan chat). */
internal fun ChatActivity.createAvatar() {
    val front = avatarFront
    val v = AvatarView(this, cfg, front)
    v.anim.levelSource = { Voice.mouthLevel() }
    v.onError = { msg ->
        if (!avatarErrorShown) {
            avatarErrorShown = true
            Toast.makeText(this, "Avatar gagal dimuat: $msg", Toast.LENGTH_LONG).show()
        }
    }
    val lp = FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
    if (front) frontHost.addView(v, lp) else bgHost.addView(v, lp)
    avatar = v
    // Di depan chat: tahan lama badan avatar = geser bebas. Posisi terakhir diingat per model.
    rootFrame.target = v
    rootFrame.dragEnabled = front
    // Zoom dua jari (depan & belakang chat) dan geser (hanya depan chat). Posisi & ukuran diingat per model dan per mode.
    val tag = if (front) "f" else "b"
    val mid = cfg.id
    v.setUserScale(prefs().getFloat("avatar_scale_${mid}_$tag", 1f))
    v.setDrag(prefs().getFloat("avatar_dx_${mid}_$tag", 0f), prefs().getFloat("avatar_dy_${mid}_$tag", 0f))
    rootFrame.onGestureEnd = { x, y, sc ->
        prefs().edit()
            .putFloat("avatar_scale_${mid}_$tag", sc)
            .putFloat("avatar_dx_${mid}_$tag", x)
            .putFloat("avatar_dy_${mid}_$tag", y)
            .apply()
    }
    AvatarTex.prefetch(this, cfg.texturePaths())
    if (uiActive) v.onResume()
}

/** Hancurkan tampilan GL (konteks + tekstur ikut lepas dari memori GPU). */
internal fun ChatActivity.destroyAvatar() {
    val k = avatar ?: return
    rootFrame.target = null
    lastHoles = FloatArray(0)
    k.onPause()
    (k.parent as? ViewGroup)?.removeView(k)
    avatar = null
    AvatarTex.prefetch(this, emptyList())   // buang decode yang menggantung
}

internal fun ChatActivity.switchModel(id: String) {
    if (id == cfg.id) return
    prefs().edit().putString("avatar_model", id).apply()
    destroyAvatar()
    cfg = loadCfg(id)
    avatarErrorShown = false
    if (!avatarWanted) {
        avatarWanted = true
        prefs().edit().putBoolean("avatar_on", true).apply()
    }
    applyAvatar()
    Toast.makeText(this, cfg.name, Toast.LENGTH_SHORT).show()
}

internal fun ChatActivity.toggleFront() {
    avatarFront = !avatarFront
    prefs().edit().putBoolean("avatar_front", avatarFront).apply()
    destroyAvatar()
    applyAvatar()
    Toast.makeText(
        this,
        if (avatarFront) "Avatar di depan chat. Tahan lama badan avatar untuk menggesernya" else "Avatar di belakang chat",
        Toast.LENGTH_LONG
    ).show()
}

internal fun ChatActivity.showAvatarMenu() {
    val items = ArrayList<String>()
    val acts = ArrayList<() -> Unit>()
    val models = ModelCfg.list(this)
    if (models.size > 1) {   // pilihan model baru muncul kalau ada lebih dari satu model di index.json
        for ((id, name) in models) {
            items.add((if (id == cfg.id) "●  " else "○  ") + name)
            acts.add { switchModel(id) }
        }
    }
    items.add(if (avatarFront) "Posisi: di depan chat  →  pindah ke belakang" else "Posisi: di belakang chat  →  majukan ke depan")
    acts.add { toggleFront() }
    if (avatar != null) {
        items.add(if (avatarFront) "Kembalikan posisi & ukuran avatar" else "Kembalikan ukuran avatar")
        acts.add {
            val tag = if (avatarFront) "f" else "b"
            avatar?.setUserScale(1f)
            avatar?.setDrag(0f, 0f)
            prefs().edit().remove("avatar_scale_${cfg.id}_$tag").remove("avatar_dx_${cfg.id}_$tag").remove("avatar_dy_${cfg.id}_$tag").apply()
        }
    }
    if (!avatarFront && avatarWanted) {
        items.add("Batas pudar chat…")
        acts.add { showFadeDialog() }
    }
    if (cfg.expressions.isNotEmpty() && avatar != null) {
        items.add("Ekspresi…")
        acts.add { showExprDialog() }
    }
    items.add(if (avatarWanted) "Sembunyikan avatar" else "Tampilkan avatar")
    acts.add { toggleAvatar() }
    AlertDialog.Builder(this)
        .setTitle("Avatar")
        .setItems(items.toTypedArray()) { _, i -> acts[i]() }
        .show()
}

internal fun ChatActivity.showExprDialog() {
    val k = avatar ?: return
    val keys = cfg.expressions.keys.toList()
    val checked = BooleanArray(keys.size) { k.anim.isExprHeld(keys[it]) }
    AlertDialog.Builder(this)
        .setTitle("Ekspresi (ditahan sampai dimatikan)")
        .setMultiChoiceItems(keys.map { Emotion.label(it) }.toTypedArray(), checked) { _, i, on ->
            k.anim.setExprHold(keys[i], on)
        }
        .setPositiveButton("Selesai", null)
        .show()
}

internal fun ChatActivity.applyAvatar() {
    if (avatarWanted && avatar == null) createAvatar()
    if (!avatarWanted && avatar != null) destroyAvatar()

    val front = avatarFront

    // Avatar TETAP tampil saat keyboard muncul. Yang disembunyikan: bubble chat (supaya avatar kelihatan penuh)
    // dan tombol di kanan atas. Kalau avatar dimatikan, chat tetap tampil seperti biasa.
    bgHost.visibility = if (avatarWanted && !front) View.VISIBLE else View.GONE
    frontHost.visibility = if (avatarWanted && front) View.VISIBLE else View.GONE
    chipRow.visibility = if (keyboardUp) View.GONE else View.VISIBLE
    list.visibility = if (keyboardUp && avatarWanted) View.INVISIBLE else View.VISIBLE
    layoutBody()
}

/**
 * Memilih mode tata letak body (hitungannya dikerjakan BodyLayout dalam satu putaran ukur):
 *  - avatar DI BELAKANG chat: daftar chat mulai di garis cfg.chatTop dan memudar menghilang di garis itu
 *  - avatar DI DEPAN chat, tanpa avatar, atau keyboard muncul: daftar chat langsung di bawah header dan tombol
 */
internal fun ChatActivity.layoutBody() {
    if (rootFrame.height <= 0) return
    val d = resources.displayMetrics.density
    // Tinggi layar tanpa keyboard (nilai terbesar). Dipakai agar avatar tidak ikut mengecil / terdorong saat keyboard muncul.
    lastFullRootH = maxOf(lastFullRootH, rootFrame.height)
    if (body.height > 0) lastFullBodyH = maxOf(lastFullBodyH, body.height)

    val front = avatarFront
    val avatarOn = avatarWanted

    body.gapPx = (4 * d).toInt()
    body.bleedPx = chatRoot.paddingLeft
    body.topOffsetPx = chatRoot.paddingTop
    body.lineAbsPx = lastFullRootH * chatTopFrac()
    body.virtualH = lastFullBodyH
    body.mode = when {
        avatarOn && !front -> BodyLayout.Mode.FULL      // avatar di belakang chat: chat memudar di garis
        avatarOn -> BodyLayout.Mode.TOP                 // avatar di depan chat: chat penuh sampai ke atas
        else -> BodyLayout.Mode.PLAIN
    }

    (list as FadeRecyclerView).setFadeTop(if (avatarOn && !front) chatFadeDp() * d else 0f)

    // Avatar digambar seukuran layar penuh TANPA keyboard dan menempel di atas.
    avatar?.setVirtualHeight(lastFullRootH)

    // Di depan chat: avatar menjulur sampai dasar layar (tanpa bar hitam). Kolom input & Mic dilubangi
    // dari gambar avatar (lihat updateHoles), jadi tetap kelihatan dan bisa dipakai.
    val flp = frontHost.layoutParams as FrameLayout.LayoutParams
    if (flp.bottomMargin != 0) {
        flp.bottomMargin = 0
        frontHost.layoutParams = flp
    }
    updateHoles()
}

/** Dialog dua slider: posisi garis tempat chat mulai memudar, dan panjang pudarnya. Berubah langsung saat digeser. */
internal fun ChatActivity.showFadeDialog() {
    val d = resources.displayMetrics.density
    val pad = (20 * d).toInt()
    val col = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(pad, pad / 2, pad, 0)
    }
    val posLbl = TextView(this)
    val fadeLbl = TextView(this)
    val posBar = SeekBar(this).apply {
        max = 85
        progress = (chatTopFrac() * 100f).roundToInt().coerceIn(0, 85)
    }
    val fadeBar = SeekBar(this).apply {
        max = 300
        progress = chatFadeDp().roundToInt().coerceIn(0, 300)
    }
    fun upd() {
        posLbl.text = "Posisi batas: ${posBar.progress}% dari atas layar"
        fadeLbl.text = "Panjang pudar: ${fadeBar.progress} dp" + if (fadeBar.progress == 0) " (tanpa pudar)" else ""
    }
    val ls = object : SeekBar.OnSeekBarChangeListener {
        override fun onProgressChanged(sb: SeekBar?, p: Int, fromUser: Boolean) {
            upd()
            if (!fromUser) return
            prefs().edit()
                .putFloat("chat_top_${cfg.id}", posBar.progress / 100f)
                .putFloat("chat_fade_${cfg.id}", fadeBar.progress.toFloat())
                .apply()
            layoutBody()
        }
        override fun onStartTrackingTouch(sb: SeekBar?) {}
        override fun onStopTrackingTouch(sb: SeekBar?) {}
    }
    posBar.setOnSeekBarChangeListener(ls)
    fadeBar.setOnSeekBarChangeListener(ls)
    upd()
    col.addView(posLbl)
    col.addView(posBar)
    col.addView(fadeLbl.also { it.setPadding(0, pad / 2, 0, 0) })
    col.addView(fadeBar)
    val dlg = AlertDialog.Builder(this)
        .setTitle("Batas pudar chat")
        .setView(col)
        .setPositiveButton("Selesai", null)
        .setNeutralButton("Bawaan") { _, _ ->
            prefs().edit().remove("chat_top_${cfg.id}").remove("chat_fade_${cfg.id}").apply()
            layoutBody()
        }
        .create()
    // Latar tidak digelapkan dan dialog di bawah, supaya pergeseran garis pudar langsung kelihatan.
    dlg.window?.apply {
        clearFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND)
        setGravity(Gravity.BOTTOM)
    }
    dlg.show()
}

internal fun ChatActivity.hitScreen(v: View, rx: Float, ry: Float): Boolean {
    if (!v.isShown) return false
    val l = IntArray(2)
    v.getLocationOnScreen(l)
    return rx >= l[0] && rx <= l[0] + v.width && ry >= l[1] && ry <= l[1] + v.height
}

/** Reaksi sentuh avatar tidak boleh ikut terpicu saat jari mengetuk tombol, kolom input, atau bubble chat (mode belakang). */
internal fun ChatActivity.pokeAllowed(rx: Float, ry: Float): Boolean {
    if (avatarFront) return true
    if (hitScreen(inputBar, rx, ry) || hitScreen(chipRow, rx, ry) || hitScreen(findViewById(R.id.chatHeader), rx, ry)) return false
    if (hitScreen(list, rx, ry)) {
        val l = IntArray(2)
        list.getLocationOnScreen(l)
        return list.findChildViewUnder(rx - l[0], ry - l[1]) == null
    }
    return true
}
