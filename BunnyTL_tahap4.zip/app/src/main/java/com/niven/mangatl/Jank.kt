package com.niven.mangatl

import android.app.Activity
import android.content.ContentValues
import android.content.Context
import android.net.Uri
import android.os.Build
import android.os.Debug
import android.os.Environment
import android.os.SystemClock
import android.provider.MediaStore
import android.util.Log
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicBoolean

/**
 * Indikator SEMENTARA untuk melacak avatar yang kadang melompat / tersentak.
 * Setiap ada keterlambatan: dicatat ke logcat (tag "Jank"), ditampilkan sebagai teks kuning di layar 3 detik,
 * dan DISIMPAN OTOMATIS ke satu file teks di folder Download (maks 3 detik setelah kejadian, jadi tidak perlu ketuk apa-apa).
 * Setelah penyebabnya ketemu: set ON = false atau hapus file ini.
 *
 * Arti tiap baris:
 *   tick      selang antar tick() avatar di main thread > TH_MS  (main thread telat / sibuk)
 *   tickBody  isi tick() sendiri lambat                         (VisTap.read dkk)
 *   draw      selang antar frame render > TH_MS                 (thread GL telat)
 *   glDraw    onDrawFrame() sendiri lambat                      (beban gambar Live2D)
 *   glSwap    eglSwapBuffers() menunggu lama                    (GPU / compositor)
 *   gc+N      jumlah GC ART sejak snapshot terakhir (-1 = tidak terbaca)
 */
object Jank {
    const val ON = true
    const val TH_MS = 80L

    @Volatile private var muteUntil = 0L
    @Volatile private var gcSnap = -1L
    @Volatile private var count = 0
    private val fmt = SimpleDateFormat("HH:mm:ss.SSS", Locale.US)
    private val recent = ArrayList<Pair<Long, String>>()
    private val all = ArrayList<String>()   // semua kejadian (maks 3000 baris)

    // ---- penyimpanan file otomatis ----
    private var appCtx: Context? = null
    private var hz = 0f
    private var sessionName = ""
    private var sessionUri: Uri? = null
    private val io = Executors.newSingleThreadScheduledExecutor { r -> Thread(r, "jank-io").apply { isDaemon = true } }
    private val pending = AtomicBoolean(false)

    /** Dipanggil sekali dari MikuAvatar.attach(). Menentukan nama file sesi ini. */
    @Suppress("DEPRECATION")
    fun init(act: Activity) {
        if (appCtx != null) return
        appCtx = act.applicationContext
        hz = try {
            act.windowManager.defaultDisplay.refreshRate
        } catch (_: Throwable) {
            0f
        }
        sessionName = "jank_" + SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date()) + ".txt"
    }

    fun fileName(): String = sessionName

    private fun gc(): Long = try {
        Debug.getRuntimeStat("art.gc.gc-count").toLong()
    } catch (_: Throwable) {
        -1L
    }

    /** Dipanggil berkala supaya "gc+N" berarti GC di jendela waktu pendek sebelum kejadian. */
    fun snap() {
        gcSnap = gc()
    }

    /** Abaikan laporan sesaat (mis. habis resume, selang frame memang panjang). */
    fun mute(ms: Long) {
        muteUntil = SystemClock.uptimeMillis() + ms
    }

    fun report(kind: String, ms: Long) {
        if (!ON) return
        val now = SystemClock.uptimeMillis()
        if (now < muteUntil) return
        val g = gc()
        val dg = if (g >= 0L && gcSnap >= 0L) g - gcSnap else -1L
        gcSnap = g
        count++
        val t = synchronized(fmt) { fmt.format(Date()) }
        val s = "$t $kind ${ms}ms gc+$dg #$count"
        Log.w("Jank", s)
        synchronized(recent) {
            recent.add((now + 3000L) to s)
            while (recent.size > 3) recent.removeAt(0)
        }
        synchronized(all) {
            all.add(s)
            if (all.size > 3000) all.removeAt(0)
        }
        scheduleSave()
    }

    fun total(): Int = count

    /** Teks yang sedang ditampilkan (baris yang belum kedaluwarsa). */
    fun text(now: Long): String = synchronized(recent) {
        recent.removeAll { it.first < now }
        recent.joinToString("\n") { it.second }
    }

    /** Simpan otomatis: banyak kejadian berdekatan digabung jadi satu penulisan, 3 detik setelah kejadian pertama. */
    private fun scheduleSave() {
        if (appCtx == null) return
        if (pending.compareAndSet(false, true)) {
            io.schedule({
                pending.set(false)
                writeSession()
            }, 3L, TimeUnit.SECONDS)
        }
    }

    /** Simpan sekarang juga (dipanggil saat app di-pause). Jalan di thread terpisah. */
    fun flush() {
        if (!ON || appCtx == null || count == 0) return
        io.execute { writeSession() }
    }

    /** Simpan sekarang juga di thread pemanggil (untuk ketukan manual). Mengembalikan keterangan lokasi. */
    fun saveNow(): String = writeSession()

    @Synchronized
    private fun writeSession(): String {
        val ctx = appCtx ?: return "belum siap"
        val head = "Jank log | ${Build.MANUFACTURER} ${Build.MODEL} | Android ${Build.VERSION.SDK_INT} | layar ${hz}Hz | " +
            "tick/draw > ${TH_MS}ms, total $count kejadian\n" +
            "format: jam kategori selang gc+N(jumlah GC sejak snapshot) #urutan\n"
        val body = synchronized(all) { all.joinToString("\n") }
        val text = head + (if (body.isEmpty()) "(belum ada kejadian)" else body) + "\n"
        return try {
            if (Build.VERSION.SDK_INT >= 29) {
                var uri = sessionUri
                if (uri == null) {
                    val cv = ContentValues()
                    cv.put(MediaStore.Downloads.DISPLAY_NAME, sessionName)
                    cv.put(MediaStore.Downloads.MIME_TYPE, "text/plain")
                    cv.put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS)
                    uri = ctx.contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, cv)
                        ?: return "gagal membuat file"
                    sessionUri = uri
                }
                ctx.contentResolver.openOutputStream(uri, "wt")?.use { it.write(text.toByteArray()) }
                "Tersimpan: Download/$sessionName"
            } else {
                val f = File(ctx.getExternalFilesDir(null), sessionName)
                f.writeText(text)
                "Tersimpan: ${f.absolutePath}"
            }
        } catch (t: Throwable) {
            "Gagal menyimpan: ${t.message}"
        }
    }
}
