package com.niven.mangatl

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.View
import android.widget.EditText
import android.widget.TextView
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/** Isi satu folder video: thumbnail, durasi, ukuran, progres tontonan, urutkan, pengaturan. */
class VideoListActivity : MediaActivity() {

    override val kind = 2
    override fun deniedView(): TextView = tvEmpty

    private lateinit var adapter: RowAdapter
    private lateinit var etSearch: EditText
    private lateinit var tvEmpty: TextView
    private var videos: List<Library.Video> = emptyList()
    private var loaded = false
    private var sortMode = 2
    private var bucket = 0L

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_list)
        Fx.enter(this)
        bucket = intent.getLongExtra("bucket", 0L)
        findViewById<TextView>(R.id.tvTitle).text = intent.getStringExtra("name") ?: "Video"
        findViewById<View>(R.id.ibOpen).visibility = View.GONE
        sortMode = Prefs.int(this, "sort_vlist", 2)

        findViewById<View>(R.id.ibSort).setOnClickListener {
            Ui.sortDialog(this, Ui.SORT_VIDEO, sortMode) {
                sortMode = it
                Prefs.setInt(this, "sort_vlist", it)
                refresh()
            }
        }
        findViewById<View>(R.id.ibSettings).setOnClickListener {
            VideoSettings.show(this) { refresh() }
        }

        etSearch = findViewById(R.id.etSearch)
        etSearch.hint = "Cari video"
        tvEmpty = findViewById(R.id.tvEmpty)
        adapter = RowAdapter(lifecycleScope)
        findViewById<RecyclerView>(R.id.list).apply {
            layoutManager = LinearLayoutManager(this@VideoListActivity)
            adapter = this@VideoListActivity.adapter
        }
        etSearch.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun afterTextChanged(s: Editable?) = refresh()
        })
        ensureMedia()
    }

    override fun onStart() {
        super.onStart()
        refresh() // perbarui bilah progres setelah balik dari pemutar
    }

    override fun onMediaReady() {
        tvEmpty.text = "Memuat..."
        tvEmpty.visibility = View.VISIBLE
        lifecycleScope.launch {
            videos = withContext(Dispatchers.IO) { Library.videos(this@VideoListActivity, bucket) }
            loaded = true
            refresh()
        }
    }

    private fun videoMenu(v: Library.Video) {
        Sheet.menu(
            this, v.title, Library.sizeStr(v.size) + "  \u2022  " + Library.fmt(v.durationMs),
            listOf(
                Sheet.Item("Pilih", R.drawable.ic_check) {
                    startSelect(
                        v.id, { videos.map { it.id } }, { refresh() },
                        { ids -> moveVideos(ids) }, { ids -> confirmDeleteMany(ids) }
                    )
                },
                Sheet.Item("Edit video", R.drawable.ic_cut) {
                    startActivity(
                        Intent(this, VideoEditActivity::class.java)
                            .putExtra("uri", v.uri.toString())
                            .putExtra("name", v.title)
                            .putExtra("rel", v.rel)
                    )
                },
                Sheet.Item("Ganti nama", R.drawable.ic_edit) {
                    renameDialog(v.uri, v.title.substringBeforeLast('.'), v.title.substringAfterLast('.', ""), "video") {
                        onMediaReady()
                    }
                },
                Sheet.Item("Pindahkan ke folder", R.drawable.ic_move) { moveVideo(v) },
                null,
                Sheet.Item("Hapus dari HP", R.drawable.ic_trash, true) { confirmDelete(v) }
            )
        )
    }

    private fun moveVideos(ids: List<Long>) {
        val uris = videos.filter { it.id in ids }.map { it.uri }
        if (uris.isEmpty()) return
        lifecycleScope.launch {
            val rels = withContext(Dispatchers.IO) {
                Library.videos(this@VideoListActivity).map { it.rel }.filter { it.isNotEmpty() }
            }
            moveMany(
                uris, "", rels, listOf("DCIM/", "Movies/", "Pictures/"), "Movies/",
                "Pindahkan ${uris.size} video ke"
            ) {
                exitSelect()
                onMediaReady()
            }
        }
    }

    private fun confirmDeleteMany(ids: List<Long>) {
        val list = videos.filter { it.id in ids }
        if (list.isEmpty()) return
        Sheet.confirm(
            this, "Hapus ${list.size} video permanen?",
            "Total ${Library.sizeStr(list.sumOf { it.size })} akan dihapus dari HP dan tidak bisa dikembalikan.",
            "Hapus", true
        ) {
            deleteMedia(list.map { it.uri }) { ok ->
                if (ok) {
                    val p1 = getSharedPreferences("player_pos", Context.MODE_PRIVATE).edit()
                    val p2 = getSharedPreferences("player_done", Context.MODE_PRIVATE).edit()
                    list.forEach { p1.remove(it.uri.toString()); p2.remove(it.uri.toString()) }
                    p1.apply()
                    p2.apply()
                    exitSelect()
                    onMediaReady()
                }
            }
        }
    }

    private fun moveVideo(v: Library.Video) {
        lifecycleScope.launch {
            val rels = withContext(Dispatchers.IO) {
                Library.videos(this@VideoListActivity).map { it.rel }.filter { it.isNotEmpty() }
            }
            moveDialog(v.uri, v.rel, rels, listOf("DCIM/", "Movies/", "Pictures/"), "Movies/") { onMediaReady() }
        }
    }

    private fun confirmDelete(v: Library.Video) {
        Sheet.confirm(
            this, "Hapus video permanen?",
            "\"${v.title}\" (${Library.sizeStr(v.size)}) akan dihapus dari HP dan tidak bisa dikembalikan.",
            "Hapus", true
        ) {
            deleteMedia(listOf(v.uri)) { ok ->
                if (ok) {
                    val key = v.uri.toString()
                    getSharedPreferences("player_pos", Context.MODE_PRIVATE).edit().remove(key).apply()
                    getSharedPreferences("player_done", Context.MODE_PRIVATE).edit().remove(key).apply()
                    android.widget.Toast.makeText(this, "Video dihapus.", android.widget.Toast.LENGTH_SHORT).show()
                    onMediaReady()
                }
            }
        }
    }

    private fun refresh() {
        if (!loaded) return
        val q = etSearch.text.toString().trim().lowercase()
        val shown = Ui.sortBy(
            videos.filter { q.isEmpty() || it.title.lowercase().contains(q) },
            sortMode, { it.title }, { it.dateAdded }, { it.size }
        )
        val prefs = getSharedPreferences("player_pos", Context.MODE_PRIVATE)
        val donePrefs = getSharedPreferences("player_done", Context.MODE_PRIVATE)
        val uris = shown.map { it.uri.toString() }.toTypedArray()
        val rows = shown.mapIndexed { i, v ->
            val pos = prefs.getLong(v.uri.toString(), 0L)
            val pr = if (pos > 0 && v.durationMs > 0) (pos * 100 / v.durationMs).toInt().coerceIn(1, 99) else -1
            val isDone = pos <= 0L && donePrefs.getBoolean(v.uri.toString(), false)
            val status = when {
                pos > 0L && v.durationMs > 0 -> "\u25B6 Berhenti di ${Library.fmt(pos)} dari ${Library.fmt(v.durationMs)}"
                pos > 0L -> "\u25B6 Berhenti di ${Library.fmt(pos)}"
                isDone -> "\u2713 Selesai ditonton"
                else -> null
            }
            Row(
                title = v.title,
                sub = Library.sizeStr(v.size),
                icon = R.drawable.ic_movie,
                thumb = v.uri,
                video = true,
                badge = if (isDone) "\u2713 " + Library.fmt(v.durationMs) else Library.fmt(v.durationMs),
                progress = pr,
                status = status,
                statusDone = isDone,
                selected = picked.contains(v.id),
                onLong = { if (selecting) toggleSelect(v.id) else videoMenu(v) },
                onClick = {
                    if (selecting) {
                        toggleSelect(v.id)
                    } else {
                        startActivity(
                            Intent(this, VideoActivity::class.java)
                                .putExtra("uris", uris)
                                .putExtra("index", i)
                                .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                        )
                    }
                }
            )
        }
        adapter.rows = rows
        tvEmpty.text = "Tidak ada video."
        tvEmpty.visibility = if (rows.isEmpty()) View.VISIBLE else View.GONE
    }
}
