package com.niven.mangatl

import android.content.Context
import android.net.Uri
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.InputStream
import java.util.zip.ZipInputStream

/**
 * Model Live2D yang diimpor pengguna disimpan di folder internal PRIVAT aplikasi: filesDir/models/<id>/.
 * Model bawaan tetap di assets/models/<id>/. Path logis keduanya sama ("models/<id>/file"),
 * jadi kode pembaca cukup memanggil [open] dan tidak peduli asalnya.
 */
object ModelStore {
    fun root(ctx: Context) = File(ctx.filesDir, "models")

    /** Buka file model: folder internal dulu, kalau tidak ada baru assets. */
    fun open(ctx: Context, path: String): InputStream {
        val f = File(ctx.filesDir, path)
        return if (f.isFile) f.inputStream() else ctx.assets.open(path)
    }

    fun isImported(ctx: Context, id: String) = File(root(ctx), id + "/model.json").isFile

    fun delete(ctx: Context, id: String): Boolean {
        if (!isImported(ctx, id)) return false
        return File(root(ctx), id).deleteRecursively()
    }

    /** id model yang diimpor (folder yang berisi model.json). */
    fun importedIds(ctx: Context): List<String> =
        (root(ctx).listFiles() ?: emptyArray())
            .filter { it.isDirectory && File(it, "model.json").isFile && !it.name.startsWith(".") }
            .map { it.name }.sorted()

    // ------------------------------------------------------------------ impor .zip

    class ImportError(msg: String) : Exception(msg)
    class Imported(val id: String, val name: String, val notes: List<String>)

    private const val MAX_ENTRIES = 600
    private const val MAX_FILE = 80L shl 20      // 80 MB per file
    private const val MAX_TOTAL = 250L shl 20    // 250 MB total
    private val KEEP_EXT = setOf("moc3", "json", "png", "jpg", "jpeg", "webp")

    /** Baca zip → ekstrak aman ke folder sementara → buat model.json kalau belum ada → pindahkan ke folder model. */
    fun importZip(ctx: Context, uri: Uri, displayName: String): Imported {
        val rootDir = root(ctx).also { it.mkdirs() }
        val tmp = File(rootDir, ".tmp_import")
        tmp.deleteRecursively()
        tmp.mkdirs()
        try {
            extract(ctx, uri, tmp)
            // Folder model = folder paling dangkal yang berisi .moc3 (zip sering punya 1 folder pembungkus).
            val moc = tmp.walkTopDown().filter { it.isFile && it.extension.equals("moc3", true) }
                .minByOrNull { it.relativeTo(tmp).path.count { c -> c == File.separatorChar } }
                ?: throw ImportError("Tidak ada file .moc3 di zip ini. Pastikan ini model Live2D Cubism 3/4/5 (bukan .moc lama).")
            val src = moc.parentFile!!
            val notes = ArrayList<String>()
            val name = ensureModelJson(src, moc.name, displayName, notes)
            // id unik
            var base = slug(displayName)
            if (base.isEmpty()) base = "model"
            var id = base
            var n = 2
            while (File(rootDir, id).exists() || assetHas(ctx, id)) id = base + "_" + n++
            val dest = File(rootDir, id)
            if (!src.renameTo(dest)) {
                src.copyRecursively(dest, true)
            }
            // validasi terakhir: model.json terbaca & semua file ada
            try {
                val cfg = ModelCfg.load(ctx, id)
                if (!File(dest, cfg.moc).isFile) throw ImportError("File moc3 tidak ditemukan.")
                for (t in cfg.textures) if (!File(dest, t).isFile) throw ImportError("Tekstur hilang: $t")
                if (cfg.textures.isEmpty()) throw ImportError("Tidak ada tekstur (.png) di zip ini.")
            } catch (e: Throwable) {
                dest.deleteRecursively()
                throw if (e is ImportError) e else ImportError("model.json tidak valid: ${e.message}")
            }
            return Imported(id, name, notes)
        } finally {
            tmp.deleteRecursively()
        }
    }

    private fun assetHas(ctx: Context, id: String): Boolean = try {
        ctx.assets.open("models/$id/model.json").close(); true
    } catch (_: Throwable) {
        false
    }

    private fun slug(s: String): String {
        val b = s.substringBeforeLast('.').lowercase().map { if (it in 'a'..'z' || it in '0'..'9') it else '_' }
            .joinToString("").replace(Regex("_+"), "_").trim('_')
        return b.take(32)
    }

    private fun extract(ctx: Context, uri: Uri, out: File) {
        val canon = out.canonicalPath + File.separator
        val ins = ctx.contentResolver.openInputStream(uri) ?: throw ImportError("File tidak bisa dibuka.")
        var count = 0
        var total = 0L
        ZipInputStream(ins.buffered()).use { z ->
            while (true) {
                val e = z.nextEntry ?: break
                if (e.isDirectory) continue
                val nm = e.name.replace('\\', '/')
                if (nm.startsWith("__MACOSX/") || nm.substringAfterLast('/').startsWith(".")) continue
                val ext = nm.substringAfterLast('.', "").lowercase()
                if (ext !in KEEP_EXT) continue                         // abaikan file lain (psd, cmo3, exe, dll)
                if (++count > MAX_ENTRIES) throw ImportError("Isi zip terlalu banyak file.")
                val f = File(out, nm)
                // zip-slip: hasil harus tetap di dalam folder sementara
                if (nm.startsWith("/") || !f.canonicalPath.startsWith(canon)) throw ImportError("Zip tidak aman (path mencurigakan).")
                f.parentFile?.mkdirs()
                var size = 0L
                f.outputStream().use { o ->
                    val buf = ByteArray(64 * 1024)
                    while (true) {
                        val r = z.read(buf)
                        if (r < 0) break
                        size += r
                        total += r
                        if (size > MAX_FILE || total > MAX_TOTAL) throw ImportError("Zip terlalu besar (batas 250 MB terurai).")
                        o.write(buf, 0, r)
                    }
                }
            }
        }
        if (count == 0) throw ImportError("Zip kosong atau bukan file zip.")
    }

    // ------------------------------------------------------------------ model.json otomatis

    private fun readJson(f: File): JSONObject? = try {
        JSONObject(f.readText().trimStart('﻿'))
    } catch (_: Throwable) {
        null
    }

    /** Kembalikan nama tampilan. Kalau model.json sudah ada (buatan sendiri) dipakai apa adanya. */
    private fun ensureModelJson(dir: File, mocName: String, displayName: String, notes: MutableList<String>): String {
        val mj = File(dir, "model.json")
        if (mj.isFile) {
            val j = readJson(mj) ?: throw ImportError("model.json di zip rusak.")
            notes.add("model.json bawaan zip dipakai")
            return j.optString("name", displayName.substringBeforeLast('.'))
        }
        fun rel(f: File) = f.relativeTo(dir).path.replace(File.separatorChar, '/')
        val all = dir.walkTopDown().filter { it.isFile }.toList()
        val m3 = all.firstOrNull { it.name.endsWith(".model3.json", true) }?.let { readJson(it) }
        val refs = m3?.optJSONObject("FileReferences")

        var moc = mocName
        var textures = ArrayList<String>()
        var physics = ""
        var motion = ""
        val exps = ArrayList<Pair<String, String>>() // nama → file
        if (refs != null) {
            refs.optString("Moc").takeIf { it.isNotEmpty() && File(dir, it).isFile }?.let { moc = it }
            refs.optJSONArray("Textures")?.let { a -> for (i in 0 until a.length()) if (File(dir, a.getString(i)).isFile) textures.add(a.getString(i)) }
            refs.optString("Physics").takeIf { it.isNotEmpty() && File(dir, it).isFile }?.let { physics = it }
            refs.optJSONObject("Motions")?.let { ms ->
                val keys = ms.keys().asSequence().toList()
                val pick = keys.firstOrNull { it.equals("Idle", true) } ?: keys.firstOrNull()
                val arr = pick?.let { ms.optJSONArray(it) }
                val f = arr?.optJSONObject(0)?.optString("File").orEmpty()
                if (f.isNotEmpty() && File(dir, f).isFile) motion = f
            }
            refs.optJSONArray("Expressions")?.let { a ->
                for (i in 0 until a.length()) {
                    val o = a.getJSONObject(i)
                    val f = o.optString("File")
                    if (File(dir, f).isFile) exps.add(o.optString("Name", f) to f)
                }
            }
        }
        // cadangan kalau model3.json tidak ada / tidak lengkap
        if (textures.isEmpty()) {
            textures = ArrayList(all.filter { it.extension.lowercase() in setOf("png", "jpg", "jpeg", "webp") }
                .map { rel(it) }.sorted())
            if (textures.isNotEmpty()) notes.add("tekstur dicari otomatis (urut nama)")
        }
        if (physics.isEmpty()) all.firstOrNull { it.name.endsWith("physics3.json", true) || it.name.startsWith("physics", true) && it.extension == "json" }?.let { physics = rel(it) }
        if (motion.isEmpty()) {
            val ms = all.filter { it.name.endsWith(".motion3.json", true) }.map { rel(it) }.sorted()
            motion = ms.firstOrNull { it.contains("idle", true) || it.contains("stand", true) } ?: ms.firstOrNull() ?: ""
        }
        if (exps.isEmpty()) {
            for (f in all.filter { it.name.endsWith(".exp3.json", true) }.sortedBy { it.name }) {
                exps.add(f.name.removeSuffix(".json").removeSuffix(".exp3") to rel(f))
            }
        }
        if (motion.isEmpty()) notes.add("tidak ada animasi idle (hanya gerak kepala/mata/napas dari aplikasi)")
        if (physics.isEmpty()) notes.add("tidak ada physics (rambut tidak bergoyang)")

        val name = displayName.substringBeforeLast('.').replace('_', ' ').trim().ifEmpty { "Model" }
        val o = JSONObject()
        o.put("name", name)
        o.put("fps", 30)
        o.put("moc", moc)
        if (physics.isNotEmpty()) o.put("physics", physics)
        if (motion.isNotEmpty()) o.put("motion", motion)
        o.put("textures", JSONArray(textures))
        o.put("frame", JSONObject().put("zoom", 1.0).put("offsetY", 0.0))
        val p = JSONObject()
        val std = listOf(
            "angleX" to "ParamAngleX", "angleY" to "ParamAngleY", "angleZ" to "ParamAngleZ",
            "bodyX" to "ParamBodyAngleX", "bodyY" to "ParamBodyAngleY", "bodyZ" to "ParamBodyAngleZ",
            "eyeX" to "ParamEyeBallX", "eyeY" to "ParamEyeBallY",
            "eyeLOpen" to "ParamEyeLOpen", "eyeROpen" to "ParamEyeROpen",
            "eyeLSmile" to "ParamEyeLSmile", "eyeRSmile" to "ParamEyeRSmile",
            "browL" to "ParamBrowLY", "browR" to "ParamBrowRY",
            "mouthForm" to "ParamMouthForm", "mouthOpen" to "ParamMouthOpenY", "breath" to "ParamBreath"
        )
        for ((k, v) in std) p.put(k, v)
        o.put("params", p)

        // ekspresi: nama file/nama ekspresi dicocokkan ke kunci emosi aplikasi lewat kata kunci
        val ex = JSONObject()
        val used = HashSet<String>()
        for ((nm, f) in exps) {
            val key = matchEmotion(nm)
            if (key == null || key in used) continue
            val e = readJson(File(dir, f)) ?: continue
            val ps = e.optJSONArray("Parameters") ?: continue
            val arr = JSONArray()
            for (i in 0 until ps.length()) {
                val q = ps.getJSONObject(i)
                arr.put(JSONArray().put(q.getString("Id")).put(q.optDouble("Value", 0.0)))
            }
            if (arr.length() == 0) continue
            ex.put(key, arr)
            used.add(key)
        }
        o.put("expressions", ex)
        notes.add(if (ex.length() > 0) "ekspresi terpasang: " + used.joinToString(", ") + " (dari ${exps.size} file ekspresi)" else if (exps.isEmpty()) "model ini tidak punya file ekspresi (.exp3.json)" else "nama ekspresi tidak dikenali, tidak ada yang terpasang")
        mj.writeText(o.toString(1))
        return name
    }

    /** Cocokkan nama ekspresi (mis. "F01_Angry", "shy", "cry") ke kunci emosi aplikasi. */
    internal fun matchEmotion(nameRaw: String): String? {
        val s = nameRaw.lowercase()
        val table = listOf(
            "heartEyes" to listOf("heart", "love", "kiss", "inlove", "hati", "cinta"),
            "starEyes" to listOf("star", "sparkle", "shine", "excite", "bintang", "kira"),
            "rollEyes" to listOf("roll", "bored", "tsun", "jito", "smug", "unamused", "bosan"),
            "tears" to listOf("cry", "tear", "sad", "sob", "weep", "nangis", "sedih", "naki"),
            "angry" to listOf("angry", "anger", "mad", "rage", "furious", "ikari", "marah", "kowai"),
            "dark" to listOf("surpris", "shock", "scare", "fear", "afraid", "dark", "panic", "kaget", "odoroki"),
            "blush" to listOf("blush", "shy", "happy", "smile", "joy", "glad", "fun", "tere", "malu", "senyum", "warai", "egao", "cheek")
        )
        for ((k, ws) in table) if (ws.any { s.contains(it) }) return k
        return null
    }
}
