package com.niven.mangatl

import android.content.Context
import android.graphics.Rect
import com.google.mlkit.vision.text.Text

/**
 * Mengubah hasil OCR (blok ML Kit) menjadi kotak-kotak teks yang akan diterjemahkan.
 *
 * - Satu blok ML Kit bisa berisi teks besar + kecil sekaligus. Di sini blok dipecah per baris
 *   kalau tinggi huruf beda jauh ("Perbedaan ukuran teks") atau jarak antar baris renggang
 *   ("Spasi blok teks"), jadi nama karakter tidak menyatu dengan dialognya.
 * - Kata di ujung baris yang sebenarnya ikon (simbol aneh, satu huruf nyasar) dibuang, sekalian
 *   dari kotaknya, supaya kotak terjemahan tidak menutupi ikon.
 * - Teks yang ada di daftar abaikan (mis. "Auto", "Log") tidak diterjemahkan.
 */
object Grouping {

    const val PREF_FILE = "mangatl"
    const val KEY_SPACING = "grp_spacing"
    const val KEY_SIZEDIFF = "grp_sizediff"
    const val KEY_IGNORE = "ignore_list"

    const val SPACING_DEFAULT = 10 // posisi slider 0..20
    const val SIZEDIFF_DEFAULT = 35 // persen

    /** Posisi slider 0..20 -> jarak maksimum antar baris (kelipatan tinggi huruf) 0.3x .. 2.3x. */
    fun spacingFactor(progress: Int): Float = 0.3f + progress.coerceIn(0, 20) * 0.1f

    class Group(val rect: Rect, val text: String, val lines: Int, val ignored: Boolean)

    class Params(val spacing: Float, val sizeDiff: Float, val ignore: List<String>)

    fun params(ctx: Context): Params {
        val sp = ctx.getSharedPreferences(PREF_FILE, Context.MODE_PRIVATE)
        val s = spacingFactor(sp.getInt(KEY_SPACING, SPACING_DEFAULT))
        val d = sp.getInt(KEY_SIZEDIFF, SIZEDIFF_DEFAULT).coerceIn(10, 80) / 100f
        return Params(s, d, parseIgnore(sp.getString(KEY_IGNORE, "") ?: ""))
    }

    // ------------------------------------------------------------------ daftar abaikan

    private fun norm(s: String): String {
        val sb = StringBuilder()
        for (ch in s.lowercase()) {
            if (ch.isLetterOrDigit()) sb.append(ch) else sb.append(' ')
        }
        return sb.toString().replace(Regex("\\s+"), " ").trim()
    }

    /** Satu entri per baris (atau dipisah titik koma). "*" di awal/akhir = cocok sebagian. */
    fun parseIgnore(raw: String): List<String> =
        raw.split('\n', ';').map { it.trim() }.filter { it.isNotEmpty() }

    private fun isIgnored(text: String, ignore: List<String>): Boolean {
        if (ignore.isEmpty()) return false
        val t = norm(text)
        if (t.isEmpty()) return false
        for (e in ignore) {
            val starStart = e.startsWith("*")
            val starEnd = e.length > 1 && e.endsWith("*")
            val core = norm(e)
            if (core.isEmpty()) continue
            val hit = when {
                starStart && starEnd -> t.contains(core)
                starStart -> t.endsWith(core)
                starEnd -> t.startsWith(core)
                else -> t == core
            }
            if (hit) return true
        }
        return false
    }

    // ------------------------------------------------------------------ sampah ikon

    /** Simbol aneh yang bukan kata dan bukan tanda baca biasa (ikon yang terbaca sebagai karakter). */
    private fun isSymbolJunk(t: String): Boolean {
        val s = t.trim()
        if (s.isEmpty()) return true
        if (s.any { it.isLetterOrDigit() }) return false
        return !s.all { it in ".,!?…-~'\"" }
    }

    /** Satu huruf yang bukan kata ("a", "I"), biasanya ikon di awal baris yang terbaca sebagai huruf. */
    private fun isStrayLetter(t: String): Boolean {
        val s = t.trim()
        return s.length == 1 && s[0].isLetter() && s[0] != 'a' && s[0] != 'A' && s[0] != 'I'
    }

    private class Ln(val text: String, val box: Rect)

    private fun cleanLine(ln: Text.Line): Ln? {
        val els: ArrayList<Text.Element> = ArrayList(ln.elements)
        if (els.isEmpty()) {
            val b = ln.boundingBox ?: return null
            val t = ln.text.trim()
            return if (t.isEmpty()) null else Ln(t, Rect(b))
        }
        while (els.isNotEmpty() && isSymbolJunk(els[els.size - 1].text)) els.removeAt(els.size - 1)
        while (els.isNotEmpty() && isSymbolJunk(els[0].text)) els.removeAt(0)
        if (els.size >= 2 && isStrayLetter(els[0].text)) els.removeAt(0)
        if (els.isEmpty()) return null

        val acc = Rect()
        var has = false
        val sb = StringBuilder()
        for (e in els) {
            val r = e.boundingBox ?: continue
            if (!has) {
                acc.set(r)
                has = true
            } else {
                acc.union(r)
            }
            if (sb.isNotEmpty()) sb.append(' ')
            sb.append(e.text)
        }
        if (!has) {
            val b = ln.boundingBox ?: return null
            acc.set(b)
        }
        val t = if (sb.isNotEmpty()) sb.toString() else ln.text.trim()
        return if (t.isBlank()) null else Ln(t, acc)
    }

    // ------------------------------------------------------------------ pengelompokan

    /**
     * Kumpulkan baris OCR menjadi kelompok teks. Kelompok yang masuk daftar abaikan tetap
     * dikembalikan dengan tanda ignored = true (dipakai alat uji); pemanggil lain membuangnya.
     */
    fun group(text: Text, p: Params): List<Group> {
        val out = ArrayList<Group>()
        for (b in text.textBlocks) {
            val lines = ArrayList<Ln>()
            for (ln in b.lines) {
                val l = cleanLine(ln)
                if (l != null) lines.add(l)
            }
            if (lines.isEmpty()) continue

            var cur = ArrayList<Ln>()
            for (l in lines) {
                if (cur.isNotEmpty() && shouldSplit(cur, l, p)) {
                    emit(cur, p, out)
                    cur = ArrayList()
                }
                cur.add(l)
            }
            if (cur.isNotEmpty()) emit(cur, p, out)
        }
        return out
    }

    /** Hanya kelompok yang boleh diterjemahkan. */
    fun translatable(text: Text, p: Params): List<Pair<Rect, String>> =
        translatableGroups(text, p).map { Pair(it.rect, it.text) }

    fun translatableGroups(text: Text, p: Params): List<Group> =
        group(text, p).filter { !it.ignored }

    private fun shouldSplit(cur: List<Ln>, next: Ln, p: Params): Boolean {
        var sum = 0f
        for (l in cur) sum += l.box.height()
        val avg = (sum / cur.size).coerceAtLeast(1f)
        val h = next.box.height().toFloat().coerceAtLeast(1f)
        val diff = Math.abs(h - avg) / Math.max(h, avg)
        if (diff > p.sizeDiff) return true
        val prev = cur[cur.size - 1]
        val gap = next.box.top - prev.box.bottom
        if (gap > p.spacing * avg) return true
        return false
    }

    private fun emit(cur: List<Ln>, p: Params, out: MutableList<Group>) {
        val acc = Rect(cur[0].box)
        val sb = StringBuilder()
        for (l in cur) {
            acc.union(l.box)
            if (sb.isNotEmpty()) sb.append(' ')
            sb.append(l.text)
        }
        val t = sb.toString().trim()
        if (t.isEmpty()) return
        out.add(Group(acc, t, cur.size, isIgnored(t, p.ignore)))
    }
}
