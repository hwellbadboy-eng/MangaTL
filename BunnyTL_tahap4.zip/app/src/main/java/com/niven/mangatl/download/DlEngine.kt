package com.niven.mangatl

import android.content.Context
import android.util.Log
import com.yausername.ffmpeg.FFmpeg
import com.yausername.youtubedl_android.YoutubeDL
import com.yausername.youtubedl_android.YoutubeDLRequest
import java.io.File

/**
 * Mesin unduh (yt-dlp lewat youtubedl-android, diambil dari SnapNet).
 * Disiapkan malas: baru diekstrak/dijalankan saat pertama kali dipakai, bukan saat BunnyTL dibuka.
 * Semua fungsi di sini BLOKIR -> panggil dari thread latar.
 */
object DlEngine {
    private const val TAG = "DlEngine"
    private val VERSION_RE = Regex("""\b(\d{4}\.\d{1,2}\.\d{1,2}(?:\.\d+)?)\b""")
    private val lock = Any()

    @Volatile private var ready = false

    /** true kalau modul mutagen ada di Python bawaan (dibutuhkan yt-dlp untuk menyematkan cover ke Opus). */
    @Volatile var hasMutagen: Boolean = false
        private set

    /** Versi yt-dlp yang benar-benar jalan (kosong kalau belum disiapkan). */
    @Volatile var version: String = ""
        private set

    /** Siapkan mesin (ekstrak Python + yt-dlp + ffmpeg bawaan, lalu uji jalan). Aman dipanggil berulang. */
    fun ensureReady(ctx: Context) {
        if (ready) return
        synchronized(lock) {
            if (ready) return
            val app = ctx.applicationContext
            YoutubeDL.init(app)
            FFmpeg.init(app)
            var v = probe()
            if (v == null) {
                Log.w(TAG, "mesin tidak bisa jalan, memulihkan salinan bawaan APK")
                restoreBundled(app)
                v = probe()
            }
            if (v == null) throw IllegalStateException("Mesin unduh tidak bisa dijalankan di HP ini.")
            version = v
            hasMutagen = detectMutagen()
            Log.i(TAG, "yt-dlp $v, mutagen=$hasMutagen")
            ready = true
        }
    }

    /** Jalankan `yt-dlp --version`. Null kalau mesin gagal jalan. */
    fun probe(): String? = runCatching {
        val r = YoutubeDL.getInstance().execute(YoutubeDLRequest(listOf("--version")))
        VERSION_RE.find("${r.out}\n${r.err}")?.groupValues?.get(1)
    }.onFailure { Log.w(TAG, "probe gagal", it) }.getOrNull()

    /**
     * yt-dlp -v mencetak baris "Optional libraries: ..., mutagen-x.y, ..." sebelum bekerja.
     * Dijalankan ke URL palsu (tanpa jaringan); galat "unsupported URL" tidak masalah, yang dibaca hanya log-nya.
     * Kalau barisnya tidak ketemu, dianggap TIDAK ada (cara aman: Opus tanpa cover).
     */
    private fun detectMutagen(): Boolean {
        val log = try {
            val r = YoutubeDL.getInstance().execute(
                YoutubeDLRequest(listOf("-v", "--ignore-config", "--skip-download", "about:blank"))
            )
            "${r.out}\n${r.err}"
        } catch (e: Exception) {
            e.message.orEmpty()
        }
        val line = log.lineSequence().firstOrNull { it.contains("Optional libraries", ignoreCase = true) } ?: return false
        return Regex("""\bmutagen\b""", RegexOption.IGNORE_CASE).containsMatchIn(line)
    }

    fun refreshVersion() {
        probe()?.let { version = it }
    }

    /** Hapus yt-dlp hasil update dan ekstrak ulang salinan yang ikut di dalam APK. */
    fun restoreBundled(ctx: Context): Boolean = runCatching {
        val dir = File(ctx.noBackupFilesDir, "youtubedl-android/yt-dlp")
        if (dir.exists()) dir.deleteRecursively()
        YoutubeDL.getInstance().init_ytdlp(ctx, dir)
        true
    }.onFailure { Log.e(TAG, "gagal memulihkan mesin bawaan", it) }.getOrDefault(false)

    /** Galat ini bisa diatasi dengan login (cookies). */
    fun needsLogin(msg: String?) = msg != null && "Masuk akun" in msg

    /** Ubah galat mentah yt-dlp jadi kalimat yang bisa dipahami. */
    fun friendlyError(t: Throwable): String {
        val m = t.message ?: t.toString()
        val low = m.lowercase()
        return when {
            "sign in to confirm" in low || "not a bot" in low ->
                "YouTube minta verifikasi (anti-bot). Masuk akun lewat tombol di bawah, atau perbarui mesin unduh."
            "confirm your age" in low || "age-restricted" in low || "inappropriate for some users" in low ->
                "Video dibatasi umur. Masuk akun (cookies) dulu lewat tombol di bawah."
            "members-only" in low || "join this channel" in low ->
                "Video khusus member. Masuk akun (cookies) yang sudah jadi member dulu."
            "redirected to the login page" in low || "rate-limit for accessing" in low || "login required" in low ||
                "requires login" in low || "use --cookies" in low || "--cookies-from-browser" in low ->
                "Situs ini minta login (akses tanpa akun dibatasi). Masuk akun lewat tombol di bawah, lalu coba lagi."
            "unsupported url" in low -> "Link ini tidak didukung."
            "private video" in low -> "Video ini privat."
            "video unavailable" in low || "not available" in low ->
                "Video tidak tersedia (dihapus atau dibatasi wilayah)."
            "http error 403" in low -> "Ditolak situs (403). Coba perbarui mesin unduh."
            "http error 429" in low -> "Terlalu banyak permintaan (429). Tunggu sebentar lalu coba lagi."
            "unable to resolve" in low || "unknownhost" in low || "network is unreachable" in low ||
                "timed out" in low || "unable to connect" in low ->
                "Koneksi internet bermasalah."
            else -> {
                val line = m.lineSequence().lastOrNull { it.contains("ERROR", ignoreCase = true) }
                (line?.substringAfter("ERROR:")?.trim() ?: m.trim()).take(300)
            }
        }
    }
}

/** Pengaturan kecil fitur unduh. */
object DlPrefs {
    private fun p(ctx: Context) =
        ctx.applicationContext.getSharedPreferences("dl_settings", Context.MODE_PRIVATE)

    fun lastUpdate(ctx: Context) = p(ctx).getLong("last_update", 0L)
    fun setLastUpdate(ctx: Context, v: Long) = p(ctx).edit().putLong("last_update", v).apply()

    /** true = MP4 kompatibel (utamakan H.264), false = MKV kualitas tertinggi. */
    fun compat(ctx: Context) = p(ctx).getBoolean("compat", true)
    fun setCompat(ctx: Context, v: Boolean) = p(ctx).edit().putBoolean("compat", v).apply()

    fun lastAudio(ctx: Context) = p(ctx).getBoolean("last_audio", false)
    fun setLastAudio(ctx: Context, v: Boolean) = p(ctx).edit().putBoolean("last_audio", v).apply()

    /** 0 = MP3, 1 = M4A, 2 = Opus */
    fun audioFmt(ctx: Context) = p(ctx).getInt("audio_fmt", 0)
    fun setAudioFmt(ctx: Context, v: Int) = p(ctx).edit().putInt("audio_fmt", v).apply()

    /** Video: sematkan subtitle bila tersedia. */
    fun subs(ctx: Context) = p(ctx).getBoolean("subs", true)
    fun setSubs(ctx: Context, v: Boolean) = p(ctx).edit().putBoolean("subs", v).apply()

    /** Musik: cari lirik otomatis. */
    fun lyrics(ctx: Context) = p(ctx).getBoolean("lyrics", true)
    fun setLyrics(ctx: Context, v: Boolean) = p(ctx).edit().putBoolean("lyrics", v).apply()

    /** Musik: potong cover jadi persegi (MP3/M4A). */
    fun square(ctx: Context) = p(ctx).getBoolean("square", true)
    fun setSquare(ctx: Context, v: Boolean) = p(ctx).edit().putBoolean("square", v).apply()

    /** Pakai cookies.txt (kalau ada) saat mengambil info dan mengunduh. */
    fun useCookies(ctx: Context) = p(ctx).getBoolean("use_cookies", true)
    fun setUseCookies(ctx: Context, v: Boolean) = p(ctx).edit().putBoolean("use_cookies", v).apply()

    /** User-Agent yang dipakai WebView saat login; dikirim juga ke yt-dlp supaya cocok dengan cookies. */
    fun userAgent(ctx: Context) = p(ctx).getString("ua", "") ?: ""
    fun setUserAgent(ctx: Context, v: String) = p(ctx).edit().putString("ua", v).apply()

    /** Kunci situs terakhir yang dipakai login manual (mis. instagram.com). */
    fun lastLogin(ctx: Context) = p(ctx).getString("last_login", "") ?: ""
    fun setLastLogin(ctx: Context, v: String) = p(ctx).edit().putString("last_login", v).apply()

    fun notifAsked(ctx: Context) = p(ctx).getBoolean("notif_asked", false)
    fun setNotifAsked(ctx: Context) = p(ctx).edit().putBoolean("notif_asked", true).apply()
}
