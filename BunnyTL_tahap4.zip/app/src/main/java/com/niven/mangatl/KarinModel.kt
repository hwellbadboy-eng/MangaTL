package com.niven.mangatl

import android.content.Context
import android.graphics.BitmapFactory
import android.opengl.GLES20
import android.opengl.GLUtils
import android.util.Log
import com.live2d.sdk.cubism.core.ICubismLogger
import com.live2d.sdk.cubism.framework.CubismFramework
import com.live2d.sdk.cubism.framework.ICubismLoadFileFunction
import com.live2d.sdk.cubism.framework.id.CubismId
import com.live2d.sdk.cubism.framework.math.CubismMatrix44
import com.live2d.sdk.cubism.framework.model.CubismUserModel
import com.live2d.sdk.cubism.framework.motion.CubismPhysicsUpdater
import com.live2d.sdk.cubism.framework.rendering.android.CubismRendererAndroid
import org.json.JSONObject

/** Menyalakan Cubism Framework sekali per proses. */
object KarinCore {
    fun ensure(ctx: Context) {
        if (!CubismFramework.isStarted()) {
            val app = ctx.applicationContext
            val opt = CubismFramework.Option()
            opt.logFunction = ICubismLogger { msg -> Log.d("Karin", msg) }
            opt.loadFileFunction = ICubismLoadFileFunction { path ->
                try {
                    app.assets.open(path).use { it.readBytes() }
                } catch (e: Exception) {
                    Log.e("Karin", "Gagal baca asset $path: ${e.message}")
                    ByteArray(0)
                }
            }
            CubismFramework.startUp(opt)
        }
        if (!CubismFramework.isInitialized()) CubismFramework.initialize()
    }
}

/** Model Live2D Karin (assets/karin). Semua fungsi dipanggil dari thread GL. */
class KarinModel(private val ctx: Context) : CubismUserModel() {

    private val texIds = ArrayList<Int>()
    private var loaded = false

    private val idm = CubismFramework.getIdManager()
    private val pAngleX: CubismId = idm.getId("ParamAngleX")
    private val pAngleY: CubismId = idm.getId("ParamAngleY")
    private val pAngleZ: CubismId = idm.getId("ParamAngleZ")
    private val pBodyX: CubismId = idm.getId("ParamBodyAngleX")
    private val pBodyY: CubismId = idm.getId("ParamBodyAngleY")
    private val pBodyZ: CubismId = idm.getId("ParamBodyAngleZ")
    private val pEyeBallX: CubismId = idm.getId("ParamEyeBallX")
    private val pEyeBallY: CubismId = idm.getId("ParamEyeBallY")
    private val pEyeLOpen: CubismId = idm.getId("ParamEyeLOpen")
    private val pEyeROpen: CubismId = idm.getId("ParamEyeROpen")
    private val pEyeLSmile: CubismId = idm.getId("ParamEyeLSmile")
    private val pEyeRSmile: CubismId = idm.getId("ParamEyeRSmile")
    private val pBrowLY: CubismId = idm.getId("ParamBrowLY")
    private val pBrowRY: CubismId = idm.getId("ParamBrowRY")
    private val pMouthForm: CubismId = idm.getId("ParamMouthForm")
    private val pMouthOpen: CubismId = idm.getId("ParamMouthOpenY")
    private val pBreath: CubismId = idm.getId("ParamBreath")
    private val pCheek: CubismId = idm.getId("ParamCheek")

    private fun read(path: String): ByteArray = ctx.assets.open(path).use { it.readBytes() }

    /** Muat moc3, physics, dan tekstur. Harus dipanggil saat konteks GL aktif. */
    fun load(w: Int, h: Int): Boolean {
        val dir = "karin/"
        val refs = JSONObject(String(read(dir + "Karin.model3.json"))).getJSONObject("FileReferences")

        loadModel(read(dir + refs.getString("Moc")))
        if (getModel() == null) return false

        if (refs.has("Physics")) {
            loadPhysics(read(dir + refs.getString("Physics")))
            if (physics != null) updateScheduler.addUpdatableList(CubismPhysicsUpdater(physics))
        }
        updateScheduler.sortUpdatableList()

        setupRenderer(CubismRendererAndroid.create(w, h))
        setRenderTargetSize(w, h)

        val tex = refs.getJSONArray("Textures")
        for (i in 0 until tex.length()) {
            val id = upload(dir + tex.getString(i))
            texIds.add(id)
            getRenderer<CubismRendererAndroid>().bindTexture(i, id)
        }
        getRenderer<CubismRendererAndroid>().isPremultipliedAlpha(true)

        getModel().saveParameters()
        loaded = true
        return true
    }

    private fun upload(path: String): Int {
        val opts = BitmapFactory.Options().apply { inPremultiplied = true }
        val bmp = ctx.assets.open(path).use { BitmapFactory.decodeStream(it, null, opts) }
            ?: throw IllegalStateException("Tekstur tidak terbaca: $path")
        val ids = IntArray(1)
        GLES20.glGenTextures(1, ids, 0)
        GLES20.glActiveTexture(GLES20.GL_TEXTURE0)
        GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, ids[0])
        GLUtils.texImage2D(GLES20.GL_TEXTURE_2D, 0, bmp, 0)
        GLES20.glGenerateMipmap(GLES20.GL_TEXTURE_2D)
        GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_MIN_FILTER, GLES20.GL_LINEAR_MIPMAP_LINEAR)
        GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_MAG_FILTER, GLES20.GL_LINEAR)
        bmp.recycle()
        return ids[0]
    }

    fun isLoaded() = loaded

    fun canvasRatio(): Float {
        val m = getModel()
        return m.canvasHeight / m.canvasWidth
    }

    /** Hitung parameter dari KarinAnim, jalankan physics (rambut), lalu update model. */
    fun update(dt: Float, a: KarinAnim) {
        val m = getModel()
        m.loadParameters()
        a.step(dt)
        m.setParameterValue(pAngleX, a.angleX)
        m.setParameterValue(pAngleY, a.angleY)
        m.setParameterValue(pAngleZ, a.angleZ)
        m.setParameterValue(pBodyX, a.bodyX)
        m.setParameterValue(pBodyY, a.bodyY)
        m.setParameterValue(pBodyZ, a.bodyZ)
        m.setParameterValue(pEyeBallX, a.eyeX)
        m.setParameterValue(pEyeBallY, a.eyeY)
        m.setParameterValue(pEyeLOpen, a.eyeOpenL)
        m.setParameterValue(pEyeROpen, a.eyeOpenR)
        m.setParameterValue(pEyeLSmile, a.smile)
        m.setParameterValue(pEyeRSmile, a.smile)
        m.setParameterValue(pBrowLY, a.browL)
        m.setParameterValue(pBrowRY, a.browR)
        m.setParameterValue(pMouthForm, a.mouthForm)
        m.setParameterValue(pMouthOpen, a.mouthOpen)
        m.setParameterValue(pBreath, a.breath)
        m.setParameterValue(pCheek, a.cheek)
        updateScheduler.onLateUpdate(m, dt)
        m.update()
    }

    fun draw(projection: CubismMatrix44) {
        CubismMatrix44.multiply(getModelMatrix().array, projection.array, projection.array)
        val r = getRenderer<CubismRendererAndroid>()
        r.setMvpMatrix(projection)
        r.drawModel()
    }

    /** glDelete = true kalau konteks GL yang lama masih aktif. */
    fun release(glDelete: Boolean) {
        loaded = false
        try {
            if (glDelete && texIds.isNotEmpty()) {
                GLES20.glDeleteTextures(texIds.size, texIds.toIntArray(), 0)
            }
        } catch (_: Throwable) {
        }
        texIds.clear()
        try {
            delete()
        } catch (_: Throwable) {
        }
    }
}
