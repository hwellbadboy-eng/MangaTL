package com.niven.mangatl

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.opengl.GLES20
import android.opengl.GLUtils
import android.util.Log
import com.live2d.sdk.cubism.core.ICubismLogger
import com.live2d.sdk.cubism.framework.CubismFramework
import com.live2d.sdk.cubism.framework.ICubismLoadFileFunction
import com.live2d.sdk.cubism.framework.id.CubismId
import com.live2d.sdk.cubism.framework.math.CubismMatrix44
import com.live2d.sdk.cubism.framework.model.CubismUserModel
import com.live2d.sdk.cubism.framework.motion.CubismMotion
import com.live2d.sdk.cubism.framework.motion.CubismPhysicsUpdater
import com.live2d.sdk.cubism.framework.rendering.android.CubismRendererAndroid
import java.util.concurrent.Callable
import java.util.concurrent.Executors
import java.util.concurrent.Future

/** Menyalakan Cubism Framework sekali per proses. */
object KarinCore {
    fun ensure(ctx: Context) {
        if (!CubismFramework.isStarted()) {
            val app = ctx.applicationContext
            val opt = CubismFramework.Option()
            opt.logFunction = ICubismLogger { msg -> Log.d("Karin", msg) }
            opt.loadFileFunction = ICubismLoadFileFunction { path ->
                try {
                    app.assets.open(path).use { it.readBytes() }
                } catch (e: Exception) {
                    Log.e("Karin", "Gagal baca asset $path: ${e.message}")
                    ByteArray(0)
                }
            }
            CubismFramework.startUp(opt)
        }
        if (!CubismFramework.isInitialized()) CubismFramework.initialize()
    }
}

/**
 * Decode tekstur PNG di thread latar (paralel) supaya thread GL tidak tertahan.
 * prefetch() dipanggil sedini mungkin; take() mengambil hasilnya.
 */
object KarinTex {
    private val pool = Executors.newFixedThreadPool(3) { r ->
        Thread(r, "karin-tex").apply {
            isDaemon = true
            priority = Thread.NORM_PRIORITY - 1
        }
    }
    private val pending = HashMap<String, Future<Bitmap?>>()

    private fun decode(app: Context, path: String): Bitmap? {
        val opts = BitmapFactory.Options().apply { inPremultiplied = true }
        return app.assets.open(path).use { BitmapFactory.decodeStream(it, null, opts) }
    }

    /** Mulai decode path-path ini. Decode model lain yang masih menggantung dibuang (hemat memori). */
    @Synchronized
    fun prefetch(ctx: Context, paths: List<String>) {
        val app = ctx.applicationContext
        val it = pending.entries.iterator()
        while (it.hasNext()) {
            val e = it.next()
            if (e.key !in paths) {
                e.value.cancel(true)
                try {
                    if (e.value.isDone && !e.value.isCancelled) e.value.get()?.recycle()
                } catch (_: Throwable) {
                }
                it.remove()
            }
        }
        for (p in paths) {
            if (pending.containsKey(p)) continue
            pending[p] = pool.submit(Callable<Bitmap?> {
                try {
                    decode(app, p)
                } catch (e: Throwable) {
                    Log.e("Karin", "Decode gagal $p: ${e.message}")
                    null
                }
            })
        }
    }

    /** Ambil bitmap hasil prefetch (kalau belum ada, decode langsung). Pemanggil wajib recycle(). */
    fun take(ctx: Context, path: String): Bitmap? {
        val f = synchronized(this) { pending.remove(path) }
        return try {
            f?.get() ?: decode(ctx.applicationContext, path)
        } catch (e: Throwable) {
            decode(ctx.applicationContext, path)
        }
    }
}

/** Satu model Live2D (assets/models/<id>), diatur oleh ModelCfg. Semua fungsi dipanggil dari thread GL. */
class KarinModel(private val ctx: Context, private val cfg: ModelCfg) : CubismUserModel() {

    private val texIds = ArrayList<Int>()
    private var loaded = false
    private var texCount = 0
    private var nextTex = 0

    private val idm = CubismFramework.getIdManager()
    private fun id(role: String): CubismId? {
        val n = cfg.params[role] ?: return null
        return if (n.isEmpty()) null else idm.getId(n)
    }

    private val pAngleX = id("angleX")
    private val pAngleY = id("angleY")
    private val pAngleZ = id("angleZ")
    private val pBodyX = id("bodyX")
    private val pBodyY = id("bodyY")
    private val pBodyZ = id("bodyZ")
    private val pEyeBallX = id("eyeX")
    private val pEyeBallY = id("eyeY")
    private val pEyeLOpen = id("eyeLOpen")
    private val pEyeROpen = id("eyeROpen")
    private val pEyeLSmile = id("eyeLSmile")
    private val pEyeRSmile = id("eyeRSmile")
    private val pBrowL = id("browL")
    private val pBrowR = id("browR")
    private val pMouthForm = id("mouthForm")
    private val pMouthOpen = id("mouthOpen")
    private val pBreath = id("breath")
    private val pCheek = id("cheek")
    private val pPosX = id("posX")
    private val pPosY = id("posY")

    private class Expr(val key: String, val items: List<Pair<CubismId, Float>>)

    private val exprs: List<Expr> = cfg.expressions.map { (k, list) ->
        Expr(k, list.map { idm.getId(it.first) to it.second })
    }

    private fun read(path: String): ByteArray = ctx.assets.open(path).use { it.readBytes() }

    /**
     * Tahap 1: moc3, physics, motion efek, renderer (kompilasi shader). Tekstur diunggah per frame lewat step()
     * supaya tidak ada satu frame panjang. Harus dipanggil saat konteks GL aktif.
     */
    fun begin(w: Int, h: Int): Boolean {
        val paths = cfg.texturePaths()
        KarinTex.prefetch(ctx, paths)   // kalau belum jalan, mulai decode sekarang

        loadModel(read(cfg.dir + cfg.moc))
        if (getModel() == null) return false

        if (cfg.physics.isNotEmpty()) {
            loadPhysics(read(cfg.dir + cfg.physics))
            if (physics != null) updateScheduler.addUpdatableList(CubismPhysicsUpdater(physics))
        }
        updateScheduler.sortUpdatableList()

        if (cfg.motion.isNotEmpty()) {
            try {
                val mo = CubismMotion.create(read(cfg.dir + cfg.motion))
                if (mo != null) {
                    mo.setLoop(true)
                    mo.setLoopFadeIn(true)
                    motionManager.startMotionPriority(mo, 1)
                }
            } catch (t: Throwable) {
                Log.e("Karin", "Motion gagal dimuat: ${t.message}")
            }
        }

        setupRenderer(CubismRendererAndroid.create(w, h))
        setRenderTargetSize(w, h)
        getRenderer<CubismRendererAndroid>().isPremultipliedAlpha(true)
        if (cfg.maskSize > 0) {
            // Mask clipping lebih halus saat avatar di-zoom (tepi mata, rambut, dll. tidak bergerigi / bocor).
            val r = getRenderer<CubismRendererAndroid>()
            r.setDrawableClippingMaskBufferSize(cfg.maskSize.toFloat(), cfg.maskSize.toFloat())
            r.setOffscreenClippingMaskBufferSize(cfg.maskSize.toFloat(), cfg.maskSize.toFloat())
        }

        texCount = paths.size
        nextTex = 0
        return true
    }

    /** Tahap 2: unggah satu tekstur per panggilan. true = semua tekstur terpasang, model siap. */
    fun step(): Boolean {
        val paths = cfg.texturePaths()
        if (nextTex < texCount) {
            val id = upload(paths[nextTex])
            texIds.add(id)
            getRenderer<CubismRendererAndroid>().bindTexture(nextTex, id)
            nextTex++
        }
        if (nextTex >= texCount) {
            getModel().saveParameters()
            loaded = true
            return true
        }
        return false
    }

    fun setFade(a: Float) {
        getRenderer<CubismRendererAndroid>().setModelColor(1f, 1f, 1f, a)
    }

    private fun upload(path: String): Int {
        val bmp = KarinTex.take(ctx, path)
            ?: throw IllegalStateException("Tekstur tidak terbaca: $path")
        val ids = IntArray(1)
        GLES20.glGenTextures(1, ids, 0)
        GLES20.glActiveTexture(GLES20.GL_TEXTURE0)
        GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, ids[0])
        GLUtils.texImage2D(GLES20.GL_TEXTURE_2D, 0, bmp, 0)
        GLES20.glGenerateMipmap(GLES20.GL_TEXTURE_2D)
        GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_MIN_FILTER, GLES20.GL_LINEAR_MIPMAP_LINEAR)
        GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_MAG_FILTER, GLES20.GL_LINEAR)
        bmp.recycle()
        return ids[0]
    }

    fun isLoaded() = loaded

    fun canvasRatio(): Float {
        val m = getModel()
        return m.canvasHeight / m.canvasWidth
    }

    private fun put(m: com.live2d.sdk.cubism.framework.model.CubismModel, id: CubismId?, v: Float) {
        if (id != null) m.setParameterValue(id, v)
    }

    /** Hitung parameter dari KarinAnim, jalankan physics, lalu update model. */
    fun update(dt: Float, a: KarinAnim) {
        val m = getModel()
        m.loadParameters()
        // efek berulang dari file motion (air mata, bintang, dll). Tidak menyentuh parameter gerak kita.
        if (cfg.motion.isNotEmpty()) motionManager.updateMotion(m, dt)
        a.step(dt)
        put(m, pAngleX, a.angleX)
        put(m, pAngleY, a.angleY)
        put(m, pAngleZ, a.angleZ)
        put(m, pBodyX, a.bodyX)
        put(m, pBodyY, a.bodyY)
        put(m, pBodyZ, a.bodyZ)
        put(m, pEyeBallX, a.eyeX)
        put(m, pEyeBallY, a.eyeY)
        put(m, pEyeLOpen, a.eyeOpenL)
        put(m, pEyeROpen, a.eyeOpenR)
        put(m, pEyeLSmile, a.smile)
        put(m, pEyeRSmile, a.smile)
        put(m, pBrowL, a.browL)
        put(m, pBrowR, a.browR)
        put(m, pMouthForm, a.mouthForm)
        put(m, pMouthOpen, a.mouthOpen)
        put(m, pBreath, a.breath)
        put(m, pCheek, a.cheek)
        put(m, pPosX, a.posX)
        put(m, pPosY, a.posY)
        // ekspresi: nilai 'Add' dikali bobot fade
        for (e in exprs) {
            val w = a.exprWeight(e.key)
            if (w <= 0f) continue
            for ((pid, v) in e.items) m.addParameterValue(pid, v * w)
        }
        updateScheduler.onLateUpdate(m, dt)
        m.update()
    }

    fun draw(projection: CubismMatrix44) {
        CubismMatrix44.multiply(getModelMatrix().array, projection.array, projection.array)
        val r = getRenderer<CubismRendererAndroid>()
        r.setMvpMatrix(projection)
        r.drawModel()
    }

    /** glDelete = true kalau konteks GL yang lama masih aktif. */
    fun release(glDelete: Boolean) {
        loaded = false
        try {
            if (glDelete && texIds.isNotEmpty()) {
                GLES20.glDeleteTextures(texIds.size, texIds.toIntArray(), 0)
            }
        } catch (_: Throwable) {
        }
        texIds.clear()
        try {
            delete()
        } catch (_: Throwable) {
        }
    }
}
