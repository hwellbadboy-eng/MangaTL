package com.niven.mangatl

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RadialGradient
import android.graphics.Shader
import android.util.AttributeSet
import android.view.View
import kotlin.math.hypot

/**
 * Lapisan gelap di tepi (vignette): tengah tetap terang, sisi dan sudut makin gelap.
 * Dipakai di kartu Chat AI supaya tulisan di tengah tetap jelas apa pun latarnya.
 */
class VignetteView @JvmOverloads constructor(
    ctx: Context,
    attrs: AttributeSet? = null
) : View(ctx, attrs) {

    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)

    /** 0..100 */
    var strength: Int = 0
        set(v) {
            field = v.coerceIn(0, 100)
            rebuild()
            invalidate()
        }

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        super.onSizeChanged(w, h, ow, oh)
        rebuild()
    }

    private fun rebuild() {
        if (width == 0 || height == 0) return
        val a = (strength / 100f * 0.95f * 255f).toInt()
        val r = hypot(width.toFloat(), height.toFloat()) / 2f
        paint.shader = RadialGradient(
            width / 2f, height / 2f, r,
            intArrayOf(Color.argb(0, 0, 0, 0), Color.argb(0, 0, 0, 0), Color.argb(a, 0, 0, 0)),
            floatArrayOf(0f, 0.25f, 1f),
            Shader.TileMode.CLAMP
        )
    }

    override fun onDraw(c: Canvas) {
        if (strength > 0) c.drawRect(0f, 0f, width.toFloat(), height.toFloat(), paint)
    }
}
