package com.niven.mangatl

import android.view.View
import android.widget.CheckBox
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

// Layar Musik: pengaturan, banner (video/foto latar) dan dialog posisi banner.
// Fungsi ekstensi dari MusicActivity; keadaan dan siklus hidup layar tetap di MusicActivity.kt.

internal fun MusicActivity.updateBannerAspect() {
    banner.aspect = bannerHeightPx().toFloat() / resources.displayMetrics.widthPixels
}

/** Banner tampil kalau ada dan "Video latar" aktif; kalau belum ada banner, tampil cahaya abu pengganti. */
internal fun MusicActivity.applyHeaderLayout() {
    updateBannerAspect()
    val has = banner.has()
    val show = has && videoOn()
    bannerLayer.visibility = if (show) View.VISIBLE else View.GONE
    bgGlow.visibility = if (!has && videoOn()) View.VISIBLE else View.GONE
    tvBannerLabel.visibility = View.GONE
}

/** Pasang ulang tampilan header lalu putar banner (kalau ada). */
internal fun MusicActivity.applyBanner() {
    applyHeaderLayout()
    if (banner.has() && videoOn()) banner.start() else banner.stop()
}

internal fun MusicActivity.positionDialog() {
    updateBannerAspect()
    lifecycleScope.launch {
        val bmp = withContext(Dispatchers.IO) { banner.preview() }
        if (bmp == null) {
            Toast.makeText(this@positionDialog, "Pratinjau banner tidak bisa dibuka.", Toast.LENGTH_SHORT).show()
            return@launch
        }
        val v = BannerPosView(this@positionDialog).apply {
            this.bmp = bmp
            aspect = 1f / banner.aspect
            fx = banner.fx()
            fy = banner.fy()
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, Ui.dp(this@positionDialog, 280)
            )
        }
        val box = Ui.box(this@positionDialog)
        val tip = TextView(this@positionDialog).apply {
            text = if (v.canMove()) "Geser kotak terang untuk memilih bagian yang tampil di banner."
            else "Gambar ini sudah pas dengan banner, tidak ada bagian yang terpotong."
            textSize = 13f
            alpha = 0.8f
            setPadding(0, 0, 0, Ui.dp(this@positionDialog, 10))
        }
        box.addView(tip)
        box.addView(v)
        AlertDialog.Builder(this@positionDialog)
            .setTitle("Atur posisi banner")
            .setView(box)
            .setPositiveButton("Simpan") { _, _ ->
                banner.setFocus((v.fx * 100).toInt(), (v.fy * 100).toInt()) { err ->
                    if (err != null) Toast.makeText(this@positionDialog, err, Toast.LENGTH_LONG).show()
                    applyBanner()
                    onBannerChange?.invoke()
                }
            }
            .setNegativeButton("Batal", null)
            .show()
    }
}

internal fun MusicActivity.settingsDialog() {
    val order = Prefs.tabOrder(this).toMutableList()
    val hidden = Prefs.tabHidden(this).toMutableSet()
    val root = Ui.box(this)

    fun render() {
        root.removeAllViews()
        root.addView(Ui.section(this, "Banner (foto / GIF / video)"))
        if (banner.has()) {
            root.addView(TextView(this).apply {
                text = "${(banner.type() ?: "").uppercase()} · ${banner.name() ?: ""}"
                textSize = 14f
                maxLines = 2
                ellipsize = android.text.TextUtils.TruncateAt.END
            })
            val change = com.google.android.material.button.MaterialButton(this)
            change.text = "Ganti file"
            change.setOnClickListener { pickBanner.launch(arrayOf("video/*", "image/*")) }
            root.addView(change)
            val pos = com.google.android.material.button.MaterialButton(this)
            pos.text = "Atur posisi"
            pos.setOnClickListener { positionDialog() }
            root.addView(pos)
            val del = com.google.android.material.button.MaterialButton(this)
            del.text = "Hapus banner"
            del.setOnClickListener {
                banner.remove()
                applyBanner()
                render()
            }
            root.addView(del)
            if (banner.type() != "photo") {
                root.addView(Ui.section(this, "Mode putar banner"))
                root.addView(Ui.radios(this, listOf("Loop", "Maju-mundur"), banner.mode()) { m ->
                    if (m == Banner.MODE_PINGPONG) {
                        Toast.makeText(this, "Menyiapkan maju-mundur...", Toast.LENGTH_SHORT).show()
                    }
                    updateBannerAspect()
                    banner.setMode(m) { err ->
                        if (err != null) Toast.makeText(this, err, Toast.LENGTH_LONG).show()
                        applyBanner()
                        render()
                    }
                })
            }
        } else {
            val pick = com.google.android.material.button.MaterialButton(this)
            pick.text = "Pilih banner"
            pick.setOnClickListener { pickBanner.launch(arrayOf("video/*", "image/*")) }
            root.addView(pick)
        }
        root.addView(Ui.section(this, "Tab yang ditampilkan (urutan bisa digeser)"))
        order.forEachIndexed { i, id ->
            val row = LinearLayout(this)
            row.orientation = LinearLayout.HORIZONTAL
            row.gravity = android.view.Gravity.CENTER_VERTICAL
            val cb = CheckBox(this)
            cb.text = Prefs.TAB_NAMES[id]
            cb.isChecked = id !in hidden
            cb.layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            cb.setOnCheckedChangeListener { _, on ->
                if (on) hidden.remove(id) else {
                    if (order.count { it !in hidden } <= 1) {
                        cb.isChecked = true
                        Toast.makeText(this, "Minimal satu tab harus tampil.", Toast.LENGTH_SHORT).show()
                    } else hidden.add(id)
                }
            }
            row.addView(cb)
            val up = Ui.iconBtn(this, R.drawable.ic_up, "Naik") {
                if (i > 0) { order.add(i - 1, order.removeAt(i)); render() }
            }
            val down = Ui.iconBtn(this, R.drawable.ic_down, "Turun") {
                if (i < order.size - 1) { order.add(i + 1, order.removeAt(i)); render() }
            }
            up.layoutParams = LinearLayout.LayoutParams(Ui.dp(this, 44), Ui.dp(this, 44))
            down.layoutParams = LinearLayout.LayoutParams(Ui.dp(this, 44), Ui.dp(this, 44))
            up.alpha = if (i == 0) 0.25f else 1f
            down.alpha = if (i == order.size - 1) 0.25f else 1f
            row.addView(up)
            row.addView(down)
            root.addView(row)
        }
        root.addView(Ui.section(this, "Lirik"))
        root.addView(Ui.switchRow(this, "Cari lirik online otomatis (butuh internet)", Prefs.lyricsOnline(this)) {
            Prefs.setBool(this, "lyrics_online", it)
        })
        val tree = Prefs.str(this, "lyrics_tree")
        val b = com.google.android.material.button.MaterialButton(this)
        b.text = if (tree == null) "Pilih folder file lirik (.lrc)" else "Ganti folder file lirik (.lrc)"
        b.setOnClickListener { pickLyricsFolder.launch(null) }
        root.addView(b)
        if (tree != null) {
            val clear = com.google.android.material.button.MaterialButton(this)
            clear.text = "Lepas folder lirik"
            clear.setOnClickListener {
                Prefs.setStr(this, "lyrics_tree", null)
                Lyrics.resetIndex()
                render()
            }
            root.addView(clear)
        }
    }
    onBannerChange = { render() }
    render()

    AlertDialog.Builder(this)
        .setOnDismissListener { onBannerChange = null }
        .setTitle("Pengaturan musik")
        .setView(Ui.scroll(root))
        .setPositiveButton("Simpan") { _, _ ->
            Prefs.saveTabs(this, order, hidden)
            rebuildTabs()
            refresh()
        }
        .setNegativeButton("Batal", null)
        .show()
}
