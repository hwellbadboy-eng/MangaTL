package com.niven.mangatl

import android.net.Uri
import android.provider.OpenableColumns
import android.widget.Toast

/** Impor model Live2D dari .zip (folder internal privat) + hapus model hasil impor. */
internal fun ChatActivity.pickModelZip() {
    try {
        pickZip.launch(arrayOf("application/zip", "application/x-zip-compressed", "application/octet-stream"))
    } catch (_: Throwable) {
        Toast.makeText(this, "Tidak bisa membuka pemilih file.", Toast.LENGTH_SHORT).show()
    }
}

private fun ChatActivity.displayName(uri: Uri): String {
    try {
        contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use {
            if (it.moveToFirst()) return it.getString(0) ?: "model"
        }
    } catch (_: Throwable) {
    }
    return uri.lastPathSegment?.substringAfterLast('/') ?: "model"
}

internal fun ChatActivity.onZipPicked(uri: Uri) {
    val name = displayName(uri)
    Toast.makeText(this, "Mengimpor model…", Toast.LENGTH_SHORT).show()
    val app = applicationContext
    Thread {
        val res = try {
            ModelStore.importZip(app, uri, name)
        } catch (e: ModelStore.ImportError) {
            runOnUiThread { Sheet.confirm(this, "Impor gagal", e.message ?: "Zip tidak bisa dipakai.", "OK", false) {} }
            return@Thread
        } catch (e: Throwable) {
            runOnUiThread { Sheet.confirm(this, "Impor gagal", "Terjadi kesalahan: ${e.message}", "OK", false) {} }
            return@Thread
        }
        runOnUiThread {
            modelsCache = null
            switchModel(res.id)
            val msg = "Model \"${res.name}\" siap dipakai.\n\n" + res.notes.joinToString("\n") { "• $it" }
            Sheet.confirm(this, "Impor berhasil", msg, "OK", false) {}
            pushState()
        }
    }.start()
}

internal fun ChatActivity.deleteCurrentModel() {
    val id = cfg.id
    if (!ModelStore.isImported(this, id)) {
        Toast.makeText(this, "Model bawaan tidak bisa dihapus.", Toast.LENGTH_SHORT).show()
        return
    }
    Sheet.confirm(this, "Hapus model?", "\"${cfg.name}\" akan dihapus dari aplikasi (file zip aslimu tidak ikut terhapus).", "Hapus", true) {
        destroyAvatar()
        ModelStore.delete(this, id)
        modelsCache = null
        val first = models.firstOrNull()?.first ?: "jian"
        cfg = loadCfg(first)
        prefs().edit().putString("avatar_model", first).apply()
        applyAvatar()
        pushState()
    }
}
