package com.niven.mangatl

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.util.AttributeSet
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.widget.TextView
import androidx.core.graphics.ColorUtils

/** Saklar pil 44x26: aktif = putih dengan titik hitam, mati = abu dengan titik abu muda. */
class PillSwitch @JvmOverloads constructor(ctx: Context, attrs: AttributeSet? = null) : View(ctx, attrs) {
    private val d = resources.displayMetrics.density
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val rect = RectF()
    private var t = 0f
    private var anim: ValueAnimator? = null

    var checked = false
        set(v) {
            if (field == v) return
            field = v
            anim?.cancel()
            val a = ValueAnimator.ofFloat(t, if (v) 1f else 0f)
            a.duration = 200L
            a.addUpdateListener {
                t = it.animatedValue as Float
                invalidate()
            }
            anim = a
            a.start()
        }

    /** Pasang nilai awal tanpa animasi. */
    fun setCheckedNow(v: Boolean) {
        checked = v
        anim?.cancel()
        t = if (v) 1f else 0f
        invalidate()
    }

    override fun onMeasure(widthSpec: Int, heightSpec: Int) {
        setMeasuredDimension((44 * d).toInt(), (26 * d).toInt())
    }

    override fun onDraw(c: Canvas) {
        paint.color = ColorUtils.blendARGB(0xFF333333.toInt(), Color.WHITE, t)
        rect.set(0f, 0f, 44f * d, 26f * d)
        c.drawRoundRect(rect, 13f * d, 13f * d, paint)
        paint.color = ColorUtils.blendARGB(0xFF888888.toInt(), Color.BLACK, t)
        val cx = (3f + 18f * t + 10f) * d
        c.drawCircle(cx, 13f * d, 10f * d, paint)
    }
}

/**
 * Garis seek mini player: tipis 2dp, saat disentuh jadi 4dp dengan bulatan. Area sentuh 24dp.
 * Posisi baru dikirim saat jari diangkat (onDragEnd), bukan tiap geser, supaya lagu tidak tersendat.
 */
class SeekLine @JvmOverloads constructor(ctx: Context, attrs: AttributeSet? = null) : View(ctx, attrs) {
    private val d = resources.displayMetrics.density
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val rect = RectF()

    var progress = 0f
        set(v) {
            field = v.coerceIn(0f, 1f)
            invalidate()
        }

    var dragging = false
        private set

    var onDragStart: (() -> Unit)? = null
    var onDrag: ((Float) -> Unit)? = null

    /** (posisi 0..1, true kalau jari diangkat; false kalau dibatalkan) */
    var onDragEnd: ((Float, Boolean) -> Unit)? = null

    private fun frac(e: MotionEvent): Float =
        if (width <= 0) 0f else (e.x / width).coerceIn(0f, 1f)

    override fun onDraw(c: Canvas) {
        val w = width.toFloat()
        val top = (if (dragging) 10f else 11f) * d
        val h = (if (dragging) 4f else 2f) * d
        paint.color = 0xFF2A2A2A.toInt()
        rect.set(0f, top, w, top + h)
        c.drawRoundRect(rect, 2f * d, 2f * d, paint)
        paint.color = Color.WHITE
        rect.set(0f, top, w * progress, top + h)
        c.drawRoundRect(rect, 2f * d, 2f * d, paint)
        if (dragging) c.drawCircle(w * progress, top + h / 2f, 6f * d, paint)
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                parent?.requestDisallowInterceptTouchEvent(true)
                dragging = true
                progress = frac(e)
                onDragStart?.invoke()
                onDrag?.invoke(progress)
            }

            MotionEvent.ACTION_MOVE -> if (dragging) {
                progress = frac(e)
                onDrag?.invoke(progress)
            }

            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> if (dragging) {
                val ok = e.actionMasked == MotionEvent.ACTION_UP
                if (ok) progress = frac(e)
                dragging = false
                invalidate()
                onDragEnd?.invoke(progress, ok)
            }
        }
        return true
    }

    override fun performClick(): Boolean = super.performClick()
}

/** Tab teks: terpilih = putih tebal dengan garis bawah 2dp; tidak terpilih = abu. */
class TabText(ctx: Context) : TextView(ctx) {
    private val d = resources.displayMetrics.density
    private val line = Paint().apply { color = Color.WHITE }

    var sel = false
        set(v) {
            field = v
            setTextColor(if (v) Color.WHITE else 0xFF8A8A8A.toInt())
            typeface = MusicFonts.face(context, if (v) 700 else 600)
            invalidate()
        }

    init {
        textSize = 15f
        gravity = Gravity.CENTER_VERTICAL
        setPadding((8 * d).toInt(), 0, (8 * d).toInt(), 0)
        setTextColor(0xFF8A8A8A.toInt())
        typeface = MusicFonts.face(ctx, 600)
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        if (sel) {
            canvas.drawRect(
                paddingLeft.toFloat(), height - 2f * d,
                (width - paddingRight).toFloat(), height.toFloat(), line
            )
        }
    }
}
