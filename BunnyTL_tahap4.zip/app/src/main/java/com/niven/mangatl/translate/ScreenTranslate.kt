package com.niven.mangatl

import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.Rect
import android.graphics.RectF
import android.view.View
import com.google.mlkit.vision.common.InputImage
import kotlin.math.abs

// Terjemah layar: OCR area terpilih, terjemah per baris, dan susun item hasil.
// Fungsi ekstensi dari ScreenService; keadaan dan siklus hidup service tetap di ScreenService.kt.

internal fun ScreenService.process(full: Bitmap, auto: Boolean) {
    curAuto = auto
    // Tombol sudah aman muncul lagi: layar sudah terambil.
    main.post {
        fab?.text = "..."
        fab?.visibility = View.VISIBLE
    }

    val cr = cropRect(full, auto)
    val whole = cr.left == 0 && cr.top == 0 && cr.width() == full.width && cr.height() == full.height
    val crop = if (whole) full else Bitmap.createBitmap(full, cr.left, cr.top, cr.width(), cr.height())

    recognizer
        .process(InputImage.fromBitmap(crop, 0))
        .addOnSuccessListener { text ->
            // Pecah blok per baris (ukuran huruf / jarak), buang sampah ikon dan teks di daftar abaikan.
            val groups = Grouping.translatableGroups(text, Grouping.params(this))
            val lineCountOf = HashMap<Rect, Int>()
            for (g in groups) lineCountOf[g.rect] = g.lines
            val found = groups.map { Pair(it.rect, it.text) }
            val pairs = TextUtil.readingOrderPairs(found)
                .filter { TextUtil.isTranslatable(TextUtil.normalizeForModel(it.second)) }
                .take(16)
            curLines = pairs.map { lineCountOf[it.first] ?: 1 }

            if (pairs.isEmpty()) {
                if (curAuto) finishCapture() else showMessage("Tidak ada teks terdeteksi.")
                return@addOnSuccessListener
            }

            val mode = prefs().getInt("pos", 0)
            val alpha = prefs().getInt("ov_alpha2", 100).coerceIn(30, 100) * 255 / 100
            val align = prefs().getInt("ov_align", 0).coerceIn(0, 1)
            main.post {
                ov?.bgAlpha = alpha
                ov?.align = align
            }
            val lines = pairs.map { it.second }
            // Posisi di layar = posisi di potongan + jarak potongan dari kiri/atas layar.
            val boxes = pairs.map {
                Rect(
                    it.first.left + cr.left, it.first.top + cr.top,
                    it.first.right + cr.left, it.first.bottom + cr.top
                )
            }
            val bgs = if (mode == 0) pairs.map { TextUtil.sampleBg(crop, it.first) } else emptyList()

            val key = pairs.joinToString("|") { "${it.second}@${it.first.left / 8},${it.first.top / 8}" }
            if (auto) {
                if (key == lastKey && mode == lastMode) {
                    sameStreak++
                    main.post {
                        ov?.alpha = 1f
                        panel?.alpha = 1f
                    }
                } else {
                    // Dialog baru: buang terjemahan lama dan tampilkan lagi lapisannya.
                    sameStreak = 0
                    main.post {
                        ov?.setItems(emptyList())
                        ov?.alpha = 1f
                        panel?.alpha = 1f
                    }
                }
            }
            if (key == lastKey && mode == lastMode) {
                if (mode == 0 && lastItems.isNotEmpty()) {
                    ov?.setItems(lastItems)
                    finishCapture()
                    return@addOnSuccessListener
                }
                if (mode != 0 && lastOut.isNotEmpty()) {
                    showPanel(lastOut)
                    finishCapture()
                    return@addOnSuccessListener
                }
            }

            if (mode != 0) showPanel("Menerjemahkan...")
            translateLines(lines, boxes, bgs, key, mode)
        }
        .addOnFailureListener { e ->
            fail("OCR gagal: ${e.message}")
        }
}

internal fun ScreenService.render(lines: List<String>, tr: List<String?>): String {
    val parts = tr.indices.mapNotNull { i ->
        val t = tr[i]
        if (t == null) null else t.ifBlank { lines.getOrElse(i) { "" } }
    }
    return if (parts.isEmpty()) "Menerjemahkan..." else parts.joinToString("\n")
}

/** Susun kotak terjemahan yang menimpa teks asli, warnanya mengikuti latar sekitar teks. */
internal fun ScreenService.buildItems(boxes: List<Rect>, bgs: List<Int>, tr: List<String?>): List<OverlayView.Item> {
    val out = ArrayList<OverlayView.Item>()
    for (i in boxes.indices) {
        val t = tr.getOrNull(i)
        if (t.isNullOrBlank()) continue
        val bg = bgs.getOrElse(i) { Color.BLACK }
        val fg = if (TextUtil.luminance(bg) > 140) 0xFF111111.toInt() else Color.WHITE
        out.add(OverlayView.Item(boxes[i], t, bg, fg, curLines.getOrElse(i) { 1 }))
    }
    return out
}

internal fun ScreenService.translateLines(lines: List<String>, boxes: List<Rect>, bgs: List<Int>, key: String, mode: Int) {
    val p = prefs()
    val styles = Gemma.Style.values()
    val style = styles[p.getInt("style", 0).coerceIn(0, styles.size - 1)]
    val glossary = p.getString("glossary", "") ?: ""

    Thread {
        try {
            val model = Gemma.findModel(this)
                ?: throw IllegalStateException("Model .litertlm belum ada")
            // Mode cepat: cache per baris, prompt pendek, hasil muncul bertahap (streaming).
            val res = Gemma.translateFast(
                applicationContext, model, lines, style, glossary,
                onProgress = { tr ->
                    main.post {
                        if (mode == 0) ov?.setItems(buildItems(boxes, bgs, tr))
                        else showPanel(render(lines, tr))
                    }
                }
            )
            lastKey = key
            lastMode = mode
            if (mode == 0) {
                lastItems = buildItems(boxes, bgs, res.lines)
                lastOut = ""
            } else {
                lastOut = render(lines, res.lines)
                lastItems = emptyList()
            }
            main.post {
                if (mode == 0) ov?.setItems(lastItems) else showPanel(lastOut)
                finishCapture()
            }
        } catch (t: Throwable) {
            fail("Gagal: ${t.message}")
        }
    }.start()
}

/** Area custom (pecahan layar) untuk mode tap (auto=false) atau auto (auto=true); null = pakai pilihan "baca ...". */
internal fun ScreenService.areaFor(auto: Boolean): RectF? {
    val p = prefs()
    val key = if (auto) "area_auto" else "area_tap"
    if (p.getInt(key + "_on", 0) != 1) return null
    return parseArea(p.getString(key, "")) ?: RectF(0f, 0.62f, 1f, 1f)
}

internal fun ScreenService.parseArea(raw: String?): RectF? {
    val f = (raw ?: "").split(",").mapNotNull { it.trim().toFloatOrNull() }
    if (f.size != 4) return null
    if (f[2] <= f[0] + 0.02f || f[3] <= f[1] + 0.02f) return null
    return RectF(f[0].coerceIn(0f, 1f), f[1].coerceIn(0f, 1f), f[2].coerceIn(0f, 1f), f[3].coerceIn(0f, 1f))
}

internal fun ScreenService.cropRect(full: Bitmap, auto: Boolean): Rect {
    val a = areaFor(auto)
    if (a != null) {
        val l = (a.left * full.width).toInt().coerceIn(0, full.width - 2)
        val t = (a.top * full.height).toInt().coerceIn(0, full.height - 2)
        val r = (a.right * full.width).toInt().coerceIn(l + 2, full.width)
        val b = (a.bottom * full.height).toInt().coerceIn(t + 2, full.height)
        return Rect(l, t, r, b)
    }
    val frac = when (prefs().getInt("scan", 0)) {
        1 -> 0.5
        2 -> 0.34
        else -> 1.0
    }
    val top = (full.height * (1.0 - frac)).toInt().coerceIn(0, full.height - 1)
    return Rect(0, top, full.width, full.height)
}

/** Sidik jari kasar isi area: 48x27 sel kecerahan. */
internal fun ScreenService.areaSig(full: Bitmap): IntArray {
    val cr = cropRect(full, true)
    val sub = Bitmap.createBitmap(full, cr.left, cr.top, cr.width(), cr.height())
    val sm = Bitmap.createScaledBitmap(sub, 48, 27, true)
    val px = IntArray(48 * 27)
    sm.getPixels(px, 0, 48, 0, 0, 48, 27)
    val out = IntArray(px.size) {
        val c = px[it]
        (299 * Color.red(c) + 587 * Color.green(c) + 114 * Color.blue(c)) / 1000
    }
    if (sm !== sub) sm.recycle()
    if (sub !== full) sub.recycle()
    return out
}

/** Persen sel yang berubah cukup jauh antara dua sidik jari. */
internal fun ScreenService.sigDiffPct(a: IntArray, b: IntArray): Double {
    var n = 0
    for (i in a.indices) if (abs(a[i] - b[i]) > 30) n++
    return n * 100.0 / a.size
}
