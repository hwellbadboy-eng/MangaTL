package com.niven.mangatl

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.View
import android.widget.EditText
import android.widget.TextView
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/** Isi satu folder video: thumbnail, durasi, ukuran, progres tontonan, urutkan, pengaturan. */
class VideoListActivity : MediaActivity() {

    override val kind = 2
    override fun deniedView(): TextView = tvEmpty

    private lateinit var adapter: RowAdapter
    private lateinit var etSearch: EditText
    private lateinit var tvEmpty: TextView
    private var videos: List<Library.Video> = emptyList()
    private var loaded = false
    private var sortMode = 2
    private var bucket = 0L

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_list)
        Fx.enter(this)
        bucket = intent.getLongExtra("bucket", 0L)
        findViewById<TextView>(R.id.tvTitle).text = intent.getStringExtra("name") ?: "Video"
        findViewById<View>(R.id.ibOpen).visibility = View.GONE
        sortMode = Prefs.int(this, "sort_vlist", 2)

        findViewById<View>(R.id.ibSort).setOnClickListener {
            Ui.sortDialog(this, Ui.SORT_VIDEO, sortMode) {
                sortMode = it
                Prefs.setInt(this, "sort_vlist", it)
                refresh()
            }
        }
        findViewById<View>(R.id.ibSettings).setOnClickListener {
            VideoSettings.show(this) { refresh() }
        }

        etSearch = findViewById(R.id.etSearch)
        etSearch.hint = "Cari video"
        tvEmpty = findViewById(R.id.tvEmpty)
        adapter = RowAdapter(lifecycleScope)
        findViewById<RecyclerView>(R.id.list).apply {
            layoutManager = LinearLayoutManager(this@VideoListActivity)
            adapter = this@VideoListActivity.adapter
        }
        etSearch.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun afterTextChanged(s: Editable?) = refresh()
        })
        ensureMedia()
    }

    override fun onStart() {
        super.onStart()
        refresh() // perbarui bilah progres setelah balik dari pemutar
    }

    override fun onMediaReady() {
        tvEmpty.text = "Memuat..."
        tvEmpty.visibility = View.VISIBLE
        lifecycleScope.launch {
            videos = withContext(Dispatchers.IO) { Library.videos(this@VideoListActivity, bucket) }
            loaded = true
            refresh()
        }
    }

    private fun confirmDelete(v: Library.Video) {
        androidx.appcompat.app.AlertDialog.Builder(this)
            .setTitle("Hapus video permanen?")
            .setMessage("\"${v.title}\" (${Library.sizeStr(v.size)}) akan dihapus dari HP dan tidak bisa dikembalikan.")
            .setPositiveButton("Hapus") { _, _ ->
                deleteMedia(listOf(v.uri)) { ok ->
                    if (ok) {
                        val key = v.uri.toString()
                        getSharedPreferences("player_pos", Context.MODE_PRIVATE).edit().remove(key).apply()
                        getSharedPreferences("player_done", Context.MODE_PRIVATE).edit().remove(key).apply()
                        android.widget.Toast.makeText(this, "Video dihapus.", android.widget.Toast.LENGTH_SHORT).show()
                        onMediaReady()
                    }
                }
            }
            .setNegativeButton("Batal", null)
            .show()
    }

    private fun refresh() {
        if (!loaded) return
        val q = etSearch.text.toString().trim().lowercase()
        val shown = Ui.sortBy(
            videos.filter { q.isEmpty() || it.title.lowercase().contains(q) },
            sortMode, { it.title }, { it.dateAdded }, { it.size }
        )
        val prefs = getSharedPreferences("player_pos", Context.MODE_PRIVATE)
        val donePrefs = getSharedPreferences("player_done", Context.MODE_PRIVATE)
        val uris = shown.map { it.uri.toString() }.toTypedArray()
        val rows = shown.mapIndexed { i, v ->
            val pos = prefs.getLong(v.uri.toString(), 0L)
            val pr = if (pos > 0 && v.durationMs > 0) (pos * 100 / v.durationMs).toInt().coerceIn(1, 99) else -1
            val isDone = pos <= 0L && donePrefs.getBoolean(v.uri.toString(), false)
            val status = when {
                pos > 0L && v.durationMs > 0 -> "\u25B6 Berhenti di ${Library.fmt(pos)} dari ${Library.fmt(v.durationMs)}"
                pos > 0L -> "\u25B6 Berhenti di ${Library.fmt(pos)}"
                isDone -> "\u2713 Selesai ditonton"
                else -> null
            }
            Row(
                title = v.title,
                sub = Library.sizeStr(v.size),
                icon = R.drawable.ic_movie,
                thumb = v.uri,
                video = true,
                badge = if (isDone) "\u2713 " + Library.fmt(v.durationMs) else Library.fmt(v.durationMs),
                progress = pr,
                status = status,
                statusDone = isDone,
                onLong = { confirmDelete(v) },
                onClick = {
                    startActivity(
                        Intent(this, VideoActivity::class.java)
                            .putExtra("uris", uris)
                            .putExtra("index", i)
                            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                    )
                }
            )
        }
        adapter.rows = rows
        tvEmpty.text = "Tidak ada video."
        tvEmpty.visibility = if (rows.isEmpty()) View.VISIBLE else View.GONE
    }
}
