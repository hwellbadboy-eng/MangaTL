package com.niven.mangatl

import android.annotation.SuppressLint
import android.content.Context
import android.opengl.GLES20
import android.os.SystemClock
import android.opengl.GLSurfaceView
import android.graphics.PixelFormat
import android.graphics.SurfaceTexture
import android.opengl.EGL14
import android.view.TextureView
import android.util.Log
import android.view.MotionEvent
import android.view.SurfaceHolder
import java.util.concurrent.Executors
import java.util.concurrent.RejectedExecutionException
import com.live2d.sdk.cubism.framework.math.CubismMatrix44
import com.live2d.sdk.cubism.framework.rendering.android.CubismOffscreenManagerAndroid
import com.live2d.sdk.cubism.framework.rendering.android.CubismShaderAndroid
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.FloatBuffer
import javax.microedition.khronos.egl.EGLConfig
import javax.microedition.khronos.opengles.GL10

/**
 * Avatar (Live2D) sebagai tubuh AI di chat. Latar digambar sewarna latar app (#000000).
 * Digambar 30 fps (hemat baterai); berhenti total saat layar di-pause.
 */
class AvatarView(
    context: Context,
    private val cfg: ModelCfg,
    /** true = digambar DI ATAS chat (permukaan transparan, sentuhan diteruskan ke chat). false = di belakang. */
    private val front: Boolean
) : GLSurfaceView(context) {

    val anim = AvatarAnim()

    /** Dipanggil di thread utama kalau model gagal dimuat. */
    var onError: ((String) -> Unit)? = null

    private val rend = AvatarRenderer(context.applicationContext, cfg, anim, front) { msg -> post { onError?.invoke(msg) } }
    private var ticking = false
    private val tick = object : Runnable {
        override fun run() {
            if (!ticking) return
            requestRender()
            postDelayed(this, cfg.frameMs())
        }
    }

    init {
        setEGLContextClientVersion(2)
        setEGLConfigChooser(8, 8, 8, 8, 16, 0)
        // Jangan buang konteks GL saat app ke latar: kembali dari app lain = langsung jalan, tanpa muat ulang tekstur.
        preserveEGLContextOnPause = true
        if (front) {
            // Di depan chat: permukaan di atas jendela dan transparan, jadi chat tetap terlihat di sekitar badan avatar.
            setZOrderOnTop(true)
            holder.setFormat(PixelFormat.TRANSLUCENT)
        }
        anim.usePos = !cfg.params["posX"].isNullOrEmpty() && !cfg.params["posY"].isNullOrEmpty()
        setRenderer(rend)
        renderMode = RENDERMODE_WHEN_DIRTY
    }

    // GLSurfaceView.surfaceChanged MENUNGGU thread GL selesai menggambar satu frame, di thread utama. Saat thread GL
    // lagi mengompilasi shader Live2D (beberapa detik di Adreno, terutama pertama kali), layar macet dan Android
    // menampilkan "tidak menanggapi" (ANR). Jadi pemberitahuan ukuran baru diteruskan lewat thread lain.
    private val resizeExec = Executors.newSingleThreadExecutor { r ->
        Thread(r, "avatar-resize").apply { isDaemon = true }
    }

    override fun surfaceChanged(holder: SurfaceHolder, format: Int, w: Int, h: Int) {
        try {
            resizeExec.execute {
                try {
                    super@AvatarView.surfaceChanged(holder, format, w, h)
                } catch (_: Throwable) {
                }
            }
        } catch (_: RejectedExecutionException) {
        }
    }

    override fun onDetachedFromWindow() {
        super.onDetachedFromWindow()
        resizeExec.shutdown()
    }

    override fun onResume() {
        super.onResume()
        ticking = true
        removeCallbacks(tick)
        post(tick)
    }

    override fun onPause() {
        ticking = false
        removeCallbacks(tick)
        super.onPause()
    }

    // ---- geser avatar (mode di depan chat) ----
    fun dragX() = rend.dragX
    fun dragY() = rend.dragY

    fun setDrag(x: Float, y: Float) {
        rend.dragX = x.coerceIn(-1.6f, 1.6f)
        rend.dragY = y.coerceIn(-1.6f, 1.6f)
        requestRender()
    }

    private var lastDragT = 0L

    /** Geser dalam piksel layar (jari). Kecepatan geser diteruskan ke animasi supaya badan/rambut/ekor ikut terayun. */
    fun dragBy(dxPx: Float, dyPx: Float) {
        val w = width.coerceAtLeast(1)
        val h = height.coerceAtLeast(1)
        val now = SystemClock.uptimeMillis()
        val dt = (now - lastDragT).coerceIn(8L, 100L) / 1000f
        lastDragT = now
        anim.dragMove(dxPx / w * 2f / dt, -dyPx / h * 2f / dt)
        setDrag(rend.dragX + dxPx / w * 2f, rend.dragY - dyPx / h * 2f)
    }

    // ---- zoom dua jari ----
    fun userScale() = rend.userScale

    fun setUserScale(sc: Float) {
        rend.userScale = sc.coerceIn(0.35f, 3.5f)
        requestLayout()
        requestRender()
    }

    /** Zoom sebesar 'factor' dengan titik fokus (x, y) piksel view tetap diam (seperti zoom foto). */
    fun pinchBy(factor: Float, fx: Float, fy: Float) {
        val old = rend.userScale
        val ns = (old * factor).coerceIn(0.35f, 3.5f)
        if (ns == old) return
        val f = rend.xf
        val w = width.coerceAtLeast(1).toFloat()
        val h = height.coerceAtLeast(1).toFloat()
        val cx = fx / w * 2f - 1f
        val cy = if (f != null && f[7] > 0f) ((h - fy) - f[6]) / f[7] * 2f - 1f else 1f - fy / h * 2f
        val r = ns / old
        rend.userScale = ns
        setDrag(cx - (cx - rend.dragX) * r, cy - (cy - rend.dragY) * r)
    }

    fun setDragging(on: Boolean) {
        anim.setDragging(on)
    }

    /**
     * Tinggi layar 'seolah' tanpa keyboard (px). Avatar digambar seukuran ini dan menempel di atas, jadi saat keyboard muncul
     * dan permukaan mengecil, avatar tidak ikut mengecil / terdorong ke atas. 0 = ikuti ukuran permukaan.
     */
    fun setVirtualHeight(px: Int) {
        rend.virtualH = px.coerceAtLeast(0)
        requestRender()
    }

    /**
     * Di depan chat: daerah (px view; l, t, r, b, radius per lubang) yang dilubangi transparan SETELAH avatar digambar,
     * supaya kolom input & tombol Mic tetap kelihatan dan avatar boleh menjulur sampai dasar layar.
     */
    fun setHoles(a: FloatArray) {
        rend.holes = a
        requestRender()
    }

    /** Titik layar (piksel view) -> pecahan kanvas model (0..1 dari kiri-atas). null kalau belum digambar. */
    fun canvasFrac(x: Float, y: Float): FloatArray? {
        val f = rend.xf ?: return null
        val sx = f[0]
        val sy = f[1]
        val tx = f[2]
        val ty = f[3]
        val cw = f[4]
        val ch = f[5]
        val vy = f[6]
        val vh = f[7]
        val h = f[8]
        val w = f[9]
        if (sx == 0f || sy == 0f || vh <= 0f || w <= 0f) return null
        val cx = x / w * 2f - 1f
        val cy = ((h - y) - vy) / vh * 2f - 1f
        val xm = (cx - tx) / sx
        val ym = (cy - ty) / sy
        return floatArrayOf(xm / cw + 0.5f, 0.5f - ym / ch)
    }

    /** Dipanggil (thread utama) tiap ketukan di avatar: nama zona yang kena ("-" kalau di luar zona) dan koordinat kanvas 0..1. */
    var onZone: ((String, Float, Float) -> Unit)? = null

    /** Sentuhan di titik (x, y): kalau kena zona tubuh model (dada, paha, dll.) picu reaksinya. true = ada reaksi. */
    fun pokeAt(x: Float, y: Float): Boolean {
        val f = canvasFrac(x, y) ?: return false
        for (z in cfg.touch) {
            if (f[0] in z.x0..z.x1 && f[1] in z.y0..z.y1) {
                anim.poke(z.react, z.strength)
                if (z.expr.isNotEmpty()) anim.triggerExpr(z.expr, if (z.react == "shy") 5f else 3f)
                onZone?.invoke(z.name, f[0], f[1])
                return true
            }
        }
        onZone?.invoke("-", f[0], f[1])
        return false
    }

    /** Apakah piksel (x, y) di view ini bagian badan avatar (alpha > 0)? Dijawab asynchronous, hasil di thread utama. */
    fun probeHit(x: Float, y: Float, cb: (Boolean) -> Unit) {
        rend.probeCb = { hit -> post { cb(hit) } }
        rend.probe = floatArrayOf(x, y)
        requestRender()
    }

    /** Pudarkan 'px' paling bawah view jadi transparan (halus), supaya badan avatar tidak terpotong kasar. 0 = mati. */
    fun setFadeBottom(px: Int) {
        rend.fadePx = px.coerceAtLeast(0)
        requestRender()
    }

    /** Lepas model + tekstur dari memori GPU (dipakai saat avatar dimatikan). onDone jalan di thread utama. */
    fun releaseModel(onDone: () -> Unit) {
        queueEvent {
            rend.releaseModel()
            post { onDone() }
        }
        requestRender()
    }

    @SuppressLint("ClickableViewAccessibility")
    override fun onTouchEvent(e: MotionEvent): Boolean {
        if (front) return false   // di depan chat: sentuhan diteruskan ke daftar chat di bawahnya
        val w = width.coerceAtLeast(1)
        val h = height.coerceAtLeast(1)
        val nx = (e.x / w * 2f - 1f).coerceIn(-1f, 1f)
        val ny = (1f - e.y / h * 2f).coerceIn(-1f, 1f)
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN, MotionEvent.ACTION_MOVE -> anim.touch(nx, ny, true)
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> anim.touch(nx, ny, false)
        }
        return true
    }
}

private class AvatarRenderer(
    private val appCtx: Context,
    private val cfg: ModelCfg,
    private val anim: AvatarAnim,
    private val front: Boolean,
    private val fail: (String) -> Unit
) : GLSurfaceView.Renderer {

    @Volatile var wantModel = true
    @Volatile var holes: FloatArray = FloatArray(0)
    @Volatile var virtualH = 0
    @Volatile var fadePx = 0
    private var fadeProg = 0
    private var fadePos = -1
    private var fadeK = -1
    private var fadeBuf: FloatBuffer? = null
    private var fadeKey = 0
    // lubang mode depan: satu tekstur mask (dibuat ulang hanya kalau posisi lubang / ukuran berubah) + beberapa quad kecil
    private var holeProg = 0
    private var holePos = -1
    private var holeSamp = -1
    private var holeTex = 0
    private var holeKey: FloatArray? = null
    private var holeGeo: FloatBuffer? = null
    private var holeN = 0
    private var holeW = 0
    private var holeH = 0
    private var rtW = 0
    private var rtH = 0
    @Volatile var dragX = 0f
    @Volatile var dragY = 0f
    @Volatile var userScale = 1f
    @Volatile var xf: FloatArray? = null
    @Volatile var probe: FloatArray? = null
    @Volatile var probeCb: ((Boolean) -> Unit)? = null
    private var model: AvatarModel? = null
    private var loading: AvatarModel? = null
    private var w = 0
    private var h = 0
    private var last = 0L
    private var fadeStart = 0L
    private var failed = false
    private val proj = CubismMatrix44.create()

    init {
        AvatarCore.ensure(appCtx)
    }

    private fun compile(type: Int, src: String): Int {
        val sh = GLES20.glCreateShader(type)
        GLES20.glShaderSource(sh, src)
        GLES20.glCompileShader(sh)
        val ok = IntArray(1)
        GLES20.glGetShaderiv(sh, GLES20.GL_COMPILE_STATUS, ok, 0)
        if (ok[0] == 0) {
            val log = GLES20.glGetShaderInfoLog(sh)
            GLES20.glDeleteShader(sh)
            throw IllegalStateException(log)
        }
        return sh
    }

    private fun initHole() {
        holeProg = 0
        holeTex = 0
        holeKey = null
        holeGeo = null
        holeN = 0
        holeW = 0
        holeH = 0
        try {
            val vs = compile(GLES20.GL_VERTEX_SHADER,
                "attribute vec2 a;varying vec2 v;void main(){gl_Position=vec4(a,0.0,1.0);v=vec2(a.x*0.5+0.5,0.5-a.y*0.5);}")
            val fs = compile(GLES20.GL_FRAGMENT_SHADER,
                "#ifdef GL_FRAGMENT_PRECISION_HIGH\nprecision highp float;\n#else\nprecision mediump float;\n#endif\n" +
                    "uniform sampler2D t;varying vec2 v;void main(){float m=texture2D(t,v).a;gl_FragColor=vec4(m,m,m,m);}")
            val pr = GLES20.glCreateProgram()
            GLES20.glAttachShader(pr, vs)
            GLES20.glAttachShader(pr, fs)
            GLES20.glLinkProgram(pr)
            val ok = IntArray(1)
            GLES20.glGetProgramiv(pr, GLES20.GL_LINK_STATUS, ok, 0)
            if (ok[0] == 0) throw IllegalStateException(GLES20.glGetProgramInfoLog(pr))
            holeProg = pr
            holePos = GLES20.glGetAttribLocation(pr, "a")
            holeSamp = GLES20.glGetUniformLocation(pr, "t")
        } catch (t: Throwable) {
            Log.e("Avatar", "Shader lubang gagal dibuat (pakai cara lama): ${t.message}")
            holeProg = 0
        }
    }

    private fun initFade() {
        fadeProg = 0
        try {
            val vs = compile(GLES20.GL_VERTEX_SHADER,
                "attribute vec2 a;attribute float k;varying float vk;void main(){gl_Position=vec4(a,0.0,1.0);vk=k;}")
            val fs = compile(GLES20.GL_FRAGMENT_SHADER,
                "precision mediump float;varying float vk;void main(){float s=clamp(vk,0.0,1.0);s=s*s*(3.0-2.0*s);gl_FragColor=vec4(s,s,s,s);}")
            val pr = GLES20.glCreateProgram()
            GLES20.glAttachShader(pr, vs)
            GLES20.glAttachShader(pr, fs)
            GLES20.glLinkProgram(pr)
            val ok = IntArray(1)
            GLES20.glGetProgramiv(pr, GLES20.GL_LINK_STATUS, ok, 0)
            if (ok[0] == 0) throw IllegalStateException(GLES20.glGetProgramInfoLog(pr))
            fadeProg = pr
            fadePos = GLES20.glGetAttribLocation(pr, "a")
            fadeK = GLES20.glGetAttribLocation(pr, "k")
        } catch (t: Throwable) {
            Log.e("Avatar", "Shader pudar gagal dibuat: ${t.message}")
            fadeProg = 0
        }
        fadeBuf = null
    }

    /** Kalikan piksel di 'fadePx' paling bawah dengan gradien 0..1 (RGBA sekaligus; permukaan premultiplied), jadi memudar ke transparan. */
    private fun drawFade() {
        val fp = fadePx
        if (fp <= 0 || fadeProg == 0 || w <= 0 || h <= 0) return
        val key = fp * 100003 + h
        if (fadeBuf == null || fadeKey != key) {
            val top = (fp.toFloat() / h).coerceAtMost(1f) * 2f - 1f
            val b = ByteBuffer.allocateDirect(4 * 3 * 4).order(ByteOrder.nativeOrder()).asFloatBuffer()
            b.put(-1f).put(-1f).put(0f)
            b.put(1f).put(-1f).put(0f)
            b.put(-1f).put(top).put(1f)
            b.put(1f).put(top).put(1f)
            b.position(0)
            fadeBuf = b
            fadeKey = key
        }
        val buf = fadeBuf ?: return
        GLES20.glBindFramebuffer(GLES20.GL_FRAMEBUFFER, 0)
        GLES20.glViewport(0, 0, w, h)
        GLES20.glDisable(GLES20.GL_DEPTH_TEST)
        GLES20.glDisable(GLES20.GL_CULL_FACE)
        GLES20.glDisable(GLES20.GL_SCISSOR_TEST)
        GLES20.glDisable(GLES20.GL_STENCIL_TEST)
        GLES20.glBindBuffer(GLES20.GL_ARRAY_BUFFER, 0)
        GLES20.glEnable(GLES20.GL_BLEND)
        GLES20.glBlendFunc(GLES20.GL_ZERO, GLES20.GL_SRC_COLOR)
        GLES20.glUseProgram(fadeProg)
        GLES20.glEnableVertexAttribArray(fadePos)
        GLES20.glEnableVertexAttribArray(fadeK)
        buf.position(0)
        GLES20.glVertexAttribPointer(fadePos, 2, GLES20.GL_FLOAT, false, 12, buf)
        buf.position(2)
        GLES20.glVertexAttribPointer(fadeK, 1, GLES20.GL_FLOAT, false, 12, buf)
        GLES20.glDrawArrays(GLES20.GL_TRIANGLE_STRIP, 0, 4)
        GLES20.glDisableVertexAttribArray(fadePos)
        GLES20.glDisableVertexAttribArray(fadeK)
        buf.position(0)
        GLES20.glBlendFunc(GLES20.GL_SRC_ALPHA, GLES20.GL_ONE_MINUS_SRC_ALPHA)
    }

    override fun onSurfaceCreated(gl: GL10?, config: EGLConfig?) {
        // Konteks GL baru: semua resource GL yang lama sudah tidak berlaku.
        model?.release(false)
        model = null
        loading?.release(false)
        loading = null
        failed = false
        CubismOffscreenManagerAndroid.releaseInstance()
        try {
            CubismShaderAndroid.getInstance().releaseInvalidShaderProgram()
        } catch (_: Throwable) {
        }
        CubismShaderAndroid.deleteInstance()
        GLES20.glEnable(GLES20.GL_BLEND)
        GLES20.glBlendFunc(GLES20.GL_SRC_ALPHA, GLES20.GL_ONE_MINUS_SRC_ALPHA)
        last = 0L
        fadeStart = 0L
        initFade()
        initHole()
        if (wantModel) AvatarTex.prefetch(appCtx, cfg.texturePaths())   // mulai decode tekstur lebih awal
    }

    override fun onSurfaceChanged(gl: GL10?, width: Int, height: Int) {
        val changed = width != w || height != h
        w = width
        h = height
        GLES20.glViewport(0, 0, width, height)
        if (changed) {
            rtW = 0   // paksa sinkron ulang ukuran render target pada frame berikutnya
            rtH = 0
        }
    }

    fun releaseModel() {
        wantModel = false
        loading?.release(true)
        loading = null
        model?.release(true)
        model = null
    }

    override fun onDrawFrame(gl: GL10?) {
        if (front) GLES20.glClearColor(0f, 0f, 0f, 0f) else GLES20.glClearColor(9f / 255f, 9f / 255f, 10f / 255f, 1f)
        GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT or GLES20.GL_DEPTH_BUFFER_BIT)
        if (w <= 0 || h <= 0) return

        // Muat bertahap: frame 1 = moc3 + shader, lalu satu tekstur per frame (tidak ada frame panjang).
        if (model == null) {
            probe?.let {
                probe = null
                probeCb?.invoke(false)
                probeCb = null
            }
            if (!wantModel || failed) return
            try {
                val l = loading
                if (l == null) {
                    val n = AvatarModel(appCtx, cfg)
                    if (n.begin(w, h)) {
                        loading = n
                    } else {
                        n.release(true)
                        failed = true
                        fail("model tidak terbentuk (cek file .moc3)")
                    }
                } else if (l.step()) {
                    model = l
                    loading = null
                    last = 0L
                    fadeStart = 0L
                }
            } catch (t: Throwable) {
                failed = true
                loading?.release(true)
                loading = null
                Log.e("Avatar", "Gagal muat model", t)
                fail(t.message ?: t::class.java.simpleName)
            }
            return
        }
        val m = model ?: return

        val now = System.nanoTime()
        val dt = if (last == 0L) 0.033f else ((now - last) / 1_000_000_000f).coerceIn(0.001f, 0.1f)
        last = now
        if (fadeStart == 0L) fadeStart = now
        val f = ((now - fadeStart) / 450_000_000f).coerceIn(0f, 1f)
        m.setFade(f * f * (3f - 2f * f))   // muncul halus, bukan tiba-tiba

        // Kalau virtualH > tinggi permukaan (keyboard muncul / kolom input di depan), avatar tetap digambar seukuran virtualH.
        val rsv = if (virtualH > h) -(virtualH - h) else 0
        val vw = w
        val vh = (h - rsv).coerceAtLeast(1)
        GLES20.glViewport(0, rsv, vw, vh)
        // Render target offscreen (blend mode / mask) HARUS sama dengan area gambar, kalau tidak lapisan blend meleset
        // dan muncul tepi putih di sekitar mulut / hidung.
        if (vw != rtW || vh != rtH) {
            m.setRenderTargetSize(vw, vh)
            rtW = vw
            rtH = vh
        }

        val offscreen = CubismOffscreenManagerAndroid.getInstance()
        offscreen.beginFrameProcess()

        // Pas: seluruh badan avatar muat penuh di area. Titik asal koordinat model sudah di tengah kanvas,
        // jadi TIDAK perlu setCenterPosition (itu yang bikin avatar melorot ke pojok kiri-bawah).
        val aspect = vw.toFloat() / vh.toFloat()
        val displayRatio = vh.toFloat() / vw.toFloat()
        proj.loadIdentity()
        val z = cfg.zoom * userScale
        if (m.canvasRatio() < displayRatio) {
            m.getModelMatrix().setWidth(2.0f * z)
            proj.scale(1.0f, aspect)
        } else {
            m.getModelMatrix().setHeight(2.0f * z)
            proj.scale(1.0f / aspect, 1.0f)
        }
        if (cfg.offsetY != 0f || dragX != 0f || dragY != 0f) proj.translate(dragX, cfg.offsetY + dragY)   // geser dalam satuan layar (2.0 = tinggi penuh)

        m.update(dt, anim)
        m.draw(proj)
        // simpan transformasi akhir (kanvas -> layar) untuk menerjemahkan sentuhan ke bagian tubuh
        val ar = proj.array
        val cm = m.getModel()
        xf = floatArrayOf(ar[0], ar[5], ar[12], ar[13], cm.canvasWidth, cm.canvasHeight, rsv.toFloat(), vh.toFloat(), h.toFloat(), w.toFloat())

        offscreen.endFrameProcess()
        offscreen.releaseStaleRenderTextures()

        drawFade()
        punchHoles()
        answerProbe()
    }

    /** Mode depan: hapus piksel avatar di atas kolom input / tombol (bentuk pil), jadi yang tampil lagi adalah kolom input di bawahnya. */
    private fun punchHoles() {
        val hs = holes
        if (!front || hs.size < 5) return
        if (holeProg != 0 && punchHolesMask(hs)) return
        punchHolesLegacy(hs)
    }

    /** Bangun tekstur mask (1 = tetap, 0 = lubang, tepi halus) dan quad kecil per lubang. Hanya dipanggil saat lubang / ukuran berubah. */
    private fun buildHoleMask(hs: FloatArray) {
        val bmp = android.graphics.Bitmap.createBitmap(w, h, android.graphics.Bitmap.Config.ALPHA_8)
        try {
            bmp.eraseColor(0xFF000000.toInt())
            val c = android.graphics.Canvas(bmp)
            val p = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG)
            p.xfermode = android.graphics.PorterDuffXfermode(android.graphics.PorterDuff.Mode.CLEAR)
            val rf = android.graphics.RectF()
            val n = hs.size / 5
            val g = ByteBuffer.allocateDirect(n * 8 * 4).order(ByteOrder.nativeOrder()).asFloatBuffer()
            var i = 0
            while (i + 4 < hs.size) {
                val l = hs[i]
                val t = hs[i + 1]
                val r = hs[i + 2]
                val b = hs[i + 3]
                val rad = minOf(hs[i + 4], (b - t) / 2f, (r - l) / 2f).coerceAtLeast(0f)
                if (r > l && b > t) {
                    rf.set(l, t, r, b)
                    c.drawRoundRect(rf, rad, rad, p)
                }
                val x0 = (l - 1f) / w * 2f - 1f
                val x1 = (r + 1f) / w * 2f - 1f
                val y0 = 1f - (t - 1f) / h * 2f
                val y1 = 1f - (b + 1f) / h * 2f
                g.put(x0).put(y0).put(x1).put(y0).put(x0).put(y1).put(x1).put(y1)
                i += 5
            }
            g.position(0)
            holeGeo = g
            holeN = n
            if (holeTex == 0) {
                val ids = IntArray(1)
                GLES20.glGenTextures(1, ids, 0)
                holeTex = ids[0]
            }
            GLES20.glActiveTexture(GLES20.GL_TEXTURE0)
            GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, holeTex)
            android.opengl.GLUtils.texImage2D(GLES20.GL_TEXTURE_2D, 0, bmp, 0)
            GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_MIN_FILTER, GLES20.GL_LINEAR)
            GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_MAG_FILTER, GLES20.GL_LINEAR)
            GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_WRAP_S, GLES20.GL_CLAMP_TO_EDGE)
            GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_WRAP_T, GLES20.GL_CLAMP_TO_EDGE)
            holeW = w
            holeH = h
        } finally {
            bmp.recycle()
        }
    }

    /** Lubang lewat SATU tekstur mask: beberapa quad kecil mengalikan piksel (RGBA, premultiplied) dengan 0 di dalam lubang. false = gagal, pakai cara lama. */
    private fun punchHolesMask(hs: FloatArray): Boolean {
        try {
            val key = holeKey
            if (key == null || !key.contentEquals(hs) || holeW != w || holeH != h) {
                buildHoleMask(hs)
                holeKey = hs.copyOf()
            }
            val geo = holeGeo ?: return false
            if (holeN <= 0 || holeTex == 0) return false
            GLES20.glBindFramebuffer(GLES20.GL_FRAMEBUFFER, 0)
            GLES20.glViewport(0, 0, w, h)
            GLES20.glDisable(GLES20.GL_DEPTH_TEST)
            GLES20.glDisable(GLES20.GL_CULL_FACE)
            GLES20.glDisable(GLES20.GL_SCISSOR_TEST)
            GLES20.glDisable(GLES20.GL_STENCIL_TEST)
            GLES20.glBindBuffer(GLES20.GL_ARRAY_BUFFER, 0)
            GLES20.glEnable(GLES20.GL_BLEND)
            GLES20.glBlendFunc(GLES20.GL_ZERO, GLES20.GL_SRC_COLOR)
            GLES20.glUseProgram(holeProg)
            GLES20.glActiveTexture(GLES20.GL_TEXTURE0)
            GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, holeTex)
            GLES20.glUniform1i(holeSamp, 0)
            GLES20.glEnableVertexAttribArray(holePos)
            geo.position(0)
            GLES20.glVertexAttribPointer(holePos, 2, GLES20.GL_FLOAT, false, 8, geo)
            for (k in 0 until holeN) GLES20.glDrawArrays(GLES20.GL_TRIANGLE_STRIP, k * 4, 4)
            GLES20.glDisableVertexAttribArray(holePos)
            GLES20.glBlendFunc(GLES20.GL_SRC_ALPHA, GLES20.GL_ONE_MINUS_SRC_ALPHA)
            return true
        } catch (t: Throwable) {
            Log.e("Avatar", "Lubang via mask gagal, pakai cara lama: ${t.message}")
            holeProg = 0
            GLES20.glBlendFunc(GLES20.GL_SRC_ALPHA, GLES20.GL_ONE_MINUS_SRC_ALPHA)
            return false
        }
    }

    /** Cara lama (cadangan): puluhan glClear ber-scissor per frame. */
    private fun punchHolesLegacy(hs: FloatArray) {
        GLES20.glBindFramebuffer(GLES20.GL_FRAMEBUFFER, 0)
        GLES20.glViewport(0, 0, w, h)
        GLES20.glEnable(GLES20.GL_SCISSOR_TEST)
        GLES20.glClearColor(0f, 0f, 0f, 0f)
        fun clr(x0: Float, y0: Float, x1: Float, y1: Float) {
            val ix0 = x0.toInt().coerceIn(0, w)
            val ix1 = x1.toInt().coerceIn(0, w)
            val iy0 = y0.toInt().coerceIn(0, h)
            val iy1 = y1.toInt().coerceIn(0, h)
            if (ix1 <= ix0 || iy1 <= iy0) return
            GLES20.glScissor(ix0, h - iy1, ix1 - ix0, iy1 - iy0)
            GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT)
        }
        var i = 0
        while (i + 4 < hs.size) {
            val l = hs[i]; val t = hs[i + 1]; val r = hs[i + 2]; val b = hs[i + 3]
            val rad = minOf(hs[i + 4], (b - t) / 2f, (r - l) / 2f)
            clr(l, t + rad, r, b - rad)
            val step = 3f
            var y = 0f
            while (y < rad) {
                // Inset dihitung di tepi LUAR potongan (hasilnya sedikit lebih sempit dari pil), jadi tidak ada sudut hitam kotak yang nongol.
                val dy = rad - y
                val inset = rad - Math.sqrt((rad * rad - dy * dy).coerceAtLeast(0f).toDouble()).toFloat()
                val h2 = minOf(step, rad - y)
                clr(l + inset, t + y, r - inset, t + y + h2)
                clr(l + inset, b - y - h2, r - inset, b - y)
                y += step
            }
            i += 5
        }
        GLES20.glDisable(GLES20.GL_SCISSOR_TEST)
    }

    /** Jawab pertanyaan "apakah piksel ini badan avatar?" dengan membaca satu piksel dari frame yang baru digambar. */
    private fun answerProbe() {
        val pr = probe ?: return
        probe = null
        val cb = probeCb
        probeCb = null
        var hit = false
        try {
            GLES20.glBindFramebuffer(GLES20.GL_FRAMEBUFFER, 0)
            val buf = ByteBuffer.allocateDirect(4).order(ByteOrder.nativeOrder())
            val px = pr[0].toInt().coerceIn(0, w - 1)
            val py = (h - 1 - pr[1].toInt()).coerceIn(0, h - 1)
            GLES20.glReadPixels(px, py, 1, 1, GLES20.GL_RGBA, GLES20.GL_UNSIGNED_BYTE, buf)
            hit = (buf.get(3).toInt() and 0xff) > 10
        } catch (_: Throwable) {
        }
        cb?.invoke(hit)
    }
}

/**
 * Versi TextureView dari AvatarView: digambar sebagai view biasa (alpha asli, urutan lapisan normal), jadi bisa ditaruh
 * DI BAWAH view lain (ikon, visualizer) tanpa melubangi jendela. Dipakai avatar di layar Sedang diputar.
 */
class AvatarTexView(
    context: Context,
    private val cfg: ModelCfg
) : TextureView(context), TextureView.SurfaceTextureListener {

    val anim = AvatarAnim()

    /** Dipanggil di thread utama kalau model gagal dimuat. */
    var onError: ((String) -> Unit)? = null

    private val rend = AvatarRenderer(context.applicationContext, cfg, anim, true) { msg -> post { onError?.invoke(msg) } }
    private var glThread: GlThread? = null
    private var paused = true

    init {
        isOpaque = false
        surfaceTextureListener = this
        anim.usePos = !cfg.params["posX"].isNullOrEmpty() && !cfg.params["posY"].isNullOrEmpty()
    }

    /** Pudarkan 'px' paling bawah jadi transparan (halus). 0 = mati. */
    fun setFadeBottom(px: Int) {
        rend.fadePx = px.coerceAtLeast(0)
    }

    fun onResume() {
        paused = false
        glThread?.setPaused(false)
    }

    fun onPause() {
        paused = true
        glThread?.setPaused(true)
    }

    override fun onSurfaceTextureAvailable(st: SurfaceTexture, width: Int, height: Int) {
        glThread?.quitNow()
        val t = GlThread(st, width, height)
        t.setPaused(paused)
        glThread = t
        t.start()
    }

    override fun onSurfaceTextureSizeChanged(st: SurfaceTexture, width: Int, height: Int) {
        glThread?.resize(width, height)
    }

    override fun onSurfaceTextureDestroyed(st: SurfaceTexture): Boolean {
        glThread?.quitNow()
        glThread = null
        return true
    }

    override fun onSurfaceTextureUpdated(st: SurfaceTexture) {}

    private inner class GlThread(private val tex: SurfaceTexture, w0: Int, h0: Int) : Thread("avatar-tex") {
        private val lock = Object()
        @Volatile private var quit = false
        @Volatile private var pausedT = true
        @Volatile private var w = w0
        @Volatile private var h = h0
        @Volatile private var sizeDirty = false

        fun setPaused(p: Boolean) {
            synchronized(lock) {
                pausedT = p
                lock.notifyAll()
            }
        }

        fun resize(nw: Int, nh: Int) {
            w = nw
            h = nh
            sizeDirty = true
        }

        fun quitNow() {
            synchronized(lock) {
                quit = true
                lock.notifyAll()
            }
        }

        override fun run() {
            var dpy: android.opengl.EGLDisplay? = null
            var ctx: android.opengl.EGLContext? = null
            var surf: android.opengl.EGLSurface? = null
            try {
                dpy = EGL14.eglGetDisplay(EGL14.EGL_DEFAULT_DISPLAY)
                val ver = IntArray(2)
                if (!EGL14.eglInitialize(dpy, ver, 0, ver, 1)) throw IllegalStateException("EGL init gagal")
                val attr = intArrayOf(
                    EGL14.EGL_RED_SIZE, 8, EGL14.EGL_GREEN_SIZE, 8, EGL14.EGL_BLUE_SIZE, 8, EGL14.EGL_ALPHA_SIZE, 8,
                    EGL14.EGL_DEPTH_SIZE, 16, EGL14.EGL_STENCIL_SIZE, 0,
                    EGL14.EGL_RENDERABLE_TYPE, EGL14.EGL_OPENGL_ES2_BIT, EGL14.EGL_NONE
                )
                val cfgs = arrayOfNulls<android.opengl.EGLConfig>(1)
                val num = IntArray(1)
                if (!EGL14.eglChooseConfig(dpy, attr, 0, cfgs, 0, 1, num, 0) || num[0] <= 0) throw IllegalStateException("EGL config tidak ada")
                ctx = EGL14.eglCreateContext(dpy, cfgs[0], EGL14.EGL_NO_CONTEXT, intArrayOf(EGL14.EGL_CONTEXT_CLIENT_VERSION, 2, EGL14.EGL_NONE), 0)
                surf = EGL14.eglCreateWindowSurface(dpy, cfgs[0], tex, intArrayOf(EGL14.EGL_NONE), 0)
                if (!EGL14.eglMakeCurrent(dpy, surf, surf, ctx)) throw IllegalStateException("EGL makeCurrent gagal")
                rend.onSurfaceCreated(null, null)
                rend.onSurfaceChanged(null, w, h)
                val frameNs = 1_000_000_000L / cfg.fps.coerceIn(10, 60)
                var nextNs = System.nanoTime()
                while (!quit) {
                    synchronized(lock) {
                        while (pausedT && !quit) { lock.wait(250L); nextNs = System.nanoTime() }
                    }
                    if (quit) break
                    if (sizeDirty) {
                        sizeDirty = false
                        rend.onSurfaceChanged(null, w, h)
                    }
                    rend.onDrawFrame(null)
                    EGL14.eglSwapBuffers(dpy, surf)
                    // tenggat absolut: selang antar frame rata (tidak kumulatif jitter). Kalau ketinggalan > 1 frame, mulai ulang tenggat.
                    nextNs += frameNs
                    val waitNs = nextNs - System.nanoTime()
                    if (waitNs > 0) sleep(waitNs / 1_000_000L, (waitNs % 1_000_000L).toInt())
                    else if (waitNs < -frameNs) nextNs = System.nanoTime()
                }
            } catch (_: InterruptedException) {
            } catch (t: Throwable) {
                Log.e("Avatar", "Thread GL gagal: ${t.message}")
                post { onError?.invoke(t.message ?: "EGL gagal") }
            } finally {
                try {
                    if (dpy != null) {
                        EGL14.eglMakeCurrent(dpy, EGL14.EGL_NO_SURFACE, EGL14.EGL_NO_SURFACE, EGL14.EGL_NO_CONTEXT)
                        if (surf != null) EGL14.eglDestroySurface(dpy, surf)
                        if (ctx != null) EGL14.eglDestroyContext(dpy, ctx)
                        EGL14.eglTerminate(dpy)
                    }
                } catch (_: Throwable) {
                }
            }
        }
    }
}
