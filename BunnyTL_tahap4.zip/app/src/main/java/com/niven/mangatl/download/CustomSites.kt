package com.niven.mangatl

import android.content.Context
import android.net.Uri
import org.json.JSONArray
import org.json.JSONObject

/** Situs login buatan pengguna (tombol "+ Tambah" di popup login). Disimpan di SharedPreferences. */
object CustomSites {
    const val MAX = 30

    /** Salinan terakhir daftar situs, supaya DlCookies.siteFor() tidak butuh Context. Dihangatkan lewat [load]. */
    @Volatile
    var cached: List<LoginSite> = emptyList()
        private set

    private fun sp(ctx: Context) = ctx.applicationContext.getSharedPreferences("dl_custom_sites", Context.MODE_PRIVATE)

    fun load(ctx: Context): List<LoginSite> {
        val raw = sp(ctx).getString("list", "[]") ?: "[]"
        val out = runCatching {
            val a = JSONArray(raw)
            (0 until a.length()).mapNotNull {
                val o = a.getJSONObject(it)
                val u = o.optString("u")
                val k = keyOf(u) ?: return@mapNotNull null
                LoginSite(o.optString("l").ifBlank { k }, k, u)
            }
        }.getOrDefault(emptyList())
        cached = out
        return out
    }

    private fun save(ctx: Context, list: List<LoginSite>) {
        val a = JSONArray()
        list.forEach { a.put(JSONObject().put("l", it.label).put("u", it.loginUrl)) }
        sp(ctx).edit().putString("list", a.toString()).apply()
        cached = list
    }

    /** Domain induk dari link (www. dibuang), mis. https://www.bilibili.com/login -> bilibili.com. */
    fun keyOf(url: String): String? {
        val h = runCatching { Uri.parse(url).host }.getOrNull()?.lowercase()?.removePrefix("www.") ?: return null
        val p = h.split('.')
        if (p.size < 2) return null
        val second = setOf("co", "com", "net", "org", "ac", "go", "or", "gov", "edu")
        return if (p.size >= 3 && p.last().length == 2 && p[p.size - 2] in second) p.takeLast(3).joinToString(".")
        else p.takeLast(2).joinToString(".")
    }

    fun normalize(raw: String): String? {
        var u = raw.trim()
        if (u.isEmpty()) return null
        if (!u.contains("://")) u = "https://$u"
        val uri = Uri.parse(u)
        if (uri.scheme != "https" && uri.scheme != "http") return null
        if (keyOf(u) == null) return null
        return u
    }

    /** null = berhasil, selain itu pesan galat untuk ditampilkan. */
    fun add(ctx: Context, label: String, rawUrl: String): String? = put(ctx, null, label, rawUrl)

    fun update(ctx: Context, oldKey: String, label: String, rawUrl: String): String? = put(ctx, oldKey, label, rawUrl)

    private fun put(ctx: Context, oldKey: String?, label: String, rawUrl: String): String? {
        val u = normalize(rawUrl) ?: return "Link login tidak valid"
        val k = keyOf(u) ?: return "Link login tidak valid"
        val cur = load(ctx)
        if (oldKey == null && cur.size >= MAX) return "Maksimal $MAX situs"
        if (DlCookies.SITES.any { it.key == k } || cur.any { it.key == k && it.key != oldKey }) return "Situs ini sudah ada"
        val site = LoginSite(label.trim().ifBlank { k }.take(20), k, u)
        save(ctx, if (oldKey == null) cur + site else cur.map { if (it.key == oldKey) site else it })
        return null
    }

    fun remove(ctx: Context, key: String) = save(ctx, load(ctx).filter { it.key != key })
}
