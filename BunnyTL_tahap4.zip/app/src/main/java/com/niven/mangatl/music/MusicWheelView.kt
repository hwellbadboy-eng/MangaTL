package com.niven.mangatl

import android.animation.Animator
import android.animation.AnimatorListenerAdapter
import android.animation.TimeInterpolator
import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.text.TextPaint
import android.text.TextUtils
import android.util.AttributeSet
import android.view.Gravity
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.VelocityTracker
import android.view.ViewGroup
import android.view.View
import android.view.animation.DecelerateInterpolator
import android.view.animation.LinearInterpolator
import android.view.animation.PathInterpolator
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.core.content.res.ResourcesCompat
import kotlinx.coroutines.CoroutineScope
import kotlin.math.abs
import kotlin.math.atan2
import kotlin.math.ceil
import kotlin.math.cos
import kotlin.math.floor
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

/**
 * Font layar Musik. Desain memakai Inter: taruh file font bernama "inter" (res/font/inter.ttf)
 * dan otomatis dipakai. Kalau tidak ada, jatuh ke font bawaan HP.
 */
object MusicFonts {
    private var base: Typeface? = null
    private var tried = false

    private fun base(ctx: Context): Typeface {
        if (!tried) {
            tried = true
            val id = ctx.resources.getIdentifier("inter", "font", ctx.packageName)
            if (id != 0) {
                base = try {
                    ResourcesCompat.getFont(ctx, id)
                } catch (e: Exception) {
                    null
                }
            }
        }
        return base ?: Typeface.DEFAULT
    }

    fun face(ctx: Context, weight: Int): Typeface {
        val b = base(ctx)
        return if (Build.VERSION.SDK_INT >= 28) {
            Typeface.create(b, weight, false)
        } else {
            Typeface.create(b, if (weight >= 600) Typeface.BOLD else Typeface.NORMAL)
        }
    }
}

/** Tiga garis equalizer kecil: bergerak saat lagu diputar, diam (tinggi tetap) saat dijeda. */
internal class EqView(c: Context) : View(c) {
    private val d = resources.displayMetrics.density
    private val p = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE }
    private var t = 0f
    private var running = false
    private var anim: ValueAnimator? = null

    fun run(on: Boolean) {
        if (on == running) return
        running = on
        anim?.cancel()
        anim = null
        if (on) {
            anim = ValueAnimator.ofFloat(0f, 1f).apply {
                duration = 900L
                repeatCount = ValueAnimator.INFINITE
                interpolator = LinearInterpolator()
                addUpdateListener {
                    t = it.animatedValue as Float
                    invalidate()
                }
                start()
            }
        } else {
            invalidate()
        }
    }

    override fun onDraw(canvas: Canvas) {
        val w = 3f * d
        val gap = 2f * d
        val h = height.toFloat()
        val x0 = (width - (3 * w + 2 * gap)) / 2f
        val still = floatArrayOf(0.55f, 0.85f, 0.4f)
        for (i in 0..2) {
            val frac = if (running) {
                0.28f + 0.72f * (0.5f - 0.5f * cos(2.0 * Math.PI * (t - i * 0.33f)).toFloat())
            } else still[i]
            val bh = max(h * frac, 2f * d)
            val x = x0 + i * (w + gap)
            canvas.drawRoundRect(x, h - bh, x + w, h, d, d, p)
        }
    }

    override fun onDetachedFromWindow() {
        anim?.cancel()
        anim = null
        running = false
        super.onDetachedFromWindow()
    }
}

/**
 * Daftar musik gaya "roda": baris di tengah paling besar, baris lain mengecil, memudar dan
 * bergeser mengikuti lengkung. Seret = geser, lepas = berhenti di baris terdekat. Tahan lama baris
 * tengah = menu. Garis lengkung di tepi = cari cepat (seret untuk loncat jauh, huruf pertama judul
 * muncul di gelembung). Ukuran dalam dp mengikuti artboard 390 x 844 di desain "Versi 3".
 *
 * Hanya sekitar 11 baris yang benar-benar dibuat; sisanya hanya data (Row), jadi aman untuk ribuan lagu.
 */
class MusicWheelView @JvmOverloads constructor(ctx: Context, attrs: AttributeSet? = null) :
    ViewGroup(ctx, attrs) {

    var scope: CoroutineScope? = null

    /** Ketuk baris. */
    var onRowClick: ((Row) -> Unit)? = null

    /** Tahan lama baris tengah. Kembalikan true kalau ditangani (ketukan setelahnya diabaikan). */
    var onRowLong: ((Row) -> Boolean)? = null

    private val d = resources.displayMetrics.density
    private val uiHandler = Handler(Looper.getMainLooper())
    private val ease = PathInterpolator(0.25f, 0.1f, 0.25f, 1f)

    /** Dipanggil saat lagu yang diputar jauh dari tengah roda (show) dan arahnya (up = di atas). */
    var onBackHint: ((show: Boolean, up: Boolean) -> Unit)? = null
    private var hintShow = false
    private var hintUp = true
    private var playingNow = false

    // muat cover saat cari cepat: hanya baris dekat tengah, dan hanya saat jari melambat
    private var nearPending = false
    private var nearLast = 0f
    private val nearRun = Runnable {
        nearPending = false
        val still = abs(focus - nearLast) <= 1.5f
        nearLast = focus
        if (still) {
            for (v in bound.values) if (v.needCover && abs(v.index - focus) <= 2.5f) loadCover(v)
        } else if (fast) {
            scheduleNear()
        }
    }

    private fun scheduleNear() {
        if (nearPending) return
        nearPending = true
        uiHandler.postDelayed(nearRun, 120L)
    }

    private var rows: List<Row> = emptyList()
    private var playingKey = -1L
    private var userFocus: Int? = null
    private var focus = 0f
    private var curveT = 1f
    private var qsT = 0f
    private var qsActive = false
    private var dragging = false
    private var fast = false
    private var qsRight = true

    private var anim: ValueAnimator? = null
    private var curveAnim: ValueAnimator? = null
    private var qsAnim: ValueAnimator? = null

    private val bound = HashMap<Int, ItemView>()
    private val free = ArrayList<ItemView>()

    // gambar garis cari cepat
    private val railPath = Path()
    private var railW = -1f
    private var railC = -1f
    private var railR = true
    private val railPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 1.5f
        color = 0xFF3A3A3A.toInt()
    }
    private val dotPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE }
    private val bubblePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE }
    private val letterPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.BLACK
        textSize = 20f
        textAlign = Paint.Align.CENTER
        typeface = MusicFonts.face(ctx, 800)
    }

    // playlist: geser kanan cepat tanpa lepas, lalu atas/bawah ganti playlist, lepas = pilih
    private var plNames: List<String> = emptyList()
    private var plSel = 0
    private var plActive = false
    private var plReset = false
    private var plF = 0f
    private var plBase = 0
    private var plRound = 0
    private var plY0 = 0f
    private var plT = 0f
    private var plAnim: ValueAnimator? = null
    private var plLastUp = 0L
    private val plPaint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply { textAlign = Paint.Align.CENTER }
    private val plFaceB = MusicFonts.face(ctx, 800)
    private val plFaceN = MusicFonts.face(ctx, 600)

    /** Dipanggil saat pengguna memilih playlist (indeks di daftar nama). 0 = Semua lagu. */
    var onPlaylistPick: ((Int) -> Unit)? = null

    // sentuhan
    private var downX = 0f
    private var downT = 0L
    private var downY = 0f
    private var startFocus = 0f
    private var moved = false
    private var lpFired = false
    private var pressedIdx = -1
    private var vt: VelocityTracker? = null

    private val lpRun = Runnable {
        val i = pressedIdx
        if (!moved && i in rows.indices) {
            performHapticFeedback(HapticFeedbackConstants.LONG_PRESS)
            lpFired = onRowLong?.invoke(rows[i]) ?: false
        }
    }

    init {
        setWillNotDraw(false)
        clipChildren = false
        repeat(14) {
            val v = ItemView(ctx)
            v.visibility = INVISIBLE
            addView(v)
            free.add(v)
        }
    }

    // ------------------------------------------------------------------ item

    private inner class ItemView(c: Context) : LinearLayout(c) {
        val cover = FrameLayout(c)
        val img = ImageView(c)
        val icon = ImageView(c)
        val title = TextView(c)
        val artist = TextView(c)
        val coverBg = GradientDrawable()
        val eq = EqView(c)
        var index = -1
        var row: Row? = null
        var bold = false
        var coverColor = 0
        var ring = false
        var needCover = false

        init {
            orientation = HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            coverBg.cornerRadius = 10f * d
            coverBg.setColor(0xFF222222.toInt())
            coverColor = 0xFF222222.toInt()
            cover.background = coverBg
            cover.clipToOutline = true
            img.scaleType = ImageView.ScaleType.CENTER_CROP
            cover.addView(img, FrameLayout.LayoutParams(-1, -1))
            icon.setColorFilter(Color.WHITE)
            icon.alpha = 0.6f
            icon.visibility = GONE
            cover.addView(
                icon,
                FrameLayout.LayoutParams((20 * d).toInt(), (20 * d).toInt(), Gravity.CENTER)
            )
            addView(cover, LinearLayout.LayoutParams((42 * d).toInt(), (42 * d).toInt()))

            val col = LinearLayout(c)
            col.orientation = VERTICAL
            title.textSize = 15f
            title.setTextColor(Color.WHITE)
            title.maxLines = 1
            title.ellipsize = TextUtils.TruncateAt.END
            title.typeface = MusicFonts.face(c, 500)
            artist.textSize = 12f
            artist.setTextColor(0xFFB0B0B0.toInt())
            title.setShadowLayer(8f * d, 0f, d, 0xD9000000.toInt())
            artist.setShadowLayer(8f * d, 0f, d, 0xD9000000.toInt())
            artist.maxLines = 1
            artist.ellipsize = TextUtils.TruncateAt.END
            artist.typeface = MusicFonts.face(c, 400)
            col.addView(
                title,
                LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
                )
            )
            col.addView(
                artist,
                LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
                ).apply { topMargin = (2 * d).toInt() }
            )
            addView(
                col,
                LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
                    .apply { marginStart = (14 * d).toInt() }
            )
            eq.visibility = GONE
            addView(
                eq,
                LinearLayout.LayoutParams((14 * d).toInt(), (14 * d).toInt()).apply {
                    marginStart = (8 * d).toInt()
                    marginEnd = (4 * d).toInt()
                }
            )
            pivotX = 0f
            pivotY = ITEM_H * d / 2f
        }
    }

    // ------------------------------------------------------------------ API

    /** Ganti isi daftar. keepFocus = true: tetap di posisi sekarang (mis. setelah pilih/favorit). */
    fun setRows(list: List<Row>, keepFocus: Boolean) {
        rows = list
        for (v in bound.values) {
            v.index = -1
            v.row = null
            v.visibility = INVISIBLE
            free.add(v)
        }
        bound.clear()
        anim?.cancel()
        val last = max(list.size - 1, 0)
        if (!keepFocus) userFocus = null
        userFocus = userFocus?.coerceIn(0, last)
        if (keepFocus) {
            focus = focus.coerceIn(0f, last.toFloat())
        } else {
            focus = targetIndex().toFloat()
        }
        update()
        loadPending()
    }

    /** Lagu yang sedang diputar (id); wheel memusatkan baris ini kecuali pengguna baru saja menggeser. */
    fun setPlayingKey(key: Long, recenter: Boolean) {
        val changed = key != playingKey
        playingKey = key
        if (changed || recenter) {
            userFocus = null
            if (!dragging) animateFocusTo(targetIndex().toFloat(), 300L, ease) else update()
        } else {
            update()
        }
    }

    /** Lagu sedang berbunyi (true) atau dijeda (false): menggerakkan garis equalizer di baris yang diputar. */
    fun setPlayingNow(on: Boolean) {
        if (playingNow == on) return
        playingNow = on
        update()
    }

    /** Balik ke lagu yang sedang diputar. */
    fun recenter() {
        userFocus = null
        animateFocusTo(autoIndex().toFloat(), 420L, ease)
    }

    fun setCurved(on: Boolean, animate: Boolean) {
        curveAnim?.cancel()
        val to = if (on) 1f else 0f
        if (!animate) {
            curveT = to
            update()
            return
        }
        val a = ValueAnimator.ofFloat(curveT, to)
        a.duration = 300L
        a.interpolator = ease
        a.addUpdateListener {
            curveT = it.animatedValue as Float
            update()
        }
        curveAnim = a
        a.start()
    }

    fun setQsRight(on: Boolean) {
        qsRight = on
        invalidate()
    }

    /** Nama playlist untuk gestur geser-kanan-cepat. Daftar kosong / satu isi = gestur mati (mis. di tab lain). */
    fun setPlaylists(names: List<String>, selected: Int) {
        plNames = names
        plSel = selected.coerceIn(0, max(names.size - 1, 0))
        if (!plActive) plF = plSel.toFloat()
    }

    private fun animatePl(to: Float) {
        plAnim?.cancel()
        val a = ValueAnimator.ofFloat(plT, to)
        a.duration = 180L
        a.addUpdateListener {
            plT = it.animatedValue as Float
            invalidate()
        }
        plAnim = a
        a.start()
    }

    private fun startPlaylist(now: Long, y: Float) {
        uiHandler.removeCallbacks(lpRun)
        parent?.requestDisallowInterceptTouchEvent(true)
        plActive = true
        plBase = plSel
        plF = plSel.toFloat()
        plRound = plSel
        plY0 = y
        performHapticFeedback(HapticFeedbackConstants.LONG_PRESS)
        // geser kanan kedua yang menyusul cepat = kembali ke Semua lagu
        plReset = plLastUp > 0L && now - plLastUp <= DOUBLE_MS
        if (plReset) {
            plF = 0f
            plRound = 0
            if (plSel != 0) {
                plSel = 0
                onPlaylistPick?.invoke(0)
            }
        }
        animatePl(1f)
    }

    // ------------------------------------------------------------------ hitung

    private fun lastIndex() = max(rows.size - 1, 0)

    private fun autoIndex(): Int {
        val i = rows.indexOfFirst { it.key >= 0 && it.key == playingKey }
        return if (i < 0) 0 else i
    }

    private fun targetIndex(): Int = (userFocus ?: autoIndex()).coerceIn(0, lastIndex())

    /** Skala tinggi layar terhadap artboard desain (844dp); HP yang lebih tinggi membuat daftar ikut memanjang ke bawah. */
    private fun k(): Float = ((height / d + TOP_DP) / 844f).coerceIn(0.9f, 1.3f)

    private fun stp(): Float = STEP * k()

    /** Tengah roda (dp, dari atas view): 500dp di artboard, dikurangi posisi atas view. */
    private fun centerY(): Float = 500f * k() - TOP_DP

    // ------------------------------------------------------------------ animasi

    private fun animateFocusTo(target: Float, dur: Long, interp: TimeInterpolator) {
        anim?.cancel()
        val from = focus
        if (abs(target - from) < 0.001f) {
            focus = target
            update()
            settled()
            return
        }
        if (abs(target - from) > 14f) {
            // loncatan jauh: langsung pindah supaya tidak memuat ratusan thumbnail di jalan
            focus = target
            update()
            settled()
            return
        }
        val a = ValueAnimator.ofFloat(from, target)
        a.duration = dur
        a.interpolator = interp
        a.addUpdateListener {
            focus = it.animatedValue as Float
            update()
        }
        a.addListener(object : AnimatorListenerAdapter() {
            override fun onAnimationEnd(animation: Animator) {
                if (anim === animation) settled()
            }
        })
        anim = a
        a.start()
    }

    private fun animateQs(to: Float) {
        qsAnim?.cancel()
        val a = ValueAnimator.ofFloat(qsT, to)
        a.duration = 200L
        a.addUpdateListener {
            qsT = it.animatedValue as Float
            invalidate()
        }
        qsAnim = a
        a.start()
    }

    private fun settled() {
        fast = false
        uiHandler.removeCallbacks(nearRun)
        nearPending = false
        loadPending()
    }

    private fun notifyHint() {
        val pi = if (playingKey >= 0) rows.indexOfFirst { it.key == playingKey } else -1
        val show = pi >= 0 && abs(pi - focus) >= 1.5f
        val up = pi < focus
        if (show != hintShow || (show && up != hintUp)) {
            hintShow = show
            hintUp = up
            uiHandler.post { onBackHint?.invoke(show, up) }
        }
    }

    // ------------------------------------------------------------------ tata letak

    override fun onMeasure(widthSpec: Int, heightSpec: Int) {
        setMeasuredDimension(
            MeasureSpec.getSize(widthSpec), MeasureSpec.getSize(heightSpec)
        )
        val cw = MeasureSpec.makeMeasureSpec((ITEM_W * d).toInt(), MeasureSpec.EXACTLY)
        val ch = MeasureSpec.makeMeasureSpec((ITEM_H * d).toInt(), MeasureSpec.EXACTLY)
        for (i in 0 until childCount) getChildAt(i).measure(cw, ch)
    }

    override fun onLayout(changed: Boolean, l: Int, t: Int, r: Int, b: Int) {
        for (i in 0 until childCount) {
            val c = getChildAt(i)
            c.layout(0, 0, c.measuredWidth, c.measuredHeight)
        }
        update()
    }

    /** Pasang ulang posisi, ukuran dan bayangan tiap baris dari nilai [focus] sekarang. */
    private fun update() {
        if (width == 0) return
        val n = rows.size
        val ctr = centerY()
        val lo: Int
        val hi: Int
        if (n == 0) {
            lo = 0
            hi = -1
        } else {
            lo = max(0, floor(focus - 5f).toInt())
            hi = min(n - 1, ceil(focus + 5f).toInt())
        }

        val iter = bound.entries.iterator()
        while (iter.hasNext()) {
            val e = iter.next()
            if (e.key < lo || e.key > hi) {
                val v = e.value
                v.index = -1
                v.row = null
                v.visibility = INVISIBLE
                free.add(v)
                iter.remove()
            }
        }

        for (i in lo..hi) {
            var v = bound[i]
            if (v == null) {
                v = if (free.isNotEmpty()) {
                    free.removeAt(free.size - 1)
                } else {
                    val nv = ItemView(context)
                    addView(nv)
                    nv
                }
                bound[i] = v
            }
            bindRow(v, i)
            place(v, i, ctr)
        }
        if (fast) scheduleNear()
        notifyHint()
        invalidate()
    }

    private fun bindRow(v: ItemView, i: Int) {
        val r = rows[i]
        v.index = i
        if (v.row === r) return
        v.row = r
        v.title.text = r.title
        v.artist.text = r.sub
        v.artist.visibility = if (r.sub.isEmpty()) GONE else VISIBLE
        val noArt = r.thumb == null && r.thumbs.isEmpty()
        if (noArt && r.icon != R.drawable.ic_music_note && r.icon != 0) {
            v.icon.setImageResource(r.icon)
            v.icon.visibility = VISIBLE
        } else {
            v.icon.visibility = GONE
        }
        v.img.setImageDrawable(null)
        v.needCover = true
        if (!fast) loadCover(v) else if (peekCover(v)) v.needCover = false
    }

    private fun peekCover(v: ItemView): Boolean {
        val r = v.row ?: return false
        return Thumbs.peek(v.img, r.thumb ?: r.thumbs.firstOrNull(), (42 * d * 2).toInt())
    }

    private fun loadCover(v: ItemView) {
        val r = v.row ?: return
        val sc = scope ?: return
        v.needCover = false
        Thumbs.load(sc, v.img, r.thumb ?: r.thumbs.firstOrNull(), (42 * d * 2).toInt(), false)
    }

    private fun loadPending() {
        for (v in bound.values) if (v.needCover) loadCover(v)
    }

    private fun place(v: ItemView, i: Int, ctr: Float) {
        val r = v.row ?: return
        val dd = i - focus
        val ad = abs(dd)
        val mid = ad < 0.5f
        val curveLeft = 28f * max(0f, cos(0.38f * dd))
        val curveSc = max(0.78f, 1.06f - 0.12f * ad)
        val flatSc = if (mid) 1.04f else 1f
        val left = LEFT + curveLeft * curveT
        val sc = flatSc + (curveSc - flatSc) * curveT
        val op = max(0.57f, 1f - 0.1f * ad) * min(1f, max(0f, (4.9f - ad) / 0.7f))

        v.translationX = left * d
        v.translationY = (ctr + dd * stp() - ITEM_H / 2f) * d
        v.scaleX = sc
        v.scaleY = sc
        v.alpha = op
        v.visibility = if (op > 0.01f) VISIBLE else INVISIBLE

        val playing = r.key >= 0 && r.key == playingKey
        v.eq.visibility = if (playing) VISIBLE else GONE
        v.eq.run(playing && playingNow)
        val col = if (playing) 0xFFFFFFFF.toInt() else if (mid) 0xFF3A3A3A.toInt() else 0xFF222222.toInt()
        if (v.coverColor != col) {
            v.coverColor = col
            v.coverBg.setColor(col)
        }
        val boldNow = mid || playing
        if (boldNow != v.bold) {
            v.bold = boldNow
            v.title.typeface = MusicFonts.face(context, if (boldNow) 700 else 500)
        }
        if (r.selected != v.ring) {
            v.ring = r.selected
            v.coverBg.setStroke(if (r.selected) (3 * d).toInt() else 0, Color.WHITE)
        }
    }

    // ------------------------------------------------------------------ gambar rel cari cepat

    private fun arcX(c: Float): Float {
        val w = width / d
        return if (qsRight) w - 38f + 20f * c else 8f + 30f * c
    }

    private fun rebuildRail(ctr: Float) {
        railPath.reset()
        for (q in 0..30) {
            val t = q / 30f
            val dd = -3f + 6f * t
            val x = arcX(cos(0.45f * dd))
            val y = ctr + dd * stp()
            if (q == 0) railPath.moveTo(x, y) else railPath.lineTo(x, y)
        }
    }

    override fun dispatchDraw(canvas: Canvas) {
        val n = rows.size
        if (n > 0 && width > 0) {
            val w = width / d
            val ctr = centerY()
            if (railW != w || railC != ctr || railR != qsRight) {
                railW = w
                railC = ctr
                railR = qsRight
                rebuildRail(ctr)
            }
            canvas.save()
            canvas.scale(d, d)
            if (qsT > 0.01f) {
                railPaint.alpha = (qsT * 255).toInt()
                canvas.drawPath(railPath, railPaint)
            }
            val t = if (n > 1) (focus / (n - 1)).coerceIn(0f, 1f) else 0.5f
            val dd = -3f + 6f * t
            val px = arcX(cos(0.45f * dd))
            val py = ctr + dd * stp()
            dotPaint.alpha = ((0.5f + 0.5f * qsT) * 255).toInt()
            canvas.drawCircle(px, py, 2.5f + 2f * qsT, dotPaint)
            if (qsT > 0.01f) {
                val bx = if (qsRight) px - 70f else px + 26f
                val by = py - 22f
                bubblePaint.alpha = (qsT * 255).toInt()
                canvas.drawCircle(bx + 22f, by + 22f, 22f, bubblePaint)
                val s = rows.getOrNull(focus.roundToInt())?.title ?: ""
                if (s.isNotEmpty()) {
                    letterPaint.alpha = (qsT * 255).toInt()
                    val fm = letterPaint.fontMetrics
                    canvas.drawText(
                        s.substring(0, 1).uppercase(), bx + 22f,
                        by + 22f - (fm.ascent + fm.descent) / 2f, letterPaint
                    )
                }
            }
            canvas.restore()
        }
        super.dispatchDraw(canvas)
        drawPlaylists(canvas)
    }

    /** Posisi x (dp) nama playlist di sisi kiri: mengikuti lekukan baris (sama dengan rumus [place]) dikurangi 12dp. */
    private fun plX(y: Float, ctr: Float): Float =
        10f + 28f * max(0f, cos(0.38f * ((y - ctr) / stp()))) * curveT

    /** Nama playlist tegak (dibaca dari bawah ke atas) di ruang kosong kiri, berputar mengikuti lekukan. */
    private fun drawPlaylists(canvas: Canvas) {
        if (plT <= 0.01f || plNames.size < 2 || width == 0) return
        val ctr = centerY()
        val gap = stp() * 1.5f
        canvas.save()
        canvas.scale(d, d)
        for (i in plNames.indices) {
            val e = i - plF
            val ae = abs(e)
            val a = (1f - 0.45f * ae) * plT
            if (a <= 0.02f) continue
            val yy = ctr + e * gap
            val x = plX(yy, ctr)
            val tilt = Math.toDegrees(atan2((plX(yy - 1f, ctr) - plX(yy + 1f, ctr)).toDouble(), 2.0)).toFloat()
            val act = ae < 0.5f
            plPaint.typeface = if (act) plFaceB else plFaceN
            plPaint.textSize = if (act) 15f else 13f
            plPaint.color = if (act) Color.WHITE else 0xFF8A8A8A.toInt()
            plPaint.alpha = (a.coerceIn(0f, 1f) * 255).toInt()
            plPaint.setShadowLayer(8f, 0f, 1f, 0xD9000000.toInt())
            val s = TextUtils.ellipsize(plNames[i], plPaint, 110f, TextUtils.TruncateAt.END).toString()
            val fm = plPaint.fontMetrics
            canvas.save()
            canvas.translate(x, yy)
            canvas.rotate(-90f + tilt)
            canvas.drawText(s, 0f, -(fm.ascent + fm.descent) / 2f, plPaint)
            canvas.restore()
        }
        canvas.restore()
    }

    // ------------------------------------------------------------------ sentuhan

    private fun hitItem(x: Float, y: Float): ItemView? {
        for (v in bound.values) {
            if (v.alpha < 0.05f || v.visibility != VISIBLE) continue
            val left = v.translationX / d
            val cy = v.translationY / d + ITEM_H / 2f
            val sc = v.scaleX
            if (x >= left && x <= left + ITEM_W * sc && y >= cy - ITEM_H * sc / 2f && y <= cy + ITEM_H * sc / 2f) {
                return v
            }
        }
        return null
    }

    private fun inQs(x: Float, y: Float): Boolean {
        if (rows.isEmpty()) return false
        val w = width / d
        val c = centerY()
        val inX = if (qsRight) x >= w - 44f else x <= 30f
        return inX && y >= c - 3f * stp() - 10f && y <= c + 3f * stp() + 10f
    }

    private fun qsFocus(y: Float): Float {
        val t = ((y - (centerY() - 3f * stp())) / (6f * stp())).coerceIn(0f, 1f)
        return t * lastIndex()
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        val x = e.x / d
        val y = e.y / d
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                parent?.requestDisallowInterceptTouchEvent(true)
                anim?.cancel()
                if (inQs(x, y)) {
                    qsActive = true
                    dragging = true
                    fast = true
                    uiHandler.removeCallbacks(lpRun)
                    animateQs(1f)
                    focus = qsFocus(y)
                    update()
                    return true
                }
                downX = x
                downT = e.eventTime
                downY = y
                startFocus = focus
                moved = false
                lpFired = false
                pressedIdx = -1
                vt?.recycle()
                vt = VelocityTracker.obtain()
                vt?.addMovement(e)
                val hit = hitItem(x, y)
                if (hit != null && abs(hit.index - focus) < 0.5f) {
                    pressedIdx = hit.index
                    uiHandler.postDelayed(lpRun, 450L)
                }
            }

            MotionEvent.ACTION_MOVE -> {
                if (qsActive) {
                    focus = qsFocus(y)
                    update()
                    return true
                }
                vt?.addMovement(e)
                if (plActive) {
                    if (!plReset) {
                        plF = (plBase - (y - plY0) / PL_STEP).coerceIn(0f, (plNames.size - 1).toFloat())
                        val r = plF.roundToInt()
                        if (r != plRound) {
                            plRound = r
                            performHapticFeedback(HapticFeedbackConstants.CLOCK_TICK)
                        }
                    }
                    invalidate()
                    return true
                }
                if (!moved && plNames.size > 1 && x - downX > 40f &&
                    x - downX > abs(y - downY) * 1.5f && e.eventTime - downT <= 450L
                ) {
                    startPlaylist(e.eventTime, y)
                    return true
                }
                val dy = y - downY
                if (!moved && abs(dy) > 6f) {
                    moved = true
                    dragging = true
                    uiHandler.removeCallbacks(lpRun)
                }
                if (moved) {
                    focus = (startFocus - dy / stp()).coerceIn(0f, lastIndex().toFloat())
                    update()
                }
            }

            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                uiHandler.removeCallbacks(lpRun)
                if (qsActive) {
                    qsActive = false
                    dragging = false
                    animateQs(0f)
                    val t = focus.roundToInt().coerceIn(0, lastIndex())
                    userFocus = t
                    animateFocusTo(t.toFloat(), 300L, ease)
                    return true
                }
                val up = e.actionMasked == MotionEvent.ACTION_UP
                if (plActive) {
                    plActive = false
                    animatePl(0f)
                    val pick = if (plReset) 0 else plF.roundToInt().coerceIn(0, max(plNames.size - 1, 0))
                    plReset = false
                    if (up) {
                        plLastUp = e.eventTime
                        if (pick != plSel) {
                            plSel = pick
                            onPlaylistPick?.invoke(pick)
                        }
                    }
                    dragging = false
                    moved = false
                    vt?.recycle()
                    vt = null
                    return true
                }
                if (lpFired) {
                    lpFired = false
                } else if (moved) {
                    vt?.addMovement(e)
                    vt?.computeCurrentVelocity(1000)
                    val vy = (vt?.yVelocity ?: 0f) / d
                    val proj = focus - (vy / stp()) * 0.2f
                    val t = proj.roundToInt().coerceIn(0, lastIndex())
                    userFocus = t
                    dragging = false
                    val far = abs(t - focus) > 1f
                    animateFocusTo(
                        t.toFloat(),
                        if (far) (260L + 40L * abs(t - focus).toLong()).coerceAtMost(700L) else 300L,
                        if (far) DecelerateInterpolator(1.4f) else ease
                    )
                } else if (up) {
                    val hit = hitItem(x, y)
                    val i = hit?.index ?: -1
                    if (i in rows.indices) onRowClick?.invoke(rows[i])
                }
                dragging = false
                moved = false
                vt?.recycle()
                vt = null
            }
        }
        return true
    }

    override fun performClick(): Boolean = super.performClick()

    override fun onDetachedFromWindow() {
        uiHandler.removeCallbacks(lpRun)
        uiHandler.removeCallbacks(nearRun)
        nearPending = false
        anim?.cancel()
        curveAnim?.cancel()
        qsAnim?.cancel()
        plAnim?.cancel()
        super.onDetachedFromWindow()
    }

    companion object {
        private const val ITEM_W = 270f
        private const val ITEM_H = 52f
        private const val STEP = 60f
        private const val TOP_DP = 236f
        private const val LEFT = 22f
        private const val PL_STEP = 50f
        private const val DOUBLE_MS = 600L
    }
}
