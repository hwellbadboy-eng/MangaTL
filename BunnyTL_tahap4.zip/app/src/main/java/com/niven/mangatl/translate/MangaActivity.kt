package com.niven.mangatl

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.OpenableColumns
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

/** Layar Manga Translator: pilih halaman/CBZ, proses otomatis, baca hasil, ekspor CBZ. */
class MangaActivity : AppCompatActivity() {

    private val prefs by lazy { getSharedPreferences("mangatl", MODE_PRIVATE) }
    private lateinit var etTitle: EditText
    private lateinit var tvStatus: TextView
    private lateinit var progress: ProgressBar
    private lateinit var btnPick: TextView
    private lateinit var btnCancel: TextView
    private lateinit var listBox: LinearLayout
    private var job: Job? = null
    private var lang = 0
    private val mangaPrefs by lazy { getSharedPreferences("manga", MODE_PRIVATE) }

    private val picker = registerForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
        if (uris.isNotEmpty()) {
            tvStatus.text = "Memeriksa ${uris.size} file..."
            startImport(uris)
        }
    }

    private fun dp(v: Int) = Ui.dp(this, v)

    private fun button(text: String, hero: Boolean): TextView = TextView(this).apply {
        this.text = text
        gravity = Gravity.CENTER
        textSize = 15f
        setTypeface(typeface, android.graphics.Typeface.BOLD)
        setTextColor(if (hero) 0xFF000000.toInt() else 0xFFFFFFFF.toInt())
        setBackgroundResource(if (hero) R.drawable.bg_hero else R.drawable.bg_tile)
        isClickable = true
        layoutParams = LinearLayout.LayoutParams(-1, dp(52)).apply { topMargin = dp(10) }
    }

    private val caseNames = listOf("Kapital", "Biasa", "Otomatis")
    private lateinit var tvFontVal: TextView
    private lateinit var tvStyleVal: TextView

    private fun label(t: String) = TextView(this).apply {
        text = t.uppercase(java.util.Locale.ROOT)
        textSize = 11f
        letterSpacing = 0.06f
        setTextColor(getColor(R.color.hint))
        setPadding(dp(2), dp(20), 0, dp(8))
    }

    private fun chip(t: String, on: Boolean, click: () -> Unit) = TextView(this).apply {
        text = t
        textSize = 13f
        gravity = Gravity.CENTER
        setPadding(0, dp(10), 0, dp(10))
        setTextColor(if (on) 0xFF000000.toInt() else getColor(R.color.text_soft))
        if (on) setTypeface(typeface, android.graphics.Typeface.BOLD)
        setBackgroundResource(if (on) R.drawable.bg_hero else R.drawable.bg_card)
        layoutParams = LinearLayout.LayoutParams(0, -2, 1f).apply { marginEnd = dp(6) }
        setOnClickListener { click() }
    }

    private fun settingRow(name: String, value: TextView, click: () -> Unit) = LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL
        gravity = Gravity.CENTER_VERTICAL
        setPadding(0, dp(14), 0, dp(14))
        addView(TextView(this@MangaActivity).apply {
            text = name; textSize = 14f; setTextColor(0xFFEDEDED.toInt())
            layoutParams = LinearLayout.LayoutParams(0, -2, 1f)
        })
        addView(value)
        addView(TextView(this@MangaActivity).apply {
            text = "  \u203A"; textSize = 18f; setTextColor(getColor(R.color.muted))
        })
        setOnClickListener { click() }
    }

    private fun rebuildLangChips() {
        langBox.removeAllViews()
        MangaEngine.LANG_LABELS.forEachIndexed { i, l ->
            langBox.addView(chip(l.substringBefore(" ("), i == lang) {
                lang = i
                prefs.edit().putInt("manga_lang", i).apply()
                rebuildLangChips()
            })
        }
    }

    private lateinit var langBox: LinearLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        lang = prefs.getInt("manga_lang", 0).coerceIn(0, MangaEngine.LANG_LABELS.size - 1)

        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(20), dp(16), dp(28))
        }
        col.addView(TextView(this).apply {
            text = "Manga Translator"; textSize = 24f; setTextColor(0xFFFFFFFF.toInt())
            setTypeface(typeface, android.graphics.Typeface.BOLD)
        })
        col.addView(TextView(this).apply {
            text = "Gambar, CBZ, atau ZIP"
            textSize = 13f; setTextColor(getColor(R.color.hint)); setPadding(0, dp(4), 0, 0)
        })
        col.addView(label("Bahasa asli"))
        langBox = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        col.addView(langBox)
        rebuildLangChips()

        col.addView(label("Tampilan teks"))
        tvFontVal = TextView(this).apply { textSize = 14f; setTextColor(0xFFFFFFFF.toInt()) }
        tvStyleVal = TextView(this).apply { textSize = 13f; setTextColor(getColor(R.color.muted)) }
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundResource(R.drawable.bg_card)
            setPadding(dp(16), dp(2), dp(16), dp(2))
        }
        card.addView(settingRow("Font", tvFontVal) { fontDialog() })
        card.addView(View(this).apply {
            setBackgroundColor(getColor(R.color.card_stroke))
            layoutParams = LinearLayout.LayoutParams(-1, dp(1))
        })
        card.addView(settingRow("Gaya huruf", tvStyleVal) { styleDialog() })
        col.addView(card)
        refreshSummary()

        col.addView(label("Judul"))
        etTitle = EditText(this).apply {
            hint = "otomatis dari nama file"; setSingleLine(); setTextColor(0xFFFFFFFF.toInt())
            setHintTextColor(getColor(R.color.hint)); setBackgroundResource(R.drawable.bg_input_round)
            setPadding(dp(14), dp(10), dp(14), dp(10))
        }
        col.addView(etTitle)
        btnPick = button("Pilih halaman / CBZ", true).also { b ->
            b.setOnClickListener {
                if (job?.isActive == true) toast("Masih memproses...") else picker.launch(
                    arrayOf("*/*")
                )
            }
        }
        (btnPick.layoutParams as LinearLayout.LayoutParams).topMargin = dp(18)
        col.addView(btnPick)
        tvStatus = TextView(this).apply { text = "Siap."; textSize = 13f; setTextColor(getColor(R.color.muted)); setPadding(0, dp(10), 0, dp(4)) }
        col.addView(tvStatus)
        progress = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply { visibility = View.GONE }
        col.addView(progress)
        btnCancel = button("Batalkan", false).also { b -> b.visibility = View.GONE; b.setOnClickListener { job?.cancel() } }
        col.addView(btnCancel)
        col.addView(label("Hasil"))
        listBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        col.addView(listBox)

        setContentView(android.widget.ScrollView(this).apply { setBackgroundColor(getColor(R.color.bg)); addView(col) })
        Fx.enter(this)
    }

    override fun onResume() {
        super.onResume()
        refreshList()
    }

    private fun curFont() = mangaPrefs.getString("font", "ComicRelief-Bold.ttf") ?: "ComicRelief-Bold.ttf"

    /** Ringkasan di kartu: contoh teks dengan font terpilih, dan "Kapital, miring". */
    private fun refreshSummary() {
        val italic = mangaPrefs.getBoolean("italic", true)
        tvFontVal.text = "contoh text"
        tvFontVal.typeface = MangaEngine.loadFace(this, curFont())
        tvFontVal.paint.textSkewX = if (italic) -0.22f else 0f
        tvFontVal.invalidate()
        val cm = MangaEngine.caseModePref(this).coerceIn(0, caseNames.size - 1)
        tvStyleVal.text = caseNames[cm] + if (italic) ", miring" else ""
    }

    private fun optionRow(selected: Boolean, content: View, click: () -> Unit) = LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL
        gravity = Gravity.CENTER_VERTICAL
        setPadding(dp(12), dp(12), dp(12), dp(12))
        if (selected) background = android.graphics.drawable.GradientDrawable().apply {
            setColor(0xFF1C1C1E.toInt()); cornerRadius = dp(12).toFloat()
        }
        addView(android.widget.ImageView(this@MangaActivity).apply {
            setImageResource(if (selected) R.drawable.ic_radio_on else R.drawable.ic_radio_off)
            setColorFilter(if (selected) 0xFFFFFFFF.toInt() else getColor(R.color.hint))
            layoutParams = LinearLayout.LayoutParams(dp(20), dp(20))
        })
        content.layoutParams = LinearLayout.LayoutParams(0, -2, 1f).apply { marginStart = dp(14) }
        addView(content)
        setOnClickListener { click() }
    }

    /** Popup font: tiap pilihan cuma "contoh text" dengan font itu (ikut kapital/miring yang dipilih). */
    private fun fontDialog() {
        Sheet.custom(this, "Font terjemahan") { p, close ->
            val cm = MangaEngine.caseModePref(this)
            val italic = mangaPrefs.getBoolean("italic", true)
            for ((file, label, _) in MangaEngine.FONTS) {
                val tag = when {
                    file == "ComicRelief-Bold.ttf" -> "default"
                    file == "system" -> "sistem"
                    else -> ""
                }
                val line = LinearLayout(this).apply {
                    orientation = LinearLayout.HORIZONTAL
                    gravity = Gravity.CENTER_VERTICAL
                    addView(TextView(this@MangaActivity).apply {
                        text = if (cm == 1) "contoh text" else "CONTOH TEXT"
                        textSize = 18f; setTextColor(0xFFFFFFFF.toInt())
                        typeface = MangaEngine.loadFace(this@MangaActivity, file)
                        if (italic) paint.textSkewX = -0.22f
                        contentDescription = label
                        layoutParams = LinearLayout.LayoutParams(0, -2, 1f)
                    })
                    if (tag.isNotEmpty()) addView(TextView(this@MangaActivity).apply {
                        text = tag; textSize = 11f; setTextColor(getColor(R.color.muted))
                    })
                }
                p.addView(optionRow(file == curFont(), line) {
                    mangaPrefs.edit().putString("font", file).apply()
                    refreshSummary()
                    close()
                })
            }
            p.addView(Sheet.buttonRow(this, Sheet.button(this, "Batal", false) { close() }))
        }
    }

    /** Popup gaya huruf: kapital/biasa/otomatis + saklar huruf miring. */
    private fun styleDialog() {
        Sheet.custom(this, "Gaya huruf") { p, close ->
            val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
            fun render() {
                box.removeAllViews()
                val cur = MangaEngine.caseModePref(this)
                MangaEngine.CASE_LABELS.forEachIndexed { i, l ->
                    val main = l.substringBefore(" (")
                    val sub = if (l.contains(" (")) l.substringAfter(" (").removeSuffix(")") else ""
                    val tv = LinearLayout(this).apply {
                        orientation = LinearLayout.VERTICAL
                        addView(TextView(this@MangaActivity).apply {
                            text = main; textSize = 15f; setTextColor(0xFFEDEDED.toInt())
                        })
                        if (sub.isNotEmpty()) addView(TextView(this@MangaActivity).apply {
                            text = sub; textSize = 12f; setTextColor(getColor(R.color.muted))
                        })
                    }
                    box.addView(optionRow(i == cur, tv) {
                        mangaPrefs.edit().putInt("case_mode", i).apply()
                        refreshSummary()
                        render()
                    })
                }
            }
            render()
            p.addView(box)
            p.addView(View(this).apply {
                setBackgroundColor(getColor(R.color.card_stroke))
                layoutParams = LinearLayout.LayoutParams(-1, dp(1)).apply { setMargins(dp(12), dp(6), dp(12), dp(6)) }
            })
            p.addView(Ui.switchRow(this, "Huruf miring", mangaPrefs.getBoolean("italic", true)) {
                mangaPrefs.edit().putBoolean("italic", it).apply()
                refreshSummary()
            }.apply {
                setTextColor(0xFFEDEDED.toInt())
                setPadding(dp(12), dp(8), dp(12), dp(8))
            })
            p.addView(Sheet.buttonRow(this, Sheet.button(this, "Tutup", false) { close() }))
        }
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()

    private fun setBusy(b: Boolean) {
        btnCancel.visibility = if (b) View.VISIBLE else View.GONE
        progress.visibility = if (b) View.VISIBLE else View.GONE
        if (b) window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        else window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        if (!b) refreshList()
    }

    private fun nameOf(uri: Uri): String = try {
        contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use {
            if (it.moveToFirst()) it.getString(0) else null
        } ?: uri.lastPathSegment ?: "file"
    } catch (_: Throwable) { uri.lastPathSegment ?: "file" }

    private fun startImport(uris: List<Uri>) {
        if (job?.isActive == true) return
        val all = uris.map { Pair(it, nameOf(it)) }
        val named = all.filter { p ->
            val n = p.second.lowercase()
            MangaEngine.isImageName(n) || n.endsWith(".zip") || n.endsWith(".cbz")
        }.sortedWith { a, b -> MangaEngine.naturalCompare(a.second, b.second) }
        if (named.isEmpty()) {
            tvStatus.text = "File tidak didukung: ${all.first().second}. Pakai gambar (jpg/png/webp), .cbz, atau .zip."
            return
        }
        var title = etTitle.text.toString().trim()
        if (title.isEmpty()) title = named.first().second.substringBeforeLast('.')
        title = title.replace(Regex("[\\\\/:*?\"<>|]"), "_").take(60).ifBlank { "Manga" }
        val work = File(MangaEngine.root(this), title)
        val src = MangaEngine.srcDir(work)
        job = lifecycleScope.launch {
            setBusy(true)
            try {
                val model = Gemma.findModel(this@MangaActivity)
                if (model == null) {
                    tvStatus.text = "Model .litertlm belum ada. Salin ke:\n${getExternalFilesDir(null)}"
                    return@launch
                }
                tvStatus.text = "Menyalin halaman..."
                val total = withContext(Dispatchers.IO) {
                    src.mkdirs()
                    val base = (src.listFiles()?.mapNotNull { it.name.take(3).toIntOrNull() }?.maxOrNull() ?: -1) + 1
                    var n = 0
                    named.forEachIndexed { i, (u, nm) -> n += MangaEngine.importUri(this@MangaActivity, work, u, nm, base + i) }
                    File(work, "lang.txt").writeText(lang.toString())
                    n
                }
                if (total == 0) { tvStatus.text = "Tidak ada gambar (jpg/png/webp) ditemukan."; return@launch }
                process(work, model)
            } catch (e: CancellationException) {
                tvStatus.text = "Dibatalkan. Halaman yang sudah jadi tersimpan; lanjutkan lewat tahan daftar hasil."
            } catch (t: Throwable) {
                tvStatus.text = "Gagal: ${t::class.java.simpleName}: ${t.message}"
            } finally { setBusy(false) }
        }
    }

    private fun resume(work: File) {
        if (job?.isActive == true) { toast("Masih memproses..."); return }
        job = lifecycleScope.launch {
            setBusy(true)
            try {
                val model = Gemma.findModel(this@MangaActivity)
                if (model == null) { tvStatus.text = "Model .litertlm belum ada."; return@launch }
                lang = File(work, "lang.txt").takeIf { it.exists() }?.readText()?.trim()?.toIntOrNull()
                    ?.coerceIn(0, MangaEngine.LANG_LABELS.size - 1) ?: lang
                process(work, model)
            } catch (e: CancellationException) {
                tvStatus.text = "Dibatalkan."
            } catch (t: Throwable) {
                tvStatus.text = "Gagal: ${t::class.java.simpleName}: ${t.message}"
            } finally { setBusy(false) }
        }
    }

    private suspend fun process(work: File, model: File) {
        val pages = MangaEngine.pages(work)
        val style = Gemma.Style.values()[prefs.getInt("style", 0).coerceIn(0, Gemma.Style.values().size - 1)]
        val glossary = prefs.getString("glossary", "") ?: ""
        val rec = MangaEngine.recognizer(lang)
        val srcName = MangaEngine.LANG_PROMPT[lang]
        MangaEngine.initFonts(applicationContext)
        progress.max = pages.size
        var failed = 0
        var streak = 0
        var lastErr = ""
        try {
            for ((i, f) in pages.withIndex()) {
                currentCoroutineContext().ensureActive()
                val out = MangaEngine.outFile(work, i)
                progress.progress = i
                if (out.exists()) continue
                val head = "Halaman ${i + 1}/${pages.size}: "
                tvStatus.text = head + "mulai..."
                try {
                    var timing = ""
                    val gemmaLog = StringBuffer()
                    val nb = withContext(Dispatchers.IO) {
                        MangaEngine.processPage(f, out, rec, lang,
                            translate = { lines ->
                                Gemma.translateComic(applicationContext, model, lines, srcName, style, glossary,
                                    onLog = { gemmaLog.append(it).append(" | ") }) { s ->
                                    runOnUiThread { tvStatus.text = head + s }
                                }
                            },
                            onStep = { s -> runOnUiThread { tvStatus.text = head + s } },
                            onTiming = { timing = it }, debugDir = File(work, "debug"))
                    }
                    streak = 0
                    try { File(MangaEngine.root(this@MangaActivity), "log.txt").appendText("halaman ${i + 1} (${f.name}): $nb blok teks, $timing | gemma: $gemmaLog\n") } catch (_: Throwable) {}
                    try { File(work, "blocks.txt").appendText("${i + 1} $nb\n") } catch (_: Throwable) {}
                } catch (e: CancellationException) {
                    throw e
                } catch (t: Throwable) {
                    failed++; streak++
                    lastErr = "${t::class.java.simpleName}: ${t.message}"
                    android.util.Log.e("BunnyManga", "halaman ${i + 1} gagal", t)
                    try { File(MangaEngine.root(this@MangaActivity), "log.txt").appendText("${f.name}: ${android.util.Log.getStackTraceString(t)}\n") } catch (_: Throwable) {}
                    tvStatus.text = head + "gagal: " + lastErr
                    if (streak >= 3) { tvStatus.text = "Berhenti: 3 halaman berturut-turut gagal. Error: $lastErr"; return }
                }
            }
            progress.progress = pages.size
            tvStatus.text = "Selesai: ${pages.size} halaman" + if (failed > 0) ". $failed gagal (belum dihitung selesai, bisa diulang lewat tahan judul > Lanjutkan proses). Error: $lastErr" else "."
        } finally {
            try { rec.close() } catch (_: Throwable) {}
        }
    }

    private fun refreshList() {
        listBox.removeAllViews()
        val dirs = MangaEngine.root(this).listFiles()?.filter { it.isDirectory }?.sortedByDescending { it.lastModified() } ?: emptyList()
        if (dirs.isEmpty()) {
            listBox.addView(TextView(this).apply { text = "Belum ada."; setTextColor(getColor(R.color.hint)); textSize = 13f })
            return
        }
        for (d in dirs) {
            val total = MangaEngine.pages(d).size
            val done = MangaEngine.doneCount(d)
            val rowView = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setBackgroundResource(R.drawable.bg_card)
                setPadding(dp(16), dp(13), dp(16), dp(13)); isClickable = true
                layoutParams = LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(6) }
                addView(TextView(this@MangaActivity).apply {
                    text = d.name; textSize = 14f; setTextColor(0xFFFFFFFF.toInt())
                    maxLines = 1; ellipsize = android.text.TextUtils.TruncateAt.END
                    layoutParams = LinearLayout.LayoutParams(0, -2, 1f)
                })
                addView(TextView(this@MangaActivity).apply {
                    text = if (done < total) "$done/$total hal" else "$total hal"
                    textSize = 12f; setTextColor(getColor(R.color.hint))
                })
                setOnClickListener {
                    if (done > 0) startActivity(Intent(this@MangaActivity, MangaReaderActivity::class.java).putExtra("title", d.name))
                    else toast("Belum ada halaman jadi.")
                }
                setOnLongClickListener { menu(d, done < total); true }
            }
            listBox.addView(rowView)
        }
    }

    private fun menu(d: File, canResume: Boolean) {
        val items = ArrayList<Sheet.Item?>()
        if (canResume) items.add(Sheet.Item("Lanjutkan proses", R.drawable.ic_play) { resume(d) })
        items.add(Sheet.Item("Ekspor CBZ", R.drawable.ic_down) {
            lifecycleScope.launch {
                val target = File(MangaEngine.root(this@MangaActivity), d.name + ".cbz")
                val n = withContext(Dispatchers.IO) { try { MangaEngine.exportCbz(d, target) } catch (_: Throwable) { -1 } }
                toast(if (n >= 0) "CBZ ($n halaman): Android/data/com.niven.mangatl/files/manga/${target.name}" else "Ekspor gagal.")
            }
        })
        items.add(null)
        items.add(Sheet.Item("Tes halaman tertentu", R.drawable.ic_edit) { retestDialog(d) })
        items.add(Sheet.Item("Proses ulang semua", R.drawable.ic_refresh) {
            MangaEngine.outDir(d).deleteRecursively()
            resume(d)
        })
        items.add(Sheet.Item("Ulang halaman tanpa terjemahan", R.drawable.ic_refresh) { redoUntranslated(d) })
        items.add(null)
        items.add(Sheet.Item("Hapus", R.drawable.ic_trash, true) {
            Sheet.confirm(this, "Hapus hasil?", "\"${d.name}\" beserta hasilnya akan dihapus.", "Hapus", true) {
                d.deleteRecursively()
                refreshList()
            }
        })
        Sheet.menu(this, d.name, null, items)
    }

    private fun retestDialog(d: File) {
        Sheet.input(this, "Halaman yang diproses ulang", "mis. 43,44 atau 40-45", "", "Proses") { txt ->
            val want = HashSet<Int>()
            txt.split(",").forEach { part ->
                val q = part.trim().split("-")
                val a = q.getOrNull(0)?.trim()?.toIntOrNull()
                val b = q.getOrNull(1)?.trim()?.toIntOrNull() ?: a
                if (a != null && b != null) for (k in a..minOf(b, a + 200)) want.add(k)
            }
            var cnt = 0
            for (i in MangaEngine.pages(d).indices) if ((i + 1) in want && MangaEngine.outFile(d, i).delete()) cnt++
            if (cnt == 0) toast("Tidak ada halaman yang cocok.") else resume(d)
        }
    }

    private fun redoUntranslated(d: File) {
        val bf = File(d, "blocks.txt")
        if (!bf.exists()) {
            toast("Belum ada catatan halaman. Pakai \"Proses ulang semua\" sekali dulu.")
            return
        }
        val last = HashMap<Int, Int>()
        bf.readLines().forEach { l ->
            val q = l.trim().split(" ")
            if (q.size == 2) { val a = q[0].toIntOrNull(); val b = q[1].toIntOrNull(); if (a != null && b != null) last[a] = b }
        }
        var cnt = 0
        for (i in MangaEngine.pages(d).indices) if ((last[i + 1] ?: 0) == 0 && MangaEngine.outFile(d, i).delete()) cnt++
        if (cnt == 0) toast("Semua halaman sudah punya terjemahan.") else resume(d)
    }
}
