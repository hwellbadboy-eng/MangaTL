package com.niven.mangatl

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.view.WindowManager
import android.widget.Toast

// Layar Chat: suara AI (TTS) dan Mic (Whisper / pengenal suara bawaan, mode live).
// Fungsi ekstensi dari ChatActivity; keadaan dan siklus hidup layar tetap di ChatActivity.kt.

internal fun ChatActivity.updateVoiceButton() {
    btnVoice.text = if (Voice.autoSpeak(this)) "Suara: nyala" else "Suara: mati"
}

/** Ketuk balon AI: bacakan. Saat sedang bicara, ketukan diabaikan (berhenti lewat tombol "Suara"). */
internal fun ChatActivity.speakMsg(m: Msg) {
    if (Voice.speaking || Voice.playing) return
    if (Voice.findVoice(this) == null) {
        Toast.makeText(this, "Model suara belum ada.", Toast.LENGTH_LONG).show()
        return
    }
    Toast.makeText(this, "Membaca...", Toast.LENGTH_SHORT).show()
    Voice.speak(this, m.text) { err ->
        if (err != null) runOnUiThread {
            Toast.makeText(this, "Suara gagal: $err", Toast.LENGTH_LONG).show()
        }
    }
}

internal fun ChatActivity.updateMicLabel() {
    btnMic.text = micStatus ?: when {
        listening -> "Dengar..."
        live -> "Live"
        else -> "Mic"
    }
}

/** Ketuk Mic: sekali bicara. Ketuk saat mode live: keluar dari live. */
internal fun ChatActivity.onMic() {
    if (live) {
        setLive(false)
        return
    }
    if (listening) {
        // Whisper: ketuk saat merekam = anggap sudah selesai ngomong, langsung dikenali.
        if (!Ear.finishNow()) stopListening()
        return
    }
    if (sending) {
        Toast.makeText(this, "Tunggu jawaban selesai dulu.", Toast.LENGTH_SHORT).show()
        return
    }
    beginListening()
}

/** Tahan Mic: mode live ngobrol (dengar -> jawab bersuara -> dengar lagi, terus sampai dimatikan). */
internal fun ChatActivity.onMicLong(): Boolean {
    if (live) {
        setLive(false)
    } else {
        if (Voice.findVoice(this) == null) {
            Toast.makeText(this, "Mode live butuh model suara. Salin dulu model Supertonic.", Toast.LENGTH_LONG).show()
            return true
        }
        if (sending) {
            Toast.makeText(this, "Tunggu jawaban selesai dulu.", Toast.LENGTH_SHORT).show()
            return true
        }
        setLive(true)
        Voice.preload(this)
        Toast.makeText(this, "Mode live nyala. Ngobrol aja, ketuk Mic buat berhenti.", Toast.LENGTH_LONG).show()
        beginListening()
    }
    return true
}

internal fun ChatActivity.setLive(on: Boolean) {
    live = on
    if (on) {
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
    } else {
        window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        turn++
        stopListening()
        Voice.stop()
    }
    updateMicLabel()
}

internal fun ChatActivity.beginListening() {
    if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
        micPerm.launch(Manifest.permission.RECORD_AUDIO)
        return
    }
    startListening()
}

/** Dalam mode live: mulai dengar lagi setelah jeda singkat (biar ekor suara AI tidak ikut terekam). */
internal fun ChatActivity.relisten(delayMs: Long) {
    val t = turn
    handler.postDelayed({
        if (live && t == turn && !sending && !listening && !isFinishing) beginListening()
    }, delayMs)
}

/** Mic offline Whisper (kalau model Whisper sudah dipasang). */
internal fun ChatActivity.startListeningWhisper() {
    Voice.stop()
    listening = true
    micStatus = null
    updateMicLabel()
    input.setText("")
    Ear.listen(
        this,
        silenceMs = if (live) 1500 else 1300,
        onState = { s ->
            micStatus = when (s) {
                "load" -> "Memuat..."
                "think" -> "Proses..."
                else -> null
            }
            updateMicLabel()
        }
    ) { text, err ->
        micStatus = null
        listening = false
        updateMicLabel()
        when {
            !text.isNullOrBlank() && !sending -> send(text.trim())
            err == Ear.NOSPEECH -> {
                if (live) relisten(200)
                else Toast.makeText(this, "Suaranya nggak kedengeran, coba lagi.", Toast.LENGTH_SHORT).show()
            }
            err != null -> {
                whisperFailed = true
                if (live) setLive(false)
                Toast.makeText(
                    this, "Mic Whisper gagal ($err). Sementara pakai mic bawaan, ketuk Mic lagi.",
                    Toast.LENGTH_LONG
                ).show()
            }
            live -> relisten(300)
        }
    }
}

internal fun ChatActivity.startListening() {
    if (!whisperFailed && Ear.available(this)) {
        if (!micInfoShown) {
            micInfoShown = true
            Toast.makeText(this, "Mic: Whisper (${Ear.findModel(this)?.name})", Toast.LENGTH_SHORT).show()
        }
        startListeningWhisper()
        return
    }
    if (!micInfoShown) {
        micInfoShown = true
        Toast.makeText(
            this,
            if (whisperFailed) "Mic: bawaan HP (Whisper error)" else "Mic: bawaan HP (folder Whisper tidak kebaca)",
            Toast.LENGTH_LONG
        ).show()
    }
    Voice.stop()
    val r = try {
        // Full offline: pengenal on-device dulu. Yang biasa cuma cadangan dan dipaksa offline.
        if (Build.VERSION.SDK_INT >= 33 && SpeechRecognizer.isOnDeviceRecognitionAvailable(this)) {
            SpeechRecognizer.createOnDeviceSpeechRecognizer(this)
        } else if (SpeechRecognizer.isRecognitionAvailable(this)) {
            SpeechRecognizer.createSpeechRecognizer(this)
        } else {
            null
        }
    } catch (_: Throwable) {
        null
    }
    if (r == null) {
        Toast.makeText(this, "Pengenal suara tidak tersedia di HP ini.", Toast.LENGTH_LONG).show()
        if (live) setLive(false)
        return
    }
    recognizer = r
    r.setRecognitionListener(object : RecognitionListener {
        override fun onReadyForSpeech(params: Bundle?) {}
        override fun onBeginningOfSpeech() {}
        override fun onRmsChanged(rmsdB: Float) {}
        override fun onBufferReceived(buffer: ByteArray?) {}
        override fun onEndOfSpeech() {}
        override fun onEvent(eventType: Int, params: Bundle?) {}

        override fun onPartialResults(partialResults: Bundle?) {
            val t = partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
            if (!t.isNullOrBlank()) input.setText(t)
        }

        override fun onResults(results: Bundle?) {
            val t = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
            stopListening()
            if (!t.isNullOrBlank() && !sending) {
                input.setText("")
                send(t.trim())
            } else if (live) {
                relisten(300)
            }
        }

        override fun onError(error: Int) {
            stopListening()
            if (live) {
                when (error) {
                    // Diam / tidak ada ucapan / pengenal sibuk: dengar lagi diam-diam.
                    SpeechRecognizer.ERROR_NO_MATCH, SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> relisten(200)
                    SpeechRecognizer.ERROR_RECOGNIZER_BUSY -> relisten(800)
                    else -> {
                        setLive(false)
                        Toast.makeText(
                            this@startListening,
                            "Mode live berhenti (kode $error). Cek izin mikrofon / paket suara.",
                            Toast.LENGTH_LONG
                        ).show()
                    }
                }
                return
            }
            val msg = when (error) {
                6, 7 -> "Suaranya nggak kedengeran, coba lagi."
                9 -> "Izin mikrofon belum ada."
                12, 13 -> "Paket bahasa Indonesia untuk suara offline belum terpasang di HP."
                2, 1, 4 -> "Pengenal suara butuh internet atau paket suara offline."
                else -> "Gagal mendengar (kode $error)."
            }
            Toast.makeText(this@startListening, msg, Toast.LENGTH_LONG).show()
        }
    })
    val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
        .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
        .putExtra(RecognizerIntent.EXTRA_LANGUAGE, "id-ID")
        .putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "id-ID")
        .putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, packageName)
        .putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
        .putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, true)
        .putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
        // Jeda lebih lega: bisik / ngomong pelan-pelan tidak langsung dianggap selesai.
        .putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS, 1800L)
        .putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_POSSIBLY_COMPLETE_SILENCE_LENGTH_MILLIS, 1500L)
        .putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_MINIMUM_LENGTH_MILLIS, 400L)
    listening = true
    updateMicLabel()
    input.setText("")
    try {
        r.startListening(i)
    } catch (t: Throwable) {
        stopListening()
        if (live) setLive(false)
        Toast.makeText(this, "Gagal mulai mendengar: ${t.message}", Toast.LENGTH_LONG).show()
    }
}

internal fun ChatActivity.stopListening() {
    Ear.cancel()
    micStatus = null
    listening = false
    updateMicLabel()
    try {
        recognizer?.cancel()
        recognizer?.destroy()
    } catch (_: Throwable) {
    }
    recognizer = null
}
