package com.niven.mangatl

import android.animation.ArgbEvaluator
import android.animation.ValueAnimator
import android.content.ComponentName
import android.content.ContentUris
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.ColorMatrix
import android.graphics.ColorMatrixColorFilter
import android.graphics.LinearGradient
import android.graphics.Outline
import android.graphics.PorterDuff
import android.graphics.RenderEffect
import android.graphics.Shader
import android.graphics.Typeface
import android.graphics.drawable.PaintDrawable
import android.graphics.drawable.ShapeDrawable
import android.graphics.drawable.shapes.RectShape
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.provider.MediaStore
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.ViewOutlineProvider
import android.view.animation.AccelerateInterpolator
import android.view.animation.DecelerateInterpolator
import android.view.animation.OvershootInterpolator
import android.view.animation.PathInterpolator
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.view.WindowCompat
import androidx.core.widget.TextViewCompat
import androidx.lifecycle.lifecycleScope
import androidx.media3.common.Player
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.LinearSmoothScroller
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.bottomsheet.BottomSheetDialog
import com.google.common.util.concurrent.ListenableFuture
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/**
 * "Sedang diputar" sesuai desain Pemutar Musik + Audio Engine: cover penuh, badge Hi-Res,
 * seek, kontrol, lima tab efek (Bass, 3D, Vokal, Reverb, Efek) dengan popup parameter cepat.
 * Acak, ulang, suka, lirik, timer tidur, kecepatan, dan antrean ada di menu "Lainnya".
 */
class NowPlayingActivity : AppCompatActivity() {

    private lateinit var npRoot: FrameLayout
    private lateinit var ivArt: ImageView
    private lateinit var tvTitle: TextView
    private lateinit var tvArtist: TextView
    private lateinit var tvTimeCur: TextView
    private lateinit var tvTimeTot: TextView
    private lateinit var tvHiBadge: TextView
    private lateinit var tvHiState: TextView
    private lateinit var sbSeek: SeekBar
    private lateinit var btnPlay: ImageButton
    private lateinit var bunny: BunnyWebView
    private lateinit var btnFav: ImageButton
    private lateinit var tabs: LinearLayout
    private lateinit var visHost: FrameLayout
    private lateinit var popLayer: FrameLayout
    private lateinit var topBox: View
    private lateinit var bottomBox: View
    private var vis: VisualizerView? = null
    private var miku: MikuAvatar? = null

    // geometri mockup Usulan-B3 (lebar artboard 1159 px): semua ukuran diskalakan ke lebar layar lewat m()
    private var scaleW = 1f
    private fun m(px: Float): Float = px * scaleW / 1159f
    private fun mi(px: Float): Int = m(px).toInt()

    private lateinit var ivBlur: ImageView

    // lirik mini (di atas baris Hi-Res) dan layar lirik penuh
    private lateinit var miniWin: FrameLayout
    private lateinit var miniCol: LinearLayout
    private val miniLines = ArrayList<TextView>()
    private lateinit var lyricOverlay: FrameLayout
    private lateinit var ovBlur: ImageView
    private lateinit var ovThumb: ImageView
    private lateinit var ovTitle: TextView
    private lateinit var ovArtist: TextView
    private lateinit var ovEmpty: TextView
    private lateinit var rvLyrics: RecyclerView
    private var lyricScreenOpen = false
    private var lyricStatus = "Memuat lirik..."
    private val lineAnims = java.util.WeakHashMap<TextView, ValueAnimator>()

    private var future: ListenableFuture<MediaController>? = null
    private var controller: MediaController? = null
    private val handler = Handler(Looper.getMainLooper())
    private var dragging = false
    private var lastId: Long? = null
    private var lastIdx = -1
    private var track: Library.Track? = null
    private var lyrics: Lyrics.Result? = null
    private var curLine = -1
    private val speeds = floatArrayOf(0.75f, 1f, 1.25f, 1.5f, 2f)

    private class Tab(val fid: String?, val label: String, val box: FrameLayout, val l1: TextView, val l2: TextView, val dot: View, val col: View)

    private val tabList = ArrayList<Tab>()
    private var popFid: String? = null
    private val popRows = ArrayList<ParamRow>()

    private val tick = object : Runnable {
        override fun run() {
            updateProgress()
            for (r in popRows) r.tick()
            handler.postDelayed(this, 400)
        }
    }

    private val pickLyricFile = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        val t = track
        if (uri != null && t != null) {
            try {
                val text = contentResolver.openInputStream(uri)?.use { it.readBytes().toString(Charsets.UTF_8) } ?: ""
                if (Lyrics.parse(text, "") == null) {
                    Toast.makeText(this, "File kosong.", Toast.LENGTH_SHORT).show()
                } else {
                    Lyrics.save(this, t.id, text)
                    applyLyrics(Lyrics.parse(text, "Tersimpan"))
                }
            } catch (e: Exception) {
                Toast.makeText(this, "Gagal membaca file.", Toast.LENGTH_SHORT).show()
            }
        }
    }

    // ---- adapter layar lirik: baris 200 x 1159, teks 66 bold maks 2 baris, aktif putih membesar ----
    private class LineHolder(val row: FrameLayout, val tv: TextView) : RecyclerView.ViewHolder(row)

    private val lyricAdapter = object : RecyclerView.Adapter<LineHolder>() {
        override fun getItemCount() = lyrics?.lines?.size ?: 0

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): LineHolder {
            val row = FrameLayout(parent.context)
            row.layoutParams = RecyclerView.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, mi(200f))
            val tv = TextView(parent.context)
            tv.setTextSize(TypedValue.COMPLEX_UNIT_PX, m(66f))
            TextViewCompat.setLineHeight(tv, mi(84f))
            tv.maxLines = 2
            tv.ellipsize = android.text.TextUtils.TruncateAt.END
            tv.gravity = Gravity.CENTER_VERTICAL
            tv.pivotX = 0f
            tv.pivotY = m(100f)
            row.addView(tv, FrameLayout.LayoutParams(mi(900f), mi(200f)).apply { leftMargin = mi(62f) })
            return LineHolder(row, tv)
        }

        override fun onBindViewHolder(h: LineHolder, pos: Int) = bindLine(h, pos, false)

        override fun onBindViewHolder(h: LineHolder, pos: Int, payloads: MutableList<Any>) = bindLine(h, pos, payloads.isNotEmpty())
    }

    private fun bindLine(h: LineHolder, pos: Int, animate: Boolean) {
        val r = lyrics ?: return
        val l = r.lines[pos]
        h.tv.text = l.text.ifEmpty { "…" }
        h.row.setOnClickListener {
            if (r.synced && l.timeMs >= 0) {
                controller?.seekTo(l.timeMs)
                syncLyric(l.timeMs)
            }
        }
        styleLine(h.tv, lineState(pos), true, animate)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        AudioEngine.init(this)
        OutputCaps.init(this)
        // cover penuh sampai atas (di belakang status bar) dan bawah
        WindowCompat.setDecorFitsSystemWindows(window, false)
        window.statusBarColor = Color.TRANSPARENT
        window.navigationBarColor = Color.TRANSPARENT
        if (android.os.Build.VERSION.SDK_INT >= 29) window.isNavigationBarContrastEnforced = false
        setContentView(R.layout.activity_nowplaying)
        npRoot = findViewById(R.id.npRoot)
        ivArt = findViewById(R.id.ivArt)
        tvTitle = findViewById(R.id.tvTitle)
        tvArtist = findViewById(R.id.tvArtist)
        tvTimeCur = findViewById(R.id.tvTimeCur)
        tvTimeTot = findViewById(R.id.tvTimeTot)
        tvHiBadge = findViewById(R.id.tvHiBadge)
        tvHiState = findViewById(R.id.tvHiState)
        sbSeek = findViewById(R.id.sbSeek)
        btnPlay = findViewById(R.id.btnPlay)
        bunny = findViewById(R.id.bunnyWeb)
        bunny.onPlayPause = { controller?.let { if (it.isPlaying) it.pause() else it.play() } }
        bunny.onPrev = { controller?.seekToPreviousMediaItem() }
        bunny.onNext = { controller?.seekToNextMediaItem() }
        bunny.setup()
        btnFav = findViewById(R.id.btnFav)
        tabs = findViewById(R.id.tabs)
        visHost = findViewById(R.id.visHost)
        popLayer = findViewById(R.id.popLayer)
        topBox = findViewById(R.id.topBox)
        bottomBox = findViewById(R.id.bottomBox)

        npRoot.setOnApplyWindowInsetsListener { v, ins ->
            // systemWindowInsetBottom (API lama) ikut menghitung keyboard/IME dan inset sementara, bikin blok bawah naik.
            // Pakai bar sistem saja (tinggi bar navigasi), tanpa IME.
            val c = androidx.core.view.WindowInsetsCompat.toWindowInsetsCompat(ins, v)
            val bars = c.getInsets(androidx.core.view.WindowInsetsCompat.Type.systemBars())
            android.util.Log.d(
                "NowPlayingInset",
                "legacyBottom=${ins.systemWindowInsetBottom} barsBottom=${bars.bottom} " +
                    "imeBottom=${c.getInsets(androidx.core.view.WindowInsetsCompat.Type.ime()).bottom}"
            )
            bottomBox.setPadding(bottomBox.paddingLeft, 0, bottomBox.paddingRight, bars.bottom + Ui.dp(this, 8))
            ins
        }

        scaleW = resources.displayMetrics.widthPixels.toFloat()

        // judul + artis: kotak di y=150, judul 44 bold, artis 36 #D6D6D6 (jarak 8), bayangan teks 0 2 12
        (topBox.layoutParams as ViewGroup.MarginLayoutParams).topMargin = mi(150f)
        topBox.setPadding(mi(62f), 0, mi(62f), 0)
        tvTitle.setTextSize(TypedValue.COMPLEX_UNIT_PX, m(44f))
        tvArtist.setTextSize(TypedValue.COMPLEX_UNIT_PX, m(36f))
        (tvArtist.layoutParams as ViewGroup.MarginLayoutParams).topMargin = mi(8f)
        for (t in arrayOf(tvTitle, tvArtist)) t.setShadowLayer(m(12f), 0f, m(2f), 0xB3000000.toInt())

        // latar blur: kotak lebar x 1900, cover 2508 px digeser (-675, -297), blur 100, redup 0,72, saturasi 1,3
        findViewById<View>(R.id.bgBox).layoutParams = FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, mi(1900f))
        ivBlur = findViewById(R.id.ivBlur)
        ivBlur.layoutParams = FrameLayout.LayoutParams(mi(2508f), mi(2508f)).apply {
            leftMargin = -mi(675f)
            topMargin = -mi(297f)
        }
        ivBlur.colorFilter = tintFilter(0.72f)

        // cover 1:1 selebar layar (tidak di-crop / di-zoom), top 190, memudar atas 0-20% dan bawah 76-100%
        findViewById<FadeMask>(R.id.coverBox).apply {
            layoutParams = FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, scaleW.toInt()).apply { topMargin = mi(190f) }
            setStops(floatArrayOf(0f, 0.20f, 0.76f, 1f), intArrayOf(0, 255, 255, 0))
        }
        // placeholder cover (gradasi radial seperti desain) kalau lagu tidak punya gambar
        ivArt.background = GradientDrawable().apply {
            gradientType = GradientDrawable.RADIAL_GRADIENT
            gradientRadius = Ui.dp(this@NowPlayingActivity, 460).toFloat()
            setGradientCenter(0.5f, 0.3f)
            colors = intArrayOf(0xFFE2E2E8.toInt(), 0xFF8A8A92.toInt(), 0xFF0B0B0D.toInt())
        }

        // gradasi hitam di bawah latar blur: transparan sampai 25%, hitam penuh mulai 68%
        findViewById<View>(R.id.scrimBottom).apply {
            layoutParams = FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, mi(1900f))
            background = PaintDrawable().apply {
                shape = RectShape()
                shaderFactory = object : ShapeDrawable.ShaderFactory() {
                    override fun resize(width: Int, height: Int): Shader = LinearGradient(
                        0f, 0f, 0f, height.toFloat(),
                        intArrayOf(0x00000000, 0x00000000, 0xFF000000.toInt(), 0xFF000000.toInt()),
                        floatArrayOf(0f, 0.25f, 0.68f, 1f), Shader.TileMode.CLAMP
                    )
                }
            }
        }

        buildLyricViews()
        buildTabs()

        findViewById<View>(R.id.hiresBtn).setOnClickListener { togglePop(AudioEngine.HIRES, it.x + it.width / 2f) }
        btnPlay.setOnClickListener { controller?.let { if (it.isPlaying) it.pause() else it.play() } }
        findViewById<View>(R.id.btnPrev).setOnClickListener { controller?.seekToPreviousMediaItem() }
        findViewById<View>(R.id.btnNext).setOnClickListener { controller?.seekToNextMediaItem() }
        btnFav.setOnClickListener { toggleFav() }
        findViewById<View>(R.id.btnMore).setOnClickListener { showMore() }
        popLayer.setOnClickListener { hidePop() }

        sbSeek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar?, p: Int, fromUser: Boolean) {
                if (fromUser) tvTimeCur.text = Library.fmt(p.toLong())
            }

            override fun onStartTrackingTouch(sb: SeekBar?) {
                dragging = true
            }

            override fun onStopTrackingTouch(sb: SeekBar?) {
                dragging = false
                controller?.seekTo((sb?.progress ?: 0).toLong())
            }
        })

        // avatar Miku badan penuh di kotak kanan-bawah, di BAWAH ikon / visualizer / seekbar (disisipkan sebelum bottomBox)
        miku = MikuAvatar(this, npRoot, btnFav, findViewById(R.id.bottomBox)).also { it.attach() }

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                when {
                    popLayer.visibility == View.VISIBLE -> hidePop()
                    lyricScreenOpen -> setLyricScreen(false)
                    else -> finish()
                }
            }
        })
    }

    override fun onStart() {
        super.onStart()
        val token = SessionToken(this, ComponentName(this, PlayerService::class.java))
        val f = MediaController.Builder(this, token).buildAsync()
        future = f
        f.addListener({
            try {
                val c = f.get()
                controller = c
                lastIdx = c.currentMediaItemIndex
                c.addListener(object : Player.Listener {
                    override fun onMediaItemTransition(mediaItem: androidx.media3.common.MediaItem?, reason: Int) {
                        val i = c.currentMediaItemIndex
                        if (lastIdx >= 0 && i != lastIdx) {
                            val wrapFwd = i == 0 && lastIdx == c.mediaItemCount - 1
                            bunny.skip(if (i > lastIdx || wrapFwd) 1 else -1)
                        }
                        lastIdx = i
                    }
                    override fun onEvents(player: Player, events: Player.Events) = updateUi()
                })
                updateUi()
                handler.post(tick)
            } catch (e: Exception) {
                Toast.makeText(this, "Pemutar gagal tersambung", Toast.LENGTH_LONG).show()
            }
        }, ContextCompat.getMainExecutor(this))
    }

    override fun onResume() {
        super.onResume()
        bunny.onResume()
        miku?.onResume()
        refreshAll()
    }

    override fun onPause() {
        bunny.onPause()
        miku?.onPause()
        super.onPause()
    }

    override fun onDestroy() {
        bunny.destroy()
        miku?.onDestroy()
        miku = null
        super.onDestroy()
    }

    override fun onStop() {
        handler.removeCallbacks(tick)
        future?.let { MediaController.releaseFuture(it) }
        future = null
        controller = null
        super.onStop()
    }

    // ---------- tab efek + popup ----------

    private fun buildTabs() {
        val defs = listOf(
            Pair("BASS", AudioEngine.BASS), Pair("3D", AudioEngine.SPATIAL), Pair("VOKAL", AudioEngine.VOCAL),
            Pair("REVERB", AudioEngine.REVERB), Pair("EFEK", null as String?)
        )
        for ((idx, def) in defs.withIndex()) {
            val (label, fid) = def
            val edge = when (idx) { 0 -> Gravity.START; defs.size - 1 -> Gravity.END; else -> Gravity.CENTER_HORIZONTAL }
            val box = FrameLayout(this)
            val col = LinearLayout(this)
            col.orientation = LinearLayout.VERTICAL
            col.gravity = Gravity.CENTER
            val l1 = TextView(this)
            l1.text = label
            l1.textSize = 13f
            l1.letterSpacing = 0.14f
            l1.gravity = Gravity.CENTER
            val l2 = TextView(this)
            l2.textSize = 11f
            l2.gravity = Gravity.CENTER
            col.addView(l1)
            col.addView(l2)
            // Tab pertama rata kiri, terakhir rata kanan (sejajar tepi waktu/seekbar); sisanya tetap di tengah kolom.
            // Teks bawah (0 dB / 5 aktif) tetap di tengah di bawah judulnya.
            if (edge == Gravity.CENTER_HORIZONTAL) {
                box.addView(col, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
            } else {
                box.addView(col, FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.MATCH_PARENT, edge))
                // letterSpacing menambah jarak setelah huruf terakhir; geser supaya huruf "K" benar-benar rata kanan.
                if (edge == Gravity.END) l1.translationX = l1.textSize * l1.letterSpacing
            }
            val dot = View(this)
            dot.background = AU.shape(Color.WHITE, 2f, this)
            val dl = FrameLayout.LayoutParams(Ui.dp(this, 4), Ui.dp(this, 4), Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL)
            dl.bottomMargin = Ui.dp(this, 4)
            box.addView(dot, dl)
            // titik indikator mengikuti titik tengah teks, bukan tengah kolom
            col.addOnLayoutChangeListener { _, l, _, r, _, _, _, _, _ ->
                dot.translationX = (l + r) / 2f - box.width / 2f
            }
            val t = Tab(fid, label, box, l1, l2, dot, col)
            tabList.add(t)
            box.setOnClickListener {
                if (fid == null) startActivity(android.content.Intent(this, AudioEngineActivity::class.java))
                else togglePop(fid, box.x + col.left + col.width / 2f)
            }
            tabs.addView(box, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f))
        }
    }

    private fun refreshTabs() {
        val d = resources.displayMetrics.density
        for (t in tabList) {
            val fid = t.fid
            if (fid == null) {
                t.l1.setTextColor(Color.WHITE)
                val n = AudioEngine.features.count { it.id != AudioEngine.AVATAR && AudioEngine.isOn(it.id) }
                t.l2.text = "$n aktif"
                t.l2.setTextColor(Color.WHITE)
                t.l2.alpha = 0.7f
                t.dot.visibility = View.GONE
                continue
            }
            val on = AudioEngine.isOn(fid)
            val f = AudioEngine.feature(fid)
            val qi = f.quick.firstOrNull() ?: 0
            val p = f.params[qi]
            t.l2.text = if (!on) "mati" else {
                val v = AudioEngine.get(fid, qi)
                if (p is PNum) AU.fmt(v) + (if (p.unit.isEmpty()) "" else " " + p.unit) else ""
            }
            t.l1.setTextColor(if (on) Color.WHITE else AU.MUT)
            t.l2.setTextColor(if (on) Color.WHITE else AU.MUT)
            t.l1.animate().translationY(if (on) -7 * d else 0f).setDuration(320).setInterpolator(OvershootInterpolator(1.4f)).start()
            t.l2.animate().translationY(if (on) -5 * d else 0f).alpha(if (on) 0.9f else 0.7f).setDuration(320)
                .setInterpolator(OvershootInterpolator(1.4f)).start()
            t.dot.visibility = if (on) View.VISIBLE else View.GONE
        }
    }

    private fun hiResText(): String {
        if (!AudioEngine.isOn(AudioEngine.HIRES)) return "Hi-Res mati"
        val v = AudioEngine.raw(AudioEngine.HIRES)
        if (v.size > 5 && v[5].toInt() == 1) return if (OutputCaps.bitPerfectAvailable()) "Bit-perfect" else "Bit-perfect tidak tersedia"
        // format yang benar-benar dikirim ke Android (bukan sekadar pengaturan), kalau sudah ada aliran aktif
        val actual = AudioEngine.outputInfo
        if (actual.isNotEmpty()) return actual
        val rates = arrayOf("Auto", "44.1", "48", "88.2", "96", "176.4", "192")
        val r = v[0].toInt().coerceIn(0, 6)
        val b = v[1].toInt().coerceIn(0, 3)
        val rate = if (r == 0) "Auto" else rates[r] + " kHz"
        val bit = if (b == 0) "Auto" else "${intArrayOf(0, 16, 24, 32)[b]} bit"
        return "$bit / $rate"
    }

    private fun updateHiState() {
        val on = AudioEngine.isOn(AudioEngine.HIRES)
        if (on) {
            tvHiBadge.background = AU.shape(Color.WHITE, 6f, this)
            tvHiBadge.setTextColor(Color.BLACK)
        } else {
            tvHiBadge.background = AU.shape(0, 6f, this, Color.WHITE, 2)
            tvHiBadge.setTextColor(Color.WHITE)
        }
        tvHiState.text = hiResText()
    }

    private fun refreshAll() {
        refreshTabs()
        updateHiState()
        val showVis = AudioEngine.isOn(AudioEngine.VIS)
        if (showVis && vis == null) {
            val v = VisualizerView(this)
            vis = v
            // area visHost cuma menyediakan tempat; ukuran & posisi visualizer diatur dari pengaturan
            visHost.clipChildren = false
            (bottomBox as ViewGroup).clipChildren = false
            npRoot.clipChildren = false
            visHost.addView(v, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, Ui.dp(this, 64), Gravity.BOTTOM))
            // JANGAN bringToFront(): di LinearLayout vertikal itu memindahkan visHost ke dasar daftar anak
            // (di bawah tab) dan mendorong semua kontrol naik. Cukup dinaikkan Z-nya supaya digambar paling atas.
            visHost.translationZ = Ui.dp(this, 4).toFloat()
            // tanpa ini semua yang digambar di luar padding bottomBox (geser X/Y jauh) terpotong dan "hilang"
            (bottomBox as ViewGroup).clipToPadding = false
        }
        visHost.visibility = if (showVis) View.VISIBLE else View.GONE
        for (r in popRows) r.refresh()
        val pf = popFid
        popBody?.alpha = if (pf != null && !AudioEngine.featureOn(pf)) 0.45f else 1f
    }

    private var popClosing = false
    private var popBody: View? = null

    private fun togglePop(fid: String, anchorX: Float) {
        if (popLayer.visibility == View.VISIBLE && popFid == fid && !popClosing) {
            hidePop()
            return
        }
        showPop(fid, anchorX)
    }

    private fun clearPop() {
        popLayer.visibility = View.GONE
        popLayer.removeAllViews()
        popRows.clear()
        popFid = null
        popBody = null
        popClosing = false
    }

    /** Tutup popup: mengecil ke tombol tab (kebalikan animasi buka, seperti desain). */
    private fun hidePop() {
        if (popLayer.visibility != View.VISIBLE || popClosing) return
        val card = popLayer.getChildAt(0)
        if (card == null) {
            clearPop()
            return
        }
        popClosing = true
        card.animate().cancel()
        card.animate().alpha(0f).scaleX(0.04f).scaleY(0.04f).setDuration(300)
            .setInterpolator(AccelerateInterpolator(1.4f))
            .withEndAction { if (popLayer.getChildAt(0) === card) clearPop() }
            .start()
    }

    private fun showPop(fid: String, anchorX: Float) {
        popLayer.getChildAt(0)?.animate()?.cancel()
        popLayer.removeAllViews()
        popRows.clear()
        popClosing = false
        popFid = fid
        val f = AudioEngine.feature(fid)
        val w = npRoot.width
        val cardW = minOf(Ui.dp(this, 304), w - Ui.dp(this, 24))
        val maxH = (npRoot.height * 0.42f).toInt()

        val card = LinearLayout(this)
        card.orientation = LinearLayout.VERTICAL
        card.background = AU.shape(0xFF1C1C20.toInt(), 22f, this, 0xFF2E2E34.toInt(), 1)
        card.isClickable = true
        card.elevation = Ui.dp(this, 12).toFloat()

        val head = LinearLayout(this)
        head.orientation = LinearLayout.HORIZONTAL
        head.gravity = Gravity.CENTER_VERTICAL
        head.setPadding(Ui.dp(this, 16), Ui.dp(this, 12), Ui.dp(this, 16), Ui.dp(this, 4))
        head.addView(AU.text(this, f.title, 15f, Color.WHITE, true), LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        val reset = AU.text(this, "Reset", 13f, AU.MUT)
        reset.setPadding(Ui.dp(this, 8), Ui.dp(this, 8), Ui.dp(this, 12), Ui.dp(this, 8))
        reset.setOnClickListener {
            AudioEngine.resetFeature(fid)
            refreshAll()
        }
        head.addView(reset)
        head.addView(AU.switch(this, AudioEngine.featureOn(fid)) { v ->
            AudioEngine.setOn(fid, v)
            refreshAll()
        })
        card.addView(head)

        val sv = ScrollView(this)
        sv.isVerticalScrollBarEnabled = false
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(Ui.dp(this, 16), 0, Ui.dp(this, 2), Ui.dp(this, 8))
        // semua parameter fitur (seperti desain), bukan hanya yang "quick"
        for (qi in f.params.indices) {
            val r = ParamRow(this, fid, qi, true) { refreshAll() }
            popRows.add(r)
            col.addView(r.view)
        }
        col.alpha = if (AudioEngine.featureOn(fid)) 1f else 0.45f
        popBody = col
        sv.addView(col)
        val rail = RailView(this, sv)
        sv.setOnScrollChangeListener { _, _, _, _, _ -> rail.invalidate() }
        val body = LinearLayout(this)
        body.orientation = LinearLayout.HORIZONTAL
        body.addView(sv, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f))
        val rl = LinearLayout.LayoutParams(Ui.dp(this, 28), ViewGroup.LayoutParams.MATCH_PARENT)
        rl.topMargin = Ui.dp(this, 6)
        rl.bottomMargin = Ui.dp(this, 10)
        body.addView(rail, rl)

        col.measure(
            View.MeasureSpec.makeMeasureSpec(cardW - Ui.dp(this, 28), View.MeasureSpec.EXACTLY),
            View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED)
        )
        head.measure(
            View.MeasureSpec.makeMeasureSpec(cardW, View.MeasureSpec.EXACTLY),
            View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED)
        )
        val bodyH = minOf(col.measuredHeight, maxH - head.measuredHeight).coerceAtLeast(Ui.dp(this, 80))
        // rail hanya muncul kalau isi memang bisa digulir
        rail.visibility = if (col.measuredHeight > bodyH + 1) View.VISIBLE else View.INVISIBLE
        card.addView(body, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, bodyH))

        // lapisan popup berhenti tepat di atas tab bar, jadi tab lain tetap bisa diketuk
        val tl = IntArray(2)
        val rl2 = IntArray(2)
        tabs.getLocationOnScreen(tl)
        npRoot.getLocationOnScreen(rl2)
        (popLayer.layoutParams as ViewGroup.MarginLayoutParams).bottomMargin = (rl2[1] + npRoot.height) - tl[1]
        popLayer.requestLayout()
        val lp = FrameLayout.LayoutParams(cardW, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL)
        lp.bottomMargin = Ui.dp(this, 6)
        popLayer.addView(card, lp)
        popLayer.visibility = View.VISIBLE
        card.alpha = 0f
        card.scaleX = 0.04f
        card.scaleY = 0.04f
        val anchorScreenX = tl[0] + anchorX
        card.post {
            card.pivotY = card.height.toFloat()
            card.pivotX = (anchorScreenX - card.left).coerceIn(0f, card.width.toFloat())
            card.animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(380)
                .setInterpolator(DecelerateInterpolator(1.6f)).start()
        }
    }

    // ---------- menu Lainnya ----------

    private fun showMore() {
        val d = BottomSheetDialog(this)
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.background = GradientDrawable().apply {
            setColor(0xFF1A1A1E.toInt())
            val r = Ui.dp(this@NowPlayingActivity, 24).toFloat()
            cornerRadii = floatArrayOf(r, r, r, r, 0f, 0f, 0f, 0f)
        }
        col.setPadding(Ui.dp(this, 20), Ui.dp(this, 20), Ui.dp(this, 20), Ui.dp(this, 24))
        col.addView(AU.text(this, "Lainnya", 20f, Color.WHITE, true))

        class Item(val icon: Int, val label: String, val value: () -> String, val onClick: () -> Unit)
        val items = listOf(
            Item(R.drawable.ic_shuffle, "Acak", { if (controller?.shuffleModeEnabled == true) "Aktif" else "" }) {
                controller?.let { it.shuffleModeEnabled = !it.shuffleModeEnabled }
                Toast.makeText(this, if (controller?.shuffleModeEnabled == true) "Acak aktif" else "Acak mati", Toast.LENGTH_SHORT).show()
            },
            Item(R.drawable.ic_repeat, "Ulang", {
                when (controller?.repeatMode) {
                    Player.REPEAT_MODE_ALL -> "Semua"
                    Player.REPEAT_MODE_ONE -> "Satu lagu"
                    else -> ""
                }
            }) {
                controller?.let {
                    it.repeatMode = when (it.repeatMode) {
                        Player.REPEAT_MODE_OFF -> Player.REPEAT_MODE_ALL
                        Player.REPEAT_MODE_ALL -> Player.REPEAT_MODE_ONE
                        else -> Player.REPEAT_MODE_OFF
                    }
                }
            },
            Item(R.drawable.ic_fav_border, "Suka", { if (isFavNow()) "Aktif" else "" }) { toggleFav() },
            Item(R.drawable.ic_lyrics, "Lirik", { "" }) {
                d.dismiss()
                lyricActionsSheet()
            },
            Item(R.drawable.ic_timer, "Timer tidur", {
                val left = (PlayerService.instance?.sleepEndAt ?: 0L) - SystemClock.elapsedRealtime()
                if (left > 0) "${(left / 60000) + 1} menit" else ""
            }) {
                d.dismiss()
                sleepDialog()
            },
            Item(R.drawable.ic_speed, "Kecepatan", {
                val sp = controller?.playbackParameters?.speed ?: 1f
                if (sp == 1f) "1x" else if (sp == sp.toInt().toFloat()) "${sp.toInt()}x" else "${sp}x"
            }) {
                d.dismiss()
                speedDialog()
            },
            Item(R.drawable.ic_queue, "Antrean", { "" }) {
                d.dismiss()
                queueDialog()
            }
        )
        val valueViews = ArrayList<TextView>()
        for (item in items) {
            val row = LinearLayout(this)
            row.orientation = LinearLayout.HORIZONTAL
            row.gravity = Gravity.CENTER_VERTICAL
            row.minimumHeight = Ui.dp(this, 56)
            val ic = ImageView(this)
            ic.setImageResource(item.icon)
            ic.setColorFilter(AU.MUT, PorterDuff.Mode.SRC_IN)
            row.addView(ic, LinearLayout.LayoutParams(Ui.dp(this, 22), Ui.dp(this, 22)))
            val lb = AU.text(this, item.label, 15f, Color.WHITE)
            lb.setPadding(Ui.dp(this, 12), 0, 0, 0)
            row.addView(lb, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
            val vt = AU.text(this, item.value(), 12f, AU.MUT)
            valueViews.add(vt)
            row.addView(vt)
            row.setOnClickListener {
                item.onClick()
                for ((i, v) in valueViews.withIndex()) v.text = items[i].value()
                updateUi()
            }
            col.addView(row)
            val line = View(this)
            line.setBackgroundColor(0xFF1F1F23.toInt())
            col.addView(line, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 1))
        }
        d.setContentView(col)
        d.setOnShowListener {
            d.findViewById<View>(com.google.android.material.R.id.design_bottom_sheet)?.setBackgroundColor(Color.TRANSPARENT)
        }
        d.show()
    }

    private fun isFavNow(): Boolean {
        val id = controller?.currentMediaItem?.mediaId?.toLongOrNull() ?: return false
        return MusicStore.isFav(this, id)
    }

    private fun toggleFav() {
        val id = controller?.currentMediaItem?.mediaId?.toLongOrNull() ?: return
        MusicStore.toggleFav(this, id)
        Toast.makeText(this, if (MusicStore.isFav(this, id)) "Ditambahkan ke Suka" else "Dihapus dari Suka", Toast.LENGTH_SHORT).show()
        updateUi()
    }

    private fun tintFilter(brightness: Float): ColorMatrixColorFilter {
        val b = brightness
        val cm = ColorMatrix().apply { setSaturation(1.3f) }
        cm.postConcat(ColorMatrix(floatArrayOf(b, 0f, 0f, 0f, 0f, 0f, b, 0f, 0f, 0f, 0f, 0f, b, 0f, 0f, 0f, 0f, 0f, 1f, 0f)))
        return ColorMatrixColorFilter(cm)
    }

    /** Pasang cover ke semua tempat: cover 1:1, tamnel layar lirik, dan dua latar blur. */
    private fun setArt(bmp: Bitmap?) {
        ivArt.setImageBitmap(bmp)
        ovThumb.setImageBitmap(bmp)
        // Android 12+ memakai RenderEffect (dipasang di buildLyricViews); di bawahnya bitmap kecil yang diperbesar sudah buram
        val soft = if (bmp != null && Build.VERSION.SDK_INT < 31) Bitmap.createScaledBitmap(bmp, 48, 48, true) else bmp
        ivBlur.setImageBitmap(soft)
        ovBlur.setImageBitmap(soft)
    }

    private fun buildLyricViews() {
        val match = ViewGroup.LayoutParams.MATCH_PARENT
        val wrap = ViewGroup.LayoutParams.WRAP_CONTENT

        // ---- lirik mini: kotak 560 x 132 (2 baris x 66), menumpang di slot 64dp di atas baris Hi-Res ----
        miniWin = FrameLayout(this)
        miniWin.isClickable = true
        miniWin.contentDescription = "Buka layar lirik"
        miniCol = LinearLayout(this)
        miniCol.orientation = LinearLayout.VERTICAL
        miniWin.addView(miniCol, FrameLayout.LayoutParams(match, wrap))
        miniWin.setOnClickListener { if (lyrics != null) setLyricScreen(true) else lyricActionsSheet() }
        findViewById<FrameLayout>(R.id.lyricSlot).addView(
            miniWin, 0, FrameLayout.LayoutParams(mi(560f), mi(132f)).apply { topMargin = mi(24f) }
        )

        // ---- layar lirik penuh: 1159 x 1400 di atas cover, di bawah kontrol ----
        lyricOverlay = FrameLayout(this)
        lyricOverlay.visibility = View.GONE
        lyricOverlay.alpha = 0f
        lyricOverlay.isClickable = true

        // latar: cover blur lebih gelap (0,5) + lapisan hitam 35%, memudar di dasar (78% -> 100%)
        val bgMask = FadeMask(this)
        bgMask.setStops(floatArrayOf(0f, 0.78f, 1f), intArrayOf(255, 255, 0))
        val bgInner = FrameLayout(this)
        bgInner.setBackgroundColor(Color.BLACK)
        ovBlur = ImageView(this)
        ovBlur.scaleType = ImageView.ScaleType.CENTER_CROP
        ovBlur.colorFilter = tintFilter(0.5f)
        bgInner.addView(ovBlur, FrameLayout.LayoutParams(mi(2576f), mi(2576f)).apply {
            leftMargin = -mi(708f)
            topMargin = -mi(400f)
        })
        bgInner.addView(View(this).apply { setBackgroundColor(0x59000000) }, FrameLayout.LayoutParams(match, match))
        bgMask.addView(bgInner, FrameLayout.LayoutParams(match, match))
        lyricOverlay.addView(bgMask, FrameLayout.LayoutParams(match, match))
        if (Build.VERSION.SDK_INT >= 31) {
            val blur = RenderEffect.createBlurEffect(m(100f), m(100f), Shader.TileMode.CLAMP)
            ivBlur.setRenderEffect(blur)
            ovBlur.setRenderEffect(blur)
        }

        // kepala: tamnel 150 (sudut 20) di (62,130), judul/artis di x=244 y=160, tombol tutup 120 di kanan
        ovThumb = ImageView(this)
        ovThumb.scaleType = ImageView.ScaleType.CENTER_CROP
        ovThumb.clipToOutline = true
        ovThumb.outlineProvider = object : ViewOutlineProvider() {
            override fun getOutline(v: View, o: Outline) = o.setRoundRect(0, 0, v.width, v.height, m(20f))
        }
        lyricOverlay.addView(ovThumb, FrameLayout.LayoutParams(mi(150f), mi(150f)).apply {
            leftMargin = mi(62f)
            topMargin = mi(130f)
        })
        val head = LinearLayout(this)
        head.orientation = LinearLayout.VERTICAL
        ovTitle = TextView(this).apply {
            setTextSize(TypedValue.COMPLEX_UNIT_PX, m(44f))
            setTypeface(null, Typeface.BOLD)
            setTextColor(Color.WHITE)
            maxLines = 1
            ellipsize = android.text.TextUtils.TruncateAt.END
        }
        ovArtist = TextView(this).apply {
            setTextSize(TypedValue.COMPLEX_UNIT_PX, m(36f))
            setTextColor(0xFFD6D6D6.toInt())
            maxLines = 1
            ellipsize = android.text.TextUtils.TruncateAt.END
        }
        head.addView(ovTitle)
        head.addView(ovArtist, LinearLayout.LayoutParams(match, wrap).apply { topMargin = mi(8f) })
        lyricOverlay.addView(head, FrameLayout.LayoutParams(scaleW.toInt() - mi(244f) - mi(62f + 120f + 24f), wrap).apply {
            leftMargin = mi(244f)
            topMargin = mi(160f)
        })
        val close = ImageButton(this)
        close.setImageResource(R.drawable.ic_down)
        close.setColorFilter(Color.WHITE)
        close.scaleType = ImageView.ScaleType.FIT_CENTER
        close.setPadding(mi(26f), mi(26f), mi(26f), mi(26f))
        close.background = GradientDrawable().apply {
            shape = GradientDrawable.OVAL
            setColor(0x29FFFFFF)
        }
        close.contentDescription = "Tutup lirik"
        close.setOnClickListener { setLyricScreen(false) }
        lyricOverlay.addView(close, FrameLayout.LayoutParams(mi(120f), mi(120f), Gravity.END or Gravity.TOP).apply {
            rightMargin = mi(62f)
            topMargin = mi(115f)
        })

        // daftar lirik: y=330 tinggi 1070, memudar 0-10% dan 78-100%; baris aktif berhenti di y=180 dalam daftar
        val listMask = FadeMask(this)
        listMask.setStops(floatArrayOf(0f, 0.10f, 0.78f, 1f), intArrayOf(0, 255, 255, 0))
        rvLyrics = RecyclerView(this)
        rvLyrics.layoutManager = LinearLayoutManager(this)
        rvLyrics.adapter = lyricAdapter
        rvLyrics.itemAnimator = null
        rvLyrics.overScrollMode = View.OVER_SCROLL_NEVER
        rvLyrics.clipToPadding = false
        rvLyrics.setPadding(0, mi(180f), 0, mi(1070f - 180f - 200f))
        listMask.addView(rvLyrics, FrameLayout.LayoutParams(match, match))
        lyricOverlay.addView(listMask, FrameLayout.LayoutParams(match, mi(1070f)).apply { topMargin = mi(330f) })

        ovEmpty = TextView(this)
        ovEmpty.setTextSize(TypedValue.COMPLEX_UNIT_PX, m(44f))
        ovEmpty.setTextColor(0x99FFFFFF.toInt())
        ovEmpty.gravity = Gravity.CENTER
        ovEmpty.text = lyricStatus
        lyricOverlay.addView(ovEmpty, FrameLayout.LayoutParams(match, wrap).apply {
            topMargin = mi(330f + 400f)
            leftMargin = mi(62f)
            rightMargin = mi(62f)
        })

        npRoot.addView(lyricOverlay, npRoot.indexOfChild(topBox) + 1, FrameLayout.LayoutParams(match, mi(1400f)))
    }

    /** Buka / tutup layar lirik: layar lirik muncul 0,35 dtk, lirik mini hilang bersamaan. */
    private fun setLyricScreen(open: Boolean) {
        if (lyricScreenOpen == open) return
        lyricScreenOpen = open
        lyricOverlay.animate().cancel()
        miniWin.animate().cancel()
        if (open) {
            lyricOverlay.visibility = View.VISIBLE
            lyricOverlay.animate().alpha(1f).setDuration(350).start()
            miniWin.animate().alpha(0f).setDuration(350).withEndAction { if (lyricScreenOpen) miniWin.visibility = View.INVISIBLE }.start()
            scrollLyricsTo(curLine.coerceAtLeast(0), false)
        } else {
            miniWin.visibility = View.VISIBLE
            miniWin.animate().alpha(1f).setDuration(350).start()
            lyricOverlay.animate().alpha(0f).setDuration(350).withEndAction { if (!lyricScreenOpen) lyricOverlay.visibility = View.GONE }.start()
        }
    }

    /** Taruh baris idx di posisi aktif (y=180 dalam daftar); smooth = geser 0,6 dtk. */
    private fun scrollLyricsTo(idx: Int, smooth: Boolean) {
        if (idx < 0 || idx >= lyricAdapter.itemCount) return
        val lm = rvLyrics.layoutManager as LinearLayoutManager
        if (!smooth) {
            lm.scrollToPositionWithOffset(idx, mi(180f))
            return
        }
        val sc = object : LinearSmoothScroller(this) {
            override fun getVerticalSnapPreference() = SNAP_TO_START
            override fun calculateTimeForScrolling(dx: Int) = 600
            override fun calculateTimeForDeceleration(dx: Int) = 600
        }
        sc.targetPosition = idx
        lm.startSmoothScroll(sc)
    }

    /** 0 = baris biasa (redup), 1 = baris aktif, 2 = lirik tanpa waktu (semua netral). */
    private fun lineState(pos: Int): Int = if (lyrics?.synced != true) 2 else if (pos == curLine) 1 else 0

    /**
     * Gaya satu baris lirik. full = layar lirik (redup 0,45, aktif x1,14, redup x0,86, glow 36),
     * bukan full = lirik mini (redup 0,5, aktif x1,15, glow 18). Warna 0,4 dtk, skala 0,6 dtk.
     */
    private fun styleLine(tv: TextView, state: Int, full: Boolean, animate: Boolean) {
        val on = state == 1
        val toColor = when (state) {
            1 -> Color.WHITE
            2 -> 0xD9FFFFFF.toInt()
            else -> if (full) 0x73FFFFFF.toInt() else 0x80FFFFFF.toInt()
        }
        val toScale = when {
            on -> if (full) 1.14f else 1.15f
            state == 2 || !full -> 1f
            else -> 0.86f
        }
        val glowR = m(if (full) 36f else 18f)
        val toGlow = if (on) ((if (full) 0.4f else 0.45f) * 255).toInt() else 0
        tv.typeface = if (on || full) Typeface.DEFAULT_BOLD else Typeface.create("sans-serif-medium", Typeface.NORMAL)
        lineAnims.remove(tv)?.cancel()
        tv.animate().cancel()
        if (!animate) {
            tv.scaleX = toScale
            tv.scaleY = toScale
            tv.setTextColor(toColor)
            tv.setShadowLayer(glowR, 0f, 0f, Color.argb(toGlow, 255, 255, 255))
            return
        }
        tv.animate().scaleX(toScale).scaleY(toScale).setDuration(600).setInterpolator(PathInterpolator(0.22f, 1f, 0.36f, 1f)).start()
        val from = tv.currentTextColor
        val fromGlow = Color.alpha(tv.shadowColor)
        val a = ValueAnimator.ofFloat(0f, 1f)
        a.duration = 400
        a.addUpdateListener {
            val t = it.animatedFraction
            tv.setTextColor(ArgbEvaluator().evaluate(t, from, toColor) as Int)
            tv.setShadowLayer(glowR, 0f, 0f, Color.argb((fromGlow + (toGlow - fromGlow) * t).toInt(), 255, 255, 255))
        }
        lineAnims[tv] = a
        a.start()
    }

    private fun miniLine(text: String): TextView {
        val tv = TextView(this)
        tv.setTextSize(TypedValue.COMPLEX_UNIT_PX, m(44f))
        tv.maxLines = 1
        tv.ellipsize = android.text.TextUtils.TruncateAt.END
        tv.gravity = Gravity.CENTER_VERTICAL
        tv.pivotX = 0f
        tv.pivotY = m(33f)
        tv.text = text
        return tv
    }

    /** Isi ulang lirik mini: satu TextView 480 x 66 per baris, atau satu baris status kalau belum ada lirik. */
    private fun rebuildMini() {
        miniLines.clear()
        miniCol.removeAllViews()
        val r = lyrics
        if (r == null) {
            val tv = miniLine(lyricStatus)
            styleLine(tv, 0, false, false)
            miniCol.addView(tv, LinearLayout.LayoutParams(mi(480f), mi(66f)))
        } else {
            for ((i, l) in r.lines.withIndex()) {
                val tv = miniLine(l.text.ifEmpty { "…" })
                styleLine(tv, lineState(i), false, false)
                miniCol.addView(tv, LinearLayout.LayoutParams(mi(480f), mi(66f)))
                miniLines.add(tv)
            }
        }
        moveMini(false)
    }

    /** Geser kolom lirik mini supaya baris aktif ada di atas (0,5 dtk). */
    private fun moveMini(animate: Boolean) {
        val y = -curLine.coerceAtLeast(0) * m(66f)
        miniCol.animate().cancel()
        if (animate) {
            miniCol.animate().translationY(y).setDuration(500).setInterpolator(PathInterpolator(0.22f, 0.61f, 0.36f, 1f)).start()
        } else {
            miniCol.translationY = y
        }
    }

    private fun setLyricStatus(s: String) {
        lyricStatus = s
        ovEmpty.text = s
        if (lyrics == null) rebuildMini()
    }

    /** Aksi lirik: cari online, pilih file .lrc, tempel / ubah. */
    private fun lyricActionsSheet() {
        val d = BottomSheetDialog(this)
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.background = GradientDrawable().apply {
            setColor(0xFF1A1A1E.toInt())
            val r = Ui.dp(this@NowPlayingActivity, 24).toFloat()
            cornerRadii = floatArrayOf(r, r, r, r, 0f, 0f, 0f, 0f)
        }
        col.setPadding(Ui.dp(this, 20), Ui.dp(this, 20), Ui.dp(this, 20), Ui.dp(this, 24))
        col.addView(AU.text(this, "Lirik", 20f, Color.WHITE, true))
        fun row(icon: Int, label: String, onClick: () -> Unit) {
            val row = LinearLayout(this)
            row.orientation = LinearLayout.HORIZONTAL
            row.gravity = Gravity.CENTER_VERTICAL
            row.minimumHeight = Ui.dp(this, 56)
            val ic = ImageView(this)
            ic.setImageResource(icon)
            ic.setColorFilter(AU.MUT, PorterDuff.Mode.SRC_IN)
            row.addView(ic, LinearLayout.LayoutParams(Ui.dp(this, 22), Ui.dp(this, 22)))
            val lb = AU.text(this, label, 15f, Color.WHITE)
            lb.setPadding(Ui.dp(this, 12), 0, 0, 0)
            row.addView(lb, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
            row.setOnClickListener {
                d.dismiss()
                onClick()
            }
            col.addView(row)
        }
        row(R.drawable.ic_cloud, "Cari lirik online") { fetchOnline(true) }
        row(R.drawable.ic_file, "Pilih file lirik") { pickLyricFile.launch(arrayOf("*/*")) }
        row(R.drawable.ic_edit, "Tempel / ubah lirik") { editDialog() }
        d.setContentView(col)
        d.setOnShowListener {
            d.findViewById<View>(com.google.android.material.R.id.design_bottom_sheet)?.setBackgroundColor(Color.TRANSPARENT)
        }
        d.show()
    }

    // ---------- UI ----------

    private fun updateUi() {
        val c = controller ?: return
        tvTitle.text = c.mediaMetadata.title ?: "—"
        tvArtist.text = c.mediaMetadata.artist ?: ""
        ovTitle.text = tvTitle.text
        ovArtist.text = tvArtist.text
        btnPlay.setImageResource(if (c.isPlaying) R.drawable.ic_pause else R.drawable.ic_play)
        bunny.setPlaying(c.isPlaying)
        miku?.setPlaying(c.isPlaying)
        val id = c.currentMediaItem?.mediaId?.toLongOrNull()
        val fav = id != null && MusicStore.isFav(this, id)
        btnFav.setImageResource(if (fav) R.drawable.ic_fav else R.drawable.ic_fav_border)
        btnFav.setColorFilter(if (fav) Color.WHITE else 0xFFC4C4CA.toInt(), PorterDuff.Mode.SRC_IN)
        if (id != lastId) {
            lastId = id
            miku?.onTrackChanged()
            val uri = id?.let { ContentUris.withAppendedId(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, it) }
            setArt(null)
            Thumbs.fetch(lifecycleScope, this, uri, scaleW.toInt(), false) { if (lastId == id) setArt(it) }
            loadTrackLyrics(id)
        }
        updateProgress()
    }

    private fun updateProgress() {
        val c = controller ?: return
        if (!dragging) {
            val dur = c.duration.takeIf { it > 0 } ?: 0L
            sbSeek.max = dur.toInt()
            sbSeek.progress = c.currentPosition.coerceIn(0, dur).toInt()
            tvTimeCur.text = Library.fmt(c.currentPosition)
            tvTimeTot.text = Library.fmt(dur)
        }
        syncLyric(c.currentPosition)
    }

    // ---------- lirik ----------

    private fun applyLyrics(r: Lyrics.Result?, status: String = "Belum ada lirik") {
        lyrics = r
        curLine = -1
        lyricAdapter.notifyDataSetChanged()
        rvLyrics.scrollToPosition(0)
        ovEmpty.visibility = if (r == null) View.VISIBLE else View.GONE
        if (r == null) lyricStatus = status
        ovEmpty.text = lyricStatus
        rebuildMini()
    }

    private fun loadTrackLyrics(id: Long?) {
        track = null
        applyLyrics(null, "Memuat lirik...")
        if (id == null) {
            setLyricStatus("Lirik tidak tersedia")
            return
        }
        lifecycleScope.launch {
            val t = withContext(Dispatchers.IO) { Library.track(this@NowPlayingActivity, id) }
            if (lastId != id) return@launch
            track = t
            if (t == null) {
                setLyricStatus("Belum ada lirik")
                return@launch
            }
            val local = withContext(Dispatchers.IO) { Lyrics.loadLocal(this@NowPlayingActivity, t) }
            if (lastId != id) return@launch
            if (local != null) {
                applyLyrics(local)
            } else {
                setLyricStatus("Belum ada lirik")
                if (Prefs.lyricsOnline(this@NowPlayingActivity)) fetchOnline(false)
            }
        }
    }

    private fun fetchOnline(manual: Boolean) {
        val t = track ?: return
        if (lyrics == null) setLyricStatus("Mencari lirik online...")
        lifecycleScope.launch {
            val text = withContext(Dispatchers.IO) { Lyrics.online(t) }
            if (track?.id != t.id) return@launch
            val r = text?.let { Lyrics.parse(it, "LRCLIB") }
            if (r != null) {
                Lyrics.save(this@NowPlayingActivity, t.id, text)
                applyLyrics(r)
            } else {
                if (lyrics == null) setLyricStatus("Belum ada lirik")
                if (manual) Toast.makeText(this@NowPlayingActivity, "Lirik tidak ditemukan / tidak ada internet.", Toast.LENGTH_LONG).show()
            }
        }
    }

    private fun syncLyric(posMs: Long) {
        val r = lyrics ?: return
        if (!r.synced) return
        var idx = -1
        for (i in r.lines.indices) {
            if (r.lines[i].timeMs <= posMs + 250) idx = i else break
        }
        if (idx != curLine) {
            val old = curLine
            curLine = idx
            if (old >= 0) {
                lyricAdapter.notifyItemChanged(old, true)
                miniLines.getOrNull(old)?.let { styleLine(it, 0, false, true) }
            }
            if (idx >= 0) {
                lyricAdapter.notifyItemChanged(idx, true)
                miniLines.getOrNull(idx)?.let { styleLine(it, 1, false, true) }
            }
            moveMini(true)
            if (lyricScreenOpen) scrollLyricsTo(idx, true)
        }
    }

    private fun editDialog() {
        val t = track ?: return
        val et = EditText(this)
        et.setText(lyrics?.raw ?: "")
        et.hint = "Tempel lirik di sini (boleh format .lrc dengan waktu [mm:ss.xx])"
        et.minLines = 6
        et.gravity = android.view.Gravity.TOP
        AlertDialog.Builder(this)
            .setTitle("Lirik: ${t.title}")
            .setView(et)
            .setPositiveButton("Simpan") { _, _ ->
                val s = et.text.toString()
                val r = Lyrics.parse(s, "Tersimpan")
                if (r == null) {
                    Lyrics.clear(this, t.id)
                    applyLyrics(null)
                } else {
                    Lyrics.save(this, t.id, s)
                    applyLyrics(r)
                }
            }
            .setNeutralButton("Hapus") { _, _ ->
                Lyrics.clear(this, t.id)
                loadTrackLyrics(t.id)
            }
            .setNegativeButton("Batal", null)
            .show()
    }

    // ---------- dialog ----------

    private var sleepPick = -1

    private fun darkSheet(title: String, sub: String? = null): Pair<BottomSheetDialog, LinearLayout> {
        val d = BottomSheetDialog(this)
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.background = GradientDrawable().apply {
            setColor(0xFF1A1A1E.toInt())
            val r = Ui.dp(this@NowPlayingActivity, 24).toFloat()
            cornerRadii = floatArrayOf(r, r, r, r, 0f, 0f, 0f, 0f)
        }
        col.setPadding(Ui.dp(this, 20), Ui.dp(this, 20), Ui.dp(this, 20), Ui.dp(this, 24))
        col.addView(AU.text(this, title, 20f, Color.WHITE, true))
        if (sub != null) {
            val t = AU.text(this, sub, 13f, AU.MUT)
            t.setPadding(0, Ui.dp(this, 6), 0, 0)
            col.addView(t)
        }
        d.setContentView(col)
        d.setOnShowListener {
            d.findViewById<View>(com.google.android.material.R.id.design_bottom_sheet)?.setBackgroundColor(Color.TRANSPARENT)
        }
        return Pair(d, col)
    }

    private fun addChips(col: LinearLayout, labels: List<String>, selected: Int, onPick: (Int) -> Unit) {
        val g = com.google.android.material.chip.ChipGroup(this)
        g.chipSpacingHorizontal = Ui.dp(this, 8)
        g.chipSpacingVertical = Ui.dp(this, 8)
        for ((i, l) in labels.withIndex()) {
            val c = AU.chip(this, l, i == selected)
            c.setOnClickListener { onPick(i) }
            g.addView(c)
        }
        val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        lp.topMargin = Ui.dp(this, 14)
        col.addView(g, lp)
    }

    private fun speedDialog() {
        val c = controller ?: return
        val labels = speeds.map { if (it == it.toInt().toFloat()) "${it.toInt()}×" else "$it×" }
        val cur = speeds.indexOfFirst { it == c.playbackParameters.speed }
        val (d, col) = darkSheet("Kecepatan putar")
        addChips(col, labels, cur) { i ->
            c.setPlaybackSpeed(speeds[i])
            Toast.makeText(this, "Kecepatan: ${labels[i]}", Toast.LENGTH_SHORT).show()
            d.dismiss()
        }
        d.show()
    }

    private fun sleepDialog() {
        val labels = listOf("Mati", "15 menit", "30 menit", "45 menit", "60 menit")
        val mins = intArrayOf(0, 15, 30, 45, 60)
        val left = (PlayerService.instance?.sleepEndAt ?: 0L) - SystemClock.elapsedRealtime()
        val sel = if (left <= 0) 0 else sleepPick
        val (d, col) = darkSheet("Timer tidur", "Musik berhenti otomatis setelah waktu dipilih.")
        addChips(col, labels, sel) { i ->
            sleepPick = i
            PlayerService.instance?.setSleepTimer(mins[i])
            Toast.makeText(
                this, if (mins[i] == 0) "Timer tidur: Mati" else "Timer tidur: ${labels[i]}", Toast.LENGTH_SHORT
            ).show()
            d.dismiss()
        }
        d.show()
    }

    private fun queueDialog() {
        val c = controller ?: return
        val (d, col) = darkSheet("Antrean")
        val rowH = Ui.dp(this, 57)
        val cur = c.currentMediaItemIndex
        val list = LinearLayout(this)
        list.orientation = LinearLayout.VERTICAL
        for (i in 0 until c.mediaItemCount) {
            val name = (c.getMediaItemAt(i).mediaMetadata.title ?: "?").toString()
            val on = i == cur
            val row = LinearLayout(this)
            row.orientation = LinearLayout.HORIZONTAL
            row.gravity = Gravity.CENTER_VERTICAL
            val tv = AU.text(this, if (on) "▶ $name" else name, 15f, if (on) Color.WHITE else AU.SOFT, on)
            tv.maxLines = 1
            tv.ellipsize = android.text.TextUtils.TruncateAt.END
            row.addView(tv, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
            row.setOnClickListener {
                c.seekTo(i, 0L)
                c.play()
                d.dismiss()
            }
            list.addView(row, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, rowH - 1))
            val line = View(this)
            line.setBackgroundColor(0xFF1F1F23.toInt())
            list.addView(line, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 1))
        }
        val sv = ScrollView(this)
        sv.addView(list)
        val h = minOf(maxOf(c.mediaItemCount, 1) * rowH, (npRoot.height * 0.5f).toInt())
        val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, h)
        lp.topMargin = Ui.dp(this, 8)
        col.addView(sv, lp)
        sv.post { sv.scrollTo(0, maxOf(0, cur * rowH - rowH)) }
        d.show()
    }

}
