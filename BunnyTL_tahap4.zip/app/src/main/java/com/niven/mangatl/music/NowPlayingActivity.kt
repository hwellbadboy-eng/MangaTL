package com.niven.mangatl

import android.animation.ValueAnimator
import android.content.ComponentName
import android.content.ContentUris
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.ColorMatrix
import android.graphics.ColorMatrixColorFilter
import android.graphics.LinearGradient
import android.graphics.PorterDuff
import android.graphics.RenderEffect
import android.graphics.Shader
import android.graphics.drawable.PaintDrawable
import android.graphics.drawable.ShapeDrawable
import android.graphics.drawable.shapes.RectShape
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.ViewOutlineProvider
import android.widget.FrameLayout
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.view.WindowCompat
import androidx.core.widget.TextViewCompat
import androidx.lifecycle.lifecycleScope
import androidx.media3.common.Player
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import androidx.recyclerview.widget.RecyclerView
import com.google.common.util.concurrent.ListenableFuture

/**
 * "Sedang diputar" sesuai desain Pemutar Musik + Audio Engine: cover penuh, badge Hi-Res,
 * seek, kontrol, lima tab efek (Bass, 3D, Vokal, Reverb, Efek) dengan popup parameter cepat.
 * Acak, ulang, suka, lirik, timer tidur, kecepatan, dan antrean ada di menu "Lainnya".
 */
class NowPlayingActivity : AppCompatActivity() {

    internal lateinit var npRoot: FrameLayout
    private lateinit var ivArt: ImageView
    private lateinit var tvTitle: TextView
    private lateinit var tvArtist: TextView
    private lateinit var tvTimeCur: TextView
    private lateinit var tvTimeTot: TextView
    internal lateinit var tvHiBadge: TextView
    internal lateinit var tvHiState: TextView
    private lateinit var sbSeek: SeekBar
    private lateinit var btnPlay: ImageButton
    private lateinit var bunny: BunnyWebView
    private lateinit var btnFav: ImageButton
    internal lateinit var tabs: LinearLayout
    private lateinit var visHost: FrameLayout
    internal lateinit var popLayer: FrameLayout
    internal lateinit var topBox: View
    internal lateinit var bottomBox: View
    private var vis: VisualizerView? = null
    private var miku: MikuAvatar? = null

    // geometri mockup Usulan-B3 (lebar artboard 1159 px): semua ukuran diskalakan ke lebar layar lewat m()
    internal var scaleW = 1f
    internal fun m(px: Float): Float = px * scaleW / 1159f
    internal fun mi(px: Float): Int = m(px).toInt()

    internal lateinit var ivBlur: ImageView
    private lateinit var ivArtMirror: ImageView

    // lirik mini (di atas baris Hi-Res) dan layar lirik penuh
    internal lateinit var miniWin: FrameLayout
    internal lateinit var miniCol: LinearLayout
    internal val miniLines = ArrayList<TextView>()
    internal lateinit var lyricOverlay: FrameLayout
    internal lateinit var ovBlur: ImageView
    internal lateinit var ovThumb: ImageView
    internal lateinit var ovTitle: TextView
    internal lateinit var ovArtist: TextView
    internal lateinit var ovEmpty: TextView
    internal lateinit var rvLyrics: RecyclerView
    internal var lyricScreenOpen = false
    internal var lyricStatus = "Memuat lirik..."
    internal val lineAnims = java.util.WeakHashMap<TextView, ValueAnimator>()
    internal val fadeAnims = java.util.WeakHashMap<TextView, android.animation.ObjectAnimator>()

    private var future: ListenableFuture<MediaController>? = null
    internal var controller: MediaController? = null
    private val handler = Handler(Looper.getMainLooper())
    private var dragging = false
    internal var lastId: Long? = null
    private var lastIdx = -1
    internal var track: Library.Track? = null
    internal var lyrics: Lyrics.Result? = null
    internal var curLine = -1
    internal val speeds = floatArrayOf(0.75f, 1f, 1.25f, 1.5f, 2f)

    internal val tabList = ArrayList<Tab>()
    internal var popFid: String? = null
    internal val popRows = ArrayList<ParamRow>()

    private val tick = object : Runnable {
        override fun run() {
            updateProgress()
            for (r in popRows) r.tick()
            handler.postDelayed(this, 400)
        }
    }

    internal val pickLyricFile = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        val t = track
        if (uri != null && t != null) {
            try {
                val text = contentResolver.openInputStream(uri)?.use { it.readBytes().toString(Charsets.UTF_8) } ?: ""
                if (Lyrics.parse(text, "") == null) {
                    Toast.makeText(this, "File kosong.", Toast.LENGTH_SHORT).show()
                } else {
                    Lyrics.save(this, t.id, text)
                    applyLyrics(Lyrics.parse(text, "Tersimpan"))
                }
            } catch (e: Exception) {
                Toast.makeText(this, "Gagal membaca file.", Toast.LENGTH_SHORT).show()
            }
        }
    }

    // ---- adapter layar lirik: baris 200 x 1159, teks 66 bold maks 2 baris, aktif putih membesar ----

    internal val lyricAdapter = object : RecyclerView.Adapter<LineHolder>() {
        override fun getItemCount() = lyrics?.lines?.size ?: 0

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): LineHolder {
            val row = FrameLayout(parent.context)
            row.layoutParams = RecyclerView.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, mi(200f))
            val tv = TextView(parent.context)
            tv.setTextSize(TypedValue.COMPLEX_UNIT_PX, m(66f))
            TextViewCompat.setLineHeight(tv, mi(84f))
            tv.maxLines = 2
            tv.ellipsize = android.text.TextUtils.TruncateAt.END
            tv.gravity = Gravity.CENTER_VERTICAL
            tv.pivotX = 0f
            tv.pivotY = m(100f)
            row.addView(tv, FrameLayout.LayoutParams(mi(900f), mi(200f)).apply { leftMargin = mi(62f) })
            return LineHolder(row, tv)
        }

        override fun onBindViewHolder(h: LineHolder, pos: Int) = bindLine(h, pos, false)

        override fun onBindViewHolder(h: LineHolder, pos: Int, payloads: MutableList<Any>) = bindLine(h, pos, payloads.isNotEmpty())
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        AudioEngine.init(this)
        OutputCaps.init(this)
        // cover penuh sampai atas (di belakang status bar) dan bawah
        WindowCompat.setDecorFitsSystemWindows(window, false)
        window.statusBarColor = Color.TRANSPARENT
        window.navigationBarColor = Color.TRANSPARENT
        if (android.os.Build.VERSION.SDK_INT >= 29) window.isNavigationBarContrastEnforced = false
        setContentView(R.layout.activity_nowplaying)
        npRoot = findViewById(R.id.npRoot)
        ivArt = findViewById(R.id.ivArt)
        tvTitle = findViewById(R.id.tvTitle)
        tvArtist = findViewById(R.id.tvArtist)
        tvTimeCur = findViewById(R.id.tvTimeCur)
        tvTimeTot = findViewById(R.id.tvTimeTot)
        tvHiBadge = findViewById(R.id.tvHiBadge)
        tvHiState = findViewById(R.id.tvHiState)
        sbSeek = findViewById(R.id.sbSeek)
        btnPlay = findViewById(R.id.btnPlay)
        bunny = findViewById(R.id.bunnyWeb)
        bunny.onPlayPause = { controller?.let { if (it.isPlaying) it.pause() else it.play() } }
        bunny.onPrev = { controller?.seekToPreviousMediaItem() }
        bunny.onNext = { controller?.seekToNextMediaItem() }
        bunny.setup()
        btnFav = findViewById(R.id.btnFav)
        tabs = findViewById(R.id.tabs)
        visHost = findViewById(R.id.visHost)
        popLayer = findViewById(R.id.popLayer)
        topBox = findViewById(R.id.topBox)
        bottomBox = findViewById(R.id.bottomBox)

        npRoot.setOnApplyWindowInsetsListener { v, ins ->
            // systemWindowInsetBottom (API lama) ikut menghitung keyboard/IME dan inset sementara, bikin blok bawah naik.
            // Pakai bar sistem saja (tinggi bar navigasi), tanpa IME.
            val c = androidx.core.view.WindowInsetsCompat.toWindowInsetsCompat(ins, v)
            val bars = c.getInsets(androidx.core.view.WindowInsetsCompat.Type.systemBars())
            android.util.Log.d(
                "NowPlayingInset",
                "legacyBottom=${ins.systemWindowInsetBottom} barsBottom=${bars.bottom} " +
                    "imeBottom=${c.getInsets(androidx.core.view.WindowInsetsCompat.Type.ime()).bottom}"
            )
            bottomBox.setPadding(bottomBox.paddingLeft, 0, bottomBox.paddingRight, bars.bottom + Ui.dp(this, 8))
            ins
        }

        scaleW = resources.displayMetrics.widthPixels.toFloat()

        // judul + artis: kotak di y=150, judul 44 bold, artis 36 #D6D6D6 (jarak 8), bayangan teks 0 2 12
        (topBox.layoutParams as ViewGroup.MarginLayoutParams).topMargin = mi(150f)
        topBox.setPadding(mi(62f), 0, mi(62f), 0)
        tvTitle.setTextSize(TypedValue.COMPLEX_UNIT_PX, m(44f))
        tvArtist.setTextSize(TypedValue.COMPLEX_UNIT_PX, m(36f))
        (tvArtist.layoutParams as ViewGroup.MarginLayoutParams).topMargin = mi(8f)
        for (t in arrayOf(tvTitle, tvArtist)) t.setShadowLayer(m(12f), 0f, m(2f), 0xB3000000.toInt())

        // latar blur: kotak lebar x 1900, cover 2508 px digeser (-675, -297), blur 100, redup 0,72, saturasi 1,3
        findViewById<View>(R.id.bgBox).apply {
            layoutParams = FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, mi(1900f))
            // cover blur 2508 px sengaja lebih besar dari kotak (setara overflow:hidden di mockup); potong keras di batas kotak
            (this as ViewGroup).clipChildren = true
            clipToOutline = true
            outlineProvider = ViewOutlineProvider.BOUNDS
        }
        ivBlur = findViewById(R.id.ivBlur)
        ivBlur.layoutParams = FrameLayout.LayoutParams(mi(2508f), mi(2508f)).apply {
            leftMargin = -mi(675f)
            topMargin = -mi(297f)
        }
        ivBlur.colorFilter = tintFilter(0.72f)

        // cover 1:1 selebar layar (tidak di-crop / di-zoom), top 190, memudar atas 0-20% dan bawah 76-100%
        // pudar bawah digeser turun 116 px (10%), panjangnya tetap 278 px. Supaya tepi bawah cover tidak kelihatan,
        // kotak cover ditambah 116 px dan bagian tambahannya diisi cerminan tepi bawah cover (sambungan piksel mulus).
        findViewById<FadeMask>(R.id.coverBox).apply {
            layoutParams = FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, scaleW.toInt() + mi(116f)).apply { topMargin = mi(190f) }
            setStops(floatArrayOf(0f, 231.8f / 1275f, 997f / 1275f, 1f), intArrayOf(0, 255, 255, 0))
            ivArt.layoutParams = FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, scaleW.toInt())
            ivArtMirror = ImageView(this@NowPlayingActivity).apply {
                scaleType = ImageView.ScaleType.CENTER_CROP
                scaleY = -1f
                importantForAccessibility = View.IMPORTANT_FOR_ACCESSIBILITY_NO
            }
            addView(ivArtMirror, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, scaleW.toInt()).apply { topMargin = scaleW.toInt() })
        }
        // placeholder cover (gradasi radial seperti desain) kalau lagu tidak punya gambar
        ivArt.background = GradientDrawable().apply {
            gradientType = GradientDrawable.RADIAL_GRADIENT
            gradientRadius = Ui.dp(this@NowPlayingActivity, 460).toFloat()
            setGradientCenter(0.5f, 0.3f)
            colors = intArrayOf(0xFFE2E2E8.toInt(), 0xFF8A8A92.toInt(), 0xFF0B0B0D.toInt())
        }

        // gradasi hitam di bawah latar blur: transparan sampai 25%, hitam penuh mulai 68%
        findViewById<View>(R.id.scrimBottom).apply {
            // tinggi penuh layar: gradasi dihitung dari 1900 px pertama, sisanya (CLAMP) hitam penuh, jadi tidak ada pita di bawah seekbar
            layoutParams = FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
            val gradH = mi(1900f).toFloat()
            background = PaintDrawable().apply {
                shape = RectShape()
                shaderFactory = object : ShapeDrawable.ShaderFactory() {
                    override fun resize(width: Int, height: Int): Shader = LinearGradient(
                        0f, 0f, 0f, gradH,
                        intArrayOf(0x00000000, 0x00000000, 0xFF000000.toInt(), 0xFF000000.toInt()),
                        floatArrayOf(0f, 0.311f, 0.741f, 1f), Shader.TileMode.CLAMP
                    )
                }
            }
        }

        buildLyricViews()
        buildTabs()

        findViewById<View>(R.id.hiresBtn).setOnClickListener { togglePop(AudioEngine.HIRES, it.x + it.width / 2f) }
        btnPlay.setOnClickListener { controller?.let { if (it.isPlaying) it.pause() else it.play() } }
        findViewById<View>(R.id.btnPrev).setOnClickListener { controller?.seekToPreviousMediaItem() }
        findViewById<View>(R.id.btnNext).setOnClickListener { controller?.seekToNextMediaItem() }
        btnFav.setOnClickListener { toggleFav() }
        findViewById<View>(R.id.btnMore).setOnClickListener { showMore() }
        popLayer.setOnClickListener { hidePop() }

        sbSeek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar?, p: Int, fromUser: Boolean) {
                if (fromUser) tvTimeCur.text = Library.fmt(p.toLong())
            }

            override fun onStartTrackingTouch(sb: SeekBar?) {
                dragging = true
            }

            override fun onStopTrackingTouch(sb: SeekBar?) {
                dragging = false
                controller?.seekTo((sb?.progress ?: 0).toLong())
            }
        })

        // avatar Miku badan penuh di kotak kanan-bawah, di BAWAH ikon / visualizer / seekbar (disisipkan sebelum bottomBox)
        miku = MikuAvatar(this, npRoot, btnFav, findViewById(R.id.bottomBox)).also { it.attach() }

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                when {
                    popLayer.visibility == View.VISIBLE -> hidePop()
                    lyricScreenOpen -> setLyricScreen(false)
                    else -> finish()
                }
            }
        })
    }

    override fun onStart() {
        super.onStart()
        val token = SessionToken(this, ComponentName(this, PlayerService::class.java))
        val f = MediaController.Builder(this, token).buildAsync()
        future = f
        f.addListener({
            try {
                val c = f.get()
                controller = c
                lastIdx = c.currentMediaItemIndex
                c.addListener(object : Player.Listener {
                    override fun onMediaItemTransition(mediaItem: androidx.media3.common.MediaItem?, reason: Int) {
                        val i = c.currentMediaItemIndex
                        if (lastIdx >= 0 && i != lastIdx) {
                            val wrapFwd = i == 0 && lastIdx == c.mediaItemCount - 1
                            bunny.skip(if (i > lastIdx || wrapFwd) 1 else -1)
                        }
                        lastIdx = i
                    }
                    override fun onEvents(player: Player, events: Player.Events) = updateUi()
                })
                updateUi()
                handler.post(tick)
            } catch (e: Exception) {
                Toast.makeText(this, "Pemutar gagal tersambung", Toast.LENGTH_LONG).show()
            }
        }, ContextCompat.getMainExecutor(this))
    }

    override fun onResume() {
        super.onResume()
        bunny.onResume()
        miku?.onResume()
        refreshAll()
    }

    override fun onPause() {
        bunny.onPause()
        miku?.onPause()
        super.onPause()
    }

    override fun onDestroy() {
        bunny.destroy()
        miku?.onDestroy()
        miku = null
        super.onDestroy()
    }

    override fun onStop() {
        handler.removeCallbacks(tick)
        future?.let { MediaController.releaseFuture(it) }
        future = null
        controller = null
        super.onStop()
    }

    // ---------- tab efek + popup ----------

    internal fun refreshAll() {
        refreshTabs()
        updateHiState()
        val showVis = AudioEngine.isOn(AudioEngine.VIS)
        if (showVis && vis == null) {
            val v = VisualizerView(this)
            vis = v
            // area visHost cuma menyediakan tempat; ukuran & posisi visualizer diatur dari pengaturan
            visHost.clipChildren = false
            (bottomBox as ViewGroup).clipChildren = false
            npRoot.clipChildren = false
            visHost.addView(v, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, Ui.dp(this, 64), Gravity.BOTTOM))
            // JANGAN bringToFront(): di LinearLayout vertikal itu memindahkan visHost ke dasar daftar anak
            // (di bawah tab) dan mendorong semua kontrol naik. Cukup dinaikkan Z-nya supaya digambar paling atas.
            visHost.translationZ = Ui.dp(this, 4).toFloat()
            // tanpa ini semua yang digambar di luar padding bottomBox (geser X/Y jauh) terpotong dan "hilang"
            (bottomBox as ViewGroup).clipToPadding = false
        }
        visHost.visibility = if (showVis) View.VISIBLE else View.GONE
        for (r in popRows) r.refresh()
        val pf = popFid
        popBody?.alpha = if (pf != null && !AudioEngine.featureOn(pf)) 0.45f else 1f
    }

    internal var popClosing = false
    internal var popBody: View? = null

    // ---------- menu Lainnya ----------

    internal fun isFavNow(): Boolean {
        val id = controller?.currentMediaItem?.mediaId?.toLongOrNull() ?: return false
        return MusicStore.isFav(this, id)
    }

    internal fun tintFilter(brightness: Float): ColorMatrixColorFilter {
        val b = brightness
        val cm = ColorMatrix().apply { setSaturation(1.3f) }
        cm.postConcat(ColorMatrix(floatArrayOf(b, 0f, 0f, 0f, 0f, 0f, b, 0f, 0f, 0f, 0f, 0f, b, 0f, 0f, 0f, 0f, 0f, 1f, 0f)))
        return ColorMatrixColorFilter(cm)
    }

    /** Pasang cover ke semua tempat: cover 1:1, tamnel layar lirik, dan dua latar blur. */
    private fun setArt(bmp: Bitmap?) {
        ivArt.setImageBitmap(bmp)
        ivArtMirror.setImageBitmap(bmp)
        ovThumb.setImageBitmap(bmp)
        // Android 12+ memakai RenderEffect (dipasang di buildLyricViews); di bawahnya bitmap kecil yang diperbesar sudah buram
        val soft = if (bmp != null && Build.VERSION.SDK_INT < 31) Bitmap.createScaledBitmap(bmp, 48, 48, true) else bmp
        ivBlur.setImageBitmap(soft)
        ovBlur.setImageBitmap(soft)
    }

    /** 0 = baris biasa (redup), 1 = baris aktif, 2 = lirik tanpa waktu (semua netral). */
    internal fun lineState(pos: Int): Int = if (lyrics?.synced != true) 2 else if (pos == curLine) 1 else 0

    // ---------- UI ----------

    internal fun updateUi() {
        val c = controller ?: return
        tvTitle.text = c.mediaMetadata.title ?: "—"
        tvArtist.text = c.mediaMetadata.artist ?: ""
        ovTitle.text = tvTitle.text
        ovArtist.text = tvArtist.text
        btnPlay.setImageResource(if (c.isPlaying) R.drawable.ic_pause else R.drawable.ic_play)
        bunny.setPlaying(c.isPlaying)
        miku?.setPlaying(c.isPlaying)
        val id = c.currentMediaItem?.mediaId?.toLongOrNull()
        val fav = id != null && MusicStore.isFav(this, id)
        btnFav.setImageResource(if (fav) R.drawable.ic_fav else R.drawable.ic_fav_border)
        btnFav.setColorFilter(if (fav) Color.WHITE else 0xFFC4C4CA.toInt(), PorterDuff.Mode.SRC_IN)
        if (id != lastId) {
            lastId = id
            miku?.onTrackChanged()
            val uri = id?.let { ContentUris.withAppendedId(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, it) }
            setArt(null)
            Thumbs.fetch(lifecycleScope, this, uri, scaleW.toInt(), false) { if (lastId == id) setArt(it) }
            loadTrackLyrics(id)
        }
        updateProgress()
    }

    private fun updateProgress() {
        val c = controller ?: return
        if (!dragging) {
            val dur = c.duration.takeIf { it > 0 } ?: 0L
            sbSeek.max = dur.toInt()
            sbSeek.progress = c.currentPosition.coerceIn(0, dur).toInt()
            tvTimeCur.text = Library.fmt(c.currentPosition)
            tvTimeTot.text = Library.fmt(dur)
        }
        syncLyric(c.currentPosition)
    }

    // ---------- lirik ----------

    // ---------- dialog ----------

    internal var sleepPick = -1

}
