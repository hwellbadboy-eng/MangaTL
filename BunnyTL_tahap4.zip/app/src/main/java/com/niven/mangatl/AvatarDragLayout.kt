package com.niven.mangatl

import android.content.Context
import android.os.SystemClock
import android.util.AttributeSet
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.ViewConfiguration
import android.widget.FrameLayout
import kotlin.math.hypot

/**
 * Root layar chat. Mengintip semua sentuhan lebih dulu, tanpa mengganggu chat:
 *  - Avatar di depan chat: sentuh badan avatar lalu geser = langsung menggeser avatar (tanpa tekan lama).
 *    Sentuhan yang mulai di bagian transparan tetap menjadi scroll chat biasa.
 *  - Dua jari (cubit) = zoom avatar, di mode depan maupun belakang chat.
 *  - Ketukan singkat di bagian tubuh avatar = avatar bereaksi (dada, paha, dll.).
 */
class AvatarDragLayout @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : FrameLayout(context, attrs) {

    /** Avatar yang bisa disentuh. null = fitur mati. */
    var target: KarinView? = null

    /** true = badan avatar boleh digeser dengan jari (hanya saat avatar di depan chat). */
    var dragEnabled = false

    /** Menentukan apakah titik layar (rawX, rawY) boleh memicu reaksi sentuh (mis. bukan di atas bubble/tombol). */
    var pokeFilter: ((Float, Float) -> Boolean)? = null

    /** Dipanggil saat geser / zoom selesai: posisi (x, y) dan skala baru, untuk disimpan. */
    var onGestureEnd: ((Float, Float, Float) -> Unit)? = null

    private val slop = ViewConfiguration.get(context).scaledTouchSlop

    private var downX = 0f
    private var downY = 0f
    private var lastX = 0f
    private var lastY = 0f
    private var downTime = 0L

    private var probeDone = false
    private var onBody = false
    private var armed = false          // sentuhan masih mungkin menjadi geser
    private var wantDrag = false       // jari sudah bergerak, menunggu hasil probe
    private var dragging = false
    private var pinching = false
    private var gestureUsed = false    // ada geser/zoom yang perlu disimpan
    private var swallow = false        // telan sisa sentuhan sampai jari terakhir diangkat
    private var lastDist = 0f
    private val loc = IntArray(2)

    private fun cancelChildren(x: Float, y: Float) {
        val c = MotionEvent.obtain(downTime, SystemClock.uptimeMillis(), MotionEvent.ACTION_CANCEL, x, y, 0)
        super.dispatchTouchEvent(c)
        c.recycle()
    }

    private fun startDrag(k: KarinView) {
        if (dragging) return
        dragging = true
        armed = false
        wantDrag = false
        gestureUsed = true
        k.setDragging(true)
        performHapticFeedback(HapticFeedbackConstants.CLOCK_TICK)
        cancelChildren(lastX, lastY)
    }

    private fun finish(k: KarinView) {
        if (dragging) k.setDragging(false)
        if (gestureUsed) onGestureEnd?.invoke(k.dragX(), k.dragY(), k.userScale())
        dragging = false
        pinching = false
        gestureUsed = false
        armed = false
        wantDrag = false
    }

    override fun dispatchTouchEvent(ev: MotionEvent): Boolean {
        val k = target
        if (k == null || !k.isShown) {
            dragging = false
            pinching = false
            armed = false
            return super.dispatchTouchEvent(ev)
        }
        when (ev.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                dragging = false
                pinching = false
                swallow = false
                gestureUsed = false
                wantDrag = false
                probeDone = false
                onBody = false
                downX = ev.x; downY = ev.y; lastX = ev.x; lastY = ev.y
                downTime = ev.downTime
                armed = dragEnabled
                if (dragEnabled) {
                    k.getLocationOnScreen(loc)
                    // Tanya GL: apakah piksel di bawah jari ini bagian badan avatar (bukan bagian transparan)?
                    k.probeHit(ev.rawX - loc[0], ev.rawY - loc[1]) { hit ->
                        probeDone = true
                        onBody = hit
                        if (armed && wantDrag) {
                            if (hit) startDrag(k) else armed = false
                        }
                    }
                }
            }

            MotionEvent.ACTION_POINTER_DOWN -> {
                if (ev.pointerCount == 2 && !pinching) {
                    // Dua jari = zoom. Batalkan sentuhan yang sedang berjalan di chat / geser.
                    if (dragging) k.setDragging(false)
                    dragging = false
                    armed = false
                    wantDrag = false
                    pinching = true
                    gestureUsed = true
                    swallow = true
                    lastDist = hypot(ev.getX(0) - ev.getX(1), ev.getY(0) - ev.getY(1))
                    cancelChildren(ev.getX(0), ev.getY(0))
                    return true
                }
            }

            MotionEvent.ACTION_MOVE -> {
                if (pinching && ev.pointerCount >= 2) {
                    val dist = hypot(ev.getX(0) - ev.getX(1), ev.getY(0) - ev.getY(1))
                    if (lastDist > 8f && dist > 8f) {
                        k.getLocationOnScreen(loc)
                        val fx = (ev.getRawX(0) + ev.getRawX(1)) / 2f - loc[0]
                        val fy = (ev.getRawY(0) + ev.getRawY(1)) / 2f - loc[1]
                        k.pinchBy(dist / lastDist, fx, fy)
                    }
                    lastDist = dist
                    return true
                }
                if (swallow) return true
                if (dragging) {
                    k.dragBy(ev.x - lastX, ev.y - lastY)
                    lastX = ev.x; lastY = ev.y
                    return true
                }
                lastX = ev.x; lastY = ev.y
                if (armed && hypot(ev.x - downX, ev.y - downY) > slop) {
                    if (probeDone) {
                        if (onBody) startDrag(k) else armed = false
                    } else {
                        wantDrag = true     // tunggu jawaban probe (sekitar satu frame)
                    }
                    if (dragging) return true
                }
            }

            MotionEvent.ACTION_POINTER_UP -> {
                if (pinching) {
                    // Jari kedua diangkat: akhiri zoom, telan sisa sentuhan supaya avatar tidak melompat.
                    pinching = false
                    return true
                }
            }

            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                val consumed = dragging || pinching || swallow
                val tap = ev.actionMasked == MotionEvent.ACTION_UP && !consumed && !gestureUsed &&
                    ev.eventTime - ev.downTime < 350L && hypot(ev.x - downX, ev.y - downY) <= slop
                finish(k)
                swallow = false
                if (consumed) return true
                // Ketukan singkat di bagian tubuh (dada, paha, dll.) = avatar bereaksi. Chat tetap menerima ketukannya.
                if (tap && (!dragEnabled || onBody) && (pokeFilter?.invoke(ev.rawX, ev.rawY) ?: true)) {
                    k.getLocationOnScreen(loc)
                    k.pokeAt(ev.rawX - loc[0], ev.rawY - loc[1])
                }
            }
        }
        if (swallow) return true
        return super.dispatchTouchEvent(ev)
    }
}
