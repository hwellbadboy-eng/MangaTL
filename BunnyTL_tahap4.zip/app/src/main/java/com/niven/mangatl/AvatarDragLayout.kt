package com.niven.mangatl

import android.content.Context
import android.os.SystemClock
import android.util.AttributeSet
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.ViewConfiguration
import android.widget.FrameLayout
import kotlin.math.hypot

/**
 * Root layar chat. Mengintip semua sentuhan TANPA mengganggu chat: kalau jari menekan lama tepat di badan avatar
 * (avatar di depan chat), avatar masuk mode geser bebas dan sentuhan itu tidak lagi diteruskan ke chat.
 * Tekan singkat / scroll / ketuk biasa tetap berjalan normal ke daftar chat dan tombol.
 */
class AvatarDragLayout @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : FrameLayout(context, attrs) {

    /** Avatar yang boleh digeser (hanya saat berada di depan chat). null = fitur mati. */
    var target: KarinView? = null

    /** Dipanggil saat geseran selesai: posisi baru (satuan layar, -1..1) untuk disimpan. */
    var onDragEnd: ((Float, Float) -> Unit)? = null

    private val slop = ViewConfiguration.get(context).scaledTouchSlop
    private val longMs = ViewConfiguration.getLongPressTimeout().toLong()

    private var downX = 0f
    private var downY = 0f
    private var lastX = 0f
    private var lastY = 0f
    private var downTime = 0L
    private var pressStart = 0L
    private var armed = false
    private var dragging = false
    private val loc = IntArray(2)
    private val fire = Runnable { startDrag() }

    private fun cancelPress() {
        armed = false
        removeCallbacks(fire)
    }

    private fun startDrag() {
        if (!armed) return
        armed = false
        dragging = true
        performHapticFeedback(HapticFeedbackConstants.LONG_PRESS)
        // Batalkan sentuhan di anak-anak (daftar chat, tombol) supaya tidak ikut scroll / terklik.
        val c = MotionEvent.obtain(downTime, SystemClock.uptimeMillis(), MotionEvent.ACTION_CANCEL, lastX, lastY, 0)
        super.dispatchTouchEvent(c)
        c.recycle()
    }

    override fun dispatchTouchEvent(ev: MotionEvent): Boolean {
        val k = target
        if (k == null || !k.isShown) {
            if (dragging || armed) {
                dragging = false
                cancelPress()
            }
            return super.dispatchTouchEvent(ev)
        }
        when (ev.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                cancelPress()
                dragging = false
                downX = ev.x; downY = ev.y; lastX = ev.x; lastY = ev.y
                downTime = ev.downTime
                pressStart = SystemClock.uptimeMillis()
                armed = true
                k.getLocationOnScreen(loc)
                // Tanya GL: apakah piksel di bawah jari ini bagian badan avatar (bukan bagian transparan)?
                k.probeHit(ev.rawX - loc[0], ev.rawY - loc[1]) { hit ->
                    if (armed && hit && !dragging) {
                        val remain = (longMs - (SystemClock.uptimeMillis() - pressStart)).coerceAtLeast(0L)
                        postDelayed(fire, remain)
                    }
                }
            }
            MotionEvent.ACTION_MOVE -> {
                if (dragging) {
                    k.dragBy(ev.x - lastX, ev.y - lastY)
                    lastX = ev.x; lastY = ev.y
                    return true
                }
                lastX = ev.x; lastY = ev.y
                if (armed && hypot(ev.x - downX, ev.y - downY) > slop) cancelPress()
            }
            MotionEvent.ACTION_POINTER_DOWN -> cancelPress()
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                val was = dragging
                cancelPress()
                dragging = false
                if (was) {
                    onDragEnd?.invoke(k.dragX(), k.dragY())
                    return true
                }
            }
        }
        return super.dispatchTouchEvent(ev)
    }
}
