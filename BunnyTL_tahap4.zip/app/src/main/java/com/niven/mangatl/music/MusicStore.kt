package com.niven.mangatl

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/** Favorit, playlist, sesi putar terakhir, dan riwayat putar (musik & video), disimpan di SharedPreferences. */
object MusicStore {
    private fun p(ctx: Context) = ctx.getSharedPreferences("music", Context.MODE_PRIVATE)

    fun favs(ctx: Context): Set<Long> =
        (p(ctx).getStringSet("favs", emptySet()) ?: emptySet()).mapNotNull { it.toLongOrNull() }.toSet()

    fun isFav(ctx: Context, id: Long) = favs(ctx).contains(id)

    fun toggleFav(ctx: Context, id: Long): Boolean {
        val s = HashSet(p(ctx).getStringSet("favs", emptySet()) ?: emptySet())
        val now = if (s.contains(id.toString())) { s.remove(id.toString()); false } else { s.add(id.toString()); true }
        p(ctx).edit().putStringSet("favs", s).apply()
        return now
    }

    fun playlists(ctx: Context): LinkedHashMap<String, MutableList<Long>> {
        val out = LinkedHashMap<String, MutableList<Long>>()
        try {
            val o = JSONObject(p(ctx).getString("playlists", "{}") ?: "{}")
            val it = o.keys()
            while (it.hasNext()) {
                val name = it.next()
                val arr = o.getJSONArray(name)
                val l = ArrayList<Long>()
                for (i in 0 until arr.length()) l.add(arr.getLong(i))
                out[name] = l
            }
        } catch (e: Exception) {
        }
        return out
    }

    private fun save(ctx: Context, m: Map<String, List<Long>>) {
        val o = JSONObject()
        for ((k, v) in m) o.put(k, JSONArray(v))
        p(ctx).edit().putString("playlists", o.toString()).apply()
    }

    fun create(ctx: Context, name: String) {
        val m = playlists(ctx)
        if (!m.containsKey(name)) m[name] = ArrayList()
        save(ctx, m)
    }

    fun addTo(ctx: Context, name: String, id: Long) {
        val m = playlists(ctx)
        val l = m.getOrPut(name) { ArrayList() }
        if (!l.contains(id)) l.add(id)
        save(ctx, m)
    }

    fun removeFrom(ctx: Context, name: String, id: Long) {
        val m = playlists(ctx)
        m[name]?.remove(id)
        save(ctx, m)
    }

    fun delete(ctx: Context, name: String) {
        val m = playlists(ctx)
        m.remove(name)
        save(ctx, m)
    }

    // ------------------------------------------------------------------ sesi putar terakhir

    /** Antrean musik terakhir: id lagu, indeks yang sedang diputar, posisi (ms), mode ulang & acak. */
    class Session(val ids: List<Long>, val index: Int, val pos: Long, val repeat: Int, val shuffle: Boolean)

    fun saveSession(ctx: Context, ids: List<Long>, index: Int, pos: Long, repeat: Int, shuffle: Boolean) {
        if (ids.isEmpty()) return
        try {
            val o = JSONObject().put("ids", JSONArray(ids)).put("i", index).put("p", pos).put("r", repeat).put("s", shuffle)
            p(ctx).edit().putString("session", o.toString()).apply()
        } catch (e: Exception) {
        }
    }

    fun session(ctx: Context): Session? = try {
        val o = JSONObject(p(ctx).getString("session", null) ?: "")
        val a = o.getJSONArray("ids")
        val ids = ArrayList<Long>()
        for (i in 0 until a.length()) ids.add(a.getLong(i))
        if (ids.isEmpty()) null
        else Session(ids, o.optInt("i", 0).coerceIn(0, ids.size - 1), o.optLong("p", 0L).coerceAtLeast(0L), o.optInt("r", 0), o.optBoolean("s", false))
    } catch (e: Exception) {
        null
    }

    // ------------------------------------------------------------------ riwayat putar (terbaru di depan)

    private const val HIST_MAX = 100

    private fun readHist(ctx: Context, key: String): MutableList<String> =
        (p(ctx).getString(key, "") ?: "").split(",").filter { it.isNotBlank() }.toMutableList()

    private fun pushHist(ctx: Context, key: String, v: String) {
        val l = readHist(ctx, key)
        l.remove(v)
        l.add(0, v)
        while (l.size > HIST_MAX) l.removeAt(l.size - 1)
        p(ctx).edit().putString(key, l.joinToString(",")).apply()
    }

    /** Lagu yang diputar > beberapa detik. Terbaru di depan, tanpa duplikat. */
    fun addHistory(ctx: Context, id: Long) = pushHist(ctx, "hist_audio", id.toString())

    fun history(ctx: Context): List<Long> = readHist(ctx, "hist_audio").mapNotNull { it.toLongOrNull() }

    fun lastPlayed(ctx: Context): Long? = history(ctx).firstOrNull()

    /** Video disimpan sebagai uri (sama dengan mediaId di pemutar video); uri tidak mengandung koma. */
    fun addVideoHistory(ctx: Context, uri: String) = pushHist(ctx, "hist_video", uri)

    fun videoHistory(ctx: Context): List<String> = readHist(ctx, "hist_video")

    fun clearHistory(ctx: Context) {
        p(ctx).edit().remove("hist_audio").remove("hist_video").apply()
    }
}
