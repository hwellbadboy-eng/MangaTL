package com.niven.mangatl

import android.app.Activity
import android.view.View
import android.view.ViewGroup
import android.view.animation.DecelerateInterpolator
import android.widget.ScrollView

/** Animasi masuk layar: anak-anak langsung dari root naik pelan satu per satu. */
object Fx {
    fun enter(a: Activity) {
        val root = a.findViewById<ViewGroup>(android.R.id.content) ?: return
        var c: View? = root.getChildAt(0)
        if (c is ScrollView) c = c.getChildAt(0)
        val g = c as? ViewGroup ?: return
        val d = a.resources.displayMetrics.density
        for (i in 0 until minOf(g.childCount, 8)) {
            val v = g.getChildAt(i)
            v.alpha = 0f
            v.translationY = 14f * d
            v.animate().alpha(1f).translationY(0f)
                .setStartDelay(60L + i * 60L).setDuration(460)
                .setInterpolator(DecelerateInterpolator(2f)).start()
        }
    }
}
