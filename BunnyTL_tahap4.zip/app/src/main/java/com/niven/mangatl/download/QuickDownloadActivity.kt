package com.niven.mangatl

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.os.Build
import android.os.Bundle
import android.view.Gravity
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity

/** Dipakai bersama: ambil link pertama dari teks/Intent. */
object DlUrl {
    private val RE = Regex("""https?://[^\s<>"']+""")

    fun extract(i: Intent?): String? {
        val raw = i?.getStringExtra(Intent.EXTRA_TEXT) ?: i?.dataString ?: return null
        return RE.find(raw)?.value?.trimEnd('.', ',', ')', ']')
    }
}

/**
 * Tujuan "Bagikan -> BunnyTL": sheet transparan di atas app asal.
 * Langsung tampil pilihan kualitas tanpa membuka BunnyTL; setelah Unduh ditekan, sheet menutup
 * dan unduhan jalan di latar (progres di notifikasi).
 */
class QuickDownloadActivity : AppCompatActivity() {
    private lateinit var picker: DlPicker
    private var pending: List<DlTask>? = null

    private val notifPerm = registerForActivityResult(ActivityResultContracts.RequestPermission()) {
        pending?.let { go(it) }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val url = DlUrl.extract(intent)
        if (url == null) {
            Toast.makeText(this, "Tidak ada link yang bisa diunduh.", Toast.LENGTH_SHORT).show()
            finish()
            return
        }
        val scrim = FrameLayout(this).apply {
            setBackgroundColor(Color.parseColor("#99000000"))
            setOnClickListener { finish() }
        }
        picker = DlPicker(this) { start(it) }
        val panel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundResource(R.drawable.bg_popup)
            val p = Ui.dp(this@QuickDownloadActivity, 16)
            setPadding(p, p, p, p)
            isClickable = true // jangan tutup kalau panel disentuh
            addView(picker.root)
        }
        val m = Ui.dp(this, 8)
        scrim.addView(panel, FrameLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.BOTTOM
        ).apply { setMargins(m, 0, m, m) })
        setContentView(scrim)
        picker.load(url)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        DlUrl.extract(intent)?.let { picker.load(it) }
    }

    private fun start(tasks: List<DlTask>) {
        val needAsk = Build.VERSION.SDK_INT >= 33 && !DlPrefs.notifAsked(this) &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        if (needAsk) {
            DlPrefs.setNotifAsked(this)
            pending = tasks
            notifPerm.launch(Manifest.permission.POST_NOTIFICATIONS)
        } else {
            go(tasks)
        }
    }

    private fun go(tasks: List<DlTask>) {
        pending = null
        tasks.forEach { DlQueue.enqueue(this, it) }
        val msg = if (tasks.size == 1) "Mulai mengunduh: ${tasks[0].title}" else "${tasks.size} item masuk antrean"
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
        finish()
    }
}
