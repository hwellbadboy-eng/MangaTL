package com.niven.mangatl

import android.content.Context
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

/** Layar satu fitur: semua parameter (slider + angka), reset per parameter / fitur, simpan. */
class AudioFeatureActivity : AppCompatActivity() {

    private lateinit var fid: String
    private lateinit var body: LinearLayout
    private lateinit var warn: View
    private val rows = ArrayList<ParamRow>()
    private var bandBar: LinearLayout? = null
    private val h = Handler(Looper.getMainLooper())
    private val tick = object : Runnable {
        override fun run() {
            for (r in rows) r.tick()
            h.postDelayed(this, 400)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        AudioEngine.init(this)
        OutputCaps.init(this)
        fid = intent.getStringExtra("fid") ?: AudioEngine.features[0].id
        val f = AudioEngine.feature(fid)

        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setBackgroundColor(AU.BLACK)
        val sv = ScrollView(this)
        sv.isFillViewport = true
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(AU.dp(this, 20), AU.dp(this, 24), AU.dp(this, 20), AU.dp(this, 40))
        sv.addView(col)
        root.addView(sv, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        setContentView(root)
        // Visualizer: pratinjau mini tetap di atas (tidak ikut scroll) supaya perubahan terlihat langsung
        if (fid == AudioEngine.VIS) root.addView(buildMiniPreview(), 0)
        root.setOnApplyWindowInsetsListener { v, ins ->
            v.setPadding(0, ins.systemWindowInsetTop, 0, ins.systemWindowInsetBottom)
            ins
        }

        val hd = LinearLayout(this)
        hd.orientation = LinearLayout.HORIZONTAL
        hd.gravity = Gravity.CENTER_VERTICAL
        val back = Ui.iconBtn(this, R.drawable.ic_back, "Kembali") { finish() }
        back.background = AU.shape(0, 99f, this, AU.LN, 1)
        hd.addView(back, LinearLayout.LayoutParams(AU.dp(this, 44), AU.dp(this, 44)))
        val title = AU.text(this, f.title, 24f, AU.WHITE, true)
        title.setPadding(AU.dp(this, 12), 0, 0, 0)
        hd.addView(title, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        val sw = AU.switch(this, AudioEngine.featureOn(fid)) { v ->
            AudioEngine.setOn(fid, v)
            updateWarn()
        }
        hd.addView(sw)
        col.addView(hd)

        val sub = AU.text(this, f.desc, 13f, AU.MUT)
        sub.setPadding(0, AU.dp(this, 6), 0, AU.dp(this, 10))
        col.addView(sub)

        val w = AU.text(this, "", 13f, AU.WHITE)
        w.background = AU.shape(AU.CD, 12f, this, AU.LN, 1)
        w.setPadding(AU.dp(this, 12), AU.dp(this, 10), AU.dp(this, 12), AU.dp(this, 10))
        warn = w
        col.addView(w, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))

        if (fid == AudioEngine.EQ) {
            val hs = HorizontalScrollView(this)
            hs.isHorizontalScrollBarEnabled = false
            val bar = LinearLayout(this)
            bar.orientation = LinearLayout.HORIZONTAL
            hs.addView(bar)
            bandBar = bar
            val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            lp.topMargin = AU.dp(this, 12)
            col.addView(hs, lp)
            val t = AU.text(this, "Pilih band, lalu atur Frequency, Gain, Q, tipe, dan slope. Tiap band independen.", 12f, AU.MUT)
            t.setPadding(0, AU.dp(this, 6), 0, 0)
            col.addView(t)
        }

        body = LinearLayout(this)
        body.orientation = LinearLayout.VERTICAL
        col.addView(body, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        buildRows()
        buildBands()

        val actions = LinearLayout(this)
        actions.orientation = LinearLayout.HORIZONTAL
        val bReset = AU.chip(this, "Reset fitur", false)
        bReset.setOnClickListener {
            AudioEngine.resetFeature(fid)
            buildRows()
            buildBands()
            Toast.makeText(this, "${f.title} dikembalikan ke default", Toast.LENGTH_SHORT).show()
        }
        val bSave = AU.chip(this, "Simpan", true)
        bSave.setOnClickListener {
            Toast.makeText(
                this, if (AudioEngine.saveSlot()) "Konfigurasi disimpan" else "Gagal menyimpan", Toast.LENGTH_SHORT
            ).show()
        }
        val l1 = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        l1.rightMargin = AU.dp(this, 8)
        actions.addView(bReset, l1)
        actions.addView(bSave)
        val lpA = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        lpA.topMargin = AU.dp(this, 14)
        col.addView(actions, lpA)
        updateWarn()
    }

    /** Miniatur layar pemutar lengkap dengan elemen UI-nya; visualizer digambar paling atas dan tidak terpotong. */
    private fun buildMiniPreview(): View {
        val dm = resources.displayMetrics
        val sc = 0.22f
        val fw = (dm.widthPixels * sc).toInt()
        val fh = (dm.heightPixels * sc).toInt()
        val px = dm.density * sc
        val dim = 0xFF4A4A52.toInt()
        val bright = 0xFFB8B8C0.toInt()
        val frame = FrameLayout(this)
        frame.background = AU.shape(0xFF000000.toInt(), 10f, this, AU.LN, 1)
        val cover = View(this)
        cover.setBackgroundColor(0xFF2A2A30.toInt())
        frame.addView(cover, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, (fh * 0.62f).toInt()))

        // pasang elemen berdasarkan titik tengah (pecahan lebar/tinggi layar)
        fun put(v: View, w: Int, h: Int, xc: Float, yc: Float) {
            val lp = FrameLayout.LayoutParams(w.coerceAtLeast(2), h.coerceAtLeast(2), Gravity.TOP or Gravity.START)
            lp.leftMargin = (fw * xc - w / 2f).toInt()
            lp.topMargin = (fh * yc - h / 2f).toInt()
            frame.addView(v, lp)
        }
        fun blob(color: Int, w: Int, h: Int, xc: Float, yc: Float) {
            val v = View(this)
            v.background = AU.shape(color, 99f, this)
            put(v, w, h, xc, yc)
        }
        fun ringV(color: Int, size: Int, xc: Float, yc: Float) {
            val v = View(this)
            v.background = AU.shape(0, 99f, this, color, 1)
            put(v, size, size, xc, yc)
        }
        // judul + artis
        blob(bright, (fw * 0.55f).toInt(), (12 * px).toInt(), 0.5f, 0.073f)
        blob(dim, (fw * 0.30f).toInt(), (9 * px).toInt(), 0.5f, 0.095f)
        // badge Hi-Res + info bit/kHz
        val pill = View(this)
        pill.background = AU.shape(0xFFEDEDED.toInt(), 5f, this)
        put(pill, (fw * 0.18f).toInt(), (26 * px).toInt(), 0.144f, 0.664f)
        blob(dim, (fw * 0.23f).toInt(), (9 * px).toInt(), 0.169f, 0.694f)
        // suka + lainnya
        ringV(bright, (34 * px).toInt(), 0.79f, 0.667f)
        blob(dim, (16 * px).toInt(), (16 * px).toInt(), 0.91f, 0.667f)
        // seekbar + waktu
        blob(dim, (fw * 0.892f).toInt(), (6 * px).toInt(), 0.5f, 0.732f)
        blob(0xFFEDEDED.toInt(), (fw * 0.18f).toInt(), (6 * px).toInt(), 0.054f + 0.09f, 0.732f)
        blob(dim, (fw * 0.07f).toInt(), (9 * px).toInt(), 0.089f, 0.761f)
        blob(dim, (fw * 0.07f).toInt(), (9 * px).toInt(), 0.911f, 0.761f)
        // prev / play / next
        blob(bright, (26 * px).toInt(), (26 * px).toInt(), 0.145f, 0.844f)
        blob(bright, (26 * px).toInt(), (26 * px).toInt(), 0.855f, 0.844f)
        ringV(bright, (96 * px).toInt(), 0.5f, 0.844f)
        // tab bawah
        for (k in 0 until 5) blob(dim, (fw * 0.12f).toInt(), (9 * px).toInt(), (k + 0.5f) / 5f, 0.955f)

        // visualizer paling atas, tidak dipotong wadahnya
        val vh = FrameLayout(this)
        vh.clipChildren = false
        val vhH = (64 * px).toInt()
        val lpVh = FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, vhH, Gravity.BOTTOM)
        lpVh.leftMargin = (22 * px).toInt()
        lpVh.rightMargin = (22 * px).toInt()
        lpVh.bottomMargin = (fh * 0.363f).toInt()
        frame.addView(vh, lpVh)
        val vv = VisualizerView(this)
        vv.uiScale = sc
        vh.addView(vv, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, vhH, Gravity.BOTTOM))

        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.gravity = Gravity.CENTER_HORIZONTAL
        box.setPadding(0, AU.dp(this, 8), 0, AU.dp(this, 8))
        box.addView(frame, LinearLayout.LayoutParams(fw, fh))
        val cap = AU.text(this, "Pratinjau layar pemutar (diperkecil)", 11f, AU.MUT)
        cap.gravity = Gravity.CENTER
        cap.setPadding(0, AU.dp(this, 4), 0, 0)
        box.addView(cap, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        return box
    }

    private fun updateWarn() {
        val f = AudioEngine.feature(fid)
        body.alpha = if (AudioEngine.featureOn(fid)) 1f else 0.45f
        when {
            !AudioEngine.master -> {
                warn.visibility = View.VISIBLE
                (warn as android.widget.TextView).text = "Audio Engine sedang mati. Nyalakan di layar Audio Engine agar efek terdengar."
            }
            !AudioEngine.featureOn(fid) -> {
                warn.visibility = View.VISIBLE
                (warn as android.widget.TextView).text = "Fitur nonaktif: parameter tersimpan tapi belum memengaruhi suara. Nyalakan saklar di atas."
            }
            else -> warn.visibility = View.GONE
        }
    }

    private fun buildRows() {
        body.removeAllViews()
        rows.clear()
        val f = AudioEngine.feature(fid)
        for (i in f.params.indices) {
            val r = ParamRow(this, fid, i, false) { onParamChanged() }
            rows.add(r)
            body.addView(r.view)
            val line = View(this)
            line.setBackgroundColor(0xFF1F1F23.toInt())
            body.addView(line, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 1))
        }
    }

    private fun onParamChanged() {
        // jumlah band, label frekuensi band, atau baris yang bergantung pada nilai lain bisa berubah
        if (fid == AudioEngine.EQ) buildBands() else for (r in rows) r.refresh()
    }

    private fun buildBands() {
        val bar = bandBar ?: return
        bar.removeAllViews()
        val n = AudioEngine.eqCount()
        for (i in 0 until n) {
            val f = AudioEngine.eqBands[i * 5]
            val label = if (f >= 1000f) "${AU.fmt(f / 1000f)}k" else AU.fmt(f)
            val c = AU.chip(this, label, i == AudioEngine.eqSel, true, true)
            val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            lp.rightMargin = AU.dp(this, 6)
            c.setOnClickListener {
                AudioEngine.selectEqBand(i)
                buildBands()
                for (r in rows) r.refresh()
            }
            bar.addView(c, lp)
        }
        for (r in rows) r.refresh()
    }

    override fun onResume() {
        super.onResume()
        updateWarn()
        for (r in rows) r.refresh()
        h.post(tick)
    }

    override fun onPause() {
        h.removeCallbacks(tick)
        super.onPause()
    }
}
