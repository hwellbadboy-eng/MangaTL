package com.niven.mangatl

import android.content.Context
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

/** Layar satu fitur: semua parameter (slider + angka), reset per parameter / fitur, simpan. */
class AudioFeatureActivity : AppCompatActivity() {

    private lateinit var fid: String
    private lateinit var body: LinearLayout
    private lateinit var warn: View
    private val rows = ArrayList<ParamRow>()
    private var bandBar: LinearLayout? = null
    private val h = Handler(Looper.getMainLooper())
    private val tick = object : Runnable {
        override fun run() {
            for (r in rows) r.tick()
            h.postDelayed(this, 400)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        AudioEngine.init(this)
        OutputCaps.init(this)
        fid = intent.getStringExtra("fid") ?: AudioEngine.features[0].id
        val f = AudioEngine.feature(fid)

        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setBackgroundColor(AU.BLACK)
        val sv = ScrollView(this)
        sv.isFillViewport = true
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(AU.dp(this, 20), AU.dp(this, 24), AU.dp(this, 20), AU.dp(this, 40))
        sv.addView(col)
        root.addView(sv, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        setContentView(root)
        root.setOnApplyWindowInsetsListener { v, ins ->
            v.setPadding(0, ins.systemWindowInsetTop, 0, ins.systemWindowInsetBottom)
            ins
        }

        val hd = LinearLayout(this)
        hd.orientation = LinearLayout.HORIZONTAL
        hd.gravity = Gravity.CENTER_VERTICAL
        val back = Ui.iconBtn(this, R.drawable.ic_back, "Kembali") { finish() }
        back.background = AU.shape(0, 99f, this, AU.LN, 1)
        hd.addView(back, LinearLayout.LayoutParams(AU.dp(this, 44), AU.dp(this, 44)))
        val title = AU.text(this, f.title, 24f, AU.WHITE, true)
        title.setPadding(AU.dp(this, 12), 0, 0, 0)
        hd.addView(title, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        val sw = AU.switch(this, AudioEngine.featureOn(fid)) { v ->
            AudioEngine.setOn(fid, v)
            updateWarn()
        }
        hd.addView(sw)
        col.addView(hd)

        val sub = AU.text(this, f.desc, 13f, AU.MUT)
        sub.setPadding(0, AU.dp(this, 6), 0, AU.dp(this, 10))
        col.addView(sub)

        val w = AU.text(this, "", 13f, AU.WHITE)
        w.background = AU.shape(AU.CD, 12f, this, AU.LN, 1)
        w.setPadding(AU.dp(this, 12), AU.dp(this, 10), AU.dp(this, 12), AU.dp(this, 10))
        warn = w
        col.addView(w, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))

        if (fid == AudioEngine.EQ) {
            val hs = HorizontalScrollView(this)
            hs.isHorizontalScrollBarEnabled = false
            val bar = LinearLayout(this)
            bar.orientation = LinearLayout.HORIZONTAL
            hs.addView(bar)
            bandBar = bar
            val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            lp.topMargin = AU.dp(this, 12)
            col.addView(hs, lp)
            val t = AU.text(this, "Pilih band, lalu atur Frequency, Gain, Q, tipe, dan slope. Tiap band independen.", 12f, AU.MUT)
            t.setPadding(0, AU.dp(this, 6), 0, 0)
            col.addView(t)
        }

        body = LinearLayout(this)
        body.orientation = LinearLayout.VERTICAL
        col.addView(body, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        buildRows()
        buildBands()

        val actions = LinearLayout(this)
        actions.orientation = LinearLayout.HORIZONTAL
        val bReset = AU.chip(this, "Reset fitur", false)
        bReset.setOnClickListener {
            AudioEngine.resetFeature(fid)
            buildRows()
            buildBands()
            Toast.makeText(this, "${f.title} dikembalikan ke default", Toast.LENGTH_SHORT).show()
        }
        val bSave = AU.chip(this, "Simpan", true)
        bSave.setOnClickListener {
            Toast.makeText(
                this, if (AudioEngine.saveSlot()) "Konfigurasi disimpan" else "Gagal menyimpan", Toast.LENGTH_SHORT
            ).show()
        }
        val l1 = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        l1.rightMargin = AU.dp(this, 8)
        actions.addView(bReset, l1)
        actions.addView(bSave)
        val lpA = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        lpA.topMargin = AU.dp(this, 14)
        col.addView(actions, lpA)
        updateWarn()
    }

    private fun updateWarn() {
        val f = AudioEngine.feature(fid)
        body.alpha = if (AudioEngine.featureOn(fid)) 1f else 0.45f
        when {
            !AudioEngine.master -> {
                warn.visibility = View.VISIBLE
                (warn as android.widget.TextView).text = "Audio Engine sedang mati. Nyalakan di layar Audio Engine agar efek terdengar."
            }
            !AudioEngine.featureOn(fid) -> {
                warn.visibility = View.VISIBLE
                (warn as android.widget.TextView).text = "Fitur nonaktif: parameter tersimpan tapi belum memengaruhi suara. Nyalakan saklar di atas."
            }
            else -> warn.visibility = View.GONE
        }
    }

    private fun buildRows() {
        body.removeAllViews()
        rows.clear()
        val f = AudioEngine.feature(fid)
        for (i in f.params.indices) {
            val r = ParamRow(this, fid, i, false) { onParamChanged() }
            rows.add(r)
            body.addView(r.view)
            val line = View(this)
            line.setBackgroundColor(0xFF1F1F23.toInt())
            body.addView(line, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 1))
        }
    }

    private fun onParamChanged() {
        // jumlah band, label frekuensi band, atau baris yang bergantung pada nilai lain bisa berubah
        if (fid == AudioEngine.EQ) buildBands() else for (r in rows) r.refresh()
    }

    private fun buildBands() {
        val bar = bandBar ?: return
        bar.removeAllViews()
        val n = AudioEngine.eqCount()
        for (i in 0 until n) {
            val f = AudioEngine.eqBands[i * 5]
            val label = if (f >= 1000f) "${AU.fmt(f / 1000f)}k" else AU.fmt(f)
            val c = AU.chip(this, label, i == AudioEngine.eqSel, true, true)
            val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            lp.rightMargin = AU.dp(this, 6)
            c.setOnClickListener {
                AudioEngine.selectEqBand(i)
                buildBands()
                for (r in rows) r.refresh()
            }
            bar.addView(c, lp)
        }
        for (r in rows) r.refresh()
    }

    override fun onResume() {
        super.onResume()
        updateWarn()
        for (r in rows) r.refresh()
        h.post(tick)
    }

    override fun onPause() {
        h.removeCallbacks(tick)
        super.onPause()
    }
}
