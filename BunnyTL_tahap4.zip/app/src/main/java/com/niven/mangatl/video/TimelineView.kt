package com.niven.mangatl

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.util.TypedValue
import android.view.MotionEvent
import android.view.ScaleGestureDetector
import android.view.View
import java.util.Locale
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

/**
 * Timeline tiga jenis baris dengan skala waktu yang sama dan bisa di-zoom:
 * lapisan video (di atas, satu baris per lapisan), video utama (berurutan), dan lagu.
 * Klip yang dipilih punya handle potong di kiri dan kanan, lingkaran panjang pudar di sisi atas,
 * dan titik lekuk yang menempel di garis kurva pudar (bisa ditarik bebas).
 */
class TimelineView(ctx: Context) : View(ctx) {

    /** Kurva pudar. in/out = panjang (ms). (ix,iy) dan (ox,oy) = titik lekuk di kurva, 0..1 dari tepi klip. */
    class Fade(
        val inMs: Long,
        val outMs: Long,
        val ix: Float,
        val iy: Float,
        val ox: Float,
        val oy: Float
    )

    class Item(
        val start: Long,
        val len: Long,
        val label: String,
        val sub: String?,
        val photo: Boolean,
        val fade: Fade
    )

    private var main: List<Item> = emptyList()
    private var ovs: List<Item> = emptyList()
    private var aud: List<Item> = emptyList()
    private var total = 1L

    var selV = -1
        set(v) {
            field = v
            invalidate()
        }
    var selO = -1
        set(v) {
            field = v
            invalidate()
        }
    var selA = -1
        set(v) {
            field = v
            invalidate()
        }

    var playheadMs = 0L
        set(v) {
            field = v
            followPlayhead()
            invalidate()
        }

    var zoom = 1f
        private set
    private var scrollX = 0f

    /** (posisi ms, ikut memilih klip video utama di posisi itu). */
    var onScrub: ((Long, Boolean) -> Unit)? = null

    /** (jenis K_*, indeks); jenis K_NONE = tidak ada yang dipilih. */
    var onSelect: ((Int, Int) -> Unit)? = null
    var onDragStart: (() -> Unit)? = null

    /** (jenis, indeks, mode MODE_*, nilai ms). Arti nilai dijelaskan di tiap mode. */
    var onEdit: ((Int, Int, Int, Long) -> Unit)? = null

    /** (jenis, indeks, true = pudar awal / false = pudar akhir, titik x, titik y). */
    var onBend: ((Int, Int, Boolean, Float, Float) -> Unit)? = null
    var onZoomChanged: ((Float) -> Unit)? = null

    /** Dipanggil saat jari diangkat setelah tarikan yang mengubah data (bukan geser posisi atau zoom). */
    var onDragEnd: (() -> Unit)? = null

    private val fill = Paint(Paint.ANTI_ALIAS_FLAG)
    private val strokeP = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        color = Color.WHITE
        strokeWidth = dp(2f)
    }
    private val line = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        strokeWidth = dp(2f)
    }
    private val curveP = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = dp(1.5f)
        strokeJoin = Paint.Join.ROUND
        strokeCap = Paint.Cap.ROUND
    }
    private val tick = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#3A3A3F")
        strokeWidth = dp(1f)
    }
    private val text = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#000000")
        textAlign = Paint.Align.CENTER
        textSize = TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_SP, 11f, resources.displayMetrics)
    }
    private val rulerText = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#6E6E73")
        textAlign = Paint.Align.CENTER
        textSize = TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_SP, 10f, resources.displayMetrics)
    }
    private val rect = RectF()
    private val path = Path()

    private val scaleDet = ScaleGestureDetector(ctx, object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
        override fun onScale(d: ScaleGestureDetector): Boolean {
            zoomAt(zoom * d.scaleFactor, d.focusX)
            return true
        }
    })
    private var lastFocusX = 0f

    private fun dp(v: Float) = v * resources.displayMetrics.density

    // ------------------------------------------------------------------ ukuran dan skala

    private fun hp() = dp(12f)
    private fun vw() = (width - 2 * hp()).coerceAtLeast(1f)
    private fun cw() = vw() * zoom
    private fun xOf(ms: Long) = hp() + cw() * ms / total - scrollX
    private fun msOf(x: Float) = (((x - hp() + scrollX) / cw()) * total).toLong().coerceIn(0L, total)
    private fun fpx(ms: Long) = cw() * ms / total
    private fun clampScroll() {
        scrollX = scrollX.coerceIn(0f, max(0f, cw() - vw()))
    }

    private fun rulerH() = dp(20f)
    private fun gap() = dp(16f)
    private fun ovH() = dp(34f)
    private fun mainH() = dp(50f)
    private fun audH() = dp(44f)
    private fun top0() = rulerH() + gap()
    private fun ovTop(i: Int) = top0() + (ovs.size - 1 - i) * (ovH() + gap())
    private fun mainTop() = top0() + ovs.size * (ovH() + gap())
    private fun audTop() = mainTop() + mainH() + gap()

    /** Tinggi yang dibutuhkan; Activity memakainya saat jumlah lapisan berubah. */
    fun wantedHeightPx(overlayCount: Int): Int =
        (top0() + overlayCount * (ovH() + gap()) + mainH() + gap() + audH() + dp(10f)).toInt()

    fun setData(m: List<Item>, o: List<Item>, a: List<Item>) {
        main = m
        ovs = o
        aud = a
        total = m.sumOf { it.len }.coerceAtLeast(1L)
        clampScroll()
        invalidate()
    }

    fun zoomBy(f: Float) = zoomAt(zoom * f, width / 2f)

    private fun zoomAt(z: Float, focusX: Float) {
        val nz = z.coerceIn(1f, 24f)
        val focusMs = msOf(focusX)
        zoom = nz
        scrollX = hp() + cw() * focusMs / total - focusX
        clampScroll()
        onZoomChanged?.invoke(zoom)
        invalidate()
    }

    private fun followPlayhead() {
        if (zoom <= 1f || mode != M_NONE || width == 0) return
        val px = xOf(playheadMs)
        if (px < hp() + dp(8f) || px > width - hp() - dp(8f)) {
            scrollX = hp() + cw() * playheadMs / total - vw() * 0.3f
            clampScroll()
        }
    }

    // ------------------------------------------------------------------ geometri item terpilih

    private class Geo(val l: Float, val r: Float, val top: Float, val bot: Float, val item: Item, val kind: Int, val idx: Int)

    private fun geoOf(kind: Int, idx: Int): Geo? {
        return when (kind) {
            K_MAIN -> main.getOrNull(idx)?.let { Geo(xOf(it.start), xOf(it.start + it.len), mainTop(), mainTop() + mainH(), it, kind, idx) }
            K_OV -> ovs.getOrNull(idx)?.let { Geo(xOf(it.start), xOf(it.start + it.len), ovTop(idx), ovTop(idx) + ovH(), it, kind, idx) }
            K_AUDIO -> aud.getOrNull(idx)?.let { Geo(xOf(it.start), xOf(it.start + it.len), audTop(), audTop() + audH(), it, kind, idx) }
            else -> null
        }
    }

    private fun selectedGeo(): Geo? = when {
        selV in main.indices -> geoOf(K_MAIN, selV)
        selO in ovs.indices -> geoOf(K_OV, selO)
        selA in aud.indices -> geoOf(K_AUDIO, selA)
        else -> null
    }

    private fun inKnob(g: Geo) = (g.l + max(fpx(g.item.fade.inMs), dp(14f))) to g.top
    private fun outKnob(g: Geo) = (g.r - max(fpx(g.item.fade.outMs), dp(14f))) to g.top
    private fun inBend(g: Geo): Pair<Float, Float>? {
        val f = g.item.fade
        return if (f.inMs > 0) (g.l + fpx(f.inMs) * f.ix) to (g.bot - (g.bot - g.top) * f.iy) else null
    }

    private fun outBend(g: Geo): Pair<Float, Float>? {
        val f = g.item.fade
        return if (f.outMs > 0) (g.r - fpx(f.outMs) * f.ox) to (g.bot - (g.bot - g.top) * f.oy) else null
    }

    // ------------------------------------------------------------------ gambar

    private fun drawFade(c: Canvas, g: Geo, shade: Int, lineColor: Int) {
        val f = g.item.fade
        val h = g.bot - g.top
        val steps = 28
        fill.color = shade
        curveP.color = lineColor
        if (f.inMs > 0) {
            val fw = min(fpx(f.inMs), g.r - g.l)
            path.reset()
            path.moveTo(g.l, g.top)
            path.lineTo(g.l + fw, g.top)
            for (k in steps downTo 0) {
                val u = k / steps.toFloat()
                path.lineTo(g.l + fw * u, g.bot - h * curve(u, f.ix, f.iy))
            }
            path.close()
            c.drawPath(path, fill)
            path.reset()
            for (k in 0..steps) {
                val u = k / steps.toFloat()
                val x = g.l + fw * u
                val y = g.bot - h * curve(u, f.ix, f.iy)
                if (k == 0) path.moveTo(x, y) else path.lineTo(x, y)
            }
            c.drawPath(path, curveP)
        }
        if (f.outMs > 0) {
            val fw = min(fpx(f.outMs), g.r - g.l)
            path.reset()
            path.moveTo(g.r - fw, g.top)
            path.lineTo(g.r, g.top)
            for (k in 0..steps) {
                val u = k / steps.toFloat()
                path.lineTo(g.r - fw * u, g.bot - h * curve(u, f.ox, f.oy))
            }
            path.close()
            c.drawPath(path, fill)
            path.reset()
            for (k in 0..steps) {
                val u = k / steps.toFloat()
                val x = g.r - fw * u
                val y = g.bot - h * curve(u, f.ox, f.oy)
                if (k == 0) path.moveTo(x, y) else path.lineTo(x, y)
            }
            c.drawPath(path, curveP)
        }
    }

    private fun knob(c: Canvas, x: Float, y: Float, rad: Float) {
        fill.color = Color.BLACK
        c.drawCircle(x, y, rad, fill)
        c.drawCircle(x, y, rad, strokeP)
    }

    private fun dot(c: Canvas, x: Float, y: Float) {
        fill.color = Color.WHITE
        c.drawCircle(x, y, dp(6f), fill)
        fill.color = Color.BLACK
        c.drawCircle(x, y, dp(2.5f), fill)
    }

    private fun bar(c: Canvas, x: Float, top: Float, bot: Float) {
        fill.color = Color.WHITE
        rect.set(x - dp(5f), top - dp(4f), x + dp(5f), bot + dp(4f))
        c.drawRoundRect(rect, dp(5f), dp(5f), fill)
        fill.color = Color.parseColor("#000000")
        rect.set(x - dp(1f), top + dp(8f), x + dp(1f), bot - dp(8f))
        c.drawRoundRect(rect, dp(1f), dp(1f), fill)
    }

    private fun drawItem(c: Canvas, g: Geo, selected: Boolean) {
        val it = g.item
        if (g.r < -dp(40f) || g.l > width + dp(40f)) return
        val r8 = dp(8f)
        rect.set(g.l + dp(1f), g.top, g.r - dp(1f), g.bot)
        val lightText = !selected && g.kind != K_MAIN
        fill.color = when {
            selected -> Color.parseColor("#F2F2F2")
            g.kind == K_MAIN -> if (it.photo) Color.parseColor("#8E8E93") else Color.parseColor("#6E6E73")
            g.kind == K_OV -> Color.parseColor("#3A3A3F")
            else -> Color.parseColor("#48484D")
        }
        c.drawRoundRect(rect, r8, r8, fill)
        val w = g.r - g.l
        if (w > dp(26f)) {
            text.color = if (lightText) Color.parseColor("#C7C7CC") else Color.parseColor("#000000")
            val cx = (max(g.l, 0f) + min(g.r, width.toFloat())) / 2f
            val cy = (g.top + g.bot) / 2f
            if (it.sub == null) {
                c.drawText(it.label, cx, cy + text.textSize / 3f, text)
            } else {
                c.drawText(it.label, cx, cy - dp(2f), text)
                c.drawText(it.sub, cx, cy + text.textSize, text)
            }
        }
        if (it.fade.inMs > 0 || it.fade.outMs > 0) {
            c.save()
            c.clipRect(g.l + dp(1f), g.top, g.r - dp(1f), g.bot)
            drawFade(
                c, g, Color.parseColor("#66000000"),
                if (selected && !lightText) Color.parseColor("#000000") else Color.parseColor("#C7C7CC")
            )
            c.restore()
        }
        if (selected) {
            val ik = inKnob(g)
            val ok = outKnob(g)
            knob(c, ik.first, ik.second, dp(7f))
            knob(c, ok.first, ok.second, dp(7f))
            inBend(g)?.let { dot(c, it.first, it.second) }
            outBend(g)?.let { dot(c, it.first, it.second) }
            bar(c, g.l, g.top, g.bot)
            bar(c, g.r, g.top, g.bot)
        }
    }

    private fun fmtT(ms: Long, tenths: Boolean): String {
        val s = ms / 1000
        val base = String.format(Locale.US, "%d:%02d", s / 60, s % 60)
        return if (tenths) base + "," + (ms % 1000) / 100 else base
    }

    private fun drawRuler(c: Canvas) {
        val steps = longArrayOf(100, 200, 500, 1000, 2000, 5000, 10000, 15000, 30000, 60000, 120000, 300000)
        var step = steps.last()
        for (s in steps) {
            if (fpx(s) >= dp(56f)) {
                step = s
                break
            }
        }
        val minor = step / 2
        val baseY = rulerH()
        c.drawLine(hp() - scrollX.coerceAtMost(hp()), baseY, width.toFloat(), baseY, tick)
        var t = (msOf(0f) / minor) * minor
        val endMs = msOf(width.toFloat())
        while (t <= endMs + minor) {
            val x = xOf(t)
            if (t in 0..total) {
                val major = t % step == 0L
                c.drawLine(x, if (major) baseY - dp(8f) else baseY - dp(4f), x, baseY, tick)
                if (major) c.drawText(fmtT(t, step < 1000), x, baseY - dp(10f), rulerText)
            }
            t += minor
        }
    }

    override fun onDraw(c: Canvas) {
        drawRuler(c)
        for (i in ovs.indices) geoOf(K_OV, i)?.let { drawItem(c, it, i == selO) }
        for (i in main.indices) geoOf(K_MAIN, i)?.let { drawItem(c, it, i == selV) }

        val at = audTop()
        val ab = at + audH()
        rect.set(hp(), at, width - hp(), ab)
        fill.color = Color.parseColor("#0D0D0F")
        c.drawRoundRect(rect, dp(8f), dp(8f), fill)
        strokeP.color = Color.parseColor("#1F1F23")
        strokeP.strokeWidth = dp(1f)
        c.drawRoundRect(rect, dp(8f), dp(8f), strokeP)
        strokeP.color = Color.WHITE
        strokeP.strokeWidth = dp(2f)
        if (aud.isEmpty()) {
            text.color = Color.parseColor("#6E6E73")
            c.drawText("Belum ada lagu", width / 2f, (at + ab) / 2f + text.textSize / 3f, text)
        }
        for (i in aud.indices) geoOf(K_AUDIO, i)?.let { drawItem(c, it, i == selA) }

        val px = xOf(playheadMs.coerceIn(0L, total))
        if (px >= 0 && px <= width) {
            c.drawLine(px, dp(2f), px, ab + dp(6f), line)
            fill.color = Color.WHITE
            c.drawCircle(px, dp(3f), dp(3.5f), fill)
        }
    }

    // ------------------------------------------------------------------ sentuhan

    private var mode = M_NONE
    private var gKind = K_NONE
    private var gIdx = -1
    private var grab = 0L
    private var lastX = 0f

    private fun near(a: Float, b: Float, r: Float) = abs(a - b) <= r

    private fun isDragMode() = mode == M_FIN || mode == M_FOUT || mode == M_BIN || mode == M_BOUT ||
        mode == M_L || mode == M_R || mode == M_MOVE

    override fun onTouchEvent(e: MotionEvent): Boolean {
        scaleDet.onTouchEvent(e)
        if (e.pointerCount > 1 || scaleDet.isInProgress) {
            val fx = scaleDet.focusX
            if (e.actionMasked == MotionEvent.ACTION_MOVE) {
                scrollX -= fx - lastFocusX
                clampScroll()
                invalidate()
            }
            lastFocusX = fx
            if (isDragMode()) onDragEnd?.invoke()
            mode = M_NONE
            return true
        }
        val x = e.x
        val y = e.y
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                parent?.requestDisallowInterceptTouchEvent(true)
                mode = M_NONE
                gKind = K_NONE
                gIdx = -1
                lastX = x
                if (y < rulerH()) {
                    mode = M_PAN
                } else if (!downSelected(x, y)) {
                    downRows(x, y)
                }
                return true
            }
            MotionEvent.ACTION_MOVE -> {
                onMove(x, y)
                return true
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                if (e.actionMasked == MotionEvent.ACTION_UP) performClick()
                val wasDrag = isDragMode()
                mode = M_NONE
                if (wasDrag) onDragEnd?.invoke()
                return true
            }
        }
        return super.onTouchEvent(e)
    }

    private fun downSelected(x: Float, y: Float): Boolean {
        val g = selectedGeo() ?: return false
        if (y < g.top - dp(24f) || y > g.bot + dp(14f)) return false
        data class Cand(val d: Float, val m: Int)
        val cands = ArrayList<Cand>()
        inBend(g)?.let { cands.add(Cand(hypot2(x - it.first, y - it.second), M_BIN)) }
        outBend(g)?.let { cands.add(Cand(hypot2(x - it.first, y - it.second), M_BOUT)) }
        val ik = inKnob(g)
        val ok = outKnob(g)
        cands.add(Cand(hypot2(x - ik.first, y - ik.second), M_FIN))
        cands.add(Cand(hypot2(x - ok.first, y - ok.second), M_FOUT))
        if (y >= g.top - dp(12f) && y <= g.bot + dp(12f)) {
            cands.add(Cand(abs(x - g.l), M_L))
            cands.add(Cand(abs(x - g.r), M_R))
        }
        val best = cands.minByOrNull { it.d } ?: return false
        if (best.d > dp(22f)) return false
        mode = best.m
        gKind = g.kind
        gIdx = g.idx
        onDragStart?.invoke()
        return true
    }

    private fun hypot2(dx: Float, dy: Float) = Math.sqrt((dx * dx + dy * dy).toDouble()).toFloat()

    private fun downRows(x: Float, y: Float) {
        val ms = msOf(x)
        val half = gap() / 2f
        // lapisan video
        for (i in ovs.indices) {
            val t = ovTop(i)
            if (y >= t - half && y <= t + ovH() + half) {
                val o = ovs[i]
                if (ms >= o.start && ms <= o.start + o.len) {
                    onSelect?.invoke(K_OV, i)
                    gKind = K_OV
                    gIdx = i
                    grab = ms - o.start
                    mode = M_MOVE
                    onDragStart?.invoke()
                } else {
                    onSelect?.invoke(K_NONE, -1)
                    mode = M_SCRUB_KEEP
                    onScrub?.invoke(ms, false)
                }
                return
            }
        }
        if (y >= audTop() - half) {
            for (i in aud.indices) {
                val a = aud[i]
                if (ms >= a.start && ms <= a.start + a.len) {
                    onSelect?.invoke(K_AUDIO, i)
                    gKind = K_AUDIO
                    gIdx = i
                    grab = ms - a.start
                    mode = M_MOVE
                    onDragStart?.invoke()
                    return
                }
            }
            onSelect?.invoke(K_NONE, -1)
            mode = M_SCRUB_KEEP
            onScrub?.invoke(ms, false)
            return
        }
        mode = M_SCRUB_SEL
        onScrub?.invoke(ms, true)
    }

    private fun onMove(x: Float, y: Float) {
        when (mode) {
            M_PAN -> {
                scrollX -= x - lastX
                lastX = x
                clampScroll()
                invalidate()
            }
            M_SCRUB_SEL -> onScrub?.invoke(msOf(x), true)
            M_SCRUB_KEEP -> onScrub?.invoke(msOf(x), false)
            M_FIN, M_FOUT -> {
                val g = geoOf(gKind, gIdx) ?: return
                val ms = if (mode == M_FIN) ((x - g.l) / cw() * total).toLong() else ((g.r - x) / cw() * total).toLong()
                onEdit?.invoke(gKind, gIdx, if (mode == M_FIN) MODE_FIN else MODE_FOUT, ms.coerceAtLeast(0L))
            }
            M_BIN, M_BOUT -> {
                val g = geoOf(gKind, gIdx) ?: return
                val f = g.item.fade
                val isIn = mode == M_BIN
                val fw = max(fpx(if (isIn) f.inMs else f.outMs), 1f)
                val bx = (if (isIn) (x - g.l) / fw else (g.r - x) / fw).coerceIn(0.08f, 0.92f)
                val by = ((g.bot - y) / (g.bot - g.top)).coerceIn(0.05f, 0.95f)
                onBend?.invoke(gKind, gIdx, isIn, bx, by)
            }
            M_L, M_R -> {
                if (gKind == K_MAIN) {
                    // video utama: potong bergeser (ripple), kirim selisih ms sejak gerakan terakhir
                    val d = ((x - lastX) / cw() * total).toLong()
                    if (d != 0L) {
                        lastX += d * cw() / total
                        onEdit?.invoke(gKind, gIdx, if (mode == M_L) MODE_TRIM_L else MODE_TRIM_R, d)
                    }
                } else {
                    onEdit?.invoke(gKind, gIdx, if (mode == M_L) MODE_L else MODE_R, msOf(x))
                }
            }
            M_MOVE -> onEdit?.invoke(gKind, gIdx, MODE_MOVE, msOf(x) - grab)
        }
    }

    override fun performClick(): Boolean = super.performClick()

    companion object {
        const val K_NONE = 0
        const val K_MAIN = 1
        const val K_OV = 2
        const val K_AUDIO = 3

        /** L/R: tepi kiri/kanan (ms absolut) untuk lagu dan lapisan. MOVE: awal baru (ms). FIN/FOUT: panjang pudar (ms). */
        const val MODE_L = 0
        const val MODE_R = 1
        const val MODE_MOVE = 2
        const val MODE_FIN = 3
        const val MODE_FOUT = 4

        /** Video utama: potong awal/akhir; nilai = selisih ms dari gerakan sebelumnya (positif = ke kanan). */
        const val MODE_TRIM_L = 5
        const val MODE_TRIM_R = 6

        private const val M_NONE = 0
        private const val M_SCRUB_SEL = 1
        private const val M_SCRUB_KEEP = 2
        private const val M_FIN = 3
        private const val M_FOUT = 4
        private const val M_BIN = 5
        private const val M_BOUT = 6
        private const val M_L = 7
        private const val M_R = 8
        private const val M_MOVE = 9
        private const val M_PAN = 10

        /**
         * Kurva pudar dari (0,0) lewat titik lekuk (bx,by) ke (1,1): spline monoton yang halus
         * (awal dan akhir landai). Selalu naik, tidak pernah melonjak.
         */
        fun curve(t: Float, bx: Float, by: Float): Float {
            val x = t.coerceIn(0f, 1f)
            val px = bx.coerceIn(0.05f, 0.95f)
            val py = by.coerceIn(0.02f, 0.98f)
            val d0 = py / px
            val d1 = (1f - py) / (1f - px)
            val m1 = if (d0 <= 0f || d1 <= 0f) 0f else 2f * d0 * d1 / (d0 + d1)
            return if (x <= px) {
                val h = px
                hermite(x / h, 0f, py, 0f, m1 * h)
            } else {
                val h = 1f - px
                hermite((x - px) / h, py, 1f, m1 * h, 0f)
            }
        }

        private fun hermite(s: Float, y0: Float, y1: Float, m0h: Float, m1h: Float): Float {
            val s2 = s * s
            val s3 = s2 * s
            val h00 = 2f * s3 - 3f * s2 + 1f
            val h10 = s3 - 2f * s2 + s
            val h01 = -2f * s3 + 3f * s2
            val h11 = s3 - s2
            return (h00 * y0 + h10 * m0h + h01 * y1 + h11 * m1h).coerceIn(0f, 1f)
        }

        /** Pengali (0..1) di posisi off dalam klip berdurasi dur. */
        fun fadeGain(off: Long, dur: Long, f: Fade): Float {
            var g = 1f
            if (f.inMs > 0L && off < f.inMs) g = min(g, curve(off.toFloat() / f.inMs, f.ix, f.iy))
            if (f.outMs > 0L && off > dur - f.outMs) g = min(g, curve((dur - off).toFloat() / f.outMs, f.ox, f.oy))
            return g.coerceIn(0f, 1f)
        }

        fun fmtSpeed(f: Float): String {
            val s = if (f == f.toInt().toFloat()) f.toInt().toString() else f.toString().replace('.', ',')
            return s + "x"
        }
    }
}
