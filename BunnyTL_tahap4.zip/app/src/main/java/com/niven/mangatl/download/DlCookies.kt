package com.niven.mangatl

import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.net.Uri
import android.util.Log
import android.webkit.CookieManager
import com.yausername.youtubedl_android.YoutubeDLRequest
import java.io.File

/**
 * Cookies untuk video yang butuh login (anti-bot YouTube, batas umur, khusus member).
 * Disimpan sebagai cookies.txt format Netscape di data app; yt-dlp membacanya lewat --cookies.
 */
object DlCookies {
    private const val TAG = "DlCookies"
    private const val HEADER = "# Netscape HTTP Cookie File\n# Dibuat oleh BunnyTL\n\n"
    private const val CHROMIUM_EPOCH = 11_644_473_600L // detik antara 1601 dan 1970

    fun file(ctx: Context) = File(ctx.filesDir, "cookies.txt")

    fun count(ctx: Context): Int {
        val f = file(ctx)
        if (!f.isFile) return 0
        return runCatching { f.readLines().count { it.isNotBlank() && !it.startsWith("#") && it.split('\t').size >= 7 } }
            .getOrDefault(0)
    }

    fun has(ctx: Context) = count(ctx) > 0

    fun enabled(ctx: Context) = DlPrefs.useCookies(ctx) && has(ctx)

    /** Tambahkan opsi cookies ke perintah yt-dlp bila diaktifkan. */
    fun apply(ctx: Context, req: YoutubeDLRequest) {
        if (!enabled(ctx)) return
        req.addOption("--cookies", file(ctx).absolutePath)
        val ua = DlPrefs.userAgent(ctx)
        if (ua.isNotEmpty()) req.addOption("--add-header", "User-Agent:$ua")
    }

    fun clear(ctx: Context) {
        file(ctx).delete()
        runCatching {
            CookieManager.getInstance().removeAllCookies(null)
            CookieManager.getInstance().flush()
        }
    }

    /** Impor cookies.txt dari berkas (mis. hasil ekstensi browser). Mengembalikan jumlah cookie. */
    fun importFrom(ctx: Context, uri: Uri): Int {
        val text = ctx.contentResolver.openInputStream(uri)?.use { it.readBytes().toString(Charsets.UTF_8) }
            ?: throw IllegalStateException("Berkas tidak bisa dibaca.")
        val lines = text.replace("\r\n", "\n").replace('\r', '\n').lines()
            .map { it.removePrefix("#HttpOnly_") }
            .filter { it.isNotBlank() && !it.startsWith("#") && it.split('\t').size >= 7 }
        if (lines.isEmpty()) throw IllegalStateException("Ini bukan cookies.txt format Netscape (tidak ada baris cookie).")
        write(ctx, lines)
        return lines.size
    }

    /** Ambil cookies yang tersimpan di WebView setelah pengguna login. Mengembalikan jumlah cookie. */
    fun exportFromWebView(ctx: Context, urls: List<String>): Int {
        val cm = CookieManager.getInstance()
        cm.flush()
        var lines = runCatching { fromWebViewDb(ctx) }.onFailure { Log.w(TAG, "baca db cookies gagal", it) }
            .getOrDefault(emptyList())
        if (lines.isEmpty()) lines = fromCookieManager(cm, urls)
        if (lines.isEmpty()) throw IllegalStateException("Belum ada cookies. Masuk ke akunmu dulu di halaman tadi.")
        write(ctx, lines)
        return lines.size
    }

    private fun write(ctx: Context, lines: List<String>) {
        file(ctx).writeText(HEADER + lines.joinToString("\n") + "\n")
    }

    private fun line(domain: String, path: String, secure: Boolean, expiry: Long, name: String, value: String): String {
        val sub = if (domain.startsWith(".")) "TRUE" else "FALSE"
        return listOf(domain, sub, path.ifEmpty { "/" }, if (secure) "TRUE" else "FALSE", expiry.toString(), name, value)
            .joinToString("\t")
    }

    /** Cookie WebView (Chromium) disimpan di app_webview/Default/Cookies, tidak dienkripsi di Android. */
    private fun fromWebViewDb(ctx: Context): List<String> {
        val db = File(ctx.dataDir, "app_webview/Default/Cookies")
        if (!db.isFile) return emptyList()
        val now = System.currentTimeMillis() / 1000
        val far = now + 365L * 24 * 3600
        val out = ArrayList<String>()
        SQLiteDatabase.openDatabase(db.absolutePath, null, SQLiteDatabase.OPEN_READONLY).use { d ->
            d.query("cookies", arrayOf("host_key", "expires_utc", "path", "name", "value", "is_secure"),
                null, null, null, null, null).use { c ->
                while (c.moveToNext()) {
                    val name = c.getString(3) ?: continue
                    val value = c.getString(4) ?: ""
                    if (name.isEmpty()) continue
                    val raw = c.getLong(1)
                    val exp = if (raw <= 0L) far else raw / 1_000_000L - CHROMIUM_EPOCH
                    if (exp in 1..now) continue // sudah kedaluwarsa
                    out += line(c.getString(0) ?: continue, c.getString(2) ?: "/", c.getInt(5) == 1, exp, name, value)
                }
            }
        }
        return out
    }

    /** Cadangan kalau database di atas tidak terbaca: hanya name=value per situs. */
    private fun fromCookieManager(cm: CookieManager, urls: List<String>): List<String> {
        val far = System.currentTimeMillis() / 1000 + 365L * 24 * 3600
        val out = LinkedHashSet<String>()
        for (u in urls) {
            val host = runCatching { Uri.parse(u).host }.getOrNull() ?: continue
            val domain = "." + host.split('.').takeLast(2).joinToString(".")
            val raw = cm.getCookie(u) ?: continue
            for (kv in raw.split(';')) {
                val i = kv.indexOf('=')
                if (i <= 0) continue
                out += line(domain, "/", true, far, kv.substring(0, i).trim(), kv.substring(i + 1).trim())
            }
        }
        return out.toList()
    }
}

/** Potong cover jadi persegi (dipakai bersama --embed-thumbnail untuk MP3/M4A). Sama dengan yang dipakai SnapNet. */
object DlConfig {
    const val CROP_ARTWORK = """--ppa "ffmpeg: -c:v mjpeg -vf crop=\"'if(gt(ih,iw),iw,ih)':'if(gt(iw,ih),ih,iw)'\"""""
}
