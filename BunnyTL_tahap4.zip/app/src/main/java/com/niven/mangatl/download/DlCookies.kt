package com.niven.mangatl

import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.net.Uri
import android.util.Log
import android.webkit.CookieManager
import com.yausername.youtubedl_android.YoutubeDLRequest
import java.io.File

/** Situs yang bisa dibuka langsung ke halaman login. [key] = domain utama. */
class LoginSite(val label: String, val key: String, val loginUrl: String)

/**
 * Cookies untuk video yang butuh login (anti-bot YouTube, batas umur, khusus member).
 * Disimpan sebagai cookies.txt format Netscape di data app; yt-dlp membacanya lewat --cookies.
 */
object DlCookies {
    private const val TAG = "DlCookies"
    private const val HEADER = "# Netscape HTTP Cookie File\n# Dibuat oleh BunnyTL\n\n"
    private const val CHROMIUM_EPOCH = 11_644_473_600L // detik antara 1601 dan 1970

    val SITES = listOf(
        LoginSite("YouTube", "youtube.com", "https://accounts.google.com/ServiceLogin?service=youtube&continue=https%3A%2F%2Fwww.youtube.com%2F"),
        LoginSite("Instagram", "instagram.com", "https://www.instagram.com/accounts/login/"),
        LoginSite("TikTok", "tiktok.com", "https://www.tiktok.com/login"),
        LoginSite("Facebook", "facebook.com", "https://www.facebook.com/login"),
        LoginSite("X", "x.com", "https://x.com/i/flow/login"),
        LoginSite("Threads", "threads.com", "https://www.threads.com/login"),
        LoginSite("Reddit", "reddit.com", "https://www.reddit.com/login/"),
        LoginSite("Pinterest", "pinterest.com", "https://www.pinterest.com/login/"),
        LoginSite("Snapchat", "snapchat.com", "https://accounts.snapchat.com/accounts/login")
    )

    private fun byKey(key: String) = SITES.first { it.key == key }

    /** Situs bawaan + situs buatan pengguna. */
    fun allSites(): List<LoginSite> = SITES + CustomSites.cached

    /** Situs dari sebuah link (null kalau bukan salah satu di daftar). */
    fun siteFor(url: String?): LoginSite? {
        val host = runCatching { url?.let { Uri.parse(it).host } }.getOrNull()?.lowercase() ?: return null
        SITES.firstOrNull { host == it.key || host.endsWith("." + it.key) }?.let { return it }
        CustomSites.cached.firstOrNull { host == it.key || host.endsWith("." + it.key) }?.let { return it }
        return when {
            host.endsWith("youtu.be") -> SITES[0]
            host.endsWith("twitter.com") -> SITES[4]
            host.endsWith("fb.watch") -> SITES[3]
            host.endsWith("threads.net") -> byKey("threads.com")
            host.endsWith("redd.it") -> byKey("reddit.com")
            host.endsWith("pin.it") -> byKey("pinterest.com")
            else -> null
        }
    }

    /** Halaman login yang dituju: situs dari link, kalau tak ada situs terakhir yang dipakai, kalau tak ada YouTube. */
    fun loginUrlFor(ctx: Context, url: String?): String =
        (siteFor(url) ?: allSites().firstOrNull { it.key == DlPrefs.lastLogin(ctx) } ?: SITES[0]).loginUrl

    fun file(ctx: Context) = File(ctx.filesDir, "cookies.txt")

    fun count(ctx: Context): Int {
        val f = file(ctx)
        if (!f.isFile) return 0
        return runCatching { f.readLines().count { it.isNotBlank() && !it.startsWith("#") && it.split('\t').size >= 7 } }
            .getOrDefault(0)
    }

    fun has(ctx: Context) = count(ctx) > 0

    fun enabled(ctx: Context) = DlPrefs.useCookies(ctx) && has(ctx)

    /** Domain tiap cookie di file (tanpa titik di depan), mis. instagram.com, www.youtube.com. */
    private fun cookieDomains(ctx: Context): Set<String> {
        val f = file(ctx)
        if (!f.isFile) return emptySet()
        return runCatching {
            f.readLines().asSequence()
                .map { it.removePrefix("#HttpOnly_") }
                .filter { it.isNotBlank() && !it.startsWith("#") }
                .mapNotNull { it.split('\t').firstOrNull()?.trim()?.trimStart('.')?.lowercase() }
                .filter { it.isNotEmpty() }
                .toSet()
        }.getOrDefault(emptySet())
    }

    /** Nama lain dari satu situs, supaya link pendek/alias tetap cocok dengan cookies-nya. */
    private fun aliases(host: String): List<String> {
        val extra = when {
            host.endsWith("youtu.be") -> listOf("youtube.com", "google.com")
            host.endsWith("youtube.com") -> listOf("google.com")
            host.endsWith("fb.watch") || host.endsWith("fb.com") -> listOf("facebook.com")
            host.endsWith("instagr.am") -> listOf("instagram.com")
            host.endsWith("twitter.com") -> listOf("x.com")
            host.endsWith("x.com") -> listOf("twitter.com")
            host.endsWith("threads.net") -> listOf("threads.com", "instagram.com")
            host.endsWith("threads.com") -> listOf("threads.net", "instagram.com")
            host.endsWith("redd.it") -> listOf("reddit.com")
            host.endsWith("pin.it") -> listOf("pinterest.com")
            else -> emptyList()
        }
        return listOf(host) + extra
    }

    /**
     * Apakah cookies dipakai untuk link ini? Hanya kalau file cookies punya cookie untuk situs link tersebut.
     * Penting: cookies Instagram TIDAK boleh ikut ke Facebook/YouTube dll. Cookies + User-Agent WebView
     * yang dipaksakan ke situs lain bisa membuat situs itu menyajikan halaman berbeda (mis. Facebook jadi
     * hanya menampilkan audio, tanpa pilihan video).
     */
    fun appliesTo(ctx: Context, url: String?): Boolean {
        if (!enabled(ctx) || url.isNullOrBlank()) return false
        val host = runCatching { Uri.parse(url).host }.getOrNull()?.lowercase() ?: return false
        val domains = cookieDomains(ctx)
        return aliases(host).any { h -> domains.any { d -> h == d || h.endsWith(".$d") || d.endsWith(".$h") } }
    }

    /** Tambahkan opsi cookies ke perintah yt-dlp, hanya bila dipakai untuk situs [url] ini. */
    fun apply(ctx: Context, req: YoutubeDLRequest, url: String?) {
        if (!appliesTo(ctx, url)) return
        req.addOption("--cookies", file(ctx).absolutePath)
        val ua = DlPrefs.userAgent(ctx)
        if (ua.isNotEmpty()) req.addOption("--add-header", "User-Agent:$ua")
    }

    // ---------------------------------------------------------------- hapus per situs

    class CookieGroup(val key: String, val label: String, val count: Int)

    private const val OTHER = "_lainnya"

    /** Domain yang dihitung milik satu situs (login YouTube lewat google.com, X = twitter.com, dst). */
    private fun siteDomains(key: String): List<String> = when (key) {
        "youtube.com" -> listOf("youtube.com", "google.com", "youtu.be", "googlevideo.com")
        "facebook.com" -> listOf("facebook.com", "fb.com")
        "x.com" -> listOf("x.com", "twitter.com")
        "threads.com" -> listOf("threads.com", "threads.net")
        "reddit.com" -> listOf("reddit.com", "redd.it")
        "pinterest.com" -> listOf("pinterest.com", "pin.it")
        else -> listOf(key)
    }

    private fun groupOf(domain: String): String {
        val d = domain.removePrefix("#HttpOnly_").trimStart('.').lowercase()
        return allSites().firstOrNull { s -> siteDomains(s.key).any { g -> d == g || d.endsWith(".$g") } }?.key ?: OTHER
    }

    private fun dataLines(ctx: Context): List<List<String>> {
        val f = file(ctx)
        if (!f.isFile) return emptyList()
        return runCatching {
            f.readLines().filter { it.isNotBlank() && !it.startsWith("#") }.map { it.split('\t') }.filter { it.size >= 7 }
        }.getOrDefault(emptyList())
    }

    /** Cookies yang tersimpan, dikelompokkan per situs (hanya situs yang punya cookies). */
    fun groups(ctx: Context): List<CookieGroup> {
        val counts = LinkedHashMap<String, Int>()
        dataLines(ctx).forEach { val k = groupOf(it[0]); counts[k] = (counts[k] ?: 0) + 1 }
        val out = allSites().filter { counts.containsKey(it.key) }.map { CookieGroup(it.key, it.label, counts[it.key]!!) }.toMutableList()
        counts[OTHER]?.let { out += CookieGroup(OTHER, "Lainnya", it) }
        return out
    }

    /** Hapus cookies hanya untuk situs [keys] (dari file cookies.txt DAN dari WebView). Situs lain tidak disentuh. */
    fun clearGroups(ctx: Context, keys: Set<String>) {
        val keep = ArrayList<String>()
        val gone = ArrayList<List<String>>()
        for (p in dataLines(ctx)) {
            if (groupOf(p[0]) in keys) gone += p else keep += p.joinToString("\t")
        }
        if (keep.isEmpty()) file(ctx).delete() else write(ctx, keep)
        runCatching {
            val cm = CookieManager.getInstance()
            val old = "Thu, 01 Jan 1970 00:00:00 GMT"
            for (p in gone) {
                val dom = p[0]
                cm.setCookie(
                    "https://" + dom.trimStart('.'),
                    "${p[5]}=; Expires=$old; Max-Age=0; Path=${p[2].ifEmpty { "/" }}" + (if (dom.startsWith(".")) "; Domain=$dom" else "")
                )
            }
            cm.flush()
        }
        WebKeeper.drop()
    }

    fun clear(ctx: Context) {
        file(ctx).delete()
        runCatching {
            CookieManager.getInstance().removeAllCookies(null)
            CookieManager.getInstance().flush()
        }
        WebKeeper.drop()
    }

    /** Impor cookies.txt dari berkas (mis. hasil ekstensi browser). Mengembalikan jumlah cookie. */
    fun importFrom(ctx: Context, uri: Uri): Int {
        val text = ctx.contentResolver.openInputStream(uri)?.use { it.readBytes().toString(Charsets.UTF_8) }
            ?: throw IllegalStateException("Berkas tidak bisa dibaca.")
        val lines = text.replace("\r\n", "\n").replace('\r', '\n').lines()
            .map { it.removePrefix("#HttpOnly_") }
            .filter { it.isNotBlank() && !it.startsWith("#") && it.split('\t').size >= 7 }
        if (lines.isEmpty()) throw IllegalStateException("Ini bukan cookies.txt format Netscape (tidak ada baris cookie).")
        write(ctx, lines)
        return lines.size
    }

    /** Ambil cookies yang tersimpan di WebView setelah pengguna login. Mengembalikan jumlah cookie. */
    fun exportFromWebView(ctx: Context, urls: List<String>): Int {
        val cm = CookieManager.getInstance()
        cm.flush()
        var lines = runCatching { fromWebViewDb(ctx) }.onFailure { Log.w(TAG, "baca db cookies gagal", it) }
            .getOrDefault(emptyList())
        if (lines.isEmpty()) lines = fromCookieManager(cm, urls)
        if (lines.isEmpty()) throw IllegalStateException("Belum ada cookies. Masuk ke akunmu dulu di halaman tadi.")
        write(ctx, lines)
        return lines.size
    }

    private fun write(ctx: Context, lines: List<String>) {
        file(ctx).writeText(HEADER + lines.joinToString("\n") + "\n")
    }

    private fun line(domain: String, path: String, secure: Boolean, expiry: Long, name: String, value: String): String {
        val sub = if (domain.startsWith(".")) "TRUE" else "FALSE"
        return listOf(domain, sub, path.ifEmpty { "/" }, if (secure) "TRUE" else "FALSE", expiry.toString(), name, value)
            .joinToString("\t")
    }

    /** Cookie WebView (Chromium) disimpan di app_webview/Default/Cookies, tidak dienkripsi di Android. */
    private fun fromWebViewDb(ctx: Context): List<String> {
        val db = File(ctx.dataDir, "app_webview/Default/Cookies")
        if (!db.isFile) return emptyList()
        val now = System.currentTimeMillis() / 1000
        val far = now + 365L * 24 * 3600
        val out = ArrayList<String>()
        SQLiteDatabase.openDatabase(db.absolutePath, null, SQLiteDatabase.OPEN_READONLY).use { d ->
            d.query("cookies", arrayOf("host_key", "expires_utc", "path", "name", "value", "is_secure"),
                null, null, null, null, null).use { c ->
                while (c.moveToNext()) {
                    val name = c.getString(3) ?: continue
                    val value = c.getString(4) ?: ""
                    if (name.isEmpty()) continue
                    if (ClaudeSlots.isClaudeDomain(c.getString(0) ?: continue)) continue // sesi Claude hanya untuk slot akun
                    val raw = c.getLong(1)
                    val exp = if (raw <= 0L) far else raw / 1_000_000L - CHROMIUM_EPOCH
                    if (exp in 1..now) continue // sudah kedaluwarsa
                    out += line(c.getString(0) ?: continue, c.getString(2) ?: "/", c.getInt(5) == 1, exp, name, value)
                }
            }
        }
        return out
    }

    /** Cadangan kalau database di atas tidak terbaca: hanya name=value per situs. */
    private fun fromCookieManager(cm: CookieManager, urls: List<String>): List<String> {
        val far = System.currentTimeMillis() / 1000 + 365L * 24 * 3600
        val out = LinkedHashSet<String>()
        for (u in urls) {
            val host = runCatching { Uri.parse(u).host }.getOrNull() ?: continue
            val domain = "." + host.split('.').takeLast(2).joinToString(".")
            if (ClaudeSlots.isClaudeDomain(domain)) continue
            val raw = cm.getCookie(u) ?: continue
            for (kv in raw.split(';')) {
                val i = kv.indexOf('=')
                if (i <= 0) continue
                out += line(domain, "/", true, far, kv.substring(0, i).trim(), kv.substring(i + 1).trim())
            }
        }
        return out.toList()
    }
}

/** Potong cover jadi persegi (dipakai bersama --embed-thumbnail untuk MP3/M4A). Sama dengan yang dipakai SnapNet. */
object DlConfig {
    const val CROP_ARTWORK = """--ppa "ffmpeg: -c:v mjpeg -vf crop=\"'if(gt(ih,iw),iw,ih)':'if(gt(iw,ih),ih,iw)'\"""""
}
