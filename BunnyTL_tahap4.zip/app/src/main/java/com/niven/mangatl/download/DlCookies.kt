package com.niven.mangatl

import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.net.Uri
import android.util.Log
import android.webkit.CookieManager
import com.yausername.youtubedl_android.YoutubeDLRequest
import java.io.File

/** Situs yang bisa dibuka langsung ke halaman login. [key] = domain utama. */
class LoginSite(val label: String, val key: String, val loginUrl: String)

/**
 * Cookies untuk video yang butuh login (anti-bot YouTube, batas umur, khusus member).
 * Disimpan sebagai cookies.txt format Netscape di data app; yt-dlp membacanya lewat --cookies.
 */
object DlCookies {
    private const val TAG = "DlCookies"
    private const val HEADER = "# Netscape HTTP Cookie File\n# Dibuat oleh BunnyTL\n\n"
    private const val CHROMIUM_EPOCH = 11_644_473_600L // detik antara 1601 dan 1970

    /**
     * Dua jalur akun untuk situs unduhan. Jalur A = profil WebView Default + cookies.txt (persis seperti sebelumnya).
     * Jalur B = profil WebView terpisah [LANE_B_PROFILE] + cookies_b.txt, untuk akun kedua di situs yang sama.
     * Tiap unduhan memakai SATU file sesuai jalur yang dipilih untuk situs itu (lihat [DlPrefs.siteLane]).
     */
    const val LANE_A = "a"
    const val LANE_B = "b"
    const val LANE_B_PROFILE = "bunny_s1"

    /** Profil WebView untuk [lane] (null = Default). */
    fun profileOf(lane: String): String? = if (lane == LANE_B) LANE_B_PROFILE else null

    /** Jalur dari profil WebView. */
    private fun laneOfProfile(profile: String?) = if (profile == LANE_B_PROFILE) LANE_B else LANE_A

    /** true = unduhan dari [url] memakai Jalur B (dan Jalur B didukung HP ini), jadi login-nya juga harus di Jalur B. */
    fun laneBFor(ctx: Context, url: String?): Boolean {
        val key = siteFor(url)?.key ?: return false
        return DlPrefs.siteLane(ctx, key) == LANE_B && ClaudeSlots.multiProfile()
    }

    val SITES = listOf(
        LoginSite("YouTube", "youtube.com", "https://accounts.google.com/ServiceLogin?service=youtube&continue=https%3A%2F%2Fwww.youtube.com%2F"),
        LoginSite("Instagram", "instagram.com", "https://www.instagram.com/accounts/login/"),
        LoginSite("TikTok", "tiktok.com", "https://www.tiktok.com/login"),
        LoginSite("Facebook", "facebook.com", "https://www.facebook.com/login"),
        LoginSite("X", "x.com", "https://x.com/i/flow/login"),
        LoginSite("Threads", "threads.com", "https://www.threads.com/login"),
        LoginSite("Reddit", "reddit.com", "https://www.reddit.com/login/"),
        LoginSite("Pinterest", "pinterest.com", "https://www.pinterest.com/login/"),
        LoginSite("Snapchat", "snapchat.com", "https://accounts.snapchat.com/accounts/login")
    )

    private fun byKey(key: String) = SITES.first { it.key == key }

    /** Situs bawaan + situs buatan pengguna. */
    fun allSites(): List<LoginSite> = SITES + CustomSites.cached

    /** Situs dari sebuah link (null kalau bukan salah satu di daftar). */
    fun siteFor(url: String?): LoginSite? {
        val host = runCatching { url?.let { Uri.parse(it).host } }.getOrNull()?.lowercase() ?: return null
        SITES.firstOrNull { host == it.key || host.endsWith("." + it.key) }?.let { return it }
        CustomSites.cached.firstOrNull { host == it.key || host.endsWith("." + it.key) }?.let { return it }
        return when {
            host.endsWith("youtu.be") -> SITES[0]
            host.endsWith("twitter.com") -> SITES[4]
            host.endsWith("fb.watch") -> SITES[3]
            host.endsWith("threads.net") -> byKey("threads.com")
            host.endsWith("redd.it") -> byKey("reddit.com")
            host.endsWith("pin.it") -> byKey("pinterest.com")
            else -> null
        }
    }

    /** Halaman login yang dituju: situs dari link, kalau tak ada situs terakhir yang dipakai, kalau tak ada YouTube. */
    fun loginUrlFor(ctx: Context, url: String?): String =
        (siteFor(url) ?: allSites().firstOrNull { it.key == DlPrefs.lastLogin(ctx) } ?: SITES[0]).loginUrl

    fun file(ctx: Context) = file(ctx, LANE_A)

    fun file(ctx: Context, lane: String) = File(ctx.filesDir, if (lane == LANE_B) "cookies_b.txt" else "cookies.txt")

    /** Jumlah cookies kedua jalur. */
    fun count(ctx: Context): Int = count(ctx, LANE_A) + count(ctx, LANE_B)

    fun count(ctx: Context, lane: String): Int {
        val f = file(ctx, lane)
        if (!f.isFile) return 0
        return runCatching { f.readLines().count { it.isNotBlank() && !it.startsWith("#") && it.split('\t').size >= 7 } }
            .getOrDefault(0)
    }

    fun has(ctx: Context) = count(ctx) > 0

    fun enabled(ctx: Context) = DlPrefs.useCookies(ctx) && has(ctx)

    /** Domain tiap cookie di file (tanpa titik di depan), mis. instagram.com, www.youtube.com. */
    private fun cookieDomains(f: File): Set<String> {
        if (!f.isFile) return emptySet()
        return runCatching {
            f.readLines().asSequence()
                .map { it.removePrefix("#HttpOnly_") }
                .filter { it.isNotBlank() && !it.startsWith("#") }
                .mapNotNull { it.split('\t').firstOrNull()?.trim()?.trimStart('.')?.lowercase() }
                .filter { it.isNotEmpty() }
                .toSet()
        }.getOrDefault(emptySet())
    }

    /** Nama lain dari satu situs, supaya link pendek/alias tetap cocok dengan cookies-nya. */
    private fun aliases(host: String): List<String> {
        val extra = when {
            host.endsWith("youtu.be") -> listOf("youtube.com", "google.com")
            host.endsWith("youtube.com") -> listOf("google.com")
            host.endsWith("fb.watch") || host.endsWith("fb.com") -> listOf("facebook.com")
            host.endsWith("instagr.am") -> listOf("instagram.com")
            host.endsWith("twitter.com") -> listOf("x.com")
            host.endsWith("x.com") -> listOf("twitter.com")
            host.endsWith("threads.net") -> listOf("threads.com", "instagram.com")
            host.endsWith("threads.com") -> listOf("threads.net", "instagram.com")
            host.endsWith("redd.it") -> listOf("reddit.com")
            host.endsWith("pin.it") -> listOf("pinterest.com")
            else -> emptyList()
        }
        return listOf(host) + extra
    }

    /**
     * Apakah cookies dipakai untuk link ini? Hanya kalau file cookies punya cookie untuk situs link tersebut.
     * Penting: cookies Instagram TIDAK boleh ikut ke Facebook/YouTube dll. Cookies + User-Agent WebView
     * yang dipaksakan ke situs lain bisa membuat situs itu menyajikan halaman berbeda (mis. Facebook jadi
     * hanya menampilkan audio, tanpa pilihan video).
     */
    fun appliesTo(ctx: Context, url: String?): Boolean = pickFile(ctx, url) != null

    private fun matches(f: File, host: String): Boolean {
        val domains = cookieDomains(f)
        return aliases(host).any { h -> domains.any { d -> h == d || h.endsWith(".$d") || d.endsWith(".$h") } }
    }

    /**
     * File cookies untuk link [url]: kalau Jalur B dipilih untuk situs itu dan file B punya cookies situs tersebut, pakai B;
     * selain itu Jalur A (perilaku lama). Jalur A tidak pernah jatuh ke B secara diam-diam.
     */
    private fun pickFile(ctx: Context, url: String?): File? {
        if (!DlPrefs.useCookies(ctx) || url.isNullOrBlank()) return null
        val host = runCatching { Uri.parse(url).host }.getOrNull()?.lowercase() ?: return null
        // 1) slot akun aktif situs ini (popup pilih akun) -- hanya cookies situs itu.
        //    Situs yang punya slot TIDAK jatuh ke cookies.txt lama: slot dihapus / habis / belum dipilih = tanpa akun
        //    (yt-dlp lalu minta login), bukan diam-diam memakai akun lama.
        siteFor(url)?.let { st ->
            val store = SiteSlots.of(st)
            store.prepare(ctx)
            return store.exportActive(ctx)?.takeIf { matches(it, host) }
        }
        // 2) situs di luar daftar: cara lama, cookies.txt Jalur A / B
        if (!has(ctx)) return null
        val wantB = laneBFor(ctx, url)
        if (wantB) file(ctx, LANE_B).takeIf { matches(it, host) }?.let { return it }
        return file(ctx, LANE_A).takeIf { matches(it, host) }
    }

    /** Tambahkan opsi cookies ke perintah yt-dlp, hanya bila dipakai untuk situs [url] ini. */
    fun apply(ctx: Context, req: YoutubeDLRequest, url: String?) {
        val f = pickFile(ctx, url) ?: return
        req.addOption("--cookies", f.absolutePath)
        val ua = DlPrefs.userAgent(ctx)
        if (ua.isNotEmpty()) req.addOption("--add-header", "User-Agent:$ua")
    }

    // ---------------------------------------------------------------- hapus per situs

    class CookieGroup(val key: String, val label: String, val count: Int)

    private const val OTHER = "_lainnya"

    /** Domain yang dihitung milik satu situs (login YouTube lewat google.com, X = twitter.com, dst). */
    internal fun siteDomains(key: String): List<String> = when (key) {
        "youtube.com" -> listOf("youtube.com", "google.com", "youtu.be", "googlevideo.com")
        "facebook.com" -> listOf("facebook.com", "fb.com")
        "x.com" -> listOf("x.com", "twitter.com")
        "threads.com" -> listOf("threads.com", "threads.net")
        "reddit.com" -> listOf("reddit.com", "redd.it")
        "pinterest.com" -> listOf("pinterest.com", "pin.it")
        else -> listOf(key)
    }

    private fun groupOf(domain: String): String {
        val d = domain.removePrefix("#HttpOnly_").trimStart('.').lowercase()
        return allSites().firstOrNull { s -> siteDomains(s.key).any { g -> d == g || d.endsWith(".$g") } }?.key ?: OTHER
    }

    private fun dataLines(ctx: Context, lane: String): List<List<String>> {
        val f = file(ctx, lane)
        if (!f.isFile) return emptyList()
        return runCatching {
            f.readLines().filter { it.isNotBlank() && !it.startsWith("#") }.map { it.split('\t') }.filter { it.size >= 7 }
        }.getOrDefault(emptyList())
    }

    /** Cookies yang tersimpan, dikelompokkan per situs (hanya situs yang punya cookies). */
    fun groups(ctx: Context, lane: String = LANE_A): List<CookieGroup> {
        val counts = LinkedHashMap<String, Int>()
        dataLines(ctx, lane).forEach { val k = groupOf(it[0]); counts[k] = (counts[k] ?: 0) + 1 }
        val out = allSites().filter { counts.containsKey(it.key) }.map { CookieGroup(it.key, it.label, counts[it.key]!!) }.toMutableList()
        counts[OTHER]?.let { out += CookieGroup(OTHER, "Lainnya", it) }
        return out
    }

    /** Hapus cookies hanya untuk situs [keys] (dari file cookies.txt DAN dari WebView). Situs lain tidak disentuh. */
    fun clearGroups(ctx: Context, keys: Set<String>, lane: String = LANE_A) {
        val keep = ArrayList<String>()
        val gone = ArrayList<List<String>>()
        for (p in dataLines(ctx, lane)) {
            if (groupOf(p[0]) in keys) gone += p else keep += p.joinToString("\t")
        }
        if (keep.isEmpty()) file(ctx, lane).delete() else write(ctx, keep, lane)
        runCatching {
            val cm = ClaudeSlots.cookieManager(profileOf(lane))
            val old = "Thu, 01 Jan 1970 00:00:00 GMT"
            for (p in gone) {
                val dom = p[0]
                cm.setCookie(
                    "https://" + dom.trimStart('.'),
                    "${p[5]}=; Expires=$old; Max-Age=0; Path=${p[2].ifEmpty { "/" }}" + (if (dom.startsWith(".")) "; Domain=$dom" else "")
                )
            }
            cm.flush()
        }
        if (lane == LANE_B) WebKeeper.dropProfile(LANE_B_PROFILE) else WebKeeper.drop()
    }

    /** Cookies lama situs [siteKey] di file [lane], sebagai cookie slot (dipakai [SiteSlots.prepare] untuk memindahkan login lama ke slot). */
    fun legacyCookies(ctx: Context, siteKey: String, lane: String): List<ClaudeCookie> =
        dataLines(ctx, lane).filter { groupOf(it[0]) == siteKey }.map {
            ClaudeCookie(
                domain = it[0], path = it[2].ifEmpty { "/" }, secure = it[3].equals("TRUE", true), httpOnly = false,
                expiry = it[4].toLongOrNull() ?: 0L, name = it[5], value = it[6]
            )
        }

    /** Jumlah cookies situs [siteKey] di file [lane] (0 = belum login di jalur itu). */
    fun laneCount(ctx: Context, siteKey: String, lane: String): Int =
        dataLines(ctx, lane).count { groupOf(it[0]) == siteKey }

    fun clear(ctx: Context) {
        file(ctx).delete()
        runCatching {
            CookieManager.getInstance().removeAllCookies(null)
            CookieManager.getInstance().flush()
        }
        WebKeeper.drop()
    }

    /** Hasil impor: [cookies] = jumlah baris cookie, [slots] = jumlah akun situs yang masuk ke slot baru. */
    class ImportResult(val cookies: Int, val slots: Int)

    /** Jumlah slot akun terisi di semua situs (dipakai saklar cookies dan judul popup login). */
    fun filledSlots(ctx: Context): Int = allSites().sumOf { st ->
        val s = SiteSlots.of(st)
        (0 until s.count(ctx)).count { s.get(ctx, it)?.filled == true }
    }

    /**
     * Cookies hasil impor juga dimasukkan ke slot: per situs, ke slot kosong pertama (Jalur A dulu, lalu B), lalu jadi aktif.
     * Situs yang tidak punya cookie sesi login, dan situs di luar daftar, dilewati (tetap ada di cookies.txt).
     */
    private fun intoSlots(ctx: Context, lines: List<String>): Int {
        val bySite = LinkedHashMap<String, MutableList<ClaudeCookie>>()
        for (f in lines.map { it.split('\t') }) {
            val key = groupOf(f[0])
            if (key == OTHER) continue
            bySite.getOrPut(key) { ArrayList() } += ClaudeCookie(
                domain = f[0], path = f[2].ifEmpty { "/" }, secure = f[3].equals("TRUE", true), httpOnly = false,
                expiry = f[4].toLongOrNull() ?: 0L, name = f[5], value = f[6]
            )
        }
        var n = 0
        for ((key, list) in bySite) {
            val site = allSites().firstOrNull { it.key == key } ?: continue
            val store = SiteSlots.of(site)
            if (!store.hasSession(list)) continue
            val free = (0 until SiteSlots.MAX_SLOTS).firstOrNull { store.get(ctx, it)?.filled != true } ?: continue
            val slot = store.get(ctx, free) ?: ClaudeSlot()
            slot.cookies = list
            slot.expired = false
            slot.dim = false
            slot.email = "Diimpor " + store.stamp().removePrefix("Disimpan ")
            if (store.put(ctx, free, slot)) { store.open(ctx, free); n++ }
        }
        return n
    }

    /** Impor cookies.txt dari berkas (mis. hasil ekstensi browser). */
    fun importFrom(ctx: Context, uri: Uri): ImportResult {
        val text = ctx.contentResolver.openInputStream(uri)?.use { it.readBytes().toString(Charsets.UTF_8) }
            ?: throw IllegalStateException("Berkas tidak bisa dibaca.")
        val lines = text.replace("\r\n", "\n").replace('\r', '\n').lines()
            .map { it.removePrefix("#HttpOnly_") }
            .filter { it.isNotBlank() && !it.startsWith("#") && it.split('\t').size >= 7 }
        if (lines.isEmpty()) throw IllegalStateException("Ini bukan cookies.txt format Netscape (tidak ada baris cookie).")
        // login lama dipindah ke slot dulu (sekali per situs), supaya tidak ikut tertimpa / terduplikasi oleh berkas impor
        allSites().forEach { SiteSlots.of(it).prepare(ctx) }
        write(ctx, lines)
        return ImportResult(lines.size, intoSlots(ctx, lines))
    }

    /** Ambil cookies yang tersimpan di WebView setelah pengguna login. Mengembalikan jumlah cookie. */
    fun exportFromWebView(ctx: Context, urls: List<String>, profile: String? = null): Int {
        val lane = laneOfProfile(profile)
        val cm = ClaudeSlots.cookieManager(profile)
        cm.flush()
        var lines = runCatching { fromWebViewDb(ctx, profile) }.onFailure { Log.w(TAG, "baca db cookies gagal", it) }
            .getOrDefault(emptyList())
        if (lines.isEmpty()) lines = fromCookieManager(cm, urls)
        if (lines.isEmpty()) throw IllegalStateException("Belum ada cookies. Masuk ke akunmu dulu di halaman tadi.")
        write(ctx, lines, lane)
        return lines.size
    }

    private fun write(ctx: Context, lines: List<String>, lane: String = LANE_A) {
        file(ctx, lane).writeText(HEADER + lines.joinToString("\n") + "\n")
    }

    private fun line(domain: String, path: String, secure: Boolean, expiry: Long, name: String, value: String): String {
        val sub = if (domain.startsWith(".")) "TRUE" else "FALSE"
        return listOf(domain, sub, path.ifEmpty { "/" }, if (secure) "TRUE" else "FALSE", expiry.toString(), name, value)
            .joinToString("\t")
    }

    /** Cookie WebView (Chromium) disimpan di app_webview/Default/Cookies, tidak dienkripsi di Android. */
    private fun fromWebViewDb(ctx: Context, profile: String?): List<String> {
        val db = ClaudeSlots.cookieDb(ctx, profile) ?: return emptyList()
        val now = System.currentTimeMillis() / 1000
        val far = now + 365L * 24 * 3600
        val out = ArrayList<String>()
        SQLiteDatabase.openDatabase(db.absolutePath, null, SQLiteDatabase.OPEN_READONLY).use { d ->
            d.query("cookies", arrayOf("host_key", "expires_utc", "path", "name", "value", "is_secure"),
                null, null, null, null, null).use { c ->
                while (c.moveToNext()) {
                    val name = c.getString(3) ?: continue
                    val value = c.getString(4) ?: ""
                    if (name.isEmpty()) continue
                    if (ClaudeSlots.isClaudeDomain(c.getString(0) ?: continue)) continue // sesi Claude hanya untuk slot akun
                    val raw = c.getLong(1)
                    val exp = if (raw <= 0L) far else raw / 1_000_000L - CHROMIUM_EPOCH
                    if (exp in 1..now) continue // sudah kedaluwarsa
                    out += line(c.getString(0) ?: continue, c.getString(2) ?: "/", c.getInt(5) == 1, exp, name, value)
                }
            }
        }
        return out
    }

    /** Cadangan kalau database di atas tidak terbaca: hanya name=value per situs. */
    private fun fromCookieManager(cm: CookieManager, urls: List<String>): List<String> {
        val far = System.currentTimeMillis() / 1000 + 365L * 24 * 3600
        val out = LinkedHashSet<String>()
        for (u in urls) {
            val host = runCatching { Uri.parse(u).host }.getOrNull() ?: continue
            val domain = "." + host.split('.').takeLast(2).joinToString(".")
            if (ClaudeSlots.isClaudeDomain(domain)) continue
            val raw = cm.getCookie(u) ?: continue
            for (kv in raw.split(';')) {
                val i = kv.indexOf('=')
                if (i <= 0) continue
                out += line(domain, "/", true, far, kv.substring(0, i).trim(), kv.substring(i + 1).trim())
            }
        }
        return out.toList()
    }
}

/** Potong cover jadi persegi (dipakai bersama --embed-thumbnail untuk MP3/M4A). Sama dengan yang dipakai SnapNet. */
object DlConfig {
    const val CROP_ARTWORK = """--ppa "ffmpeg: -c:v mjpeg -vf crop=\"'if(gt(ih,iw),iw,ih)':'if(gt(iw,ih),ih,iw)'\"""""
}
