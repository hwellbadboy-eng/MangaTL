package com.niven.mangatl

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.Color
import android.util.AttributeSet
import android.view.MotionEvent
import android.webkit.JavascriptInterface
import android.webkit.WebView
import android.webkit.WebViewClient

/**
 * Logo kelinci beranimasi (WebGL, assets/bunny/bunny_logo.html). Latar transparan.
 *
 * - [setActive]: false = animasi biasa (idle, mesin AI mati), true = animasi aktif (mesin AI hidup).
 *   Perpindahan mati -> hidup memicu kilatan "bangun" sekali; [silent] = tanpa kilatan (state awal).
 * - [aura]: kilatan + animasi aktif sesaat, dipakai bubble browser saat ditekan lama / di-tap.
 *
 * Catatan: jangan pakai pauseTimers()/resumeTimers() — itu global untuk SEMUA WebView di aplikasi dan
 * membekukan logo di layar lain (bug logo tidak muncul saat pertama masuk). Cukup onPause()/onResume() per-instance.
 *
 * View ini tidak menangkap sentuhan: semua sentuhan diteruskan ke parent, jadi klik / geser / tekan lama
 * ditangani oleh view yang membungkusnya.
 */
class BunnyLogoView @JvmOverloads constructor(context: Context, attrs: AttributeSet? = null) : WebView(context, attrs) {

    /** Resolusi kanvas (px). Logo kecil tidak butuh besar; makin kecil makin ringan buat GPU. */
    var resolution = 320

    /** Perbesar isi logo (1 = apa adanya). Kelinci hanya ~65% dari kanvas, jadi 1.3 membuatnya hampir penuh. */
    var zoom = 1f

    private var ready = false
    private var active = false
    private var firstPush = true
    private var pendingAura = 0
    private var paused = false

    private inner class Bridge {
        @JavascriptInterface fun ready() { post { onPageReady() } }
    }

    @SuppressLint("SetJavaScriptEnabled")
    fun setup() {
        setBackgroundColor(Color.TRANSPARENT)
        overScrollMode = OVER_SCROLL_NEVER
        isVerticalScrollBarEnabled = false
        isHorizontalScrollBarEnabled = false
        isHapticFeedbackEnabled = false
        isFocusable = false
        isClickable = false
        setLayerType(LAYER_TYPE_HARDWARE, null)
        settings.javaScriptEnabled = true
        settings.allowFileAccess = true
        addJavascriptInterface(Bridge(), "Android")
        webViewClient = object : WebViewClient() {}
        onResume()
        loadUrl("file:///android_asset/bunny/bunny_logo.html?r=$resolution&z=$zoom")
    }

    private fun onPageReady() {
        ready = true
        push(silent = true)
        if (pendingAura > 0) { aura(pendingAura); pendingAura = 0 }
    }

    private fun push(silent: Boolean) {
        evaluateJavascript("window.setActive&&window.setActive($active,$silent)", null)
    }

    /** Ikuti status mesin AI. Panggilan pertama selalu tanpa kilatan. */
    fun setActive(on: Boolean) {
        if (active == on && !firstPush) return
        val silent = firstPush
        firstPush = false
        active = on
        if (ready) push(silent)
    }

    /** Kilatan + animasi aktif sesaat (ms), lalu kembali ke state mesin. */
    fun aura(ms: Int = 1700) {
        if (!ready) { pendingAura = ms; return }
        evaluateJavascript("window.aura&&window.aura($ms)", null)
    }

    /** Panggil dari onResume / onPause activity supaya animasi berhenti saat layar tidak terlihat. */
    fun resumeLogo() { if (paused) { paused = false; onResume() } }
    fun pauseLogo() { if (!paused) { paused = true; onPause() } }

    fun release() {
        stopLoading()
        removeJavascriptInterface("Android")
        destroy()
    }

    // Sentuhan diteruskan ke parent.
    override fun dispatchTouchEvent(ev: MotionEvent): Boolean = false
    override fun performClick(): Boolean = false
}
