package com.niven.mangatl

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView

/**
 * Layar pemilih teks yang diabaikan: tangkapan layar yang dibekukan + kotak-kotak teks hasil OCR.
 * Ketuk kotak untuk menandainya (merah = diabaikan), ketuk lagi untuk memulihkan.
 * Hanya muncul saat dibuka dari menu tekan-lama tombol TL, jadi tidak ada ketukan nyasar saat main.
 */
class PickIgnoreView(
    ctx: Context,
    private val bmp: Bitmap,
    private val groups: List<Grouping.Group>,
    initial: BooleanArray,
    /** (hasil, kosongkan semua). hasil = null kalau dibatalkan. */
    private val onResult: (BooleanArray?, Boolean) -> Unit
) : FrameLayout(ctx) {

    private val state: BooleanArray = initial.copyOf()
    private var clearAll = false
    private val density = resources.displayMetrics.density
    private val banner = TextView(ctx)
    private val boxes = Boxes(ctx)

    private fun dp(v: Int): Int = (v * density).toInt()

    private fun button(label: String, action: () -> Unit): Button {
        val b = Button(context)
        b.text = label
        b.isAllCaps = false
        b.setTextColor(Color.WHITE)
        b.textSize = 14f
        val bg = GradientDrawable()
        bg.setColor(0xFF3A3A3E.toInt())
        bg.cornerRadius = dp(12).toFloat()
        b.background = bg
        b.setOnClickListener { action() }
        return b
    }

    init {
        addView(boxes, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))

        banner.text = "Ketuk kotak teks yang TIDAK mau diterjemahkan (jadi merah). Ketuk lagi untuk memulihkan."
        banner.setTextColor(Color.WHITE)
        banner.textSize = 13f
        banner.setPadding(dp(14), dp(10), dp(14), dp(10))
        val bb = GradientDrawable()
        bb.setColor(0xEE2B2930.toInt())
        bb.cornerRadius = dp(12).toFloat()
        banner.background = bb
        val bl = FrameLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.TOP
        )
        bl.setMargins(dp(16), dp(28), dp(16), 0)
        addView(banner, bl)

        val row = LinearLayout(context)
        row.orientation = LinearLayout.HORIZONTAL
        val cell = { LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).also { it.setMargins(dp(4), 0, dp(4), 0) } }
        row.addView(button("Batal") { onResult(null, false) }, cell())
        row.addView(button("Kosongkan daftar") {
            for (i in state.indices) state[i] = false
            clearAll = true
            banner.text = "Daftar dikosongkan. Ketuk Selesai untuk menyimpan, atau pilih kotak lagi."
            boxes.invalidate()
        }, cell())
        row.addView(button("Selesai") { onResult(state, clearAll) }, cell())
        val rl = FrameLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.BOTTOM
        )
        rl.setMargins(dp(12), 0, dp(12), dp(24))
        addView(row, rl)
    }

    private inner class Boxes(c: Context) : View(c) {
        private val fill = Paint(Paint.ANTI_ALIAS_FLAG)
        private val stroke = Paint(Paint.ANTI_ALIAS_FLAG)
        private val dst = RectF()

        init {
            stroke.style = Paint.Style.STROKE
            stroke.strokeWidth = 2f * density
        }

        override fun onDraw(canvas: Canvas) {
            dst.set(0f, 0f, width.toFloat(), height.toFloat())
            canvas.drawBitmap(bmp, null, dst, null)
            canvas.drawColor(0x55000000)
            val sx = width.toFloat() / bmp.width
            val sy = height.toFloat() / bmp.height
            for (i in groups.indices) {
                val g = groups[i]
                val r = RectF(g.rect.left * sx, g.rect.top * sy, g.rect.right * sx, g.rect.bottom * sy)
                if (state[i]) {
                    fill.color = 0x66FF4444
                    canvas.drawRect(r, fill)
                    stroke.color = 0xFFFF5555.toInt()
                } else {
                    stroke.color = 0xFF33CCFF.toInt()
                }
                canvas.drawRect(r, stroke)
            }
        }

        override fun onTouchEvent(e: MotionEvent): Boolean {
            if (e.action == MotionEvent.ACTION_DOWN) return true
            if (e.action == MotionEvent.ACTION_UP) {
                val sx = width.toFloat() / bmp.width
                val sy = height.toFloat() / bmp.height
                val slop = 6f * density
                var best = -1
                var bestArea = Float.MAX_VALUE
                for (i in groups.indices) {
                    val g = groups[i]
                    val l = g.rect.left * sx - slop
                    val t = g.rect.top * sy - slop
                    val r = g.rect.right * sx + slop
                    val b = g.rect.bottom * sy + slop
                    if (e.x >= l && e.x <= r && e.y >= t && e.y <= b) {
                        val area = (r - l) * (b - t)
                        if (area < bestArea) {
                            bestArea = area
                            best = i
                        }
                    }
                }
                if (best >= 0) {
                    state[best] = !state[best]
                    invalidate()
                }
                performClick()
                return true
            }
            return super.onTouchEvent(e)
        }

        override fun performClick(): Boolean = super.performClick()
    }
}
