package com.niven.mangatl

import android.annotation.SuppressLint
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.Editable
import android.text.TextWatcher
import android.view.MotionEvent
import android.view.View
import android.view.ViewOutlineProvider
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.widget.CheckBox
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.core.content.ContextCompat
import androidx.core.view.ViewCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.media3.ui.PlayerView
import androidx.lifecycle.lifecycleScope
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.Player
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import com.google.common.util.concurrent.ListenableFuture
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlin.math.abs
import kotlin.math.max
import kotlin.random.Random

/**
 * Layar Musik (desain "Versi 3"): daftar melengkung dengan cari cepat di tepi, tab teks, mini player
 * dengan garis seek di atas. Tab (Lagu/Album/Artis/Folder/Playlist) bisa disembunyikan & diurutkan ulang
 * lewat pengaturan. Tombol urutkan: nama, tanggal, durasi (naik/turun).
 */
class MusicActivity : MediaActivity() {

    override val kind = 1
    override fun deniedView(): TextView = tvEmpty

    /** kind: 0 biasa, 1 favorit, 2 playlist */
    private class Drill(val title: String, var tracks: List<Library.Track>, val kind: Int, val playlist: String?)

    private lateinit var wheel: MusicWheelView
    private lateinit var etSearch: EditText
    private lateinit var searchRow: View
    private lateinit var tvTitle: TextView
    private lateinit var tvBannerLabel: TextView
    private lateinit var topButtons: View
    private lateinit var bgGlow: View
    private lateinit var bannerLayer: View
    private lateinit var fade: View
    private lateinit var tabScroll: View
    private lateinit var tabsBox: LinearLayout
    private lateinit var tvEmpty: TextView
    private lateinit var drillBar: View
    private lateinit var tvDrill: TextView
    private lateinit var mini: View
    private lateinit var swipeInner: View
    private lateinit var tvNow: TextView
    private lateinit var tvArtist: TextView
    private lateinit var ivMini: ImageView
    private lateinit var btnMiniPlay: ImageButton
    private lateinit var seek: SeekLine
    private lateinit var timeRow: View
    private lateinit var tvElapsed: TextView
    private lateinit var tvTotal: TextView
    private lateinit var settingsPop: View
    private lateinit var popScrim: View
    private lateinit var swVideo: PillSwitch
    private lateinit var swCurve: PillSwitch
    private lateinit var swSide: PillSwitch
    private lateinit var backCb: OnBackPressedCallback
    private lateinit var banner: Banner
    private var statusTop = 0
    private var navBottom = 0
    private var onBannerChange: (() -> Unit)? = null
    private var searchOpen = false
    private var popOpen = false
    private var tabIndex = 0

    private val pickBanner = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            Toast.makeText(this, "Menyalin banner...", Toast.LENGTH_SHORT).show()
            updateBannerAspect()
            banner.importFile(uri) { err ->
                if (err != null) Toast.makeText(this, err, Toast.LENGTH_LONG).show()
                applyBanner()
                onBannerChange?.invoke()
                if (banner.has() && err?.startsWith("Maju") != false) positionDialog()
            }
        }
    }

    private var tracks: List<Library.Track> = emptyList()
    private var albums: List<Library.Group> = emptyList()
    private var artists: List<Library.Group> = emptyList()
    private var folders: List<Library.Group> = emptyList()
    private val byId = HashMap<Long, Library.Track>()
    private var drill: Drill? = null
    private var loaded = false
    private var visibleIds: List<Int> = listOf(0)
    private var sortMode = 0

    private var future: ListenableFuture<MediaController>? = null
    private var controller: MediaController? = null
    private val handler = Handler(Looper.getMainLooper())
    private val tick = object : Runnable {
        override fun run() {
            updateProgress()
            handler.postDelayed(this, 500)
        }
    }

    private val pickLyricsFolder = registerForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri ->
        if (uri != null) {
            try {
                contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
            } catch (e: Exception) {
            }
            Prefs.setStr(this, "lyrics_tree", uri.toString())
            Lyrics.resetIndex()
            Toast.makeText(this, "Folder lirik dipilih.", Toast.LENGTH_SHORT).show()
        }
    }

    private fun curTab(): Int = visibleIds.getOrElse(tabIndex) { 0 }

    @SuppressLint("ClickableViewAccessibility")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        window.statusBarColor = android.graphics.Color.TRANSPARENT
        setContentView(R.layout.activity_music)
        Fx.enter(this)

        bannerLayer = findViewById(R.id.bannerLayer)
        // video/foto yang diperbesar tidak boleh bocor ke bawah batas banner
        bannerLayer.outlineProvider = ViewOutlineProvider.BOUNDS
        bannerLayer.clipToOutline = true
        banner = Banner(
            this,
            findViewById<PlayerView>(R.id.bnVideo),
            findViewById<ImageView>(R.id.bnImage),
            bannerLayer
        )

        wheel = findViewById(R.id.wheel)
        etSearch = findViewById(R.id.etSearch)
        searchRow = findViewById(R.id.searchRow)
        tvTitle = findViewById(R.id.tvMusicTitle)
        tvBannerLabel = findViewById(R.id.tvBannerLabel)
        topButtons = findViewById(R.id.topButtons)
        bgGlow = findViewById(R.id.bgGlow)
        fade = findViewById(R.id.fade)
        tabScroll = findViewById(R.id.tabScroll)
        tabsBox = findViewById(R.id.tabsBox)
        tvEmpty = findViewById(R.id.tvEmpty)
        drillBar = findViewById(R.id.drillBar)
        tvDrill = findViewById(R.id.tvDrill)
        mini = findViewById(R.id.mini)
        swipeInner = findViewById(R.id.swipeInner)
        tvNow = findViewById(R.id.tvNow)
        tvArtist = findViewById(R.id.tvArtist)
        ivMini = findViewById(R.id.ivMini)
        btnMiniPlay = findViewById(R.id.btnMiniPlay)
        seek = findViewById(R.id.seek)
        timeRow = findViewById(R.id.timeRow)
        tvElapsed = findViewById(R.id.tvElapsed)
        tvTotal = findViewById(R.id.tvTotal)
        settingsPop = findViewById(R.id.settingsPop)
        popScrim = findViewById(R.id.popScrim)
        swVideo = findViewById(R.id.swVideo)
        swCurve = findViewById(R.id.swCurve)
        swSide = findViewById(R.id.swSide)
        sortMode = Prefs.int(this, "sort_music", 0)

        // huruf desain
        tvTitle.typeface = MusicFonts.face(this, 800)
        tvBannerLabel.typeface = MusicFonts.face(this, 600)
        etSearch.typeface = MusicFonts.face(this, 600)
        tvNow.typeface = MusicFonts.face(this, 700)
        tvArtist.typeface = MusicFonts.face(this, 400)
        tvDrill.typeface = MusicFonts.face(this, 700)

        // daftar melengkung
        wheel.scope = lifecycleScope
        wheel.onRowClick = { r -> r.onClick() }
        wheel.onRowLong = { r ->
            val lg = r.onLong
            if (lg != null) {
                lg()
                true
            } else {
                false
            }
        }

        // popup pengaturan cepat (3 saklar desain + jalan ke pengaturan lengkap)
        swVideo.setCheckedNow(Prefs.bool(this, "music_video_bg", true))
        swCurve.setCheckedNow(Prefs.bool(this, "music_curve", true))
        swSide.setCheckedNow(Prefs.bool(this, "music_qs_right", true))
        wheel.setCurved(swCurve.checked, false)
        wheel.setQsRight(swSide.checked)
        findViewById<View>(R.id.rowVideo).setOnClickListener {
            val on = !swVideo.checked
            swVideo.checked = on
            Prefs.setBool(this, "music_video_bg", on)
            applyBanner()
        }
        findViewById<View>(R.id.rowCurve).setOnClickListener {
            val on = !swCurve.checked
            swCurve.checked = on
            Prefs.setBool(this, "music_curve", on)
            wheel.setCurved(on, true)
        }
        findViewById<View>(R.id.rowSide).setOnClickListener {
            val on = !swSide.checked
            swSide.checked = on
            Prefs.setBool(this, "music_qs_right", on)
            wheel.setQsRight(on)
        }
        findViewById<View>(R.id.tvMoreSettings).setOnClickListener {
            setPop(false)
            settingsDialog()
        }
        popScrim.setOnClickListener { setPop(false) }

        rebuildTabs()

        etSearch.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun afterTextChanged(s: Editable?) = refresh()
        })
        etSearch.setOnEditorActionListener { _, actionId, _ ->
            if (actionId == EditorInfo.IME_ACTION_SEARCH) {
                hideKeyboard()
                true
            } else {
                false
            }
        }

        backCb = object : OnBackPressedCallback(false) {
            override fun handleOnBackPressed() {
                if (popOpen) {
                    setPop(false)
                } else {
                    drill = null
                    refresh()
                }
            }
        }
        onBackPressedDispatcher.addCallback(this, backCb)

        findViewById<View>(R.id.ibSearch).setOnClickListener { toggleSearch() }
        findViewById<View>(R.id.ibSearchClose).setOnClickListener { toggleSearch() }
        findViewById<View>(R.id.ibSort).setOnClickListener {
            setPop(false)
            Ui.sortDialog(this, Ui.SORT_MUSIC, sortMode) {
                sortMode = it
                Prefs.setInt(this, "sort_music", it)
                refresh()
            }
        }
        findViewById<View>(R.id.ibSettings).setOnClickListener { setPop(!popOpen) }

        findViewById<View>(R.id.btnPlayAll).setOnClickListener {
            drill?.let { d -> if (d.tracks.isNotEmpty()) playQueue(sortedTracks(d.tracks), 0, false) }
        }
        findViewById<View>(R.id.btnShufAll).setOnClickListener {
            drill?.let { d ->
                if (d.tracks.isNotEmpty()) playQueue(d.tracks, Random.nextInt(d.tracks.size), true)
            }
        }

        // mini player
        btnMiniPlay.setOnClickListener {
            controller?.let { if (it.isPlaying) it.pause() else it.play() }
        }
        findViewById<View>(R.id.btnMiniNext).setOnClickListener { controller?.seekToNextMediaItem() }
        findViewById<View>(R.id.btnMiniPrev).setOnClickListener { controller?.seekToPreviousMediaItem() }
        setupSwipe()
        setupSeek()

        // dipasang paling akhir: pemanggilan pertamanya memakai semua view di atas
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.musicRoot)) { _, ins ->
            statusTop = ins.getInsets(WindowInsetsCompat.Type.systemBars()).top
            navBottom = ins.getInsets(
                WindowInsetsCompat.Type.systemBars() or WindowInsetsCompat.Type.ime()
            ).bottom
            applyInsets()
            WindowInsetsCompat.CONSUMED
        }

        ensureMedia()
    }

    /** Geser baris judul di mini player: kiri = berikutnya, kanan = sebelumnya, ketuk / geser atas = buka pemutar. */
    @SuppressLint("ClickableViewAccessibility")
    private fun setupSwipe() {
        val area = findViewById<View>(R.id.swipeArea)
        val density = resources.displayMetrics.density
        var sx = 0f
        var sy = 0f
        var moved = false
        var up = false
        var active = false
        area.setOnTouchListener { _, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    sx = e.rawX
                    sy = e.rawY
                    moved = false
                    up = false
                    active = true
                    swipeInner.animate().cancel()
                }

                MotionEvent.ACTION_MOVE -> if (active) {
                    val dx = e.rawX - sx
                    val dy = e.rawY - sy
                    if (abs(dx) > 8f * density || abs(dy) > 8f * density) moved = true
                    if (dy < -40f * density && abs(dx) < 40f * density) up = true
                    swipeInner.translationX = dx
                    swipeInner.alpha = max(0.2f, 1f - abs(dx) / (140f * density))
                }

                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> if (active) {
                    active = false
                    val dx = e.rawX - sx
                    swipeInner.animate().translationX(0f).alpha(1f).setDuration(250L).start()
                    if (e.actionMasked == MotionEvent.ACTION_UP) {
                        if (up || !moved) {
                            startActivity(Intent(this, NowPlayingActivity::class.java))
                        } else if (dx < -60f * density) {
                            controller?.seekToNextMediaItem()
                        } else if (dx > 60f * density) {
                            controller?.seekToPreviousMediaItem()
                        }
                    }
                }
            }
            true
        }
    }

    /** Garis seek mini player: waktu muncul saat disentuh, posisi dikirim saat jari diangkat. */
    private fun setupSeek() {
        seek.onDragStart = {
            timeRow.animate().alpha(1f).setDuration(200L).start()
        }
        seek.onDrag = { p ->
            val dur = (controller?.duration ?: 0L).coerceAtLeast(0L)
            tvElapsed.text = Library.fmt((p * dur).toLong())
            tvTotal.text = Library.fmt(dur)
        }
        seek.onDragEnd = { p, ok ->
            timeRow.animate().alpha(0f).setDuration(200L).start()
            val c = controller
            if (ok && c != null && c.duration > 0) c.seekTo((p * c.duration).toLong())
        }
    }

    // ---------- tata letak & popup ----------

    /** Posisi yang ikut status bar (atas) dan bar navigasi / keyboard (bawah). */
    private fun applyInsets() {
        fun top(v: View, dpv: Int) {
            (v.layoutParams as FrameLayout.LayoutParams).topMargin = Ui.dp(this, dpv) + statusTop
        }
        top(tvBannerLabel, 26)
        top(topButtons, 14)
        top(settingsPop, 62)
        (mini.layoutParams as FrameLayout.LayoutParams).bottomMargin = navBottom
        (fade.layoutParams as FrameLayout.LayoutParams).height = Ui.dp(this, 96) + navBottom
        findViewById<View>(R.id.musicRoot).requestLayout()
        applyHeaderLayout()
    }

    private fun imm() = getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager

    private fun hideKeyboard() {
        imm().hideSoftInputFromWindow(etSearch.windowToken, 0)
    }

    private fun toggleSearch() {
        searchOpen = !searchOpen
        setPop(false)
        etSearch.setText("")
        searchRow.visibility = if (searchOpen) View.VISIBLE else View.GONE
        tvTitle.visibility = if (searchOpen) View.INVISIBLE else View.VISIBLE
        if (searchOpen) {
            etSearch.requestFocus()
            imm().showSoftInput(etSearch, InputMethodManager.SHOW_IMPLICIT)
        } else {
            hideKeyboard()
            etSearch.clearFocus()
        }
    }

    private fun setPop(open: Boolean) {
        popOpen = open
        settingsPop.visibility = if (open) View.VISIBLE else View.GONE
        popScrim.visibility = if (open) View.VISIBLE else View.GONE
        updateBack()
    }

    private fun updateBack() {
        if (::backCb.isInitialized) backCb.isEnabled = drill != null || popOpen
    }

    // ---------- banner ----------

    private fun bannerHeightPx() = Ui.dp(this, 440)

    private fun videoOn() = Prefs.bool(this, "music_video_bg", true)

    private fun updateBannerAspect() {
        banner.aspect = bannerHeightPx().toFloat() / resources.displayMetrics.widthPixels
    }

    /** Teks kecil di kiri atas, mengikuti banner yang dipakai. */
    private fun bannerLabel(): String {
        val kind = when (banner.type()) {
            "video" -> "VIDEO KUSTOM"
            "gif" -> "GIF KUSTOM"
            "photo" -> "FOTO KUSTOM"
            else -> "BANNER KUSTOM"
        }
        val mode = when {
            banner.type() == "photo" -> ""
            banner.mode() == Banner.MODE_PINGPONG -> " / MAJU-MUNDUR"
            else -> " / LOOP"
        }
        return kind + mode
    }

    /** Banner tampil kalau ada dan "Video latar" aktif; kalau belum ada banner, tampil cahaya abu pengganti. */
    private fun applyHeaderLayout() {
        updateBannerAspect()
        val has = banner.has()
        val show = has && videoOn()
        bannerLayer.visibility = if (show) View.VISIBLE else View.GONE
        bgGlow.visibility = if (!has && videoOn()) View.VISIBLE else View.GONE
        tvBannerLabel.visibility = View.GONE
    }

    /** Pasang ulang tampilan header lalu putar banner (kalau ada). */
    private fun applyBanner() {
        applyHeaderLayout()
        if (banner.has() && videoOn()) banner.start() else banner.stop()
    }

    private fun positionDialog() {
        updateBannerAspect()
        lifecycleScope.launch {
            val bmp = withContext(Dispatchers.IO) { banner.preview() }
            if (bmp == null) {
                Toast.makeText(this@MusicActivity, "Pratinjau banner tidak bisa dibuka.", Toast.LENGTH_SHORT).show()
                return@launch
            }
            val v = BannerPosView(this@MusicActivity).apply {
                this.bmp = bmp
                aspect = 1f / banner.aspect
                fx = banner.fx()
                fy = banner.fy()
                layoutParams = LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT, Ui.dp(this@MusicActivity, 280)
                )
            }
            val box = Ui.box(this@MusicActivity)
            val tip = TextView(this@MusicActivity).apply {
                text = if (v.canMove()) "Geser kotak terang untuk memilih bagian yang tampil di banner."
                else "Gambar ini sudah pas dengan banner, tidak ada bagian yang terpotong."
                textSize = 13f
                alpha = 0.8f
                setPadding(0, 0, 0, Ui.dp(this@MusicActivity, 10))
            }
            box.addView(tip)
            box.addView(v)
            AlertDialog.Builder(this@MusicActivity)
                .setTitle("Atur posisi banner")
                .setView(box)
                .setPositiveButton("Simpan") { _, _ ->
                    banner.setFocus((v.fx * 100).toInt(), (v.fy * 100).toInt()) { err ->
                        if (err != null) Toast.makeText(this@MusicActivity, err, Toast.LENGTH_LONG).show()
                        applyBanner()
                        onBannerChange?.invoke()
                    }
                }
                .setNegativeButton("Batal", null)
                .show()
        }
    }

    override fun onStart() {
        super.onStart()
        applyBanner()
        val token = SessionToken(this, ComponentName(this, PlayerService::class.java))
        val f = MediaController.Builder(this, token).buildAsync()
        future = f
        f.addListener({
            try {
                val c = f.get()
                controller = c
                c.addListener(object : Player.Listener {
                    override fun onEvents(player: Player, events: Player.Events) = updateMini()
                })
                updateMini()
                handler.post(tick)
            } catch (e: Exception) {
                Toast.makeText(this, "Pemutar gagal tersambung: ${e.message}", Toast.LENGTH_LONG).show()
            }
        }, ContextCompat.getMainExecutor(this))
    }

    override fun onStop() {
        banner.stop()
        handler.removeCallbacks(tick)
        future?.let { MediaController.releaseFuture(it) }
        future = null
        controller = null
        super.onStop()
    }

    // ---------- tab ----------

    private fun rebuildTabs() {
        visibleIds = Prefs.visibleTabs(this)
        tabIndex = 0
        tabsBox.removeAllViews()
        visibleIds.forEachIndexed { i, id ->
            val t = TabText(this)
            t.text = Prefs.TAB_NAMES[id]
            t.setOnClickListener { selectTab(i) }
            val lp = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT, Ui.dp(this, 36)
            )
            lp.marginEnd = Ui.dp(this, 8)
            tabsBox.addView(t, lp)
        }
        styleTabs()
        drill = null
    }

    private fun selectTab(i: Int) {
        tabIndex = i
        styleTabs()
        drill = null
        refresh()
    }

    private fun styleTabs() {
        for (i in 0 until tabsBox.childCount) {
            (tabsBox.getChildAt(i) as TabText).sel = i == tabIndex
        }
    }

    private fun settingsDialog() {
        val order = Prefs.tabOrder(this).toMutableList()
        val hidden = Prefs.tabHidden(this).toMutableSet()
        val root = Ui.box(this)

        fun render() {
            root.removeAllViews()
            root.addView(Ui.section(this, "Banner (foto / GIF / video)"))
            if (banner.has()) {
                root.addView(TextView(this).apply {
                    text = "${(banner.type() ?: "").uppercase()} · ${banner.name() ?: ""}"
                    textSize = 14f
                    maxLines = 2
                    ellipsize = android.text.TextUtils.TruncateAt.END
                })
                val change = com.google.android.material.button.MaterialButton(this)
                change.text = "Ganti file"
                change.setOnClickListener { pickBanner.launch(arrayOf("video/*", "image/*")) }
                root.addView(change)
                val pos = com.google.android.material.button.MaterialButton(this)
                pos.text = "Atur posisi"
                pos.setOnClickListener { positionDialog() }
                root.addView(pos)
                val del = com.google.android.material.button.MaterialButton(this)
                del.text = "Hapus banner"
                del.setOnClickListener {
                    banner.remove()
                    applyBanner()
                    render()
                }
                root.addView(del)
                if (banner.type() != "photo") {
                    root.addView(Ui.section(this, "Mode putar banner"))
                    root.addView(Ui.radios(this, listOf("Loop", "Maju-mundur"), banner.mode()) { m ->
                        if (m == Banner.MODE_PINGPONG) {
                            Toast.makeText(this, "Menyiapkan maju-mundur...", Toast.LENGTH_SHORT).show()
                        }
                        updateBannerAspect()
                        banner.setMode(m) { err ->
                            if (err != null) Toast.makeText(this, err, Toast.LENGTH_LONG).show()
                            applyBanner()
                            render()
                        }
                    })
                }
            } else {
                val pick = com.google.android.material.button.MaterialButton(this)
                pick.text = "Pilih banner"
                pick.setOnClickListener { pickBanner.launch(arrayOf("video/*", "image/*")) }
                root.addView(pick)
            }
            root.addView(Ui.section(this, "Tab yang ditampilkan (urutan bisa digeser)"))
            order.forEachIndexed { i, id ->
                val row = LinearLayout(this)
                row.orientation = LinearLayout.HORIZONTAL
                row.gravity = android.view.Gravity.CENTER_VERTICAL
                val cb = CheckBox(this)
                cb.text = Prefs.TAB_NAMES[id]
                cb.isChecked = id !in hidden
                cb.layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
                cb.setOnCheckedChangeListener { _, on ->
                    if (on) hidden.remove(id) else {
                        if (order.count { it !in hidden } <= 1) {
                            cb.isChecked = true
                            Toast.makeText(this, "Minimal satu tab harus tampil.", Toast.LENGTH_SHORT).show()
                        } else hidden.add(id)
                    }
                }
                row.addView(cb)
                val up = Ui.iconBtn(this, R.drawable.ic_up, "Naik") {
                    if (i > 0) { order.add(i - 1, order.removeAt(i)); render() }
                }
                val down = Ui.iconBtn(this, R.drawable.ic_down, "Turun") {
                    if (i < order.size - 1) { order.add(i + 1, order.removeAt(i)); render() }
                }
                up.layoutParams = LinearLayout.LayoutParams(Ui.dp(this, 44), Ui.dp(this, 44))
                down.layoutParams = LinearLayout.LayoutParams(Ui.dp(this, 44), Ui.dp(this, 44))
                up.alpha = if (i == 0) 0.25f else 1f
                down.alpha = if (i == order.size - 1) 0.25f else 1f
                row.addView(up)
                row.addView(down)
                root.addView(row)
            }
            root.addView(Ui.section(this, "Lirik"))
            root.addView(Ui.switchRow(this, "Cari lirik online otomatis (butuh internet)", Prefs.lyricsOnline(this)) {
                Prefs.setBool(this, "lyrics_online", it)
            })
            val tree = Prefs.str(this, "lyrics_tree")
            val b = com.google.android.material.button.MaterialButton(this)
            b.text = if (tree == null) "Pilih folder file lirik (.lrc)" else "Ganti folder file lirik (.lrc)"
            b.setOnClickListener { pickLyricsFolder.launch(null) }
            root.addView(b)
            if (tree != null) {
                val clear = com.google.android.material.button.MaterialButton(this)
                clear.text = "Lepas folder lirik"
                clear.setOnClickListener {
                    Prefs.setStr(this, "lyrics_tree", null)
                    Lyrics.resetIndex()
                    render()
                }
                root.addView(clear)
            }
        }
        onBannerChange = { render() }
        render()

        AlertDialog.Builder(this)
            .setOnDismissListener { onBannerChange = null }
            .setTitle("Pengaturan musik")
            .setView(Ui.scroll(root))
            .setPositiveButton("Simpan") { _, _ ->
                Prefs.saveTabs(this, order, hidden)
                rebuildTabs()
                refresh()
            }
            .setNegativeButton("Batal", null)
            .show()
    }

    // ---------- data ----------

    override fun onMediaReady() {
        tvEmpty.text = "Memuat..."
        tvEmpty.visibility = View.VISIBLE
        val first = !loaded
        lifecycleScope.launch {
            val t = withContext(Dispatchers.IO) { Library.audios(this@MusicActivity) }
            tracks = t
            byId.clear()
            t.forEach { byId[it.id] = it }
            drill?.let { d -> d.tracks = d.tracks.mapNotNull { byId[it.id] } }
            albums = Library.albums(t)
            artists = Library.artists(t)
            folders = Library.folders(t)
            loaded = true
            refresh(!first)
            updateMini()
        }
    }

    private fun match(t: Library.Track, q: String) =
        q.isEmpty() || t.title.lowercase().contains(q) ||
            t.artist.lowercase().contains(q) || t.album.lowercase().contains(q)

    private fun sortedTracks(l: List<Library.Track>) =
        Ui.sortBy(l, sortMode, { it.title }, { it.dateAdded }, { it.durationMs })

    private fun sortedGroups(l: List<Library.Group>) =
        Ui.sortBy(l, sortMode, { it.title }, { it.date }, { it.big })

    private fun refresh(keep: Boolean = false) {
        if (!loaded) return
        val q = etSearch.text.toString().trim().lowercase()
        val d = drill
        val out = ArrayList<Row>()
        if (d != null) {
            drillBar.visibility = View.VISIBLE
            tabScroll.visibility = View.GONE
            tvDrill.text = d.title
            out.addAll(trackRows(sortedTracks(d.tracks.filter { match(it, q) }), d))
        } else {
            drillBar.visibility = View.GONE
            tabScroll.visibility = View.VISIBLE
            when (curTab()) {
                0 -> out.addAll(trackRows(sortedTracks(tracks.filter { match(it, q) }), null))
                1 -> out.addAll(groupRows(albums, q, R.drawable.ic_album))
                2 -> out.addAll(groupRows(artists, q, R.drawable.ic_person))
                3 -> out.addAll(groupRows(folders, q, R.drawable.ic_folder))
                else -> out.addAll(playlistRows())
            }
        }
        updateBack()
        wheel.setRows(out, keep)
        tvEmpty.text = "Tidak ada hasil"
        tvEmpty.visibility = if (out.isEmpty()) View.VISIBLE else View.GONE
    }

    private var shownIds: List<Long> = emptyList()

    private fun trackRows(shown: List<Library.Track>, d: Drill?): List<Row> {
        shownIds = shown.map { it.id }
        return shown.mapIndexed { i, t ->
            Row(
                title = t.title,
                sub = t.artist,
                icon = R.drawable.ic_music_note,
                thumb = t.uri,
                selected = picked.contains(t.id),
                key = t.id,
                onLong = { if (selecting) toggleSelect(t.id) else trackMenu(t, d) },
                onClick = { if (selecting) toggleSelect(t.id) else playQueue(shown, i, false) }
            )
        }
    }

    private fun moveTracks(ids: List<Long>) {
        val uris = tracks.filter { it.id in ids }.map { it.uri }
        if (uris.isEmpty()) return
        moveMany(
            uris, "", tracks.map { it.rel }.filter { it.isNotEmpty() },
            listOf("Music/", "Alarms/", "Notifications/", "Podcasts/", "Ringtones/", "Audiobooks/", "Recordings/"),
            "Music/", "Pindahkan ${uris.size} lagu ke"
        ) {
            exitSelect()
            onMediaReady()
        }
    }

    private fun confirmDeleteTracks(ids: List<Long>) {
        val list = tracks.filter { it.id in ids }
        if (list.isEmpty()) return
        Sheet.confirm(
            this, "Hapus ${list.size} lagu permanen?",
            "Lagu akan dihapus dari HP dan tidak bisa dikembalikan.", "Hapus", true
        ) {
            deleteMedia(list.map { it.uri }) { ok ->
                if (ok) {
                    Toast.makeText(this, "Lagu dihapus.", Toast.LENGTH_SHORT).show()
                    exitSelect()
                    onMediaReady()
                }
            }
        }
    }

    private fun covers(l: List<Library.Track>): List<Uri> =
        l.distinctBy { it.albumId }.take(4).map { it.uri }

    private fun groupRows(groups: List<Library.Group>, q: String, icon: Int): List<Row> =
        sortedGroups(
            groups.filter { q.isEmpty() || it.title.lowercase().contains(q) || it.sub.lowercase().contains(q) }
        ).map { g ->
            Row(
                title = g.title,
                sub = g.sub,
                icon = icon,
                thumb = g.tracks.firstOrNull()?.uri,
                thumbs = if (icon == R.drawable.ic_album) emptyList() else covers(g.tracks),
                onClick = {
                    drill = Drill(g.title, g.tracks, 0, null)
                    refresh()
                }
            )
        }

    private fun favTracks(): List<Library.Track> {
        val f = MusicStore.favs(this)
        return tracks.filter { it.id in f }
    }

    private fun playlistTracks(name: String): List<Library.Track> =
        (MusicStore.playlists(this)[name] ?: emptyList<Long>()).mapNotNull { byId[it] }

    private fun playlistRows(): List<Row> {
        val rows = ArrayList<Row>()
        val fav = favTracks()
        rows.add(
            Row(
                title = "Favorit", sub = "${fav.size} lagu", icon = R.drawable.ic_fav,
                thumbs = covers(fav), thumb = fav.firstOrNull()?.uri,
                onClick = {
                    drill = Drill("Favorit", favTracks(), 1, null)
                    refresh()
                }
            )
        )
        for (name in MusicStore.playlists(this).keys.toList()) {
            val l = playlistTracks(name)
            rows.add(
                Row(
                    title = name, sub = "${l.size} lagu", icon = R.drawable.ic_playlist,
                    thumbs = covers(l), thumb = l.firstOrNull()?.uri,
                    onLong = { confirmDeletePlaylist(name) },
                    onClick = {
                        drill = Drill(name, playlistTracks(name), 2, name)
                        refresh()
                    }
                )
            )
        }
        rows.add(
            Row(
                title = "Buat playlist baru", sub = "", icon = R.drawable.ic_add,
                onClick = { createPlaylistDialog(null) }
            )
        )
        return rows
    }

    private fun reloadDrill() {
        val d = drill ?: return
        d.tracks = when (d.kind) {
            1 -> favTracks()
            2 -> playlistTracks(d.playlist ?: "")
            else -> d.tracks
        }
    }

    // ---------- menu tahan-lama ----------

    private fun trackMenu(t: Library.Track, d: Drill?) {
        val items = ArrayList<Sheet.Item?>()
        items.add(Sheet.Item("Pilih", R.drawable.ic_check) {
            startSelect(
                t.id, { shownIds }, { refresh(true) },
                { ids -> moveTracks(ids) }, { ids -> confirmDeleteTracks(ids) }
            )
        })
        items.add(null)
        items.add(Sheet.Item("Putar berikutnya", R.drawable.ic_next) { playNext(t) })
        items.add(Sheet.Item("Tambah ke antrean", R.drawable.ic_queue) { addToQueue(t) })
        if (MusicStore.isFav(this, t.id)) {
            items.add(Sheet.Item("Hapus dari favorit", R.drawable.ic_fav) {
                MusicStore.toggleFav(this, t.id); reloadDrill(); refresh(true)
            })
        } else {
            items.add(Sheet.Item("Tambah ke favorit", R.drawable.ic_fav_border) {
                MusicStore.toggleFav(this, t.id); reloadDrill(); refresh(true)
            })
        }
        items.add(Sheet.Item("Tambah ke playlist", R.drawable.ic_playlist) { pickPlaylist(t) })
        if (d != null && d.kind == 2 && d.playlist != null) {
            items.add(Sheet.Item("Hapus dari playlist", R.drawable.ic_playlist) {
                MusicStore.removeFrom(this, d.playlist, t.id)
                reloadDrill()
                refresh(true)
            })
        }
        items.add(null)
        items.add(Sheet.Item("Ganti nama", R.drawable.ic_edit) {
            renameDialog(t.uri, t.fileBase, t.ext, "lagu") { onMediaReady() }
        })
        items.add(Sheet.Item("Edit info", R.drawable.ic_music_note) { editInfo(t) })
        items.add(Sheet.Item("Pindahkan ke folder", R.drawable.ic_move) { moveTrack(t) })
        items.add(null)
        items.add(Sheet.Item("Hapus dari HP", R.drawable.ic_trash, true) { confirmDeleteTrack(t) })
        Sheet.menu(this, t.title, t.artist, items)
    }

    private fun editInfo(t: Library.Track) {
        val artist = if (t.artist == "Tidak diketahui") "" else t.artist
        Sheet.form(
            this, "Edit info lagu", null,
            listOf("Judul" to t.title, "Artis" to artist, "Album" to t.album), "Simpan"
        ) { f ->
            val v = android.content.ContentValues()
            v.put(android.provider.MediaStore.Audio.Media.TITLE, f[0].trim().ifEmpty { t.title })
            v.put(android.provider.MediaStore.Audio.Media.ARTIST, f[1].trim())
            v.put(android.provider.MediaStore.Audio.Media.ALBUM, f[2].trim())
            updateMedia(t.uri, v) { ok ->
                if (ok) {
                    Toast.makeText(this, "Info lagu disimpan.", Toast.LENGTH_SHORT).show()
                    onMediaReady()
                }
            }
        }
    }

    private fun moveTrack(t: Library.Track) {
        moveDialog(
            t.uri, t.rel, tracks.map { it.rel }.filter { it.isNotEmpty() },
            listOf("Music/", "Alarms/", "Notifications/", "Podcasts/", "Ringtones/", "Audiobooks/", "Recordings/"),
            "Music/"
        ) { onMediaReady() }
    }

    private fun confirmDeleteTrack(t: Library.Track) {
        Sheet.confirm(
            this, "Hapus lagu permanen?",
            "\"${t.title}\" akan dihapus dari HP dan tidak bisa dikembalikan.", "Hapus", true
        ) {
            deleteMedia(listOf(t.uri)) { ok ->
                if (ok) {
                    drill?.let { d -> d.tracks = d.tracks.filter { it.id != t.id } }
                    Toast.makeText(this, "Lagu dihapus.", Toast.LENGTH_SHORT).show()
                    onMediaReady()
                }
            }
        }
    }

    private fun pickPlaylist(t: Library.Track) {
        val names = MusicStore.playlists(this).keys.toList()
        val items = ArrayList<Sheet.Item?>()
        for (n in names) {
            items.add(Sheet.Item(n, R.drawable.ic_playlist) {
                MusicStore.addTo(this, n, t.id)
                Toast.makeText(this, "Ditambahkan ke $n", Toast.LENGTH_SHORT).show()
                refresh(true)
            })
        }
        if (names.isNotEmpty()) items.add(null)
        items.add(Sheet.Item("Playlist baru", R.drawable.ic_add) { createPlaylistDialog(t) })
        Sheet.menu(this, "Tambah ke playlist", null, items)
    }

    private fun createPlaylistDialog(add: Library.Track?) {
        Sheet.input(this, "Playlist baru", "Nama playlist", "", "Buat") { raw ->
            val n = raw.trim()
            if (n.isNotEmpty()) {
                MusicStore.create(this, n)
                if (add != null) MusicStore.addTo(this, n, add.id)
                refresh(true)
            }
        }
    }

    private fun confirmDeletePlaylist(name: String) {
        Sheet.confirm(this, "Hapus playlist \"$name\"?", "Lagu di dalamnya tidak ikut terhapus dari HP.", "Hapus", true) {
            MusicStore.delete(this, name)
            refresh(true)
        }
    }

    // ---------- putar ----------

    private fun item(t: Library.Track): MediaItem {
        val art = Uri.parse("content://media/external/audio/albumart/${t.albumId}")
        return MediaItem.Builder()
            .setMediaId(t.id.toString())
            .setUri(t.uri)
            .setMediaMetadata(
                MediaMetadata.Builder()
                    .setTitle(t.title)
                    .setArtist(t.artist)
                    .setAlbumTitle(t.album)
                    .setArtworkUri(art)
                    .build()
            )
            .build()
    }

    private fun playQueue(queue: List<Library.Track>, index: Int, shuffle: Boolean) {
        val c = controller ?: run {
            Toast.makeText(this, "Pemutar belum siap, coba lagi.", Toast.LENGTH_SHORT).show()
            return
        }
        queue.getOrNull(index)?.let { wheel.setPlayingKey(it.id, true) }
        c.shuffleModeEnabled = shuffle
        c.setMediaItems(queue.map { item(it) }, index, 0L)
        c.prepare()
        c.play()
    }

    private fun playNext(t: Library.Track) {
        val c = controller ?: return
        if (c.mediaItemCount == 0) {
            playQueue(listOf(t), 0, false)
        } else {
            c.addMediaItem(c.currentMediaItemIndex + 1, item(t))
            Toast.makeText(this, "Diputar berikutnya", Toast.LENGTH_SHORT).show()
        }
    }

    private fun addToQueue(t: Library.Track) {
        val c = controller ?: return
        if (c.mediaItemCount == 0) {
            playQueue(listOf(t), 0, false)
        } else {
            c.addMediaItem(item(t))
            Toast.makeText(this, "Masuk antrean", Toast.LENGTH_SHORT).show()
        }
    }

    // ---------- mini player ----------

    private fun updateMini() {
        val c = controller ?: return
        mini.visibility = if (c.mediaItemCount > 0) View.VISIBLE else View.GONE
        tvNow.text = c.mediaMetadata.title ?: "—"
        tvArtist.text = c.mediaMetadata.artist ?: ""
        btnMiniPlay.setImageResource(if (c.isPlaying) R.drawable.ic_dm_pause else R.drawable.ic_dm_play)
        val id = c.currentMediaItem?.mediaId?.toLongOrNull()
        Thumbs.load(lifecycleScope, ivMini, id?.let { byId[it]?.uri }, 128, false)
        wheel.setPlayingKey(id ?: -1L, false)
        updateProgress()
    }

    private fun updateProgress() {
        val c = controller ?: return
        if (seek.dragging) return
        val dur = c.duration
        seek.progress = if (dur > 0) c.currentPosition.coerceIn(0, dur).toFloat() / dur else 0f
    }
}
