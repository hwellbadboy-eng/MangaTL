package com.niven.mangatl

import android.content.ComponentName
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.Editable
import android.text.TextWatcher
import android.view.View
import android.widget.CheckBox
import android.widget.EditText
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.Player
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.tabs.TabLayout
import com.google.common.util.concurrent.ListenableFuture
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlin.random.Random

/**
 * Layar Musik. Tab (Lagu/Album/Artis/Folder/Playlist) bisa disembunyikan & diurutkan ulang lewat
 * tombol pengaturan di layar ini. Tombol urutkan: nama, tanggal, durasi (naik/turun).
 */
class MusicActivity : MediaActivity() {

    override val kind = 1
    override fun deniedView(): TextView = tvEmpty

    /** kind: 0 biasa, 1 favorit, 2 playlist */
    private class Drill(val title: String, var tracks: List<Library.Track>, val kind: Int, val playlist: String?)

    private lateinit var adapter: RowAdapter
    private lateinit var etSearch: EditText
    private lateinit var tabs: TabLayout
    private lateinit var tvEmpty: TextView
    private lateinit var drillBar: View
    private lateinit var tvDrill: TextView
    private lateinit var mini: View
    private lateinit var tvNow: TextView
    private lateinit var tvArtist: TextView
    private lateinit var ivMini: ImageView
    private lateinit var pbMini: ProgressBar
    private lateinit var btnMiniPlay: ImageButton
    private lateinit var backCb: OnBackPressedCallback

    private var tracks: List<Library.Track> = emptyList()
    private var albums: List<Library.Group> = emptyList()
    private var artists: List<Library.Group> = emptyList()
    private var folders: List<Library.Group> = emptyList()
    private val byId = HashMap<Long, Library.Track>()
    private var drill: Drill? = null
    private var loaded = false
    private var visibleIds: List<Int> = listOf(0)
    private var rebuilding = false
    private var sortMode = 0

    private var future: ListenableFuture<MediaController>? = null
    private var controller: MediaController? = null
    private val handler = Handler(Looper.getMainLooper())
    private val tick = object : Runnable {
        override fun run() {
            updateProgress()
            handler.postDelayed(this, 500)
        }
    }

    private val pickLyricsFolder = registerForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri ->
        if (uri != null) {
            try {
                contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
            } catch (e: Exception) {
            }
            Prefs.setStr(this, "lyrics_tree", uri.toString())
            Lyrics.resetIndex()
            Toast.makeText(this, "Folder lirik dipilih.", Toast.LENGTH_SHORT).show()
        }
    }

    private fun curTab(): Int = visibleIds.getOrElse(tabs.selectedTabPosition) { 0 }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_music)
        Fx.enter(this)

        etSearch = findViewById(R.id.etSearch)
        tabs = findViewById(R.id.tabs)
        tvEmpty = findViewById(R.id.tvEmpty)
        drillBar = findViewById(R.id.drillBar)
        tvDrill = findViewById(R.id.tvDrill)
        mini = findViewById(R.id.mini)
        tvNow = findViewById(R.id.tvNow)
        tvArtist = findViewById(R.id.tvArtist)
        ivMini = findViewById(R.id.ivMini)
        pbMini = findViewById(R.id.pbMini)
        btnMiniPlay = findViewById(R.id.btnMiniPlay)
        sortMode = Prefs.int(this, "sort_music", 0)

        adapter = RowAdapter(lifecycleScope)
        val list = findViewById<RecyclerView>(R.id.list)
        list.layoutManager = LinearLayoutManager(this)
        list.adapter = adapter

        tabs.addOnTabSelectedListener(object : TabLayout.OnTabSelectedListener {
            override fun onTabSelected(tab: TabLayout.Tab?) {
                if (rebuilding) return
                drill = null
                refresh()
            }

            override fun onTabUnselected(tab: TabLayout.Tab?) {}
            override fun onTabReselected(tab: TabLayout.Tab?) {
                drill = null
                refresh()
            }
        })
        rebuildTabs()

        etSearch.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun afterTextChanged(s: Editable?) = refresh()
        })

        backCb = object : OnBackPressedCallback(false) {
            override fun handleOnBackPressed() {
                drill = null
                refresh()
            }
        }
        onBackPressedDispatcher.addCallback(this, backCb)

        findViewById<View>(R.id.ibSort).setOnClickListener {
            Ui.sortDialog(this, Ui.SORT_MUSIC, sortMode) {
                sortMode = it
                Prefs.setInt(this, "sort_music", it)
                refresh()
            }
        }
        findViewById<View>(R.id.ibSettings).setOnClickListener { settingsDialog() }

        findViewById<View>(R.id.btnPlayAll).setOnClickListener {
            drill?.let { d -> if (d.tracks.isNotEmpty()) playQueue(sortedTracks(d.tracks), 0, false) }
        }
        findViewById<View>(R.id.btnShufAll).setOnClickListener {
            drill?.let { d ->
                if (d.tracks.isNotEmpty()) playQueue(d.tracks, Random.nextInt(d.tracks.size), true)
            }
        }

        findViewById<View>(R.id.miniRow).setOnClickListener {
            startActivity(Intent(this, NowPlayingActivity::class.java))
        }
        btnMiniPlay.setOnClickListener {
            controller?.let { if (it.isPlaying) it.pause() else it.play() }
        }
        findViewById<View>(R.id.btnMiniNext).setOnClickListener { controller?.seekToNextMediaItem() }

        ensureMedia()
    }

    override fun onStart() {
        super.onStart()
        val token = SessionToken(this, ComponentName(this, PlayerService::class.java))
        val f = MediaController.Builder(this, token).buildAsync()
        future = f
        f.addListener({
            try {
                val c = f.get()
                controller = c
                c.addListener(object : Player.Listener {
                    override fun onEvents(player: Player, events: Player.Events) = updateMini()
                })
                updateMini()
                handler.post(tick)
            } catch (e: Exception) {
                Toast.makeText(this, "Pemutar gagal tersambung: ${e.message}", Toast.LENGTH_LONG).show()
            }
        }, ContextCompat.getMainExecutor(this))
    }

    override fun onStop() {
        handler.removeCallbacks(tick)
        future?.let { MediaController.releaseFuture(it) }
        future = null
        controller = null
        super.onStop()
    }

    // ---------- tab ----------

    private fun rebuildTabs() {
        rebuilding = true
        tabs.removeAllTabs()
        visibleIds = Prefs.visibleTabs(this)
        for (id in visibleIds) tabs.addTab(tabs.newTab().setText(Prefs.TAB_NAMES[id]))
        rebuilding = false
        drill = null
    }

    private fun settingsDialog() {
        val order = Prefs.tabOrder(this).toMutableList()
        val hidden = Prefs.tabHidden(this).toMutableSet()
        val root = Ui.box(this)

        fun render() {
            root.removeAllViews()
            root.addView(Ui.section(this, "Tab yang ditampilkan (urutan bisa digeser)"))
            order.forEachIndexed { i, id ->
                val row = LinearLayout(this)
                row.orientation = LinearLayout.HORIZONTAL
                row.gravity = android.view.Gravity.CENTER_VERTICAL
                val cb = CheckBox(this)
                cb.text = Prefs.TAB_NAMES[id]
                cb.isChecked = id !in hidden
                cb.layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
                cb.setOnCheckedChangeListener { _, on ->
                    if (on) hidden.remove(id) else {
                        if (order.count { it !in hidden } <= 1) {
                            cb.isChecked = true
                            Toast.makeText(this, "Minimal satu tab harus tampil.", Toast.LENGTH_SHORT).show()
                        } else hidden.add(id)
                    }
                }
                row.addView(cb)
                val up = Ui.iconBtn(this, R.drawable.ic_up, "Naik") {
                    if (i > 0) { order.add(i - 1, order.removeAt(i)); render() }
                }
                val down = Ui.iconBtn(this, R.drawable.ic_down, "Turun") {
                    if (i < order.size - 1) { order.add(i + 1, order.removeAt(i)); render() }
                }
                up.layoutParams = LinearLayout.LayoutParams(Ui.dp(this, 44), Ui.dp(this, 44))
                down.layoutParams = LinearLayout.LayoutParams(Ui.dp(this, 44), Ui.dp(this, 44))
                up.alpha = if (i == 0) 0.25f else 1f
                down.alpha = if (i == order.size - 1) 0.25f else 1f
                row.addView(up)
                row.addView(down)
                root.addView(row)
            }
            root.addView(Ui.section(this, "Lirik"))
            root.addView(Ui.switchRow(this, "Cari lirik online otomatis (butuh internet)", Prefs.lyricsOnline(this)) {
                Prefs.setBool(this, "lyrics_online", it)
            })
            val tree = Prefs.str(this, "lyrics_tree")
            val b = com.google.android.material.button.MaterialButton(this)
            b.text = if (tree == null) "Pilih folder file lirik (.lrc)" else "Ganti folder file lirik (.lrc)"
            b.setOnClickListener { pickLyricsFolder.launch(null) }
            root.addView(b)
            if (tree != null) {
                val clear = com.google.android.material.button.MaterialButton(this)
                clear.text = "Lepas folder lirik"
                clear.setOnClickListener {
                    Prefs.setStr(this, "lyrics_tree", null)
                    Lyrics.resetIndex()
                    render()
                }
                root.addView(clear)
            }
        }
        render()

        AlertDialog.Builder(this)
            .setTitle("Pengaturan musik")
            .setView(Ui.scroll(root))
            .setPositiveButton("Simpan") { _, _ ->
                Prefs.saveTabs(this, order, hidden)
                rebuildTabs()
                refresh()
            }
            .setNegativeButton("Batal", null)
            .show()
    }

    // ---------- data ----------

    override fun onMediaReady() {
        tvEmpty.text = "Memuat..."
        tvEmpty.visibility = View.VISIBLE
        lifecycleScope.launch {
            val t = withContext(Dispatchers.IO) { Library.audios(this@MusicActivity) }
            tracks = t
            byId.clear()
            t.forEach { byId[it.id] = it }
            albums = Library.albums(t)
            artists = Library.artists(t)
            folders = Library.folders(t)
            loaded = true
            refresh()
            updateMini()
        }
    }

    private fun match(t: Library.Track, q: String) =
        q.isEmpty() || t.title.lowercase().contains(q) ||
            t.artist.lowercase().contains(q) || t.album.lowercase().contains(q)

    private fun sortedTracks(l: List<Library.Track>) =
        Ui.sortBy(l, sortMode, { it.title }, { it.dateAdded }, { it.durationMs })

    private fun sortedGroups(l: List<Library.Group>) =
        Ui.sortBy(l, sortMode, { it.title }, { it.date }, { it.big })

    private fun refresh() {
        if (!loaded) return
        val q = etSearch.text.toString().trim().lowercase()
        val d = drill
        val out = ArrayList<Row>()
        if (d != null) {
            drillBar.visibility = View.VISIBLE
            tvDrill.text = d.title
            out.addAll(trackRows(sortedTracks(d.tracks.filter { match(it, q) }), d))
        } else {
            drillBar.visibility = View.GONE
            when (curTab()) {
                0 -> out.addAll(trackRows(sortedTracks(tracks.filter { match(it, q) }), null))
                1 -> out.addAll(groupRows(albums, q, R.drawable.ic_album))
                2 -> out.addAll(groupRows(artists, q, R.drawable.ic_person))
                3 -> out.addAll(groupRows(folders, q, R.drawable.ic_folder))
                else -> out.addAll(playlistRows())
            }
        }
        backCb.isEnabled = d != null
        adapter.rows = out
        tvEmpty.text = "Tidak ada yang ditemukan."
        tvEmpty.visibility = if (out.isEmpty()) View.VISIBLE else View.GONE
    }

    private fun trackRows(shown: List<Library.Track>, d: Drill?): List<Row> =
        shown.mapIndexed { i, t ->
            Row(
                title = t.title,
                sub = "${t.artist}  •  ${Library.fmt(t.durationMs)}",
                icon = R.drawable.ic_music_note,
                thumb = t.uri,
                onLong = { trackMenu(t, d) },
                onClick = { playQueue(shown, i, false) }
            )
        }

    private fun covers(l: List<Library.Track>): List<Uri> =
        l.distinctBy { it.albumId }.take(4).map { it.uri }

    private fun groupRows(groups: List<Library.Group>, q: String, icon: Int): List<Row> =
        sortedGroups(
            groups.filter { q.isEmpty() || it.title.lowercase().contains(q) || it.sub.lowercase().contains(q) }
        ).map { g ->
            Row(
                title = g.title,
                sub = g.sub,
                icon = icon,
                thumb = g.tracks.firstOrNull()?.uri,
                thumbs = if (icon == R.drawable.ic_album) emptyList() else covers(g.tracks),
                onClick = {
                    drill = Drill(g.title, g.tracks, 0, null)
                    refresh()
                }
            )
        }

    private fun favTracks(): List<Library.Track> {
        val f = MusicStore.favs(this)
        return tracks.filter { it.id in f }
    }

    private fun playlistTracks(name: String): List<Library.Track> =
        (MusicStore.playlists(this)[name] ?: emptyList<Long>()).mapNotNull { byId[it] }

    private fun playlistRows(): List<Row> {
        val rows = ArrayList<Row>()
        val fav = favTracks()
        rows.add(
            Row(
                title = "Favorit", sub = "${fav.size} lagu", icon = R.drawable.ic_fav,
                thumbs = covers(fav), thumb = fav.firstOrNull()?.uri,
                onClick = {
                    drill = Drill("Favorit", favTracks(), 1, null)
                    refresh()
                }
            )
        )
        for (name in MusicStore.playlists(this).keys.toList()) {
            val l = playlistTracks(name)
            rows.add(
                Row(
                    title = name, sub = "${l.size} lagu", icon = R.drawable.ic_playlist,
                    thumbs = covers(l), thumb = l.firstOrNull()?.uri,
                    onLong = { confirmDeletePlaylist(name) },
                    onClick = {
                        drill = Drill(name, playlistTracks(name), 2, name)
                        refresh()
                    }
                )
            )
        }
        rows.add(
            Row(
                title = "Buat playlist baru", sub = "", icon = R.drawable.ic_add,
                onClick = { createPlaylistDialog(null) }
            )
        )
        return rows
    }

    private fun reloadDrill() {
        val d = drill ?: return
        d.tracks = when (d.kind) {
            1 -> favTracks()
            2 -> playlistTracks(d.playlist ?: "")
            else -> d.tracks
        }
    }

    // ---------- menu tahan-lama ----------

    private fun trackMenu(t: Library.Track, d: Drill?) {
        val labels = ArrayList<String>()
        val acts = ArrayList<() -> Unit>()
        fun add(l: String, a: () -> Unit) {
            labels.add(l)
            acts.add(a)
        }
        add("Putar berikutnya") { playNext(t) }
        add("Tambah ke antrean") { addToQueue(t) }
        if (MusicStore.isFav(this, t.id)) {
            add("Hapus dari favorit") { MusicStore.toggleFav(this, t.id); reloadDrill(); refresh() }
        } else {
            add("Tambah ke favorit") { MusicStore.toggleFav(this, t.id); reloadDrill(); refresh() }
        }
        add("Tambah ke playlist...") { pickPlaylist(t) }
        if (d != null && d.kind == 2 && d.playlist != null) {
            add("Hapus dari playlist") {
                MusicStore.removeFrom(this, d.playlist, t.id)
                reloadDrill()
                refresh()
            }
        }
        add("Hapus dari HP (permanen)...") { confirmDeleteTrack(t) }
        AlertDialog.Builder(this)
            .setTitle(t.title)
            .setItems(labels.toTypedArray()) { _, w -> acts[w]() }
            .show()
    }

    private fun confirmDeleteTrack(t: Library.Track) {
        AlertDialog.Builder(this)
            .setTitle("Hapus lagu permanen?")
            .setMessage("\"${t.title}\" akan dihapus dari HP dan tidak bisa dikembalikan.")
            .setPositiveButton("Hapus") { _, _ ->
                deleteMedia(listOf(t.uri)) { ok ->
                    if (ok) {
                        drill?.let { d -> d.tracks = d.tracks.filter { it.id != t.id } }
                        Toast.makeText(this, "Lagu dihapus.", Toast.LENGTH_SHORT).show()
                        onMediaReady()
                    }
                }
            }
            .setNegativeButton("Batal", null)
            .show()
    }

    private fun pickPlaylist(t: Library.Track) {
        val names = MusicStore.playlists(this).keys.toList()
        val items = names.toMutableList()
        items.add("+ Playlist baru")
        AlertDialog.Builder(this)
            .setTitle("Tambah ke playlist")
            .setItems(items.toTypedArray()) { _, w ->
                if (w < names.size) {
                    MusicStore.addTo(this, names[w], t.id)
                    Toast.makeText(this, "Ditambahkan ke ${names[w]}", Toast.LENGTH_SHORT).show()
                    refresh()
                } else createPlaylistDialog(t)
            }
            .show()
    }

    private fun createPlaylistDialog(add: Library.Track?) {
        val et = EditText(this)
        et.hint = "Nama playlist"
        AlertDialog.Builder(this)
            .setTitle("Playlist baru")
            .setView(et)
            .setPositiveButton("Buat") { _, _ ->
                val n = et.text.toString().trim()
                if (n.isNotEmpty()) {
                    MusicStore.create(this, n)
                    if (add != null) MusicStore.addTo(this, n, add.id)
                    refresh()
                }
            }
            .setNegativeButton("Batal", null)
            .show()
    }

    private fun confirmDeletePlaylist(name: String) {
        AlertDialog.Builder(this)
            .setTitle("Hapus playlist \"$name\"?")
            .setPositiveButton("Hapus") { _, _ ->
                MusicStore.delete(this, name)
                refresh()
            }
            .setNegativeButton("Batal", null)
            .show()
    }

    // ---------- putar ----------

    private fun item(t: Library.Track): MediaItem {
        val art = Uri.parse("content://media/external/audio/albumart/${t.albumId}")
        return MediaItem.Builder()
            .setMediaId(t.id.toString())
            .setUri(t.uri)
            .setMediaMetadata(
                MediaMetadata.Builder()
                    .setTitle(t.title)
                    .setArtist(t.artist)
                    .setAlbumTitle(t.album)
                    .setArtworkUri(art)
                    .build()
            )
            .build()
    }

    private fun playQueue(queue: List<Library.Track>, index: Int, shuffle: Boolean) {
        val c = controller ?: run {
            Toast.makeText(this, "Pemutar belum siap, coba lagi.", Toast.LENGTH_SHORT).show()
            return
        }
        c.shuffleModeEnabled = shuffle
        c.setMediaItems(queue.map { item(it) }, index, 0L)
        c.prepare()
        c.play()
    }

    private fun playNext(t: Library.Track) {
        val c = controller ?: return
        if (c.mediaItemCount == 0) {
            playQueue(listOf(t), 0, false)
        } else {
            c.addMediaItem(c.currentMediaItemIndex + 1, item(t))
            Toast.makeText(this, "Diputar berikutnya", Toast.LENGTH_SHORT).show()
        }
    }

    private fun addToQueue(t: Library.Track) {
        val c = controller ?: return
        if (c.mediaItemCount == 0) {
            playQueue(listOf(t), 0, false)
        } else {
            c.addMediaItem(item(t))
            Toast.makeText(this, "Masuk antrean", Toast.LENGTH_SHORT).show()
        }
    }

    // ---------- mini player ----------

    private fun updateMini() {
        val c = controller ?: return
        mini.visibility = if (c.mediaItemCount > 0) View.VISIBLE else View.GONE
        tvNow.text = c.mediaMetadata.title ?: "—"
        tvArtist.text = c.mediaMetadata.artist ?: ""
        btnMiniPlay.setImageResource(if (c.isPlaying) R.drawable.ic_pause else R.drawable.ic_play)
        val id = c.currentMediaItem?.mediaId?.toLongOrNull()
        Thumbs.load(lifecycleScope, ivMini, id?.let { byId[it]?.uri }, 128, false)
        updateProgress()
    }

    private fun updateProgress() {
        val c = controller ?: return
        val dur = c.duration
        pbMini.max = if (dur > 0) dur.toInt() else 1
        pbMini.progress = if (dur > 0) c.currentPosition.coerceIn(0, dur).toInt() else 0
    }
}
