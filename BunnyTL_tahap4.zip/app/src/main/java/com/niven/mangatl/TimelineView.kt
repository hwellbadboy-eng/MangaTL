package com.niven.mangatl

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.util.TypedValue
import android.view.MotionEvent
import android.view.View

/** Timeline sederhana: tiap klip satu kotak (lebar sebanding durasi), garis putih = posisi putar. */
class TimelineView(ctx: Context) : View(ctx) {

    private var durs: List<Long> = emptyList()
    private var photos: List<Boolean> = emptyList()
    private var speeds: List<Float> = emptyList()

    var selected = -1
        set(v) {
            field = v
            invalidate()
        }

    var playheadMs = 0L
        set(v) {
            field = v
            invalidate()
        }

    /** Dipanggil saat jari menyentuh atau menggeser timeline; isinya posisi (ms) di timeline. */
    var onScrub: ((Long) -> Unit)? = null

    private val fill = Paint(Paint.ANTI_ALIAS_FLAG)
    private val stroke = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        color = Color.WHITE
        strokeWidth = dp(2f)
    }
    private val line = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        strokeWidth = dp(2f)
    }
    private val text = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#09090A")
        textAlign = Paint.Align.CENTER
        textSize = TypedValue.applyDimension(
            TypedValue.COMPLEX_UNIT_SP, 11f, resources.displayMetrics
        )
    }
    private val rect = RectF()

    private fun dp(v: Float) = v * resources.displayMetrics.density

    fun setClips(d: List<Long>, p: List<Boolean>, s: List<Float>) {
        durs = d
        photos = p
        speeds = s
        invalidate()
    }

    private fun gap() = dp(3f)

    /** Kiri dan lebar tiap kotak. */
    private fun layoutBoxes(): List<Pair<Float, Float>> {
        val n = durs.size
        if (n == 0) return emptyList()
        val total = durs.sum().coerceAtLeast(1L).toFloat()
        val usable = (width - gap() * (n - 1)).coerceAtLeast(1f)
        val out = ArrayList<Pair<Float, Float>>()
        var x = 0f
        for (i in 0 until n) {
            val w = usable * durs[i] / total
            out.add(x to w)
            x += w + gap()
        }
        return out
    }

    private fun xFor(ms: Long): Float {
        val boxes = layoutBoxes()
        var acc = 0L
        for (i in boxes.indices) {
            val d = durs[i]
            if (ms <= acc + d || i == boxes.lastIndex) {
                val f = if (d <= 0) 0f else ((ms - acc).toFloat() / d).coerceIn(0f, 1f)
                return boxes[i].first + boxes[i].second * f
            }
            acc += d
        }
        return 0f
    }

    private fun msFor(x: Float): Long {
        val boxes = layoutBoxes()
        if (boxes.isEmpty()) return 0L
        var acc = 0L
        for (i in boxes.indices) {
            val (l, w) = boxes[i]
            if (x < l + w + gap() || i == boxes.lastIndex) {
                val f = if (w <= 0) 0f else ((x - l) / w).coerceIn(0f, 1f)
                return acc + (durs[i] * f).toLong()
            }
            acc += durs[i]
        }
        return acc
    }

    override fun onDraw(c: Canvas) {
        val boxes = layoutBoxes()
        val h = height.toFloat()
        val r = dp(8f)
        for (i in boxes.indices) {
            val (l, w) = boxes[i]
            rect.set(l, 0f, l + w, h)
            fill.color = when {
                i == selected -> Color.parseColor("#F2F2F2")
                photos[i] -> Color.parseColor("#8E8E93")
                else -> Color.parseColor("#6E6E73")
            }
            c.drawRoundRect(rect, r, r, fill)
            if (i == selected) {
                rect.inset(dp(1f), dp(1f))
                c.drawRoundRect(rect, r, r, stroke)
            }
            if (w > dp(26f)) {
                val label = if (photos[i]) "Foto" else ('A' + (i % 26)).toString()
                val sp = speeds[i]
                val sub = if (!photos[i] && sp != 1f) fmtSpeed(sp) else null
                val cy = h / 2f
                if (sub == null) {
                    c.drawText(label, l + w / 2f, cy + text.textSize / 3f, text)
                } else {
                    c.drawText(label, l + w / 2f, cy - dp(2f), text)
                    c.drawText(sub, l + w / 2f, cy + text.textSize, text)
                }
            }
        }
        val px = xFor(playheadMs)
        c.drawLine(px, -dp(2f), px, h + dp(2f), line)
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN, MotionEvent.ACTION_MOVE -> {
                parent?.requestDisallowInterceptTouchEvent(true)
                onScrub?.invoke(msFor(e.x))
                return true
            }
            MotionEvent.ACTION_UP -> {
                performClick()
                return true
            }
        }
        return super.onTouchEvent(e)
    }

    override fun performClick(): Boolean = super.performClick()

    companion object {
        fun fmtSpeed(f: Float): String {
            val s = if (f == f.toInt().toFloat()) f.toInt().toString() else f.toString().replace('.', ',')
            return s + "x"
        }
    }
}
