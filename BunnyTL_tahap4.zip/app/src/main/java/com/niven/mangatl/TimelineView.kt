package com.niven.mangatl

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.util.TypedValue
import android.view.MotionEvent
import android.view.View
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

/**
 * Timeline dua baris dengan skala waktu yang sama:
 * baris atas = video/foto (berurutan), baris bawah = lagu (bebas dipotong, digeser, dipisah).
 * Klip yang dipilih punya lingkaran kurva pudar di sisi atas (awal dan akhir),
 * lagu yang dipilih punya pegangan potong di kiri dan kanan.
 */
class TimelineView(ctx: Context) : View(ctx) {

    class V(
        val dur: Long,
        val photo: Boolean,
        val speed: Float,
        val fadeIn: Long,
        val fadeOut: Long,
        val smooth: Float
    )

    class A(
        val start: Long,
        val len: Long,
        val fadeIn: Long,
        val fadeOut: Long,
        val smooth: Float
    )

    private var vs: List<V> = emptyList()
    private var asg: List<A> = emptyList()
    private var total = 1L

    var selV = -1
        set(v) {
            field = v
            invalidate()
        }

    var selA = -1
        set(v) {
            field = v
            invalidate()
        }

    var playheadMs = 0L
        set(v) {
            field = v
            invalidate()
        }

    /** (posisi ms, ikut memilih klip video di posisi itu). */
    var onScrub: ((Long, Boolean) -> Unit)? = null
    var onSelectAudio: ((Int) -> Unit)? = null

    /** Dipanggil sekali di awal tarikan yang mengubah data (untuk Urungkan). */
    var onDragStart: (() -> Unit)? = null

    /** (indeks klip, true = pudar awal / false = pudar akhir, durasi pudar ms). */
    var onVideoFade: ((Int, Boolean, Long) -> Unit)? = null

    /** (indeks lagu, mode MODE_*, nilai ms). Arti nilai dijelaskan di tiap mode. */
    var onAudioEdit: ((Int, Int, Long) -> Unit)? = null

    private val fill = Paint(Paint.ANTI_ALIAS_FLAG)
    private val strokeP = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        color = Color.WHITE
        strokeWidth = dp(2f)
    }
    private val line = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        strokeWidth = dp(2f)
    }
    private val curveP = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = dp(1.5f)
        strokeJoin = Paint.Join.ROUND
        strokeCap = Paint.Cap.ROUND
    }
    private val text = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#000000")
        textAlign = Paint.Align.CENTER
        textSize = TypedValue.applyDimension(
            TypedValue.COMPLEX_UNIT_SP, 11f, resources.displayMetrics
        )
    }
    private val rect = RectF()
    private val path = Path()

    private fun dp(v: Float) = v * resources.displayMetrics.density

    private fun hp() = dp(12f)
    private fun usable() = (width - 2 * hp()).coerceAtLeast(1f)
    private fun xOf(ms: Long) = hp() + usable() * ms / total
    private fun msOf(x: Float) = (((x - hp()) / usable()) * total).toLong().coerceIn(0L, total)
    private fun fpx(ms: Long) = usable() * ms / total

    private fun vTop() = dp(12f)
    private fun vBot() = vTop() + dp(50f)
    private fun aTop() = vBot() + dp(22f)
    private fun aBot() = aTop() + dp(44f)

    fun wantedHeightPx(): Int = (aBot() + dp(10f)).toInt()

    fun setData(v: List<V>, a: List<A>) {
        vs = v
        asg = a
        total = v.sumOf { it.dur }.coerceAtLeast(1L)
        invalidate()
    }

    private fun vRange(i: Int): Pair<Float, Float> {
        var acc = 0L
        for (k in 0 until i) acc += vs[k].dur
        return xOf(acc) to xOf(acc + vs[i].dur)
    }

    private fun aRange(i: Int): Pair<Float, Float> {
        val s = asg[i]
        return xOf(s.start) to xOf(min(s.start + s.len, total))
    }

    // ------------------------------------------------------------------ gambar

    private fun curvePoint(l: Float, r: Float, top: Float, bot: Float, fi: Long, fo: Long, x: Float, s: Float): Float {
        // tinggi (y) kurva di posisi x, dari kiri ke kanan klip
        val g = fadeGain(((x - l) / usable() * total).toLong(), ((r - l) / usable() * total).toLong(), fi, fo, s)
        return bot - (bot - top) * g
    }

    private fun drawFade(
        c: Canvas, l: Float, r: Float, top: Float, bot: Float,
        fi: Long, fo: Long, s: Float, shade: Int, lineColor: Int
    ) {
        val steps = 28
        fill.color = shade
        curveP.color = lineColor
        if (fi > 0) {
            val fw = min(fpx(fi), r - l)
            path.reset()
            path.moveTo(l, top)
            path.lineTo(l + fw, top)
            for (k in steps downTo 0) {
                val x = l + fw * k / steps
                path.lineTo(x, curvePoint(l, r, top, bot, fi, 0L, x, s))
            }
            path.close()
            c.drawPath(path, fill)
            path.reset()
            for (k in 0..steps) {
                val x = l + fw * k / steps
                val y = curvePoint(l, r, top, bot, fi, 0L, x, s)
                if (k == 0) path.moveTo(x, y) else path.lineTo(x, y)
            }
            c.drawPath(path, curveP)
        }
        if (fo > 0) {
            val fw = min(fpx(fo), r - l)
            path.reset()
            path.moveTo(r - fw, top)
            path.lineTo(r, top)
            path.lineTo(r, bot)
            for (k in steps downTo 0) {
                val x = r - fw + fw * k / steps
                path.lineTo(x, curvePoint(l, r, top, bot, 0L, fo, x, s))
            }
            path.close()
            c.drawPath(path, fill)
            path.reset()
            for (k in 0..steps) {
                val x = r - fw + fw * k / steps
                val y = curvePoint(l, r, top, bot, 0L, fo, x, s)
                if (k == 0) path.moveTo(x, y) else path.lineTo(x, y)
            }
            c.drawPath(path, curveP)
        }
    }

    private fun knob(c: Canvas, x: Float, y: Float) {
        fill.color = Color.BLACK
        c.drawCircle(x, y, dp(7f), fill)
        c.drawCircle(x, y, dp(7f), strokeP)
    }

    private fun bar(c: Canvas, x: Float, top: Float, bot: Float) {
        fill.color = Color.WHITE
        rect.set(x - dp(5f), top - dp(4f), x + dp(5f), bot + dp(4f))
        c.drawRoundRect(rect, dp(5f), dp(5f), fill)
        fill.color = Color.parseColor("#000000")
        rect.set(x - dp(1f), top + dp(8f), x + dp(1f), bot - dp(8f))
        c.drawRoundRect(rect, dp(1f), dp(1f), fill)
    }

    override fun onDraw(c: Canvas) {
        val vt = vTop()
        val vb = vBot()
        val r8 = dp(8f)

        // baris video
        var acc = 0L
        for (i in vs.indices) {
            val v = vs[i]
            val l = xOf(acc)
            val r = xOf(acc + v.dur)
            acc += v.dur
            rect.set(l + dp(1f), vt, r - dp(1f), vb)
            val sel = i == selV
            fill.color = when {
                sel -> Color.parseColor("#F2F2F2")
                v.photo -> Color.parseColor("#8E8E93")
                else -> Color.parseColor("#6E6E73")
            }
            c.drawRoundRect(rect, r8, r8, fill)
            val w = r - l
            if (w > dp(26f)) {
                val label = if (v.photo) "Foto" else ('A' + (i % 26)).toString()
                val sub = if (!v.photo && v.speed != 1f) fmtSpeed(v.speed) else null
                val cy = (vt + vb) / 2f
                text.color = Color.parseColor("#000000")
                if (sub == null) {
                    c.drawText(label, l + w / 2f, cy + text.textSize / 3f, text)
                } else {
                    c.drawText(label, l + w / 2f, cy - dp(2f), text)
                    c.drawText(sub, l + w / 2f, cy + text.textSize, text)
                }
            }
            if (v.fadeIn > 0 || v.fadeOut > 0) {
                c.save()
                c.clipRect(l + dp(1f), vt, r - dp(1f), vb)
                drawFade(
                    c, l, r, vt, vb, v.fadeIn, v.fadeOut, v.smooth,
                    if (sel) Color.parseColor("#66000000") else Color.parseColor("#55000000"),
                    if (sel) Color.parseColor("#000000") else Color.parseColor("#C7C7CC")
                )
                c.restore()
            }
            if (sel) {
                knob(c, l + max(fpx(v.fadeIn), dp(14f)), vt)
                knob(c, r - max(fpx(v.fadeOut), dp(14f)), vt)
            }
        }

        // baris lagu
        val at = aTop()
        val ab = aBot()
        rect.set(hp(), at, width - hp(), ab)
        fill.color = Color.parseColor("#0D0D0F")
        c.drawRoundRect(rect, r8, r8, fill)
        strokeP.color = Color.parseColor("#1F1F23")
        strokeP.strokeWidth = dp(1f)
        c.drawRoundRect(rect, r8, r8, strokeP)
        strokeP.color = Color.WHITE
        strokeP.strokeWidth = dp(2f)
        if (asg.isEmpty()) {
            text.color = Color.parseColor("#6E6E73")
            c.drawText("Belum ada lagu", width / 2f, (at + ab) / 2f + text.textSize / 3f, text)
        }
        for (i in asg.indices) {
            val s = asg[i]
            val (l, r) = aRange(i)
            val sel = i == selA
            rect.set(l + dp(1f), at, r - dp(1f), ab)
            fill.color = if (sel) Color.parseColor("#F2F2F2") else Color.parseColor("#48484D")
            c.drawRoundRect(rect, r8, r8, fill)
            if (r - l > dp(40f)) {
                text.color = if (sel) Color.parseColor("#000000") else Color.parseColor("#C7C7CC")
                c.drawText("Lagu", (l + r) / 2f, (at + ab) / 2f + text.textSize / 3f, text)
            }
            if (s.fadeIn > 0 || s.fadeOut > 0) {
                c.save()
                c.clipRect(l + dp(1f), at, r - dp(1f), ab)
                drawFade(
                    c, l, r, at, ab, s.fadeIn, s.fadeOut, s.smooth,
                    Color.parseColor("#66000000"),
                    if (sel) Color.parseColor("#000000") else Color.parseColor("#C7C7CC")
                )
                c.restore()
            }
            if (sel) {
                knob(c, l + max(fpx(s.fadeIn), dp(14f)), at)
                knob(c, r - max(fpx(s.fadeOut), dp(14f)), at)
                bar(c, l, at, ab)
                bar(c, r, at, ab)
            }
        }

        // garis posisi putar
        val px = xOf(playheadMs.coerceIn(0L, total))
        c.drawLine(px, dp(2f), px, ab + dp(6f), line)
        fill.color = Color.WHITE
        c.drawCircle(px, dp(3f), dp(3.5f), fill)
    }

    // ------------------------------------------------------------------ sentuhan

    private var mode = M_NONE
    private var idx = -1
    private var grab = 0L

    private fun near(a: Float, b: Float, r: Float) = abs(a - b) <= r

    override fun onTouchEvent(e: MotionEvent): Boolean {
        val x = e.x
        val y = e.y
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                parent?.requestDisallowInterceptTouchEvent(true)
                mode = M_NONE
                idx = -1
                if (y < aTop() - dp(12f)) downVideoRow(x, y) else downAudioRow(x, y)
                return true
            }
            MotionEvent.ACTION_MOVE -> {
                when (mode) {
                    M_SCRUB_SEL -> onScrub?.invoke(msOf(x), true)
                    M_SCRUB_KEEP -> onScrub?.invoke(msOf(x), false)
                    M_V_IN, M_V_OUT -> {
                        val (l, r) = vRange(idx)
                        val ms = if (mode == M_V_IN) ((x - l) / usable() * total).toLong()
                        else ((r - x) / usable() * total).toLong()
                        onVideoFade?.invoke(idx, mode == M_V_IN, ms.coerceAtLeast(0L))
                    }
                    M_A_FIN, M_A_FOUT -> {
                        val (l, r) = aRange(idx)
                        val ms = if (mode == M_A_FIN) ((x - l) / usable() * total).toLong()
                        else ((r - x) / usable() * total).toLong()
                        onAudioEdit?.invoke(idx, if (mode == M_A_FIN) MODE_FIN else MODE_FOUT, ms.coerceAtLeast(0L))
                    }
                    M_A_L -> onAudioEdit?.invoke(idx, MODE_L, msOf(x))
                    M_A_R -> onAudioEdit?.invoke(idx, MODE_R, msOf(x))
                    M_A_MOVE -> onAudioEdit?.invoke(idx, MODE_MOVE, msOf(x) - grab)
                }
                return true
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                if (e.actionMasked == MotionEvent.ACTION_UP) performClick()
                mode = M_NONE
                return true
            }
        }
        return super.onTouchEvent(e)
    }

    private fun downVideoRow(x: Float, y: Float) {
        if (selV in vs.indices) {
            val v = vs[selV]
            val (l, r) = vRange(selV)
            val inX = l + max(fpx(v.fadeIn), dp(14f))
            val outX = r - max(fpx(v.fadeOut), dp(14f))
            val ty = vTop()
            val dIn = if (near(y, ty, dp(22f))) abs(x - inX) else Float.MAX_VALUE
            val dOut = if (near(y, ty, dp(22f))) abs(x - outX) else Float.MAX_VALUE
            if (min(dIn, dOut) <= dp(22f)) {
                idx = selV
                mode = if (dIn <= dOut) M_V_IN else M_V_OUT
                onDragStart?.invoke()
                return
            }
        }
        mode = M_SCRUB_SEL
        onScrub?.invoke(msOf(x), true)
    }

    private fun downAudioRow(x: Float, y: Float) {
        val at = aTop()
        val ab = aBot()
        if (selA in asg.indices) {
            val s = asg[selA]
            val (l, r) = aRange(selA)
            val inX = l + max(fpx(s.fadeIn), dp(14f))
            val outX = r - max(fpx(s.fadeOut), dp(14f))
            val knobNear = near(y, at, dp(22f))
            val dIn = if (knobNear) abs(x - inX) else Float.MAX_VALUE
            val dOut = if (knobNear) abs(x - outX) else Float.MAX_VALUE
            val barNear = y >= at - dp(12f) && y <= ab + dp(12f)
            val dL = if (barNear) abs(x - l) else Float.MAX_VALUE
            val dR = if (barNear) abs(x - r) else Float.MAX_VALUE
            val best = minOf(dIn, dOut, dL, dR)
            if (best <= dp(22f)) {
                idx = selA
                mode = when (best) {
                    dIn -> M_A_FIN
                    dOut -> M_A_FOUT
                    dL -> M_A_L
                    else -> M_A_R
                }
                onDragStart?.invoke()
                return
            }
        }
        // ketuk badan lagu: pilih dan siap digeser
        val ms = msOf(x)
        for (i in asg.indices) {
            val s = asg[i]
            if (ms >= s.start && ms <= s.start + s.len) {
                if (i != selA) onSelectAudio?.invoke(i)
                idx = i
                grab = ms - s.start
                mode = M_A_MOVE
                onDragStart?.invoke()
                return
            }
        }
        onSelectAudio?.invoke(-1)
        mode = M_SCRUB_KEEP
        onScrub?.invoke(ms, false)
    }

    override fun performClick(): Boolean = super.performClick()

    companion object {
        const val MODE_L = 0
        const val MODE_R = 1
        const val MODE_MOVE = 2
        const val MODE_FIN = 3
        const val MODE_FOUT = 4

        private const val M_NONE = 0
        private const val M_SCRUB_SEL = 1
        private const val M_SCRUB_KEEP = 2
        private const val M_V_IN = 3
        private const val M_V_OUT = 4
        private const val M_A_FIN = 5
        private const val M_A_FOUT = 6
        private const val M_A_L = 7
        private const val M_A_R = 8
        private const val M_A_MOVE = 9

        /** Kurva pudar: s = 0 lurus, s = 1 berbentuk S yang halus. */
        fun ease(t: Float, s: Float): Float {
            val x = t.coerceIn(0f, 1f)
            val smooth = x * x * (3f - 2f * x)
            return x + (smooth - x) * s.coerceIn(0f, 1f)
        }

        /** Pengali (0..1) di posisi off dalam klip berdurasi dur, dengan pudar awal fi dan pudar akhir fo. */
        fun fadeGain(off: Long, dur: Long, fi: Long, fo: Long, s: Float): Float {
            var g = 1f
            if (fi > 0L && off < fi) g = min(g, ease(off.toFloat() / fi, s))
            if (fo > 0L && off > dur - fo) g = min(g, ease((dur - off).toFloat() / fo, s))
            return g.coerceIn(0f, 1f)
        }

        fun fmtSpeed(f: Float): String {
            val s = if (f == f.toInt().toFloat()) f.toInt().toString() else f.toString().replace('.', ',')
            return s + "x"
        }
    }
}
