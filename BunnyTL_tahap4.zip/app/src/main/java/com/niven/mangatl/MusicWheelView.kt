package com.niven.mangatl

import android.animation.Animator
import android.animation.AnimatorListenerAdapter
import android.animation.TimeInterpolator
import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.text.TextUtils
import android.util.AttributeSet
import android.view.Gravity
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.VelocityTracker
import android.view.ViewGroup
import android.view.animation.DecelerateInterpolator
import android.view.animation.PathInterpolator
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.core.content.res.ResourcesCompat
import kotlinx.coroutines.CoroutineScope
import kotlin.math.abs
import kotlin.math.ceil
import kotlin.math.cos
import kotlin.math.floor
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

/**
 * Font layar Musik. Desain memakai Inter: taruh file font bernama "inter" (res/font/inter.ttf)
 * dan otomatis dipakai. Kalau tidak ada, jatuh ke font bawaan HP.
 */
object MusicFonts {
    private var base: Typeface? = null
    private var tried = false

    private fun base(ctx: Context): Typeface {
        if (!tried) {
            tried = true
            val id = ctx.resources.getIdentifier("inter", "font", ctx.packageName)
            if (id != 0) {
                base = try {
                    ResourcesCompat.getFont(ctx, id)
                } catch (e: Exception) {
                    null
                }
            }
        }
        return base ?: Typeface.DEFAULT
    }

    fun face(ctx: Context, weight: Int): Typeface {
        val b = base(ctx)
        return if (Build.VERSION.SDK_INT >= 28) {
            Typeface.create(b, weight, false)
        } else {
            Typeface.create(b, if (weight >= 600) Typeface.BOLD else Typeface.NORMAL)
        }
    }
}

/**
 * Daftar musik gaya "roda": baris di tengah paling besar, baris lain mengecil, memudar dan
 * bergeser mengikuti lengkung. Seret = geser, lepas = berhenti di baris terdekat. Tahan lama baris
 * tengah = menu. Garis lengkung di tepi = cari cepat (seret untuk loncat jauh, huruf pertama judul
 * muncul di gelembung). Ukuran dalam dp mengikuti artboard 390 x 844 di desain "Versi 3".
 *
 * Hanya sekitar 11 baris yang benar-benar dibuat; sisanya hanya data (Row), jadi aman untuk ribuan lagu.
 */
class MusicWheelView @JvmOverloads constructor(ctx: Context, attrs: AttributeSet? = null) :
    ViewGroup(ctx, attrs) {

    var scope: CoroutineScope? = null

    /** Ketuk baris. */
    var onRowClick: ((Row) -> Unit)? = null

    /** Tahan lama baris tengah. Kembalikan true kalau ditangani (ketukan setelahnya diabaikan). */
    var onRowLong: ((Row) -> Boolean)? = null

    private val d = resources.displayMetrics.density
    private val uiHandler = Handler(Looper.getMainLooper())
    private val ease = PathInterpolator(0.25f, 0.1f, 0.25f, 1f)

    private var rows: List<Row> = emptyList()
    private var playingKey = -1L
    private var userFocus: Int? = null
    private var focus = 0f
    private var curveT = 1f
    private var qsT = 0f
    private var qsActive = false
    private var dragging = false
    private var fast = false
    private var qsRight = true

    private var anim: ValueAnimator? = null
    private var curveAnim: ValueAnimator? = null
    private var qsAnim: ValueAnimator? = null

    private val bound = HashMap<Int, ItemView>()
    private val free = ArrayList<ItemView>()

    // gambar garis cari cepat
    private val railPath = Path()
    private var railW = -1f
    private var railC = -1f
    private var railR = true
    private val railPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 1.5f
        color = 0xFF3A3A3A.toInt()
    }
    private val dotPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE }
    private val bubblePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE }
    private val letterPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.BLACK
        textSize = 20f
        textAlign = Paint.Align.CENTER
        typeface = MusicFonts.face(ctx, 800)
    }

    // sentuhan
    private var downY = 0f
    private var startFocus = 0f
    private var moved = false
    private var lpFired = false
    private var pressedIdx = -1
    private var vt: VelocityTracker? = null

    private val lpRun = Runnable {
        val i = pressedIdx
        if (!moved && i in rows.indices) {
            performHapticFeedback(HapticFeedbackConstants.LONG_PRESS)
            lpFired = onRowLong?.invoke(rows[i]) ?: false
        }
    }

    init {
        setWillNotDraw(false)
        clipChildren = false
        repeat(14) {
            val v = ItemView(ctx)
            v.visibility = INVISIBLE
            addView(v)
            free.add(v)
        }
    }

    // ------------------------------------------------------------------ item

    private inner class ItemView(c: Context) : LinearLayout(c) {
        val cover = FrameLayout(c)
        val img = ImageView(c)
        val icon = ImageView(c)
        val title = TextView(c)
        val artist = TextView(c)
        val coverBg = GradientDrawable()
        var index = -1
        var row: Row? = null
        var bold = false
        var coverColor = 0
        var ring = false
        var needCover = false

        init {
            orientation = HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            coverBg.cornerRadius = 10f * d
            coverBg.setColor(0xFF222222.toInt())
            coverColor = 0xFF222222.toInt()
            cover.background = coverBg
            cover.clipToOutline = true
            img.scaleType = ImageView.ScaleType.CENTER_CROP
            cover.addView(img, FrameLayout.LayoutParams(-1, -1))
            icon.setColorFilter(Color.WHITE)
            icon.alpha = 0.6f
            icon.visibility = GONE
            cover.addView(
                icon,
                FrameLayout.LayoutParams((20 * d).toInt(), (20 * d).toInt(), Gravity.CENTER)
            )
            addView(cover, LinearLayout.LayoutParams((42 * d).toInt(), (42 * d).toInt()))

            val col = LinearLayout(c)
            col.orientation = VERTICAL
            title.textSize = 15f
            title.setTextColor(Color.WHITE)
            title.maxLines = 1
            title.ellipsize = TextUtils.TruncateAt.END
            title.typeface = MusicFonts.face(c, 500)
            artist.textSize = 12f
            artist.setTextColor(0xFF9A9A9A.toInt())
            artist.maxLines = 1
            artist.ellipsize = TextUtils.TruncateAt.END
            artist.typeface = MusicFonts.face(c, 400)
            col.addView(
                title,
                LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
                )
            )
            col.addView(
                artist,
                LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
                ).apply { topMargin = (2 * d).toInt() }
            )
            addView(
                col,
                LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
                    .apply { marginStart = (14 * d).toInt() }
            )
            pivotX = 0f
            pivotY = ITEM_H * d / 2f
        }
    }

    // ------------------------------------------------------------------ API

    /** Ganti isi daftar. keepFocus = true: tetap di posisi sekarang (mis. setelah pilih/favorit). */
    fun setRows(list: List<Row>, keepFocus: Boolean) {
        rows = list
        for (v in bound.values) {
            v.index = -1
            v.row = null
            v.visibility = INVISIBLE
            free.add(v)
        }
        bound.clear()
        anim?.cancel()
        val last = max(list.size - 1, 0)
        if (!keepFocus) userFocus = null
        userFocus = userFocus?.coerceIn(0, last)
        if (keepFocus) {
            focus = focus.coerceIn(0f, last.toFloat())
        } else {
            focus = targetIndex().toFloat()
        }
        update()
        loadPending()
    }

    /** Lagu yang sedang diputar (id); wheel memusatkan baris ini kecuali pengguna baru saja menggeser. */
    fun setPlayingKey(key: Long, recenter: Boolean) {
        val changed = key != playingKey
        playingKey = key
        if (changed || recenter) {
            userFocus = null
            if (!dragging) animateFocusTo(targetIndex().toFloat(), 300L, ease) else update()
        } else {
            update()
        }
    }

    fun setCurved(on: Boolean, animate: Boolean) {
        curveAnim?.cancel()
        val to = if (on) 1f else 0f
        if (!animate) {
            curveT = to
            update()
            return
        }
        val a = ValueAnimator.ofFloat(curveT, to)
        a.duration = 300L
        a.interpolator = ease
        a.addUpdateListener {
            curveT = it.animatedValue as Float
            update()
        }
        curveAnim = a
        a.start()
    }

    fun setQsRight(on: Boolean) {
        qsRight = on
        invalidate()
    }

    // ------------------------------------------------------------------ hitung

    private fun lastIndex() = max(rows.size - 1, 0)

    private fun autoIndex(): Int {
        val i = rows.indexOfFirst { it.key >= 0 && it.key == playingKey }
        return if (i < 0) 0 else i
    }

    private fun targetIndex(): Int = (userFocus ?: autoIndex()).coerceIn(0, lastIndex())

    private fun centerY(): Float {
        val h = height / d
        return min(264f, max(120f, h - 150f))
    }

    // ------------------------------------------------------------------ animasi

    private fun animateFocusTo(target: Float, dur: Long, interp: TimeInterpolator) {
        anim?.cancel()
        val from = focus
        if (abs(target - from) < 0.001f) {
            focus = target
            update()
            settled()
            return
        }
        if (abs(target - from) > 14f) {
            // loncatan jauh: langsung pindah supaya tidak memuat ratusan thumbnail di jalan
            focus = target
            update()
            settled()
            return
        }
        val a = ValueAnimator.ofFloat(from, target)
        a.duration = dur
        a.interpolator = interp
        a.addUpdateListener {
            focus = it.animatedValue as Float
            update()
        }
        a.addListener(object : AnimatorListenerAdapter() {
            override fun onAnimationEnd(animation: Animator) {
                if (anim === animation) settled()
            }
        })
        anim = a
        a.start()
    }

    private fun animateQs(to: Float) {
        qsAnim?.cancel()
        val a = ValueAnimator.ofFloat(qsT, to)
        a.duration = 200L
        a.addUpdateListener {
            qsT = it.animatedValue as Float
            invalidate()
        }
        qsAnim = a
        a.start()
    }

    private fun settled() {
        fast = false
        loadPending()
    }

    // ------------------------------------------------------------------ tata letak

    override fun onMeasure(widthSpec: Int, heightSpec: Int) {
        setMeasuredDimension(
            MeasureSpec.getSize(widthSpec), MeasureSpec.getSize(heightSpec)
        )
        val cw = MeasureSpec.makeMeasureSpec((ITEM_W * d).toInt(), MeasureSpec.EXACTLY)
        val ch = MeasureSpec.makeMeasureSpec((ITEM_H * d).toInt(), MeasureSpec.EXACTLY)
        for (i in 0 until childCount) getChildAt(i).measure(cw, ch)
    }

    override fun onLayout(changed: Boolean, l: Int, t: Int, r: Int, b: Int) {
        for (i in 0 until childCount) {
            val c = getChildAt(i)
            c.layout(0, 0, c.measuredWidth, c.measuredHeight)
        }
        update()
    }

    /** Pasang ulang posisi, ukuran dan bayangan tiap baris dari nilai [focus] sekarang. */
    private fun update() {
        if (width == 0) return
        val n = rows.size
        val ctr = centerY()
        val lo: Int
        val hi: Int
        if (n == 0) {
            lo = 0
            hi = -1
        } else {
            lo = max(0, floor(focus - 5f).toInt())
            hi = min(n - 1, ceil(focus + 5f).toInt())
        }

        val iter = bound.entries.iterator()
        while (iter.hasNext()) {
            val e = iter.next()
            if (e.key < lo || e.key > hi) {
                val v = e.value
                v.index = -1
                v.row = null
                v.visibility = INVISIBLE
                free.add(v)
                iter.remove()
            }
        }

        for (i in lo..hi) {
            var v = bound[i]
            if (v == null) {
                v = if (free.isNotEmpty()) {
                    free.removeAt(free.size - 1)
                } else {
                    val nv = ItemView(context)
                    addView(nv)
                    nv
                }
                bound[i] = v
            }
            bindRow(v, i)
            place(v, i, ctr)
        }
        invalidate()
    }

    private fun bindRow(v: ItemView, i: Int) {
        val r = rows[i]
        v.index = i
        if (v.row === r) return
        v.row = r
        v.title.text = r.title
        v.artist.text = r.sub
        v.artist.visibility = if (r.sub.isEmpty()) GONE else VISIBLE
        val noArt = r.thumb == null && r.thumbs.isEmpty()
        if (noArt && r.icon != R.drawable.ic_music_note && r.icon != 0) {
            v.icon.setImageResource(r.icon)
            v.icon.visibility = VISIBLE
        } else {
            v.icon.visibility = GONE
        }
        v.img.setImageDrawable(null)
        v.needCover = true
        if (!fast) loadCover(v)
    }

    private fun loadCover(v: ItemView) {
        val r = v.row ?: return
        val sc = scope ?: return
        v.needCover = false
        Thumbs.load(sc, v.img, r.thumb ?: r.thumbs.firstOrNull(), (42 * d * 2).toInt(), false)
    }

    private fun loadPending() {
        for (v in bound.values) if (v.needCover) loadCover(v)
    }

    private fun place(v: ItemView, i: Int, ctr: Float) {
        val r = v.row ?: return
        val dd = i - focus
        val ad = abs(dd)
        val mid = ad < 0.5f
        val curveLeft = 34f * cos(0.45f * dd)
        val curveSc = max(0.78f, 1.06f - 0.12f * ad)
        val flatSc = if (mid) 1.04f else 1f
        val left = LEFT + curveLeft * curveT
        val sc = flatSc + (curveSc - flatSc) * curveT
        val op = max(0.25f, 1f - 0.22f * ad) * min(1f, max(0f, 4.6f - ad))

        v.translationX = left * d
        v.translationY = (ctr + dd * STEP - ITEM_H / 2f) * d
        v.scaleX = sc
        v.scaleY = sc
        v.alpha = op
        v.visibility = if (op > 0.01f) VISIBLE else INVISIBLE

        val playing = r.key >= 0 && r.key == playingKey
        val col = if (playing) 0xFFFFFFFF.toInt() else if (mid) 0xFF3A3A3A.toInt() else 0xFF222222.toInt()
        if (v.coverColor != col) {
            v.coverColor = col
            v.coverBg.setColor(col)
        }
        val boldNow = mid || playing
        if (boldNow != v.bold) {
            v.bold = boldNow
            v.title.typeface = MusicFonts.face(context, if (boldNow) 700 else 500)
        }
        if (r.selected != v.ring) {
            v.ring = r.selected
            v.coverBg.setStroke(if (r.selected) (3 * d).toInt() else 0, Color.WHITE)
        }
    }

    // ------------------------------------------------------------------ gambar rel cari cepat

    private fun arcX(c: Float): Float {
        val w = width / d
        return if (qsRight) w - 38f + 20f * c else 8f + 30f * c
    }

    private fun rebuildRail(ctr: Float) {
        railPath.reset()
        for (q in 0..30) {
            val t = q / 30f
            val dd = -3f + 6f * t
            val x = arcX(cos(0.45f * dd))
            val y = ctr + dd * STEP
            if (q == 0) railPath.moveTo(x, y) else railPath.lineTo(x, y)
        }
    }

    override fun dispatchDraw(canvas: Canvas) {
        val n = rows.size
        if (n > 0 && width > 0) {
            val w = width / d
            val ctr = centerY()
            if (railW != w || railC != ctr || railR != qsRight) {
                railW = w
                railC = ctr
                railR = qsRight
                rebuildRail(ctr)
            }
            canvas.save()
            canvas.scale(d, d)
            if (qsT > 0.01f) {
                railPaint.alpha = (qsT * 255).toInt()
                canvas.drawPath(railPath, railPaint)
            }
            val t = if (n > 1) (focus / (n - 1)).coerceIn(0f, 1f) else 0.5f
            val dd = -3f + 6f * t
            val px = arcX(cos(0.45f * dd))
            val py = ctr + dd * STEP
            dotPaint.alpha = ((0.5f + 0.5f * qsT) * 255).toInt()
            canvas.drawCircle(px, py, 2.5f + 2f * qsT, dotPaint)
            if (qsT > 0.01f) {
                val bx = if (qsRight) px - 70f else px + 26f
                val by = py - 22f
                bubblePaint.alpha = (qsT * 255).toInt()
                canvas.drawCircle(bx + 22f, by + 22f, 22f, bubblePaint)
                val s = rows.getOrNull(focus.roundToInt())?.title ?: ""
                if (s.isNotEmpty()) {
                    letterPaint.alpha = (qsT * 255).toInt()
                    val fm = letterPaint.fontMetrics
                    canvas.drawText(
                        s.substring(0, 1).uppercase(), bx + 22f,
                        by + 22f - (fm.ascent + fm.descent) / 2f, letterPaint
                    )
                }
            }
            canvas.restore()
        }
        super.dispatchDraw(canvas)
    }

    // ------------------------------------------------------------------ sentuhan

    private fun hitItem(x: Float, y: Float): ItemView? {
        for (v in bound.values) {
            if (v.alpha < 0.05f || v.visibility != VISIBLE) continue
            val left = v.translationX / d
            val cy = v.translationY / d + ITEM_H / 2f
            val sc = v.scaleX
            if (x >= left && x <= left + ITEM_W * sc && y >= cy - ITEM_H * sc / 2f && y <= cy + ITEM_H * sc / 2f) {
                return v
            }
        }
        return null
    }

    private fun inQs(x: Float, y: Float): Boolean {
        if (rows.isEmpty()) return false
        val w = width / d
        val c = centerY()
        val inX = if (qsRight) x >= w - 44f else x <= 30f
        return inX && y >= c - 190f && y <= c + 190f
    }

    private fun qsFocus(y: Float): Float {
        val t = ((y - (centerY() - 180f)) / 360f).coerceIn(0f, 1f)
        return t * lastIndex()
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        val x = e.x / d
        val y = e.y / d
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                parent?.requestDisallowInterceptTouchEvent(true)
                anim?.cancel()
                if (inQs(x, y)) {
                    qsActive = true
                    dragging = true
                    fast = true
                    uiHandler.removeCallbacks(lpRun)
                    animateQs(1f)
                    focus = qsFocus(y)
                    update()
                    return true
                }
                downY = y
                startFocus = focus
                moved = false
                lpFired = false
                pressedIdx = -1
                vt?.recycle()
                vt = VelocityTracker.obtain()
                vt?.addMovement(e)
                val hit = hitItem(x, y)
                if (hit != null && abs(hit.index - focus) < 0.5f) {
                    pressedIdx = hit.index
                    uiHandler.postDelayed(lpRun, 450L)
                }
            }

            MotionEvent.ACTION_MOVE -> {
                if (qsActive) {
                    focus = qsFocus(y)
                    update()
                    return true
                }
                vt?.addMovement(e)
                val dy = y - downY
                if (!moved && abs(dy) > 6f) {
                    moved = true
                    dragging = true
                    uiHandler.removeCallbacks(lpRun)
                }
                if (moved) {
                    focus = (startFocus - dy / STEP).coerceIn(0f, lastIndex().toFloat())
                    update()
                }
            }

            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                uiHandler.removeCallbacks(lpRun)
                if (qsActive) {
                    qsActive = false
                    dragging = false
                    animateQs(0f)
                    val t = focus.roundToInt().coerceIn(0, lastIndex())
                    userFocus = t
                    animateFocusTo(t.toFloat(), 300L, ease)
                    return true
                }
                val up = e.actionMasked == MotionEvent.ACTION_UP
                if (lpFired) {
                    lpFired = false
                } else if (moved) {
                    vt?.addMovement(e)
                    vt?.computeCurrentVelocity(1000)
                    val vy = (vt?.yVelocity ?: 0f) / d
                    val proj = focus - (vy / STEP) * 0.2f
                    val t = proj.roundToInt().coerceIn(0, lastIndex())
                    userFocus = t
                    dragging = false
                    val far = abs(t - focus) > 1f
                    animateFocusTo(
                        t.toFloat(),
                        if (far) (260L + 40L * abs(t - focus).toLong()).coerceAtMost(700L) else 300L,
                        if (far) DecelerateInterpolator(1.4f) else ease
                    )
                } else if (up) {
                    val hit = hitItem(x, y)
                    val i = hit?.index ?: -1
                    if (i in rows.indices) onRowClick?.invoke(rows[i])
                }
                dragging = false
                moved = false
                vt?.recycle()
                vt = null
            }
        }
        return true
    }

    override fun performClick(): Boolean = super.performClick()

    override fun onDetachedFromWindow() {
        uiHandler.removeCallbacks(lpRun)
        anim?.cancel()
        curveAnim?.cancel()
        qsAnim?.cancel()
        super.onDetachedFromWindow()
    }

    companion object {
        private const val ITEM_W = 270f
        private const val ITEM_H = 52f
        private const val STEP = 60f
        private const val LEFT = 22f
    }
}
