package com.niven.mangatl

import android.graphics.Color
import android.view.Gravity
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.TextView
import androidx.lifecycle.lifecycleScope
import androidx.media3.common.MediaItem
import androidx.media3.exoplayer.ExoPlayer
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.Locale

// Editor video: operasi edit (bagi, hapus, geser, kecepatan, volume, lagu) dan dialognya.
// Fungsi ekstensi dari VideoEditActivity; keadaan editor tetap dimiliki activity.

internal fun VideoEditActivity.splitSeg() {
    val sg = segs[selA]
    val rel = playhead - sg.start
    if (rel < 300L || sg.len() - rel < 300L) {
        toast("Geser garis putih ke tengah lagu dulu.")
        return
    }
    pushHistory()
    val b = sg.copy()
    b.start = playhead
    b.from = sg.from + rel
    b.fadeIn = 0L
    sg.to = sg.from + rel
    sg.fadeOut = 0L
    sg.clampFades()
    b.clampFades()
    segs.add(selA + 1, b)
    pushTimeline()
}

internal fun VideoEditActivity.splitOv() {
    val o = ovs[selO]
    val rel = playhead - o.start
    if (rel < 300L || o.dur() - rel < 300L) {
        toast("Geser garis putih ke tengah lapisan dulu.")
        return
    }
    pushHistory()
    val b = o.copy()
    b.start = playhead
    if (o.photo) {
        b.photoMs = o.photoMs - rel
        o.photoMs = rel
    } else {
        val srcRel = (rel * o.speed).toLong()
        b.srcStart = o.srcStart + srcRel
        o.srcEnd = o.srcStart + srcRel
    }
    o.fadeOut = 0L
    b.fadeIn = 0L
    o.clampFades()
    b.clampFades()
    ovs.add(selO + 1, b)
    rebuildOverlays()
    pushTimeline()
}

internal fun VideoEditActivity.split() {
    if (selO in ovs.indices) {
        splitOv()
        return
    }
    if (selA in segs.indices) {
        splitSeg()
        return
    }
    if (clips.isEmpty()) return
    val (i, off) = locate(playhead)
    val c = clips[i]
    if (c.photo) {
        toast("Foto tidak bisa dipisah.")
        return
    }
    val d = c.dur()
    if (off < 300L || d - off < 300L) {
        toast("Geser garis putih ke tengah klip dulu.")
        return
    }
    pushHistory()
    val srcOff = (off * c.speed).toLong()
    val a = c.copy()
    a.end = c.start + srcOff
    a.fadeOut = 0L
    a.clampFades()
    val b = c.copy()
    b.start = c.start + srcOff
    b.fadeIn = 0L
    b.clampFades()
    clips[i] = a
    clips.add(i + 1, b)
    sel = i
    rebuild(playhead)
}

internal fun VideoEditActivity.deleteSel() {
    if (selO in ovs.indices) {
        pushHistory()
        releaseOverlays()
        ovs.removeAt(selO)
        selO = -1
        rebuildOverlays()
        pushTimeline()
        return
    }
    if (selA in segs.indices) {
        pushHistory()
        segs.removeAt(selA)
        selA = -1
        curSeg = -1
        audioPlayer?.pause()
        if (segs.isEmpty()) clearSong()
        pushTimeline()
        return
    }
    if (sel !in clips.indices) {
        toast("Ketuk bagian di timeline yang mau dihapus.")
        return
    }
    if (clips.size == 1) {
        toast("Minimal harus ada satu bagian.")
        return
    }
    pushHistory()
    var before = 0L
    for (k in 0 until sel) before += clips[k].dur()
    clips.removeAt(sel)
    sel = -1
    rebuild(before)
}

internal fun VideoEditActivity.moveSel(dir: Int) {
    if (selO in ovs.indices) {
        pendingHistory = true
        ovEdit(selO, TimelineView.MODE_MOVE, ovs[selO].start + dir * 100L)
        return
    }
    if (selA in segs.indices) {
        pendingHistory = true
        audioEdit(selA, TimelineView.MODE_MOVE, segs[selA].start + dir * 100L)
        return
    }
    if (sel !in clips.indices) {
        toast("Ketuk bagian di timeline dulu.")
        return
    }
    val j = sel + dir
    if (j !in clips.indices) {
        toast(if (dir < 0) "Sudah paling kiri." else "Sudah paling kanan.")
        return
    }
    pushHistory()
    val c = clips.removeAt(sel)
    clips.add(j, c)
    sel = j
    var before = 0L
    for (k in 0 until j) before += clips[k].dur()
    rebuild(before)
}

internal fun VideoEditActivity.speedDialog() {
    if (selO in ovs.indices) {
        toast("Kecepatan lapisan belum tersedia.")
        return
    }
    if (selA in segs.indices) {
        toast("Kecepatan hanya untuk video.")
        return
    }
    if (sel !in clips.indices) {
        toast("Ketuk bagian di timeline dulu.")
        return
    }
    val c = clips[sel]
    if (c.photo) {
        photoDurationDialog(c)
        return
    }
    val steps = floatArrayOf(0.25f, 0.5f, 0.75f, 1f, 1.5f, 2f, 3f, 4f)
    Sheet.custom(this, "Kecepatan") { p, close ->
        val tv = TextView(this)
        tv.textSize = 28f
        tv.gravity = Gravity.CENTER
        tv.setTextColor(Color.WHITE)
        val sb = SeekBar(this)
        sb.max = steps.size - 1
        sb.progress = steps.indexOfFirst { it == c.speed }.let { if (it < 0) 3 else it }
        tv.text = TimelineView.fmtSpeed(steps[sb.progress])
        sb.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, v: Int, fromUser: Boolean) {
                tv.text = TimelineView.fmtSpeed(steps[v])
            }

            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })
        p.addView(tv)
        p.addView(sb, LinearLayout.LayoutParams(-1, -2).apply { setMargins(dp(12), dp(8), dp(12), dp(8)) })
        p.addView(
            Sheet.buttonRow(
                this,
                Sheet.button(this, "Batal", false) { close() },
                Sheet.button(this, "Terapkan", true) {
                    val v = steps[sb.progress]
                    close()
                    if (v != c.speed) {
                        pushHistory()
                        c.speed = v
                        c.clampFades()
                        rebuild(playhead)
                    }
                }
            )
        )
    }
}

internal fun VideoEditActivity.photoDurationDialog(c: Clip) {
    Sheet.custom(this, "Durasi foto") { p, close ->
        val tv = TextView(this)
        tv.textSize = 28f
        tv.gravity = Gravity.CENTER
        tv.setTextColor(Color.WHITE)
        val sb = SeekBar(this)
        sb.max = 19
        sb.progress = ((c.photoMs / 500L).toInt() - 1).coerceIn(0, 19)
        fun sec(v: Int) = String.format(Locale.US, "%.1f detik", (v + 1) * 0.5)
        tv.text = sec(sb.progress)
        sb.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, v: Int, fromUser: Boolean) {
                tv.text = sec(v)
            }

            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })
        p.addView(tv)
        p.addView(sb, LinearLayout.LayoutParams(-1, -2).apply { setMargins(dp(12), dp(8), dp(12), dp(8)) })
        p.addView(
            Sheet.buttonRow(
                this,
                Sheet.button(this, "Batal", false) { close() },
                Sheet.button(this, "Terapkan", true) {
                    val ms = (sb.progress + 1) * 500L
                    close()
                    if (ms != c.photoMs) {
                        pushHistory()
                        c.photoMs = ms
                        rebuild(playhead)
                    }
                }
            )
        )
    }
}

internal fun VideoEditActivity.pickSong() {
    lifecycleScope.launch {
        val list = withContext(Dispatchers.IO) { Library.audios(this@pickSong) }
        if (list.isEmpty()) {
            toast("Belum ada lagu di HP (atau izin musik belum diberikan).")
            return@launch
        }
        Sheet.pickList(
            this@pickSong, "Pilih lagu",
            list.map { it.title }, list.map { it.artist }, R.drawable.ic_music_note
        ) { i -> setSong(list[i]) }
    }
}

internal fun VideoEditActivity.setSong(t: Library.Track) {
    pushHistory()
    audioPlayer?.release()
    song = t.uri
    songDur = t.durationMs
    val tot = total()
    val start = if (tot - playhead < 1000L) 0L else playhead
    val len = minOf(t.durationMs, (tot - start).coerceAtLeast(300L))
    segs = arrayListOf(Seg(start, 0L, len))
    selA = 0
    sel = -1
    curSeg = -1
    val a = ExoPlayer.Builder(this).build()
    a.setMediaItem(MediaItem.fromUri(t.uri))
    a.volume = songVol
    a.prepare()
    audioPlayer = a
    pushTimeline()
}

internal fun VideoEditActivity.clearSong() {
    audioPlayer?.release()
    audioPlayer = null
    song = null
    segs.clear()
    selA = -1
    curSeg = -1
}

/** Ubah satu potongan lagu dari tarikan di timeline. Potongan tidak boleh saling menimpa. */
internal fun VideoEditActivity.audioEdit(i: Int, mode: Int, ms: Long) {
    val s = segs.getOrNull(i) ?: return
    commitPending()
    val tot = total()
    val prevEnd = if (i > 0) segs[i - 1].end() else 0L
    val nextStart = if (i < segs.lastIndex) segs[i + 1].start else tot
    when (mode) {
        TimelineView.MODE_L -> {
            val minStart = maxOf(prevEnd, s.start - s.from)
            val ns = clampTo(ms, minStart, s.end() - 300L)
            val d = ns - s.start
            s.start = ns
            s.from += d
            s.clampFades()
        }
        TimelineView.MODE_R -> {
            val maxEnd = minOf(nextStart, s.start + (songDur - s.from))
            val ne = clampTo(ms, s.start + 300L, maxEnd)
            s.to = s.from + (ne - s.start)
            s.clampFades()
        }
        TimelineView.MODE_MOVE -> {
            val len = s.len()
            s.start = clampTo(ms, prevEnd, nextStart - len)
        }
        TimelineView.MODE_FIN -> s.fadeIn = snapFade(ms).coerceIn(0L, s.len() - s.fadeOut)
        TimelineView.MODE_FOUT -> s.fadeOut = snapFade(ms).coerceIn(0L, s.len() - s.fadeIn)
    }
    pushTimeline()
}

internal fun VideoEditActivity.editItem(kind: Int, i: Int, mode: Int, ms: Long) {
    when (kind) {
        TimelineView.K_AUDIO -> audioEdit(i, mode, ms)
        TimelineView.K_OV -> ovEdit(i, mode, ms)
        TimelineView.K_MAIN -> mainEdit(i, mode, ms)
    }
}

/** Titik lekuk di kurva pudar ditarik bebas; garis kurva menyesuaikan dan tetap halus. */
internal fun VideoEditActivity.bendItem(kind: Int, i: Int, isIn: Boolean, x: Float, y: Float) {
    val f = fadableOf(kind, i) ?: return
    commitPending()
    if (isIn) {
        f.inX = x
        f.inY = y
    } else {
        f.outX = x
        f.outY = y
    }
    pushTimeline()
}

/** Video utama: pudar, dan potong awal/akhir dengan handle (klip sesudahnya ikut bergeser). */
internal fun VideoEditActivity.mainEdit(i: Int, mode: Int, ms: Long) {
    val c = clips.getOrNull(i) ?: return
    commitPending()
    val minSrc = (300L * c.speed).toLong()
    when (mode) {
        TimelineView.MODE_FIN -> c.fadeIn = snapFade(ms).coerceIn(0L, c.dur() - c.fadeOut)
        TimelineView.MODE_FOUT -> c.fadeOut = snapFade(ms).coerceIn(0L, c.dur() - c.fadeIn)
        TimelineView.MODE_TRIM_L -> {
            if (c.photo) c.photoMs = (c.photoMs - ms).coerceIn(300L, 120000L)
            else c.start = clampTo(c.start + (ms * c.speed).toLong(), 0L, c.end - minSrc)
            c.clampFades()
            needRebuild = true
        }
        TimelineView.MODE_TRIM_R -> {
            if (c.photo) c.photoMs = (c.photoMs + ms).coerceIn(300L, 120000L)
            else c.end = clampTo(c.end + (ms * c.speed).toLong(), c.start + minSrc, c.srcDur)
            c.clampFades()
            needRebuild = true
        }
    }
    pushTimeline()
}

/** Lapisan video: potong, geser, pudar. Posisi absolut di timeline. */
internal fun VideoEditActivity.ovEdit(i: Int, mode: Int, ms: Long) {
    val o = ovs.getOrNull(i) ?: return
    commitPending()
    val tot = total()
    when (mode) {
        TimelineView.MODE_L -> {
            val minStart = if (o.photo) 0L else maxOf(0L, o.start - (o.srcStart / o.speed).toLong())
            val ns = clampTo(ms, minStart, o.start + o.dur() - 300L)
            val d = ns - o.start
            if (o.photo) o.photoMs -= d else o.srcStart += (d * o.speed).toLong()
            o.start = ns
            o.clampFades()
            needOvRebuild = true
        }
        TimelineView.MODE_R -> {
            val srcRoom = if (o.photo) Long.MAX_VALUE / 4 else o.start + ((o.srcDur - o.srcStart) / o.speed).toLong()
            val ne = clampTo(ms, o.start + 300L, minOf(tot, srcRoom))
            if (o.photo) o.photoMs = ne - o.start else o.srcEnd = o.srcStart + ((ne - o.start) * o.speed).toLong()
            o.clampFades()
            needOvRebuild = true
        }
        TimelineView.MODE_MOVE -> o.start = clampTo(ms, 0L, maxOf(0L, tot - o.dur()))
        TimelineView.MODE_FIN -> o.fadeIn = snapFade(ms).coerceIn(0L, o.dur() - o.fadeOut)
        TimelineView.MODE_FOUT -> o.fadeOut = snapFade(ms).coerceIn(0L, o.dur() - o.fadeIn)
    }
    pushTimeline()
}

internal fun VideoEditActivity.volumeDialog() {
    Sheet.custom(this, "Suara") { p, close ->
        fun slider(name: String, start: Float, enabled: Boolean): SeekBar {
            val t = TextView(this)
            t.text = name
            t.textSize = 12f
            t.setTextColor(clr(R.color.muted))
            t.setPadding(dp(14), dp(6), dp(14), 0)
            p.addView(t)
            val sb = SeekBar(this)
            sb.max = 100
            sb.progress = (start * 100).toInt()
            sb.isEnabled = enabled
            p.addView(sb, LinearLayout.LayoutParams(-1, -2).apply { setMargins(dp(12), dp(4), dp(12), dp(8)) })
            return sb
        }
        val a = slider("Suara video asli", origVol, true)
        val b = slider(if (song == null) "Lagu (belum ada lagu)" else "Lagu", songVol, song != null)
        p.addView(
            Sheet.buttonRow(
                this,
                Sheet.button(this, "Batal", false) { close() },
                Sheet.button(this, "Terapkan", true) {
                    origVol = a.progress / 100f
                    songVol = b.progress / 100f
                    player.volume = origVol
                    audioPlayer?.volume = songVol
                    close()
                }
            )
        )
    }
}

internal fun VideoEditActivity.askLeave() {
    if (exporting) return
    if (history.isEmpty() && song == null && ovs.isEmpty()) {
        finish()
        return
    }
    Sheet.confirm(this, "Keluar dari editor?", "Perubahan yang belum disimpan akan hilang.", "Keluar", true) {
        finish()
    }
}

internal fun VideoEditActivity.askSave() {
    if (clips.isEmpty() || exporting) return
    player.pause()
    Sheet.choice(
        this, "Simpan hasil edit", "Resolusi dan bitrate mengikuti video asli.",
        listOf(
            "Simpan sebagai video baru" to "Video asli tetap ada",
            "Timpa video asli" to "Video asli diganti"
        ),
        0
    ) { i ->
        if (i == 0) {
            export(false)
        } else {
            Sheet.confirm(
                this, "Timpa video asli?",
                "Video asli akan diganti hasil edit dan tidak bisa dikembalikan.", "Timpa", true
            ) { export(true) }
        }
    }
}
