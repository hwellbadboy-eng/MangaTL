package com.niven.mangatl

import android.content.Context
import android.content.DialogInterface
import android.text.InputType
import android.widget.EditText
import android.widget.LinearLayout
import androidx.appcompat.app.AlertDialog

/** Dialog tambah / ubah / hapus situs buatan sendiri. Dipakai popup login (grid) dan Menu situs di bubble. */
object SiteDialogs {
    /** [old] null = tambah situs baru; selain itu ubah situs tsb (ada tombol Hapus). [onDone] menerima pesan singkat. */
    fun edit(ctx: Context, old: LoginSite?, onDone: (String) -> Unit) {
        val d = ctx.resources.displayMetrics.density
        fun dp(v: Int) = (v * d).toInt()
        val box = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(8), dp(20), 0)
        }
        val etName = EditText(ctx).apply {
            hint = "Nama (mis. Bilibili)"
            setSingleLine(true)
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_CAP_WORDS
            setText(old?.label.orEmpty())
        }
        val etLink = EditText(ctx).apply {
            hint = "Link login (mis. bilibili.com/login)"
            setSingleLine(true)
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_URI
            setText(old?.loginUrl.orEmpty())
        }
        box.addView(etName)
        box.addView(etLink)
        val b = AlertDialog.Builder(ctx)
            .setTitle(if (old == null) "Tambah situs" else "Ubah situs")
            .setView(box)
            .setNegativeButton("Batal", null)
            .setPositiveButton("Simpan", null)
        if (old != null) {
            b.setNeutralButton("Hapus") { _, _ ->
                CustomSites.remove(ctx, old.key)
                Favicons.forget(old.key)
                BubbleSites.setHidden(ctx, old.key, false)
                onDone("${old.label} dihapus dari daftar")
            }
        }
        val dlg = b.create()
        dlg.setOnShowListener {
            // Simpan tidak menutup dialog kalau isian salah, supaya tidak perlu mengetik ulang
            dlg.getButton(DialogInterface.BUTTON_POSITIVE).setOnClickListener {
                val name = etName.text.toString()
                val link = etLink.text.toString()
                val err = if (old == null) CustomSites.add(ctx, name, link) else CustomSites.update(ctx, old.key, name, link)
                if (err != null) {
                    etLink.error = err
                } else {
                    if (old != null) {
                        Favicons.forget(old.key)
                        BubbleSites.setHidden(ctx, old.key, false)
                    }
                    dlg.dismiss()
                    onDone(if (old == null) "Situs ditambah" else "Situs diubah")
                }
            }
        }
        dlg.show()
    }
}
