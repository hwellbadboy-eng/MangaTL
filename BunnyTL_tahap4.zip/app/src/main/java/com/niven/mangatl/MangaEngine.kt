package com.niven.mangatl

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.Path
import android.graphics.Point
import android.graphics.Rect
import android.graphics.RectF
import android.graphics.Typeface
import android.net.Uri
import android.text.Layout
import android.text.StaticLayout
import android.text.TextPaint
import com.google.android.gms.tasks.Tasks
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.Text
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.TextRecognizer
import com.google.mlkit.vision.text.chinese.ChineseTextRecognizerOptions
import com.google.mlkit.vision.text.japanese.JapaneseTextRecognizerOptions
import com.google.mlkit.vision.text.korean.KoreanTextRecognizerOptions
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import java.io.File
import java.util.Locale
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream

/**
 * Mesin Manga Translator: impor halaman (gambar / CBZ / ZIP), baca teks (ML Kit per bahasa),
 * gabungkan blok satu balon, tutup teks asli dengan warna latar, tulis terjemahan Indonesia.
 * Penerjemahnya sendiri (Gemma) dipanggil lewat lambda supaya mesin ini tidak bergantung ke model.
 */
object MangaEngine {

    val LANG_LABELS = listOf("Jepang (manga)", "Korea (manhwa)", "Mandarin (manhua)", "Inggris")
    val LANG_PROMPT = listOf("Japanese", "Korean", "Chinese", "English")

    private const val STRIP_H = 1800

    /** Font terjemahan. Default Comic Relief Bold (gaya komik/scanlation, lisensi OFL, ada di assets/fonts). */
    private const val DEFAULT_FONT = "ComicRelief-Bold.ttf"
    private var dialogFace: Typeface? = null

    /** Daftar font yang bisa dipilih di menu Manga Translator: (nama file di assets/fonts, nama tampil, keterangan). */
    val FONTS = listOf(
        Triple("ComicRelief-Bold.ttf", "Comic Relief Bold", "Gaya komik umum, bulat dan mudah dibaca (default)"),
        Triple("ComicNeue-Bold.ttf", "Comic Neue Bold", "Komik yang lebih ramping, muat banyak teks di balon kecil"),
        Triple("Bangers-Regular.ttf", "Bangers", "Tebal ala teriakan/efek suara, cocok untuk aksi"),
        Triple("system", "Font sistem HP", "Font bawaan HP, paling netral")
    )

    /** Mode huruf: 0 kapital semua (konsisten), 1 huruf biasa (konsisten), 2 otomatis (kapital, balon sempit pindah ke huruf biasa). */
    val CASE_LABELS = listOf(
        "Kapital semua (semua balon sama)",
        "Huruf biasa (semua balon sama)",
        "Otomatis (balon sempit pakai huruf biasa, bisa kelihatan campur)"
    )

    /** Muat Typeface dari nama file di FONTS. Gagal dimuat = font sistem tebal. */
    fun loadFace(context: Context, name: String): Typeface {
        val sys = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        if (name == "system") return sys
        return try { Typeface.createFromAsset(context.applicationContext.assets, "fonts/$name") } catch (_: Throwable) { sys }
    }

    /** Gaya lettering manhwa: huruf kapital + miring. Diatur lewat menu Manga Translator (SharedPreferences "manga"). */
    private var caseMode = 0
    private var capsOn = true
    private var italicOn = true

    fun caseModePref(context: Context): Int {
        val sp = context.getSharedPreferences("manga", Context.MODE_PRIVATE)
        // Pengaturan lama "caps": false = huruf biasa; selain itu kapital konsisten (bukan lagi campur otomatis).
        return sp.getInt("case_mode", if (sp.getBoolean("caps", true)) 0 else 1).coerceIn(0, 2)
    }

    /**
     * Muat font terjemahan sekali sebelum render. Pilihan disimpan di SharedPreferences "manga" kunci "font"
     * (lihat FONTS). Kalau file font gagal dimuat, otomatis kembali ke font sistem tebal supaya render tidak pernah gagal.
     */
    fun initFonts(context: Context) {
        val sp = context.getSharedPreferences("manga", Context.MODE_PRIVATE)
        val name = sp.getString("font", DEFAULT_FONT) ?: DEFAULT_FONT
        caseMode = caseModePref(context)
        capsOn = caseMode != 1
        italicOn = sp.getBoolean("italic", true)
        dialogFace = loadFace(context, name)
    }

    /** Huruf terjemahan paling besar = tinggi huruf asli x angka ini (cegah teks raksasa & ukuran beda dalam satu balon). */
    private const val SIZE_CAP = 1.35f

    /** Sudut minimum (derajat) supaya teks dianggap miring dan terjemahannya diputar. */
    private const val TILT_MIN = 2f
    private val IMAGE_EXT = setOf("jpg", "jpeg", "png", "webp")

    // ------------------------------------------------------------------ folder & berkas

    fun root(ctx: Context): File = File(ctx.getExternalFilesDir(null), "manga").also { it.mkdirs() }

    fun srcDir(work: File) = File(work, "src")

    fun outDir(work: File) = File(work, "out")

    fun isImageName(name: String): Boolean =
        name.substringAfterLast('.', "").lowercase(Locale.ROOT) in IMAGE_EXT

    fun naturalCompare(a: String, b: String): Int {
        val re = Regex("\\d+|\\D+")
        val ra = re.findAll(a.lowercase(Locale.ROOT)).map { it.value }.toList()
        val rb = re.findAll(b.lowercase(Locale.ROOT)).map { it.value }.toList()
        for (i in 0 until minOf(ra.size, rb.size)) {
            val x = ra[i]
            val y = rb[i]
            val c = if (x[0].isDigit() && y[0].isDigit()) {
                val lx = x.trimStart('0')
                val ly = y.trimStart('0')
                if (lx.length != ly.length) lx.length.compareTo(ly.length) else lx.compareTo(ly)
            } else {
                x.compareTo(y)
            }
            if (c != 0) return c
        }
        return ra.size.compareTo(rb.size)
    }

    /** Halaman sumber, terurut alami (1, 2, 10 bukan 1, 10, 2). */
    fun pages(work: File): List<File> =
        srcDir(work).listFiles()
            ?.filter { it.isFile && isImageName(it.name) }
            ?.sortedWith { a, b -> naturalCompare(a.name, b.name) }
            ?: emptyList()

    fun doneCount(work: File): Int =
        outDir(work).listFiles()?.count { it.isFile && it.name.endsWith(".jpg") } ?: 0

    fun outFile(work: File, index: Int) = File(outDir(work), "%04d.jpg".format(Locale.US, index + 1))

    /** Halaman untuk dibaca/ekspor: hasil terjemahan; kalau belum ada / gagal, pakai gambar asli. */
    fun readPages(work: File): List<File> =
        pages(work).mapIndexed { i, f -> outFile(work, i).takeIf { it.exists() } ?: f }

    /** Salin satu gambar, atau isi satu CBZ/ZIP, ke folder src. Kembalikan jumlah gambar yang masuk. */
    fun importUri(ctx: Context, work: File, uri: Uri, displayName: String, idx: Int): Int {
        val dir = srcDir(work)
        dir.mkdirs()
        // Berkas kosong (0 byte) sisa impor yang gagal dibuang, supaya bisa disalin ulang.
        dir.listFiles()?.filter { it.isFile && it.length() == 0L }?.forEach { it.delete() }
        val existing = dir.listFiles()?.map { it.name.substringAfter('_') }?.toHashSet() ?: hashSetOf()
        val lower = displayName.lowercase(Locale.ROOT)
        fun safeName(n: String) = n.replace('/', '_').replace('\\', '_')

        if (lower.endsWith(".zip") || lower.endsWith(".cbz")) {
            // Baca lewat daftar isi (ZipFile) pada salinan sementara: lebih andal daripada ZipInputStream
            // untuk CBZ yang ukuran entri-nya baru tercatat di akhir berkas.
            val tmp = File(ctx.externalCacheDir ?: ctx.cacheDir, "import_${System.nanoTime()}.zip")
            try {
                ctx.contentResolver.openInputStream(uri)?.use { input -> tmp.outputStream().use { input.copyTo(it) } }
                var n = 0
                java.util.zip.ZipFile(tmp).use { zf ->
                    for (e in zf.entries().toList()) {
                        val leaf = e.name.substringAfterLast('/')
                        if (e.isDirectory || !isImageName(e.name) || leaf.startsWith(".")) continue
                        val safe = safeName(e.name)
                        if (safe !in existing) {
                            val f = File(dir, "%03d_%s".format(Locale.US, idx, safe))
                            zf.getInputStream(e).use { i -> f.outputStream().use { i.copyTo(it) } }
                            if (f.length() == 0L) { f.delete(); continue }
                        }
                        n++
                    }
                }
                return n
            } finally {
                tmp.delete()
            }
        }
        if (isImageName(displayName)) {
            val safe = safeName(displayName)
            if (safe in existing) return 1
            val f = File(dir, "%03d_%s".format(Locale.US, idx, safe))
            ctx.contentResolver.openInputStream(uri)?.use { input -> f.outputStream().use { input.copyTo(it) } }
            if (f.length() == 0L) { f.delete(); return 0 }
            return 1
        }
        return 0
    }

    fun exportCbz(work: File, target: File): Int {
        val files = readPages(work)
        ZipOutputStream(target.outputStream().buffered()).use { zos ->
            files.forEachIndexed { i, f ->
                zos.putNextEntry(ZipEntry("%04d.%s".format(Locale.US, i + 1, f.extension.lowercase(Locale.ROOT))))
                f.inputStream().use { it.copyTo(zos) }
                zos.closeEntry()
            }
        }
        return files.size
    }

    // ------------------------------------------------------------------ OCR

    class Block(
        val rect: Rect,
        val text: String,
        val angle: Float = 0f,
        val pts: List<Point> = emptyList(),
        /** Tinggi huruf asli (median tinggi baris OCR, piksel gambar asli). 0 = tidak diketahui. */
        val lineH: Int = 0
    )

    fun recognizer(lang: Int): TextRecognizer = when (lang) {
        0 -> TextRecognition.getClient(JapaneseTextRecognizerOptions.Builder().build())
        1 -> TextRecognition.getClient(KoreanTextRecognizerOptions.Builder().build())
        2 -> TextRecognition.getClient(ChineseTextRecognizerOptions.Builder().build())
        else -> TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
    }

    private fun hasCjk(s: String) = s.any { it.isLetter() && it.code >= 0x2E80 }

    private fun usable(s: String): Boolean {
        val letters = s.count { it.isLetter() }
        return letters >= 2 || (letters >= 1 && hasCjk(s))
    }

    /** Dekode gambar jadi bitmap yang bisa digambar; dikecilkan kalau terlalu besar. */
    fun decode(file: File): Bitmap? {
        val o = BitmapFactory.Options()
        o.inJustDecodeBounds = true
        BitmapFactory.decodeFile(file.path, o)
        if (o.outWidth <= 0 || o.outHeight <= 0) return null
        var sample = 1
        while (o.outWidth / sample > 2400 ||
            (o.outWidth / sample).toLong() * (o.outHeight / sample) > 20_000_000L
        ) sample *= 2
        val o2 = BitmapFactory.Options()
        o2.inSampleSize = sample
        o2.inMutable = true
        o2.inPreferredConfig = Bitmap.Config.ARGB_8888
        return BitmapFactory.decodeFile(file.path, o2)
    }

    /** Ada garis pembatas (tepi balon/kotak) yang melintang di strip ini? Strip = celah antara dua baris teks. */
    private fun hasSeparator(img: Bitmap, x0: Int, x1: Int, y0: Int, y1: Int): Boolean {
        val xs = maxOf(0, x0)
        val ys = maxOf(0, y0)
        val w = minOf(img.width, x1) - xs
        val h = minOf(img.height, y1) - ys
        if (w < 8 || h < 5) return false
        val px = IntArray(w * h)
        img.getPixels(px, 0, w, xs, ys, w, h)
        val lum = IntArray(w * h) { (Color.red(px[it]) * 299 + Color.green(px[it]) * 587 + Color.blue(px[it]) * 114) / 1000 }
        val med = lum.sorted()[lum.size / 2]
        var high = 0
        for (row in 0 until h) {
            var cnt = 0
            for (x in 0 until w) if (Math.abs(lum[row * w + x] - med) > 80) cnt++
            if (cnt >= 0.85f * w) high++
        }
        // Garis tepi balon = beberapa baris tipis yang hampir penuh; pita teks tidak dihitung.
        return high in 1..maxOf(4, h / 3)
    }

    /**
     * Kelompokkan baris-baris teks ke dalam balon/kotak yang sama: bertumpuk rapat, kolom sejajar,
     * tinggi huruf mirip, dan tidak ada garis tepi balon di antaranya.
     */
    private class Geo(val cx: Float, val cy: Float, val w: Float, val h: Float, val ang: Float)

    /** Geometri baris dari titik sudutnya (ikut kemiringan). Null kalau ML Kit tidak memberi titik sudut. */
    private fun geoOf(l: Text.Line): Geo? {
        val cp = l.cornerPoints
        if (cp == null || cp.size != 4) return null
        val w = Math.hypot((cp[1].x - cp[0].x).toDouble(), (cp[1].y - cp[0].y).toDouble()).toFloat()
        val h = Math.hypot((cp[3].x - cp[0].x).toDouble(), (cp[3].y - cp[0].y).toDouble()).toFloat()
        val ang = Math.toDegrees(Math.atan2((cp[1].y - cp[0].y).toDouble(), (cp[1].x - cp[0].x).toDouble())).toFloat()
        return Geo(cp.sumOf { it.x } / 4f, cp.sumOf { it.y } / 4f, w, h, ang)
    }

    private fun clusterLines(img: Bitmap, lines: List<Text.Line>, dbg: StringBuilder?): List<List<Text.Line>> {
        val ls = lines.filter { it.boundingBox != null }
        val n = ls.size
        val parent = IntArray(n) { it }
        fun find(x: Int): Int {
            var r = x
            while (parent[r] != r) r = parent[r]
            var c = x
            while (parent[c] != r) { val nx = parent[c]; parent[c] = r; c = nx }
            return r
        }
        val geos = ls.map { geoOf(it) }
        for (i in 0 until n) for (j in i + 1 until n) {
            val ga = geos[i]
            val gb = geos[j]
            if (ga != null && gb != null && (Math.abs(ga.ang) >= TILT_MIN || Math.abs(gb.ang) >= TILT_MIN)) {
                // Teks miring: bandingkan di bingkai yang ikut kemiringan, bukan di kotak sumbu-X yang membengkak.
                if (Math.abs(ga.ang - gb.ang) > 6f) continue
                val th = Math.toRadians(((ga.ang + gb.ang) / 2f).toDouble())
                val cs = Math.cos(th).toFloat()
                val sn = Math.sin(th).toFloat()
                val ax = ga.cx * cs + ga.cy * sn
                val ay = -ga.cx * sn + ga.cy * cs
                val bx = gb.cx * cs + gb.cy * sn
                val by = -gb.cx * sn + gb.cy * cs
                val lhR = minOf(ga.h, gb.h).coerceAtLeast(1f)
                if (maxOf(ga.h, gb.h) > 2.2f * lhR) continue
                val gapR = Math.abs(ay - by) - (ga.h + gb.h) / 2f
                if (gapR < -0.5f * lhR || gapR > 0.7f * maxOf(ga.h, gb.h)) continue
                val oxR = minOf(ax + ga.w / 2f, bx + gb.w / 2f) - maxOf(ax - ga.w / 2f, bx - gb.w / 2f)
                if (oxR < 0.4f * minOf(ga.w, gb.w)) continue
                val wMaxR = maxOf(ga.w, gb.w)
                val alignedR = Math.abs(ax - bx) <= 0.3f * wMaxR ||
                    Math.abs((ax - ga.w / 2f) - (bx - gb.w / 2f)) <= 0.6f * lhR ||
                    Math.abs((ax + ga.w / 2f) - (bx + gb.w / 2f)) <= 0.6f * lhR
                if (!alignedR) continue
                dbg?.append("  GABUNG(miring) [${ls[i].text.take(20)}] + [${ls[j].text.take(20)}] gap=${gapR.toInt()}\n")
                val rA = find(i)
                val rB = find(j)
                if (rA != rB) parent[rB] = rA
                continue
            }
            val a = ls[i].boundingBox!!
            val b = ls[j].boundingBox!!
            val lh = minOf(a.height(), b.height()).coerceAtLeast(1)
            if (maxOf(a.height(), b.height()) > 2.2f * lh) continue
            val gap = maxOf(a.top, b.top) - minOf(a.bottom, b.bottom)
            if (gap < -0.5f * lh || gap > 0.7f * maxOf(a.height(), b.height())) continue
            val ox = minOf(a.right, b.right) - maxOf(a.left, b.left)
            if (ox < 0.4f * minOf(a.width(), b.width())) continue
            val wMax = maxOf(a.width(), b.width())
            val aligned = Math.abs(a.centerX() - b.centerX()) <= 0.3f * wMax ||
                Math.abs(a.left - b.left) <= 0.6f * lh || Math.abs(a.right - b.right) <= 0.6f * lh
            if (!aligned) continue
            if (gap >= 6 && hasSeparator(img, maxOf(a.left, b.left), minOf(a.right, b.right), minOf(a.bottom, b.bottom), maxOf(a.top, b.top))) {
                dbg?.append("  PISAH(garis pembatas) [${ls[i].text.take(20)}] | [${ls[j].text.take(20)}] gap=$gap\n")
                continue
            }
            dbg?.append("  GABUNG [${ls[i].text.take(20)}] + [${ls[j].text.take(20)}] gap=$gap ox=$ox lh=$lh\n")
            val ra = find(i)
            val rb = find(j)
            if (ra != rb) parent[rb] = ra
        }
        val groups = LinkedHashMap<Int, MutableList<Text.Line>>()
        for (i in 0 until n) groups.getOrPut(find(i)) { mutableListOf() }.add(ls[i])
        return groups.values.map { g -> g.sortedWith(compareBy({ it.boundingBox!!.top }, { it.boundingBox!!.left })) }
    }


    /**
     * Baca teks per potongan tinggi. Gambar kecil diperbesar dulu (teks kecil sering lolos OCR).
     * Potongan sengaja saling tumpang tindih supaya teks di garis potong tidak terbelah; duplikat dibuang.
     */
    private fun readBlocks(rec: TextRecognizer, bmp: Bitmap, lang: Int, dbg: StringBuilder? = null): List<Block> {
        val all = ArrayList<Block>()
        val joiner = if (lang == 0 || lang == 2) "" else " "
        val scale = when {
            bmp.width <= 1100 -> 2f
            bmp.width <= 1700 -> 1.5f
            else -> 1f
        }
        val stripH = (STRIP_H / scale).toInt()
        val overlap = 160
        var y = 0
        while (true) {
            var h = minOf(stripH, bmp.height - y)
            if (bmp.height - (y + h) in 1..300) h = bmp.height - y
            val strip = Bitmap.createBitmap(bmp, 0, y, bmp.width, h)
            val big = if (scale == 1f) strip
            else Bitmap.createScaledBitmap(strip, (bmp.width * scale).toInt(), (h * scale).toInt(), true)
            try {
                val t = Tasks.await(rec.process(InputImage.fromBitmap(big, 0)))
                // Teks horizontal: kelompokkan ulang per BARIS (blok ML Kit sering memecah satu balon jadi banyak potongan).
                val groupList: List<List<Text.Line>> =
                    if (lang == 0) t.textBlocks.map { it.lines }
                    else clusterLines(big, t.textBlocks.flatMap { it.lines }, dbg)
                run {
                    for (g in groupList) {
                        val box = Rect()
                        var first = true
                        for (ln in g) {
                            val lb = ln.boundingBox ?: continue
                            if (first) { box.set(lb); first = false } else box.union(lb)
                        }
                        if (first) continue
                        val txt = g.joinToString(joiner) { it.text.trim() }.trim()
                        if (!usable(txt)) continue
                        val pts = ArrayList<Point>()
                        val angs = ArrayList<Pair<Double, Double>>()
                        for (ln in g) {
                            val cp = ln.cornerPoints
                            if (cp != null && cp.size == 4) {
                                for (p in cp) pts.add(Point((p.x / scale).toInt(), (p.y / scale).toInt() + y))
                                val dx = (cp[1].x - cp[0].x).toDouble()
                                val dy = (cp[1].y - cp[0].y).toDouble()
                                angs.add(Pair(Math.toDegrees(Math.atan2(dy, dx)), Math.hypot(dx, dy)))
                            }
                        }
                        val hs = g.mapNotNull { it.boundingBox?.height() }.sorted()
                        val lineH = if (lang == 0 || hs.isEmpty()) 0 else (hs[hs.size / 2] / scale).toInt()
                        val ang0 = weightedMedian(angs)
                        val rectOrig = Rect(
                            (box.left / scale).toInt(), (box.top / scale).toInt() + y,
                            (box.right / scale).toInt(), (box.bottom / scale).toInt() + y
                        )
                        val tilted = lang != 0 && pts.size >= 4 && Math.abs(ang0) >= TILT_MIN && Math.abs(ang0) <= 60f
                        // Sudut ML Kit untuk baris pendek sering meleset; perhalus dari piksel gambar asli.
                        val ang = if (tilted) refineAngle(bmp, rectOrig, ang0) else ang0
                        val tiltedFinal = tilted && Math.abs(ang) >= TILT_MIN
                        all.add(
                            Block(
                                rectOrig, txt, if (tiltedFinal) ang else 0f, if (tiltedFinal) pts else emptyList(), lineH
                            )
                        )
                    }
                }
            } finally {
                if (big !== strip) big.recycle()
                if (strip !== bmp) strip.recycle()
            }
            if (y + h >= bmp.height) break
            y += maxOf(1, h - overlap)
        }
        if (all.size < 2) return all.map { reReadTilted(rec, bmp, it, lang, scale, dbg) }
        // Buang duplikat dari area tumpang tindih: simpan yang teksnya paling lengkap.
        val kept = ArrayList<Block>()
        for (b in all.sortedByDescending { it.text.length }) {
            val dup = kept.any { k ->
                val ix = minOf(k.rect.right, b.rect.right) - maxOf(k.rect.left, b.rect.left)
                val iy = minOf(k.rect.bottom, b.rect.bottom) - maxOf(k.rect.top, b.rect.top)
                if (ix <= 0 || iy <= 0) false
                else ix.toLong() * iy > 0.5 * minOf(k.rect.width().toLong() * k.rect.height(), b.rect.width().toLong() * b.rect.height())
            }
            if (!dup) kept.add(b)
        }
        return kept.map { reReadTilted(rec, bmp, it, lang, scale, dbg) }
    }

    /**
     * Teks miring sering terbaca terpotong ("Meat was real cheap today so I'm" hanya terbaca "o I'm").
     * Luruskan potongan gambar di sekitar blok miring, baca ulang, dan pakai hasilnya kalau lebih lengkap.
     * Titik sudut baris hasil baca ulang dipetakan balik ke gambar asli supaya penghapusan teks ikut menutup baris yang tadi terlewat.
     * Kalau apa pun gagal, blok lama dipakai apa adanya.
     */
    private fun reReadTilted(rec: TextRecognizer, bmp: Bitmap, b: Block, lang: Int, scale: Float, dbg: StringBuilder?): Block {
        if (lang == 0 || b.angle == 0f || b.pts.size < 4) return b
        try {
            val padX = maxOf(20, b.rect.width() / 4)
            val padY = maxOf(20, b.rect.height() / 2)
            val sub = clampRect(Rect(b.rect.left - padX, b.rect.top - padY, b.rect.right + padX, b.rect.bottom + padY), bmp)
            val w = sub.width()
            val h = sub.height()
            if (w < 30 || h < 20 || w.toLong() * h > 1_500_000L) return b
            val m = Matrix()
            m.postRotate(-b.angle, w / 2f, h / 2f)
            m.postScale(scale, scale)
            val dev = RectF(0f, 0f, w.toFloat(), h.toFloat())
            m.mapRect(dev)
            val rot = Bitmap.createBitmap(bmp, sub.left, sub.top, w, h, m, true)
            try {
                val inv = Matrix()
                if (!m.invert(inv)) return b
                val t = Tasks.await(rec.process(InputImage.fromBitmap(rot, 0)))
                val lines = t.textBlocks.flatMap { it.lines }
                if (lines.isEmpty()) return b
                val groups = clusterLines(rot, lines, null)
                // pusat blok lama di koordinat gambar yang sudah diluruskan
                val c = floatArrayOf(b.rect.centerX() - sub.left.toFloat(), b.rect.centerY() - sub.top.toFloat())
                m.mapPoints(c)
                c[0] -= dev.left
                c[1] -= dev.top
                val g = groups.minByOrNull { grp ->
                    val bb = Rect()
                    var f = true
                    for (ln in grp) { val lb = ln.boundingBox ?: continue; if (f) { bb.set(lb); f = false } else bb.union(lb) }
                    val dx = bb.centerX() - c[0]
                    val dy = bb.centerY() - c[1]
                    dx * dx + dy * dy
                } ?: return b
                val txt = g.joinToString(" ") { it.text.trim() }.trim()
                if (!usable(txt) || txt.length < b.text.length + 8) return b
                val pts = ArrayList<Point>()
                val hs = ArrayList<Int>()
                for (ln in g) {
                    val cp = ln.cornerPoints ?: continue
                    if (cp.size != 4) continue
                    for (pnt in cp) {
                        val q = floatArrayOf(pnt.x + dev.left, pnt.y + dev.top)
                        inv.mapPoints(q)
                        pts.add(Point((q[0] + sub.left).toInt(), (q[1] + sub.top).toInt()))
                    }
                    hs.add((Math.hypot((cp[3].x - cp[0].x).toDouble(), (cp[3].y - cp[0].y).toDouble()) / scale).toInt())
                }
                if (pts.size < 4) return b
                val r = Rect(pts[0].x, pts[0].y, pts[0].x, pts[0].y)
                for (pnt in pts) r.union(pnt.x, pnt.y)
                r.union(b.rect)
                hs.sort()
                dbg?.append("  OCR-ULANG miring ${b.angle.toInt()}deg: [${b.text.take(30)}] -> [${txt.take(50)}]\n")
                return Block(r, txt, b.angle, pts, if (hs.isEmpty()) b.lineH else hs[hs.size / 2])
            } finally {
                rot.recycle()
            }
        } catch (_: Throwable) {
            return b
        }
    }

    /** Median dengan bobot (sudut, panjang baris). Baris panjang lebih dipercaya daripada kata pendek. */
    private fun weightedMedian(v: List<Pair<Double, Double>>): Float {
        if (v.isEmpty()) return 0f
        val sorted = v.sortedBy { it.first }
        val total = sorted.sumOf { it.second }
        var acc = 0.0
        for (p in sorted) {
            acc += p.second
            if (acc >= total / 2) return p.first.toFloat()
        }
        return sorted.last().first.toFloat()
    }

    /**
     * Perhalus sudut teks dari piksel gambar asli: coba sudut di sekitar tebakan ML Kit (+-8 derajat) dan
     * pilih yang membuat goresan tinta paling mengumpul di baris-baris (proyeksi baris paling "tajam").
     * Kalau buktinya lemah (tinta terlalu sedikit/penuh, atau tidak lebih baik dari tebakan), pakai tebakan.
     */
    private fun refineAngle(bmp: Bitmap, r: Rect, guess: Float): Float {
        val c = clampRect(r, bmp)
        val w = c.width()
        val h = c.height()
        if (w < 30 || h < 20 || w.toLong() * h > 500_000L) return guess
        val px = IntArray(w * h)
        bmp.getPixels(px, 0, w, c.left, c.top, w, h)
        val xs = IntArray(w * h)
        val ys = IntArray(w * h)
        var n = 0
        for (y in 0 until h) for (x in 0 until w) {
            val p = px[y * w + x]
            if ((Color.red(p) * 299 + Color.green(p) * 587 + Color.blue(p) * 114) / 1000 < 110) {
                xs[n] = x; ys[n] = y; n++
            }
        }
        if (n < 150 || n > w.toLong() * h * 0.5) return guess
        val off = w + h + 2
        val bins = IntArray(2 * off + h + 2)
        fun score(a: Float): Double {
            java.util.Arrays.fill(bins, 0)
            val th = Math.toRadians(a.toDouble())
            val s = Math.sin(th).toFloat()
            val co = Math.cos(th).toFloat()
            for (k in 0 until n) {
                val yy = (-xs[k] * s + ys[k] * co).toInt() + off
                if (yy >= 0 && yy < bins.size) bins[yy]++
            }
            var sum = 0.0
            for (b in bins) sum += b.toDouble() * b
            return sum
        }
        val base = score(guess)
        var best = guess
        var bestScore = base
        var a = guess - 8f
        while (a <= guess + 8f) {
            val sc = score(a)
            if (sc > bestScore) { bestScore = sc; best = a }
            a += 0.5f
        }
        return if (bestScore > base * 1.03) best else guess
    }

    // ------------------------------------------------------------------ gabung blok satu balon

    private fun close(a: Rect, b: Rect, lang: Int): Boolean {
        if (lang != 0) return false // teks horizontal: pemisahan per balon sudah ditangani saat OCR
        val dimA = minOf(a.width(), a.height())
        val dimB = minOf(b.width(), b.height())
        val gap = (minOf(dimA, dimB) * 0.6f).toInt().coerceIn(6, 20)
        val ra = Rect(a.left - gap, a.top - gap, a.right + gap, a.bottom + gap)
        return Rect.intersects(ra, b)
    }

    /** Urutan baca dua blok: manga Jepang kolom kanan dulu, lainnya atas dulu. */
    private fun firstIsBefore(a: Rect, b: Rect, lang: Int): Boolean {
        val sameRow = Math.abs(a.centerY() - b.centerY()) < maxOf(a.height(), b.height()) * 0.6f
        return if (lang == 0 && sameRow) a.centerX() > b.centerX() else a.top < b.top ||
            (a.top == b.top && a.left < b.left)
    }

    private fun merge(blocks: List<Block>, lang: Int): List<Block> {
        val joiner = if (lang == 0 || lang == 2) "" else " "
        val list = blocks.toMutableList()
        var changed = true
        while (changed) {
            changed = false
            loop@ for (i in list.indices) {
                for (j in i + 1 until list.size) {
                    val a = list[i]
                    val b = list[j]
                    if (close(a.rect, b.rect, lang)) {
                        val first = if (firstIsBefore(a.rect, b.rect, lang)) a else b
                        val second = if (first === a) b else a
                        val r = Rect(a.rect)
                        r.union(b.rect)
                        list[i] = Block(r, first.text + joiner + second.text, 0f, emptyList(), maxOf(a.lineH, b.lineH))
                        list.removeAt(j)
                        changed = true
                        break@loop
                    }
                }
            }
        }
        // urutan baca antar balon
        val rtl = lang == 0
        val sorted = list.sortedBy { it.rect.top }
        val rows = ArrayList<MutableList<Block>>()
        for (b in sorted) {
            val row = rows.lastOrNull()
            if (row != null && b.rect.centerY() <= row.minOf { it.rect.bottom }) row.add(b) else rows.add(mutableListOf(b))
        }
        return rows.flatMap { row ->
            if (rtl) row.sortedByDescending { it.rect.right } else row.sortedBy { it.rect.left }
        }
    }

    // ------------------------------------------------------------------ gambar ulang

    private class Plan(val box: Rect, val erase: Rect, val bg: Int)

    private fun clampRect(r: Rect, bmp: Bitmap): Rect {
        val c = Rect(r)
        if (!c.intersect(0, 0, bmp.width, bmp.height)) return Rect(0, 0, 1, 1)
        return c
    }

    private fun colorDist(a: Int, b: Int): Int =
        Math.abs(Color.red(a) - Color.red(b)) + Math.abs(Color.green(a) - Color.green(b)) +
            Math.abs(Color.blue(a) - Color.blue(b))

    /**
     * Hapus hanya goresan teks (piksel yang beda dari warna latar) di [r], lalu isi dengan warna latar.
     * Kembalikan false kalau areanya terlalu "penuh" (bukan teks di atas latar rata); pemanggil lalu menutup satu kotak.
     */
    private fun eraseInk(bmp: Bitmap, r: Rect, bg: Int): Boolean {
        val w = r.width()
        val h = r.height()
        if (w < 2 || h < 2) return false
        val px = IntArray(w * h)
        bmp.getPixels(px, 0, w, r.left, r.top, w, h)
        val ink = BooleanArray(w * h)
        var cnt = 0L
        val dist = IntArray(w * h)
        for (i in px.indices) { dist[i] = colorDist(px[i], bg); if (dist[i] > 90) { ink[i] = true; cnt++ } }
        if (cnt > w.toLong() * h / 2) return false
        // Tepi huruf yang pudar (abu-abu tipis hasil anti-alias) juga tinta, tapi hanya kalau dekat tinta kuat.
        // Dengan begitu tidak ada garis hantu, sedangkan titik screentone yang jauh dari huruf tidak ikut terhapus.
        val strongNear = dilate(ink, w, h, 7)
        for (i in px.indices) if (!ink[i] && strongNear[i] && dist[i] > 18) { ink[i] = true; cnt++ }
        if (cnt > w.toLong() * h * 3 / 4) return false
        val rad = (minOf(w, h) * 0.04f).toInt().coerceIn(2, 5)
        val a = BooleanArray(w * h)
        val pre = IntArray(maxOf(w, h) + 1)
        for (y in 0 until h) {
            for (x in 0 until w) pre[x + 1] = pre[x] + if (ink[y * w + x]) 1 else 0
            for (x in 0 until w) a[y * w + x] = pre[minOf(w, x + rad + 1)] - pre[maxOf(0, x - rad)] > 0
        }
        val e = BooleanArray(w * h)
        for (x in 0 until w) {
            for (y in 0 until h) pre[y + 1] = pre[y] + if (a[y * w + x]) 1 else 0
            for (y in 0 until h) if (pre[minOf(h, y + rad + 1)] - pre[maxOf(0, y - rad)] > 0) e[y * w + x] = true
        }
        // Isi bekas teks dari piksel terdekat kiri dan kanan di baris yang sama (latar gradasi tetap mulus).
        // Kalau tidak ada tetangga atau warnanya jauh dari latar, pakai warna latar rata seperti sebelumnya.
        val left = IntArray(w)
        val right = IntArray(w)
        val orig = px.copyOf()
        for (y in 0 until h) {
            var last = -1
            for (x in 0 until w) { if (!e[y * w + x]) last = x; left[x] = last }
            last = -1
            for (x in w - 1 downTo 0) { if (!e[y * w + x]) last = x; right[x] = last }
            for (x in 0 until w) {
                if (!e[y * w + x]) continue
                val l = left[x]
                val rr = right[x]
                var col = bg
                if (l >= 0 && rr >= 0) {
                    val c1 = orig[y * w + l]
                    val c2 = orig[y * w + rr]
                    val t = (x - l).toFloat() / maxOf(1, rr - l)
                    val cr = (Color.red(c1) * (1 - t) + Color.red(c2) * t).toInt()
                    val cg = (Color.green(c1) * (1 - t) + Color.green(c2) * t).toInt()
                    val cb = (Color.blue(c1) * (1 - t) + Color.blue(c2) * t).toInt()
                    val mix = Color.rgb(cr, cg, cb)
                    if (colorDist(mix, bg) <= 120) col = mix
                }
                px[y * w + x] = col
            }
        }
        bmp.setPixels(px, 0, w, r.left, r.top, w, h)
        return true
    }

    /** Tinggi huruf asli tengah (median) di halaman yang sedang dirender; dipakai supaya ukuran huruf antar balon seragam. */
    private var pageRefH = 0f

    /** Batas ukuran huruf terjemahan untuk satu blok: tidak lebih dari 1,35x huruf asli DAN tidak jauh di atas median halaman. */
    private fun sizeCap(b: Block): Float {
        if (b.lineH <= 0) return 64f
        val own = b.lineH * SIZE_CAP
        val cap = if (pageRefH > 0f) minOf(own, pageRefH * 1.6f) else own
        return cap.coerceIn(10f, 64f)
    }

    private fun render(bmp: Bitmap, blocks: List<Block>, trIn: List<String>) {
        val tr = if (capsOn) trIn.map { it.uppercase(java.util.Locale("id", "ID")) } else trIn
        val n = minOf(blocks.size, tr.size)
        if (n == 0) return
        val hs = (0 until n).map { blocks[it].lineH }.filter { it > 0 }.sorted()
        pageRefH = if (hs.isEmpty()) 0f else hs[hs.size / 2].toFloat()

        // Ambil warna latar SEBELUM ada yang digambar, supaya blok tetangga tidak ikut mempengaruhi.
        val plans = ArrayList<Plan>()
        for (i in 0 until n) {
            val r = blocks[i].rect
            val ex = maxOf(4, (r.width() * 0.05f).toInt())
            val ey = maxOf(4, (r.height() * 0.05f).toInt())
            val base = clampRect(Rect(r.left - ex, r.top - ey, r.right + ex, r.bottom + ey), bmp)
            val bg = TextUtil.sampleBg(bmp, base) or (0xFF shl 24)
            var box = base
            // Teks vertikal (kolom sempit): lebarkan kotak terjemahan kalau latar sekitarnya sama.
            if (base.height() > base.width() * 2) {
                val extra = (base.width() * 0.6f).toInt()
                val wide = clampRect(Rect(base.left - extra, base.top, base.right + extra, base.bottom), bmp)
                val hitsOther = (0 until n).any { j -> j != i && Rect.intersects(wide, blocks[j].rect) }
                if (!hitsOther && colorDist(bg, TextUtil.sampleBg(bmp, wide)) < 60) box = wide
            }
            plans.add(Plan(box, base, bg))
        }

        val c = Canvas(bmp)
        val fill = Paint(Paint.ANTI_ALIAS_FLAG)
        fill.style = Paint.Style.FILL
        val tp = TextPaint(Paint.ANTI_ALIAS_FLAG)
        tp.typeface = dialogFace ?: Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        if (italicOn) tp.textSkewX = -0.22f

        for (i in 0 until n) {
            val p = plans[i]
            val box = p.box
            if (box.width() < 8 || box.height() < 8 || blocks[i].pts.isNotEmpty()) continue
            // Hapus semua teks asli dulu; terjemahan digambar sesudahnya supaya tidak tertimpa blok tetangga.
            if (!eraseInk(bmp, p.erase, p.bg)) {
                fill.color = p.bg
                val rad = minOf(box.width(), box.height()) * 0.12f
                c.drawRoundRect(RectF(box), rad, rad, fill)
            }
        }
        for (i in 0 until n) {
            val p = plans[i]
            val box = p.box
            if (box.width() < 8 || box.height() < 8 || blocks[i].pts.isNotEmpty()) continue
            val capsText = tr[i].trim()
            if (capsText.isEmpty()) continue
            // Huruf kapital lebih lebar. Kalau balon sempit dan hasilnya jadi kecil, pakai huruf biasa.
            var text = capsText
            if (caseMode == 2) {
                val plain = trIn[i].trim()
                val okCaps = typesetInBalloon(bmp, c, tp, blocks, i, capsText, p.bg, n, draw = false)
                val sCaps = typesetSize
                if (!okCaps || sCaps < 14f) {
                    val okPlain = typesetInBalloon(bmp, c, tp, blocks, i, plain, p.bg, n, draw = false)
                    val sPlain = typesetSize
                    if (okPlain && (!okCaps || sCaps < sPlain * 0.85f)) text = plain
                    else if (!okCaps) text = plain
                }
            }
            if (typesetInBalloon(bmp, c, tp, blocks, i, text, p.bg, n)) continue
            val pad = maxOf(2, (minOf(box.width(), box.height()) * 0.06f).toInt())
            val w = box.width() - 2 * pad
            val h = box.height() - 2 * pad
            if (w < 6 || h < 6) continue

            tp.color = if (TextUtil.luminance(p.bg) > 128) Color.parseColor("#111111") else Color.WHITE
            var size = minOf(h * 0.8f, 90f).coerceAtLeast(9f)
            if (blocks[i].lineH > 0) size = minOf(size, sizeCap(blocks[i])).coerceAtLeast(9f)
            var layout = layoutOf(text, tp, size, w)
            while (layout.height > h && size > 9f) {
                size = maxOf(9f, size * 0.93f)
                layout = layoutOf(text, tp, size, w)
            }
            // Kata tidak boleh terpotong: kecilkan lagi (sampai batas bawah) kalau kata terpanjang tidak muat.
            val words = text.split(Regex("\\s+"))
            while (words.any { tp.measureText(it) > w } && size > 6f) {
                size = maxOf(6f, size * 0.93f)
                layout = layoutOf(text, tp, size, w)
            }
            c.save()
            c.translate((box.left + pad).toFloat(), box.top + pad + (h - layout.height) / 2f)
            layout.draw(c)
            c.restore()
        }
        renderTilted(bmp, c, tp, blocks, tr, n)
    }

    /**
     * Tulis terjemahan mengikuti BENTUK balon: cari bagian dalam balon (flood fill dari tengah teks asli yang sudah
     * dihapus), lalu bungkus kata baris demi baris sesuai lebar balon di tiap ketinggian dan pilih huruf terbesar yang muat.
     * Kembalikan false kalau gagal (pemanggil memakai jalur kotak biasa).
     */
    /** Ukuran huruf hasil typesetInBalloon terakhir yang berhasil (dipakai untuk memilih kapital vs huruf biasa). */
    private var typesetSize = 0f

    private fun typesetInBalloon(
        bmp: Bitmap, c: Canvas, tp: TextPaint, blocks: List<Block>, i: Int, text: String, bg: Int, n: Int,
        draw: Boolean = true
    ): Boolean {
        val r = blocks[i].rect
        val m = maxOf(r.width(), r.height()) + 40
        val win = clampRect(Rect(r.left - m, r.top - m, r.right + m, r.bottom + m), bmp)
        var yMin = win.top
        var yMax = win.bottom
        // balon yang dipakai bersama blok lain di atas/bawahnya: bagi dua di tengah celah
        for (j in 0 until n) {
            if (j == i) continue
            val o = blocks[j].rect
            val ox = minOf(o.right, r.right) - maxOf(o.left, r.left)
            if (ox > 0.3f * minOf(o.width(), r.width())) {
                if (o.centerY() < r.centerY()) yMin = maxOf(yMin, (o.bottom + r.top) / 2)
                else yMax = minOf(yMax, (r.bottom + o.top) / 2)
            }
        }
        yMin = minOf(yMin, r.top)
        yMax = maxOf(yMax, r.bottom)
        // Tetangga yang ada di sekitar jendela ini. Tiap piksel hanya boleh dipakai blok yang kotak
        // aslinya PALING DEKAT (Voronoi), jadi teks tidak pernah meluber ke area blok lain,
        // baik ke atas/bawah maupun ke samping (kotak narasi yang berdempetan, balon bersebelahan).
        val near = ArrayList<Rect>()
        for (j in 0 until n) {
            if (j == i) continue
            val o = blocks[j].rect
            if (o.right >= win.left && o.left <= win.right && o.bottom >= win.top && o.top <= win.bottom) near.add(o)
        }
        fun d2(o: Rect, x: Int, y: Int): Long {
            val dx = maxOf(maxOf(o.left - x, x - o.right), 0).toLong()
            val dy = maxOf(maxOf(o.top - y, y - o.bottom), 0).toLong()
            return dx * dx + dy * dy
        }
        val ww = win.width()
        val wh = win.height()
        if (ww < 8 || wh < 8) return false
        val px = IntArray(ww * wh)
        bmp.getPixels(px, 0, ww, win.left, win.top, ww, wh)
        val sx = r.centerX() - win.left
        val sy = r.centerY() - win.top
        if (sx !in 0 until ww || sy !in 0 until wh) return false
        if (colorDist(px[sy * ww + sx], bg) > 60) return false
        val y0 = maxOf(0, yMin - win.top)
        val y1 = minOf(wh - 1, yMax - win.top)
        // Batas keras area balon: tidak lebih dari ~1,9x kotak teks asli, jadi isian tidak bisa bocor lewat
        // celah garis balon / ekor balon ke area lain.
        val limX = maxOf(10, (r.width() * 0.45f).toInt())
        val limY = maxOf(10, (r.height() * 0.45f).toInt())
        val lx0 = maxOf(0, r.left - limX - win.left)
        val lx1 = minOf(ww - 1, r.right + limX - win.left)
        val ly0 = maxOf(y0, r.top - limY - win.top)
        val ly1 = minOf(y1, r.bottom + limY - win.top)
        fun owned(k: Int): Boolean {
            val kx = k % ww
            val ky = k / ww
            if (kx < lx0 || kx > lx1 || ky < ly0 || ky > ly1) return false
            if (near.isEmpty()) return true
            val x = win.left + k % ww
            val y = win.top + k / ww
            val mine = d2(r, x, y)
            for (o in near) if (d2(o, x, y) < mine) return false
            return true
        }
        val inReg = BooleanArray(ww * wh)
        val stack = IntArray(ww * wh)
        var sp = 0
        stack[sp++] = sy * ww + sx
        inReg[sy * ww + sx] = true
        while (sp > 0) {
            val q = stack[--sp]
            val x = q % ww
            val y = q / ww
            if (x > 0) { val k = q - 1; if (!inReg[k] && colorDist(px[k], bg) <= 60 && owned(k)) { inReg[k] = true; stack[sp++] = k } }
            if (x < ww - 1) { val k = q + 1; if (!inReg[k] && colorDist(px[k], bg) <= 60 && owned(k)) { inReg[k] = true; stack[sp++] = k } }
            if (y > y0) { val k = q - ww; if (!inReg[k] && colorDist(px[k], bg) <= 60 && owned(k)) { inReg[k] = true; stack[sp++] = k } }
            if (y < y1) { val k = q + ww; if (!inReg[k] && colorDist(px[k], bg) <= 60 && owned(k)) { inReg[k] = true; stack[sp++] = k } }
        }
        val words = text.split(Regex("\\s+")).filter { it.isNotEmpty() }
        if (words.isEmpty()) return true
        val maxW = r.width() * 1.5f + 20f
        val ext = FloatArray(2) // lebar, titik tengah pada baris y (koordinat window)
        fun extentAt(y: Int): Boolean {
            if (y < y0 || y > y1) return false
            val base = y * ww
            if (!inReg[base + sx]) return false
            var l = sx
            while (l > 0 && inReg[base + l - 1]) l--
            var rr = sx
            while (rr < ww - 1 && inReg[base + rr + 1]) rr++
            ext[0] = minOf((rr - l + 1) * 0.84f, maxW)
            ext[1] = (l + rr) / 2f
            return true
        }
        tp.color = if (TextUtil.luminance(bg) > 128) Color.parseColor("#111111") else Color.WHITE
        val capSize = sizeCap(blocks[i]).toInt()
        for (sizeI in capSize downTo 9) {
            val size = sizeI.toFloat()
            tp.textSize = size
            val lh = size * 1.18f
            var wordTooLong = false
            for (nl in 1..14) {
                val totalH = nl * lh
                val top = sy - totalH / 2f
                if (top < y0 || top + totalH > y1) break
                val lines = ArrayList<String>()
                val centers = ArrayList<Float>()
                var wi = 0
                var ok = true
                for (k in 0 until nl) {
                    val yTop = top + k * lh
                    var wMin = Float.MAX_VALUE
                    var ctr = 0f
                    for (f in 0..4) {
                        val yy = when (f) { 0 -> yTop + 2f; 1 -> yTop + lh * 0.25f; 2 -> yTop + lh * 0.5f; 3 -> yTop + lh * 0.75f; else -> yTop + lh - 2f }
                        if (!extentAt(yy.toInt())) { ok = false; break }
                        wMin = minOf(wMin, ext[0])
                        if (f == 2) ctr = ext[1]
                    }
                    if (!ok) break
                    var line = ""
                    while (wi < words.size) {
                        val cand = if (line.isEmpty()) words[wi] else line + " " + words[wi]
                        if (tp.measureText(cand) <= wMin) { line = cand; wi++ }
                        else if (line.isEmpty()) { wordTooLong = true; break }
                        else break
                    }
                    if (line.isEmpty()) { ok = false; break }
                    lines.add(line)
                    centers.add(ctr)
                }
                if (wordTooLong) break
                if (!ok || wi < words.size) continue
                // Cek akhir: ujung kiri/kanan tiap baris (plus condong huruf miring) harus tepat di dalam area balon.
                var inside = true
                val slant = if (italicOn) size * 0.2f else 0f
                for (k in lines.indices) {
                    val wLine = tp.measureText(lines[k])
                    val ix0 = (centers[k] - wLine / 2f).toInt()
                    val ix1 = (centers[k] + wLine / 2f + slant).toInt()
                    val yTop = top + k * lh
                    for (yy in floatArrayOf(yTop + 2f, yTop + lh * 0.5f, yTop + lh - 2f)) {
                        val iy = yy.toInt()
                        if (iy < y0 || iy > y1 || ix0 < 1 || ix1 > ww - 2 || !inReg[iy * ww + ix0] || !inReg[iy * ww + ix1]) { inside = false; break }
                    }
                    if (!inside) break
                }
                if (!inside) continue
                // muat: gambar (teks selalu dijaga tetap di dalam gambar, mis. balon di tepi halaman)
                typesetSize = size
                if (draw) {
                    for (k in lines.indices) {
                        val wLine = tp.measureText(lines[k])
                        val x = (win.left + centers[k] - wLine / 2f).coerceIn(0f, maxOf(0f, bmp.width - wLine))
                        c.drawText(lines[k], x, win.top + top + k * lh + size * 0.95f, tp)
                    }
                }
                return true
            }
        }
        return false
    }

    private fun dilate(src: BooleanArray, w: Int, h: Int, rad: Int): BooleanArray {
        val a = BooleanArray(w * h)
        val pre = IntArray(maxOf(w, h) + 1)
        for (y in 0 until h) {
            for (x in 0 until w) pre[x + 1] = pre[x] + if (src[y * w + x]) 1 else 0
            for (x in 0 until w) a[y * w + x] = pre[minOf(w, x + rad + 1)] - pre[maxOf(0, x - rad)] > 0
        }
        val out = BooleanArray(w * h)
        for (x in 0 until w) {
            for (y in 0 until h) pre[y + 1] = pre[y] + if (a[y * w + x]) 1 else 0
            for (y in 0 until h) out[y * w + x] = pre[minOf(h, y + rad + 1)] - pre[maxOf(0, y - rad)] > 0
        }
        return out
    }

    /**
     * Teks miring (layar HP/tablet): hapus goresan teks hanya di dalam poligon baris (ikut kemiringan),
     * isi dari piksel sekitar terdekat (4 arah), lalu tulis terjemahan dengan sudut yang sama.
     */
    private fun renderTilted(bmp: Bitmap, c: Canvas, tp: TextPaint, blocks: List<Block>, tr: List<String>, n: Int) {
        for (i in 0 until n) {
            val b = blocks[i]
            if (b.pts.size < 4) continue
            var minX = Int.MAX_VALUE
            var minY = Int.MAX_VALUE
            var maxX = Int.MIN_VALUE
            var maxY = Int.MIN_VALUE
            for (p in b.pts) { minX = minOf(minX, p.x); minY = minOf(minY, p.y); maxX = maxOf(maxX, p.x); maxY = maxOf(maxY, p.y) }
            val reg = clampRect(Rect(minX - 8, minY - 8, maxX + 8, maxY + 8), bmp)
            val w = reg.width()
            val h = reg.height()
            if (w < 8 || h < 8) continue
            val px = IntArray(w * h)
            bmp.getPixels(px, 0, w, reg.left, reg.top, w, h)

            // mask = poligon tiap baris (sedikit dilebarkan)
            val mbmp = Bitmap.createBitmap(w, h, Bitmap.Config.ALPHA_8)
            val mc = Canvas(mbmp)
            val mp = Paint(Paint.ANTI_ALIAS_FLAG)
            mp.color = Color.WHITE
            mp.style = Paint.Style.FILL_AND_STROKE
            mp.strokeWidth = 8f
            var k = 0
            while (k + 3 < b.pts.size) {
                val path = Path()
                path.moveTo((b.pts[k].x - reg.left).toFloat(), (b.pts[k].y - reg.top).toFloat())
                for (q in 1..3) path.lineTo((b.pts[k + q].x - reg.left).toFloat(), (b.pts[k + q].y - reg.top).toFloat())
                path.close()
                mc.drawPath(path, mp)
                k += 4
            }
            val mpx = IntArray(w * h)
            mbmp.getPixels(mpx, 0, w, 0, 0, w, h)
            mbmp.recycle()
            val inMask = BooleanArray(w * h) { (mpx[it] ushr 24) > 0 }

            // warna latar = median piksel di dalam mask (goresan teks adalah minoritas)
            val rs = ArrayList<Int>()
            val gs = ArrayList<Int>()
            val bs = ArrayList<Int>()
            for (q in px.indices) if (inMask[q]) { rs.add(Color.red(px[q])); gs.add(Color.green(px[q])); bs.add(Color.blue(px[q])) }
            if (rs.size < 20) continue
            rs.sort(); gs.sort(); bs.sort()
            val bg = Color.rgb(rs[rs.size / 2], gs[gs.size / 2], bs[bs.size / 2])
            val ink = BooleanArray(w * h)
            for (q in px.indices) if (inMask[q] && colorDist(px[q], bg) > 90) ink[q] = true
            val dil = dilate(ink, w, h, 3)

            val out = px.copyOf()
            for (y in 0 until h) for (x in 0 until w) {
                val q = y * w + x
                if (!dil[q]) continue
                var sr = 0f
                var sg = 0f
                var sb = 0f
                var sw = 0f
                for (d in 0 until 4) {
                    var st = 1
                    while (st <= 24) {
                        val xx = x + (if (d == 0) st else if (d == 1) -st else 0)
                        val yy = y + (if (d == 2) st else if (d == 3) -st else 0)
                        if (xx < 0 || yy < 0 || xx >= w || yy >= h) break
                        val qq = yy * w + xx
                        if (!dil[qq]) {
                            val wt = 1f / st
                            sr += Color.red(px[qq]) * wt; sg += Color.green(px[qq]) * wt; sb += Color.blue(px[qq]) * wt; sw += wt
                            break
                        }
                        st++
                    }
                }
                out[q] = if (sw > 0f) Color.rgb((sr / sw).toInt(), (sg / sw).toInt(), (sb / sw).toInt()) else bg
            }
            bmp.setPixels(out, 0, w, reg.left, reg.top, w, h)

            val text = tr[i].trim()
            if (text.isEmpty()) continue
            // ukuran teks dalam bingkai yang sudah "ditegakkan" (diputar balik sebesar sudutnya)
            val cx = b.pts.sumOf { it.x }.toFloat() / b.pts.size
            val cy = b.pts.sumOf { it.y }.toFloat() / b.pts.size
            val th = Math.toRadians(b.angle.toDouble())
            val cs = Math.cos(th).toFloat()
            val sn = Math.sin(th).toFloat()
            var rminX = Float.MAX_VALUE
            var rmaxX = -Float.MAX_VALUE
            var rminY = Float.MAX_VALUE
            var rmaxY = -Float.MAX_VALUE
            for (p in b.pts) {
                val dx = p.x - cx
                val dy = p.y - cy
                val rx = dx * cs + dy * sn
                val ry = -dx * sn + dy * cs
                rminX = minOf(rminX, rx); rmaxX = maxOf(rmaxX, rx); rminY = minOf(rminY, ry); rmaxY = maxOf(rmaxY, ry)
            }
            val bw = (rmaxX - rminX).toInt() + 8
            val bh = (rmaxY - rminY).toInt() + 8
            if (bw < 6 || bh < 6) continue
            tp.color = if (TextUtil.luminance(bg) > 128) Color.parseColor("#111111") else Color.WHITE
            var size = minOf(bh * 0.8f, 90f).coerceAtLeast(9f)
            if (b.lineH > 0) size = minOf(size, maxOf(10f, b.lineH * SIZE_CAP))
            var layout = layoutOf(text, tp, size, bw)
            while (layout.height > bh && size > 9f) {
                size = maxOf(9f, size * 0.93f)
                layout = layoutOf(text, tp, size, bw)
            }
            val words = text.split(Regex("\\s+"))
            while (words.any { tp.measureText(it) > bw } && size > 8f) {
                size = maxOf(8f, size * 0.93f)
                layout = layoutOf(text, tp, size, bw)
            }
            c.save()
            c.rotate(b.angle, cx, cy)
            c.translate(cx - bw / 2f, cy - layout.height / 2f)
            layout.draw(c)
            c.restore()
        }
    }

    private fun layoutOf(text: String, tp: TextPaint, size: Float, width: Int): StaticLayout {
        tp.textSize = size
        return StaticLayout.Builder.obtain(text, 0, text.length, tp, width)
            .setAlignment(Layout.Alignment.ALIGN_CENTER)
            .setIncludePad(false)
            .build()
    }

    // ------------------------------------------------------------------ satu halaman

    /** Gambar halaman asli dengan kotak merah + nomor untuk tiap blok yang dibaca (bahan debug). */
    private fun saveDebugImage(bmp: Bitmap, blocks: List<Block>, target: File) {
        val copy = bmp.copy(Bitmap.Config.ARGB_8888, true)
        try {
            val cv = Canvas(copy)
            val pnt = Paint()
            pnt.style = Paint.Style.STROKE
            pnt.strokeWidth = 3f
            pnt.color = Color.RED
            val tx = Paint(Paint.ANTI_ALIAS_FLAG)
            tx.color = Color.BLUE
            tx.textSize = 30f
            blocks.forEachIndexed { i, b ->
                cv.drawRect(RectF(b.rect), pnt)
                cv.drawText("$i", b.rect.left + 3f, b.rect.top + 28f, tx)
            }
            target.outputStream().use { copy.compress(Bitmap.CompressFormat.JPEG, 75, it) }
        } finally {
            copy.recycle()
        }
    }

    /** Proses satu halaman dan simpan hasilnya sebagai JPEG. Kembalikan jumlah blok teks yang diterjemahkan. */
    fun processPage(
        file: File,
        outFile: File,
        rec: TextRecognizer,
        lang: Int,
        translate: (List<String>) -> List<String>,
        onStep: (String) -> Unit,
        onTiming: (String) -> Unit = {},
        debugDir: File? = null
    ): Int {
        val bmp = decode(file) ?: throw IllegalStateException("Gambar tidak terbaca: ${file.name}")
        try {
            onStep("membaca teks")
            val t0 = System.currentTimeMillis()
            val dbg = if (debugDir != null) StringBuilder() else null
            val blocks = merge(readBlocks(rec, bmp, lang, dbg), lang)
            val t1 = System.currentTimeMillis()
            var t2 = t1
            var trOut: List<String> = emptyList()
            if (debugDir != null) {
                try { saveDebugImage(bmp, blocks, File(debugDir.apply { mkdirs() }, outFile.nameWithoutExtension + ".jpg")) } catch (_: Throwable) {}
            }
            if (blocks.isNotEmpty()) {
                onStep("menerjemahkan ${blocks.size} blok")
                val tr = translate(blocks.map { it.text })
                trOut = tr
                t2 = System.currentTimeMillis()
                onStep("menggambar")
                render(bmp, blocks, tr)
            }
            if (debugDir != null) {
                try {
                    debugDir.mkdirs()
                    File(debugDir, outFile.nameWithoutExtension + ".txt").writeText(buildString {
                        append("gambar ${bmp.width}x${bmp.height}, bahasa $lang, ${blocks.size} blok akhir\n\n")
                        append("--- keputusan pemisahan baris ---\n").append(dbg).append("\n--- blok akhir ---\n")
                        blocks.forEachIndexed { i, b ->
                            append("#$i rect=${b.rect.left},${b.rect.top},${b.rect.right},${b.rect.bottom} sudut=${"%.1f".format(b.angle)}\n  asli: ${b.text}\n  terjemah: ${trOut.getOrNull(i) ?: "-"}\n")
                        }
                    })
                } catch (_: Throwable) {}
            }
            onTiming("OCR ${t1 - t0}ms, terjemah ${t2 - t1}ms, gambar ${System.currentTimeMillis() - t2}ms")
            outFile.parentFile?.mkdirs()
            val tmp = File(outFile.parentFile, outFile.name + ".tmp")
            tmp.outputStream().use { bmp.compress(Bitmap.CompressFormat.JPEG, 92, it) }
            if (!tmp.renameTo(outFile)) {
                tmp.copyTo(outFile, true)
                tmp.delete()
            }
            return blocks.size
        } finally {
            bmp.recycle()
        }
    }
}
