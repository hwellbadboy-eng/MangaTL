package com.niven.mangatl

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Rect
import android.graphics.RectF
import android.graphics.Typeface
import android.net.Uri
import android.text.Layout
import android.text.StaticLayout
import android.text.TextPaint
import com.google.android.gms.tasks.Tasks
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.TextRecognizer
import com.google.mlkit.vision.text.chinese.ChineseTextRecognizerOptions
import com.google.mlkit.vision.text.japanese.JapaneseTextRecognizerOptions
import com.google.mlkit.vision.text.korean.KoreanTextRecognizerOptions
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import java.io.File
import java.util.Locale
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream

/**
 * Mesin Manga Translator: impor halaman (gambar / CBZ / ZIP), baca teks (ML Kit per bahasa),
 * gabungkan blok satu balon, tutup teks asli dengan warna latar, tulis terjemahan Indonesia.
 * Penerjemahnya sendiri (Gemma) dipanggil lewat lambda supaya mesin ini tidak bergantung ke model.
 */
object MangaEngine {

    val LANG_LABELS = listOf("Jepang (manga)", "Korea (manhwa)", "Mandarin (manhua)", "Inggris")
    val LANG_PROMPT = listOf("Japanese", "Korean", "Chinese", "English")

    private const val STRIP_H = 1800
    private val IMAGE_EXT = setOf("jpg", "jpeg", "png", "webp")

    // ------------------------------------------------------------------ folder & berkas

    fun root(ctx: Context): File = File(ctx.getExternalFilesDir(null), "manga").also { it.mkdirs() }

    fun srcDir(work: File) = File(work, "src")

    fun outDir(work: File) = File(work, "out")

    fun isImageName(name: String): Boolean =
        name.substringAfterLast('.', "").lowercase(Locale.ROOT) in IMAGE_EXT

    fun naturalCompare(a: String, b: String): Int {
        val re = Regex("\\d+|\\D+")
        val ra = re.findAll(a.lowercase(Locale.ROOT)).map { it.value }.toList()
        val rb = re.findAll(b.lowercase(Locale.ROOT)).map { it.value }.toList()
        for (i in 0 until minOf(ra.size, rb.size)) {
            val x = ra[i]
            val y = rb[i]
            val c = if (x[0].isDigit() && y[0].isDigit()) {
                val lx = x.trimStart('0')
                val ly = y.trimStart('0')
                if (lx.length != ly.length) lx.length.compareTo(ly.length) else lx.compareTo(ly)
            } else {
                x.compareTo(y)
            }
            if (c != 0) return c
        }
        return ra.size.compareTo(rb.size)
    }

    /** Halaman sumber, terurut alami (1, 2, 10 bukan 1, 10, 2). */
    fun pages(work: File): List<File> =
        srcDir(work).listFiles()
            ?.filter { it.isFile && isImageName(it.name) }
            ?.sortedWith { a, b -> naturalCompare(a.name, b.name) }
            ?: emptyList()

    fun doneCount(work: File): Int =
        outDir(work).listFiles()?.count { it.isFile && it.name.endsWith(".jpg") } ?: 0

    fun outFile(work: File, index: Int) = File(outDir(work), "%04d.jpg".format(Locale.US, index + 1))

    fun outPages(work: File): List<File> =
        outDir(work).listFiles()
            ?.filter { it.isFile && it.name.endsWith(".jpg") }
            ?.sortedBy { it.name }
            ?: emptyList()

    /** Halaman untuk dibaca/ekspor: hasil terjemahan; kalau belum ada / gagal, pakai gambar asli. */
    fun readPages(work: File): List<File> =
        pages(work).mapIndexed { i, f -> outFile(work, i).takeIf { it.exists() } ?: f }

    /** Salin satu gambar, atau isi satu CBZ/ZIP, ke folder src. Kembalikan jumlah gambar yang masuk. */
    fun importUri(ctx: Context, work: File, uri: Uri, displayName: String, idx: Int): Int {
        val dir = srcDir(work)
        dir.mkdirs()
        val lower = displayName.lowercase(Locale.ROOT)
        var n = 0
        val existing = dir.listFiles()?.map { it.name.substringAfter('_') }?.toHashSet() ?: hashSetOf()
        if (lower.endsWith(".zip") || lower.endsWith(".cbz")) {
            ctx.contentResolver.openInputStream(uri)?.use { raw ->
                ZipInputStream(raw.buffered()).use { zin ->
                    var e: ZipEntry? = zin.nextEntry
                    while (e != null) {
                        val en = e.name
                        val leaf = en.substringAfterLast('/')
                        if (!e.isDirectory && isImageName(en) && !leaf.startsWith(".")) {
                            val safe = en.replace('/', '_').replace('\\', '_')
                            if (safe !in existing) {
                                val f = File(dir, "%03d_%s".format(Locale.US, idx, safe))
                                f.outputStream().use { zin.copyTo(it) }
                            }
                            n++
                        }
                        zin.closeEntry()
                        e = zin.nextEntry
                    }
                }
            }
        } else if (isImageName(displayName)) {
            val safe = displayName.replace('/', '_').replace('\\', '_')
            val f = File(dir, "%03d_%s".format(Locale.US, idx, safe))
            if (safe in existing) {
                n++
            } else ctx.contentResolver.openInputStream(uri)?.use { input ->
                f.outputStream().use { input.copyTo(it) }
                n++
            }
        }
        return n
    }

    fun exportCbz(work: File, target: File): Int {
        val files = readPages(work)
        ZipOutputStream(target.outputStream().buffered()).use { zos ->
            files.forEachIndexed { i, f ->
                zos.putNextEntry(ZipEntry("%04d.%s".format(Locale.US, i + 1, f.extension.lowercase(Locale.ROOT))))
                f.inputStream().use { it.copyTo(zos) }
                zos.closeEntry()
            }
        }
        return files.size
    }

    // ------------------------------------------------------------------ OCR

    class Block(val rect: Rect, val text: String)

    fun recognizer(lang: Int): TextRecognizer = when (lang) {
        0 -> TextRecognition.getClient(JapaneseTextRecognizerOptions.Builder().build())
        1 -> TextRecognition.getClient(KoreanTextRecognizerOptions.Builder().build())
        2 -> TextRecognition.getClient(ChineseTextRecognizerOptions.Builder().build())
        else -> TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
    }

    private fun hasCjk(s: String) = s.any { it.isLetter() && it.code >= 0x2E80 }

    private fun usable(s: String): Boolean {
        val letters = s.count { it.isLetter() }
        return letters >= 2 || (letters >= 1 && hasCjk(s))
    }

    /** Dekode gambar jadi bitmap yang bisa digambar; dikecilkan kalau terlalu besar. */
    fun decode(file: File): Bitmap? {
        val o = BitmapFactory.Options()
        o.inJustDecodeBounds = true
        BitmapFactory.decodeFile(file.path, o)
        if (o.outWidth <= 0 || o.outHeight <= 0) return null
        var sample = 1
        while (o.outWidth / sample > 2400 ||
            (o.outWidth / sample).toLong() * (o.outHeight / sample) > 20_000_000L
        ) sample *= 2
        val o2 = BitmapFactory.Options()
        o2.inSampleSize = sample
        o2.inMutable = true
        o2.inPreferredConfig = Bitmap.Config.ARGB_8888
        return BitmapFactory.decodeFile(file.path, o2)
    }

    /** Baca teks per potongan tinggi (halaman webtoon panjang dipotong supaya OCR tidak kewalahan). */
    private fun readBlocks(rec: TextRecognizer, bmp: Bitmap, lang: Int): List<Block> {
        val out = ArrayList<Block>()
        val joiner = if (lang == 0 || lang == 2) "" else " "
        var y = 0
        while (y < bmp.height) {
            var h = minOf(STRIP_H, bmp.height - y)
            if (bmp.height - (y + h) in 1..400) h = bmp.height - y
            val strip = Bitmap.createBitmap(bmp, 0, y, bmp.width, h)
            try {
                val t = Tasks.await(rec.process(InputImage.fromBitmap(strip, 0)))
                for (b in t.textBlocks) {
                    val box = b.boundingBox ?: continue
                    val txt = b.lines.joinToString(joiner) { it.text.trim() }.trim()
                    if (!usable(txt)) continue
                    out.add(Block(Rect(box.left, box.top + y, box.right, box.bottom + y), txt))
                }
            } finally {
                if (strip !== bmp) strip.recycle()
            }
            y += h
        }
        return out
    }

    // ------------------------------------------------------------------ gabung blok satu balon

    private fun close(a: Rect, b: Rect): Boolean {
        val dimA = minOf(a.width(), a.height())
        val dimB = minOf(b.width(), b.height())
        val gap = (minOf(dimA, dimB) * 0.6f).toInt().coerceIn(6, 28)
        val ra = Rect(a.left - gap, a.top - gap, a.right + gap, a.bottom + gap)
        return Rect.intersects(ra, b)
    }

    /** Urutan baca dua blok: manga Jepang kolom kanan dulu, lainnya atas dulu. */
    private fun firstIsBefore(a: Rect, b: Rect, lang: Int): Boolean {
        val sameRow = Math.abs(a.centerY() - b.centerY()) < maxOf(a.height(), b.height()) * 0.6f
        return if (lang == 0 && sameRow) a.centerX() > b.centerX() else a.top < b.top ||
            (a.top == b.top && a.left < b.left)
    }

    private fun merge(blocks: List<Block>, lang: Int): List<Block> {
        val joiner = if (lang == 0 || lang == 2) "" else " "
        val list = blocks.toMutableList()
        var changed = true
        while (changed) {
            changed = false
            loop@ for (i in list.indices) {
                for (j in i + 1 until list.size) {
                    val a = list[i]
                    val b = list[j]
                    if (close(a.rect, b.rect)) {
                        val first = if (firstIsBefore(a.rect, b.rect, lang)) a else b
                        val second = if (first === a) b else a
                        val r = Rect(a.rect)
                        r.union(b.rect)
                        list[i] = Block(r, first.text + joiner + second.text)
                        list.removeAt(j)
                        changed = true
                        break@loop
                    }
                }
            }
        }
        // urutan baca antar balon
        val rtl = lang == 0
        val sorted = list.sortedBy { it.rect.top }
        val rows = ArrayList<MutableList<Block>>()
        for (b in sorted) {
            val row = rows.lastOrNull()
            if (row != null && b.rect.centerY() <= row.minOf { it.rect.bottom }) row.add(b) else rows.add(mutableListOf(b))
        }
        return rows.flatMap { row ->
            if (rtl) row.sortedByDescending { it.rect.right } else row.sortedBy { it.rect.left }
        }
    }

    // ------------------------------------------------------------------ gambar ulang

    private class Plan(val box: Rect, val bg: Int)

    private fun clampRect(r: Rect, bmp: Bitmap): Rect {
        val c = Rect(r)
        if (!c.intersect(0, 0, bmp.width, bmp.height)) return Rect(0, 0, 1, 1)
        return c
    }

    private fun colorDist(a: Int, b: Int): Int =
        Math.abs(Color.red(a) - Color.red(b)) + Math.abs(Color.green(a) - Color.green(b)) +
            Math.abs(Color.blue(a) - Color.blue(b))

    private fun render(bmp: Bitmap, blocks: List<Block>, tr: List<String>) {
        val n = minOf(blocks.size, tr.size)
        if (n == 0) return

        // Ambil warna latar SEBELUM ada yang digambar, supaya blok tetangga tidak ikut mempengaruhi.
        val plans = ArrayList<Plan>()
        for (i in 0 until n) {
            val r = blocks[i].rect
            val padX = maxOf(3, (r.width() * 0.06f).toInt())
            val padY = maxOf(3, (r.height() * 0.04f).toInt())
            val base = clampRect(Rect(r.left - padX, r.top - padY, r.right + padX, r.bottom + padY), bmp)
            val bg = TextUtil.sampleBg(bmp, base)
            var box = base
            // Teks vertikal (kolom sempit): lebarkan kotak terjemahan kalau latar sekitarnya sama.
            if (base.height() > base.width() * 2) {
                val extra = (base.width() * 0.6f).toInt()
                val wide = clampRect(Rect(base.left - extra, base.top, base.right + extra, base.bottom), bmp)
                if (colorDist(bg, TextUtil.sampleBg(bmp, wide)) < 60) box = wide
            }
            plans.add(Plan(box, bg))
        }

        val c = Canvas(bmp)
        val fill = Paint(Paint.ANTI_ALIAS_FLAG)
        fill.style = Paint.Style.FILL
        val tp = TextPaint(Paint.ANTI_ALIAS_FLAG)
        tp.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)

        for (i in 0 until n) {
            val p = plans[i]
            val box = p.box
            if (box.width() < 8 || box.height() < 8) continue
            fill.color = p.bg
            val rad = minOf(box.width(), box.height()) * 0.12f
            c.drawRoundRect(RectF(box), rad, rad, fill)

            val text = tr[i].trim()
            if (text.isEmpty()) continue
            val pad = maxOf(2, (minOf(box.width(), box.height()) * 0.06f).toInt())
            val w = box.width() - 2 * pad
            val h = box.height() - 2 * pad
            if (w < 6 || h < 6) continue

            tp.color = if (TextUtil.luminance(p.bg) > 128) Color.parseColor("#111111") else Color.WHITE
            var size = minOf(h * 0.8f, 90f).coerceAtLeast(10f)
            var layout = layoutOf(text, tp, size, w)
            while (layout.height > h && size > 10f) {
                size = maxOf(10f, size * 0.93f)
                layout = layoutOf(text, tp, size, w)
            }
            c.save()
            c.clipRect(box)
            c.translate((box.left + pad).toFloat(), box.top + pad + maxOf(0f, (h - layout.height) / 2f))
            layout.draw(c)
            c.restore()
        }
    }

    private fun layoutOf(text: String, tp: TextPaint, size: Float, width: Int): StaticLayout {
        tp.textSize = size
        return StaticLayout.Builder.obtain(text, 0, text.length, tp, width)
            .setAlignment(Layout.Alignment.ALIGN_CENTER)
            .setIncludePad(false)
            .build()
    }

    // ------------------------------------------------------------------ satu halaman

    /** Proses satu halaman dan simpan hasilnya sebagai JPEG. Kembalikan jumlah blok teks yang diterjemahkan. */
    fun processPage(
        file: File,
        outFile: File,
        rec: TextRecognizer,
        lang: Int,
        translate: (List<String>) -> List<String>,
        onStep: (String) -> Unit
    ): Int {
        val bmp = decode(file) ?: throw IllegalStateException("Gambar tidak terbaca: ${file.name}")
        try {
            onStep("membaca teks")
            val blocks = merge(readBlocks(rec, bmp, lang), lang)
            if (blocks.isNotEmpty()) {
                onStep("menerjemahkan ${blocks.size} blok")
                val tr = translate(blocks.map { it.text })
                onStep("menggambar")
                render(bmp, blocks, tr)
            }
            outFile.parentFile?.mkdirs()
            val tmp = File(outFile.parentFile, outFile.name + ".tmp")
            tmp.outputStream().use { bmp.compress(Bitmap.CompressFormat.JPEG, 92, it) }
            if (!tmp.renameTo(outFile)) {
                tmp.copyTo(outFile, true)
                tmp.delete()
            }
            return blocks.size
        } finally {
            bmp.recycle()
        }
    }
}
