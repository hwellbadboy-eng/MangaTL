package com.niven.mangatl

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Rect
import android.graphics.RectF
import android.graphics.Typeface
import android.net.Uri
import android.text.Layout
import android.text.StaticLayout
import android.text.TextPaint
import com.google.android.gms.tasks.Tasks
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.Text
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.TextRecognizer
import com.google.mlkit.vision.text.chinese.ChineseTextRecognizerOptions
import com.google.mlkit.vision.text.japanese.JapaneseTextRecognizerOptions
import com.google.mlkit.vision.text.korean.KoreanTextRecognizerOptions
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import java.io.File
import java.util.Locale
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream

/**
 * Mesin Manga Translator: impor halaman (gambar / CBZ / ZIP), baca teks (ML Kit per bahasa),
 * gabungkan blok satu balon, tutup teks asli dengan warna latar, tulis terjemahan Indonesia.
 * Penerjemahnya sendiri (Gemma) dipanggil lewat lambda supaya mesin ini tidak bergantung ke model.
 */
object MangaEngine {

    val LANG_LABELS = listOf("Jepang (manga)", "Korea (manhwa)", "Mandarin (manhua)", "Inggris")
    val LANG_PROMPT = listOf("Japanese", "Korean", "Chinese", "English")

    private const val STRIP_H = 1800
    private val IMAGE_EXT = setOf("jpg", "jpeg", "png", "webp")

    // ------------------------------------------------------------------ folder & berkas

    fun root(ctx: Context): File = File(ctx.getExternalFilesDir(null), "manga").also { it.mkdirs() }

    fun srcDir(work: File) = File(work, "src")

    fun outDir(work: File) = File(work, "out")

    fun isImageName(name: String): Boolean =
        name.substringAfterLast('.', "").lowercase(Locale.ROOT) in IMAGE_EXT

    fun naturalCompare(a: String, b: String): Int {
        val re = Regex("\\d+|\\D+")
        val ra = re.findAll(a.lowercase(Locale.ROOT)).map { it.value }.toList()
        val rb = re.findAll(b.lowercase(Locale.ROOT)).map { it.value }.toList()
        for (i in 0 until minOf(ra.size, rb.size)) {
            val x = ra[i]
            val y = rb[i]
            val c = if (x[0].isDigit() && y[0].isDigit()) {
                val lx = x.trimStart('0')
                val ly = y.trimStart('0')
                if (lx.length != ly.length) lx.length.compareTo(ly.length) else lx.compareTo(ly)
            } else {
                x.compareTo(y)
            }
            if (c != 0) return c
        }
        return ra.size.compareTo(rb.size)
    }

    /** Halaman sumber, terurut alami (1, 2, 10 bukan 1, 10, 2). */
    fun pages(work: File): List<File> =
        srcDir(work).listFiles()
            ?.filter { it.isFile && isImageName(it.name) }
            ?.sortedWith { a, b -> naturalCompare(a.name, b.name) }
            ?: emptyList()

    fun doneCount(work: File): Int =
        outDir(work).listFiles()?.count { it.isFile && it.name.endsWith(".jpg") } ?: 0

    fun outFile(work: File, index: Int) = File(outDir(work), "%04d.jpg".format(Locale.US, index + 1))

    fun outPages(work: File): List<File> =
        outDir(work).listFiles()
            ?.filter { it.isFile && it.name.endsWith(".jpg") }
            ?.sortedBy { it.name }
            ?: emptyList()

    /** Halaman untuk dibaca/ekspor: hasil terjemahan; kalau belum ada / gagal, pakai gambar asli. */
    fun readPages(work: File): List<File> =
        pages(work).mapIndexed { i, f -> outFile(work, i).takeIf { it.exists() } ?: f }

    /** Salin satu gambar, atau isi satu CBZ/ZIP, ke folder src. Kembalikan jumlah gambar yang masuk. */
    fun importUri(ctx: Context, work: File, uri: Uri, displayName: String, idx: Int): Int {
        val dir = srcDir(work)
        dir.mkdirs()
        // Berkas kosong (0 byte) sisa impor yang gagal dibuang, supaya bisa disalin ulang.
        dir.listFiles()?.filter { it.isFile && it.length() == 0L }?.forEach { it.delete() }
        val existing = dir.listFiles()?.map { it.name.substringAfter('_') }?.toHashSet() ?: hashSetOf()
        val lower = displayName.lowercase(Locale.ROOT)
        fun safeName(n: String) = n.replace('/', '_').replace('\\', '_')

        if (lower.endsWith(".zip") || lower.endsWith(".cbz")) {
            // Baca lewat daftar isi (ZipFile) pada salinan sementara: lebih andal daripada ZipInputStream
            // untuk CBZ yang ukuran entri-nya baru tercatat di akhir berkas.
            val tmp = File(ctx.externalCacheDir ?: ctx.cacheDir, "import_${System.nanoTime()}.zip")
            try {
                ctx.contentResolver.openInputStream(uri)?.use { input -> tmp.outputStream().use { input.copyTo(it) } }
                var n = 0
                java.util.zip.ZipFile(tmp).use { zf ->
                    for (e in zf.entries().toList()) {
                        val leaf = e.name.substringAfterLast('/')
                        if (e.isDirectory || !isImageName(e.name) || leaf.startsWith(".")) continue
                        val safe = safeName(e.name)
                        if (safe !in existing) {
                            val f = File(dir, "%03d_%s".format(Locale.US, idx, safe))
                            zf.getInputStream(e).use { i -> f.outputStream().use { i.copyTo(it) } }
                            if (f.length() == 0L) { f.delete(); continue }
                        }
                        n++
                    }
                }
                return n
            } finally {
                tmp.delete()
            }
        }
        if (isImageName(displayName)) {
            val safe = safeName(displayName)
            if (safe in existing) return 1
            val f = File(dir, "%03d_%s".format(Locale.US, idx, safe))
            ctx.contentResolver.openInputStream(uri)?.use { input -> f.outputStream().use { input.copyTo(it) } }
            if (f.length() == 0L) { f.delete(); return 0 }
            return 1
        }
        return 0
    }

    fun exportCbz(work: File, target: File): Int {
        val files = readPages(work)
        ZipOutputStream(target.outputStream().buffered()).use { zos ->
            files.forEachIndexed { i, f ->
                zos.putNextEntry(ZipEntry("%04d.%s".format(Locale.US, i + 1, f.extension.lowercase(Locale.ROOT))))
                f.inputStream().use { it.copyTo(zos) }
                zos.closeEntry()
            }
        }
        return files.size
    }

    // ------------------------------------------------------------------ OCR

    class Block(val rect: Rect, val text: String)

    fun recognizer(lang: Int): TextRecognizer = when (lang) {
        0 -> TextRecognition.getClient(JapaneseTextRecognizerOptions.Builder().build())
        1 -> TextRecognition.getClient(KoreanTextRecognizerOptions.Builder().build())
        2 -> TextRecognition.getClient(ChineseTextRecognizerOptions.Builder().build())
        else -> TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
    }

    private fun hasCjk(s: String) = s.any { it.isLetter() && it.code >= 0x2E80 }

    private fun usable(s: String): Boolean {
        val letters = s.count { it.isLetter() }
        return letters >= 2 || (letters >= 1 && hasCjk(s))
    }

    /** Dekode gambar jadi bitmap yang bisa digambar; dikecilkan kalau terlalu besar. */
    fun decode(file: File): Bitmap? {
        val o = BitmapFactory.Options()
        o.inJustDecodeBounds = true
        BitmapFactory.decodeFile(file.path, o)
        if (o.outWidth <= 0 || o.outHeight <= 0) return null
        var sample = 1
        while (o.outWidth / sample > 2400 ||
            (o.outWidth / sample).toLong() * (o.outHeight / sample) > 20_000_000L
        ) sample *= 2
        val o2 = BitmapFactory.Options()
        o2.inSampleSize = sample
        o2.inMutable = true
        o2.inPreferredConfig = Bitmap.Config.ARGB_8888
        return BitmapFactory.decodeFile(file.path, o2)
    }

    /** Ada garis pembatas (tepi balon/kotak) yang melintang di strip ini? Strip = celah antara dua baris teks. */
    private fun hasSeparator(img: Bitmap, x0: Int, x1: Int, y0: Int, y1: Int): Boolean {
        val xs = maxOf(0, x0)
        val ys = maxOf(0, y0)
        val w = minOf(img.width, x1) - xs
        val h = minOf(img.height, y1) - ys
        if (w < 8 || h < 5) return false
        val px = IntArray(w * h)
        img.getPixels(px, 0, w, xs, ys, w, h)
        val lum = IntArray(w * h) { (Color.red(px[it]) * 299 + Color.green(px[it]) * 587 + Color.blue(px[it]) * 114) / 1000 }
        val med = lum.sorted()[lum.size / 2]
        var high = 0
        for (row in 0 until h) {
            var cnt = 0
            for (x in 0 until w) if (Math.abs(lum[row * w + x] - med) > 80) cnt++
            if (cnt >= 0.85f * w) high++
        }
        // Garis tepi balon = beberapa baris tipis yang hampir penuh; pita teks tidak dihitung.
        return high in 1..maxOf(4, h / 3)
    }

    /**
     * Kelompokkan baris-baris teks ke dalam balon/kotak yang sama: bertumpuk rapat, kolom sejajar,
     * tinggi huruf mirip, dan tidak ada garis tepi balon di antaranya.
     */
    private fun clusterLines(img: Bitmap, lines: List<Text.Line>, dbg: StringBuilder?): List<List<Text.Line>> {
        val ls = lines.filter { it.boundingBox != null }
        val n = ls.size
        val parent = IntArray(n) { it }
        fun find(x: Int): Int {
            var r = x
            while (parent[r] != r) r = parent[r]
            var c = x
            while (parent[c] != r) { val nx = parent[c]; parent[c] = r; c = nx }
            return r
        }
        for (i in 0 until n) for (j in i + 1 until n) {
            val a = ls[i].boundingBox!!
            val b = ls[j].boundingBox!!
            val lh = minOf(a.height(), b.height()).coerceAtLeast(1)
            if (maxOf(a.height(), b.height()) > 2.2f * lh) continue
            val gap = maxOf(a.top, b.top) - minOf(a.bottom, b.bottom)
            if (gap < -0.5f * lh || gap > 0.7f * maxOf(a.height(), b.height())) continue
            val ox = minOf(a.right, b.right) - maxOf(a.left, b.left)
            if (ox < 0.4f * minOf(a.width(), b.width())) continue
            val wMax = maxOf(a.width(), b.width())
            val aligned = Math.abs(a.centerX() - b.centerX()) <= 0.3f * wMax ||
                Math.abs(a.left - b.left) <= 0.6f * lh || Math.abs(a.right - b.right) <= 0.6f * lh
            if (!aligned) continue
            if (gap >= 6 && hasSeparator(img, maxOf(a.left, b.left), minOf(a.right, b.right), minOf(a.bottom, b.bottom), maxOf(a.top, b.top))) {
                dbg?.append("  PISAH(garis pembatas) [${ls[i].text.take(20)}] | [${ls[j].text.take(20)}] gap=$gap\n")
                continue
            }
            dbg?.append("  GABUNG [${ls[i].text.take(20)}] + [${ls[j].text.take(20)}] gap=$gap ox=$ox lh=$lh\n")
            val ra = find(i)
            val rb = find(j)
            if (ra != rb) parent[rb] = ra
        }
        val groups = LinkedHashMap<Int, MutableList<Text.Line>>()
        for (i in 0 until n) groups.getOrPut(find(i)) { mutableListOf() }.add(ls[i])
        return groups.values.map { g -> g.sortedWith(compareBy({ it.boundingBox!!.top }, { it.boundingBox!!.left })) }
    }

    /**
     * ML Kit kadang menyatukan beberapa balon/kotak yang bertumpuk (mis. chat di layar HP) jadi satu blok.
     * Pecah per balon: baris dipisah kalau ada garis pembatas di celahnya, celahnya lebar, atau kolomnya beda.
     */
    private fun splitLines(img: Bitmap, lines: List<Text.Line>, dbg: StringBuilder? = null): List<List<Text.Line>> {
        val ls = lines.filter { it.boundingBox != null }.sortedBy { it.boundingBox!!.top }
        if (ls.size < 2) return listOf(ls)
        val out = ArrayList<List<Text.Line>>()
        var cur = mutableListOf(ls[0])
        for (k in 1 until ls.size) {
            val a = ls[k - 1].boundingBox!!
            val b = ls[k].boundingBox!!
            val gap = b.top - a.bottom
            val lh = maxOf(a.height(), b.height())
            val ox = minOf(a.right, b.right) - maxOf(a.left, b.left)
            val reason = when {
                ox < 0.3f * minOf(a.width(), b.width()) -> "kolom beda"
                gap > lh -> "celah lebar"
                gap >= 6 && hasSeparator(img, maxOf(a.left, b.left), minOf(a.right, b.right), a.bottom, b.top) -> "garis pembatas"
                else -> ""
            }
            dbg?.append("  [${ls[k - 1].text.take(28)}] -> [${ls[k].text.take(28)}] gap=$gap lh=$lh ox=$ox ${if (reason.isEmpty()) "SATU" else "PISAH($reason)"}\n")
            if (reason.isNotEmpty()) {
                out.add(cur)
                cur = mutableListOf(ls[k])
            } else cur.add(ls[k])
        }
        out.add(cur)
        return out
    }

    /**
     * Baca teks per potongan tinggi. Gambar kecil diperbesar dulu (teks kecil sering lolos OCR).
     * Potongan sengaja saling tumpang tindih supaya teks di garis potong tidak terbelah; duplikat dibuang.
     */
    private fun readBlocks(rec: TextRecognizer, bmp: Bitmap, lang: Int, dbg: StringBuilder? = null): List<Block> {
        val all = ArrayList<Block>()
        val joiner = if (lang == 0 || lang == 2) "" else " "
        val scale = when {
            bmp.width <= 1100 -> 2f
            bmp.width <= 1700 -> 1.5f
            else -> 1f
        }
        val stripH = (STRIP_H / scale).toInt()
        val overlap = 160
        var y = 0
        while (true) {
            var h = minOf(stripH, bmp.height - y)
            if (bmp.height - (y + h) in 1..300) h = bmp.height - y
            val strip = Bitmap.createBitmap(bmp, 0, y, bmp.width, h)
            val big = if (scale == 1f) strip
            else Bitmap.createScaledBitmap(strip, (bmp.width * scale).toInt(), (h * scale).toInt(), true)
            try {
                val t = Tasks.await(rec.process(InputImage.fromBitmap(big, 0)))
                // Teks horizontal: kelompokkan ulang per BARIS (blok ML Kit sering memecah satu balon jadi banyak potongan).
                val groupList: List<List<Text.Line>> =
                    if (lang == 0) t.textBlocks.map { it.lines }
                    else clusterLines(big, t.textBlocks.flatMap { it.lines }, dbg)
                run {
                    for (g in groupList) {
                        val box = Rect()
                        var first = true
                        for (ln in g) {
                            val lb = ln.boundingBox ?: continue
                            if (first) { box.set(lb); first = false } else box.union(lb)
                        }
                        if (first) continue
                        val txt = g.joinToString(joiner) { it.text.trim() }.trim()
                        if (!usable(txt)) continue
                        all.add(
                            Block(
                                Rect(
                                    (box.left / scale).toInt(), (box.top / scale).toInt() + y,
                                    (box.right / scale).toInt(), (box.bottom / scale).toInt() + y
                                ), txt
                            )
                        )
                    }
                }
            } finally {
                if (big !== strip) big.recycle()
                if (strip !== bmp) strip.recycle()
            }
            if (y + h >= bmp.height) break
            y += maxOf(1, h - overlap)
        }
        if (all.size < 2) return all
        // Buang duplikat dari area tumpang tindih: simpan yang teksnya paling lengkap.
        val kept = ArrayList<Block>()
        for (b in all.sortedByDescending { it.text.length }) {
            val dup = kept.any { k ->
                val ix = minOf(k.rect.right, b.rect.right) - maxOf(k.rect.left, b.rect.left)
                val iy = minOf(k.rect.bottom, b.rect.bottom) - maxOf(k.rect.top, b.rect.top)
                if (ix <= 0 || iy <= 0) false
                else ix.toLong() * iy > 0.5 * minOf(k.rect.width().toLong() * k.rect.height(), b.rect.width().toLong() * b.rect.height())
            }
            if (!dup) kept.add(b)
        }
        return kept
    }

    // ------------------------------------------------------------------ gabung blok satu balon

    private fun close(a: Rect, b: Rect, lang: Int): Boolean {
        if (lang != 0) return false // teks horizontal: pemisahan per balon sudah ditangani saat OCR
        val dimA = minOf(a.width(), a.height())
        val dimB = minOf(b.width(), b.height())
        val gap = (minOf(dimA, dimB) * 0.6f).toInt().coerceIn(6, 20)
        val ra = Rect(a.left - gap, a.top - gap, a.right + gap, a.bottom + gap)
        return Rect.intersects(ra, b)
    }

    /** Urutan baca dua blok: manga Jepang kolom kanan dulu, lainnya atas dulu. */
    private fun firstIsBefore(a: Rect, b: Rect, lang: Int): Boolean {
        val sameRow = Math.abs(a.centerY() - b.centerY()) < maxOf(a.height(), b.height()) * 0.6f
        return if (lang == 0 && sameRow) a.centerX() > b.centerX() else a.top < b.top ||
            (a.top == b.top && a.left < b.left)
    }

    private fun merge(blocks: List<Block>, lang: Int): List<Block> {
        val joiner = if (lang == 0 || lang == 2) "" else " "
        val list = blocks.toMutableList()
        var changed = true
        while (changed) {
            changed = false
            loop@ for (i in list.indices) {
                for (j in i + 1 until list.size) {
                    val a = list[i]
                    val b = list[j]
                    if (close(a.rect, b.rect, lang)) {
                        val first = if (firstIsBefore(a.rect, b.rect, lang)) a else b
                        val second = if (first === a) b else a
                        val r = Rect(a.rect)
                        r.union(b.rect)
                        list[i] = Block(r, first.text + joiner + second.text)
                        list.removeAt(j)
                        changed = true
                        break@loop
                    }
                }
            }
        }
        // urutan baca antar balon
        val rtl = lang == 0
        val sorted = list.sortedBy { it.rect.top }
        val rows = ArrayList<MutableList<Block>>()
        for (b in sorted) {
            val row = rows.lastOrNull()
            if (row != null && b.rect.centerY() <= row.minOf { it.rect.bottom }) row.add(b) else rows.add(mutableListOf(b))
        }
        return rows.flatMap { row ->
            if (rtl) row.sortedByDescending { it.rect.right } else row.sortedBy { it.rect.left }
        }
    }

    // ------------------------------------------------------------------ gambar ulang

    private class Plan(val box: Rect, val erase: Rect, val bg: Int)

    private fun clampRect(r: Rect, bmp: Bitmap): Rect {
        val c = Rect(r)
        if (!c.intersect(0, 0, bmp.width, bmp.height)) return Rect(0, 0, 1, 1)
        return c
    }

    private fun colorDist(a: Int, b: Int): Int =
        Math.abs(Color.red(a) - Color.red(b)) + Math.abs(Color.green(a) - Color.green(b)) +
            Math.abs(Color.blue(a) - Color.blue(b))

    /**
     * Hapus hanya goresan teks (piksel yang beda dari warna latar) di [r], lalu isi dengan warna latar.
     * Kembalikan false kalau areanya terlalu "penuh" (bukan teks di atas latar rata); pemanggil lalu menutup satu kotak.
     */
    private fun eraseInk(bmp: Bitmap, r: Rect, bg: Int): Boolean {
        val w = r.width()
        val h = r.height()
        if (w < 2 || h < 2) return false
        val px = IntArray(w * h)
        bmp.getPixels(px, 0, w, r.left, r.top, w, h)
        val ink = BooleanArray(w * h)
        var cnt = 0L
        for (i in px.indices) if (colorDist(px[i], bg) > 90) { ink[i] = true; cnt++ }
        if (cnt > w.toLong() * h / 2) return false
        val rad = (minOf(w, h) * 0.04f).toInt().coerceIn(2, 5)
        val a = BooleanArray(w * h)
        val pre = IntArray(maxOf(w, h) + 1)
        for (y in 0 until h) {
            for (x in 0 until w) pre[x + 1] = pre[x] + if (ink[y * w + x]) 1 else 0
            for (x in 0 until w) a[y * w + x] = pre[minOf(w, x + rad + 1)] - pre[maxOf(0, x - rad)] > 0
        }
        for (x in 0 until w) {
            for (y in 0 until h) pre[y + 1] = pre[y] + if (a[y * w + x]) 1 else 0
            for (y in 0 until h) if (pre[minOf(h, y + rad + 1)] - pre[maxOf(0, y - rad)] > 0) px[y * w + x] = bg
        }
        bmp.setPixels(px, 0, w, r.left, r.top, w, h)
        return true
    }

    private fun render(bmp: Bitmap, blocks: List<Block>, tr: List<String>) {
        val n = minOf(blocks.size, tr.size)
        if (n == 0) return

        // Ambil warna latar SEBELUM ada yang digambar, supaya blok tetangga tidak ikut mempengaruhi.
        val plans = ArrayList<Plan>()
        for (i in 0 until n) {
            val r = blocks[i].rect
            val ex = maxOf(4, (r.width() * 0.05f).toInt())
            val ey = maxOf(4, (r.height() * 0.05f).toInt())
            val base = clampRect(Rect(r.left - ex, r.top - ey, r.right + ex, r.bottom + ey), bmp)
            val bg = TextUtil.sampleBg(bmp, base) or (0xFF shl 24)
            var box = base
            // Teks vertikal (kolom sempit): lebarkan kotak terjemahan kalau latar sekitarnya sama.
            if (base.height() > base.width() * 2) {
                val extra = (base.width() * 0.6f).toInt()
                val wide = clampRect(Rect(base.left - extra, base.top, base.right + extra, base.bottom), bmp)
                if (colorDist(bg, TextUtil.sampleBg(bmp, wide)) < 60) box = wide
            }
            plans.add(Plan(box, base, bg))
        }

        val c = Canvas(bmp)
        val fill = Paint(Paint.ANTI_ALIAS_FLAG)
        fill.style = Paint.Style.FILL
        val tp = TextPaint(Paint.ANTI_ALIAS_FLAG)
        tp.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)

        for (i in 0 until n) {
            val p = plans[i]
            val box = p.box
            if (box.width() < 8 || box.height() < 8) continue
            // Hapus semua teks asli dulu; terjemahan digambar sesudahnya supaya tidak tertimpa blok tetangga.
            if (!eraseInk(bmp, p.erase, p.bg)) {
                fill.color = p.bg
                val rad = minOf(box.width(), box.height()) * 0.12f
                c.drawRoundRect(RectF(box), rad, rad, fill)
            }
        }
        for (i in 0 until n) {
            val p = plans[i]
            val box = p.box
            if (box.width() < 8 || box.height() < 8) continue
            val text = tr[i].trim()
            if (text.isEmpty()) continue
            val pad = maxOf(2, (minOf(box.width(), box.height()) * 0.06f).toInt())
            val w = box.width() - 2 * pad
            val h = box.height() - 2 * pad
            if (w < 6 || h < 6) continue

            tp.color = if (TextUtil.luminance(p.bg) > 128) Color.parseColor("#111111") else Color.WHITE
            var size = minOf(h * 0.8f, 90f).coerceAtLeast(9f)
            var layout = layoutOf(text, tp, size, w)
            while (layout.height > h && size > 9f) {
                size = maxOf(9f, size * 0.93f)
                layout = layoutOf(text, tp, size, w)
            }
            // Kata tidak boleh terpotong: kecilkan lagi (sampai batas bawah) kalau kata terpanjang tidak muat.
            val words = text.split(Regex("\\s+"))
            while (words.any { tp.measureText(it) > w } && size > 8f) {
                size = maxOf(8f, size * 0.93f)
                layout = layoutOf(text, tp, size, w)
            }
            c.save()
            c.translate((box.left + pad).toFloat(), box.top + pad + (h - layout.height) / 2f)
            layout.draw(c)
            c.restore()
        }
    }

    private fun layoutOf(text: String, tp: TextPaint, size: Float, width: Int): StaticLayout {
        tp.textSize = size
        return StaticLayout.Builder.obtain(text, 0, text.length, tp, width)
            .setAlignment(Layout.Alignment.ALIGN_CENTER)
            .setIncludePad(false)
            .build()
    }

    // ------------------------------------------------------------------ satu halaman

    /** Gambar halaman asli dengan kotak merah + nomor untuk tiap blok yang dibaca (bahan debug). */
    private fun saveDebugImage(bmp: Bitmap, blocks: List<Block>, target: File) {
        val copy = bmp.copy(Bitmap.Config.ARGB_8888, true)
        try {
            val cv = Canvas(copy)
            val pnt = Paint()
            pnt.style = Paint.Style.STROKE
            pnt.strokeWidth = 3f
            pnt.color = Color.RED
            val tx = Paint(Paint.ANTI_ALIAS_FLAG)
            tx.color = Color.BLUE
            tx.textSize = 30f
            blocks.forEachIndexed { i, b ->
                cv.drawRect(RectF(b.rect), pnt)
                cv.drawText("$i", b.rect.left + 3f, b.rect.top + 28f, tx)
            }
            target.outputStream().use { copy.compress(Bitmap.CompressFormat.JPEG, 75, it) }
        } finally {
            copy.recycle()
        }
    }

    /** Proses satu halaman dan simpan hasilnya sebagai JPEG. Kembalikan jumlah blok teks yang diterjemahkan. */
    fun processPage(
        file: File,
        outFile: File,
        rec: TextRecognizer,
        lang: Int,
        translate: (List<String>) -> List<String>,
        onStep: (String) -> Unit,
        onTiming: (String) -> Unit = {},
        debugDir: File? = null
    ): Int {
        val bmp = decode(file) ?: throw IllegalStateException("Gambar tidak terbaca: ${file.name}")
        try {
            onStep("membaca teks")
            val t0 = System.currentTimeMillis()
            val dbg = if (debugDir != null) StringBuilder() else null
            val blocks = merge(readBlocks(rec, bmp, lang, dbg), lang)
            val t1 = System.currentTimeMillis()
            var t2 = t1
            var trOut: List<String> = emptyList()
            if (debugDir != null) {
                try { saveDebugImage(bmp, blocks, File(debugDir.apply { mkdirs() }, outFile.nameWithoutExtension + ".jpg")) } catch (_: Throwable) {}
            }
            if (blocks.isNotEmpty()) {
                onStep("menerjemahkan ${blocks.size} blok")
                val tr = translate(blocks.map { it.text })
                trOut = tr
                t2 = System.currentTimeMillis()
                onStep("menggambar")
                render(bmp, blocks, tr)
            }
            if (debugDir != null) {
                try {
                    debugDir.mkdirs()
                    File(debugDir, outFile.nameWithoutExtension + ".txt").writeText(buildString {
                        append("gambar ${bmp.width}x${bmp.height}, bahasa $lang, ${blocks.size} blok akhir\n\n")
                        append("--- keputusan pemisahan baris ---\n").append(dbg).append("\n--- blok akhir ---\n")
                        blocks.forEachIndexed { i, b ->
                            append("#$i rect=${b.rect.left},${b.rect.top},${b.rect.right},${b.rect.bottom}\n  asli: ${b.text}\n  terjemah: ${trOut.getOrNull(i) ?: "-"}\n")
                        }
                    })
                } catch (_: Throwable) {}
            }
            onTiming("OCR ${t1 - t0}ms, terjemah ${t2 - t1}ms, gambar ${System.currentTimeMillis() - t2}ms")
            outFile.parentFile?.mkdirs()
            val tmp = File(outFile.parentFile, outFile.name + ".tmp")
            tmp.outputStream().use { bmp.compress(Bitmap.CompressFormat.JPEG, 92, it) }
            if (!tmp.renameTo(outFile)) {
                tmp.copyTo(outFile, true)
                tmp.delete()
            }
            return blocks.size
        } finally {
            bmp.recycle()
        }
    }
}
