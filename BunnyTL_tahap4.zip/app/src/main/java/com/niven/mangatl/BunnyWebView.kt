package com.niven.mangatl

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.Color
import android.util.AttributeSet
import android.view.MotionEvent
import android.webkit.JavascriptInterface
import android.webkit.WebView
import android.webkit.WebViewClient

/**
 * Tombol pemutar kelinci (prev / play-pause / next). Isinya HTML di assets/bunny/bunny_player.html.
 * WebView dibuat lebih tinggi dari barisnya supaya animasi loncat tidak terpotong; sentuhan di bagian atas
 * yang transparan diteruskan ke view di bawahnya (seekbar), hanya [hotDp] paling bawah yang menangkap sentuhan.
 */
class BunnyWebView @JvmOverloads constructor(context: Context, attrs: AttributeSet? = null) : WebView(context, attrs) {

    var onPlayPause: (() -> Unit)? = null
    var onPrev: (() -> Unit)? = null
    var onNext: (() -> Unit)? = null
    var hotDp = 126f

    private var ready = false
    private var firstPush = true
    private var pending: Boolean? = null
    private var pass = false

    private inner class Bridge {
        @JavascriptInterface fun playPause() { post { onPlayPause?.invoke() } }
        @JavascriptInterface fun prev() { post { onPrev?.invoke() } }
        @JavascriptInterface fun next() { post { onNext?.invoke() } }
    }

    @SuppressLint("SetJavaScriptEnabled")
    fun setup() {
        setBackgroundColor(Color.TRANSPARENT)
        overScrollMode = OVER_SCROLL_NEVER
        isVerticalScrollBarEnabled = false
        isHorizontalScrollBarEnabled = false
        isHapticFeedbackEnabled = false
        setOnLongClickListener { true }
        settings.javaScriptEnabled = true
        addJavascriptInterface(Bridge(), "Android")
        webViewClient = object : WebViewClient() {
            override fun onPageFinished(view: WebView?, url: String?) {
                ready = true
                pending?.let { pending = null; setPlaying(it) }
            }
        }
        loadUrl("file:///android_asset/bunny/bunny_player.html")
    }

    /** Sinkronkan ikon & animasi dengan status pemutar. Panggilan pertama tanpa animasi loncat. */
    fun setPlaying(p: Boolean) {
        if (!ready) { pending = p; return }
        val silent = firstPush
        firstPush = false
        evaluateJavascript("window.setPlaying&&window.setPlaying($p,$silent)", null)
    }

    override fun dispatchTouchEvent(ev: MotionEvent): Boolean {
        if (ev.actionMasked == MotionEvent.ACTION_DOWN) {
            pass = ev.y < height - hotDp * resources.displayMetrics.density
        }
        if (pass) return false
        return super.dispatchTouchEvent(ev)
    }
}
