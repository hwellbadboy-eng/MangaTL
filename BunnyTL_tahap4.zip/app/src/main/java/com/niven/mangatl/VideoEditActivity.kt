package com.niven.mangatl

import android.content.ContentValues
import android.content.res.ColorStateList
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.view.Gravity
import android.view.MotionEvent
import android.view.ScaleGestureDetector
import android.view.TextureView
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.IntentSenderRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import androidx.media3.common.C
import androidx.media3.common.Effect
import androidx.media3.common.MediaItem
import androidx.media3.common.OverlaySettings
import androidx.media3.common.Player
import androidx.media3.common.VideoCompositorSettings
import androidx.media3.common.audio.AudioProcessor
import androidx.media3.common.audio.BaseAudioProcessor
import androidx.media3.common.audio.ChannelMixingAudioProcessor
import androidx.media3.common.audio.ChannelMixingMatrix
import androidx.media3.common.audio.SonicAudioProcessor
import androidx.media3.common.util.Size
import androidx.media3.effect.Presentation
import androidx.media3.effect.RgbMatrix
import androidx.media3.effect.SpeedChangeEffect
import androidx.media3.effect.StaticOverlaySettings
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.transformer.Composition
import androidx.media3.transformer.DefaultEncoderFactory
import androidx.media3.transformer.EditedMediaItem
import androidx.media3.transformer.EditedMediaItemSequence
import androidx.media3.transformer.Effects
import androidx.media3.transformer.ExportException
import androidx.media3.transformer.ExportResult
import androidx.media3.transformer.ProgressHolder
import androidx.media3.transformer.Transformer
import androidx.media3.transformer.VideoEncoderSettings
import androidx.media3.ui.AspectRatioFrameLayout
import androidx.media3.ui.PlayerView
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.nio.ByteBuffer
import java.util.Locale

/**
 * Editor video dasar: pisah klip, hapus bagian, percepat/perlambat, sambung video/foto,
 * tambah lagu. Hasil disimpan dengan resolusi dan bitrate mengikuti video asli.
 */
class VideoEditActivity : AppCompatActivity() {

    /** Dasar untuk semua yang bisa dipudarkan: panjang pudar (ms) dan titik lekuk di kurva (0..1 dari tepi klip). */
    open class Fadable {
        var fadeIn = 0L
        var fadeOut = 0L
        var inX = 0.5f
        var inY = 0.5f
        var outX = 0.5f
        var outY = 0.5f

        open fun length(): Long = 0L

        fun fade() = TimelineView.Fade(fadeIn, fadeOut, inX, inY, outX, outY)

        /** Pudar tidak boleh lebih panjang dari klipnya. */
        fun clampFades() {
            val d = length()
            fadeIn = fadeIn.coerceIn(0L, d)
            fadeOut = fadeOut.coerceIn(0L, d - fadeIn)
        }

        fun copyFadeTo(o: Fadable) {
            o.fadeIn = fadeIn
            o.fadeOut = fadeOut
            o.inX = inX
            o.inY = inY
            o.outX = outX
            o.outY = outY
        }
    }

    class Clip(
        val uri: Uri,
        val photo: Boolean,
        val srcDur: Long,
        var start: Long,
        var end: Long,
        var speed: Float,
        val w: Int,
        val h: Int,
        val bitrate: Int,
        var photoMs: Long = 3000L
    ) : Fadable() {
        /** false = Pas layar (ada bar hitam), true = Penuh (mengisi kanvas, tepi terpotong). */
        var fill = false

        fun dur(): Long =
            if (photo) photoMs else (((end - start) / speed).toLong()).coerceAtLeast(1L)

        override fun length(): Long = dur()

        fun copy(): Clip {
            val c = Clip(uri, photo, srcDur, start, end, speed, w, h, bitrate, photoMs)
            c.fill = fill
            copyFadeTo(c)
            return c
        }
    }

    /** Satu potongan lagu di timeline: mulai di detik video ke [start], memakai bagian lagu [from]..[to]. */
    class Seg(
        var start: Long,
        var from: Long,
        var to: Long
    ) : Fadable() {
        fun len(): Long = to - from
        fun end(): Long = start + len()
        override fun length(): Long = len()

        fun copy(): Seg {
            val c = Seg(start, from, to)
            copyFadeTo(c)
            return c
        }
    }

    /**
     * Satu lapisan video/foto di atas video utama. Satu lapisan = satu baris di timeline.
     * Posisi di layar: (cx,cy) = titik tengah (0..1 dari frame), wf = lebar (1 = selebar frame).
     */
    class Ov(
        val uri: Uri,
        val photo: Boolean,
        val srcDur: Long,
        var srcStart: Long,
        var srcEnd: Long,
        var speed: Float,
        val w: Int,
        val h: Int,
        var photoMs: Long,
        var start: Long
    ) : Fadable() {
        var cx = 0.5f
        var cy = 0.5f
        var wf = 1f

        // hanya untuk pratinjau, tidak ikut disalin ke riwayat
        var view: View? = null
        var player: ExoPlayer? = null
        var running = false

        fun dur(): Long =
            if (photo) photoMs else (((srcEnd - srcStart) / speed).toLong()).coerceAtLeast(1L)

        override fun length(): Long = dur()

        fun aspect(): Float = if (w > 0 && h > 0) w.toFloat() / h else 16f / 9f

        fun copy(): Ov {
            val o = Ov(uri, photo, srcDur, srcStart, srcEnd, speed, w, h, photoMs, start)
            o.cx = cx
            o.cy = cy
            o.wf = wf
            copyFadeTo(o)
            return o
        }
    }

    private class Snap(val clips: List<Clip>, val segs: List<Seg>, val ovs: List<Ov>)

    private var clips = ArrayList<Clip>()
    private var segs = ArrayList<Seg>()
    private var ovs = ArrayList<Ov>()
    private val history = ArrayList<Snap>()
    private var sel = -1
    private var selA = -1
    private var selO = -1
    private var curSeg = -1
    private var playhead = 0L

    private var song: Uri? = null
    private var songName = ""
    private var songDur = 0L
    private var songVol = 1f
    private var origVol = 1f

    private lateinit var origUri: Uri
    private var origName = "video.mp4"
    private var origRel = ""

    private lateinit var player: ExoPlayer
    private var audioPlayer: ExoPlayer? = null
    private lateinit var playerView: PlayerView
    private lateinit var timeline: TimelineView
    private lateinit var tvTime: TextView
    private lateinit var fadeCover: View
    private lateinit var pvBox: FrameLayout
    private lateinit var stage: FrameLayout
    private lateinit var ovBar: View
    private lateinit var tvZoom: TextView
    private var selBox: View? = null
    private lateinit var canvasFrame: FrameLayout
    private var canvasKey = "asli"
    private var ovExtra: List<View> = emptyList()
    private var pendingHistory = false
    private var needRebuild = false
    private var needOvRebuild = false

    // gerakan di pratinjau (geser dan cubit lapisan)
    private var stLastX = 0f
    private var stLastY = 0f
    private var stDownX = 0f
    private var stDownY = 0f
    private var stMoved = false
    private var stHit = -1
    private var stHist = false
    private lateinit var btnPlay: ImageButton

    private val handler = Handler(Looper.getMainLooper())
    private var transformer: Transformer? = null
    private var progressBar: ProgressBar? = null
    private var tvPct: TextView? = null
    private var progressDlg: AlertDialog? = null
    private var outFile: File? = null
    private var exporting = false
    private var pendingWrite: (() -> Unit)? = null

    private val addPicker = registerForActivityResult(
        ActivityResultContracts.OpenMultipleDocuments()
    ) { uris ->
        if (uris.isEmpty()) return@registerForActivityResult
        lifecycleScope.launch {
            val loaded = withContext(Dispatchers.IO) { uris.mapNotNull { loadClip(it) } }
            if (loaded.isEmpty()) {
                toast("File tidak bisa dibuka.")
                return@launch
            }
            pushHistory()
            var idx = 0
            if (clips.isNotEmpty()) {
                val (i, off) = locate(playhead)
                val c = clips[i]
                idx = if (!c.photo && off >= 300L && c.dur() - off >= 300L) {
                    val srcOff = (off * c.speed).toLong()
                    val a = c.copy()
                    a.end = c.start + srcOff
                    a.fadeOut = 0L
                    a.clampFades()
                    val b = c.copy()
                    b.start = c.start + srcOff
                    b.fadeIn = 0L
                    b.clampFades()
                    clips[i] = a
                    clips.add(i + 1, b)
                    i + 1
                } else if (off >= c.dur() / 2) i + 1 else i
            }
            clips.addAll(idx, loaded)
            sel = idx
            selA = -1
            selO = -1
            var before = 0L
            for (k in 0 until idx) before += clips[k].dur()
            rebuild(before)
            toast("Ditambahkan di posisi garis putih.")
        }
    }

    private val ovPicker = registerForActivityResult(
        ActivityResultContracts.OpenMultipleDocuments()
    ) { uris ->
        if (uris.isEmpty() || clips.isEmpty()) return@registerForActivityResult
        lifecycleScope.launch {
            val loaded = withContext(Dispatchers.IO) { uris.mapNotNull { loadClip(it) } }
            if (loaded.isEmpty()) {
                toast("File tidak bisa dibuka.")
                return@launch
            }
            pushHistory()
            val tot = total()
            val start = if (tot - playhead < 500L) 0L else playhead
            for (c in loaded) {
                val o = ovFrom(c, start, tot)
                fitOv(o, false)
                ovs.add(o)
            }
            rebuildOverlays()
            selectItem(TimelineView.K_OV, ovs.lastIndex)
            pushTimeline()
            toast("Lapisan ditambahkan di posisi garis putih.")
        }
    }

    private val writeLauncher = registerForActivityResult(
        ActivityResultContracts.StartIntentSenderForResult()
    ) { r ->
        val cb = pendingWrite
        pendingWrite = null
        if (r.resultCode == RESULT_OK) cb?.invoke() else {
            toast("Izin tulis ditolak. Video asli tidak diubah.")
            outFile?.delete()
        }
    }

    // ------------------------------------------------------------------ UI

    private fun dp(v: Int) = Ui.dp(this, v)
    private fun clr(id: Int) = ContextCompat.getColor(this, id)
    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()

    private fun label(text: String) = TextView(this).apply {
        this.text = text
        textSize = 11f
        setTextColor(clr(R.color.muted))
        setPadding(0, 0, 0, dp(4))
    }

    private fun tool(icon: Int, name: String, onClick: () -> Unit): View {
        val l = LinearLayout(this)
        l.orientation = LinearLayout.VERTICAL
        l.gravity = Gravity.CENTER
        l.setPadding(0, dp(8), 0, dp(8))
        l.layoutParams = LinearLayout.LayoutParams(dp(68), ViewGroup.LayoutParams.WRAP_CONTENT)
        val iv = ImageView(this)
        iv.setImageResource(icon)
        iv.setColorFilter(Color.WHITE)
        iv.layoutParams = LinearLayout.LayoutParams(dp(22), dp(22))
        l.addView(iv)
        l.addView(TextView(this).apply {
            text = name
            textSize = 11f
            gravity = Gravity.CENTER
            setTextColor(clr(R.color.text_soft))
            maxLines = 1
            setPadding(0, dp(2), 0, 0)
        })
        l.setOnClickListener { onClick() }
        return l
    }

    private fun iconButton(res: Int, desc: String, onClick: () -> Unit): ImageButton {
        val b = ImageButton(this)
        b.setImageResource(res)
        b.setColorFilter(Color.WHITE)
        b.contentDescription = desc
        b.setBackgroundColor(Color.TRANSPARENT)
        b.setPadding(dp(10), dp(10), dp(10), dp(10))
        b.setOnClickListener { onClick() }
        return b
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val uriStr = intent.getStringExtra("uri")
        if (uriStr == null) {
            finish()
            return
        }
        origUri = Uri.parse(uriStr)
        origName = intent.getStringExtra("name") ?: "video.mp4"
        origRel = intent.getStringExtra("rel") ?: ""

        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setBackgroundColor(clr(R.color.bg))
        root.setPadding(dp(12), dp(8), dp(12), dp(8))

        // bilah atas
        val top = LinearLayout(this)
        top.orientation = LinearLayout.HORIZONTAL
        top.gravity = Gravity.CENTER_VERTICAL
        top.addView(iconButton(R.drawable.ic_back, "Kembali") { askLeave() })
        top.addView(TextView(this).apply {
            text = "Edit video"
            textSize = 16f
            typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
            setTextColor(Color.WHITE)
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
                .apply { marginStart = dp(6) }
        })
        top.addView(iconButton(R.drawable.ic_undo, "Urungkan") { undo() })
        top.addView(TextView(this).apply {
            text = "Simpan"
            textSize = 13f
            typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
            setTextColor(Color.parseColor("#000000"))
            setPadding(dp(16), dp(8), dp(16), dp(8))
            background = GradientDrawable().apply {
                setColor(Color.parseColor("#F2F2F2"))
                cornerRadius = dp(14).toFloat()
            }
            setOnClickListener { askSave() }
        })
        root.addView(top)

        // pratinjau
        val pv = FrameLayout(this)
        pv.setBackgroundColor(Color.BLACK)
        pv.layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f)
            .apply { topMargin = dp(8) }
        playerView = PlayerView(this)
        playerView.useController = false
        playerView.setShutterBackgroundColor(Color.BLACK)
        canvasFrame = FrameLayout(this)
        canvasFrame.setBackgroundColor(Color.BLACK)
        canvasFrame.foreground = GradientDrawable().apply {
            setColor(Color.TRANSPARENT)
            setStroke(dp(1), Color.parseColor("#2A2A2E"))
        }
        pv.addView(canvasFrame, FrameLayout.LayoutParams(-1, -1, Gravity.CENTER))
        canvasFrame.addView(playerView, FrameLayout.LayoutParams(-1, -1))
        fadeCover = View(this)
        fadeCover.setBackgroundColor(Color.BLACK)
        fadeCover.alpha = 0f
        canvasFrame.addView(fadeCover, FrameLayout.LayoutParams(-1, -1))
        setupStage(pv)
        btnPlay = iconButton(R.drawable.ic_play, "Putar") { togglePlay() }
        pv.addView(btnPlay, FrameLayout.LayoutParams(dp(64), dp(64), Gravity.CENTER))
        tvTime = TextView(this).apply {
            textSize = 12f
            setTextColor(clr(R.color.text_soft))
            setPadding(dp(10), 0, 0, dp(8))
        }
        pv.addView(tvTime, FrameLayout.LayoutParams(-2, -2, Gravity.BOTTOM or Gravity.START))
        pvBox = pv
        root.addView(pv)
        ovBar = buildOvBar()
        root.addView(ovBar)

        // timeline
        val card = LinearLayout(this)
        card.orientation = LinearLayout.VERTICAL
        card.setBackgroundResource(R.drawable.bg_card)
        card.setPadding(dp(12), dp(10), dp(12), dp(12))
        card.layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            .apply { topMargin = dp(10) }
        val zr = LinearLayout(this)
        zr.orientation = LinearLayout.HORIZONTAL
        zr.gravity = Gravity.END or Gravity.CENTER_VERTICAL
        zr.addView(chip("−") { timeline.zoomBy(1f / 1.5f) })
        tvZoom = TextView(this).apply {
            text = "1.0x"
            textSize = 12f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            minWidth = dp(48)
        }
        zr.addView(tvZoom)
        zr.addView(chip("+") { timeline.zoomBy(1.5f) })
        card.addView(zr)

        timeline = TimelineView(this)
        timeline.layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, timeline.wantedHeightPx(0))
        timeline.onScrub = { ms, pick -> scrub(ms, pick) }
        timeline.onSelect = { k, i -> selectItem(k, i) }
        timeline.onDragStart = { pendingHistory = true }
        timeline.onEdit = { k, i, m, ms -> editItem(k, i, m, ms) }
        timeline.onBend = { k, i, isIn, x, y -> bendItem(k, i, isIn, x, y) }
        timeline.onZoomChanged = { z -> tvZoom.text = String.format(Locale.US, "%.1fx", z) }
        timeline.onDragEnd = {
            pendingHistory = false
            if (needRebuild) {
                needRebuild = false
                rebuild(playhead.coerceAtMost(total()))
            }
            if (needOvRebuild) {
                needOvRebuild = false
                rebuildOverlays()
            }
        }
        card.addView(timeline)
        root.addView(card)

        // alat
        val tools = LinearLayout(this)
        tools.orientation = LinearLayout.HORIZONTAL
        tools.addView(tool(R.drawable.ic_cut, "Pisah") { split() })
        tools.addView(tool(R.drawable.ic_trash, "Hapus") { deleteSel() })
        tools.addView(tool(R.drawable.ic_prev, "Geser kiri") { moveSel(-1) })
        tools.addView(tool(R.drawable.ic_next, "Geser kanan") { moveSel(1) })
        tools.addView(tool(R.drawable.ic_speed, "Kecepatan") { speedDialog() })
        tools.addView(tool(R.drawable.ic_movie, "Video/foto") { addPicker.launch(arrayOf("video/*", "image/*")) })
        tools.addView(tool(R.drawable.ic_layers, "Lapisan") { addLayer() })
        tools.addView(tool(R.drawable.ic_trim, "Ukuran") { canvasDialog() })
        tools.addView(tool(R.drawable.ic_music_note, "Lagu") { pickSong() })
        tools.addView(tool(R.drawable.ic_volume, "Suara") { volumeDialog() })
        val hs = HorizontalScrollView(this)
        hs.isHorizontalScrollBarEnabled = false
        hs.addView(tools)
        hs.layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            .apply { topMargin = dp(6) }
        root.addView(hs)

        setContentView(root)

        player = ExoPlayer.Builder(this, Decoders.factory(this, Prefs.decoder(this))).build()
        playerView.player = player
        player.addListener(object : Player.Listener {
            override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) = applySpeed()
            override fun onIsPlayingChanged(isPlaying: Boolean) {
                btnPlay.setImageResource(if (isPlaying) R.drawable.ic_pause else R.drawable.ic_play)
                if (isPlaying) {
                    handler.post(tick)
                } else {
                    playhead = globalNow()
                }
                syncAudio(isPlaying)
                syncOverlays(true)
            }

            override fun onPlaybackStateChanged(playbackState: Int) {
                if (playbackState == Player.STATE_ENDED) {
                    player.pause()
                    playhead = 0L
                    rebuild(0L)
                }
            }
        })
        playerView.setOnClickListener { togglePlay() }

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() = askLeave()
        })

        lifecycleScope.launch {
            val c = withContext(Dispatchers.IO) { loadClip(origUri) }
            if (c == null) {
                toast("Video tidak bisa dibuka.")
                finish()
                return@launch
            }
            clips.add(c)
            rebuild(0L)
            canvasDialog()
        }
    }

    // ------------------------------------------------------------------ data klip

    private fun loadClip(uri: Uri): Clip? {
        val type = contentResolver.getType(uri) ?: ""
        if (type.startsWith("image/")) {
            return try {
                val o = BitmapFactory.Options()
                o.inJustDecodeBounds = true
                contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, o) }
                Clip(uri, true, 0L, 0L, 0L, 1f, o.outWidth, o.outHeight, 0)
            } catch (e: Exception) {
                null
            }
        }
        val r = MediaMetadataRetriever()
        return try {
            r.setDataSource(this, uri)
            val dur = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L
            var w = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH)?.toIntOrNull() ?: 0
            var h = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT)?.toIntOrNull() ?: 0
            val rot = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_ROTATION)?.toIntOrNull() ?: 0
            if (rot == 90 || rot == 270) {
                val t = w
                w = h
                h = t
            }
            val br = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_BITRATE)?.toIntOrNull() ?: 0
            if (dur <= 0L) null else Clip(uri, false, dur, 0L, dur, 1f, w, h, br)
        } catch (e: Exception) {
            null
        } finally {
            try {
                r.release()
            } catch (e: Exception) {
            }
        }
    }

    private fun total() = clips.sumOf { it.dur() }

    private fun locate(g: Long): Pair<Int, Long> {
        var acc = 0L
        for (i in clips.indices) {
            val d = clips[i].dur()
            if (g < acc + d || i == clips.lastIndex) return i to (g - acc).coerceIn(0L, d)
            acc += d
        }
        return 0 to 0L
    }

    private fun globalNow(): Long {
        val i = player.currentMediaItemIndex
        if (i !in clips.indices) return playhead
        var acc = 0L
        for (k in 0 until i) acc += clips[k].dur()
        val pos = player.currentPosition.coerceAtLeast(0L)
        val c = clips[i]
        val off = if (c.photo) pos else (pos / c.speed).toLong()
        return acc + off.coerceAtMost(c.dur())
    }

    private fun pushHistory() {
        history.add(Snap(clips.map { it.copy() }, segs.map { it.copy() }, ovs.map { it.copy() }))
        if (history.size > 40) history.removeAt(0)
    }

    private fun undo() {
        if (history.isEmpty()) {
            toast("Tidak ada yang bisa diurungkan.")
            return
        }
        val snap = history.removeAt(history.size - 1)
        releaseOverlays()
        clips = ArrayList(snap.clips)
        segs = ArrayList(snap.segs)
        ovs = ArrayList(snap.ovs)
        sel = -1
        selA = -1
        selO = -1
        if (segs.isEmpty() && song != null) clearSong()
        rebuildOverlays()
        rebuild(playhead.coerceAtMost(total()))
    }

    // ------------------------------------------------------------------ pratinjau

    private fun rebuild(seekGlobal: Long) {
        if (clips.isEmpty()) return
        val items = clips.map { c ->
            val b = MediaItem.Builder().setUri(c.uri)
            if (c.photo) {
                contentResolver.getType(c.uri)?.let { b.setMimeType(it) }
                b.setImageDurationMs(c.photoMs)
            } else {
                b.setClippingConfiguration(
                    MediaItem.ClippingConfiguration.Builder()
                        .setStartPositionMs(c.start)
                        .setEndPositionMs(c.end)
                        .build()
                )
            }
            b.build()
        }
        playhead = seekGlobal.coerceIn(0L, total())
        val (i, off) = locate(playhead)
        val c = clips[i]
        val inClip = if (c.photo) off else (off * c.speed).toLong()
        player.setMediaItems(items, i, inClip)
        player.volume = origVol
        player.prepare()
        applySpeed()
        pushTimeline()
        pvBox.post { layoutStage() }
    }

    private fun pushTimeline() {
        var acc = 0L
        val m = clips.mapIndexed { i, c ->
            val item = TimelineView.Item(
                acc, c.dur(),
                if (c.photo) "Foto" else ('A' + (i % 26)).toString(),
                if (!c.photo && c.speed != 1f) TimelineView.fmtSpeed(c.speed) else null,
                c.photo, c.fade()
            )
            acc += c.dur()
            item
        }
        val ov = ovs.mapIndexed { i, o -> TimelineView.Item(o.start, o.dur(), "L" + (i + 1), null, o.photo, o.fade()) }
        val au = segs.map { TimelineView.Item(it.start, it.len(), "Lagu", null, false, it.fade()) }
        val h = timeline.wantedHeightPx(ovs.size)
        if (timeline.layoutParams.height != h) {
            timeline.layoutParams.height = h
            timeline.requestLayout()
        }
        timeline.setData(m, ov, au)
        timeline.selV = sel
        timeline.selO = selO
        timeline.selA = selA
        timeline.playheadMs = playhead
        updateOvBar()
        updateTime()
        syncOverlays(false)
    }

    private fun updateTime() {
        tvTime.text = Library.fmt(playhead) + " / " + Library.fmt(total())
        applyFadePreview()
    }

    /** Pratinjau pudar video: layar menggelap sesuai kurva di posisi putar. */
    private fun applyFadePreview() {
        if (clips.isEmpty()) return
        val (i, off) = locate(playhead)
        val c = clips[i]
        fadeCover.alpha = 1f - TimelineView.fadeGain(off, c.dur(), c.fade())
    }

    private fun applySpeed() {
        val i = player.currentMediaItemIndex
        val s = if (i in clips.indices && !clips[i].photo) clips[i].speed else 1f
        player.setPlaybackSpeed(s)
        playerView.resizeMode =
            if (i in clips.indices && clips[i].fill) AspectRatioFrameLayout.RESIZE_MODE_ZOOM else AspectRatioFrameLayout.RESIZE_MODE_FIT
    }

    private val tick = object : Runnable {
        override fun run() {
            if (!player.isPlaying) return
            playhead = globalNow()
            timeline.playheadMs = playhead
            updateTime()
            audioTick()
            syncOverlays(false)
            handler.postDelayed(this, 50)
        }
    }

    private fun togglePlay() {
        if (player.isPlaying) player.pause() else player.play()
    }

    private fun scrub(ms: Long, pick: Boolean) {
        if (clips.isEmpty() || exporting) return
        playhead = ms.coerceIn(0L, total())
        val (i, off) = locate(playhead)
        if (pick) {
            sel = i
            selA = -1
            selO = -1
        }
        val c = clips[i]
        val inClip = if (c.photo) off else (off * c.speed).toLong()
        player.seekTo(i, inClip)
        applySpeed()
        timeline.selV = sel
        timeline.selO = selO
        timeline.selA = selA
        updateOvBar()
        timeline.playheadMs = playhead
        updateTime()
        audioPlayer?.pause()
        curSeg = -1
        syncOverlays(true)
    }

    private fun syncAudio(playing: Boolean) {
        if (playing) audioTick() else audioPlayer?.pause()
    }

    /** Jalankan lagu hanya saat posisi putar ada di salah satu potongan lagu, dengan volume mengikuti kurva pudar. */
    private fun audioTick() {
        val a = audioPlayer ?: return
        var found = -1
        for (k in segs.indices) {
            val sg = segs[k]
            if (playhead >= sg.start && playhead < sg.end()) {
                found = k
                break
            }
        }
        if (player.isPlaying && found >= 0) {
            val sg = segs[found]
            val rel = playhead - sg.start
            if (!a.isPlaying || curSeg != found) {
                a.seekTo(sg.from + rel)
                a.play()
                curSeg = found
            }
            a.volume = songVol * TimelineView.fadeGain(rel, sg.len(), sg.fade())
        } else if (a.isPlaying) {
            a.pause()
            curSeg = -1
        }
    }

    // ------------------------------------------------------------------ alat

    private fun splitSeg() {
        val sg = segs[selA]
        val rel = playhead - sg.start
        if (rel < 300L || sg.len() - rel < 300L) {
            toast("Geser garis putih ke tengah lagu dulu.")
            return
        }
        pushHistory()
        val b = sg.copy()
        b.start = playhead
        b.from = sg.from + rel
        b.fadeIn = 0L
        sg.to = sg.from + rel
        sg.fadeOut = 0L
        sg.clampFades()
        b.clampFades()
        segs.add(selA + 1, b)
        pushTimeline()
    }

    private fun splitOv() {
        val o = ovs[selO]
        val rel = playhead - o.start
        if (rel < 300L || o.dur() - rel < 300L) {
            toast("Geser garis putih ke tengah lapisan dulu.")
            return
        }
        pushHistory()
        val b = o.copy()
        b.start = playhead
        if (o.photo) {
            b.photoMs = o.photoMs - rel
            o.photoMs = rel
        } else {
            val srcRel = (rel * o.speed).toLong()
            b.srcStart = o.srcStart + srcRel
            o.srcEnd = o.srcStart + srcRel
        }
        o.fadeOut = 0L
        b.fadeIn = 0L
        o.clampFades()
        b.clampFades()
        ovs.add(selO + 1, b)
        rebuildOverlays()
        pushTimeline()
    }

    private fun split() {
        if (selO in ovs.indices) {
            splitOv()
            return
        }
        if (selA in segs.indices) {
            splitSeg()
            return
        }
        if (clips.isEmpty()) return
        val (i, off) = locate(playhead)
        val c = clips[i]
        if (c.photo) {
            toast("Foto tidak bisa dipisah.")
            return
        }
        val d = c.dur()
        if (off < 300L || d - off < 300L) {
            toast("Geser garis putih ke tengah klip dulu.")
            return
        }
        pushHistory()
        val srcOff = (off * c.speed).toLong()
        val a = c.copy()
        a.end = c.start + srcOff
        a.fadeOut = 0L
        a.clampFades()
        val b = c.copy()
        b.start = c.start + srcOff
        b.fadeIn = 0L
        b.clampFades()
        clips[i] = a
        clips.add(i + 1, b)
        sel = i
        rebuild(playhead)
    }

    private fun deleteSel() {
        if (selO in ovs.indices) {
            pushHistory()
            releaseOverlays()
            ovs.removeAt(selO)
            selO = -1
            rebuildOverlays()
            pushTimeline()
            return
        }
        if (selA in segs.indices) {
            pushHistory()
            segs.removeAt(selA)
            selA = -1
            curSeg = -1
            audioPlayer?.pause()
            if (segs.isEmpty()) clearSong()
            pushTimeline()
            return
        }
        if (sel !in clips.indices) {
            toast("Ketuk bagian di timeline yang mau dihapus.")
            return
        }
        if (clips.size == 1) {
            toast("Minimal harus ada satu bagian.")
            return
        }
        pushHistory()
        var before = 0L
        for (k in 0 until sel) before += clips[k].dur()
        clips.removeAt(sel)
        sel = -1
        rebuild(before)
    }

    private fun moveSel(dir: Int) {
        if (selO in ovs.indices) {
            pendingHistory = true
            ovEdit(selO, TimelineView.MODE_MOVE, ovs[selO].start + dir * 100L)
            return
        }
        if (selA in segs.indices) {
            pendingHistory = true
            audioEdit(selA, TimelineView.MODE_MOVE, segs[selA].start + dir * 100L)
            return
        }
        if (sel !in clips.indices) {
            toast("Ketuk bagian di timeline dulu.")
            return
        }
        val j = sel + dir
        if (j !in clips.indices) {
            toast(if (dir < 0) "Sudah paling kiri." else "Sudah paling kanan.")
            return
        }
        pushHistory()
        val c = clips.removeAt(sel)
        clips.add(j, c)
        sel = j
        var before = 0L
        for (k in 0 until j) before += clips[k].dur()
        rebuild(before)
    }

    private fun speedDialog() {
        if (selO in ovs.indices) {
            toast("Kecepatan lapisan belum tersedia.")
            return
        }
        if (selA in segs.indices) {
            toast("Kecepatan hanya untuk video.")
            return
        }
        if (sel !in clips.indices) {
            toast("Ketuk bagian di timeline dulu.")
            return
        }
        val c = clips[sel]
        if (c.photo) {
            photoDurationDialog(c)
            return
        }
        val steps = floatArrayOf(0.25f, 0.5f, 0.75f, 1f, 1.5f, 2f, 3f, 4f)
        Sheet.custom(this, "Kecepatan") { p, close ->
            val tv = TextView(this)
            tv.textSize = 28f
            tv.gravity = Gravity.CENTER
            tv.setTextColor(Color.WHITE)
            val sb = SeekBar(this)
            sb.max = steps.size - 1
            sb.progress = steps.indexOfFirst { it == c.speed }.let { if (it < 0) 3 else it }
            tv.text = TimelineView.fmtSpeed(steps[sb.progress])
            sb.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, v: Int, fromUser: Boolean) {
                    tv.text = TimelineView.fmtSpeed(steps[v])
                }

                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {}
            })
            p.addView(tv)
            p.addView(sb, LinearLayout.LayoutParams(-1, -2).apply { setMargins(dp(12), dp(8), dp(12), dp(8)) })
            p.addView(
                Sheet.buttonRow(
                    this,
                    Sheet.button(this, "Batal", false) { close() },
                    Sheet.button(this, "Terapkan", true) {
                        val v = steps[sb.progress]
                        close()
                        if (v != c.speed) {
                            pushHistory()
                            c.speed = v
                            c.clampFades()
                            rebuild(playhead)
                        }
                    }
                )
            )
        }
    }

    private fun photoDurationDialog(c: Clip) {
        Sheet.custom(this, "Durasi foto") { p, close ->
            val tv = TextView(this)
            tv.textSize = 28f
            tv.gravity = Gravity.CENTER
            tv.setTextColor(Color.WHITE)
            val sb = SeekBar(this)
            sb.max = 19
            sb.progress = ((c.photoMs / 500L).toInt() - 1).coerceIn(0, 19)
            fun sec(v: Int) = String.format(Locale.US, "%.1f detik", (v + 1) * 0.5)
            tv.text = sec(sb.progress)
            sb.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, v: Int, fromUser: Boolean) {
                    tv.text = sec(v)
                }

                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {}
            })
            p.addView(tv)
            p.addView(sb, LinearLayout.LayoutParams(-1, -2).apply { setMargins(dp(12), dp(8), dp(12), dp(8)) })
            p.addView(
                Sheet.buttonRow(
                    this,
                    Sheet.button(this, "Batal", false) { close() },
                    Sheet.button(this, "Terapkan", true) {
                        val ms = (sb.progress + 1) * 500L
                        close()
                        if (ms != c.photoMs) {
                            pushHistory()
                            c.photoMs = ms
                            rebuild(playhead)
                        }
                    }
                )
            )
        }
    }

    private fun pickSong() {
        lifecycleScope.launch {
            val list = withContext(Dispatchers.IO) { Library.audios(this@VideoEditActivity) }
            if (list.isEmpty()) {
                toast("Belum ada lagu di HP (atau izin musik belum diberikan).")
                return@launch
            }
            Sheet.pickList(
                this@VideoEditActivity, "Pilih lagu",
                list.map { it.title }, list.map { it.artist }, R.drawable.ic_music_note
            ) { i -> setSong(list[i]) }
        }
    }

    private fun setSong(t: Library.Track) {
        pushHistory()
        audioPlayer?.release()
        song = t.uri
        songName = t.title
        songDur = t.durationMs
        val tot = total()
        val start = if (tot - playhead < 1000L) 0L else playhead
        val len = minOf(t.durationMs, (tot - start).coerceAtLeast(300L))
        segs = arrayListOf(Seg(start, 0L, len))
        selA = 0
        sel = -1
        curSeg = -1
        val a = ExoPlayer.Builder(this).build()
        a.setMediaItem(MediaItem.fromUri(t.uri))
        a.volume = songVol
        a.prepare()
        audioPlayer = a
        pushTimeline()
    }

    private fun clearSong() {
        audioPlayer?.release()
        audioPlayer = null
        song = null
        songName = ""
        segs.clear()
        selA = -1
        curSeg = -1
    }

    private fun selectItem(kind: Int, idx: Int) {
        sel = if (kind == TimelineView.K_MAIN) idx else -1
        selO = if (kind == TimelineView.K_OV) idx else -1
        selA = if (kind == TimelineView.K_AUDIO) idx else -1
        timeline.selV = sel
        timeline.selO = selO
        timeline.selA = selA
        updateOvBar()
        placeAllOverlays()
    }

    private fun snapFade(ms: Long) = if (ms < 150L) 0L else ms

    /** Simpan riwayat Urungkan tepat sebelum perubahan pertama dalam satu tarikan. */
    private fun commitPending() {
        if (pendingHistory) {
            pendingHistory = false
            pushHistory()
        }
    }

    private fun clampTo(v: Long, lo: Long, hi: Long) = if (hi < lo) lo else v.coerceIn(lo, hi)

    /** Ubah satu potongan lagu dari tarikan di timeline. Potongan tidak boleh saling menimpa. */
    private fun audioEdit(i: Int, mode: Int, ms: Long) {
        val s = segs.getOrNull(i) ?: return
        commitPending()
        val tot = total()
        val prevEnd = if (i > 0) segs[i - 1].end() else 0L
        val nextStart = if (i < segs.lastIndex) segs[i + 1].start else tot
        when (mode) {
            TimelineView.MODE_L -> {
                val minStart = maxOf(prevEnd, s.start - s.from)
                val ns = clampTo(ms, minStart, s.end() - 300L)
                val d = ns - s.start
                s.start = ns
                s.from += d
                s.clampFades()
            }
            TimelineView.MODE_R -> {
                val maxEnd = minOf(nextStart, s.start + (songDur - s.from))
                val ne = clampTo(ms, s.start + 300L, maxEnd)
                s.to = s.from + (ne - s.start)
                s.clampFades()
            }
            TimelineView.MODE_MOVE -> {
                val len = s.len()
                s.start = clampTo(ms, prevEnd, nextStart - len)
            }
            TimelineView.MODE_FIN -> s.fadeIn = snapFade(ms).coerceIn(0L, s.len() - s.fadeOut)
            TimelineView.MODE_FOUT -> s.fadeOut = snapFade(ms).coerceIn(0L, s.len() - s.fadeIn)
        }
        pushTimeline()
    }

    // ------------------------------------------------------------------ edit dari timeline

    private fun fadableOf(kind: Int, i: Int): Fadable? = when (kind) {
        TimelineView.K_MAIN -> clips.getOrNull(i)
        TimelineView.K_OV -> ovs.getOrNull(i)
        TimelineView.K_AUDIO -> segs.getOrNull(i)
        else -> null
    }

    private fun editItem(kind: Int, i: Int, mode: Int, ms: Long) {
        when (kind) {
            TimelineView.K_AUDIO -> audioEdit(i, mode, ms)
            TimelineView.K_OV -> ovEdit(i, mode, ms)
            TimelineView.K_MAIN -> mainEdit(i, mode, ms)
        }
    }

    /** Titik lekuk di kurva pudar ditarik bebas; garis kurva menyesuaikan dan tetap halus. */
    private fun bendItem(kind: Int, i: Int, isIn: Boolean, x: Float, y: Float) {
        val f = fadableOf(kind, i) ?: return
        commitPending()
        if (isIn) {
            f.inX = x
            f.inY = y
        } else {
            f.outX = x
            f.outY = y
        }
        pushTimeline()
    }

    /** Video utama: pudar, dan potong awal/akhir dengan handle (klip sesudahnya ikut bergeser). */
    private fun mainEdit(i: Int, mode: Int, ms: Long) {
        val c = clips.getOrNull(i) ?: return
        commitPending()
        val minSrc = (300L * c.speed).toLong()
        when (mode) {
            TimelineView.MODE_FIN -> c.fadeIn = snapFade(ms).coerceIn(0L, c.dur() - c.fadeOut)
            TimelineView.MODE_FOUT -> c.fadeOut = snapFade(ms).coerceIn(0L, c.dur() - c.fadeIn)
            TimelineView.MODE_TRIM_L -> {
                if (c.photo) c.photoMs = (c.photoMs - ms).coerceIn(300L, 120000L)
                else c.start = clampTo(c.start + (ms * c.speed).toLong(), 0L, c.end - minSrc)
                c.clampFades()
                needRebuild = true
            }
            TimelineView.MODE_TRIM_R -> {
                if (c.photo) c.photoMs = (c.photoMs + ms).coerceIn(300L, 120000L)
                else c.end = clampTo(c.end + (ms * c.speed).toLong(), c.start + minSrc, c.srcDur)
                c.clampFades()
                needRebuild = true
            }
        }
        pushTimeline()
    }

    /** Lapisan video: potong, geser, pudar. Posisi absolut di timeline. */
    private fun ovEdit(i: Int, mode: Int, ms: Long) {
        val o = ovs.getOrNull(i) ?: return
        commitPending()
        val tot = total()
        when (mode) {
            TimelineView.MODE_L -> {
                val minStart = if (o.photo) 0L else maxOf(0L, o.start - (o.srcStart / o.speed).toLong())
                val ns = clampTo(ms, minStart, o.start + o.dur() - 300L)
                val d = ns - o.start
                if (o.photo) o.photoMs -= d else o.srcStart += (d * o.speed).toLong()
                o.start = ns
                o.clampFades()
                needOvRebuild = true
            }
            TimelineView.MODE_R -> {
                val srcRoom = if (o.photo) Long.MAX_VALUE / 4 else o.start + ((o.srcDur - o.srcStart) / o.speed).toLong()
                val ne = clampTo(ms, o.start + 300L, minOf(tot, srcRoom))
                if (o.photo) o.photoMs = ne - o.start else o.srcEnd = o.srcStart + ((ne - o.start) * o.speed).toLong()
                o.clampFades()
                needOvRebuild = true
            }
            TimelineView.MODE_MOVE -> o.start = clampTo(ms, 0L, maxOf(0L, tot - o.dur()))
            TimelineView.MODE_FIN -> o.fadeIn = snapFade(ms).coerceIn(0L, o.dur() - o.fadeOut)
            TimelineView.MODE_FOUT -> o.fadeOut = snapFade(ms).coerceIn(0L, o.dur() - o.fadeIn)
        }
        pushTimeline()
    }

    // ------------------------------------------------------------------ lapisan video

    private fun chip(label: String, onClick: () -> Unit): TextView = TextView(this).apply {
        text = label
        textSize = 12f
        setTextColor(Color.WHITE)
        gravity = Gravity.CENTER
        setPadding(dp(12), dp(7), dp(12), dp(7))
        setBackgroundResource(R.drawable.bg_field)
        setOnClickListener { onClick() }
    }

    private fun buildOvBar(): View {
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        fun add(t: String, a: () -> Unit): View {
            val c = chip(t, a)
            row.addView(c, LinearLayout.LayoutParams(-2, -2).apply { marginEnd = dp(8) })
            return c
        }
        add("Pas layar") { ovFit(false) }
        add("Penuh") { ovFit(true) }
        ovExtra = listOf(
            add("Tengah") { ovCenter() },
            add("Maju") { moveLayer(1) },
            add("Mundur") { moveLayer(-1) }
        )
        val hs = HorizontalScrollView(this)
        hs.isHorizontalScrollBarEnabled = false
        hs.addView(row)
        hs.visibility = View.GONE
        hs.layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            .apply { topMargin = dp(8) }
        return hs
    }

    private fun updateOvBar() {
        val isOv = selO in ovs.indices
        val mainNeeds = clips.getOrNull(sel)?.let { c ->
            c.w > 0 && c.h > 0 && Math.abs(c.w.toFloat() / c.h - frameAspect()) > 0.02f
        } == true
        ovBar.visibility = if (isOv || mainNeeds) View.VISIBLE else View.GONE
        for (v in ovExtra) v.visibility = if (isOv) View.VISIBLE else View.GONE
    }

    private fun addLayer() {
        if (clips.isEmpty()) {
            toast("Tunggu video selesai dimuat.")
            return
        }
        ovPicker.launch(arrayOf("video/*", "image/*"))
    }

    private val canvasOpts = listOf(
        Triple("asli", "Asli (otomatis)", "Mengikuti video atau foto pertama"),
        Triple("916", "9:16", "1080 × 1920"),
        Triple("169", "16:9", "1920 × 1080"),
        Triple("11", "1:1", "1080 × 1080"),
        Triple("45", "4:5", "1080 × 1350")
    )

    /** Ukuran hasil (piksel). Asli = klip pertama (video atau foto), selain itu ukuran tetap. */
    private fun canvasSize(): Pair<Int, Int> {
        when (canvasKey) {
            "916" -> return 1080 to 1920
            "169" -> return 1920 to 1080
            "11" -> return 1080 to 1080
            "45" -> return 1080 to 1350
        }
        val f = clips.firstOrNull { it.w > 0 && it.h > 0 }
        var w = f?.w ?: 1080
        var h = f?.h ?: 1920
        w -= w % 2
        h -= h % 2
        return w to h
    }

    private fun frameAspect(): Float {
        val (w, h) = canvasSize()
        return w.toFloat() / h
    }

    private fun canvasDialog() {
        Sheet.pickList(
            this, "Ukuran video",
            canvasOpts.map { it.second }, canvasOpts.map { it.third }, R.drawable.ic_trim
        ) { i -> applyCanvas(canvasOpts[i].first) }
    }

    private fun applyCanvas(key: String) {
        if (key == canvasKey) return
        canvasKey = key
        for (o in ovs) fitOv(o, false)
        layoutStage()
        placeAllOverlays()
        pushTimeline()
    }

    private fun ovFrom(c: Clip, start: Long, tot: Long): Ov {
        val room = (tot - start).coerceAtLeast(300L)
        val o = Ov(c.uri, c.photo, c.srcDur, 0L, c.srcDur, 1f, c.w, c.h, 3000L, start)
        if (o.photo) o.photoMs = minOf(3000L, room)
        else if (o.dur() > room) o.srcEnd = room
        return o
    }

    /** Pas layar: seluruh gambar terlihat. Penuh: layar terisi penuh (bagian lebih terpotong). */
    private fun fitOv(o: Ov, fillScreen: Boolean) {
        val a = o.aspect()
        val f = frameAspect()
        o.wf = if (fillScreen) (if (a >= f) a / f else 1f) else (if (a >= f) 1f else a / f)
        o.cx = 0.5f
        o.cy = 0.5f
    }

    private fun ovFit(fillScreen: Boolean) {
        val o = ovs.getOrNull(selO)
        if (o != null) {
            pushHistory()
            fitOv(o, fillScreen)
            placeOverlay(o)
            updateSelBox()
            return
        }
        val c = clips.getOrNull(sel) ?: return
        pushHistory()
        c.fill = fillScreen
        applySpeed()
        pushTimeline()
    }

    private fun ovCenter() {
        val o = ovs.getOrNull(selO) ?: return
        pushHistory()
        o.cx = 0.5f
        o.cy = 0.5f
        placeOverlay(o)
        updateSelBox()
    }

    /** Maju = ke depan (menutupi lapisan lain), mundur = ke belakang. */
    private fun moveLayer(dir: Int) {
        val i = selO
        val j = i + dir
        if (i !in ovs.indices || j !in ovs.indices) {
            toast(if (dir > 0) "Sudah paling depan." else "Sudah paling belakang.")
            return
        }
        pushHistory()
        val t = ovs[i]
        ovs[i] = ovs[j]
        ovs[j] = t
        selO = j
        rebuildOverlays()
        pushTimeline()
    }

    private fun setupStage(pv: FrameLayout) {
        stage = FrameLayout(this)
        stage.clipChildren = true
        canvasFrame.addView(stage, FrameLayout.LayoutParams(-1, -1))
        stage.addOnLayoutChangeListener { _, _, _, _, _, _, _, _, _ -> placeAllOverlays() }
        pv.addOnLayoutChangeListener { _, _, _, _, _, _, _, _, _ -> layoutStage() }
        val pinch = ScaleGestureDetector(this, object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
            override fun onScale(d: ScaleGestureDetector): Boolean {
                val o = ovs.getOrNull(selO) ?: return false
                stageHistory()
                o.wf = (o.wf * d.scaleFactor).coerceIn(0.1f, 4f)
                placeOverlay(o)
                updateSelBox()
                return true
            }
        })
        stage.setOnTouchListener { _, e ->
            pinch.onTouchEvent(e)
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    stDownX = e.x
                    stDownY = e.y
                    stLastX = e.x
                    stLastY = e.y
                    stMoved = false
                    stHist = false
                    stHit = hitOverlay(e.x, e.y)
                    if (stHit >= 0 && stHit != selO) selectItem(TimelineView.K_OV, stHit)
                }
                MotionEvent.ACTION_MOVE -> {
                    if (e.pointerCount > 1) {
                        stMoved = true
                    } else if (stHit >= 0 && !pinch.isInProgress) {
                        val far = Math.abs(e.x - stDownX) > dp(6) || Math.abs(e.y - stDownY) > dp(6)
                        val o = ovs.getOrNull(selO)
                        if ((stMoved || far) && o != null && stage.width > 0 && stage.height > 0) {
                            stMoved = true
                            stageHistory()
                            o.cx = (o.cx + (e.x - stLastX) / stage.width).coerceIn(0f, 1f)
                            o.cy = (o.cy + (e.y - stLastY) / stage.height).coerceIn(0f, 1f)
                            placeOverlay(o)
                            updateSelBox()
                        }
                    }
                    stLastX = e.x
                    stLastY = e.y
                }
                MotionEvent.ACTION_UP -> {
                    if (!stMoved && stHit < 0) togglePlay()
                }
            }
            true
        }
        val box = View(this)
        box.background = GradientDrawable().apply {
            setColor(Color.TRANSPARENT)
            setStroke(dp(2), Color.WHITE)
        }
        box.visibility = View.GONE
        selBox = box
    }

    private fun stageHistory() {
        if (!stHist) {
            stHist = true
            pushHistory()
        }
    }

    private fun ovActive(o: Ov): Boolean {
        val rel = playhead - o.start
        return rel >= 0L && rel < o.dur()
    }

    private fun hitOverlay(x: Float, y: Float): Int {
        val sw = stage.width.toFloat()
        val sh = stage.height.toFloat()
        for (i in ovs.indices.reversed()) {
            val o = ovs[i]
            if (!ovActive(o)) continue
            val bw = o.wf * sw
            val bh = bw / o.aspect()
            val l = o.cx * sw - bw / 2f
            val t = o.cy * sh - bh / 2f
            if (x >= l && x <= l + bw && y >= t && y <= t + bh) return i
        }
        return -1
    }

    private fun layoutStage() {
        val pw = pvBox.width
        val ph = pvBox.height
        if (pw <= 0 || ph <= 0) return
        val f = frameAspect()
        var w = pw.toFloat()
        var h = w / f
        if (h > ph) {
            h = ph.toFloat()
            w = h * f
        }
        val lp = canvasFrame.layoutParams as FrameLayout.LayoutParams
        if (lp.width != w.toInt() || lp.height != h.toInt()) {
            lp.width = w.toInt()
            lp.height = h.toInt()
            lp.gravity = Gravity.CENTER
            canvasFrame.layoutParams = lp
        }
    }

    private fun releaseOverlays() {
        for (o in ovs) {
            o.player?.release()
            o.player = null
            o.view = null
            o.running = false
        }
    }

    private fun rebuildOverlays() {
        releaseOverlays()
        stage.removeAllViews()
        for (o in ovs) {
            val v: View
            if (o.photo) {
                val iv = ImageView(this)
                iv.scaleType = ImageView.ScaleType.FIT_XY
                iv.setImageURI(o.uri)
                v = iv
            } else {
                val tv = TextureView(this)
                val p = ExoPlayer.Builder(this, Decoders.factory(this, Prefs.decoder(this))).build()
                p.setVideoTextureView(tv)
                p.volume = 0f
                p.setMediaItem(
                    MediaItem.Builder().setUri(o.uri)
                        .setClippingConfiguration(
                            MediaItem.ClippingConfiguration.Builder()
                                .setStartPositionMs(o.srcStart)
                                .setEndPositionMs(o.srcEnd)
                                .build()
                        ).build()
                )
                p.setPlaybackSpeed(o.speed)
                p.prepare()
                o.player = p
                v = tv
            }
            v.visibility = View.INVISIBLE
            o.view = v
            stage.addView(v, FrameLayout.LayoutParams(2, 2, Gravity.TOP or Gravity.START))
        }
        selBox?.let { stage.addView(it, FrameLayout.LayoutParams(2, 2, Gravity.TOP or Gravity.START)) }
        placeAllOverlays()
        syncOverlays(true)
    }

    private fun placeOverlay(o: Ov) {
        val v = o.view ?: return
        val sw = stage.width.toFloat()
        val sh = stage.height.toFloat()
        if (sw <= 0f || sh <= 0f) return
        val bw = (o.wf * sw).coerceAtLeast(8f)
        val bh = (bw / o.aspect()).coerceAtLeast(8f)
        val lp = v.layoutParams as? FrameLayout.LayoutParams
        if (lp == null || lp.width != bw.toInt() || lp.height != bh.toInt()) {
            v.layoutParams = FrameLayout.LayoutParams(bw.toInt(), bh.toInt(), Gravity.TOP or Gravity.START)
        }
        v.x = o.cx * sw - bw / 2f
        v.y = o.cy * sh - bh / 2f
    }

    private fun placeAllOverlays() {
        for (o in ovs) placeOverlay(o)
        updateSelBox()
    }

    private fun updateSelBox() {
        val b = selBox ?: return
        val o = ovs.getOrNull(selO)
        val sw = stage.width.toFloat()
        val sh = stage.height.toFloat()
        if (o == null || o.view == null || sw <= 0f || sh <= 0f) {
            b.visibility = View.GONE
            return
        }
        val bw = (o.wf * sw).coerceAtLeast(8f)
        val bh = (bw / o.aspect()).coerceAtLeast(8f)
        val lp = b.layoutParams as? FrameLayout.LayoutParams
        if (lp == null || lp.width != bw.toInt() || lp.height != bh.toInt()) {
            b.layoutParams = FrameLayout.LayoutParams(bw.toInt(), bh.toInt(), Gravity.TOP or Gravity.START)
        }
        b.x = o.cx * sw - bw / 2f
        b.y = o.cy * sh - bh / 2f
        b.visibility = if (ovActive(o)) View.VISIBLE else View.GONE
    }

    /** Samakan lapisan dengan posisi putar: tampil hanya di rentangnya, ikut pudar, dan diputar bersama video utama. */
    private fun syncOverlays(forceSeek: Boolean) {
        if (!::player.isInitialized || !::stage.isInitialized) return
        val playing = player.isPlaying
        for (o in ovs) {
            val v = o.view ?: continue
            val rel = playhead - o.start
            val on = rel >= 0L && rel < o.dur()
            v.visibility = if (on) View.VISIBLE else View.INVISIBLE
            val p = o.player
            if (!on) {
                if (p != null && o.running) {
                    p.pause()
                    o.running = false
                }
                continue
            }
            v.alpha = TimelineView.fadeGain(rel, o.dur(), o.fade())
            if (p == null) continue
            val pos = (rel * o.speed).toLong()
            if (playing) {
                if (!o.running || forceSeek) {
                    p.seekTo(pos)
                    p.play()
                    o.running = true
                }
            } else if (o.running || forceSeek) {
                p.pause()
                p.seekTo(pos)
                o.running = false
            }
        }
        selBox?.visibility = if (ovs.getOrNull(selO)?.let { ovActive(it) } == true) View.VISIBLE else View.GONE
    }

    private fun volumeDialog() {
        Sheet.custom(this, "Suara") { p, close ->
            fun slider(name: String, start: Float, enabled: Boolean): SeekBar {
                val t = TextView(this)
                t.text = name
                t.textSize = 12f
                t.setTextColor(clr(R.color.muted))
                t.setPadding(dp(14), dp(6), dp(14), 0)
                p.addView(t)
                val sb = SeekBar(this)
                sb.max = 100
                sb.progress = (start * 100).toInt()
                sb.isEnabled = enabled
                p.addView(sb, LinearLayout.LayoutParams(-1, -2).apply { setMargins(dp(12), dp(4), dp(12), dp(8)) })
                return sb
            }
            val a = slider("Suara video asli", origVol, true)
            val b = slider(if (song == null) "Lagu (belum ada lagu)" else "Lagu", songVol, song != null)
            p.addView(
                Sheet.buttonRow(
                    this,
                    Sheet.button(this, "Batal", false) { close() },
                    Sheet.button(this, "Terapkan", true) {
                        origVol = a.progress / 100f
                        songVol = b.progress / 100f
                        player.volume = origVol
                        audioPlayer?.volume = songVol
                        close()
                    }
                )
            )
        }
    }

    // ------------------------------------------------------------------ simpan

    private fun askLeave() {
        if (exporting) return
        if (history.isEmpty() && song == null && ovs.isEmpty()) {
            finish()
            return
        }
        Sheet.confirm(this, "Keluar dari editor?", "Perubahan yang belum disimpan akan hilang.", "Keluar", true) {
            finish()
        }
    }

    private fun askSave() {
        if (clips.isEmpty() || exporting) return
        player.pause()
        Sheet.choice(
            this, "Simpan hasil edit", "Resolusi dan bitrate mengikuti video asli.",
            listOf(
                "Simpan sebagai video baru" to "Video asli tetap ada",
                "Timpa video asli" to "Video asli diganti"
            ),
            0
        ) { i ->
            if (i == 0) {
                export(false)
            } else {
                Sheet.confirm(
                    this, "Timpa video asli?",
                    "Video asli akan diganti hasil edit dan tidak bisa dikembalikan.", "Timpa", true
                ) { export(true) }
            }
        }
    }

    private fun volumeProcessor(v: Float): AudioProcessor {
        val p = ChannelMixingAudioProcessor()
        p.putChannelMixingMatrix(ChannelMixingMatrix.create(1, 1).scaleBy(v))
        p.putChannelMixingMatrix(ChannelMixingMatrix.create(2, 2).scaleBy(v))
        return p
    }

    private fun blankImage(): Uri {
        val f = File(cacheDir, "blank.png")
        if (!f.exists()) {
            val bmp = Bitmap.createBitmap(16, 16, Bitmap.Config.ARGB_8888)
            bmp.eraseColor(Color.BLACK)
            f.outputStream().use { bmp.compress(Bitmap.CompressFormat.PNG, 100, it) }
            bmp.recycle()
        }
        return Uri.fromFile(f)
    }

    private fun buildComposition(total: Long): Composition {
        var ovSettings: OvSettings? = null
        val vItems = ArrayList<EditedMediaItem>()
        val useOv = ovs.any { minOf(it.dur(), total - it.start) >= 200L }
        val (outW, outH) = canvasSize()
        val needSize = useOv || canvasKey != "asli" || clips.any { it.fill } || clips.firstOrNull()?.photo == true
        for (c in clips) {
            if (c.photo) {
                val pve = ArrayList<Effect>()
                if (c.fadeIn > 0L || c.fadeOut > 0L) pve.add(FadeMatrix(c.dur(), c.fade()))
                if (needSize) pve.add(Presentation.createForWidthAndHeight(outW, outH, if (c.fill) Presentation.LAYOUT_SCALE_TO_FIT_WITH_CROP else Presentation.LAYOUT_SCALE_TO_FIT))
                vItems.add(
                    EditedMediaItem.Builder(MediaItem.fromUri(c.uri))
                        .setDurationUs(c.photoMs * 1000L)
                        .setFrameRate(30)
                        .setEffects(Effects(emptyList(), pve))
                        .build()
                )
            } else {
                val cc = MediaItem.ClippingConfiguration.Builder()
                    .setStartPositionMs(c.start)
                    .setEndPositionMs(c.end)
                    .build()
                val mi = MediaItem.Builder().setUri(c.uri).setClippingConfiguration(cc).build()
                val ap = ArrayList<AudioProcessor>()
                val ve = ArrayList<Effect>()
                if (c.speed != 1f) {
                    ve.add(SpeedChangeEffect(c.speed))
                    val sonic = SonicAudioProcessor()
                    sonic.setSpeed(c.speed)
                    sonic.setPitch(1f)
                    ap.add(sonic)
                }
                if (origVol != 1f) ap.add(volumeProcessor(origVol))
                if (c.fadeIn > 0L || c.fadeOut > 0L) ve.add(FadeMatrix(c.dur(), c.fade()))
                if (needSize) ve.add(Presentation.createForWidthAndHeight(outW, outH, if (c.fill) Presentation.LAYOUT_SCALE_TO_FIT_WITH_CROP else Presentation.LAYOUT_SCALE_TO_FIT))
                vItems.add(EditedMediaItem.Builder(mi).setEffects(Effects(ap, ve)).build())
            }
        }
        val seqs = ArrayList<EditedMediaItemSequence>()
        val mainSeq = EditedMediaItemSequence.Builder(vItems).build()
        if (!useOv) {
            seqs.add(mainSeq)
        } else {
            // media3 menggambar input pertama (utama) paling atas dan menunggu semua input punya frame.
            // Jadi: input 0 = latar kosong tak terlihat (penentu waktu), lalu lapisan dari depan ke belakang,
            // dan video utama di paling belakang. Jeda diisi gambar pengisi karena gap video belum menghasilkan frame.
            val specs = ArrayList<OvSpec?>()
            val blank = blankImage()
            fun filler(ms: Long): EditedMediaItem =
                EditedMediaItem.Builder(MediaItem.Builder().setUri(blank).setMimeType("image/png").build())
                    .setDurationUs(ms * 1000L)
                    .setFrameRate(30)
                    .build()

            seqs.add(EditedMediaItemSequence.Builder().addItem(filler(total)).build())
            specs.add(OvSpec(0L, total, TimelineView.Fade(0L, 0L, 0.5f, 0.5f, 0.5f, 0.5f), 0f, 0f, true))

            for (o in ovs.reversed()) {
                val len = minOf(o.dur(), total - o.start)
                if (len < 200L) continue
                val tw = maxOf(2, Math.round(o.wf * outW) / 2 * 2)
                val th = maxOf(2, Math.round(tw / o.aspect()) / 2 * 2)
                val size = Presentation.createForWidthAndHeight(tw, th, Presentation.LAYOUT_SCALE_TO_FIT)
                val sb = EditedMediaItemSequence.Builder()
                if (o.start >= 50L) sb.addItem(filler(o.start))
                if (o.photo) {
                    sb.addItem(
                        EditedMediaItem.Builder(MediaItem.fromUri(o.uri))
                            .setDurationUs(len * 1000L)
                            .setFrameRate(30)
                            .setEffects(Effects(emptyList(), listOf<Effect>(size)))
                            .build()
                    )
                } else {
                    val cc = MediaItem.ClippingConfiguration.Builder()
                        .setStartPositionMs(o.srcStart)
                        .setEndPositionMs(o.srcStart + (len * o.speed).toLong())
                        .build()
                    val mi = MediaItem.Builder().setUri(o.uri).setClippingConfiguration(cc).build()
                    val ove = ArrayList<Effect>()
                    if (o.speed != 1f) ove.add(SpeedChangeEffect(o.speed))
                    ove.add(size)
                    sb.addItem(
                        EditedMediaItem.Builder(mi)
                            .setRemoveAudio(true)
                            .setEffects(Effects(emptyList(), ove))
                            .build()
                    )
                }
                val tail = total - o.start - len
                if (tail >= 50L) sb.addItem(filler(tail))
                seqs.add(sb.build())
                specs.add(OvSpec(o.start, len, o.fade(), o.cx * 2f - 1f, 1f - o.cy * 2f, false))
            }
            seqs.add(mainSeq)
            specs.add(null)
            ovSettings = OvSettings(specs, outW, outH)
        }

        val sUri = song
        if (sUri != null) {
            val sb = EditedMediaItemSequence.Builder()
            var cursor = 0L
            var added = 0
            for (sg in segs.sortedBy { it.start }) {
                val len = minOf(sg.len(), total - sg.start)
                if (len < 100L || sg.start < cursor) continue
                val fi = minOf(sg.fadeIn, len)
                val fo = minOf(sg.fadeOut, len - fi)
                val cc = MediaItem.ClippingConfiguration.Builder()
                    .setStartPositionMs(sg.from)
                    .setEndPositionMs(sg.from + len)
                    .build()
                val mi = MediaItem.Builder().setUri(sUri).setClippingConfiguration(cc).build()
                val procs = ArrayList<AudioProcessor>()
                procs.add(volumeProcessor(songVol))
                if (fi > 0L || fo > 0L) procs.add(FadeVolume(len, TimelineView.Fade(fi, fo, sg.inX, sg.inY, sg.outX, sg.outY)))
                val ei = EditedMediaItem.Builder(mi)
                    .setRemoveVideo(true)
                    .setEffects(Effects(procs, emptyList()))
                    .build()
                if (sg.start > cursor) sb.addGap((sg.start - cursor) * 1000L)
                sb.addItem(ei)
                cursor = sg.start + len
                added++
            }
            if (added > 0) seqs.add(sb.build())
        }
        val cb = Composition.Builder(seqs)
        ovSettings?.let { cb.setVideoCompositorSettings(it) }
        if (useOv) cb.experimentalSetForceAudioTrack(true)
        val hasPhoto = clips.any { it.photo }
        if (hasPhoto) cb.experimentalSetForceAudioTrack(true)
        val vids = clips.filter { !it.photo && it.w > 0 && it.h > 0 }
        val sizes = vids.map { it.w to it.h }.distinct()
        if (!needSize && (hasPhoto || sizes.size > 1)) {
            var w = if (vids.isNotEmpty()) vids[0].w else 1080
            var h = if (vids.isNotEmpty()) vids[0].h else 1920
            w -= w % 2
            h -= h % 2
            cb.setEffects(
                Effects(
                    emptyList(),
                    listOf<Effect>(Presentation.createForWidthAndHeight(w, h, Presentation.LAYOUT_SCALE_TO_FIT))
                )
            )
        }
        return cb.build()
    }

    private fun export(overwrite: Boolean) {
        val total = total()
        val comp = try {
            buildComposition(total)
        } catch (e: Exception) {
            toast("Gagal menyiapkan video: ${e.message}")
            return
        }
        val out = File(cacheDir, "edit_" + System.currentTimeMillis() + ".mp4")
        outFile = out
        exporting = true

        val br = clips.filter { !it.photo }.maxOfOrNull { it.bitrate } ?: 0
        val encBuilder = DefaultEncoderFactory.Builder(this)
        if (br > 0) {
            encBuilder.setRequestedVideoEncoderSettings(
                VideoEncoderSettings.Builder().setBitrate(br.coerceIn(2_000_000, 80_000_000)).build()
            )
        }

        val t = Transformer.Builder(this)
            .setEncoderFactory(encBuilder.build())
            .addListener(object : Transformer.Listener {
                override fun onCompleted(composition: Composition, exportResult: ExportResult) {
                    onExportDone(out, overwrite)
                }

                override fun onError(
                    composition: Composition, exportResult: ExportResult, exportException: ExportException
                ) {
                    onExportFailed(out, exportException.message ?: "kesalahan tidak diketahui")
                }
            })
            .build()
        transformer = t

        progressDlg = Sheet.custom(this, "Menyimpan video\u2026") { p, close ->
            val pb = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal)
            pb.max = 100
            pb.progressTintList = ColorStateList.valueOf(Color.WHITE)
            progressBar = pb
            val pct = TextView(this)
            pct.text = "0%"
            pct.textSize = 13f
            pct.gravity = Gravity.CENTER
            pct.setTextColor(clr(R.color.text_soft))
            tvPct = pct
            p.addView(pb, LinearLayout.LayoutParams(-1, -2).apply { setMargins(dp(14), dp(8), dp(14), dp(4)) })
            p.addView(pct)
            p.addView(
                Sheet.buttonRow(
                    this,
                    Sheet.button(this, "Batal", false) {
                        t.cancel()
                        close()
                        stopProgress()
                        out.delete()
                        exporting = false
                    }
                )
            )
        }
        progressDlg?.setCancelable(false)

        try {
            t.start(comp, out.absolutePath)
            handler.post(progressTick)
        } catch (e: Exception) {
            onExportFailed(out, e.message ?: "gagal memulai")
        }
    }

    private val progressTick = object : Runnable {
        override fun run() {
            val t = transformer ?: return
            val h = ProgressHolder()
            if (t.getProgress(h) == Transformer.PROGRESS_STATE_AVAILABLE) {
                progressBar?.progress = h.progress
                tvPct?.text = "${h.progress}%"
            }
            handler.postDelayed(this, 300)
        }
    }

    private fun stopProgress() {
        handler.removeCallbacks(progressTick)
        transformer = null
        progressDlg?.dismiss()
        progressDlg = null
    }

    private fun onExportFailed(out: File, msg: String) {
        stopProgress()
        out.delete()
        exporting = false
        toast("Gagal menyimpan: $msg")
    }

    private fun onExportDone(out: File, overwrite: Boolean) {
        stopProgress()
        if (overwrite) {
            overwriteOriginal(out)
        } else {
            lifecycleScope.launch {
                val ok = withContext(Dispatchers.IO) { saveAsNew(out) }
                out.delete()
                exporting = false
                if (ok) {
                    toast("Video baru disimpan.")
                    finish()
                } else {
                    toast("Gagal menyimpan ke galeri.")
                }
            }
        }
    }

    private fun saveAsNew(out: File): Boolean {
        val base = origName.substringBeforeLast('.')
        val name = base + "_edit.mp4"
        val allowed = listOf("DCIM/", "Movies/", "Pictures/")
        val rel = if (origRel.isNotEmpty() && allowed.any { origRel.startsWith(it) }) origRel else "Movies/BunnyTL/"
        fun insert(path: String?): Uri? {
            val v = ContentValues()
            v.put(MediaStore.Video.Media.DISPLAY_NAME, name)
            v.put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
            if (Build.VERSION.SDK_INT >= 29 && path != null) {
                v.put(MediaStore.Video.Media.RELATIVE_PATH, path)
                v.put(MediaStore.Video.Media.IS_PENDING, 1)
            }
            return contentResolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, v)
        }
        return try {
            val uri = try {
                insert(rel)
            } catch (e: Exception) {
                insert("Movies/BunnyTL/")
            } ?: return false
            contentResolver.openOutputStream(uri, "w")?.use { o -> out.inputStream().use { it.copyTo(o) } }
            if (Build.VERSION.SDK_INT >= 29) {
                val v = ContentValues()
                v.put(MediaStore.Video.Media.IS_PENDING, 0)
                contentResolver.update(uri, v, null, null)
            }
            true
        } catch (e: Exception) {
            false
        }
    }

    private fun overwriteOriginal(out: File) {
        fun copy() {
            lifecycleScope.launch {
                val ok = withContext(Dispatchers.IO) {
                    try {
                        contentResolver.openOutputStream(origUri, "wt")?.use { o ->
                            out.inputStream().use { it.copyTo(o) }
                        }
                        true
                    } catch (e: Exception) {
                        false
                    }
                }
                out.delete()
                exporting = false
                if (ok) {
                    toast("Video asli diganti.")
                    finish()
                } else {
                    toast("Gagal menimpa video asli.")
                }
            }
        }
        if (Build.VERSION.SDK_INT >= 30) {
            try {
                val pi = MediaStore.createWriteRequest(contentResolver, listOf(origUri))
                pendingWrite = { copy() }
                writeLauncher.launch(IntentSenderRequest.Builder(pi.intentSender).build())
            } catch (e: Exception) {
                exporting = false
                toast("Gagal: ${e.message}")
            }
        } else {
            copy()
        }
    }

    // ------------------------------------------------------------------ siklus hidup

    override fun onPause() {
        super.onPause()
        if (::player.isInitialized) player.pause()
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        transformer?.cancel()
        if (::player.isInitialized) player.release()
        audioPlayer?.release()
        releaseOverlays()
        super.onDestroy()
    }

    // ------------------------------------------------------------------ efek pudar

    /** Pudar gambar: warna dikalikan pengali kurva (menggelap ke hitam). Waktu = waktu hasil akhir klip. */
    private class FadeMatrix(
        private val durMs: Long,
        private val fade: TimelineView.Fade
    ) : RgbMatrix {
        override fun getMatrix(presentationTimeUs: Long, useHdr: Boolean): FloatArray {
            val g = TimelineView.fadeGain(presentationTimeUs / 1000L, durMs, fade)
            return floatArrayOf(
                g, 0f, 0f, 0f,
                0f, g, 0f, 0f,
                0f, 0f, g, 0f,
                0f, 0f, 0f, 1f
            )
        }
    }

    /** Pudar suara lagu: volume mengikuti kurva yang sama dengan di timeline (audio PCM 16-bit). */
    private class FadeVolume(
        private val lenMs: Long,
        private val fade: TimelineView.Fade
    ) : BaseAudioProcessor() {
        private var frames = 0L

        override fun onConfigure(inputAudioFormat: AudioProcessor.AudioFormat): AudioProcessor.AudioFormat {
            if (inputAudioFormat.encoding != C.ENCODING_PCM_16BIT) {
                throw AudioProcessor.UnhandledAudioFormatException(inputAudioFormat)
            }
            return inputAudioFormat
        }

        override fun queueInput(inputBuffer: ByteBuffer) {
            val ch = inputAudioFormat.channelCount
            val rate = inputAudioFormat.sampleRate
            val n = inputBuffer.remaining() / (2 * ch)
            val out = replaceOutputBuffer(n * 2 * ch)
            for (f in 0 until n) {
                val ms = frames * 1000L / rate
                val g = TimelineView.fadeGain(ms, lenMs, fade)
                for (k in 0 until ch) {
                    val v = (inputBuffer.short * g).toInt().coerceIn(-32768, 32767)
                    out.putShort(v.toShort())
                }
                frames++
            }
            out.flip()
        }
    }

    /** Satu input di compositor: waktu tampil, pudar, dan titik tengah (-1..1). hidden = latar penentu waktu (tak terlihat). */
    private class OvSpec(
        val start: Long,
        val len: Long,
        val fade: TimelineView.Fade,
        val ax: Float,
        val ay: Float,
        val hidden: Boolean
    )

    /**
     * Pengaturan penumpukan. specs[inputId]: null = video utama (frame penuh), hidden = latar kosong,
     * selain itu lapisan: transparansi mengikuti rentang waktu dan kurva pudar. Ukuran lapisan sudah
     * dipatok lewat Presentation, jadi skala 1 = ukuran yang diinginkan.
     */
    private class OvSettings(
        private val specs: List<OvSpec?>,
        private val outW: Int,
        private val outH: Int
    ) : VideoCompositorSettings {
        override fun getOutputSize(inputSizes: List<Size>): Size = Size(outW, outH)

        override fun getOverlaySettings(inputId: Int, presentationTimeUs: Long): OverlaySettings {
            val s = specs.getOrNull(inputId) ?: return StaticOverlaySettings.Builder().build()
            if (s.hidden) return StaticOverlaySettings.Builder().setAlphaScale(0f).build()
            val t = presentationTimeUs / 1000L - s.start
            val g = if (t < 0L || t >= s.len) 0f else TimelineView.fadeGain(t, s.len, s.fade)
            return StaticOverlaySettings.Builder()
                .setAlphaScale(g)
                .setBackgroundFrameAnchor(s.ax, s.ay)
                .build()
        }
    }
}
