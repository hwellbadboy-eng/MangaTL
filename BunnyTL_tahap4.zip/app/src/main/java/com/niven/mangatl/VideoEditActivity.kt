package com.niven.mangatl

import android.content.ContentValues
import android.content.res.ColorStateList
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.IntentSenderRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import androidx.media3.common.Effect
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.common.audio.AudioProcessor
import androidx.media3.common.audio.ChannelMixingAudioProcessor
import androidx.media3.common.audio.ChannelMixingMatrix
import androidx.media3.common.audio.SonicAudioProcessor
import androidx.media3.effect.Presentation
import androidx.media3.effect.SpeedChangeEffect
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.transformer.Composition
import androidx.media3.transformer.DefaultEncoderFactory
import androidx.media3.transformer.EditedMediaItem
import androidx.media3.transformer.EditedMediaItemSequence
import androidx.media3.transformer.Effects
import androidx.media3.transformer.ExportException
import androidx.media3.transformer.ExportResult
import androidx.media3.transformer.ProgressHolder
import androidx.media3.transformer.Transformer
import androidx.media3.transformer.VideoEncoderSettings
import androidx.media3.ui.PlayerView
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.util.Locale

/**
 * Editor video dasar: pisah klip, hapus bagian, percepat/perlambat, sambung video/foto,
 * tambah lagu. Hasil disimpan dengan resolusi dan bitrate mengikuti video asli.
 */
class VideoEditActivity : AppCompatActivity() {

    class Clip(
        val uri: Uri,
        val photo: Boolean,
        val srcDur: Long,
        var start: Long,
        var end: Long,
        var speed: Float,
        val w: Int,
        val h: Int,
        val bitrate: Int,
        var photoMs: Long = 3000L
    ) {
        fun dur(): Long =
            if (photo) photoMs else (((end - start) / speed).toLong()).coerceAtLeast(1L)

        fun copy() = Clip(uri, photo, srcDur, start, end, speed, w, h, bitrate, photoMs)
    }

    private var clips = ArrayList<Clip>()
    private val history = ArrayList<List<Clip>>()
    private var sel = -1
    private var playhead = 0L

    private var song: Uri? = null
    private var songName = ""
    private var songDur = 0L
    private var songVol = 1f
    private var origVol = 1f

    private lateinit var origUri: Uri
    private var origName = "video.mp4"
    private var origRel = ""

    private lateinit var player: ExoPlayer
    private var audioPlayer: ExoPlayer? = null
    private lateinit var playerView: PlayerView
    private lateinit var timeline: TimelineView
    private lateinit var tvTime: TextView
    private lateinit var tvSong: TextView
    private lateinit var btnPlay: ImageButton

    private val handler = Handler(Looper.getMainLooper())
    private var transformer: Transformer? = null
    private var progressBar: ProgressBar? = null
    private var tvPct: TextView? = null
    private var progressDlg: AlertDialog? = null
    private var outFile: File? = null
    private var exporting = false
    private var pendingWrite: (() -> Unit)? = null

    private val addPicker = registerForActivityResult(
        ActivityResultContracts.OpenMultipleDocuments()
    ) { uris ->
        if (uris.isEmpty()) return@registerForActivityResult
        lifecycleScope.launch {
            val loaded = withContext(Dispatchers.IO) { uris.mapNotNull { loadClip(it) } }
            if (loaded.isEmpty()) {
                toast("File tidak bisa dibuka.")
                return@launch
            }
            pushHistory()
            clips.addAll(loaded)
            rebuild(playhead)
        }
    }

    private val writeLauncher = registerForActivityResult(
        ActivityResultContracts.StartIntentSenderForResult()
    ) { r ->
        val cb = pendingWrite
        pendingWrite = null
        if (r.resultCode == RESULT_OK) cb?.invoke() else {
            toast("Izin tulis ditolak. Video asli tidak diubah.")
            outFile?.delete()
        }
    }

    // ------------------------------------------------------------------ UI

    private fun dp(v: Int) = Ui.dp(this, v)
    private fun clr(id: Int) = ContextCompat.getColor(this, id)
    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()

    private fun label(text: String) = TextView(this).apply {
        this.text = text
        textSize = 11f
        setTextColor(clr(R.color.muted))
        setPadding(0, 0, 0, dp(4))
    }

    private fun tool(icon: Int, name: String, onClick: () -> Unit): View {
        val l = LinearLayout(this)
        l.orientation = LinearLayout.VERTICAL
        l.gravity = Gravity.CENTER
        l.setPadding(0, dp(8), 0, dp(8))
        l.layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        val iv = ImageView(this)
        iv.setImageResource(icon)
        iv.setColorFilter(Color.WHITE)
        iv.layoutParams = LinearLayout.LayoutParams(dp(22), dp(22))
        l.addView(iv)
        l.addView(TextView(this).apply {
            text = name
            textSize = 11f
            gravity = Gravity.CENTER
            setTextColor(clr(R.color.text_soft))
            maxLines = 1
            setPadding(0, dp(2), 0, 0)
        })
        l.setOnClickListener { onClick() }
        return l
    }

    private fun iconButton(res: Int, desc: String, onClick: () -> Unit): ImageButton {
        val b = ImageButton(this)
        b.setImageResource(res)
        b.setColorFilter(Color.WHITE)
        b.contentDescription = desc
        b.setBackgroundColor(Color.TRANSPARENT)
        b.setPadding(dp(10), dp(10), dp(10), dp(10))
        b.setOnClickListener { onClick() }
        return b
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val uriStr = intent.getStringExtra("uri")
        if (uriStr == null) {
            finish()
            return
        }
        origUri = Uri.parse(uriStr)
        origName = intent.getStringExtra("name") ?: "video.mp4"
        origRel = intent.getStringExtra("rel") ?: ""

        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setBackgroundColor(clr(R.color.bg))
        root.setPadding(dp(12), dp(8), dp(12), dp(8))

        // bilah atas
        val top = LinearLayout(this)
        top.orientation = LinearLayout.HORIZONTAL
        top.gravity = Gravity.CENTER_VERTICAL
        top.addView(iconButton(R.drawable.ic_back, "Kembali") { askLeave() })
        top.addView(TextView(this).apply {
            text = "Edit video"
            textSize = 16f
            typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
            setTextColor(Color.WHITE)
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
                .apply { marginStart = dp(6) }
        })
        top.addView(iconButton(R.drawable.ic_undo, "Urungkan") { undo() })
        top.addView(TextView(this).apply {
            text = "Simpan"
            textSize = 13f
            typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
            setTextColor(Color.parseColor("#09090A"))
            setPadding(dp(16), dp(8), dp(16), dp(8))
            background = GradientDrawable().apply {
                setColor(Color.parseColor("#F2F2F2"))
                cornerRadius = dp(14).toFloat()
            }
            setOnClickListener { askSave() }
        })
        root.addView(top)

        // pratinjau
        val pv = FrameLayout(this)
        pv.setBackgroundColor(Color.BLACK)
        pv.layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f)
            .apply { topMargin = dp(8) }
        playerView = PlayerView(this)
        playerView.useController = false
        playerView.setShutterBackgroundColor(Color.BLACK)
        pv.addView(playerView, FrameLayout.LayoutParams(-1, -1))
        btnPlay = iconButton(R.drawable.ic_play, "Putar") { togglePlay() }
        pv.addView(btnPlay, FrameLayout.LayoutParams(dp(64), dp(64), Gravity.CENTER))
        tvTime = TextView(this).apply {
            textSize = 12f
            setTextColor(clr(R.color.text_soft))
            setPadding(dp(10), 0, 0, dp(8))
        }
        pv.addView(tvTime, FrameLayout.LayoutParams(-2, -2, Gravity.BOTTOM or Gravity.START))
        root.addView(pv)

        // timeline
        val card = LinearLayout(this)
        card.orientation = LinearLayout.VERTICAL
        card.setBackgroundResource(R.drawable.bg_card)
        card.setPadding(dp(12), dp(10), dp(12), dp(12))
        card.layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            .apply { topMargin = dp(10) }
        card.addView(label("Video dan foto  \u2022  ketuk kotak untuk memilih, geser untuk mencari posisi"))
        timeline = TimelineView(this)
        timeline.layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(56))
        timeline.onScrub = { scrub(it) }
        card.addView(timeline)
        card.addView(label("Lagu").apply { setPadding(0, dp(10), 0, dp(4)) })
        tvSong = TextView(this).apply {
            text = "Belum ada lagu"
            textSize = 13f
            setTextColor(clr(R.color.muted))
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(12), 0, dp(12), 0)
            maxLines = 1
            setBackgroundResource(R.drawable.bg_field)
            setOnClickListener { songTap() }
        }
        tvSong.layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(40))
        card.addView(tvSong)
        root.addView(card)

        // alat
        val tools = LinearLayout(this)
        tools.orientation = LinearLayout.HORIZONTAL
        tools.layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            .apply { topMargin = dp(6) }
        tools.addView(tool(R.drawable.ic_cut, "Pisah") { split() })
        tools.addView(tool(R.drawable.ic_trash, "Hapus") { deleteSel() })
        tools.addView(tool(R.drawable.ic_speed, "Kecepatan") { speedDialog() })
        tools.addView(tool(R.drawable.ic_movie, "Video/foto") { addPicker.launch(arrayOf("video/*", "image/*")) })
        tools.addView(tool(R.drawable.ic_music_note, "Lagu") { pickSong() })
        tools.addView(tool(R.drawable.ic_volume, "Suara") { volumeDialog() })
        root.addView(tools)

        setContentView(root)

        player = ExoPlayer.Builder(this, Decoders.factory(this, Prefs.decoder(this))).build()
        playerView.player = player
        player.addListener(object : Player.Listener {
            override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) = applySpeed()
            override fun onIsPlayingChanged(isPlaying: Boolean) {
                btnPlay.setImageResource(if (isPlaying) R.drawable.ic_pause else R.drawable.ic_play)
                if (isPlaying) {
                    handler.post(tick)
                } else {
                    playhead = globalNow()
                }
                syncAudio(isPlaying)
            }

            override fun onPlaybackStateChanged(playbackState: Int) {
                if (playbackState == Player.STATE_ENDED) {
                    player.pause()
                    playhead = 0L
                    rebuild(0L)
                }
            }
        })
        playerView.setOnClickListener { togglePlay() }

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() = askLeave()
        })

        lifecycleScope.launch {
            val c = withContext(Dispatchers.IO) { loadClip(origUri) }
            if (c == null) {
                toast("Video tidak bisa dibuka.")
                finish()
                return@launch
            }
            clips.add(c)
            rebuild(0L)
        }
    }

    // ------------------------------------------------------------------ data klip

    private fun loadClip(uri: Uri): Clip? {
        val type = contentResolver.getType(uri) ?: ""
        if (type.startsWith("image/")) {
            return try {
                val o = BitmapFactory.Options()
                o.inJustDecodeBounds = true
                contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, o) }
                Clip(uri, true, 0L, 0L, 0L, 1f, o.outWidth, o.outHeight, 0)
            } catch (e: Exception) {
                null
            }
        }
        val r = MediaMetadataRetriever()
        return try {
            r.setDataSource(this, uri)
            val dur = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L
            var w = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH)?.toIntOrNull() ?: 0
            var h = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT)?.toIntOrNull() ?: 0
            val rot = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_ROTATION)?.toIntOrNull() ?: 0
            if (rot == 90 || rot == 270) {
                val t = w
                w = h
                h = t
            }
            val br = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_BITRATE)?.toIntOrNull() ?: 0
            if (dur <= 0L) null else Clip(uri, false, dur, 0L, dur, 1f, w, h, br)
        } catch (e: Exception) {
            null
        } finally {
            try {
                r.release()
            } catch (e: Exception) {
            }
        }
    }

    private fun total() = clips.sumOf { it.dur() }

    private fun locate(g: Long): Pair<Int, Long> {
        var acc = 0L
        for (i in clips.indices) {
            val d = clips[i].dur()
            if (g < acc + d || i == clips.lastIndex) return i to (g - acc).coerceIn(0L, d)
            acc += d
        }
        return 0 to 0L
    }

    private fun globalNow(): Long {
        val i = player.currentMediaItemIndex
        if (i !in clips.indices) return playhead
        var acc = 0L
        for (k in 0 until i) acc += clips[k].dur()
        val pos = player.currentPosition.coerceAtLeast(0L)
        val c = clips[i]
        val off = if (c.photo) pos else (pos / c.speed).toLong()
        return acc + off.coerceAtMost(c.dur())
    }

    private fun pushHistory() {
        history.add(clips.map { it.copy() })
        if (history.size > 30) history.removeAt(0)
    }

    private fun undo() {
        if (history.isEmpty()) {
            toast("Tidak ada yang bisa diurungkan.")
            return
        }
        clips = ArrayList(history.removeAt(history.size - 1))
        sel = -1
        rebuild(playhead.coerceAtMost(total()))
    }

    // ------------------------------------------------------------------ pratinjau

    private fun rebuild(seekGlobal: Long) {
        if (clips.isEmpty()) return
        val items = clips.map { c ->
            val b = MediaItem.Builder().setUri(c.uri)
            if (c.photo) {
                contentResolver.getType(c.uri)?.let { b.setMimeType(it) }
                b.setImageDurationMs(c.photoMs)
            } else {
                b.setClippingConfiguration(
                    MediaItem.ClippingConfiguration.Builder()
                        .setStartPositionMs(c.start)
                        .setEndPositionMs(c.end)
                        .build()
                )
            }
            b.build()
        }
        playhead = seekGlobal.coerceIn(0L, total())
        val (i, off) = locate(playhead)
        val c = clips[i]
        val inClip = if (c.photo) off else (off * c.speed).toLong()
        player.setMediaItems(items, i, inClip)
        player.volume = origVol
        player.prepare()
        applySpeed()
        pushTimeline()
    }

    private fun pushTimeline() {
        timeline.setClips(clips.map { it.dur() }, clips.map { it.photo }, clips.map { it.speed })
        timeline.selected = sel
        timeline.playheadMs = playhead
        updateTime()
    }

    private fun updateTime() {
        tvTime.text = Library.fmt(playhead) + " / " + Library.fmt(total())
    }

    private fun applySpeed() {
        val i = player.currentMediaItemIndex
        val s = if (i in clips.indices && !clips[i].photo) clips[i].speed else 1f
        player.setPlaybackSpeed(s)
    }

    private val tick = object : Runnable {
        override fun run() {
            if (!player.isPlaying) return
            playhead = globalNow()
            timeline.playheadMs = playhead
            updateTime()
            handler.postDelayed(this, 50)
        }
    }

    private fun togglePlay() {
        if (player.isPlaying) player.pause() else player.play()
    }

    private fun scrub(ms: Long) {
        if (clips.isEmpty() || exporting) return
        playhead = ms.coerceIn(0L, total())
        val (i, off) = locate(playhead)
        sel = i
        val c = clips[i]
        val inClip = if (c.photo) off else (off * c.speed).toLong()
        player.seekTo(i, inClip)
        applySpeed()
        timeline.selected = sel
        timeline.playheadMs = playhead
        updateTime()
        audioPlayer?.let { if (player.isPlaying) it.seekTo(playhead.coerceAtMost(songDur)) }
    }

    private fun syncAudio(playing: Boolean) {
        val a = audioPlayer ?: return
        if (playing && playhead < songDur) {
            a.seekTo(playhead)
            a.play()
        } else {
            a.pause()
        }
    }

    // ------------------------------------------------------------------ alat

    private fun split() {
        if (clips.isEmpty()) return
        val (i, off) = locate(playhead)
        val c = clips[i]
        if (c.photo) {
            toast("Foto tidak bisa dipisah.")
            return
        }
        val d = c.dur()
        if (off < 300L || d - off < 300L) {
            toast("Geser garis putih ke tengah klip dulu.")
            return
        }
        pushHistory()
        val srcOff = (off * c.speed).toLong()
        val a = c.copy()
        a.end = c.start + srcOff
        val b = c.copy()
        b.start = c.start + srcOff
        clips[i] = a
        clips.add(i + 1, b)
        sel = i
        rebuild(playhead)
    }

    private fun deleteSel() {
        if (sel !in clips.indices) {
            toast("Ketuk bagian di timeline yang mau dihapus.")
            return
        }
        if (clips.size == 1) {
            toast("Minimal harus ada satu bagian.")
            return
        }
        pushHistory()
        var before = 0L
        for (k in 0 until sel) before += clips[k].dur()
        clips.removeAt(sel)
        sel = -1
        rebuild(before)
    }

    private fun speedDialog() {
        if (sel !in clips.indices) {
            toast("Ketuk bagian di timeline dulu.")
            return
        }
        val c = clips[sel]
        if (c.photo) {
            photoDurationDialog(c)
            return
        }
        val steps = floatArrayOf(0.25f, 0.5f, 0.75f, 1f, 1.5f, 2f, 3f, 4f)
        Sheet.custom(this, "Kecepatan") { p, close ->
            val tv = TextView(this)
            tv.textSize = 28f
            tv.gravity = Gravity.CENTER
            tv.setTextColor(Color.WHITE)
            val sb = SeekBar(this)
            sb.max = steps.size - 1
            sb.progress = steps.indexOfFirst { it == c.speed }.let { if (it < 0) 3 else it }
            tv.text = TimelineView.fmtSpeed(steps[sb.progress])
            sb.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, v: Int, fromUser: Boolean) {
                    tv.text = TimelineView.fmtSpeed(steps[v])
                }

                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {}
            })
            p.addView(tv)
            p.addView(sb, LinearLayout.LayoutParams(-1, -2).apply { setMargins(dp(12), dp(8), dp(12), dp(8)) })
            p.addView(
                Sheet.buttonRow(
                    this,
                    Sheet.button(this, "Batal", false) { close() },
                    Sheet.button(this, "Terapkan", true) {
                        val v = steps[sb.progress]
                        close()
                        if (v != c.speed) {
                            pushHistory()
                            c.speed = v
                            rebuild(playhead)
                        }
                    }
                )
            )
        }
    }

    private fun photoDurationDialog(c: Clip) {
        Sheet.custom(this, "Durasi foto") { p, close ->
            val tv = TextView(this)
            tv.textSize = 28f
            tv.gravity = Gravity.CENTER
            tv.setTextColor(Color.WHITE)
            val sb = SeekBar(this)
            sb.max = 19
            sb.progress = ((c.photoMs / 500L).toInt() - 1).coerceIn(0, 19)
            fun sec(v: Int) = String.format(Locale.US, "%.1f detik", (v + 1) * 0.5)
            tv.text = sec(sb.progress)
            sb.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, v: Int, fromUser: Boolean) {
                    tv.text = sec(v)
                }

                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {}
            })
            p.addView(tv)
            p.addView(sb, LinearLayout.LayoutParams(-1, -2).apply { setMargins(dp(12), dp(8), dp(12), dp(8)) })
            p.addView(
                Sheet.buttonRow(
                    this,
                    Sheet.button(this, "Batal", false) { close() },
                    Sheet.button(this, "Terapkan", true) {
                        val ms = (sb.progress + 1) * 500L
                        close()
                        if (ms != c.photoMs) {
                            pushHistory()
                            c.photoMs = ms
                            rebuild(playhead)
                        }
                    }
                )
            )
        }
    }

    private fun songTap() {
        if (song == null) {
            pickSong()
        } else {
            Sheet.menu(
                this, songName, null,
                listOf(
                    Sheet.Item("Ganti lagu", R.drawable.ic_music_note) { pickSong() },
                    Sheet.Item("Hapus lagu", R.drawable.ic_trash, true) { clearSong() }
                )
            )
        }
    }

    private fun pickSong() {
        lifecycleScope.launch {
            val list = withContext(Dispatchers.IO) { Library.audios(this@VideoEditActivity) }
            if (list.isEmpty()) {
                toast("Belum ada lagu di HP (atau izin musik belum diberikan).")
                return@launch
            }
            Sheet.pickList(
                this@VideoEditActivity, "Pilih lagu",
                list.map { it.title }, list.map { it.artist }, R.drawable.ic_music_note
            ) { i -> setSong(list[i]) }
        }
    }

    private fun setSong(t: Library.Track) {
        audioPlayer?.release()
        song = t.uri
        songName = t.title
        songDur = t.durationMs
        val a = ExoPlayer.Builder(this).build()
        a.setMediaItem(MediaItem.fromUri(t.uri))
        a.volume = songVol
        a.prepare()
        audioPlayer = a
        tvSong.text = t.title + "  \u2022  " + t.artist
        tvSong.setTextColor(clr(R.color.text_soft))
    }

    private fun clearSong() {
        audioPlayer?.release()
        audioPlayer = null
        song = null
        tvSong.text = "Belum ada lagu"
        tvSong.setTextColor(clr(R.color.muted))
    }

    private fun volumeDialog() {
        Sheet.custom(this, "Suara") { p, close ->
            fun slider(name: String, start: Float, enabled: Boolean): SeekBar {
                val t = TextView(this)
                t.text = name
                t.textSize = 12f
                t.setTextColor(clr(R.color.muted))
                t.setPadding(dp(14), dp(6), dp(14), 0)
                p.addView(t)
                val sb = SeekBar(this)
                sb.max = 100
                sb.progress = (start * 100).toInt()
                sb.isEnabled = enabled
                p.addView(sb, LinearLayout.LayoutParams(-1, -2).apply { setMargins(dp(12), dp(4), dp(12), dp(8)) })
                return sb
            }
            val a = slider("Suara video asli", origVol, true)
            val b = slider(if (song == null) "Lagu (belum ada lagu)" else "Lagu", songVol, song != null)
            p.addView(
                Sheet.buttonRow(
                    this,
                    Sheet.button(this, "Batal", false) { close() },
                    Sheet.button(this, "Terapkan", true) {
                        origVol = a.progress / 100f
                        songVol = b.progress / 100f
                        player.volume = origVol
                        audioPlayer?.volume = songVol
                        close()
                    }
                )
            )
        }
    }

    // ------------------------------------------------------------------ simpan

    private fun askLeave() {
        if (exporting) return
        if (history.isEmpty() && song == null) {
            finish()
            return
        }
        Sheet.confirm(this, "Keluar dari editor?", "Perubahan yang belum disimpan akan hilang.", "Keluar", true) {
            finish()
        }
    }

    private fun askSave() {
        if (clips.isEmpty() || exporting) return
        player.pause()
        Sheet.choice(
            this, "Simpan hasil edit", "Resolusi dan bitrate mengikuti video asli.",
            listOf(
                "Simpan sebagai video baru" to "Video asli tetap ada",
                "Timpa video asli" to "Video asli diganti"
            ),
            0
        ) { i ->
            if (i == 0) {
                export(false)
            } else {
                Sheet.confirm(
                    this, "Timpa video asli?",
                    "Video asli akan diganti hasil edit dan tidak bisa dikembalikan.", "Timpa", true
                ) { export(true) }
            }
        }
    }

    private fun volumeProcessor(v: Float): AudioProcessor {
        val p = ChannelMixingAudioProcessor()
        p.putChannelMixingMatrix(ChannelMixingMatrix.create(1, 1).scaleBy(v))
        p.putChannelMixingMatrix(ChannelMixingMatrix.create(2, 2).scaleBy(v))
        return p
    }

    private fun buildComposition(total: Long): Composition {
        val vItems = ArrayList<EditedMediaItem>()
        for (c in clips) {
            if (c.photo) {
                vItems.add(
                    EditedMediaItem.Builder(MediaItem.fromUri(c.uri))
                        .setDurationUs(c.photoMs * 1000L)
                        .setFrameRate(30)
                        .build()
                )
            } else {
                val cc = MediaItem.ClippingConfiguration.Builder()
                    .setStartPositionMs(c.start)
                    .setEndPositionMs(c.end)
                    .build()
                val mi = MediaItem.Builder().setUri(c.uri).setClippingConfiguration(cc).build()
                val ap = ArrayList<AudioProcessor>()
                val ve = ArrayList<Effect>()
                if (c.speed != 1f) {
                    ve.add(SpeedChangeEffect(c.speed))
                    val sonic = SonicAudioProcessor()
                    sonic.setSpeed(c.speed)
                    sonic.setPitch(1f)
                    ap.add(sonic)
                }
                if (origVol != 1f) ap.add(volumeProcessor(origVol))
                vItems.add(EditedMediaItem.Builder(mi).setEffects(Effects(ap, ve)).build())
            }
        }
        val seqs = ArrayList<EditedMediaItemSequence>()
        seqs.add(EditedMediaItemSequence.Builder(vItems).build())
        val s = song
        if (s != null) {
            val end = minOf(songDur, total).coerceAtLeast(1L)
            val cc = MediaItem.ClippingConfiguration.Builder()
                .setStartPositionMs(0L)
                .setEndPositionMs(end)
                .build()
            val mi = MediaItem.Builder().setUri(s).setClippingConfiguration(cc).build()
            val ei = EditedMediaItem.Builder(mi)
                .setRemoveVideo(true)
                .setEffects(Effects(listOf(volumeProcessor(songVol)), emptyList()))
                .build()
            seqs.add(EditedMediaItemSequence.Builder(listOf(ei)).build())
        }
        val cb = Composition.Builder(seqs)
        val hasPhoto = clips.any { it.photo }
        if (hasPhoto) cb.experimentalSetForceAudioTrack(true)
        val vids = clips.filter { !it.photo && it.w > 0 && it.h > 0 }
        val sizes = vids.map { it.w to it.h }.distinct()
        if (hasPhoto || sizes.size > 1) {
            var w = if (vids.isNotEmpty()) vids[0].w else 1080
            var h = if (vids.isNotEmpty()) vids[0].h else 1920
            w -= w % 2
            h -= h % 2
            cb.setEffects(
                Effects(
                    emptyList(),
                    listOf<Effect>(Presentation.createForWidthAndHeight(w, h, Presentation.LAYOUT_SCALE_TO_FIT))
                )
            )
        }
        return cb.build()
    }

    private fun export(overwrite: Boolean) {
        val total = total()
        val comp = try {
            buildComposition(total)
        } catch (e: Exception) {
            toast("Gagal menyiapkan video: ${e.message}")
            return
        }
        val out = File(cacheDir, "edit_" + System.currentTimeMillis() + ".mp4")
        outFile = out
        exporting = true

        val br = clips.filter { !it.photo }.maxOfOrNull { it.bitrate } ?: 0
        val encBuilder = DefaultEncoderFactory.Builder(this)
        if (br > 0) {
            encBuilder.setRequestedVideoEncoderSettings(
                VideoEncoderSettings.Builder().setBitrate(br.coerceIn(2_000_000, 80_000_000)).build()
            )
        }

        val t = Transformer.Builder(this)
            .setEncoderFactory(encBuilder.build())
            .addListener(object : Transformer.Listener {
                override fun onCompleted(composition: Composition, exportResult: ExportResult) {
                    onExportDone(out, overwrite)
                }

                override fun onError(
                    composition: Composition, exportResult: ExportResult, exportException: ExportException
                ) {
                    onExportFailed(out, exportException.message ?: "kesalahan tidak diketahui")
                }
            })
            .build()
        transformer = t

        progressDlg = Sheet.custom(this, "Menyimpan video\u2026") { p, close ->
            val pb = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal)
            pb.max = 100
            pb.progressTintList = ColorStateList.valueOf(Color.WHITE)
            progressBar = pb
            val pct = TextView(this)
            pct.text = "0%"
            pct.textSize = 13f
            pct.gravity = Gravity.CENTER
            pct.setTextColor(clr(R.color.text_soft))
            tvPct = pct
            p.addView(pb, LinearLayout.LayoutParams(-1, -2).apply { setMargins(dp(14), dp(8), dp(14), dp(4)) })
            p.addView(pct)
            p.addView(
                Sheet.buttonRow(
                    this,
                    Sheet.button(this, "Batal", false) {
                        t.cancel()
                        close()
                        stopProgress()
                        out.delete()
                        exporting = false
                    }
                )
            )
        }
        progressDlg?.setCancelable(false)

        try {
            t.start(comp, out.absolutePath)
            handler.post(progressTick)
        } catch (e: Exception) {
            onExportFailed(out, e.message ?: "gagal memulai")
        }
    }

    private val progressTick = object : Runnable {
        override fun run() {
            val t = transformer ?: return
            val h = ProgressHolder()
            if (t.getProgress(h) == Transformer.PROGRESS_STATE_AVAILABLE) {
                progressBar?.progress = h.progress
                tvPct?.text = "${h.progress}%"
            }
            handler.postDelayed(this, 300)
        }
    }

    private fun stopProgress() {
        handler.removeCallbacks(progressTick)
        transformer = null
        progressDlg?.dismiss()
        progressDlg = null
    }

    private fun onExportFailed(out: File, msg: String) {
        stopProgress()
        out.delete()
        exporting = false
        toast("Gagal menyimpan: $msg")
    }

    private fun onExportDone(out: File, overwrite: Boolean) {
        stopProgress()
        if (overwrite) {
            overwriteOriginal(out)
        } else {
            lifecycleScope.launch {
                val ok = withContext(Dispatchers.IO) { saveAsNew(out) }
                out.delete()
                exporting = false
                if (ok) {
                    toast("Video baru disimpan.")
                    finish()
                } else {
                    toast("Gagal menyimpan ke galeri.")
                }
            }
        }
    }

    private fun saveAsNew(out: File): Boolean {
        val base = origName.substringBeforeLast('.')
        val name = base + "_edit.mp4"
        val allowed = listOf("DCIM/", "Movies/", "Pictures/")
        val rel = if (origRel.isNotEmpty() && allowed.any { origRel.startsWith(it) }) origRel else "Movies/BunnyTL/"
        fun insert(path: String?): Uri? {
            val v = ContentValues()
            v.put(MediaStore.Video.Media.DISPLAY_NAME, name)
            v.put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
            if (Build.VERSION.SDK_INT >= 29 && path != null) {
                v.put(MediaStore.Video.Media.RELATIVE_PATH, path)
                v.put(MediaStore.Video.Media.IS_PENDING, 1)
            }
            return contentResolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, v)
        }
        return try {
            val uri = try {
                insert(rel)
            } catch (e: Exception) {
                insert("Movies/BunnyTL/")
            } ?: return false
            contentResolver.openOutputStream(uri, "w")?.use { o -> out.inputStream().use { it.copyTo(o) } }
            if (Build.VERSION.SDK_INT >= 29) {
                val v = ContentValues()
                v.put(MediaStore.Video.Media.IS_PENDING, 0)
                contentResolver.update(uri, v, null, null)
            }
            true
        } catch (e: Exception) {
            false
        }
    }

    private fun overwriteOriginal(out: File) {
        fun copy() {
            lifecycleScope.launch {
                val ok = withContext(Dispatchers.IO) {
                    try {
                        contentResolver.openOutputStream(origUri, "wt")?.use { o ->
                            out.inputStream().use { it.copyTo(o) }
                        }
                        true
                    } catch (e: Exception) {
                        false
                    }
                }
                out.delete()
                exporting = false
                if (ok) {
                    toast("Video asli diganti.")
                    finish()
                } else {
                    toast("Gagal menimpa video asli.")
                }
            }
        }
        if (Build.VERSION.SDK_INT >= 30) {
            try {
                val pi = MediaStore.createWriteRequest(contentResolver, listOf(origUri))
                pendingWrite = { copy() }
                writeLauncher.launch(IntentSenderRequest.Builder(pi.intentSender).build())
            } catch (e: Exception) {
                exporting = false
                toast("Gagal: ${e.message}")
            }
        } else {
            copy()
        }
    }

    // ------------------------------------------------------------------ siklus hidup

    override fun onPause() {
        super.onPause()
        if (::player.isInitialized) player.pause()
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        transformer?.cancel()
        if (::player.isInitialized) player.release()
        audioPlayer?.release()
        super.onDestroy()
    }
}
