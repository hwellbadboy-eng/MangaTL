package com.niven.mangatl

import android.content.ContentValues
import android.content.res.ColorStateList
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.IntentSenderRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import androidx.media3.common.C
import androidx.media3.common.Effect
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.common.audio.AudioProcessor
import androidx.media3.common.audio.BaseAudioProcessor
import androidx.media3.common.audio.ChannelMixingAudioProcessor
import androidx.media3.common.audio.ChannelMixingMatrix
import androidx.media3.common.audio.SonicAudioProcessor
import androidx.media3.effect.Presentation
import androidx.media3.effect.RgbMatrix
import androidx.media3.effect.SpeedChangeEffect
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.transformer.Composition
import androidx.media3.transformer.DefaultEncoderFactory
import androidx.media3.transformer.EditedMediaItem
import androidx.media3.transformer.EditedMediaItemSequence
import androidx.media3.transformer.Effects
import androidx.media3.transformer.ExportException
import androidx.media3.transformer.ExportResult
import androidx.media3.transformer.ProgressHolder
import androidx.media3.transformer.Transformer
import androidx.media3.transformer.VideoEncoderSettings
import androidx.media3.ui.PlayerView
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.nio.ByteBuffer
import java.util.Locale

/**
 * Editor video dasar: pisah klip, hapus bagian, percepat/perlambat, sambung video/foto,
 * tambah lagu. Hasil disimpan dengan resolusi dan bitrate mengikuti video asli.
 */
class VideoEditActivity : AppCompatActivity() {

    class Clip(
        val uri: Uri,
        val photo: Boolean,
        val srcDur: Long,
        var start: Long,
        var end: Long,
        var speed: Float,
        val w: Int,
        val h: Int,
        val bitrate: Int,
        var photoMs: Long = 3000L,
        var fadeIn: Long = 0L,
        var fadeOut: Long = 0L,
        var smooth: Float = 0.7f
    ) {
        fun dur(): Long =
            if (photo) photoMs else (((end - start) / speed).toLong()).coerceAtLeast(1L)

        /** Pudar tidak boleh lebih panjang dari klipnya. */
        fun clampFades() {
            val d = dur()
            fadeIn = fadeIn.coerceIn(0L, d)
            fadeOut = fadeOut.coerceIn(0L, d - fadeIn)
        }

        fun copy() = Clip(uri, photo, srcDur, start, end, speed, w, h, bitrate, photoMs, fadeIn, fadeOut, smooth)
    }

    /** Satu potongan lagu di timeline: mulai di detik video ke [start], memakai bagian lagu [from]..[to]. */
    class Seg(
        var start: Long,
        var from: Long,
        var to: Long,
        var fadeIn: Long = 0L,
        var fadeOut: Long = 0L,
        var smooth: Float = 0.7f
    ) {
        fun len(): Long = to - from
        fun end(): Long = start + len()
        fun clampFades() {
            val d = len()
            fadeIn = fadeIn.coerceIn(0L, d)
            fadeOut = fadeOut.coerceIn(0L, d - fadeIn)
        }

        fun copy() = Seg(start, from, to, fadeIn, fadeOut, smooth)
    }

    private class Snap(val clips: List<Clip>, val segs: List<Seg>)

    private var clips = ArrayList<Clip>()
    private var segs = ArrayList<Seg>()
    private val history = ArrayList<Snap>()
    private var sel = -1
    private var selA = -1
    private var curSeg = -1
    private var playhead = 0L

    private var song: Uri? = null
    private var songName = ""
    private var songDur = 0L
    private var songVol = 1f
    private var origVol = 1f

    private lateinit var origUri: Uri
    private var origName = "video.mp4"
    private var origRel = ""

    private lateinit var player: ExoPlayer
    private var audioPlayer: ExoPlayer? = null
    private lateinit var playerView: PlayerView
    private lateinit var timeline: TimelineView
    private lateinit var tvTime: TextView
    private lateinit var fadeCover: View
    private lateinit var smoothBar: SeekBar
    private lateinit var tvSmooth: TextView
    private var smoothSync = false
    private var pendingHistory = false
    private lateinit var btnPlay: ImageButton

    private val handler = Handler(Looper.getMainLooper())
    private var transformer: Transformer? = null
    private var progressBar: ProgressBar? = null
    private var tvPct: TextView? = null
    private var progressDlg: AlertDialog? = null
    private var outFile: File? = null
    private var exporting = false
    private var pendingWrite: (() -> Unit)? = null

    private val addPicker = registerForActivityResult(
        ActivityResultContracts.OpenMultipleDocuments()
    ) { uris ->
        if (uris.isEmpty()) return@registerForActivityResult
        lifecycleScope.launch {
            val loaded = withContext(Dispatchers.IO) { uris.mapNotNull { loadClip(it) } }
            if (loaded.isEmpty()) {
                toast("File tidak bisa dibuka.")
                return@launch
            }
            pushHistory()
            var idx = 0
            if (clips.isNotEmpty()) {
                val (i, off) = locate(playhead)
                val c = clips[i]
                idx = if (!c.photo && off >= 300L && c.dur() - off >= 300L) {
                    val srcOff = (off * c.speed).toLong()
                    val a = c.copy()
                    a.end = c.start + srcOff
                    a.fadeOut = 0L
                    a.clampFades()
                    val b = c.copy()
                    b.start = c.start + srcOff
                    b.fadeIn = 0L
                    b.clampFades()
                    clips[i] = a
                    clips.add(i + 1, b)
                    i + 1
                } else if (off >= c.dur() / 2) i + 1 else i
            }
            clips.addAll(idx, loaded)
            sel = idx
            selA = -1
            var before = 0L
            for (k in 0 until idx) before += clips[k].dur()
            rebuild(before)
            toast("Ditambahkan di posisi garis putih.")
        }
    }

    private val writeLauncher = registerForActivityResult(
        ActivityResultContracts.StartIntentSenderForResult()
    ) { r ->
        val cb = pendingWrite
        pendingWrite = null
        if (r.resultCode == RESULT_OK) cb?.invoke() else {
            toast("Izin tulis ditolak. Video asli tidak diubah.")
            outFile?.delete()
        }
    }

    // ------------------------------------------------------------------ UI

    private fun dp(v: Int) = Ui.dp(this, v)
    private fun clr(id: Int) = ContextCompat.getColor(this, id)
    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()

    private fun label(text: String) = TextView(this).apply {
        this.text = text
        textSize = 11f
        setTextColor(clr(R.color.muted))
        setPadding(0, 0, 0, dp(4))
    }

    private fun tool(icon: Int, name: String, onClick: () -> Unit): View {
        val l = LinearLayout(this)
        l.orientation = LinearLayout.VERTICAL
        l.gravity = Gravity.CENTER
        l.setPadding(0, dp(8), 0, dp(8))
        l.layoutParams = LinearLayout.LayoutParams(dp(68), ViewGroup.LayoutParams.WRAP_CONTENT)
        val iv = ImageView(this)
        iv.setImageResource(icon)
        iv.setColorFilter(Color.WHITE)
        iv.layoutParams = LinearLayout.LayoutParams(dp(22), dp(22))
        l.addView(iv)
        l.addView(TextView(this).apply {
            text = name
            textSize = 11f
            gravity = Gravity.CENTER
            setTextColor(clr(R.color.text_soft))
            maxLines = 1
            setPadding(0, dp(2), 0, 0)
        })
        l.setOnClickListener { onClick() }
        return l
    }

    private fun iconButton(res: Int, desc: String, onClick: () -> Unit): ImageButton {
        val b = ImageButton(this)
        b.setImageResource(res)
        b.setColorFilter(Color.WHITE)
        b.contentDescription = desc
        b.setBackgroundColor(Color.TRANSPARENT)
        b.setPadding(dp(10), dp(10), dp(10), dp(10))
        b.setOnClickListener { onClick() }
        return b
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val uriStr = intent.getStringExtra("uri")
        if (uriStr == null) {
            finish()
            return
        }
        origUri = Uri.parse(uriStr)
        origName = intent.getStringExtra("name") ?: "video.mp4"
        origRel = intent.getStringExtra("rel") ?: ""

        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setBackgroundColor(clr(R.color.bg))
        root.setPadding(dp(12), dp(8), dp(12), dp(8))

        // bilah atas
        val top = LinearLayout(this)
        top.orientation = LinearLayout.HORIZONTAL
        top.gravity = Gravity.CENTER_VERTICAL
        top.addView(iconButton(R.drawable.ic_back, "Kembali") { askLeave() })
        top.addView(TextView(this).apply {
            text = "Edit video"
            textSize = 16f
            typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
            setTextColor(Color.WHITE)
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
                .apply { marginStart = dp(6) }
        })
        top.addView(iconButton(R.drawable.ic_undo, "Urungkan") { undo() })
        top.addView(TextView(this).apply {
            text = "Simpan"
            textSize = 13f
            typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
            setTextColor(Color.parseColor("#000000"))
            setPadding(dp(16), dp(8), dp(16), dp(8))
            background = GradientDrawable().apply {
                setColor(Color.parseColor("#F2F2F2"))
                cornerRadius = dp(14).toFloat()
            }
            setOnClickListener { askSave() }
        })
        root.addView(top)

        // pratinjau
        val pv = FrameLayout(this)
        pv.setBackgroundColor(Color.BLACK)
        pv.layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f)
            .apply { topMargin = dp(8) }
        playerView = PlayerView(this)
        playerView.useController = false
        playerView.setShutterBackgroundColor(Color.BLACK)
        pv.addView(playerView, FrameLayout.LayoutParams(-1, -1))
        fadeCover = View(this)
        fadeCover.setBackgroundColor(Color.BLACK)
        fadeCover.alpha = 0f
        pv.addView(fadeCover, FrameLayout.LayoutParams(-1, -1))
        btnPlay = iconButton(R.drawable.ic_play, "Putar") { togglePlay() }
        pv.addView(btnPlay, FrameLayout.LayoutParams(dp(64), dp(64), Gravity.CENTER))
        tvTime = TextView(this).apply {
            textSize = 12f
            setTextColor(clr(R.color.text_soft))
            setPadding(dp(10), 0, 0, dp(8))
        }
        pv.addView(tvTime, FrameLayout.LayoutParams(-2, -2, Gravity.BOTTOM or Gravity.START))
        root.addView(pv)

        // timeline
        val card = LinearLayout(this)
        card.orientation = LinearLayout.VERTICAL
        card.setBackgroundResource(R.drawable.bg_card)
        card.setPadding(dp(12), dp(10), dp(12), dp(12))
        card.layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            .apply { topMargin = dp(10) }
        timeline = TimelineView(this)
        timeline.layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, timeline.wantedHeightPx())
        timeline.onScrub = { ms, pick -> scrub(ms, pick) }
        timeline.onSelectAudio = { i -> selectAudio(i) }
        timeline.onDragStart = { pendingHistory = true }
        timeline.onVideoFade = { i, isIn, ms -> videoFade(i, isIn, ms) }
        timeline.onAudioEdit = { i, mode, ms -> audioEdit(i, mode, ms) }
        card.addView(timeline)

        val smRow = LinearLayout(this)
        smRow.orientation = LinearLayout.HORIZONTAL
        smRow.gravity = Gravity.CENTER_VERTICAL
        smRow.setPadding(0, dp(6), 0, 0)
        smRow.addView(TextView(this).apply {
            text = "Kehalusan kurva"
            textSize = 12f
            setTextColor(clr(R.color.muted))
        })
        tvSmooth = TextView(this).apply {
            text = "70%"
            textSize = 12f
            setTextColor(Color.WHITE)
            gravity = Gravity.END
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        }
        smRow.addView(tvSmooth)
        card.addView(smRow)
        smoothBar = SeekBar(this)
        smoothBar.max = 100
        smoothBar.progress = 70
        smoothBar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar?, v: Int, fromUser: Boolean) {
                tvSmooth.text = "$v%"
                if (!fromUser || smoothSync) return
                if (sel in clips.indices) clips[sel].smooth = v / 100f
                else if (selA in segs.indices) segs[selA].smooth = v / 100f
                else return
                pushTimeline()
            }

            override fun onStartTrackingTouch(sb: SeekBar?) {
                if (sel in clips.indices || selA in segs.indices) pushHistory()
                else toast("Pilih klip video atau lagu dulu.")
            }

            override fun onStopTrackingTouch(sb: SeekBar?) {}
        })
        card.addView(smoothBar, LinearLayout.LayoutParams(-1, -2))
        root.addView(card)

        // alat
        val tools = LinearLayout(this)
        tools.orientation = LinearLayout.HORIZONTAL
        tools.addView(tool(R.drawable.ic_cut, "Pisah") { split() })
        tools.addView(tool(R.drawable.ic_trim, "Potong") { trimDialog() })
        tools.addView(tool(R.drawable.ic_trash, "Hapus") { deleteSel() })
        tools.addView(tool(R.drawable.ic_prev, "Geser kiri") { moveSel(-1) })
        tools.addView(tool(R.drawable.ic_next, "Geser kanan") { moveSel(1) })
        tools.addView(tool(R.drawable.ic_speed, "Kecepatan") { speedDialog() })
        tools.addView(tool(R.drawable.ic_movie, "Video/foto") { addPicker.launch(arrayOf("video/*", "image/*")) })
        tools.addView(tool(R.drawable.ic_music_note, "Lagu") { pickSong() })
        tools.addView(tool(R.drawable.ic_volume, "Suara") { volumeDialog() })
        val hs = HorizontalScrollView(this)
        hs.isHorizontalScrollBarEnabled = false
        hs.addView(tools)
        hs.layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            .apply { topMargin = dp(6) }
        root.addView(hs)

        setContentView(root)

        player = ExoPlayer.Builder(this, Decoders.factory(this, Prefs.decoder(this))).build()
        playerView.player = player
        player.addListener(object : Player.Listener {
            override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) = applySpeed()
            override fun onIsPlayingChanged(isPlaying: Boolean) {
                btnPlay.setImageResource(if (isPlaying) R.drawable.ic_pause else R.drawable.ic_play)
                if (isPlaying) {
                    handler.post(tick)
                } else {
                    playhead = globalNow()
                }
                syncAudio(isPlaying)
            }

            override fun onPlaybackStateChanged(playbackState: Int) {
                if (playbackState == Player.STATE_ENDED) {
                    player.pause()
                    playhead = 0L
                    rebuild(0L)
                }
            }
        })
        playerView.setOnClickListener { togglePlay() }

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() = askLeave()
        })

        lifecycleScope.launch {
            val c = withContext(Dispatchers.IO) { loadClip(origUri) }
            if (c == null) {
                toast("Video tidak bisa dibuka.")
                finish()
                return@launch
            }
            clips.add(c)
            rebuild(0L)
        }
    }

    // ------------------------------------------------------------------ data klip

    private fun loadClip(uri: Uri): Clip? {
        val type = contentResolver.getType(uri) ?: ""
        if (type.startsWith("image/")) {
            return try {
                val o = BitmapFactory.Options()
                o.inJustDecodeBounds = true
                contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, o) }
                Clip(uri, true, 0L, 0L, 0L, 1f, o.outWidth, o.outHeight, 0)
            } catch (e: Exception) {
                null
            }
        }
        val r = MediaMetadataRetriever()
        return try {
            r.setDataSource(this, uri)
            val dur = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L
            var w = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH)?.toIntOrNull() ?: 0
            var h = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT)?.toIntOrNull() ?: 0
            val rot = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_ROTATION)?.toIntOrNull() ?: 0
            if (rot == 90 || rot == 270) {
                val t = w
                w = h
                h = t
            }
            val br = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_BITRATE)?.toIntOrNull() ?: 0
            if (dur <= 0L) null else Clip(uri, false, dur, 0L, dur, 1f, w, h, br)
        } catch (e: Exception) {
            null
        } finally {
            try {
                r.release()
            } catch (e: Exception) {
            }
        }
    }

    private fun total() = clips.sumOf { it.dur() }

    private fun locate(g: Long): Pair<Int, Long> {
        var acc = 0L
        for (i in clips.indices) {
            val d = clips[i].dur()
            if (g < acc + d || i == clips.lastIndex) return i to (g - acc).coerceIn(0L, d)
            acc += d
        }
        return 0 to 0L
    }

    private fun globalNow(): Long {
        val i = player.currentMediaItemIndex
        if (i !in clips.indices) return playhead
        var acc = 0L
        for (k in 0 until i) acc += clips[k].dur()
        val pos = player.currentPosition.coerceAtLeast(0L)
        val c = clips[i]
        val off = if (c.photo) pos else (pos / c.speed).toLong()
        return acc + off.coerceAtMost(c.dur())
    }

    private fun pushHistory() {
        history.add(Snap(clips.map { it.copy() }, segs.map { it.copy() }))
        if (history.size > 40) history.removeAt(0)
    }

    private fun undo() {
        if (history.isEmpty()) {
            toast("Tidak ada yang bisa diurungkan.")
            return
        }
        val snap = history.removeAt(history.size - 1)
        clips = ArrayList(snap.clips)
        segs = ArrayList(snap.segs)
        sel = -1
        selA = -1
        if (segs.isEmpty() && song != null) clearSong()
        rebuild(playhead.coerceAtMost(total()))
    }

    // ------------------------------------------------------------------ pratinjau

    private fun rebuild(seekGlobal: Long) {
        if (clips.isEmpty()) return
        val items = clips.map { c ->
            val b = MediaItem.Builder().setUri(c.uri)
            if (c.photo) {
                contentResolver.getType(c.uri)?.let { b.setMimeType(it) }
                b.setImageDurationMs(c.photoMs)
            } else {
                b.setClippingConfiguration(
                    MediaItem.ClippingConfiguration.Builder()
                        .setStartPositionMs(c.start)
                        .setEndPositionMs(c.end)
                        .build()
                )
            }
            b.build()
        }
        playhead = seekGlobal.coerceIn(0L, total())
        val (i, off) = locate(playhead)
        val c = clips[i]
        val inClip = if (c.photo) off else (off * c.speed).toLong()
        player.setMediaItems(items, i, inClip)
        player.volume = origVol
        player.prepare()
        applySpeed()
        pushTimeline()
    }

    private fun pushTimeline() {
        timeline.setData(
            clips.map { TimelineView.V(it.dur(), it.photo, it.speed, it.fadeIn, it.fadeOut, it.smooth) },
            segs.map { TimelineView.A(it.start, it.len(), it.fadeIn, it.fadeOut, it.smooth) }
        )
        timeline.selV = sel
        timeline.selA = selA
        timeline.playheadMs = playhead
        syncSmooth()
        updateTime()
    }

    private fun syncSmooth() {
        val v = when {
            sel in clips.indices -> clips[sel].smooth
            selA in segs.indices -> segs[selA].smooth
            else -> null
        }
        smoothSync = true
        if (v != null) smoothBar.progress = Math.round(v * 100f)
        tvSmooth.text = "${smoothBar.progress}%"
        smoothBar.alpha = if (v != null) 1f else 0.45f
        smoothSync = false
    }

    private fun updateTime() {
        tvTime.text = Library.fmt(playhead) + " / " + Library.fmt(total())
        applyFadePreview()
    }

    /** Pratinjau pudar video: layar menggelap sesuai kurva di posisi putar. */
    private fun applyFadePreview() {
        if (clips.isEmpty()) return
        val (i, off) = locate(playhead)
        val c = clips[i]
        val g = TimelineView.fadeGain(off, c.dur(), c.fadeIn, c.fadeOut, c.smooth)
        fadeCover.alpha = 1f - g
    }

    private fun applySpeed() {
        val i = player.currentMediaItemIndex
        val s = if (i in clips.indices && !clips[i].photo) clips[i].speed else 1f
        player.setPlaybackSpeed(s)
    }

    private val tick = object : Runnable {
        override fun run() {
            if (!player.isPlaying) return
            playhead = globalNow()
            timeline.playheadMs = playhead
            updateTime()
            audioTick()
            handler.postDelayed(this, 50)
        }
    }

    private fun togglePlay() {
        if (player.isPlaying) player.pause() else player.play()
    }

    private fun scrub(ms: Long, pick: Boolean) {
        if (clips.isEmpty() || exporting) return
        playhead = ms.coerceIn(0L, total())
        val (i, off) = locate(playhead)
        if (pick) {
            sel = i
            selA = -1
        }
        val c = clips[i]
        val inClip = if (c.photo) off else (off * c.speed).toLong()
        player.seekTo(i, inClip)
        applySpeed()
        timeline.selV = sel
        timeline.selA = selA
        timeline.playheadMs = playhead
        syncSmooth()
        updateTime()
        audioPlayer?.pause()
        curSeg = -1
    }

    private fun syncAudio(playing: Boolean) {
        if (playing) audioTick() else audioPlayer?.pause()
    }

    /** Jalankan lagu hanya saat posisi putar ada di salah satu potongan lagu, dengan volume mengikuti kurva pudar. */
    private fun audioTick() {
        val a = audioPlayer ?: return
        var found = -1
        for (k in segs.indices) {
            val sg = segs[k]
            if (playhead >= sg.start && playhead < sg.end()) {
                found = k
                break
            }
        }
        if (player.isPlaying && found >= 0) {
            val sg = segs[found]
            val rel = playhead - sg.start
            if (!a.isPlaying || curSeg != found) {
                a.seekTo(sg.from + rel)
                a.play()
                curSeg = found
            }
            a.volume = songVol * TimelineView.fadeGain(rel, sg.len(), sg.fadeIn, sg.fadeOut, sg.smooth)
        } else if (a.isPlaying) {
            a.pause()
            curSeg = -1
        }
    }

    // ------------------------------------------------------------------ alat

    private fun splitSeg() {
        val sg = segs[selA]
        val rel = playhead - sg.start
        if (rel < 300L || sg.len() - rel < 300L) {
            toast("Geser garis putih ke tengah lagu dulu.")
            return
        }
        pushHistory()
        val b = sg.copy()
        b.start = playhead
        b.from = sg.from + rel
        b.fadeIn = 0L
        sg.to = sg.from + rel
        sg.fadeOut = 0L
        sg.clampFades()
        b.clampFades()
        segs.add(selA + 1, b)
        pushTimeline()
    }

    private fun split() {
        if (selA in segs.indices) {
            splitSeg()
            return
        }
        if (clips.isEmpty()) return
        val (i, off) = locate(playhead)
        val c = clips[i]
        if (c.photo) {
            toast("Foto tidak bisa dipisah.")
            return
        }
        val d = c.dur()
        if (off < 300L || d - off < 300L) {
            toast("Geser garis putih ke tengah klip dulu.")
            return
        }
        pushHistory()
        val srcOff = (off * c.speed).toLong()
        val a = c.copy()
        a.end = c.start + srcOff
        a.fadeOut = 0L
        a.clampFades()
        val b = c.copy()
        b.start = c.start + srcOff
        b.fadeIn = 0L
        b.clampFades()
        clips[i] = a
        clips.add(i + 1, b)
        sel = i
        rebuild(playhead)
    }

    private fun deleteSel() {
        if (selA in segs.indices) {
            pushHistory()
            segs.removeAt(selA)
            selA = -1
            curSeg = -1
            audioPlayer?.pause()
            if (segs.isEmpty()) clearSong()
            pushTimeline()
            return
        }
        if (sel !in clips.indices) {
            toast("Ketuk bagian di timeline yang mau dihapus.")
            return
        }
        if (clips.size == 1) {
            toast("Minimal harus ada satu bagian.")
            return
        }
        pushHistory()
        var before = 0L
        for (k in 0 until sel) before += clips[k].dur()
        clips.removeAt(sel)
        sel = -1
        rebuild(before)
    }

    private fun moveSel(dir: Int) {
        if (selA in segs.indices) {
            pendingHistory = true
            audioEdit(selA, TimelineView.MODE_MOVE, segs[selA].start + dir * 100L)
            return
        }
        if (sel !in clips.indices) {
            toast("Ketuk bagian di timeline dulu.")
            return
        }
        val j = sel + dir
        if (j !in clips.indices) {
            toast(if (dir < 0) "Sudah paling kiri." else "Sudah paling kanan.")
            return
        }
        pushHistory()
        val c = clips.removeAt(sel)
        clips.add(j, c)
        sel = j
        var before = 0L
        for (k in 0 until j) before += clips[k].dur()
        rebuild(before)
    }

    private fun trimDialog() {
        if (selA in segs.indices) {
            toast("Tarik pegangan di ujung lagu pada timeline.")
            return
        }
        if (sel !in clips.indices) {
            toast("Ketuk bagian di timeline dulu.")
            return
        }
        val c = clips[sel]
        if (c.photo) {
            photoDurationDialog(c)
            return
        }
        val step = 100L
        Sheet.custom(this, "Potong bagian") { p, close ->
            val tv = TextView(this)
            tv.textSize = 15f
            tv.gravity = Gravity.CENTER
            tv.setTextColor(Color.WHITE)
            fun slider(name: String, v: Long): SeekBar {
                val t = TextView(this)
                t.text = name
                t.textSize = 12f
                t.setTextColor(clr(R.color.muted))
                t.setPadding(dp(14), dp(8), dp(14), 0)
                p.addView(t)
                val sb = SeekBar(this)
                sb.max = (c.srcDur / step).toInt().coerceAtLeast(1)
                sb.progress = (v / step).toInt()
                p.addView(sb, LinearLayout.LayoutParams(-1, -2).apply { setMargins(dp(12), dp(4), dp(12), dp(4)) })
                return sb
            }
            val a = slider("Mulai dari (detik video asli)", c.start)
            val b = slider("Sampai (detik video asli)", c.end)
            fun show() {
                tv.text = Library.fmt(a.progress * step) + "  \u2192  " + Library.fmt(b.progress * step)
            }
            val l = object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, v: Int, fromUser: Boolean) {
                    if (fromUser) {
                        if (s === a && a.progress >= b.progress) b.progress = minOf(b.max, a.progress + 3)
                        if (s === b && b.progress <= a.progress) a.progress = maxOf(0, b.progress - 3)
                    }
                    show()
                }

                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {}
            }
            a.setOnSeekBarChangeListener(l)
            b.setOnSeekBarChangeListener(l)
            show()
            p.addView(tv, 1)
            p.addView(
                Sheet.buttonRow(
                    this,
                    Sheet.button(this, "Batal", false) { close() },
                    Sheet.button(this, "Terapkan", true) {
                        val ns = a.progress * step
                        val ne = minOf(c.srcDur, b.progress * step)
                        close()
                        if (ne - ns < 300L) {
                            toast("Bagian terlalu pendek.")
                        } else if (ns != c.start || ne != c.end) {
                            pushHistory()
                            c.start = ns
                            c.end = ne
                            c.clampFades()
                            rebuild(playhead)
                        }
                    }
                )
            )
        }
    }

    private fun speedDialog() {
        if (selA in segs.indices) {
            toast("Kecepatan hanya untuk video.")
            return
        }
        if (sel !in clips.indices) {
            toast("Ketuk bagian di timeline dulu.")
            return
        }
        val c = clips[sel]
        if (c.photo) {
            photoDurationDialog(c)
            return
        }
        val steps = floatArrayOf(0.25f, 0.5f, 0.75f, 1f, 1.5f, 2f, 3f, 4f)
        Sheet.custom(this, "Kecepatan") { p, close ->
            val tv = TextView(this)
            tv.textSize = 28f
            tv.gravity = Gravity.CENTER
            tv.setTextColor(Color.WHITE)
            val sb = SeekBar(this)
            sb.max = steps.size - 1
            sb.progress = steps.indexOfFirst { it == c.speed }.let { if (it < 0) 3 else it }
            tv.text = TimelineView.fmtSpeed(steps[sb.progress])
            sb.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, v: Int, fromUser: Boolean) {
                    tv.text = TimelineView.fmtSpeed(steps[v])
                }

                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {}
            })
            p.addView(tv)
            p.addView(sb, LinearLayout.LayoutParams(-1, -2).apply { setMargins(dp(12), dp(8), dp(12), dp(8)) })
            p.addView(
                Sheet.buttonRow(
                    this,
                    Sheet.button(this, "Batal", false) { close() },
                    Sheet.button(this, "Terapkan", true) {
                        val v = steps[sb.progress]
                        close()
                        if (v != c.speed) {
                            pushHistory()
                            c.speed = v
                            c.clampFades()
                            rebuild(playhead)
                        }
                    }
                )
            )
        }
    }

    private fun photoDurationDialog(c: Clip) {
        Sheet.custom(this, "Durasi foto") { p, close ->
            val tv = TextView(this)
            tv.textSize = 28f
            tv.gravity = Gravity.CENTER
            tv.setTextColor(Color.WHITE)
            val sb = SeekBar(this)
            sb.max = 19
            sb.progress = ((c.photoMs / 500L).toInt() - 1).coerceIn(0, 19)
            fun sec(v: Int) = String.format(Locale.US, "%.1f detik", (v + 1) * 0.5)
            tv.text = sec(sb.progress)
            sb.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, v: Int, fromUser: Boolean) {
                    tv.text = sec(v)
                }

                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {}
            })
            p.addView(tv)
            p.addView(sb, LinearLayout.LayoutParams(-1, -2).apply { setMargins(dp(12), dp(8), dp(12), dp(8)) })
            p.addView(
                Sheet.buttonRow(
                    this,
                    Sheet.button(this, "Batal", false) { close() },
                    Sheet.button(this, "Terapkan", true) {
                        val ms = (sb.progress + 1) * 500L
                        close()
                        if (ms != c.photoMs) {
                            pushHistory()
                            c.photoMs = ms
                            rebuild(playhead)
                        }
                    }
                )
            )
        }
    }

    private fun pickSong() {
        lifecycleScope.launch {
            val list = withContext(Dispatchers.IO) { Library.audios(this@VideoEditActivity) }
            if (list.isEmpty()) {
                toast("Belum ada lagu di HP (atau izin musik belum diberikan).")
                return@launch
            }
            Sheet.pickList(
                this@VideoEditActivity, "Pilih lagu",
                list.map { it.title }, list.map { it.artist }, R.drawable.ic_music_note
            ) { i -> setSong(list[i]) }
        }
    }

    private fun setSong(t: Library.Track) {
        pushHistory()
        audioPlayer?.release()
        song = t.uri
        songName = t.title
        songDur = t.durationMs
        val tot = total()
        val start = if (tot - playhead < 1000L) 0L else playhead
        val len = minOf(t.durationMs, (tot - start).coerceAtLeast(300L))
        segs = arrayListOf(Seg(start, 0L, len))
        selA = 0
        sel = -1
        curSeg = -1
        val a = ExoPlayer.Builder(this).build()
        a.setMediaItem(MediaItem.fromUri(t.uri))
        a.volume = songVol
        a.prepare()
        audioPlayer = a
        pushTimeline()
    }

    private fun clearSong() {
        audioPlayer?.release()
        audioPlayer = null
        song = null
        songName = ""
        segs.clear()
        selA = -1
        curSeg = -1
    }

    private fun selectAudio(i: Int) {
        selA = i
        if (i >= 0) sel = -1
        timeline.selA = selA
        timeline.selV = sel
        syncSmooth()
    }

    private fun snapFade(ms: Long) = if (ms < 150L) 0L else ms

    /** Simpan riwayat Urungkan tepat sebelum perubahan pertama dalam satu tarikan. */
    private fun commitPending() {
        if (pendingHistory) {
            pendingHistory = false
            pushHistory()
        }
    }

    private fun videoFade(i: Int, isIn: Boolean, ms: Long) {
        val c = clips.getOrNull(i) ?: return
        commitPending()
        if (isIn) c.fadeIn = snapFade(ms).coerceIn(0L, c.dur() - c.fadeOut)
        else c.fadeOut = snapFade(ms).coerceIn(0L, c.dur() - c.fadeIn)
        pushTimeline()
    }

    private fun clampTo(v: Long, lo: Long, hi: Long) = if (hi < lo) lo else v.coerceIn(lo, hi)

    /** Ubah satu potongan lagu dari tarikan di timeline. Potongan tidak boleh saling menimpa. */
    private fun audioEdit(i: Int, mode: Int, ms: Long) {
        val s = segs.getOrNull(i) ?: return
        commitPending()
        val tot = total()
        val prevEnd = if (i > 0) segs[i - 1].end() else 0L
        val nextStart = if (i < segs.lastIndex) segs[i + 1].start else tot
        when (mode) {
            TimelineView.MODE_L -> {
                val minStart = maxOf(prevEnd, s.start - s.from)
                val ns = clampTo(ms, minStart, s.end() - 300L)
                val d = ns - s.start
                s.start = ns
                s.from += d
                s.clampFades()
            }
            TimelineView.MODE_R -> {
                val maxEnd = minOf(nextStart, s.start + (songDur - s.from))
                val ne = clampTo(ms, s.start + 300L, maxEnd)
                s.to = s.from + (ne - s.start)
                s.clampFades()
            }
            TimelineView.MODE_MOVE -> {
                val len = s.len()
                s.start = clampTo(ms, prevEnd, nextStart - len)
            }
            TimelineView.MODE_FIN -> s.fadeIn = snapFade(ms).coerceIn(0L, s.len() - s.fadeOut)
            TimelineView.MODE_FOUT -> s.fadeOut = snapFade(ms).coerceIn(0L, s.len() - s.fadeIn)
        }
        pushTimeline()
    }

    private fun volumeDialog() {
        Sheet.custom(this, "Suara") { p, close ->
            fun slider(name: String, start: Float, enabled: Boolean): SeekBar {
                val t = TextView(this)
                t.text = name
                t.textSize = 12f
                t.setTextColor(clr(R.color.muted))
                t.setPadding(dp(14), dp(6), dp(14), 0)
                p.addView(t)
                val sb = SeekBar(this)
                sb.max = 100
                sb.progress = (start * 100).toInt()
                sb.isEnabled = enabled
                p.addView(sb, LinearLayout.LayoutParams(-1, -2).apply { setMargins(dp(12), dp(4), dp(12), dp(8)) })
                return sb
            }
            val a = slider("Suara video asli", origVol, true)
            val b = slider(if (song == null) "Lagu (belum ada lagu)" else "Lagu", songVol, song != null)
            p.addView(
                Sheet.buttonRow(
                    this,
                    Sheet.button(this, "Batal", false) { close() },
                    Sheet.button(this, "Terapkan", true) {
                        origVol = a.progress / 100f
                        songVol = b.progress / 100f
                        player.volume = origVol
                        audioPlayer?.volume = songVol
                        close()
                    }
                )
            )
        }
    }

    // ------------------------------------------------------------------ simpan

    private fun askLeave() {
        if (exporting) return
        if (history.isEmpty() && song == null) {
            finish()
            return
        }
        Sheet.confirm(this, "Keluar dari editor?", "Perubahan yang belum disimpan akan hilang.", "Keluar", true) {
            finish()
        }
    }

    private fun askSave() {
        if (clips.isEmpty() || exporting) return
        player.pause()
        Sheet.choice(
            this, "Simpan hasil edit", "Resolusi dan bitrate mengikuti video asli.",
            listOf(
                "Simpan sebagai video baru" to "Video asli tetap ada",
                "Timpa video asli" to "Video asli diganti"
            ),
            0
        ) { i ->
            if (i == 0) {
                export(false)
            } else {
                Sheet.confirm(
                    this, "Timpa video asli?",
                    "Video asli akan diganti hasil edit dan tidak bisa dikembalikan.", "Timpa", true
                ) { export(true) }
            }
        }
    }

    private fun volumeProcessor(v: Float): AudioProcessor {
        val p = ChannelMixingAudioProcessor()
        p.putChannelMixingMatrix(ChannelMixingMatrix.create(1, 1).scaleBy(v))
        p.putChannelMixingMatrix(ChannelMixingMatrix.create(2, 2).scaleBy(v))
        return p
    }

    private fun buildComposition(total: Long): Composition {
        val vItems = ArrayList<EditedMediaItem>()
        for (c in clips) {
            if (c.photo) {
                val pve = ArrayList<Effect>()
                if (c.fadeIn > 0L || c.fadeOut > 0L) pve.add(FadeMatrix(c.dur(), c.fadeIn, c.fadeOut, c.smooth))
                vItems.add(
                    EditedMediaItem.Builder(MediaItem.fromUri(c.uri))
                        .setDurationUs(c.photoMs * 1000L)
                        .setFrameRate(30)
                        .setEffects(Effects(emptyList(), pve))
                        .build()
                )
            } else {
                val cc = MediaItem.ClippingConfiguration.Builder()
                    .setStartPositionMs(c.start)
                    .setEndPositionMs(c.end)
                    .build()
                val mi = MediaItem.Builder().setUri(c.uri).setClippingConfiguration(cc).build()
                val ap = ArrayList<AudioProcessor>()
                val ve = ArrayList<Effect>()
                if (c.speed != 1f) {
                    ve.add(SpeedChangeEffect(c.speed))
                    val sonic = SonicAudioProcessor()
                    sonic.setSpeed(c.speed)
                    sonic.setPitch(1f)
                    ap.add(sonic)
                }
                if (origVol != 1f) ap.add(volumeProcessor(origVol))
                if (c.fadeIn > 0L || c.fadeOut > 0L) ve.add(FadeMatrix(c.dur(), c.fadeIn, c.fadeOut, c.smooth))
                vItems.add(EditedMediaItem.Builder(mi).setEffects(Effects(ap, ve)).build())
            }
        }
        val seqs = ArrayList<EditedMediaItemSequence>()
        seqs.add(EditedMediaItemSequence.Builder(vItems).build())
        val sUri = song
        if (sUri != null) {
            val sb = EditedMediaItemSequence.Builder()
            var cursor = 0L
            var added = 0
            for (sg in segs.sortedBy { it.start }) {
                val len = minOf(sg.len(), total - sg.start)
                if (len < 100L || sg.start < cursor) continue
                val fi = minOf(sg.fadeIn, len)
                val fo = minOf(sg.fadeOut, len - fi)
                val cc = MediaItem.ClippingConfiguration.Builder()
                    .setStartPositionMs(sg.from)
                    .setEndPositionMs(sg.from + len)
                    .build()
                val mi = MediaItem.Builder().setUri(sUri).setClippingConfiguration(cc).build()
                val procs = ArrayList<AudioProcessor>()
                procs.add(volumeProcessor(songVol))
                if (fi > 0L || fo > 0L) procs.add(FadeVolume(len, fi, fo, sg.smooth))
                val ei = EditedMediaItem.Builder(mi)
                    .setRemoveVideo(true)
                    .setEffects(Effects(procs, emptyList()))
                    .build()
                if (sg.start > cursor) sb.addGap((sg.start - cursor) * 1000L)
                sb.addItem(ei)
                cursor = sg.start + len
                added++
            }
            if (added > 0) seqs.add(sb.build())
        }
        val cb = Composition.Builder(seqs)
        val hasPhoto = clips.any { it.photo }
        if (hasPhoto) cb.experimentalSetForceAudioTrack(true)
        val vids = clips.filter { !it.photo && it.w > 0 && it.h > 0 }
        val sizes = vids.map { it.w to it.h }.distinct()
        if (hasPhoto || sizes.size > 1) {
            var w = if (vids.isNotEmpty()) vids[0].w else 1080
            var h = if (vids.isNotEmpty()) vids[0].h else 1920
            w -= w % 2
            h -= h % 2
            cb.setEffects(
                Effects(
                    emptyList(),
                    listOf<Effect>(Presentation.createForWidthAndHeight(w, h, Presentation.LAYOUT_SCALE_TO_FIT))
                )
            )
        }
        return cb.build()
    }

    private fun export(overwrite: Boolean) {
        val total = total()
        val comp = try {
            buildComposition(total)
        } catch (e: Exception) {
            toast("Gagal menyiapkan video: ${e.message}")
            return
        }
        val out = File(cacheDir, "edit_" + System.currentTimeMillis() + ".mp4")
        outFile = out
        exporting = true

        val br = clips.filter { !it.photo }.maxOfOrNull { it.bitrate } ?: 0
        val encBuilder = DefaultEncoderFactory.Builder(this)
        if (br > 0) {
            encBuilder.setRequestedVideoEncoderSettings(
                VideoEncoderSettings.Builder().setBitrate(br.coerceIn(2_000_000, 80_000_000)).build()
            )
        }

        val t = Transformer.Builder(this)
            .setEncoderFactory(encBuilder.build())
            .addListener(object : Transformer.Listener {
                override fun onCompleted(composition: Composition, exportResult: ExportResult) {
                    onExportDone(out, overwrite)
                }

                override fun onError(
                    composition: Composition, exportResult: ExportResult, exportException: ExportException
                ) {
                    onExportFailed(out, exportException.message ?: "kesalahan tidak diketahui")
                }
            })
            .build()
        transformer = t

        progressDlg = Sheet.custom(this, "Menyimpan video\u2026") { p, close ->
            val pb = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal)
            pb.max = 100
            pb.progressTintList = ColorStateList.valueOf(Color.WHITE)
            progressBar = pb
            val pct = TextView(this)
            pct.text = "0%"
            pct.textSize = 13f
            pct.gravity = Gravity.CENTER
            pct.setTextColor(clr(R.color.text_soft))
            tvPct = pct
            p.addView(pb, LinearLayout.LayoutParams(-1, -2).apply { setMargins(dp(14), dp(8), dp(14), dp(4)) })
            p.addView(pct)
            p.addView(
                Sheet.buttonRow(
                    this,
                    Sheet.button(this, "Batal", false) {
                        t.cancel()
                        close()
                        stopProgress()
                        out.delete()
                        exporting = false
                    }
                )
            )
        }
        progressDlg?.setCancelable(false)

        try {
            t.start(comp, out.absolutePath)
            handler.post(progressTick)
        } catch (e: Exception) {
            onExportFailed(out, e.message ?: "gagal memulai")
        }
    }

    private val progressTick = object : Runnable {
        override fun run() {
            val t = transformer ?: return
            val h = ProgressHolder()
            if (t.getProgress(h) == Transformer.PROGRESS_STATE_AVAILABLE) {
                progressBar?.progress = h.progress
                tvPct?.text = "${h.progress}%"
            }
            handler.postDelayed(this, 300)
        }
    }

    private fun stopProgress() {
        handler.removeCallbacks(progressTick)
        transformer = null
        progressDlg?.dismiss()
        progressDlg = null
    }

    private fun onExportFailed(out: File, msg: String) {
        stopProgress()
        out.delete()
        exporting = false
        toast("Gagal menyimpan: $msg")
    }

    private fun onExportDone(out: File, overwrite: Boolean) {
        stopProgress()
        if (overwrite) {
            overwriteOriginal(out)
        } else {
            lifecycleScope.launch {
                val ok = withContext(Dispatchers.IO) { saveAsNew(out) }
                out.delete()
                exporting = false
                if (ok) {
                    toast("Video baru disimpan.")
                    finish()
                } else {
                    toast("Gagal menyimpan ke galeri.")
                }
            }
        }
    }

    private fun saveAsNew(out: File): Boolean {
        val base = origName.substringBeforeLast('.')
        val name = base + "_edit.mp4"
        val allowed = listOf("DCIM/", "Movies/", "Pictures/")
        val rel = if (origRel.isNotEmpty() && allowed.any { origRel.startsWith(it) }) origRel else "Movies/BunnyTL/"
        fun insert(path: String?): Uri? {
            val v = ContentValues()
            v.put(MediaStore.Video.Media.DISPLAY_NAME, name)
            v.put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
            if (Build.VERSION.SDK_INT >= 29 && path != null) {
                v.put(MediaStore.Video.Media.RELATIVE_PATH, path)
                v.put(MediaStore.Video.Media.IS_PENDING, 1)
            }
            return contentResolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, v)
        }
        return try {
            val uri = try {
                insert(rel)
            } catch (e: Exception) {
                insert("Movies/BunnyTL/")
            } ?: return false
            contentResolver.openOutputStream(uri, "w")?.use { o -> out.inputStream().use { it.copyTo(o) } }
            if (Build.VERSION.SDK_INT >= 29) {
                val v = ContentValues()
                v.put(MediaStore.Video.Media.IS_PENDING, 0)
                contentResolver.update(uri, v, null, null)
            }
            true
        } catch (e: Exception) {
            false
        }
    }

    private fun overwriteOriginal(out: File) {
        fun copy() {
            lifecycleScope.launch {
                val ok = withContext(Dispatchers.IO) {
                    try {
                        contentResolver.openOutputStream(origUri, "wt")?.use { o ->
                            out.inputStream().use { it.copyTo(o) }
                        }
                        true
                    } catch (e: Exception) {
                        false
                    }
                }
                out.delete()
                exporting = false
                if (ok) {
                    toast("Video asli diganti.")
                    finish()
                } else {
                    toast("Gagal menimpa video asli.")
                }
            }
        }
        if (Build.VERSION.SDK_INT >= 30) {
            try {
                val pi = MediaStore.createWriteRequest(contentResolver, listOf(origUri))
                pendingWrite = { copy() }
                writeLauncher.launch(IntentSenderRequest.Builder(pi.intentSender).build())
            } catch (e: Exception) {
                exporting = false
                toast("Gagal: ${e.message}")
            }
        } else {
            copy()
        }
    }

    // ------------------------------------------------------------------ siklus hidup

    override fun onPause() {
        super.onPause()
        if (::player.isInitialized) player.pause()
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        transformer?.cancel()
        if (::player.isInitialized) player.release()
        audioPlayer?.release()
        super.onDestroy()
    }

    // ------------------------------------------------------------------ efek pudar

    /** Pudar gambar: warna dikalikan pengali kurva (menggelap ke hitam). Waktu = waktu hasil akhir klip. */
    private class FadeMatrix(
        private val durMs: Long,
        private val fiMs: Long,
        private val foMs: Long,
        private val smooth: Float
    ) : RgbMatrix {
        override fun getMatrix(presentationTimeUs: Long, useHdr: Boolean): FloatArray {
            val g = TimelineView.fadeGain(presentationTimeUs / 1000L, durMs, fiMs, foMs, smooth)
            return floatArrayOf(
                g, 0f, 0f, 0f,
                0f, g, 0f, 0f,
                0f, 0f, g, 0f,
                0f, 0f, 0f, 1f
            )
        }
    }

    /** Pudar suara lagu: volume mengikuti kurva yang sama dengan di timeline (audio PCM 16-bit). */
    private class FadeVolume(
        private val lenMs: Long,
        private val fiMs: Long,
        private val foMs: Long,
        private val smooth: Float
    ) : BaseAudioProcessor() {
        private var frames = 0L

        override fun onConfigure(inputAudioFormat: AudioProcessor.AudioFormat): AudioProcessor.AudioFormat {
            if (inputAudioFormat.encoding != C.ENCODING_PCM_16BIT) {
                throw AudioProcessor.UnhandledAudioFormatException(inputAudioFormat)
            }
            return inputAudioFormat
        }

        override fun queueInput(inputBuffer: ByteBuffer) {
            val ch = inputAudioFormat.channelCount
            val rate = inputAudioFormat.sampleRate
            val n = inputBuffer.remaining() / (2 * ch)
            val out = replaceOutputBuffer(n * 2 * ch)
            for (f in 0 until n) {
                val ms = frames * 1000L / rate
                val g = TimelineView.fadeGain(ms, lenMs, fiMs, foMs, smooth)
                for (k in 0 until ch) {
                    val v = (inputBuffer.short * g).toInt().coerceIn(-32768, 32767)
                    out.putShort(v.toShort())
                }
                frames++
            }
            out.flip()
        }
    }
}
