package com.niven.mangatl

import android.net.Uri
import android.view.View
import androidx.media3.exoplayer.ExoPlayer

// Model data editor video: klip utama (Clip), potongan lagu (Seg), lapisan overlay (Ov), dasar pudar (Fadable), dan riwayat undo (Snap).

/** Dasar untuk semua yang bisa dipudarkan: panjang pudar (ms) dan titik lekuk di kurva (0..1 dari tepi klip). */
internal open class Fadable {
    var fadeIn = 0L
    var fadeOut = 0L
    var inX = 0.5f
    var inY = 0.5f
    var outX = 0.5f
    var outY = 0.5f

    open fun length(): Long = 0L

    fun fade() = TimelineView.Fade(fadeIn, fadeOut, inX, inY, outX, outY)

    /** Pudar tidak boleh lebih panjang dari klipnya. */
    fun clampFades() {
        val d = length()
        fadeIn = fadeIn.coerceIn(0L, d)
        fadeOut = fadeOut.coerceIn(0L, d - fadeIn)
    }

    fun copyFadeTo(o: Fadable) {
        o.fadeIn = fadeIn
        o.fadeOut = fadeOut
        o.inX = inX
        o.inY = inY
        o.outX = outX
        o.outY = outY
    }
}

internal class Clip(
    val uri: Uri,
    val photo: Boolean,
    val srcDur: Long,
    var start: Long,
    var end: Long,
    var speed: Float,
    val w: Int,
    val h: Int,
    val bitrate: Int,
    var photoMs: Long = 3000L
) : Fadable() {
    /** false = Pas layar (ada bar hitam), true = Penuh (mengisi kanvas, tepi terpotong). */
    var fill = false

    fun dur(): Long =
        if (photo) photoMs else (((end - start) / speed).toLong()).coerceAtLeast(1L)

    override fun length(): Long = dur()

    fun copy(): Clip {
        val c = Clip(uri, photo, srcDur, start, end, speed, w, h, bitrate, photoMs)
        c.fill = fill
        copyFadeTo(c)
        return c
    }
}

/** Satu potongan lagu di timeline: mulai di detik video ke [start], memakai bagian lagu [from]..[to]. */
internal class Seg(
    var start: Long,
    var from: Long,
    var to: Long
) : Fadable() {
    fun len(): Long = to - from
    fun end(): Long = start + len()
    override fun length(): Long = len()

    fun copy(): Seg {
        val c = Seg(start, from, to)
        copyFadeTo(c)
        return c
    }
}

/**
 * Satu lapisan video/foto di atas video utama. Satu lapisan = satu baris di timeline.
 * Posisi di layar: (cx,cy) = titik tengah (0..1 dari frame), wf = lebar (1 = selebar frame).
 */
internal class Ov(
    val uri: Uri,
    val photo: Boolean,
    val srcDur: Long,
    var srcStart: Long,
    var srcEnd: Long,
    var speed: Float,
    val w: Int,
    val h: Int,
    var photoMs: Long,
    var start: Long
) : Fadable() {
    var cx = 0.5f
    var cy = 0.5f
    var wf = 1f

    // hanya untuk pratinjau, tidak ikut disalin ke riwayat
    var view: View? = null
    var player: ExoPlayer? = null
    var running = false

    fun dur(): Long =
        if (photo) photoMs else (((srcEnd - srcStart) / speed).toLong()).coerceAtLeast(1L)

    override fun length(): Long = dur()

    fun aspect(): Float = if (w > 0 && h > 0) w.toFloat() / h else 16f / 9f

    fun copy(): Ov {
        val o = Ov(uri, photo, srcDur, srcStart, srcEnd, speed, w, h, photoMs, start)
        o.cx = cx
        o.cy = cy
        o.wf = wf
        copyFadeTo(o)
        return o
    }
}

internal class Snap(val clips: List<Clip>, val segs: List<Seg>, val ovs: List<Ov>)
