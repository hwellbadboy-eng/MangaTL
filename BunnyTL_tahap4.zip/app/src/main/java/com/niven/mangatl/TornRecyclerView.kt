package com.niven.mangatl

import android.content.Context
import android.graphics.Canvas
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PorterDuff
import android.graphics.PorterDuffXfermode
import android.graphics.Shader
import android.util.AttributeSet
import androidx.recyclerview.widget.RecyclerView

/**
 * Daftar chat yang bagian atasnya dipotong mengikuti zig-zag sobekan kertas,
 * jadi bubble terlihat masuk ke bawah robekan. Posisi atas daftar = atas gambar sobekan.
 */
class TornRecyclerView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : RecyclerView(context, attrs) {

    private var prof: TearProfile? = null
    private var tearPx = 0f
    private var tearOn = true
    private val clip = Path()
    private var clipReady = false

    // Pudar di tepi atas: bubble yang naik makin transparan dan hilang tepat di tepi atas daftar.
    private var fadeTop = 0f
    private val fadePaint = Paint().apply { xfermode = PorterDuffXfermode(PorterDuff.Mode.DST_IN) }

    fun setFadeTop(px: Float) {
        if (px == fadeTop) return
        fadeTop = px
        fadePaint.shader = if (px > 0f) LinearGradient(0f, 0f, 0f, px, 0x00000000, 0xFF000000.toInt(), Shader.TileMode.CLAMP) else null
        invalidate()
    }

    fun setTear(p: TearProfile, heightPx: Float) {
        prof = p
        tearPx = heightPx
        rebuild()
        invalidate()
    }

    fun setTearEnabled(on: Boolean) {
        if (tearOn != on) {
            tearOn = on
            invalidate()
        }
    }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        rebuild()
    }

    private fun rebuild() {
        clipReady = false
        val p = prof ?: return
        if (width <= 0 || height <= 0 || tearPx <= 0f) return
        val sy = tearPx / TearProfile.IMG_H
        val n = p.n
        clip.reset()
        clip.moveTo(0f, p.cut[0] * sy)
        for (i in 1 until n) clip.lineTo(width * i / (n - 1f), p.cut[i] * sy)
        clip.lineTo(width.toFloat(), height.toFloat())
        clip.lineTo(0f, height.toFloat())
        clip.close()
        clipReady = true
    }

    override fun dispatchDraw(canvas: Canvas) {
        val fade = fadeTop > 0f && width > 0 && height > 0
        val layer = if (fade) canvas.saveLayer(0f, 0f, width.toFloat(), height.toFloat(), null) else -1
        if (tearOn && clipReady) {
            val save = canvas.save()
            canvas.clipPath(clip)
            super.dispatchDraw(canvas)
            canvas.restoreToCount(save)
        } else {
            super.dispatchDraw(canvas)
        }
        if (fade) {
            canvas.drawRect(0f, 0f, width.toFloat(), fadeTop, fadePaint)
            canvas.restoreToCount(layer)
        }
    }
}
