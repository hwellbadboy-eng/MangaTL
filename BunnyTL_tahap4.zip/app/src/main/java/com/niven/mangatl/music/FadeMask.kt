package com.niven.mangatl

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.PorterDuff
import android.graphics.PorterDuffXfermode
import android.graphics.Shader
import android.util.AttributeSet
import android.widget.FrameLayout

/**
 * FrameLayout yang memudarkan isinya secara vertikal (setara CSS mask-image: linear-gradient(to bottom, ...)).
 * setStops: pos = titik 0..1 (naik), alphas = 0..255 di tiap titik.
 */
class FadeMask @JvmOverloads constructor(ctx: Context, attrs: AttributeSet? = null) : FrameLayout(ctx, attrs) {
    private val paint = Paint().apply { xfermode = PorterDuffXfermode(PorterDuff.Mode.DST_IN) }
    private var pos = floatArrayOf(0f, 1f)
    private var alphas = intArrayOf(255, 255)

    fun setStops(pos: FloatArray, alphas: IntArray) {
        this.pos = pos
        this.alphas = alphas
        rebuild()
        invalidate()
    }

    private fun rebuild() {
        if (height <= 0) return
        paint.shader = LinearGradient(
            0f, 0f, 0f, height.toFloat(),
            IntArray(alphas.size) { Color.argb(alphas[it], 0, 0, 0) }, pos, Shader.TileMode.CLAMP
        )
    }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        rebuild()
    }

    override fun dispatchDraw(canvas: Canvas) {
        val save = canvas.saveLayer(0f, 0f, width.toFloat(), height.toFloat(), null)
        super.dispatchDraw(canvas)
        canvas.drawRect(0f, 0f, width.toFloat(), height.toFloat(), paint)
        canvas.restoreToCount(save)
    }
}
