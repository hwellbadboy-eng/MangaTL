package com.niven.mangatl

import android.content.ComponentName
import android.content.ContentUris
import android.graphics.Color
import android.graphics.PorterDuff
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.provider.MediaStore
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.animation.OvershootInterpolator
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import androidx.media3.common.Player
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.bottomsheet.BottomSheetDialog
import com.google.common.util.concurrent.ListenableFuture
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/**
 * "Sedang diputar" sesuai desain Pemutar Musik + Audio Engine: cover penuh, badge Hi-Res,
 * seek, kontrol, lima tab efek (Bass, 3D, Vokal, Reverb, Efek) dengan popup parameter cepat.
 * Acak, ulang, suka, lirik, timer tidur, kecepatan, dan antrean ada di menu "Lainnya".
 */
class NowPlayingActivity : AppCompatActivity() {

    private lateinit var npRoot: FrameLayout
    private lateinit var ivArt: ImageView
    private lateinit var tvTitle: TextView
    private lateinit var tvArtist: TextView
    private lateinit var tvTimeCur: TextView
    private lateinit var tvTimeTot: TextView
    private lateinit var tvHiBadge: TextView
    private lateinit var tvHiState: TextView
    private lateinit var sbSeek: SeekBar
    private lateinit var btnPlay: ImageButton
    private lateinit var btnFav: ImageButton
    private lateinit var tabs: LinearLayout
    private lateinit var visHost: FrameLayout
    private lateinit var popLayer: FrameLayout
    private lateinit var topBox: View
    private lateinit var bottomBox: View
    private var vis: VisualizerView? = null

    // lirik (tampil di bottom sheet)
    private lateinit var lyricFrame: FrameLayout
    private lateinit var rvLyrics: RecyclerView
    private lateinit var tvLyricsEmpty: TextView
    private var lyricsOpen = false

    private var future: ListenableFuture<MediaController>? = null
    private var controller: MediaController? = null
    private val handler = Handler(Looper.getMainLooper())
    private var dragging = false
    private var lastId: Long? = null
    private var track: Library.Track? = null
    private var lyrics: Lyrics.Result? = null
    private var curLine = -1
    private val speeds = floatArrayOf(0.75f, 1f, 1.25f, 1.5f, 2f)

    private class Tab(val fid: String?, val label: String, val box: FrameLayout, val l1: TextView, val l2: TextView, val dot: View)

    private val tabList = ArrayList<Tab>()
    private var popFid: String? = null
    private val popRows = ArrayList<ParamRow>()

    private val tick = object : Runnable {
        override fun run() {
            updateProgress()
            for (r in popRows) r.tick()
            handler.postDelayed(this, 400)
        }
    }

    private val pickLyricFile = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        val t = track
        if (uri != null && t != null) {
            try {
                val text = contentResolver.openInputStream(uri)?.use { it.readBytes().toString(Charsets.UTF_8) } ?: ""
                if (Lyrics.parse(text, "") == null) {
                    Toast.makeText(this, "File kosong.", Toast.LENGTH_SHORT).show()
                } else {
                    Lyrics.save(this, t.id, text)
                    applyLyrics(Lyrics.parse(text, "Tersimpan"))
                }
            } catch (e: Exception) {
                Toast.makeText(this, "Gagal membaca file.", Toast.LENGTH_SHORT).show()
            }
        }
    }

    // ---- adapter lirik ----
    private val lyricAdapter = object : RecyclerView.Adapter<RecyclerView.ViewHolder>() {
        override fun getItemCount() = lyrics?.lines?.size ?: 0

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
            val tv = TextView(parent.context)
            tv.layoutParams = ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            tv.gravity = Gravity.CENTER
            tv.setTextColor(Color.WHITE)
            tv.setPadding(Ui.dp(this@NowPlayingActivity, 12), Ui.dp(this@NowPlayingActivity, 8),
                Ui.dp(this@NowPlayingActivity, 12), Ui.dp(this@NowPlayingActivity, 8))
            return object : RecyclerView.ViewHolder(tv) {}
        }

        override fun onBindViewHolder(h: RecyclerView.ViewHolder, pos: Int) {
            val r = lyrics ?: return
            val l = r.lines[pos]
            val tv = h.itemView as TextView
            tv.text = l.text.ifEmpty { "…" }
            val cur = r.synced && pos == curLine
            tv.alpha = if (!r.synced || cur) 1f else 0.45f
            tv.textSize = if (cur) 20f else 17f
            tv.setTypeface(null, if (cur) android.graphics.Typeface.BOLD else android.graphics.Typeface.NORMAL)
            tv.setOnClickListener {
                if (r.synced && l.timeMs >= 0) controller?.seekTo(l.timeMs)
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        AudioEngine.init(this)
        OutputCaps.init(this)
        setContentView(R.layout.activity_nowplaying)
        npRoot = findViewById(R.id.npRoot)
        ivArt = findViewById(R.id.ivArt)
        tvTitle = findViewById(R.id.tvTitle)
        tvArtist = findViewById(R.id.tvArtist)
        tvTimeCur = findViewById(R.id.tvTimeCur)
        tvTimeTot = findViewById(R.id.tvTimeTot)
        tvHiBadge = findViewById(R.id.tvHiBadge)
        tvHiState = findViewById(R.id.tvHiState)
        sbSeek = findViewById(R.id.sbSeek)
        btnPlay = findViewById(R.id.btnPlay)
        btnFav = findViewById(R.id.btnFav)
        tabs = findViewById(R.id.tabs)
        visHost = findViewById(R.id.visHost)
        popLayer = findViewById(R.id.popLayer)
        topBox = findViewById(R.id.topBox)
        bottomBox = findViewById(R.id.bottomBox)

        val baseTop = (topBox.layoutParams as ViewGroup.MarginLayoutParams).topMargin
        npRoot.setOnApplyWindowInsetsListener { _, ins ->
            (topBox.layoutParams as ViewGroup.MarginLayoutParams).topMargin = baseTop + ins.systemWindowInsetTop
            topBox.requestLayout()
            bottomBox.setPadding(bottomBox.paddingLeft, 0, bottomBox.paddingRight, ins.systemWindowInsetBottom + Ui.dp(this, 8))
            ins
        }

        // placeholder cover (gradasi radial seperti desain) kalau lagu tidak punya gambar
        ivArt.background = GradientDrawable().apply {
            gradientType = GradientDrawable.RADIAL_GRADIENT
            gradientRadius = Ui.dp(this@NowPlayingActivity, 460).toFloat()
            setGradientCenter(0.5f, 0.3f)
            colors = intArrayOf(0xFFE2E2E8.toInt(), 0xFF8A8A92.toInt(), 0xFF0B0B0D.toInt())
        }

        buildLyricViews()
        buildTabs()

        findViewById<View>(R.id.hiresBtn).setOnClickListener { togglePop(AudioEngine.HIRES, it.x + it.width / 2f) }
        btnPlay.setOnClickListener { controller?.let { if (it.isPlaying) it.pause() else it.play() } }
        findViewById<View>(R.id.btnPrev).setOnClickListener { controller?.seekToPreviousMediaItem() }
        findViewById<View>(R.id.btnNext).setOnClickListener { controller?.seekToNextMediaItem() }
        btnFav.setOnClickListener { toggleFav() }
        findViewById<View>(R.id.btnMore).setOnClickListener { showMore() }
        popLayer.setOnClickListener { hidePop() }

        sbSeek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar?, p: Int, fromUser: Boolean) {
                if (fromUser) tvTimeCur.text = Library.fmt(p.toLong())
            }

            override fun onStartTrackingTouch(sb: SeekBar?) {
                dragging = true
            }

            override fun onStopTrackingTouch(sb: SeekBar?) {
                dragging = false
                controller?.seekTo((sb?.progress ?: 0).toLong())
            }
        })

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (popLayer.visibility == View.VISIBLE) hidePop() else finish()
            }
        })
    }

    override fun onStart() {
        super.onStart()
        val token = SessionToken(this, ComponentName(this, PlayerService::class.java))
        val f = MediaController.Builder(this, token).buildAsync()
        future = f
        f.addListener({
            try {
                val c = f.get()
                controller = c
                c.addListener(object : Player.Listener {
                    override fun onEvents(player: Player, events: Player.Events) = updateUi()
                })
                updateUi()
                handler.post(tick)
            } catch (e: Exception) {
                Toast.makeText(this, "Pemutar gagal tersambung", Toast.LENGTH_LONG).show()
            }
        }, ContextCompat.getMainExecutor(this))
    }

    override fun onResume() {
        super.onResume()
        refreshAll()
    }

    override fun onStop() {
        handler.removeCallbacks(tick)
        future?.let { MediaController.releaseFuture(it) }
        future = null
        controller = null
        super.onStop()
    }

    // ---------- tab efek + popup ----------

    private fun buildTabs() {
        val defs = listOf(
            Pair("BASS", AudioEngine.BASS), Pair("3D", AudioEngine.SPATIAL), Pair("VOKAL", AudioEngine.VOCAL),
            Pair("REVERB", AudioEngine.REVERB), Pair("EFEK", null as String?)
        )
        for ((label, fid) in defs) {
            val box = FrameLayout(this)
            val col = LinearLayout(this)
            col.orientation = LinearLayout.VERTICAL
            col.gravity = Gravity.CENTER
            val l1 = TextView(this)
            l1.text = label
            l1.textSize = 13f
            l1.letterSpacing = 0.14f
            l1.gravity = Gravity.CENTER
            val l2 = TextView(this)
            l2.textSize = 11f
            l2.gravity = Gravity.CENTER
            col.addView(l1)
            col.addView(l2)
            box.addView(col, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
            val dot = View(this)
            dot.background = AU.shape(Color.WHITE, 2f, this)
            val dl = FrameLayout.LayoutParams(Ui.dp(this, 4), Ui.dp(this, 4), Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL)
            dl.bottomMargin = Ui.dp(this, 4)
            box.addView(dot, dl)
            val t = Tab(fid, label, box, l1, l2, dot)
            tabList.add(t)
            box.setOnClickListener {
                if (fid == null) startActivity(android.content.Intent(this, AudioEngineActivity::class.java))
                else togglePop(fid, box.x + box.width / 2f)
            }
            tabs.addView(box, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f))
        }
    }

    private fun refreshTabs() {
        val d = resources.displayMetrics.density
        for (t in tabList) {
            val fid = t.fid
            if (fid == null) {
                t.l1.setTextColor(Color.WHITE)
                val n = AudioEngine.features.count { AudioEngine.isOn(it.id) }
                t.l2.text = if (!AudioEngine.master) "mati" else "$n aktif"
                t.l2.setTextColor(Color.WHITE)
                t.l2.alpha = 0.7f
                t.dot.visibility = View.GONE
                continue
            }
            val on = AudioEngine.isOn(fid)
            val f = AudioEngine.feature(fid)
            val qi = f.quick.firstOrNull() ?: 0
            val p = f.params[qi]
            t.l2.text = if (!on) "mati" else {
                val v = AudioEngine.get(fid, qi)
                if (p is PNum) AU.fmt(v) + (if (p.unit.isEmpty()) "" else " " + p.unit) else ""
            }
            t.l1.setTextColor(if (on) Color.WHITE else AU.MUT)
            t.l2.setTextColor(if (on) Color.WHITE else AU.MUT)
            t.l1.animate().translationY(if (on) -7 * d else 0f).setDuration(320).setInterpolator(OvershootInterpolator(1.4f)).start()
            t.l2.animate().translationY(if (on) -5 * d else 0f).alpha(if (on) 0.9f else 0.7f).setDuration(320)
                .setInterpolator(OvershootInterpolator(1.4f)).start()
            t.dot.visibility = if (on) View.VISIBLE else View.GONE
        }
    }

    private fun hiResText(): String {
        if (!AudioEngine.isOn(AudioEngine.HIRES)) return "Hi-Res mati"
        val v = AudioEngine.raw(AudioEngine.HIRES)
        if (v.size > 5 && v[5].toInt() == 1) return "Bit-perfect"
        val rates = arrayOf("", "44,1 kHz", "48 kHz", "88,2 kHz", "96 kHz", "176,4 kHz", "192 kHz")
        val r = v[0].toInt()
        val up = v[6].toInt()
        val rate = when {
            r > 0 -> rates[r]
            up > 0 -> "${1 shl up}× upsampling"
            else -> "laju sumber"
        }
        val bit = if (v[1].toInt() == 0) "bit sumber" else "${intArrayOf(0, 16, 24, 32)[v[1].toInt()]}-bit"
        return "$rate · $bit"
    }

    private fun updateHiState() {
        val on = AudioEngine.isOn(AudioEngine.HIRES)
        if (on) {
            tvHiBadge.background = AU.shape(Color.WHITE, 6f, this)
            tvHiBadge.setTextColor(Color.BLACK)
        } else {
            tvHiBadge.background = AU.shape(0, 6f, this, Color.WHITE, 2)
            tvHiBadge.setTextColor(Color.WHITE)
        }
        tvHiState.text = hiResText()
    }

    private fun refreshAll() {
        refreshTabs()
        updateHiState()
        val showVis = AudioEngine.isOn(AudioEngine.VIS)
        if (showVis && vis == null) {
            val v = VisualizerView(this)
            vis = v
            visHost.addView(v, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        }
        visHost.visibility = if (showVis) View.VISIBLE else View.GONE
        for (r in popRows) r.refresh()
    }

    private fun togglePop(fid: String, anchorX: Float) {
        if (popLayer.visibility == View.VISIBLE && popFid == fid) {
            hidePop()
            return
        }
        showPop(fid, anchorX)
    }

    private fun hidePop() {
        popLayer.visibility = View.GONE
        popLayer.removeAllViews()
        popRows.clear()
        popFid = null
    }

    private fun showPop(fid: String, anchorX: Float) {
        popLayer.removeAllViews()
        popRows.clear()
        popFid = fid
        val f = AudioEngine.feature(fid)
        val w = npRoot.width
        val cardW = minOf(Ui.dp(this, 304), w - Ui.dp(this, 24))
        val maxH = (npRoot.height * 0.42f).toInt()

        val card = LinearLayout(this)
        card.orientation = LinearLayout.VERTICAL
        card.background = AU.shape(0xFF1C1C20.toInt(), 22f, this, 0xFF2E2E34.toInt(), 1)
        card.isClickable = true
        card.elevation = Ui.dp(this, 12).toFloat()

        val head = LinearLayout(this)
        head.orientation = LinearLayout.HORIZONTAL
        head.gravity = Gravity.CENTER_VERTICAL
        head.setPadding(Ui.dp(this, 16), Ui.dp(this, 12), Ui.dp(this, 16), Ui.dp(this, 4))
        head.addView(AU.text(this, f.title, 15f, Color.WHITE, true), LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        val reset = AU.text(this, "Reset", 13f, AU.MUT)
        reset.setPadding(Ui.dp(this, 8), Ui.dp(this, 8), Ui.dp(this, 12), Ui.dp(this, 8))
        reset.setOnClickListener {
            AudioEngine.resetFeature(fid)
            refreshAll()
        }
        head.addView(reset)
        head.addView(AU.switch(this, AudioEngine.featureOn(fid)) { v ->
            AudioEngine.setOn(fid, v)
            refreshAll()
        })
        card.addView(head)

        val sv = ScrollView(this)
        sv.isVerticalScrollBarEnabled = false
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(Ui.dp(this, 16), 0, Ui.dp(this, 2), Ui.dp(this, 8))
        for (qi in f.quick) {
            val r = ParamRow(this, fid, qi, true) { refreshAll() }
            popRows.add(r)
            col.addView(r.view)
        }
        sv.addView(col)
        val rail = RailView(this, sv)
        sv.setOnScrollChangeListener { _, _, _, _, _ -> rail.invalidate() }
        val body = LinearLayout(this)
        body.orientation = LinearLayout.HORIZONTAL
        body.addView(sv, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f))
        val rl = LinearLayout.LayoutParams(Ui.dp(this, 28), ViewGroup.LayoutParams.MATCH_PARENT)
        rl.topMargin = Ui.dp(this, 6)
        rl.bottomMargin = Ui.dp(this, 10)
        body.addView(rail, rl)

        col.measure(
            View.MeasureSpec.makeMeasureSpec(cardW - Ui.dp(this, 28), View.MeasureSpec.EXACTLY),
            View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED)
        )
        head.measure(
            View.MeasureSpec.makeMeasureSpec(cardW, View.MeasureSpec.EXACTLY),
            View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED)
        )
        val bodyH = minOf(col.measuredHeight, maxH - head.measuredHeight).coerceAtLeast(Ui.dp(this, 80))
        card.addView(body, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, bodyH))

        val tl = IntArray(2)
        val rl2 = IntArray(2)
        tabs.getLocationOnScreen(tl)
        npRoot.getLocationOnScreen(rl2)
        val lp = FrameLayout.LayoutParams(cardW, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL)
        lp.bottomMargin = (rl2[1] + npRoot.height) - tl[1] + Ui.dp(this, 6)
        popLayer.addView(card, lp)
        popLayer.visibility = View.VISIBLE
        card.alpha = 0f
        card.scaleX = 0.92f
        card.scaleY = 0.92f
        card.post {
            card.pivotY = card.height.toFloat()
            card.pivotX = (anchorX - card.left).coerceIn(0f, card.width.toFloat())
            card.animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(240)
                .setInterpolator(OvershootInterpolator(1.1f)).start()
        }
    }

    // ---------- menu Lainnya ----------

    private fun showMore() {
        val d = BottomSheetDialog(this)
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.background = GradientDrawable().apply {
            setColor(0xFF1A1A1E.toInt())
            val r = Ui.dp(this@NowPlayingActivity, 24).toFloat()
            cornerRadii = floatArrayOf(r, r, r, r, 0f, 0f, 0f, 0f)
        }
        col.setPadding(Ui.dp(this, 20), Ui.dp(this, 20), Ui.dp(this, 20), Ui.dp(this, 24))
        col.addView(AU.text(this, "Lainnya", 20f, Color.WHITE, true))

        class Item(val icon: Int, val label: String, val value: () -> String, val onClick: () -> Unit)
        val items = listOf(
            Item(R.drawable.ic_shuffle, "Acak", { if (controller?.shuffleModeEnabled == true) "Aktif" else "" }) {
                controller?.let { it.shuffleModeEnabled = !it.shuffleModeEnabled }
                Toast.makeText(this, if (controller?.shuffleModeEnabled == true) "Acak aktif" else "Acak mati", Toast.LENGTH_SHORT).show()
            },
            Item(R.drawable.ic_repeat, "Ulang", {
                when (controller?.repeatMode) {
                    Player.REPEAT_MODE_ALL -> "Semua"
                    Player.REPEAT_MODE_ONE -> "Satu lagu"
                    else -> ""
                }
            }) {
                controller?.let {
                    it.repeatMode = when (it.repeatMode) {
                        Player.REPEAT_MODE_OFF -> Player.REPEAT_MODE_ALL
                        Player.REPEAT_MODE_ALL -> Player.REPEAT_MODE_ONE
                        else -> Player.REPEAT_MODE_OFF
                    }
                }
            },
            Item(R.drawable.ic_fav_border, "Suka", { if (isFavNow()) "Aktif" else "" }) { toggleFav() },
            Item(R.drawable.ic_lyrics, "Lirik", { "" }) {
                d.dismiss()
                lyricsSheet()
            },
            Item(R.drawable.ic_timer, "Timer tidur", {
                val left = (PlayerService.instance?.sleepEndAt ?: 0L) - SystemClock.elapsedRealtime()
                if (left > 0) "${(left / 60000) + 1} menit" else ""
            }) {
                d.dismiss()
                sleepDialog()
            },
            Item(R.drawable.ic_speed, "Kecepatan", {
                val sp = controller?.playbackParameters?.speed ?: 1f
                if (sp == 1f) "1x" else if (sp == sp.toInt().toFloat()) "${sp.toInt()}x" else "${sp}x"
            }) {
                d.dismiss()
                speedDialog()
            },
            Item(R.drawable.ic_queue, "Antrean", { "" }) {
                d.dismiss()
                queueDialog()
            }
        )
        val valueViews = ArrayList<TextView>()
        for (item in items) {
            val row = LinearLayout(this)
            row.orientation = LinearLayout.HORIZONTAL
            row.gravity = Gravity.CENTER_VERTICAL
            row.minimumHeight = Ui.dp(this, 56)
            val ic = ImageView(this)
            ic.setImageResource(item.icon)
            ic.setColorFilter(AU.MUT, PorterDuff.Mode.SRC_IN)
            row.addView(ic, LinearLayout.LayoutParams(Ui.dp(this, 22), Ui.dp(this, 22)))
            val lb = AU.text(this, item.label, 15f, Color.WHITE)
            lb.setPadding(Ui.dp(this, 12), 0, 0, 0)
            row.addView(lb, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
            val vt = AU.text(this, item.value(), 12f, AU.MUT)
            valueViews.add(vt)
            row.addView(vt)
            row.setOnClickListener {
                item.onClick()
                for ((i, v) in valueViews.withIndex()) v.text = items[i].value()
                updateUi()
            }
            col.addView(row)
            val line = View(this)
            line.setBackgroundColor(0xFF1F1F23.toInt())
            col.addView(line, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 1))
        }
        d.setContentView(col)
        d.setOnShowListener {
            d.findViewById<View>(com.google.android.material.R.id.design_bottom_sheet)?.setBackgroundColor(Color.TRANSPARENT)
        }
        d.show()
    }

    private fun isFavNow(): Boolean {
        val id = controller?.currentMediaItem?.mediaId?.toLongOrNull() ?: return false
        return MusicStore.isFav(this, id)
    }

    private fun toggleFav() {
        val id = controller?.currentMediaItem?.mediaId?.toLongOrNull() ?: return
        MusicStore.toggleFav(this, id)
        Toast.makeText(this, if (MusicStore.isFav(this, id)) "Ditambahkan ke Suka" else "Dihapus dari Suka", Toast.LENGTH_SHORT).show()
        updateUi()
    }

    private fun buildLyricViews() {
        lyricFrame = FrameLayout(this)
        rvLyrics = RecyclerView(this)
        rvLyrics.layoutManager = LinearLayoutManager(this)
        rvLyrics.adapter = lyricAdapter
        lyricFrame.addView(rvLyrics, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        tvLyricsEmpty = TextView(this)
        tvLyricsEmpty.gravity = Gravity.CENTER
        tvLyricsEmpty.setPadding(Ui.dp(this, 16), Ui.dp(this, 16), Ui.dp(this, 16), Ui.dp(this, 16))
        tvLyricsEmpty.text = "Memuat lirik..."
        tvLyricsEmpty.setTextColor(AU.MUT)
        lyricFrame.addView(tvLyricsEmpty, FrameLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.CENTER))
    }

    private fun lyricsSheet() {
        val d = BottomSheetDialog(this)
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.background = GradientDrawable().apply {
            setColor(0xFF1A1A1E.toInt())
            val r = Ui.dp(this@NowPlayingActivity, 24).toFloat()
            cornerRadii = floatArrayOf(r, r, r, r, 0f, 0f, 0f, 0f)
        }
        col.setPadding(Ui.dp(this, 12), Ui.dp(this, 16), Ui.dp(this, 12), Ui.dp(this, 12))
        col.addView(AU.text(this, "Lirik", 20f, Color.WHITE, true).apply { setPadding(Ui.dp(this@NowPlayingActivity, 8), 0, 0, Ui.dp(this@NowPlayingActivity, 8)) })
        (lyricFrame.parent as? ViewGroup)?.removeView(lyricFrame)
        col.addView(lyricFrame, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, (npRoot.height * 0.5f).toInt()))
        val bar = LinearLayout(this)
        bar.gravity = Gravity.CENTER
        bar.orientation = LinearLayout.HORIZONTAL
        fun btn(res: Int, desc: String, onClick: () -> Unit) {
            val b = Ui.iconBtn(this, res, desc, onClick)
            b.setColorFilter(0xFFC7C7CC.toInt(), PorterDuff.Mode.SRC_IN)
            bar.addView(b, LinearLayout.LayoutParams(Ui.dp(this, 48), Ui.dp(this, 48)))
        }
        btn(R.drawable.ic_cloud, "Cari lirik online") { fetchOnline(true) }
        btn(R.drawable.ic_file, "Pilih file lirik") { pickLyricFile.launch(arrayOf("*/*")) }
        btn(R.drawable.ic_edit, "Tempel / ubah lirik") { editDialog() }
        col.addView(bar)
        d.setContentView(col)
        d.setOnShowListener {
            d.findViewById<View>(com.google.android.material.R.id.design_bottom_sheet)?.setBackgroundColor(Color.TRANSPARENT)
            lyricsOpen = true
            if (curLine >= 0) (rvLyrics.layoutManager as LinearLayoutManager).scrollToPositionWithOffset(curLine, rvLyrics.height / 3)
        }
        d.setOnDismissListener {
            lyricsOpen = false
            (lyricFrame.parent as? ViewGroup)?.removeView(lyricFrame)
        }
        d.show()
    }

    // ---------- UI ----------

    private fun updateUi() {
        val c = controller ?: return
        tvTitle.text = c.mediaMetadata.title ?: "—"
        tvArtist.text = c.mediaMetadata.artist ?: ""
        btnPlay.setImageResource(if (c.isPlaying) R.drawable.ic_pause else R.drawable.ic_play)
        val id = c.currentMediaItem?.mediaId?.toLongOrNull()
        val fav = id != null && MusicStore.isFav(this, id)
        btnFav.setImageResource(if (fav) R.drawable.ic_fav else R.drawable.ic_fav_border)
        btnFav.setColorFilter(if (fav) Color.WHITE else 0xFFC4C4CA.toInt(), PorterDuff.Mode.SRC_IN)
        if (id != lastId) {
            lastId = id
            val uri = id?.let { ContentUris.withAppendedId(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, it) }
            Thumbs.load(lifecycleScope, ivArt, uri, 1000, false)
            loadTrackLyrics(id)
        }
        updateProgress()
    }

    private fun updateProgress() {
        val c = controller ?: return
        if (!dragging) {
            val dur = c.duration.takeIf { it > 0 } ?: 0L
            sbSeek.max = dur.toInt()
            sbSeek.progress = c.currentPosition.coerceIn(0, dur).toInt()
            tvTimeCur.text = Library.fmt(c.currentPosition)
            tvTimeTot.text = Library.fmt(dur)
        }
        syncLyric(c.currentPosition)
    }

    // ---------- lirik ----------

    private fun applyLyrics(r: Lyrics.Result?) {
        lyrics = r
        curLine = -1
        lyricAdapter.notifyDataSetChanged()
        tvLyricsEmpty.visibility = if (r == null) View.VISIBLE else View.GONE
        if (r == null) {
            tvLyricsEmpty.text = "Belum ada lirik.\nCari online, pilih file .lrc, atau tempel sendiri lewat tombol di bawah."
        }
    }

    private fun loadTrackLyrics(id: Long?) {
        track = null
        applyLyrics(null)
        tvLyricsEmpty.text = "Memuat lirik..."
        if (id == null) {
            tvLyricsEmpty.text = "Lirik tidak tersedia untuk file ini."
            return
        }
        lifecycleScope.launch {
            val t = withContext(Dispatchers.IO) { Library.track(this@NowPlayingActivity, id) }
            if (lastId != id) return@launch
            track = t
            if (t == null) {
                applyLyrics(null)
                return@launch
            }
            val local = withContext(Dispatchers.IO) { Lyrics.loadLocal(this@NowPlayingActivity, t) }
            if (lastId != id) return@launch
            if (local != null) {
                applyLyrics(local)
            } else {
                applyLyrics(null)
                if (Prefs.lyricsOnline(this@NowPlayingActivity)) fetchOnline(false)
            }
        }
    }

    private fun fetchOnline(manual: Boolean) {
        val t = track ?: return
        tvLyricsEmpty.visibility = View.VISIBLE
        if (lyrics == null) tvLyricsEmpty.text = "Mencari lirik online..."
        lifecycleScope.launch {
            val text = withContext(Dispatchers.IO) { Lyrics.online(t) }
            if (track?.id != t.id) return@launch
            val r = text?.let { Lyrics.parse(it, "LRCLIB") }
            if (r != null) {
                Lyrics.save(this@NowPlayingActivity, t.id, text)
                applyLyrics(r)
            } else {
                if (lyrics == null) applyLyrics(null)
                if (manual) Toast.makeText(this@NowPlayingActivity, "Lirik tidak ditemukan / tidak ada internet.", Toast.LENGTH_LONG).show()
            }
        }
    }

    private fun syncLyric(posMs: Long) {
        val r = lyrics ?: return
        if (!r.synced) return
        var idx = -1
        for (i in r.lines.indices) {
            if (r.lines[i].timeMs <= posMs + 250) idx = i else break
        }
        if (idx != curLine) {
            val old = curLine
            curLine = idx
            if (old >= 0) lyricAdapter.notifyItemChanged(old)
            if (idx >= 0) {
                lyricAdapter.notifyItemChanged(idx)
                if (lyricsOpen) {
                    (rvLyrics.layoutManager as LinearLayoutManager)
                        .scrollToPositionWithOffset(idx, rvLyrics.height / 3)
                }
            }
        }
    }

    private fun editDialog() {
        val t = track ?: return
        val et = EditText(this)
        et.setText(lyrics?.raw ?: "")
        et.hint = "Tempel lirik di sini (boleh format .lrc dengan waktu [mm:ss.xx])"
        et.minLines = 6
        et.gravity = android.view.Gravity.TOP
        AlertDialog.Builder(this)
            .setTitle("Lirik: ${t.title}")
            .setView(et)
            .setPositiveButton("Simpan") { _, _ ->
                val s = et.text.toString()
                val r = Lyrics.parse(s, "Tersimpan")
                if (r == null) {
                    Lyrics.clear(this, t.id)
                    applyLyrics(null)
                } else {
                    Lyrics.save(this, t.id, s)
                    applyLyrics(r)
                }
            }
            .setNeutralButton("Hapus") { _, _ ->
                Lyrics.clear(this, t.id)
                loadTrackLyrics(t.id)
            }
            .setNegativeButton("Batal", null)
            .show()
    }

    // ---------- dialog ----------

    private fun speedDialog() {
        val c = controller ?: return
        val labels = Array(speeds.size) { i -> if (speeds[i] == speeds[i].toInt().toFloat()) "${speeds[i].toInt()}x" else "${speeds[i]}x" }
        val cur = speeds.indexOfFirst { it == c.playbackParameters.speed }
        AlertDialog.Builder(this)
            .setTitle("Kecepatan")
            .setSingleChoiceItems(labels, cur) { d, w ->
                c.setPlaybackSpeed(speeds[w])
                d.dismiss()
            }
            .show()
    }

    private fun sleepDialog() {
        val labels = arrayOf("Mati", "15 menit", "30 menit", "45 menit", "60 menit")
        val mins = intArrayOf(0, 15, 30, 45, 60)
        AlertDialog.Builder(this)
            .setTitle("Sleep timer")
            .setItems(labels) { _, w ->
                PlayerService.instance?.setSleepTimer(mins[w])
                Toast.makeText(
                    this, if (mins[w] == 0) "Timer mati" else "Musik berhenti dalam ${mins[w]} menit",
                    Toast.LENGTH_SHORT
                ).show()
            }
            .show()
    }

    private fun queueDialog() {
        val c = controller ?: return
        val items = Array(c.mediaItemCount) { i ->
            "${i + 1}. ${c.getMediaItemAt(i).mediaMetadata.title ?: "?"}"
        }
        AlertDialog.Builder(this)
            .setTitle("Antrean")
            .setSingleChoiceItems(items, c.currentMediaItemIndex) { d, w ->
                c.seekTo(w, 0L)
                c.play()
                d.dismiss()
            }
            .show()
    }
}
