package com.niven.mangatl

import android.content.ComponentName
import android.content.ContentUris
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.provider.MediaStore
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import androidx.media3.common.Player
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.common.util.concurrent.ListenableFuture
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/** "Sedang diputar": cover besar, lirik (tersinkron), seek, acak/ulang, favorit, sleep timer, antrean, kecepatan. */
class NowPlayingActivity : AppCompatActivity() {

    private lateinit var ivArt: ImageView
    private lateinit var coverBox: View
    private lateinit var lyricsBox: View
    private lateinit var rvLyrics: RecyclerView
    private lateinit var tvLyricsEmpty: TextView
    private lateinit var tvTitle: TextView
    private lateinit var tvArtist: TextView
    private lateinit var tvTime: TextView
    private lateinit var tvInfo: TextView
    private lateinit var sbSeek: SeekBar
    private lateinit var btnPlay: ImageButton
    private lateinit var btnShuffle: ImageButton
    private lateinit var btnRepeat: ImageButton
    private lateinit var btnFav: ImageButton
    private lateinit var btnLyrics: ImageButton

    private var future: ListenableFuture<MediaController>? = null
    private var controller: MediaController? = null
    private val handler = Handler(Looper.getMainLooper())
    private var dragging = false
    private var lastId: Long? = null
    private var track: Library.Track? = null
    private var lyrics: Lyrics.Result? = null
    private var showLyrics = false
    private var curLine = -1
    private val speeds = floatArrayOf(0.75f, 1f, 1.25f, 1.5f, 2f)

    private val tick = object : Runnable {
        override fun run() {
            updateProgress()
            handler.postDelayed(this, 400)
        }
    }

    private val pickLyricFile = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        val t = track
        if (uri != null && t != null) {
            try {
                val text = contentResolver.openInputStream(uri)?.use { it.readBytes().toString(Charsets.UTF_8) } ?: ""
                if (Lyrics.parse(text, "") == null) {
                    Toast.makeText(this, "File kosong.", Toast.LENGTH_SHORT).show()
                } else {
                    Lyrics.save(this, t.id, text)
                    applyLyrics(Lyrics.parse(text, "Tersimpan"))
                }
            } catch (e: Exception) {
                Toast.makeText(this, "Gagal membaca file.", Toast.LENGTH_SHORT).show()
            }
        }
    }

    // ---- adapter lirik ----
    private val lyricAdapter = object : RecyclerView.Adapter<RecyclerView.ViewHolder>() {
        override fun getItemCount() = lyrics?.lines?.size ?: 0

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
            val tv = TextView(parent.context)
            tv.layoutParams = ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            tv.gravity = android.view.Gravity.CENTER
            tv.setPadding(Ui.dp(this@NowPlayingActivity, 12), Ui.dp(this@NowPlayingActivity, 8),
                Ui.dp(this@NowPlayingActivity, 12), Ui.dp(this@NowPlayingActivity, 8))
            return object : RecyclerView.ViewHolder(tv) {}
        }

        override fun onBindViewHolder(h: RecyclerView.ViewHolder, pos: Int) {
            val r = lyrics ?: return
            val l = r.lines[pos]
            val tv = h.itemView as TextView
            tv.text = l.text.ifEmpty { "…" }
            val cur = r.synced && pos == curLine
            tv.alpha = if (!r.synced || cur) 1f else 0.45f
            tv.textSize = if (cur) 20f else 17f
            tv.setTypeface(null, if (cur) android.graphics.Typeface.BOLD else android.graphics.Typeface.NORMAL)
            tv.setOnClickListener {
                if (r.synced && l.timeMs >= 0) controller?.seekTo(l.timeMs)
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_nowplaying)
        Fx.enter(this)
        ivArt = findViewById(R.id.ivArt)
        coverBox = findViewById(R.id.coverBox)
        lyricsBox = findViewById(R.id.lyricsBox)
        rvLyrics = findViewById(R.id.rvLyrics)
        tvLyricsEmpty = findViewById(R.id.tvLyricsEmpty)
        tvTitle = findViewById(R.id.tvTitle)
        tvArtist = findViewById(R.id.tvArtist)
        tvTime = findViewById(R.id.tvTime)
        tvInfo = findViewById(R.id.tvInfo)
        sbSeek = findViewById(R.id.sbSeek)
        btnPlay = findViewById(R.id.btnPlay)
        btnShuffle = findViewById(R.id.btnShuffle)
        btnRepeat = findViewById(R.id.btnRepeat)
        btnFav = findViewById(R.id.btnFav)
        btnLyrics = findViewById(R.id.btnLyrics)

        rvLyrics.layoutManager = LinearLayoutManager(this)
        rvLyrics.adapter = lyricAdapter
        // RecyclerView di dalam ScrollView: biar bisa digulir sendiri
        rvLyrics.setOnTouchListener { v, _ ->
            v.parent.requestDisallowInterceptTouchEvent(true)
            false
        }

        btnPlay.setOnClickListener { controller?.let { if (it.isPlaying) it.pause() else it.play() } }
        findViewById<View>(R.id.btnPrev).setOnClickListener { controller?.seekToPreviousMediaItem() }
        findViewById<View>(R.id.btnNext).setOnClickListener { controller?.seekToNextMediaItem() }
        btnShuffle.setOnClickListener { controller?.let { it.shuffleModeEnabled = !it.shuffleModeEnabled } }
        btnRepeat.setOnClickListener {
            controller?.let {
                it.repeatMode = when (it.repeatMode) {
                    Player.REPEAT_MODE_OFF -> Player.REPEAT_MODE_ALL
                    Player.REPEAT_MODE_ALL -> Player.REPEAT_MODE_ONE
                    else -> Player.REPEAT_MODE_OFF
                }
            }
        }
        btnFav.setOnClickListener {
            val id = controller?.currentMediaItem?.mediaId?.toLongOrNull() ?: return@setOnClickListener
            MusicStore.toggleFav(this, id)
            updateUi()
        }
        btnLyrics.setOnClickListener {
            showLyrics = !showLyrics
            applyLyricMode()
        }
        findViewById<View>(R.id.btnSleep).setOnClickListener { sleepDialog() }
        findViewById<View>(R.id.btnQueue).setOnClickListener { queueDialog() }
        findViewById<View>(R.id.btnSpeed).setOnClickListener {
            val c = controller ?: return@setOnClickListener
            val i = speeds.indexOfFirst { it == c.playbackParameters.speed }
            c.setPlaybackSpeed(speeds[(i + 1) % speeds.size])
            updateUi()
        }
        findViewById<View>(R.id.ibLyOnline).setOnClickListener { fetchOnline(true) }
        findViewById<View>(R.id.ibLyFile).setOnClickListener { pickLyricFile.launch(arrayOf("*/*")) }
        findViewById<View>(R.id.ibLyEdit).setOnClickListener { editDialog() }

        sbSeek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar?, p: Int, fromUser: Boolean) {
                if (fromUser) tvTime.text = "${Library.fmt(p.toLong())} / ${Library.fmt(sbSeek.max.toLong())}"
            }

            override fun onStartTrackingTouch(sb: SeekBar?) {
                dragging = true
            }

            override fun onStopTrackingTouch(sb: SeekBar?) {
                dragging = false
                controller?.seekTo((sb?.progress ?: 0).toLong())
            }
        })
    }

    override fun onStart() {
        super.onStart()
        val token = SessionToken(this, ComponentName(this, PlayerService::class.java))
        val f = MediaController.Builder(this, token).buildAsync()
        future = f
        f.addListener({
            try {
                val c = f.get()
                controller = c
                c.addListener(object : Player.Listener {
                    override fun onEvents(player: Player, events: Player.Events) = updateUi()
                })
                updateUi()
                handler.post(tick)
            } catch (e: Exception) {
                Toast.makeText(this, "Pemutar gagal tersambung", Toast.LENGTH_LONG).show()
            }
        }, ContextCompat.getMainExecutor(this))
    }

    override fun onStop() {
        handler.removeCallbacks(tick)
        future?.let { MediaController.releaseFuture(it) }
        future = null
        controller = null
        super.onStop()
    }

    // ---------- UI ----------

    private fun updateUi() {
        val c = controller ?: return
        tvTitle.text = c.mediaMetadata.title ?: "—"
        tvArtist.text = c.mediaMetadata.artist ?: ""
        btnPlay.setImageResource(if (c.isPlaying) R.drawable.ic_pause else R.drawable.ic_play)
        btnShuffle.alpha = if (c.shuffleModeEnabled) 1f else 0.4f
        btnRepeat.setImageResource(if (c.repeatMode == Player.REPEAT_MODE_ONE) R.drawable.ic_repeat_one else R.drawable.ic_repeat)
        btnRepeat.alpha = if (c.repeatMode == Player.REPEAT_MODE_OFF) 0.4f else 1f
        val id = c.currentMediaItem?.mediaId?.toLongOrNull()
        btnFav.setImageResource(if (id != null && MusicStore.isFav(this, id)) R.drawable.ic_fav else R.drawable.ic_fav_border)
        btnLyrics.alpha = if (showLyrics) 1f else 0.6f
        if (id != lastId) {
            lastId = id
            val uri = id?.let { ContentUris.withAppendedId(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, it) }
            Thumbs.load(lifecycleScope, ivArt, uri, 640, false)
            loadTrackLyrics(id)
        }
        updateProgress()
    }

    private fun updateProgress() {
        val c = controller ?: return
        val sp = c.playbackParameters.speed
        val left = (PlayerService.instance?.sleepEndAt ?: 0L) - SystemClock.elapsedRealtime()
        val info = ArrayList<String>()
        if (left > 0) info.add("Timer ${(left / 60000) + 1} menit")
        if (sp != 1f) info.add(if (sp == sp.toInt().toFloat()) "${sp.toInt()}x" else "${sp}x")
        tvInfo.text = info.joinToString("  •  ")
        if (!dragging) {
            val dur = c.duration.takeIf { it > 0 } ?: 0L
            sbSeek.max = dur.toInt()
            sbSeek.progress = c.currentPosition.coerceIn(0, dur).toInt()
            tvTime.text = "${Library.fmt(c.currentPosition)} / ${Library.fmt(dur)}"
        }
        syncLyric(c.currentPosition)
    }

    // ---------- lirik ----------

    private fun applyLyricMode() {
        coverBox.visibility = if (showLyrics) View.GONE else View.VISIBLE
        lyricsBox.visibility = if (showLyrics) View.VISIBLE else View.GONE
        btnLyrics.alpha = if (showLyrics) 1f else 0.6f
    }

    private fun applyLyrics(r: Lyrics.Result?) {
        lyrics = r
        curLine = -1
        lyricAdapter.notifyDataSetChanged()
        tvLyricsEmpty.visibility = if (r == null) View.VISIBLE else View.GONE
        if (r == null) {
            tvLyricsEmpty.text = "Belum ada lirik.\nCari online, pilih file .lrc, atau tempel sendiri lewat tombol di bawah."
        }
    }

    private fun loadTrackLyrics(id: Long?) {
        track = null
        applyLyrics(null)
        tvLyricsEmpty.text = "Memuat lirik..."
        if (id == null) {
            tvLyricsEmpty.text = "Lirik tidak tersedia untuk file ini."
            return
        }
        lifecycleScope.launch {
            val t = withContext(Dispatchers.IO) { Library.track(this@NowPlayingActivity, id) }
            if (lastId != id) return@launch
            track = t
            if (t == null) {
                applyLyrics(null)
                return@launch
            }
            val local = withContext(Dispatchers.IO) { Lyrics.loadLocal(this@NowPlayingActivity, t) }
            if (lastId != id) return@launch
            if (local != null) {
                applyLyrics(local)
            } else {
                applyLyrics(null)
                if (Prefs.lyricsOnline(this@NowPlayingActivity)) fetchOnline(false)
            }
        }
    }

    private fun fetchOnline(manual: Boolean) {
        val t = track ?: return
        tvLyricsEmpty.visibility = View.VISIBLE
        if (lyrics == null) tvLyricsEmpty.text = "Mencari lirik online..."
        lifecycleScope.launch {
            val text = withContext(Dispatchers.IO) { Lyrics.online(t) }
            if (track?.id != t.id) return@launch
            val r = text?.let { Lyrics.parse(it, "LRCLIB") }
            if (r != null) {
                Lyrics.save(this@NowPlayingActivity, t.id, text)
                applyLyrics(r)
            } else {
                if (lyrics == null) applyLyrics(null)
                if (manual) Toast.makeText(this@NowPlayingActivity, "Lirik tidak ditemukan / tidak ada internet.", Toast.LENGTH_LONG).show()
            }
        }
    }

    private fun syncLyric(posMs: Long) {
        val r = lyrics ?: return
        if (!r.synced) return
        var idx = -1
        for (i in r.lines.indices) {
            if (r.lines[i].timeMs <= posMs + 250) idx = i else break
        }
        if (idx != curLine) {
            val old = curLine
            curLine = idx
            if (old >= 0) lyricAdapter.notifyItemChanged(old)
            if (idx >= 0) {
                lyricAdapter.notifyItemChanged(idx)
                if (showLyrics) {
                    (rvLyrics.layoutManager as LinearLayoutManager)
                        .scrollToPositionWithOffset(idx, rvLyrics.height / 3)
                }
            }
        }
    }

    private fun editDialog() {
        val t = track ?: return
        val et = EditText(this)
        et.setText(lyrics?.raw ?: "")
        et.hint = "Tempel lirik di sini (boleh format .lrc dengan waktu [mm:ss.xx])"
        et.minLines = 6
        et.gravity = android.view.Gravity.TOP
        AlertDialog.Builder(this)
            .setTitle("Lirik: ${t.title}")
            .setView(et)
            .setPositiveButton("Simpan") { _, _ ->
                val s = et.text.toString()
                val r = Lyrics.parse(s, "Tersimpan")
                if (r == null) {
                    Lyrics.clear(this, t.id)
                    applyLyrics(null)
                } else {
                    Lyrics.save(this, t.id, s)
                    applyLyrics(r)
                }
            }
            .setNeutralButton("Hapus") { _, _ ->
                Lyrics.clear(this, t.id)
                loadTrackLyrics(t.id)
            }
            .setNegativeButton("Batal", null)
            .show()
    }

    // ---------- dialog ----------

    private fun sleepDialog() {
        val labels = arrayOf("Mati", "15 menit", "30 menit", "45 menit", "60 menit")
        val mins = intArrayOf(0, 15, 30, 45, 60)
        AlertDialog.Builder(this)
            .setTitle("Sleep timer")
            .setItems(labels) { _, w ->
                PlayerService.instance?.setSleepTimer(mins[w])
                Toast.makeText(
                    this, if (mins[w] == 0) "Timer mati" else "Musik berhenti dalam ${mins[w]} menit",
                    Toast.LENGTH_SHORT
                ).show()
            }
            .show()
    }

    private fun queueDialog() {
        val c = controller ?: return
        val items = Array(c.mediaItemCount) { i ->
            "${i + 1}. ${c.getMediaItemAt(i).mediaMetadata.title ?: "?"}"
        }
        AlertDialog.Builder(this)
            .setTitle("Antrean")
            .setSingleChoiceItems(items, c.currentMediaItemIndex) { d, w ->
                c.seekTo(w, 0L)
                c.play()
                d.dismiss()
            }
            .show()
    }
}
