package com.niven.mangatl

import android.content.ContentUris
import android.content.Context
import android.media.AudioFormat
import android.media.MediaCodec
import android.media.MediaExtractor
import android.media.MediaFormat
import android.provider.MediaStore
import java.nio.ByteOrder
import java.util.concurrent.Executors
import kotlin.math.abs
import kotlin.math.log10
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow
import kotlin.math.sqrt

/**
 * Pembobotan-K ITU-R BS.1770 (high shelf lalu high-pass). Koefisien resmi untuk 48 kHz,
 * dipetakan ke laju lain lewat prototipe analognya (bilinear), jadi responsnya tetap
 * sama di semua laju sampel.
 */
class KWeight(sr: Int) {
    private val s1 = Biquad()
    private val s2 = Biquad()

    init {
        conv(s1, 1.53512485958697, -2.69169618940638, 1.19839281085285, -1.69065929318241, 0.73248077421585, sr)
        conv(s2, 1.0, -2.0, 1.0, -1.99004745483398, 0.99007225036621, sr)
    }

    private fun conv(q: Biquad, b0: Double, b1: Double, b2: Double, a1: Double, a2: Double, sr: Int) {
        val n0 = b0 + b1 + b2
        val n1 = 2 * (b0 - b2)
        val n2 = b0 - b1 + b2
        val d0 = 1 + a1 + a2
        val d1 = 2 * (1 - a2)
        val d2 = 1 - a1 + a2
        val r = sr / 48000.0
        val m1 = n1 * r
        val m2 = n2 * r * r
        val e1 = d1 * r
        val e2 = d2 * r * r
        q.set(n0 + m1 + m2, 2 * n0 - 2 * m2, n0 - m1 + m2, d0 + e1 + e2, 2 * d0 - 2 * e2, d0 - e1 + e2)
    }

    fun process(x: Double): Double = s2.process(s1.process(x))
    fun reset() {
        s1.reset(); s2.reset()
    }
}

/** Meter loudness waktu-nyata: momentary (400 ms) dan short-term (3 s) dari blok 100 ms. */
class LoudMeter(private val sr: Int) {
    private val kl = KWeight(sr)
    private val kr = KWeight(sr)
    private val blockLen = max(1, sr / 10)
    private var acc = 0.0
    private var cnt = 0
    private val ring = DoubleArray(30)
    private var rp = 0
    private var filled = 0
    var momentary = -70.0
        private set
    var shortTerm = -70.0
        private set
    var rmsDb = -90.0
        private set
    private var rmsAcc = 0.0
    private var peak = 0.0
    var peakDb = -90.0
        private set

    fun push(l: Float, r: Float) {
        val a = kl.process(l.toDouble())
        val b = kr.process(r.toDouble())
        acc += a * a + b * b
        rmsAcc += l.toDouble() * l + r.toDouble() * r
        val p = max(abs(l), abs(r)).toDouble()
        if (p > peak) peak = p
        cnt++
        if (cnt >= blockLen) {
            ring[rp] = acc / cnt
            rp = (rp + 1) % ring.size
            if (filled < ring.size) filled++
            val m4 = mean(4)
            val m30 = mean(30)
            momentary = lufs(m4)
            shortTerm = lufs(m30)
            rmsDb = if (rmsAcc > 0) 10.0 * log10(rmsAcc / (cnt * 2.0)) else -90.0
            peakDb = if (peak > 1e-9) 20.0 * log10(peak) else -90.0
            acc = 0.0
            rmsAcc = 0.0
            peak = 0.0
            cnt = 0
        }
    }

    private fun mean(k: Int): Double {
        val n = min(k, filled)
        if (n == 0) return 0.0
        var s = 0.0
        for (i in 0 until n) s += ring[((rp - 1 - i) % ring.size + ring.size) % ring.size]
        return s / n
    }

    private fun lufs(ms: Double) = if (ms <= 1e-12) -70.0 else -0.691 + 10.0 * log10(ms)

    fun reset() {
        kl.reset(); kr.reset(); acc = 0.0; cnt = 0; filled = 0; rp = 0
        rmsAcc = 0.0; peak = 0.0
        momentary = -70.0; shortTerm = -70.0; rmsDb = -90.0; peakDb = -90.0
    }
}

/** Hasil analisis satu lagu. peakDb = sample peak, tpDb = true peak (interpolasi antar-sampel). */
class LoudInfo(val lufs: Double, val rg: Double, val peakDb: Double, val tpDb: Double)

/**
 * Akumulator analisis satu lagu (dipisah dari decoder supaya bisa diuji). Sumber mono diumpankan sebagai
 * dual-mono (l = r): itu loudness yang benar-benar terdengar karena mono dirender ke dua speaker, dan sama
 * dengan sumber stereo L=R. Jalur ReplayGain membagi energi dengan 2 (rata-rata per kanal) jadi tidak ada hitung ganda.
 */
class LoudAccumulator(private var sr: Int) {
    private var kl = KWeight(sr)
    private var kr = KWeight(sr)
    private var tpL = TruePeak(TruePeak.factorFor(sr))
    private var tpR = TruePeak(TruePeak.factorFor(sr))
    private val sub = ArrayList<Double>()
    private val rg = ArrayList<Double>()
    private var accSub = 0.0
    private var cntSub = 0
    private var accRg = 0.0
    private var cntRg = 0
    private var peak = 0.0
    private var tp = 0.0
    private var subLen = max(1, sr / 10)
    private var rgLen = max(1, sr / 20)

    fun setRate(nsr: Int) {
        if (nsr == sr) return
        tp = max(tp, max(tpL.flush(), tpR.flush()))
        sr = nsr
        kl = KWeight(sr); kr = KWeight(sr)
        tpL = TruePeak(TruePeak.factorFor(sr)); tpR = TruePeak(TruePeak.factorFor(sr))
        subLen = max(1, sr / 10); rgLen = max(1, sr / 20)
    }

    fun push(l: Double, r: Double) {
        val pk = max(abs(l), abs(r))
        if (pk > peak) peak = pk
        tp = max(tp, max(tpL.push(l), tpR.push(r)))
        val a = kl.process(l)
        val b = kr.process(r)
        val e = a * a + b * b
        accSub += e
        accRg += e
        cntSub++
        cntRg++
        if (cntSub >= subLen) {
            sub.add(accSub / cntSub)
            accSub = 0.0
            cntSub = 0
        }
        if (cntRg >= rgLen) {
            rg.add(accRg / cntRg)
            accRg = 0.0
            cntRg = 0
        }
    }

    fun result(): LoudInfo? {
        if (sub.size < 4) return null
        tp = max(tp, max(tpL.flush(), tpR.flush()))
        // blok 400 ms (4 sub-blok), geser 100 ms
        val blocks = ArrayList<Double>()
        for (i in 0..sub.size - 4) blocks.add((sub[i] + sub[i + 1] + sub[i + 2] + sub[i + 3]) / 4.0)
        val absThr = 10.0.pow((-70.0 + 0.691) / 10.0)
        val kept = blocks.filter { it > absThr }
        if (kept.isEmpty()) return null
        val relThr = kept.average() * 10.0.pow(-1.0)
        val kept2 = kept.filter { it > relThr }
        val integrated = -0.691 + 10.0 * log10((if (kept2.isEmpty()) kept else kept2).average())
        // ReplayGain gaya klasik: persentil 95 dari RMS 50 ms (dua kanal digabung)
        val rgDb = rg.map { 10.0 * log10(max(it / 2.0, 1e-12)) }.sorted()
        val p95 = rgDb[min(rgDb.size - 1, (rgDb.size * 0.95).toInt())] - 0.691
        val peakDb = if (peak > 1e-9) 20.0 * log10(peak) else -90.0
        val tpDb = if (tp > 1e-9) 20.0 * log10(max(tp, peak)) else -90.0
        return LoudInfo(integrated, p95, peakDb, tpDb)
    }
}

/**
 * Menganalisis lagu di latar belakang (MediaExtractor + MediaCodec), hasilnya disimpan
 * per lagu. Dua ukuran: EBU R128 (integrated, gerbang -70 LUFS dan -10 LU) dan
 * ReplayGain-gaya-klasik (persentil ke-95 dari RMS 50 ms berbobot K).
 */
object LoudnessCache {
    private val pool = Executors.newSingleThreadExecutor { r ->
        Thread(r, "loudness").apply { priority = Thread.MIN_PRIORITY }
    }
    private val mem = HashMap<Long, LoudInfo>()
    private val busy = HashSet<Long>()
    @Volatile var onReady: ((Long) -> Unit)? = null

    private fun prefs(ctx: Context) = ctx.getSharedPreferences("audio_loudness", Context.MODE_PRIVATE)

    @Synchronized
    fun get(ctx: Context, id: Long): LoudInfo? {
        mem[id]?.let { return it }
        val s = prefs(ctx).getString("t$id", null) ?: return null
        val p = s.split(",")
        // entri lama (3 kolom) hanya punya sample peak: dianalisis ulang supaya Clipping Prevention memakai true peak
        if (p.size < 4) return null
        val li = try {
            LoudInfo(p[0].toDouble(), p[1].toDouble(), p[2].toDouble(), p[3].toDouble())
        } catch (e: Exception) {
            return null
        }
        mem[id] = li
        return li
    }

    @Synchronized
    private fun put(ctx: Context, id: Long, li: LoudInfo) {
        mem[id] = li
        prefs(ctx).edit().putString("t$id", "${li.lufs},${li.rg},${li.peakDb},${li.tpDb}").apply()
    }

    @Synchronized
    private fun markBusy(id: Long): Boolean = busy.add(id)

    @Synchronized
    private fun unmark(id: Long) {
        busy.remove(id)
    }

    fun failed(ctx: Context, id: Long): Boolean = prefs(ctx).getBoolean("f$id", false)

    /** Minta analisis (tidak melakukan apa-apa kalau sudah ada / sedang berjalan). */
    fun request(ctx: Context, id: Long) {
        if (id < 0) return
        val app = ctx.applicationContext
        if (get(app, id) != null || failed(app, id)) return
        if (!markBusy(id)) return
        pool.execute {
            try {
                val li = analyze(app, id)
                if (li != null) {
                    put(app, id, li)
                    onReady?.invoke(id)
                } else {
                    prefs(app).edit().putBoolean("f$id", true).apply()
                }
            } catch (e: Throwable) {
                prefs(app).edit().putBoolean("f$id", true).apply()
            } finally {
                unmark(id)
            }
        }
    }

    fun clear(ctx: Context) {
        synchronized(this) { mem.clear() }
        prefs(ctx).edit().clear().apply()
    }

    private fun analyze(ctx: Context, id: Long): LoudInfo? {
        val uri = ContentUris.withAppendedId(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, id)
        val ex = MediaExtractor()
        var codec: MediaCodec? = null
        try {
            ex.setDataSource(ctx, uri, null)
            var track = -1
            var fmt: MediaFormat? = null
            for (i in 0 until ex.trackCount) {
                val f = ex.getTrackFormat(i)
                val mime = f.getString(MediaFormat.KEY_MIME) ?: continue
                if (mime.startsWith("audio/")) {
                    track = i
                    fmt = f
                    break
                }
            }
            if (track < 0 || fmt == null) return null
            ex.selectTrack(track)
            val mime = fmt.getString(MediaFormat.KEY_MIME) ?: return null
            codec = MediaCodec.createDecoderByType(mime)
            codec.configure(fmt, null, null, 0)
            codec.start()

            var sr = if (fmt.containsKey(MediaFormat.KEY_SAMPLE_RATE)) fmt.getInteger(MediaFormat.KEY_SAMPLE_RATE) else 44100
            var ch = if (fmt.containsKey(MediaFormat.KEY_CHANNEL_COUNT)) fmt.getInteger(MediaFormat.KEY_CHANNEL_COUNT) else 2
            var pcmEnc = AudioFormat.ENCODING_PCM_16BIT
            val accum = LoudAccumulator(sr)

            val info = MediaCodec.BufferInfo()
            var inDone = false
            var outDone = false
            var guard = 0
            while (!outDone && guard < 4_000_000) {
                guard++
                if (!inDone) {
                    val ii = codec.dequeueInputBuffer(10_000)
                    if (ii >= 0) {
                        val buf = codec.getInputBuffer(ii)!!
                        val sz = ex.readSampleData(buf, 0)
                        if (sz < 0) {
                            codec.queueInputBuffer(ii, 0, 0, 0, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                            inDone = true
                        } else {
                            codec.queueInputBuffer(ii, 0, sz, ex.sampleTime, 0)
                            ex.advance()
                        }
                    }
                }
                val oi = codec.dequeueOutputBuffer(info, 10_000)
                if (oi == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                    val of = codec.outputFormat
                    if (of.containsKey(MediaFormat.KEY_SAMPLE_RATE)) {
                        val nsr = of.getInteger(MediaFormat.KEY_SAMPLE_RATE)
                        if (nsr != sr) {
                            sr = nsr
                            accum.setRate(sr)
                        }
                    }
                    if (of.containsKey(MediaFormat.KEY_CHANNEL_COUNT)) ch = of.getInteger(MediaFormat.KEY_CHANNEL_COUNT)
                    pcmEnc = if (of.containsKey(MediaFormat.KEY_PCM_ENCODING)) of.getInteger(MediaFormat.KEY_PCM_ENCODING)
                    else AudioFormat.ENCODING_PCM_16BIT
                } else if (oi >= 0) {
                    val ob = codec.getOutputBuffer(oi)!!
                    ob.order(ByteOrder.nativeOrder())
                    ob.position(info.offset)
                    ob.limit(info.offset + info.size)
                    val bytes = if (pcmEnc == AudioFormat.ENCODING_PCM_FLOAT) 4 else 2
                    val frames = info.size / (bytes * max(ch, 1))
                    for (f in 0 until frames) {
                        var l = 0.0
                        var r = 0.0
                        for (c in 0 until ch) {
                            val x = if (bytes == 4) ob.getFloat().toDouble() else ob.getShort() / 32768.0
                            if (c == 0) l = x
                            if (c == 1) r = x
                        }
                        if (ch == 1) r = l // dual-mono: sama dengan yang terdengar (lihat LoudAccumulator)
                        accum.push(l, r)
                    }
                    codec.releaseOutputBuffer(oi, false)
                    if (info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM != 0) outDone = true
                }
            }
            return accum.result()
        } finally {
            try {
                codec?.stop()
            } catch (e: Exception) {
            }
            try {
                codec?.release()
            } catch (e: Exception) {
            }
            ex.release()
        }
    }
}
