package com.niven.mangatl

import android.content.ContentUris
import android.content.Context
import android.net.Uri
import android.provider.MediaStore

/** Baca lagu & video dari MediaStore, plus pengelompokan (album, artis, folder). */
object Library {

    class Track(
        val id: Long,
        val uri: Uri,
        val title: String,
        val artist: String,
        val album: String,
        val durationMs: Long,
        val albumId: Long,
        val folder: String,
        val dateAdded: Long,
        val fileBase: String,
        val rel: String = "",
        val ext: String = ""
    )

    class Video(
        val id: Long,
        val uri: Uri,
        val title: String,
        val durationMs: Long,
        val size: Long,
        val bucketId: Long,
        val bucket: String,
        val dateAdded: Long,
        val rel: String = ""
    )

    class Group(val title: String, val sub: String, val tracks: List<Track>, val date: Long, val big: Long)

    class VFolder(val bucketId: Long, val name: String, val videos: List<Video>) {
        val date: Long get() = videos.maxOfOrNull { it.dateAdded } ?: 0L
        val size: Long get() = videos.sumOf { it.size }
    }

    private val AUDIO_PROJ = arrayOf(
        MediaStore.Audio.Media._ID,
        MediaStore.Audio.Media.TITLE,
        MediaStore.Audio.Media.ARTIST,
        MediaStore.Audio.Media.ALBUM,
        MediaStore.Audio.Media.DURATION,
        MediaStore.Audio.Media.ALBUM_ID,
        MediaStore.Audio.Media.DATA,
        MediaStore.Audio.Media.DATE_ADDED,
        MediaStore.Audio.Media.DISPLAY_NAME
    )

    /** Folder relatif di penyimpanan utama (mis. "Music/Album/"), kosong kalau di luar penyimpanan utama. */
    private fun relFromPath(path: String): String {
        val pre = "/storage/emulated/0/"
        val dir = path.substringBeforeLast('/', "") + "/"
        return if (dir.startsWith(pre) && dir.length > pre.length) dir.removePrefix(pre) else ""
    }

    private val SITE_TAG = Regex("""\s*[(\[]\s*[\w.-]*\.(?:cc|com|net|me|io|co|org|id)\s*[)\]]""", RegexOption.IGNORE_CASE)
    private val MULTI_SPACE = Regex("\\s{2,}")

    /**
     * Judul dari nama file ("A_-_B_(MP3.cc)") dirapikan: garis bawah jadi spasi, tag situs dibuang.
     * Kalau artis kosong dan polanya "Artis - Judul", dipecah jadi artis dan judul.
     */
    private fun tidy(raw: String, artist: String?): Pair<String, String> {
        var t = raw
        if (t.contains('_') && !t.contains(' ')) t = t.replace('_', ' ')
        t = MULTI_SPACE.replace(SITE_TAG.replace(t, ""), " ").trim()
        var a = artist
        if (a == null) {
            val i = t.indexOf(" - ")
            if (i > 0 && i < t.length - 3) {
                a = t.substring(0, i).trim()
                t = t.substring(i + 3).trim()
            }
        }
        return (t.ifEmpty { raw }) to (a ?: "Tidak diketahui")
    }

    @Suppress("DEPRECATION")
    private fun queryTracks(ctx: Context, sel: String?, args: Array<String>?, order: String?): List<Track> {
        val out = ArrayList<Track>()
        ctx.contentResolver.query(
            MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, AUDIO_PROJ, sel, args, order
        )?.use { c ->
            while (c.moveToNext()) {
                val id = c.getLong(0)
                val (title, artist) = tidy(
                    c.getString(1) ?: "Tanpa judul",
                    c.getString(2)?.takeIf { it != "<unknown>" && it.isNotBlank() }
                )
                val path = c.getString(6) ?: ""
                val file = c.getString(8) ?: ""
                out.add(
                    Track(
                        id,
                        ContentUris.withAppendedId(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, id),
                        title,
                        artist,
                        c.getString(3) ?: "",
                        c.getLong(4),
                        c.getLong(5),
                        path.substringBeforeLast('/', ""),
                        c.getLong(7),
                        file.substringBeforeLast('.', file),
                        relFromPath(path),
                        file.substringAfterLast('.', "")
                    )
                )
            }
        }
        return out
    }

    fun audios(ctx: Context): List<Track> = queryTracks(
        ctx,
        "${MediaStore.Audio.Media.IS_MUSIC} != 0 AND ${MediaStore.Audio.Media.DURATION} >= 10000",
        null,
        "${MediaStore.Audio.Media.TITLE} COLLATE NOCASE ASC"
    )

    fun track(ctx: Context, id: Long): Track? =
        queryTracks(ctx, "${MediaStore.Audio.Media._ID} = ?", arrayOf(id.toString()), null).firstOrNull()

    private fun group(title: String, sub: String, l: List<Track>) =
        Group(title, sub, l, l.maxOf { it.dateAdded }, l.sumOf { it.durationMs })

    fun albums(t: List<Track>): List<Group> =
        t.groupBy { it.albumId }.values.map { l ->
            group(l[0].album.ifBlank { "Tanpa album" }, "${l[0].artist}  •  ${l.size} lagu", l)
        }

    fun artists(t: List<Track>): List<Group> =
        t.groupBy { it.artist }.values.map { l -> group(l[0].artist, "${l.size} lagu", l) }

    fun folders(t: List<Track>): List<Group> =
        t.groupBy { it.folder }.map { (path, l) ->
            group(path.substringAfterLast('/').ifBlank { "/" }, "$path  •  ${l.size} lagu", l)
        }

    fun videos(ctx: Context, bucket: Long? = null): List<Video> {
        val out = ArrayList<Video>()
        val base = arrayOf(
            MediaStore.Video.Media._ID,
            MediaStore.Video.Media.DISPLAY_NAME,
            MediaStore.Video.Media.DURATION,
            MediaStore.Video.Media.SIZE,
            MediaStore.Video.Media.BUCKET_ID,
            MediaStore.Video.Media.BUCKET_DISPLAY_NAME,
            MediaStore.Video.Media.DATE_ADDED
        )
        val hasRel = android.os.Build.VERSION.SDK_INT >= 29
        val proj = if (hasRel) base + MediaStore.Video.Media.RELATIVE_PATH else base
        val sel = if (bucket != null) "${MediaStore.Video.Media.BUCKET_ID} = ?" else null
        val args = if (bucket != null) arrayOf(bucket.toString()) else null
        ctx.contentResolver.query(
            MediaStore.Video.Media.EXTERNAL_CONTENT_URI, proj, sel, args,
            "${MediaStore.Video.Media.DATE_ADDED} DESC"
        )?.use { c ->
            while (c.moveToNext()) {
                val id = c.getLong(0)
                out.add(
                    Video(
                        id,
                        ContentUris.withAppendedId(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, id),
                        c.getString(1) ?: "Video",
                        c.getLong(2),
                        c.getLong(3),
                        c.getLong(4),
                        c.getString(5) ?: "Tanpa folder",
                        c.getLong(6),
                        if (hasRel) (c.getString(7) ?: "") else ""
                    )
                )
            }
        }
        return out
    }

    fun videoFolders(ctx: Context): List<VFolder> =
        videos(ctx).groupBy { it.bucketId }.values.map { l -> VFolder(l[0].bucketId, l[0].bucket, l) }

    fun fmt(ms: Long): String {
        if (ms <= 0) return "0:00"
        val s = ms / 1000
        val h = s / 3600
        val m = (s % 3600) / 60
        val sec = s % 60
        return if (h > 0) String.format("%d:%02d:%02d", h, m, sec) else String.format("%d:%02d", m, sec)
    }

    fun sizeStr(bytes: Long): String {
        val mb = bytes / 1024.0 / 1024.0
        return if (mb >= 1024) String.format("%.1f GB", mb / 1024) else String.format("%.1f MB", mb)
    }
}
