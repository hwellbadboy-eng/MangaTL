package com.niven.mangatl

import android.content.Context
import android.graphics.Rect

/**
 * Teks UI yang kamu pilih untuk tidak diterjemahkan (lewat menu tekan-lama tombol TL).
 *
 * Satu entri = teks (dinormalkan) + kotak posisi (pecahan 0..1 dari lebar/tinggi layar).
 * Kotak OCR dianggap sama kalau teksnya persis sama dan titik tengahnya ada di dalam kotak entri,
 * jadi dialog dengan kata yang sama di tempat lain tetap diterjemahkan. Hanya seleksi manual.
 */
object IgnoreStore {

    private const val KEY = "ui_ignore"
    private const val MAX_ENTRIES = 200

    class Entry(val text: String, val l: Float, val t: Float, val r: Float, val b: Float)

    private fun prefs(ctx: Context) = ctx.getSharedPreferences(Grouping.PREF_FILE, Context.MODE_PRIVATE)

    @Synchronized
    fun load(ctx: Context): MutableList<Entry> {
        val out = ArrayList<Entry>()
        val raw = prefs(ctx).getString(KEY, "") ?: ""
        for (line in raw.split('\n')) {
            val p = line.split('\t')
            if (p.size != 5 || p[0].isEmpty()) continue
            try {
                out.add(Entry(p[0], p[1].toFloat(), p[2].toFloat(), p[3].toFloat(), p[4].toFloat()))
            } catch (_: NumberFormatException) {
            }
        }
        return out
    }

    private fun save(ctx: Context, list: List<Entry>) {
        val sb = StringBuilder()
        for (e in list) {
            if (sb.isNotEmpty()) sb.append('\n')
            sb.append(e.text).append('\t').append(e.l).append('\t').append(e.t).append('\t')
                .append(e.r).append('\t').append(e.b)
        }
        prefs(ctx).edit().putString(KEY, sb.toString()).apply()
    }

    /** Teks sama persis dan titik tengah kotak baru ada di dalam kotak entri (toleransi 1% layar). */
    private fun matches(e: Entry, text: String, l: Float, t: Float, r: Float, b: Float): Boolean {
        if (e.text != text) return false
        val cx = (l + r) / 2f
        val cy = (t + b) / 2f
        val m = 0.01f
        return cx >= e.l - m && cx <= e.r + m && cy >= e.t - m && cy <= e.b + m
    }

    /** Apakah kotak OCR (piksel, ditambah offset potongan) cocok dengan salah satu entri. */
    fun isIgnored(entries: List<Entry>, text: String, rect: Rect, offX: Int, offY: Int, w: Int, h: Int): Boolean {
        if (w <= 0 || h <= 0 || entries.isEmpty()) return false
        val nt = Grouping.norm(text)
        val l = (rect.left + offX).toFloat() / w
        val t = (rect.top + offY).toFloat() / h
        val r = (rect.right + offX).toFloat() / w
        val b = (rect.bottom + offY).toFloat() / h
        for (e in entries) if (matches(e, nt, l, t, r, b)) return true
        return false
    }

    /** Tambahkan kalau belum ada entri yang cocok. */
    @Synchronized
    fun ensure(ctx: Context, text: String, l: Float, t: Float, r: Float, b: Float) {
        val list = load(ctx)
        val nt = Grouping.norm(text)
        if (nt.isEmpty()) return
        for (e in list) if (matches(e, nt, l, t, r, b)) return
        list.add(Entry(nt, l, t, r, b))
        while (list.size > MAX_ENTRIES) list.removeAt(0)
        save(ctx, list)
    }

    @Synchronized
    fun removeMatching(ctx: Context, text: String, l: Float, t: Float, r: Float, b: Float) {
        val list = load(ctx)
        val nt = Grouping.norm(text)
        val keep = ArrayList<Entry>()
        for (e in list) if (!matches(e, nt, l, t, r, b)) keep.add(e)
        if (keep.size != list.size) save(ctx, keep)
    }

    @Synchronized
    fun clear(ctx: Context) {
        save(ctx, emptyList())
    }
}
