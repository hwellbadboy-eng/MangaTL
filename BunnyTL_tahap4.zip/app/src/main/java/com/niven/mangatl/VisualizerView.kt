package com.niven.mangatl

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.os.SystemClock
import android.view.Gravity
import android.view.View
import android.widget.FrameLayout
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.exp
import kotlin.math.ceil
import kotlin.math.floor
import kotlin.math.log10
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow
import kotlin.math.sqrt

/**
 * Visualizer spektrum + gelombang. Sampel dibaca dari VisTap (hasil akhir rantai DSP),
 * dianalisis dengan FFT sungguhan. Semua parameter dari fitur "Visualizer".
 */
class VisualizerView(c: Context) : View(c) {

    private val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFFFFFFFF.toInt() }
    private val peakPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFFFFFFFF.toInt() }
    private val wavePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = 0x59FFFFFF
        style = Paint.Style.STROKE
        strokeWidth = 1.5f * c.resources.displayMetrics.density
    }
    /** Gaya dari pengaturan "Display Style": 0 = Kotak (batang saja), 1 = Terbentang (batang + puncak + gelombang). */
    private val compact: Boolean
        get() = AudioEngine.raw(AudioEngine.VIS).let { it.size > 13 && it[13].toInt() == 0 }

    /** 1 = ukuran asli (layar pemutar). Pratinjau mini di halaman pengaturan memakai skala kecil. */
    var uiScale = 1f

    private val rect = RectF()
    private val path = Path()

    private var running = false
    private var lastT = 0L
    private var bars = FloatArray(64)
    private var peaks = FloatArray(64)
    private var holdT = FloatArray(64)
    private var target = FloatArray(64)
    private var buf = FloatArray(8192)
    private var re = DoubleArray(8192)
    private var im = DoubleArray(8192)
    private var win = DoubleArray(0)
    private var winN = 0
    private var wave = FloatArray(8192)
    private var lastPos = 0
    private var lastMove = 0L
    private var frame = 0

    private val loop = object : Runnable {
        override fun run() {
            if (!running) return
            step()
            invalidate()
            val fps = AudioEngine.get(AudioEngine.VIS, 7).coerceIn(15f, 120f)
            postDelayed(this, (1000f / fps).toLong())
        }
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        if (windowVisibility == VISIBLE) start()
    }

    override fun onDetachedFromWindow() {
        stop()
        super.onDetachedFromWindow()
    }

    override fun onVisibilityChanged(changed: View, visibility: Int) {
        super.onVisibilityChanged(changed, visibility)
        if (visibility == VISIBLE && isAttachedToWindow && windowVisibility == VISIBLE) start() else stop()
    }

    /** Halaman tertutup halaman lain / layar mati / app ke background: berhenti total. */
    override fun onWindowVisibilityChanged(visibility: Int) {
        super.onWindowVisibilityChanged(visibility)
        if (visibility == VISIBLE && isAttachedToWindow && getVisibility() == VISIBLE) start() else stop()
    }

    private fun start() {
        if (running) return
        running = true
        VisTap.viewers++
        lastT = SystemClock.uptimeMillis()
        post(loop)
    }

    private fun stop() {
        if (running) VisTap.viewers = max(0, VisTap.viewers - 1)
        running = false
        removeCallbacks(loop)
    }

    private fun applyLayout(v: FloatArray) {
        val d = resources.displayMetrics.density
        val hPx = (v.getOrElse(14) { 64f }.coerceIn(16f, 300f) * d * uiScale).toInt()
        val parentW = (parent as? View)?.width ?: return
        if (parentW <= 0) return
        val wPx = (parentW * v.getOrElse(15) { 100f }.coerceIn(20f, 100f) / 100f).toInt()
        val lp = layoutParams as? FrameLayout.LayoutParams ?: return
        if (lp.height != hPx || lp.width != wPx) {
            lp.width = wPx
            lp.height = hPx
            lp.gravity = Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL
            layoutParams = lp
        }
        translationX = v.getOrElse(16) { 0f } * d * uiScale
        translationY = v.getOrElse(17) { 0f } * d * uiScale
    }

    private fun ensure(nBars: Int) {
        if (bars.size != nBars) {
            bars = FloatArray(nBars)
            peaks = FloatArray(nBars)
            holdT = FloatArray(nBars)
            target = FloatArray(nBars)
        }
    }

    private fun step() {
        val v = AudioEngine.raw(AudioEngine.VIS)
        if (v.size < 13) return
        applyLayout(v)
        val n = 256 shl v[0].toInt().coerceIn(0, 5)
        val nBars = v[2].toInt().coerceIn(8, 256)
        ensure(nBars)
        val smooth = v[3] / 100f
        val sens = v[4]
        val atk = max(1f, v[5])
        val dec = max(10f, v[6])
        val hold = v[8]
        val logScale = v[9].toInt() == 1
        val stereo = v[10].toInt() == 0
        val quality = v[12].toInt()
        val now = SystemClock.uptimeMillis()
        val dt = (now - lastT).coerceIn(1L, 200L).toFloat()
        lastT = now

        // tanpa data baru dari audio = diam
        val pos = VisTap.pos
        if (pos != lastPos) {
            lastPos = pos
            lastMove = now
        }
        val live = now - lastMove < 200
        frame++
        val skip = quality == 0 && (frame and 1) == 1
        if (!skip) {
            val lag = AudioEngine.meterBufferMs
            if (live && VisTap.enabled) {
                if (stereo) {
                    val half = nBars / 2
                    spectrum(0, n, half, 0, logScale, sens, quality, lag)
                    spectrum(1, n, nBars - half, half, logScale, sens, quality, lag)
                } else {
                    spectrum(2, n, nBars, 0, logScale, sens, quality, lag)
                }
                if (!compact) {
                    val wn = v[11].toInt().coerceIn(256, 8192)
                    VisTap.read(wave, wn, 2, lag)
                    waveN = wn
                }
            } else {
                java.util.Arrays.fill(target, 0f)
                waveN = 0
            }
        }
        // jabat tangan spasial
        if (smooth > 0f) {
            val k = smooth * 0.6f
            val tmp = target.copyOf()
            for (i in 0 until nBars) {
                val a = tmp[max(0, i - 1)]
                val b = tmp[min(nBars - 1, i + 1)]
                target[i] = tmp[i] * (1 - k) + (a + b) * 0.5f * k
            }
        }
        val ka = 1f - exp(-dt / atk)
        val kd = 1f - exp(-dt / dec)
        for (i in 0 until nBars) {
            val t = target[i]
            bars[i] += (t - bars[i]) * (if (t > bars[i]) ka else kd)
            if (bars[i] >= peaks[i]) {
                peaks[i] = bars[i]
                holdT[i] = 0f
            } else {
                holdT[i] += dt
                if (holdT[i] > hold) peaks[i] = max(bars[i], peaks[i] - dt * 0.0012f)
            }
        }
    }

    private var waveN = 0

    private fun spectrum(which: Int, n: Int, nb: Int, off: Int, logScale: Boolean, sens: Float, quality: Int, lag: Float) {
        VisTap.read(buf, n, which, lag)
        if (winN != n) {
            win = DoubleArray(n) { 0.5 - 0.5 * cos(2.0 * PI * it / (n - 1)) }
            winN = n
            re = DoubleArray(n)
            im = DoubleArray(n)
        }
        var ws = 0.0
        for (i in 0 until n) {
            val w = if (quality == 0) 1.0 else win[i]
            re[i] = buf[i] * w
            im[i] = 0.0
            ws += w
        }
        Fft.transform(re, im, false)
        val sr = VisTap.sampleRate.toDouble()
        val binHz = sr / n
        val maxF = min(20000.0, sr / 2.0 - binHz)
        val floorDb = -60f - sens * 0.6f
        val ceilDb = -10f
        for (b in 0 until nb) {
            val f0: Double
            val f1: Double
            if (logScale) {
                f0 = 20.0 * (maxF / 20.0).pow(b.toDouble() / nb)
                f1 = 20.0 * (maxF / 20.0).pow((b + 1.0) / nb)
            } else {
                f0 = 20.0 + (maxF - 20.0) * b / nb
                f1 = 20.0 + (maxF - 20.0) * (b + 1.0) / nb
            }
            var m = 0.0
            val i0 = floor(f0 / binHz).toInt()
            val i1 = ceil(f1 / binHz).toInt()
            if (i1 - i0 <= 1 && quality >= 2) {
                // lebar batang < 1 bin: interpolasi antar-bin
                val fc = (f0 + f1) / 2 / binHz
                val a = fc.toInt().coerceIn(1, n / 2 - 2)
                val fr = fc - a
                m = mag(a) * (1 - fr) + mag(a + 1) * fr
            } else {
                for (i in max(1, i0)..min(n / 2 - 1, max(i1, i0 + 1))) m = max(m, mag(i))
            }
            val norm = m * 2.0 / ws
            var db = (20.0 * log10(norm + 1e-9)).toFloat()
            // kompensasi miring agar treble tidak selalu rendah (+3 dB/oktaf di atas 1 kHz)
            val fm = (f0 + f1) / 2
            db += (3.0 * log10(max(fm, 100.0) / 1000.0) / log10(2.0)).toFloat()
            target[off + b] = ((db - floorDb) / (ceilDb - floorDb)).coerceIn(0f, 1f)
        }
    }

    private fun mag(i: Int): Double = sqrt(re[i] * re[i] + im[i] * im[i])

    override fun onDraw(canvas: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        val v = AudioEngine.raw(AudioEngine.VIS)
        val quality = if (v.size > 12) v[12].toInt() else 2
        paint.isAntiAlias = quality >= 1
        wavePaint.isAntiAlias = quality >= 1
        val n = bars.size
        val gap = w / n * (if (v.size > 18) v[18] else 20f).coerceIn(0f, 80f) / 100f
        val bw = (w - gap * (n - 1)) / n
        paint.alpha = 178
        for (i in 0 until n) {
            val x = i * (bw + gap)
            val bh = max(if (compact) 3f else 1.5f, bars[i] * h)
            rect.set(x, h - bh, x + bw, h)
            if (quality >= 2) canvas.drawRoundRect(rect, min(2f, bw / 2), min(2f, bw / 2), paint) else canvas.drawRect(rect, paint)
            if (!compact && peaks[i] > 0.02f && peaks[i] > bars[i] + 0.01f) {
                val py = h - peaks[i] * h
                peakPaint.alpha = 220
                canvas.drawRect(x, py - 2f, x + bw, py, peakPaint)
            }
        }
        if (!compact && waveN > 1) {
            val pts = min(waveN, max(2, (w / 2).toInt()))
            path.reset()
            val step = waveN.toFloat() / pts
            for (i in 0 until pts) {
                var s = wave[min(waveN - 1, (i * step).toInt())]
                s = s.coerceIn(-1f, 1f)
                val x = i * w / (pts - 1)
                val y = h * (0.5f - 0.45f * s)
                if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
            }
            canvas.drawPath(path, wavePaint)
        }
    }
}
