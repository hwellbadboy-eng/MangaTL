package com.niven.mangatl

import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.transformer.ProgressHolder
import androidx.media3.transformer.Transformer
import androidx.media3.ui.AspectRatioFrameLayout
import androidx.media3.ui.PlayerView
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.util.Locale

/**
 * Editor video dasar: pisah klip, hapus bagian, percepat/perlambat, sambung video/foto,
 * tambah lagu. Hasil disimpan dengan resolusi dan bitrate mengikuti video asli.
 */
class VideoEditActivity : AppCompatActivity() {

    internal var clips = ArrayList<Clip>()
    internal var segs = ArrayList<Seg>()
    internal var ovs = ArrayList<Ov>()
    internal val history = ArrayList<Snap>()
    internal var sel = -1
    internal var selA = -1
    internal var selO = -1
    internal var curSeg = -1
    internal var playhead = 0L

    internal var song: Uri? = null
    internal var songDur = 0L
    internal var songVol = 1f
    internal var origVol = 1f

    internal lateinit var origUri: Uri
    internal var origName = "video.mp4"
    internal var origRel = ""

    internal lateinit var player: ExoPlayer
    internal var audioPlayer: ExoPlayer? = null
    private lateinit var playerView: PlayerView
    internal lateinit var timeline: TimelineView
    private lateinit var tvTime: TextView
    private lateinit var fadeCover: View
    internal lateinit var pvBox: FrameLayout
    internal lateinit var stage: FrameLayout
    internal lateinit var ovBar: View
    private lateinit var tvZoom: TextView
    internal var selBox: View? = null
    internal lateinit var canvasFrame: FrameLayout
    internal var canvasKey = "asli"
    internal var ovExtra: List<View> = emptyList()
    internal var pendingHistory = false
    internal var needRebuild = false
    internal var needOvRebuild = false

    // gerakan di pratinjau (geser dan cubit lapisan)
    internal var stLastX = 0f
    internal var stLastY = 0f
    internal var stDownX = 0f
    internal var stDownY = 0f
    internal var stMoved = false
    internal var stHit = -1
    internal var stHist = false
    private lateinit var btnPlay: ImageButton

    internal val handler = Handler(Looper.getMainLooper())
    internal var transformer: Transformer? = null
    internal var progressBar: ProgressBar? = null
    internal var tvPct: TextView? = null
    internal var progressDlg: AlertDialog? = null
    internal var outFile: File? = null
    internal var exporting = false
    internal var pendingWrite: (() -> Unit)? = null

    private val addPicker = registerForActivityResult(
        ActivityResultContracts.OpenMultipleDocuments()
    ) { uris ->
        if (uris.isEmpty()) return@registerForActivityResult
        lifecycleScope.launch {
            val loaded = withContext(Dispatchers.IO) { uris.mapNotNull { loadClip(it) } }
            if (loaded.isEmpty()) {
                toast("File tidak bisa dibuka.")
                return@launch
            }
            pushHistory()
            var idx = 0
            if (clips.isNotEmpty()) {
                val (i, off) = locate(playhead)
                val c = clips[i]
                idx = if (!c.photo && off >= 300L && c.dur() - off >= 300L) {
                    val srcOff = (off * c.speed).toLong()
                    val a = c.copy()
                    a.end = c.start + srcOff
                    a.fadeOut = 0L
                    a.clampFades()
                    val b = c.copy()
                    b.start = c.start + srcOff
                    b.fadeIn = 0L
                    b.clampFades()
                    clips[i] = a
                    clips.add(i + 1, b)
                    i + 1
                } else if (off >= c.dur() / 2) i + 1 else i
            }
            clips.addAll(idx, loaded)
            sel = idx
            selA = -1
            selO = -1
            var before = 0L
            for (k in 0 until idx) before += clips[k].dur()
            rebuild(before)
            toast("Ditambahkan di posisi garis putih.")
        }
    }

    internal val ovPicker = registerForActivityResult(
        ActivityResultContracts.OpenMultipleDocuments()
    ) { uris ->
        if (uris.isEmpty() || clips.isEmpty()) return@registerForActivityResult
        lifecycleScope.launch {
            val loaded = withContext(Dispatchers.IO) { uris.mapNotNull { loadClip(it) } }
            if (loaded.isEmpty()) {
                toast("File tidak bisa dibuka.")
                return@launch
            }
            pushHistory()
            val tot = total()
            val start = if (tot - playhead < 500L) 0L else playhead
            for (c in loaded) {
                val o = ovFrom(c, start, tot)
                fitOv(o, false)
                ovs.add(o)
            }
            rebuildOverlays()
            selectItem(TimelineView.K_OV, ovs.lastIndex)
            pushTimeline()
            toast("Lapisan ditambahkan di posisi garis putih.")
        }
    }

    internal val writeLauncher = registerForActivityResult(
        ActivityResultContracts.StartIntentSenderForResult()
    ) { r ->
        val cb = pendingWrite
        pendingWrite = null
        if (r.resultCode == RESULT_OK) cb?.invoke() else {
            toast("Izin tulis ditolak. Video asli tidak diubah.")
            outFile?.delete()
        }
    }

    // ------------------------------------------------------------------ UI

    internal fun dp(v: Int) = Ui.dp(this, v)
    internal fun clr(id: Int) = ContextCompat.getColor(this, id)
    internal fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()

    private fun label(text: String) = TextView(this).apply {
        this.text = text
        textSize = 11f
        setTextColor(clr(R.color.muted))
        setPadding(0, 0, 0, dp(4))
    }

    private fun tool(icon: Int, name: String, onClick: () -> Unit): View {
        val l = LinearLayout(this)
        l.orientation = LinearLayout.VERTICAL
        l.gravity = Gravity.CENTER
        l.setPadding(0, dp(8), 0, dp(8))
        l.layoutParams = LinearLayout.LayoutParams(dp(68), ViewGroup.LayoutParams.WRAP_CONTENT)
        val iv = ImageView(this)
        iv.setImageResource(icon)
        iv.setColorFilter(Color.WHITE)
        iv.layoutParams = LinearLayout.LayoutParams(dp(22), dp(22))
        l.addView(iv)
        l.addView(TextView(this).apply {
            text = name
            textSize = 11f
            gravity = Gravity.CENTER
            setTextColor(clr(R.color.text_soft))
            maxLines = 1
            setPadding(0, dp(2), 0, 0)
        })
        l.setOnClickListener { onClick() }
        return l
    }

    private fun iconButton(res: Int, desc: String, onClick: () -> Unit): ImageButton {
        val b = ImageButton(this)
        b.setImageResource(res)
        b.setColorFilter(Color.WHITE)
        b.contentDescription = desc
        b.setBackgroundColor(Color.TRANSPARENT)
        b.setPadding(dp(10), dp(10), dp(10), dp(10))
        b.setOnClickListener { onClick() }
        return b
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val uriStr = intent.getStringExtra("uri")
        if (uriStr == null) {
            finish()
            return
        }
        origUri = Uri.parse(uriStr)
        origName = intent.getStringExtra("name") ?: "video.mp4"
        origRel = intent.getStringExtra("rel") ?: ""

        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setBackgroundColor(clr(R.color.bg))
        root.setPadding(dp(12), dp(8), dp(12), dp(8))

        // bilah atas
        val top = LinearLayout(this)
        top.orientation = LinearLayout.HORIZONTAL
        top.gravity = Gravity.CENTER_VERTICAL
        top.addView(iconButton(R.drawable.ic_back, "Kembali") { askLeave() })
        top.addView(TextView(this).apply {
            text = "Edit video"
            textSize = 16f
            typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
            setTextColor(Color.WHITE)
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
                .apply { marginStart = dp(6) }
        })
        top.addView(iconButton(R.drawable.ic_undo, "Urungkan") { undo() })
        top.addView(TextView(this).apply {
            text = "Simpan"
            textSize = 13f
            typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
            setTextColor(Color.parseColor("#000000"))
            setPadding(dp(16), dp(8), dp(16), dp(8))
            background = GradientDrawable().apply {
                setColor(Color.parseColor("#F2F2F2"))
                cornerRadius = dp(14).toFloat()
            }
            setOnClickListener { askSave() }
        })
        root.addView(top)

        // pratinjau
        val pv = FrameLayout(this)
        pv.setBackgroundColor(Color.BLACK)
        pv.layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f)
            .apply { topMargin = dp(8) }
        playerView = PlayerView(this)
        playerView.useController = false
        playerView.setShutterBackgroundColor(Color.BLACK)
        canvasFrame = FrameLayout(this)
        canvasFrame.setBackgroundColor(Color.BLACK)
        canvasFrame.foreground = GradientDrawable().apply {
            setColor(Color.TRANSPARENT)
            setStroke(dp(1), Color.parseColor("#2A2A2E"))
        }
        pv.addView(canvasFrame, FrameLayout.LayoutParams(-1, -1, Gravity.CENTER))
        canvasFrame.addView(playerView, FrameLayout.LayoutParams(-1, -1))
        fadeCover = View(this)
        fadeCover.setBackgroundColor(Color.BLACK)
        fadeCover.alpha = 0f
        canvasFrame.addView(fadeCover, FrameLayout.LayoutParams(-1, -1))
        setupStage(pv)
        btnPlay = iconButton(R.drawable.ic_play, "Putar") { togglePlay() }
        pv.addView(btnPlay, FrameLayout.LayoutParams(dp(64), dp(64), Gravity.CENTER))
        tvTime = TextView(this).apply {
            textSize = 12f
            setTextColor(clr(R.color.text_soft))
            setPadding(dp(10), 0, 0, dp(8))
        }
        pv.addView(tvTime, FrameLayout.LayoutParams(-2, -2, Gravity.BOTTOM or Gravity.START))
        pvBox = pv
        root.addView(pv)
        ovBar = buildOvBar()
        root.addView(ovBar)

        // timeline
        val card = LinearLayout(this)
        card.orientation = LinearLayout.VERTICAL
        card.setBackgroundResource(R.drawable.bg_card)
        card.setPadding(dp(12), dp(10), dp(12), dp(12))
        card.layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            .apply { topMargin = dp(10) }
        val zr = LinearLayout(this)
        zr.orientation = LinearLayout.HORIZONTAL
        zr.gravity = Gravity.END or Gravity.CENTER_VERTICAL
        zr.addView(chip("−") { timeline.zoomBy(1f / 1.5f) })
        tvZoom = TextView(this).apply {
            text = "1.0x"
            textSize = 12f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            minWidth = dp(48)
        }
        zr.addView(tvZoom)
        zr.addView(chip("+") { timeline.zoomBy(1.5f) })
        card.addView(zr)

        timeline = TimelineView(this)
        timeline.layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, timeline.wantedHeightPx(0))
        timeline.onScrub = { ms, pick -> scrub(ms, pick) }
        timeline.onSelect = { k, i -> selectItem(k, i) }
        timeline.onDragStart = { pendingHistory = true }
        timeline.onEdit = { k, i, m, ms -> editItem(k, i, m, ms) }
        timeline.onBend = { k, i, isIn, x, y -> bendItem(k, i, isIn, x, y) }
        timeline.onZoomChanged = { z -> tvZoom.text = String.format(Locale.US, "%.1fx", z) }
        timeline.onDragEnd = {
            pendingHistory = false
            if (needRebuild) {
                needRebuild = false
                rebuild(playhead.coerceAtMost(total()))
            }
            if (needOvRebuild) {
                needOvRebuild = false
                rebuildOverlays()
            }
        }
        card.addView(timeline)
        root.addView(card)

        // alat
        val tools = LinearLayout(this)
        tools.orientation = LinearLayout.HORIZONTAL
        tools.addView(tool(R.drawable.ic_cut, "Pisah") { split() })
        tools.addView(tool(R.drawable.ic_trash, "Hapus") { deleteSel() })
        tools.addView(tool(R.drawable.ic_prev, "Geser kiri") { moveSel(-1) })
        tools.addView(tool(R.drawable.ic_next, "Geser kanan") { moveSel(1) })
        tools.addView(tool(R.drawable.ic_speed, "Kecepatan") { speedDialog() })
        tools.addView(tool(R.drawable.ic_movie, "Video/foto") { addPicker.launch(arrayOf("video/*", "image/*")) })
        tools.addView(tool(R.drawable.ic_layers, "Lapisan") { addLayer() })
        tools.addView(tool(R.drawable.ic_trim, "Ukuran") { canvasDialog() })
        tools.addView(tool(R.drawable.ic_music_note, "Lagu") { pickSong() })
        tools.addView(tool(R.drawable.ic_volume, "Suara") { volumeDialog() })
        val hs = HorizontalScrollView(this)
        hs.isHorizontalScrollBarEnabled = false
        hs.addView(tools)
        hs.layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            .apply { topMargin = dp(6) }
        root.addView(hs)

        setContentView(root)

        player = ExoPlayer.Builder(this, Decoders.factory(this, Prefs.decoder(this))).build()
        playerView.player = player
        player.addListener(object : Player.Listener {
            override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) = applySpeed()
            override fun onIsPlayingChanged(isPlaying: Boolean) {
                btnPlay.setImageResource(if (isPlaying) R.drawable.ic_pause else R.drawable.ic_play)
                if (isPlaying) {
                    handler.post(tick)
                } else {
                    playhead = globalNow()
                }
                syncAudio(isPlaying)
                syncOverlays(true)
            }

            override fun onPlaybackStateChanged(playbackState: Int) {
                if (playbackState == Player.STATE_ENDED) {
                    player.pause()
                    playhead = 0L
                    rebuild(0L)
                }
            }
        })
        playerView.setOnClickListener { togglePlay() }

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() = askLeave()
        })

        lifecycleScope.launch {
            val c = withContext(Dispatchers.IO) { loadClip(origUri) }
            if (c == null) {
                toast("Video tidak bisa dibuka.")
                finish()
                return@launch
            }
            clips.add(c)
            rebuild(0L)
            canvasDialog()
        }
    }

    // ------------------------------------------------------------------ data klip

    private fun loadClip(uri: Uri): Clip? {
        val type = contentResolver.getType(uri) ?: ""
        if (type.startsWith("image/")) {
            return try {
                val o = BitmapFactory.Options()
                o.inJustDecodeBounds = true
                contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, o) }
                Clip(uri, true, 0L, 0L, 0L, 1f, o.outWidth, o.outHeight, 0)
            } catch (e: Exception) {
                null
            }
        }
        val r = MediaMetadataRetriever()
        return try {
            r.setDataSource(this, uri)
            val dur = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L
            var w = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH)?.toIntOrNull() ?: 0
            var h = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT)?.toIntOrNull() ?: 0
            val rot = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_ROTATION)?.toIntOrNull() ?: 0
            if (rot == 90 || rot == 270) {
                val t = w
                w = h
                h = t
            }
            val br = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_BITRATE)?.toIntOrNull() ?: 0
            if (dur <= 0L) null else Clip(uri, false, dur, 0L, dur, 1f, w, h, br)
        } catch (e: Exception) {
            null
        } finally {
            try {
                r.release()
            } catch (e: Exception) {
            }
        }
    }

    internal fun total() = clips.sumOf { it.dur() }

    internal fun locate(g: Long): Pair<Int, Long> {
        var acc = 0L
        for (i in clips.indices) {
            val d = clips[i].dur()
            if (g < acc + d || i == clips.lastIndex) return i to (g - acc).coerceIn(0L, d)
            acc += d
        }
        return 0 to 0L
    }

    private fun globalNow(): Long {
        val i = player.currentMediaItemIndex
        if (i !in clips.indices) return playhead
        var acc = 0L
        for (k in 0 until i) acc += clips[k].dur()
        val pos = player.currentPosition.coerceAtLeast(0L)
        val c = clips[i]
        val off = if (c.photo) pos else (pos / c.speed).toLong()
        return acc + off.coerceAtMost(c.dur())
    }

    internal fun pushHistory() {
        history.add(Snap(clips.map { it.copy() }, segs.map { it.copy() }, ovs.map { it.copy() }))
        if (history.size > 40) history.removeAt(0)
    }

    private fun undo() {
        if (history.isEmpty()) {
            toast("Tidak ada yang bisa diurungkan.")
            return
        }
        val snap = history.removeAt(history.size - 1)
        releaseOverlays()
        clips = ArrayList(snap.clips)
        segs = ArrayList(snap.segs)
        ovs = ArrayList(snap.ovs)
        sel = -1
        selA = -1
        selO = -1
        if (segs.isEmpty() && song != null) clearSong()
        rebuildOverlays()
        rebuild(playhead.coerceAtMost(total()))
    }

    // ------------------------------------------------------------------ pratinjau

    internal fun rebuild(seekGlobal: Long) {
        if (clips.isEmpty()) return
        val items = clips.map { c ->
            val b = MediaItem.Builder().setUri(c.uri)
            if (c.photo) {
                contentResolver.getType(c.uri)?.let { b.setMimeType(it) }
                b.setImageDurationMs(c.photoMs)
            } else {
                b.setClippingConfiguration(
                    MediaItem.ClippingConfiguration.Builder()
                        .setStartPositionMs(c.start)
                        .setEndPositionMs(c.end)
                        .build()
                )
            }
            b.build()
        }
        playhead = seekGlobal.coerceIn(0L, total())
        val (i, off) = locate(playhead)
        val c = clips[i]
        val inClip = if (c.photo) off else (off * c.speed).toLong()
        player.setMediaItems(items, i, inClip)
        player.volume = origVol
        player.prepare()
        applySpeed()
        pushTimeline()
        pvBox.post { layoutStage() }
    }

    internal fun pushTimeline() {
        var acc = 0L
        val m = clips.mapIndexed { i, c ->
            val item = TimelineView.Item(
                acc, c.dur(),
                if (c.photo) "Foto" else ('A' + (i % 26)).toString(),
                if (!c.photo && c.speed != 1f) TimelineView.fmtSpeed(c.speed) else null,
                c.photo, c.fade()
            )
            acc += c.dur()
            item
        }
        val ov = ovs.mapIndexed { i, o -> TimelineView.Item(o.start, o.dur(), "L" + (i + 1), null, o.photo, o.fade()) }
        val au = segs.map { TimelineView.Item(it.start, it.len(), "Lagu", null, false, it.fade()) }
        val h = timeline.wantedHeightPx(ovs.size)
        if (timeline.layoutParams.height != h) {
            timeline.layoutParams.height = h
            timeline.requestLayout()
        }
        timeline.setData(m, ov, au)
        timeline.selV = sel
        timeline.selO = selO
        timeline.selA = selA
        timeline.playheadMs = playhead
        updateOvBar()
        updateTime()
        syncOverlays(false)
    }

    private fun updateTime() {
        tvTime.text = Library.fmt(playhead) + " / " + Library.fmt(total())
        applyFadePreview()
    }

    /** Pratinjau pudar video: layar menggelap sesuai kurva di posisi putar. */
    private fun applyFadePreview() {
        if (clips.isEmpty()) return
        val (i, off) = locate(playhead)
        val c = clips[i]
        fadeCover.alpha = 1f - TimelineView.fadeGain(off, c.dur(), c.fade())
    }

    internal fun applySpeed() {
        val i = player.currentMediaItemIndex
        val s = if (i in clips.indices && !clips[i].photo) clips[i].speed else 1f
        player.setPlaybackSpeed(s)
        playerView.resizeMode =
            if (i in clips.indices && clips[i].fill) AspectRatioFrameLayout.RESIZE_MODE_ZOOM else AspectRatioFrameLayout.RESIZE_MODE_FIT
    }

    private val tick = object : Runnable {
        override fun run() {
            if (!player.isPlaying) return
            playhead = globalNow()
            timeline.playheadMs = playhead
            updateTime()
            audioTick()
            syncOverlays(false)
            handler.postDelayed(this, 50)
        }
    }

    internal fun togglePlay() {
        if (player.isPlaying) player.pause() else player.play()
    }

    private fun scrub(ms: Long, pick: Boolean) {
        if (clips.isEmpty() || exporting) return
        playhead = ms.coerceIn(0L, total())
        val (i, off) = locate(playhead)
        if (pick) {
            sel = i
            selA = -1
            selO = -1
        }
        val c = clips[i]
        val inClip = if (c.photo) off else (off * c.speed).toLong()
        player.seekTo(i, inClip)
        applySpeed()
        timeline.selV = sel
        timeline.selO = selO
        timeline.selA = selA
        updateOvBar()
        timeline.playheadMs = playhead
        updateTime()
        audioPlayer?.pause()
        curSeg = -1
        syncOverlays(true)
    }

    private fun syncAudio(playing: Boolean) {
        if (playing) audioTick() else audioPlayer?.pause()
    }

    /** Jalankan lagu hanya saat posisi putar ada di salah satu potongan lagu, dengan volume mengikuti kurva pudar. */
    private fun audioTick() {
        val a = audioPlayer ?: return
        var found = -1
        for (k in segs.indices) {
            val sg = segs[k]
            if (playhead >= sg.start && playhead < sg.end()) {
                found = k
                break
            }
        }
        if (player.isPlaying && found >= 0) {
            val sg = segs[found]
            val rel = playhead - sg.start
            if (!a.isPlaying || curSeg != found) {
                a.seekTo(sg.from + rel)
                a.play()
                curSeg = found
            }
            a.volume = songVol * TimelineView.fadeGain(rel, sg.len(), sg.fade())
        } else if (a.isPlaying) {
            a.pause()
            curSeg = -1
        }
    }

    // ------------------------------------------------------------------ alat

    internal fun selectItem(kind: Int, idx: Int) {
        sel = if (kind == TimelineView.K_MAIN) idx else -1
        selO = if (kind == TimelineView.K_OV) idx else -1
        selA = if (kind == TimelineView.K_AUDIO) idx else -1
        timeline.selV = sel
        timeline.selO = selO
        timeline.selA = selA
        updateOvBar()
        placeAllOverlays()
    }

    internal fun snapFade(ms: Long) = if (ms < 150L) 0L else ms

    /** Simpan riwayat Urungkan tepat sebelum perubahan pertama dalam satu tarikan. */
    internal fun commitPending() {
        if (pendingHistory) {
            pendingHistory = false
            pushHistory()
        }
    }

    internal fun clampTo(v: Long, lo: Long, hi: Long) = if (hi < lo) lo else v.coerceIn(lo, hi)

    // ------------------------------------------------------------------ edit dari timeline

    internal fun fadableOf(kind: Int, i: Int): Fadable? = when (kind) {
        TimelineView.K_MAIN -> clips.getOrNull(i)
        TimelineView.K_OV -> ovs.getOrNull(i)
        TimelineView.K_AUDIO -> segs.getOrNull(i)
        else -> null
    }

    // ------------------------------------------------------------------ lapisan video

    internal fun chip(label: String, onClick: () -> Unit): TextView = TextView(this).apply {
        text = label
        textSize = 12f
        setTextColor(Color.WHITE)
        gravity = Gravity.CENTER
        setPadding(dp(12), dp(7), dp(12), dp(7))
        setBackgroundResource(R.drawable.bg_field)
        setOnClickListener { onClick() }
    }

    internal val canvasOpts = listOf(
        Triple("asli", "Asli (otomatis)", "Mengikuti video atau foto pertama"),
        Triple("916", "9:16", "1080 × 1920"),
        Triple("169", "16:9", "1920 × 1080"),
        Triple("11", "1:1", "1080 × 1080"),
        Triple("45", "4:5", "1080 × 1350")
    )

    /** Samakan lapisan dengan posisi putar: tampil hanya di rentangnya, ikut pudar, dan diputar bersama video utama. */
    internal fun syncOverlays(forceSeek: Boolean) {
        if (!::player.isInitialized || !::stage.isInitialized) return
        val playing = player.isPlaying
        for (o in ovs) {
            val v = o.view ?: continue
            val rel = playhead - o.start
            val on = rel >= 0L && rel < o.dur()
            v.visibility = if (on) View.VISIBLE else View.INVISIBLE
            val p = o.player
            if (!on) {
                if (p != null && o.running) {
                    p.pause()
                    o.running = false
                }
                continue
            }
            v.alpha = TimelineView.fadeGain(rel, o.dur(), o.fade())
            if (p == null) continue
            val pos = (rel * o.speed).toLong()
            if (playing) {
                if (!o.running || forceSeek) {
                    p.seekTo(pos)
                    p.play()
                    o.running = true
                }
            } else if (o.running || forceSeek) {
                p.pause()
                p.seekTo(pos)
                o.running = false
            }
        }
        selBox?.visibility = if (ovs.getOrNull(selO)?.let { ovActive(it) } == true) View.VISIBLE else View.GONE
    }

    // ------------------------------------------------------------------ simpan

    internal val progressTick = object : Runnable {
        override fun run() {
            val t = transformer ?: return
            val h = ProgressHolder()
            if (t.getProgress(h) == Transformer.PROGRESS_STATE_AVAILABLE) {
                progressBar?.progress = h.progress
                tvPct?.text = "${h.progress}%"
            }
            handler.postDelayed(this, 300)
        }
    }

    // ------------------------------------------------------------------ siklus hidup

    override fun onPause() {
        super.onPause()
        if (::player.isInitialized) player.pause()
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        transformer?.cancel()
        if (::player.isInitialized) player.release()
        audioPlayer?.release()
        releaseOverlays()
        super.onDestroy()
    }

    // ------------------------------------------------------------------ efek pudar

}
