package com.niven.mangatl

import android.content.Context
import android.net.Uri
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.CoroutineStart
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.channels.BufferOverflow
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.launch
import org.nehuatl.llamacpp.LlamaHelper
import java.io.File
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit

/**
 * Satu model .gguf yang dijalankan lewat llama.cpp (library llamacpp-kotlin).
 * Semua fungsi memblokir thread pemanggil; panggil dari thread latar belakang.
 */
class GgufLlm(context: Context) {

    private val scope = CoroutineScope(Dispatchers.IO + SupervisorJob())
    private val flow = MutableSharedFlow<LlamaHelper.LLMEvent>(
        replay = 0,
        extraBufferCapacity = 1024,
        onBufferOverflow = BufferOverflow.DROP_OLDEST
    )
    private val helper = LlamaHelper(
        contentResolver = context.contentResolver,
        scope = scope,
        sharedFlow = flow
    )

    @Volatile
    private var pending: CountDownLatch? = null

    @Volatile
    private var aborted = false

    /** Ringkasan generate terakhir, mis. "4.2 tok/s, kata pertama 3.1 dtk". Kosong kalau belum ada. */
    @Volatile
    var lastStats: String = ""
        private set

    /** Muat model. Melempar exception kalau gagal atau lebih dari 3 menit. */
    fun load(model: File, contextLength: Int) {
        val loaded = CountDownLatch(1)
        var failure: String? = null
        val watch = scope.launch(start = CoroutineStart.UNDISPATCHED) {
            flow.collect { ev ->
                if (ev is LlamaHelper.LLMEvent.Error) {
                    failure = ev.message
                    loaded.countDown()
                }
            }
        }
        try {
            helper.load(path = Uri.fromFile(model).toString(), contextLength = contextLength) {
                loaded.countDown()
            }
            if (!loaded.await(180, TimeUnit.SECONDS)) {
                throw IllegalStateException("waktu muat model habis")
            }
        } finally {
            watch.cancel()
        }
        failure?.let { throw IllegalStateException(it) }
    }

    /** Kirim prompt mentah (sudah berformat template chat), potongan teks masuk ke [onPiece]. */
    fun generate(prompt: String, onPiece: (String) -> Unit) {
        aborted = false
        val done = CountDownLatch(1)
        pending = done
        var failure: String? = null
        var stopped = false
        var tokens = 0
        var firstAt = 0L
        val startAt = System.nanoTime()
        val buf = StringBuilder()
        fun emit(t: String) {
            if (t.isNotEmpty()) onPiece(t)
        }
        // Pelanggan flow harus aktif sebelum predict, kalau tidak token awal hilang.
        val collector = scope.launch(start = CoroutineStart.UNDISPATCHED) {
            flow.collect { ev ->
                when (ev) {
                    is LlamaHelper.LLMEvent.Ongoing -> {
                        if (!stopped) {
                            if (tokens++ == 0) firstAt = System.nanoTime()
                            buf.append(ev.word)
                            val cut = ChatTemplate.firstStop(buf)
                            if (cut >= 0) {
                                // Model tidak berhenti sendiri di akhir giliran: potong di sini dan hentikan mesin.
                                emit(buf.substring(0, cut))
                                buf.setLength(0)
                                stopped = true
                                try {
                                    helper.abort()
                                } catch (_: Throwable) {
                                }
                                done.countDown()
                            } else {
                                // Tahan ekor yang mungkin awal sebuah penanda stop yang terpotong antar token.
                                val n = buf.length - ChatTemplate.stopPrefixLen(buf)
                                if (n > 0) {
                                    emit(buf.substring(0, n))
                                    buf.delete(0, n)
                                }
                            }
                        }
                    }
                    is LlamaHelper.LLMEvent.Done -> {
                        if (!stopped) {
                            emit(buf.toString())
                            buf.setLength(0)
                        }
                        done.countDown()
                    }
                    is LlamaHelper.LLMEvent.Error -> {
                        failure = ev.message
                        done.countDown()
                    }
                    else -> {}
                }
            }
        }
        try {
            helper.predict(prompt)
            done.await()
        } finally {
            pending = null
            collector.cancel()
            try {
                helper.stopPrediction()
            } catch (_: Throwable) {
            }
        }
        if (tokens > 1) {
            val genSec = (System.nanoTime() - firstAt) / 1e9
            val firstSec = (firstAt - startAt) / 1e9
            lastStats = String.format(
                java.util.Locale.US, "%.1f tok/s, kata pertama %.1f dtk",
                (tokens - 1) / genSec.coerceAtLeast(0.001), firstSec
            )
        }
        if (!aborted) failure?.let { throw IllegalStateException(it) }
    }

    fun abort() {
        aborted = true
        try {
            helper.abort()
        } catch (_: Throwable) {
        }
        pending?.countDown()
    }

    fun close() {
        abort()
        try {
            helper.release()
        } catch (_: Throwable) {
        }
        scope.cancel()
    }
}

/** Template chat untuk model GGUF. Dipilih dari nama file; yang tidak dikenal memakai ChatML (Qwen dkk). */
object ChatTemplate {

    // Penanda akhir giliran semua format; dipakai untuk menghentikan generate kalau model tidak berhenti sendiri.
    private val STOPS = listOf(
        "<end_of_turn>", "<start_of_turn>", "<|im_end|>", "<|im_start|>", "<|eot_id|>", "<|endoftext|>"
    )

    /** Posisi penanda stop paling awal di [s], atau -1. */
    fun firstStop(s: CharSequence): Int {
        var best = -1
        for (t in STOPS) {
            val i = s.indexOf(t)
            if (i >= 0 && (best < 0 || i < best)) best = i
        }
        return best
    }

    /** Panjang ekor [s] yang bisa jadi awal sebuah penanda stop (perlu ditahan dulu). */
    fun stopPrefixLen(s: CharSequence): Int {
        var best = 0
        for (t in STOPS) {
            for (k in minOf(t.length - 1, s.length) downTo best + 1) {
                if (s.endsWith(t.substring(0, k))) {
                    best = k
                    break
                }
            }
        }
        return best
    }

    /** [turns]: pasangan (dari pengguna?, teks), urutan lama ke baru, diakhiri giliran pengguna. */
    fun render(modelName: String, system: String, turns: List<Pair<Boolean, String>>): String {
        val n = modelName.lowercase()
        return when {
            n.contains("gemma") -> gemma(system, turns)
            n.contains("llama") -> llama3(system, turns)
            else -> chatml(system, turns)
        }
    }

    private fun chatml(system: String, turns: List<Pair<Boolean, String>>) = buildString {
        append("<|im_start|>system\n").append(system).append("<|im_end|>\n")
        for ((user, text) in turns) {
            append(if (user) "<|im_start|>user\n" else "<|im_start|>assistant\n")
            append(text).append("<|im_end|>\n")
        }
        append("<|im_start|>assistant\n")
    }

    // Gemma tidak punya peran system: instruksi ditaruh di awal giliran pengguna pertama.
    private fun gemma(system: String, turns: List<Pair<Boolean, String>>) = buildString {
        var first = true
        for ((user, text) in turns) {
            append(if (user) "<start_of_turn>user\n" else "<start_of_turn>model\n")
            if (user && first) append(system).append("\n\n")
            if (user) first = false
            append(text).append("<end_of_turn>\n")
        }
        append("<start_of_turn>model\n")
    }

    private fun llama3(system: String, turns: List<Pair<Boolean, String>>) = buildString {
        append("<|start_header_id|>system<|end_header_id|>\n\n").append(system).append("<|eot_id|>")
        for ((user, text) in turns) {
            append(if (user) "<|start_header_id|>user<|end_header_id|>\n\n" else "<|start_header_id|>assistant<|end_header_id|>\n\n")
            append(text).append("<|eot_id|>")
        }
        append("<|start_header_id|>assistant<|end_header_id|>\n\n")
    }
}
