package com.niven.mangatl

import android.content.Context
import android.net.Uri
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.CoroutineStart
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.channels.BufferOverflow
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.launch
import org.nehuatl.llamacpp.LlamaHelper
import java.io.File
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit

/**
 * Satu model .gguf yang dijalankan lewat llama.cpp (library llamacpp-kotlin).
 * Semua fungsi memblokir thread pemanggil; panggil dari thread latar belakang.
 */
class GgufLlm(context: Context) {

    private val scope = CoroutineScope(Dispatchers.IO + SupervisorJob())
    private val flow = MutableSharedFlow<LlamaHelper.LLMEvent>(
        replay = 0,
        extraBufferCapacity = 1024,
        onBufferOverflow = BufferOverflow.DROP_OLDEST
    )
    private val helper = LlamaHelper(
        contentResolver = context.contentResolver,
        scope = scope,
        sharedFlow = flow
    )

    @Volatile
    private var pending: CountDownLatch? = null

    @Volatile
    private var aborted = false

    /** Muat model. Melempar exception kalau gagal atau lebih dari 3 menit. */
    fun load(model: File, contextLength: Int) {
        val loaded = CountDownLatch(1)
        var failure: String? = null
        val watch = scope.launch(start = CoroutineStart.UNDISPATCHED) {
            flow.collect { ev ->
                if (ev is LlamaHelper.LLMEvent.Error) {
                    failure = ev.message
                    loaded.countDown()
                }
            }
        }
        try {
            helper.load(path = Uri.fromFile(model).toString(), contextLength = contextLength) {
                loaded.countDown()
            }
            if (!loaded.await(180, TimeUnit.SECONDS)) {
                throw IllegalStateException("waktu muat model habis")
            }
        } finally {
            watch.cancel()
        }
        failure?.let { throw IllegalStateException(it) }
    }

    /** Kirim prompt mentah (sudah berformat template chat), potongan teks masuk ke [onPiece]. */
    fun generate(prompt: String, onPiece: (String) -> Unit) {
        aborted = false
        val done = CountDownLatch(1)
        pending = done
        var failure: String? = null
        // Pelanggan flow harus aktif sebelum predict, kalau tidak token awal hilang.
        val collector = scope.launch(start = CoroutineStart.UNDISPATCHED) {
            flow.collect { ev ->
                when (ev) {
                    is LlamaHelper.LLMEvent.Ongoing -> onPiece(ev.word)
                    is LlamaHelper.LLMEvent.Done -> done.countDown()
                    is LlamaHelper.LLMEvent.Error -> {
                        failure = ev.message
                        done.countDown()
                    }
                    else -> {}
                }
            }
        }
        try {
            helper.predict(prompt)
            done.await()
        } finally {
            pending = null
            collector.cancel()
            try {
                helper.stopPrediction()
            } catch (_: Throwable) {
            }
        }
        if (!aborted) failure?.let { throw IllegalStateException(it) }
    }

    fun abort() {
        aborted = true
        try {
            helper.abort()
        } catch (_: Throwable) {
        }
        pending?.countDown()
    }

    fun close() {
        abort()
        try {
            helper.release()
        } catch (_: Throwable) {
        }
        scope.cancel()
    }
}

/** Template chat untuk model GGUF. Dipilih dari nama file; yang tidak dikenal memakai ChatML (Qwen dkk). */
object ChatTemplate {

    /** [turns]: pasangan (dari pengguna?, teks), urutan lama ke baru, diakhiri giliran pengguna. */
    fun render(modelName: String, system: String, turns: List<Pair<Boolean, String>>): String {
        val n = modelName.lowercase()
        return when {
            n.contains("gemma") -> gemma(system, turns)
            n.contains("llama") -> llama3(system, turns)
            else -> chatml(system, turns)
        }
    }

    private fun chatml(system: String, turns: List<Pair<Boolean, String>>) = buildString {
        append("<|im_start|>system\n").append(system).append("<|im_end|>\n")
        for ((user, text) in turns) {
            append(if (user) "<|im_start|>user\n" else "<|im_start|>assistant\n")
            append(text).append("<|im_end|>\n")
        }
        append("<|im_start|>assistant\n")
    }

    // Gemma tidak punya peran system: instruksi ditaruh di awal giliran pengguna pertama.
    private fun gemma(system: String, turns: List<Pair<Boolean, String>>) = buildString {
        var first = true
        for ((user, text) in turns) {
            append(if (user) "<start_of_turn>user\n" else "<start_of_turn>model\n")
            if (user && first) append(system).append("\n\n")
            if (user) first = false
            append(text).append("<end_of_turn>\n")
        }
        append("<start_of_turn>model\n")
    }

    private fun llama3(system: String, turns: List<Pair<Boolean, String>>) = buildString {
        append("<|start_header_id|>system<|end_header_id|>\n\n").append(system).append("<|eot_id|>")
        for ((user, text) in turns) {
            append(if (user) "<|start_header_id|>user<|end_header_id|>\n\n" else "<|start_header_id|>assistant<|end_header_id|>\n\n")
            append(text).append("<|eot_id|>")
        }
        append("<|start_header_id|>assistant<|end_header_id|>\n\n")
    }
}
