package com.niven.mangatl

/** Memilih ekspresi dari emoji di balasan AI. */
object Emotion {
    private val table = listOf(
        "angry" to listOf("😠", "😡", "🤬", "💢", "😤"),
        "tears" to listOf("😢", "😭", "🥺", "😞", "😿", "😔"),
        "heartEyes" to listOf("😍", "🥰", "😻", "💕", "💖", "😘", "💗", "❤"),
        "starEyes" to listOf("🤩", "✨", "🌟", "⭐"),
        "rollEyes" to listOf("🙄", "😒", "😑", "😐"),
        "dark" to listOf("😱", "😨", "😵", "😰", "💀"),
        "blush" to listOf("😊", "☺", "🙂", "😳", "😉", "😏", "😌", "😅", "😆", "😄", "😁", "😋", "😜", "😚", "🤭")
    )

    /** Ekspresi dari emoji TERAKHIR yang muncul di text[from..]; null kalau tidak ada. */
    fun scan(text: CharSequence, from: Int): String? {
        val s = text.toString()
        var bestPos = -1
        var best: String? = null
        for ((key, emojis) in table) {
            for (e in emojis) {
                val p = s.lastIndexOf(e)
                if (p >= from.coerceAtLeast(0) && p > bestPos) {
                    bestPos = p
                    best = key
                }
            }
        }
        return best
    }

    /** Nama tampilan untuk dialog ekspresi. */
    fun label(key: String): String = when (key) {
        "dark" -> "Wajah gelap"
        "blush" -> "Pipi merah"
        "blood" -> "Darah"
        "angry" -> "Marah"
        "starEyes" -> "Mata bintang"
        "rollEyes" -> "Mata putih"
        "tears" -> "Menangis"
        "heartEyes" -> "Mata hati"
        "rightHand" -> "Tangan kanan"
        "leftHand" -> "Tangan kiri"
        else -> key
    }

    /** Ekspresi emosi (saling menggantikan). Tangan tidak termasuk. */
    fun isEmotion(key: String) = key != "rightHand" && key != "leftHand"
}
