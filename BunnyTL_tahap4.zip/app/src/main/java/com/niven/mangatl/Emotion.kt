package com.niven.mangatl

/** Memilih ekspresi dari emoji di balasan AI. */
object Emotion {
    private val table = listOf(
        "angry" to listOf("😠", "😡", "🤬", "💢", "😤"),
        "tears" to listOf("😢", "😭", "🥺", "😞", "😿", "😔"),
        "heartEyes" to listOf("😍", "🥰", "😻", "💕", "💖", "😘", "💗", "❤"),
        "starEyes" to listOf("🤩", "✨", "🌟", "⭐"),
        "rollEyes" to listOf("🙄", "😒", "😑", "😐"),
        "dark" to listOf("😱", "😨", "😵", "😰", "💀", "😲", "😮", "😯", "😧", "😦"),
        "blush" to listOf("😊", "☺", "🙂", "😳", "😉", "😏", "😌", "😅", "😆", "😄", "😁", "😋", "😜", "😚", "🤭")
    )

    // Kata kunci (huruf kecil) untuk balasan tanpa emoji, mis. narasi "*tersipu malu*". "sayang" sengaja tidak dipakai
    // karena itu panggilan biasa. Emoji dan kata dinilai sama: yang muncul PALING AKHIR menang.
    private val words = listOf(
        "angry" to listOf("marah", "kesal", "jengkel", "sebal", "geram", "murka", "hmph", "ngambek", "cemberut"),
        "tears" to listOf("sedih", "menangis", "nangis", "air mata", "terisak", "kecewa", "patah hati"),
        "dark" to listOf("kaget", "terkejut", "syok", "astaga", "waduh", "ngeri", "takut", "merinding", "panik"),
        "heartEyes" to listOf("jatuh cinta", "terpesona", "gemas", "mencium", "ciuman", "memeluk", "pelukan", "mesra"),
        "starEyes" to listOf("wow", "kagum", "berbinar", "luar biasa", "keren banget", "hebat banget"),
        "rollEyes" to listOf("memutar mata", "menghela napas", "bosan"),
        "blush" to listOf("malu", "tersipu", "merona", "memerah", "salting", "tersenyum", "senyum", "menggoda")
    )

    /** Ekspresi dari emoji / kata kunci TERAKHIR yang muncul di text[from..]; null kalau tidak ada. */
    fun scan(text: CharSequence, from: Int): String? {
        val s = text.toString()
        val lower = s.lowercase()
        val start = from.coerceAtLeast(0)
        var bestPos = -1
        var best: String? = null
        for ((key, emojis) in table) {
            for (e in emojis) {
                val p = s.lastIndexOf(e)
                if (p >= start && p > bestPos) {
                    bestPos = p
                    best = key
                }
            }
        }
        for ((key, ws) in words) {
            for (w in ws) {
                val p = lower.lastIndexOf(w)
                if (p >= start && p > bestPos) {
                    bestPos = p
                    best = key
                }
            }
        }
        return best
    }

    /** Nama tampilan untuk dialog ekspresi. */
    fun label(key: String): String = when (key) {
        "dark" -> "Wajah gelap"
        "blush" -> "Pipi merah"
        "blood" -> "Darah"
        "angry" -> "Marah"
        "starEyes" -> "Mata bintang"
        "rollEyes" -> "Mata putih"
        "tears" -> "Menangis"
        "heartEyes" -> "Mata hati"
        "rightHand" -> "Tangan kanan"
        "leftHand" -> "Tangan kiri"
        else -> key
    }

    /** Ekspresi emosi (saling menggantikan). Tangan tidak termasuk. */
    fun isEmotion(key: String) = key != "rightHand" && key != "leftHand"
}
