package com.niven.mangatl

import android.annotation.SuppressLint
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.ImageDecoder
import android.graphics.Movie
import android.graphics.Paint
import android.graphics.drawable.AnimatedImageDrawable
import android.graphics.drawable.BitmapDrawable
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.provider.OpenableColumns
import android.view.View
import android.widget.ImageView
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import kotlin.math.max
import kotlin.math.min

/**
 * Banner layar Musik: foto, GIF, atau video buatan pengguna.
 * Mode 0 = loop biasa. Mode 1 = maju-mundur (ping-pong).
 *
 * Pemutar video tidak bisa memutar mundur, jadi untuk maju-mundur video/GIF diubah dulu jadi
 * kumpulan frame kecil (maks 60 frame dari 5 detik pertama, JPEG di folder banner) lalu diputar
 * maju lalu mundur. Foto tidak butuh mode (statis).
 */
class Banner(
    private val act: AppCompatActivity,
    private val pv: PlayerView,
    private val iv: ImageView,
    private val layer: View
) {
    companion object {
        private const val DIR = "music_banner"
        private const val FW = 600
        private const val MAX_FRAMES = 60
        private const val MAX_MS = 5000

        const val MODE_LOOP = 0
        const val MODE_PINGPONG = 1

        fun dir(a: AppCompatActivity) = File(a.filesDir, DIR)
    }

    private val handler = Handler(Looper.getMainLooper())
    private var player: ExoPlayer? = null
    private var gen = 0

    fun type(): String? = Prefs.str(act, "banner_type")
    fun name(): String? = Prefs.str(act, "banner_name")
    fun mode(): Int = Prefs.int(act, "banner_mode", MODE_LOOP)

    /** Titik fokus 0..1: bagian gambar yang dipertahankan waktu dipotong (0,5 = tengah). */
    fun fx(): Float = Prefs.int(act, "banner_fx", 50) / 100f
    fun fy(): Float = Prefs.int(act, "banner_fy", 50) / 100f

    /** Tinggi / lebar area banner. Diisi layar sebelum start() supaya frame maju-mundur pas bentuknya. */
    var aspect: Float = 0.75f
    private fun fh() = (FW * aspect).toInt().coerceIn(200, 900)

    private fun src(): File? =
        Prefs.str(act, "banner_file")?.let { File(dir(act), it) }?.takeIf { it.exists() }

    fun has(): Boolean = src() != null

    private fun framesReady(): Boolean = Prefs.int(act, "banner_frames", 0) >= 2

    // ------------------------------------------------------------ putar

    /** Mulai memutar banner pilihan. Mengembalikan true kalau ada banner. */
    fun start(): Boolean {
        stop()
        val f = src() ?: return false
        val my = gen
        val t = type()
        when {
            t == "photo" -> showStill(f, my)
            mode() == MODE_PINGPONG && framesReady() -> runFrames(my)
            t == "video" -> playVideo(f)
            else -> showGif(f, my)
        }
        return true
    }

    fun stop() {
        gen++
        handler.removeCallbacksAndMessages(null)
        pv.player = null
        player?.release()
        player = null
        pv.visibility = View.GONE
        pv.translationX = 0f
        pv.translationY = 0f
        pv.layoutParams = android.widget.FrameLayout.LayoutParams(-1, -1)
        iv.scaleType = ImageView.ScaleType.CENTER_CROP
        val d = iv.drawable
        if (Build.VERSION.SDK_INT >= 28 && d is AnimatedImageDrawable) d.stop()
        iv.setImageDrawable(null)
        iv.visibility = View.GONE
    }

    private fun playVideo(f: File) {
        val p = ExoPlayer.Builder(act).build()
        p.trackSelectionParameters = p.trackSelectionParameters.buildUpon()
            .setTrackTypeDisabled(C.TRACK_TYPE_AUDIO, true)
            .build()
        p.volume = 0f
        p.repeatMode = Player.REPEAT_MODE_ONE
        p.videoScalingMode = C.VIDEO_SCALING_MODE_SCALE_TO_FIT_WITH_CROPPING
        p.setMediaItem(MediaItem.fromUri(Uri.fromFile(f)))
        p.addListener(object : Player.Listener {
            override fun onVideoSizeChanged(v: androidx.media3.common.VideoSize) {
                if (v.width > 0 && v.height > 0) {
                    val w = v.width * v.pixelWidthHeightRatio
                    layer.post { placeVideo(w, v.height.toFloat()) }
                }
            }
        })
        p.prepare()
        p.playWhenReady = true
        pv.visibility = View.VISIBLE
        pv.player = p
        player = p
    }

    /** Video diperbesar sampai menutup area banner, lalu digeser sesuai titik fokus. */
    private fun placeVideo(vw: Float, vh: Float) {
        val bw = layer.width.toFloat()
        val bh = layer.height.toFloat()
        if (bw <= 0 || bh <= 0) return
        val sc = max(bw / vw, bh / vh)
        val w = vw * sc
        val h = vh * sc
        pv.resizeMode = androidx.media3.ui.AspectRatioFrameLayout.RESIZE_MODE_FIT
        pv.layoutParams = android.widget.FrameLayout.LayoutParams(w.toInt() + 1, h.toInt() + 1)
        pv.translationX = (bw - w) * fx()
        pv.translationY = (bh - h) * fy()
    }

    /** Foto/GIF: skala menutup area banner, digeser sesuai titik fokus. */
    private fun placeImage(d: android.graphics.drawable.Drawable) {
        layer.post {
            val bw = layer.width.toFloat()
            val bh = layer.height.toFloat()
            val dw = d.intrinsicWidth.toFloat()
            val dh = d.intrinsicHeight.toFloat()
            if (bw <= 0 || bh <= 0 || dw <= 0 || dh <= 0) return@post
            val sc = max(bw / dw, bh / dh)
            val m = android.graphics.Matrix()
            m.postScale(sc, sc)
            m.postTranslate((bw - dw * sc) * fx(), (bh - dh * sc) * fy())
            iv.scaleType = ImageView.ScaleType.MATRIX
            iv.imageMatrix = m
        }
    }

    private fun showStill(f: File, my: Int) {
        act.lifecycleScope.launch {
            val d = withContext(Dispatchers.IO) { loadDrawable(f) }
            if (my != gen || d == null) return@launch
            iv.setImageDrawable(d)
            iv.visibility = View.VISIBLE
            placeImage(d)
        }
    }

    @SuppressLint("NewApi")
    private fun showGif(f: File, my: Int) {
        act.lifecycleScope.launch {
            val d = withContext(Dispatchers.IO) { loadDrawable(f) }
            if (my != gen || d == null) return@launch
            iv.setImageDrawable(d)
            iv.visibility = View.VISIBLE
            placeImage(d)
            if (Build.VERSION.SDK_INT >= 28 && d is AnimatedImageDrawable) {
                d.repeatCount = AnimatedImageDrawable.REPEAT_INFINITE
                d.start()
            }
        }
    }

    /** Foto/GIF dikecilkan maksimal 1080 px supaya hemat memori. */
    @SuppressLint("NewApi")
    private fun loadDrawable(f: File): android.graphics.drawable.Drawable? = try {
        if (Build.VERSION.SDK_INT >= 28) {
            ImageDecoder.decodeDrawable(ImageDecoder.createSource(f)) { dec, info, _ ->
                val w = info.size.width
                val h = info.size.height
                val big = max(w, h)
                if (big > 1080) {
                    val r = 1080f / big
                    dec.setTargetSize((w * r).toInt().coerceAtLeast(1), (h * r).toInt().coerceAtLeast(1))
                }
            }
        } else {
            val o = BitmapFactory.Options().apply { inSampleSize = 2 }
            BitmapDrawable(act.resources, BitmapFactory.decodeFile(f.path, o))
        }
    } catch (_: Throwable) {
        null
    }

    private fun runFrames(my: Int) {
        val count = Prefs.int(act, "banner_frames", 0)
        val delay = Prefs.int(act, "banner_delay", 100).toLong().coerceIn(40L, 400L)
        act.lifecycleScope.launch {
            val list = withContext(Dispatchers.IO) {
                val o = BitmapFactory.Options().apply { inPreferredConfig = Bitmap.Config.RGB_565 }
                (0 until count).mapNotNull { BitmapFactory.decodeFile(File(dir(act), "f$it.jpg").path, o) }
            }
            if (my != gen || list.size < 2) return@launch
            iv.scaleType = ImageView.ScaleType.CENTER_CROP
            iv.visibility = View.VISIBLE
            var i = 0
            var step = 1
            val r = object : Runnable {
                override fun run() {
                    if (my != gen) return
                    iv.setImageBitmap(list[i])
                    if (i + step !in list.indices) step = -step
                    i += step
                    handler.postDelayed(this, delay)
                }
            }
            handler.post(r)
        }
    }

    // ------------------------------------------------------------ pasang / hapus

    /** Salin file pilihan ke penyimpanan aplikasi. Kalau mode maju-mundur, frame langsung disiapkan. */
    fun importFile(uri: Uri, onDone: (String?) -> Unit) {
        val mime = act.contentResolver.getType(uri) ?: ""
        val type = when {
            mime.startsWith("video/") -> "video"
            mime == "image/gif" -> "gif"
            mime.startsWith("image/") -> "photo"
            else -> null
        }
        if (type == null) {
            onDone("Pilih foto, GIF, atau video.")
            return
        }
        val ext = when (mime) {
            "image/gif" -> "gif"
            "image/png" -> "png"
            "image/webp" -> "webp"
            "video/webm" -> "webm"
            else -> if (type == "video") "mp4" else "jpg"
        }
        val name = try {
            act.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)
                ?.use { c -> if (c.moveToFirst()) c.getString(0) else null }
        } catch (_: Exception) {
            null
        } ?: "banner.$ext"
        act.lifecycleScope.launch {
            val err = withContext(Dispatchers.IO) {
                try {
                    clearFiles()
                    val out = File(dir(act), "src.$ext")
                    act.contentResolver.openInputStream(uri)!!.use { i -> out.outputStream().use { o -> i.copyTo(o) } }
                    Prefs.setStr(act, "banner_file", out.name)
                    Prefs.setStr(act, "banner_type", type)
                    Prefs.setStr(act, "banner_name", name)
                    Prefs.setInt(act, "banner_frames", 0)
                    Prefs.setInt(act, "banner_fx", 50)
                    Prefs.setInt(act, "banner_fy", 50)
                    if (type != "photo" && mode() == MODE_PINGPONG && !bake()) {
                        Prefs.setInt(act, "banner_mode", MODE_LOOP)
                        "Maju-mundur gagal disiapkan, dipakai loop biasa."
                    } else null
                } catch (t: Throwable) {
                    "Gagal menyalin banner: ${t.message}"
                }
            }
            onDone(err)
        }
    }

    /** Ganti mode. Frame maju-mundur dibuat dulu kalau belum ada. */
    fun setMode(m: Int, onDone: (String?) -> Unit) {
        Prefs.setInt(act, "banner_mode", m)
        if (m != MODE_PINGPONG || type() == "photo" || framesReady() || !has()) {
            onDone(null)
            return
        }
        act.lifecycleScope.launch {
            val ok = withContext(Dispatchers.IO) { bake() }
            if (!ok) Prefs.setInt(act, "banner_mode", MODE_LOOP)
            onDone(if (ok) null else "Maju-mundur gagal disiapkan, dipakai loop biasa.")
        }
    }

    /** Simpan titik fokus baru (0..100). Frame maju-mundur dibuat ulang kalau mode itu aktif. */
    fun setFocus(x: Int, y: Int, onDone: (String?) -> Unit) {
        Prefs.setInt(act, "banner_fx", x.coerceIn(0, 100))
        Prefs.setInt(act, "banner_fy", y.coerceIn(0, 100))
        if (mode() != MODE_PINGPONG || type() == "photo" || !has()) {
            onDone(null)
            return
        }
        act.lifecycleScope.launch {
            val ok = withContext(Dispatchers.IO) { bake() }
            if (!ok) Prefs.setInt(act, "banner_mode", MODE_LOOP)
            onDone(if (ok) null else "Maju-mundur gagal disiapkan, dipakai loop biasa.")
        }
    }

    /** Gambar utuh (frame pertama untuk video/GIF) buat layar atur posisi. Panggil di thread latar. */
    @SuppressLint("NewApi")
    fun preview(): Bitmap? {
        val f = src() ?: return null
        return try {
            if (type() == "video") {
                val mmr = MediaMetadataRetriever()
                try {
                    mmr.setDataSource(f.path)
                    mmr.getFrameAtTime(0, MediaMetadataRetriever.OPTION_CLOSEST_SYNC)
                } finally {
                    try { mmr.release() } catch (_: Throwable) {}
                }
            } else if (Build.VERSION.SDK_INT >= 28) {
                ImageDecoder.decodeBitmap(ImageDecoder.createSource(f)) { dec, info, _ ->
                    dec.allocator = ImageDecoder.ALLOCATOR_SOFTWARE
                    val big = max(info.size.width, info.size.height)
                    if (big > 1080) {
                        val r = 1080f / big
                        dec.setTargetSize((info.size.width * r).toInt().coerceAtLeast(1), (info.size.height * r).toInt().coerceAtLeast(1))
                    }
                }
            } else {
                BitmapFactory.decodeFile(f.path, BitmapFactory.Options().apply { inSampleSize = 2 })
            }
        } catch (_: Throwable) {
            null
        }
    }

    fun remove() {
        stop()
        clearFiles()
        Prefs.setStr(act, "banner_file", null)
        Prefs.setStr(act, "banner_type", null)
        Prefs.setStr(act, "banner_name", null)
        Prefs.setInt(act, "banner_frames", 0)
    }

    private fun clearFiles() {
        dir(act).deleteRecursively()
        dir(act).mkdirs()
    }

    // ------------------------------------------------------------ frame maju-mundur

    private fun cover(src: Bitmap): Bitmap {
        val fh = fh()
        val out = Bitmap.createBitmap(FW, fh, Bitmap.Config.ARGB_8888)
        val s = max(FW / src.width.toFloat(), fh / src.height.toFloat())
        val c = Canvas(out)
        c.translate((FW - src.width * s) * fx(), (fh - src.height * s) * fy())
        c.scale(s, s)
        c.drawBitmap(src, 0f, 0f, Paint(Paint.FILTER_BITMAP_FLAG))
        return out
    }

    /** Buat frame JPEG dari file banner. Dipanggil di thread latar. */
    private fun bake(): Boolean {
        val f = src() ?: return false
        val d = dir(act)
        d.listFiles()?.filter { it.name.startsWith("f") && it.name.endsWith(".jpg") }?.forEach { it.delete() }
        var n = 0
        var delay = 100
        try {
            if (type() == "video") {
                val mmr = MediaMetadataRetriever()
                try {
                    mmr.setDataSource(f.path)
                    val dur = mmr.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L
                    if (dur <= 0) return false
                    val total = min(dur, MAX_MS.toLong())
                    val count = min(MAX_FRAMES.toLong(), max(2L, total / 83)).toInt()
                    val step = total / count
                    delay = step.toInt()
                    for (k in 0 until count) {
                        val raw = mmr.getFrameAtTime(k * step * 1000, MediaMetadataRetriever.OPTION_CLOSEST) ?: continue
                        val b = cover(raw)
                        raw.recycle()
                        File(d, "f$n.jpg").outputStream().use { b.compress(Bitmap.CompressFormat.JPEG, 85, it) }
                        b.recycle()
                        n++
                    }
                } finally {
                    try { mmr.release() } catch (_: Throwable) {}
                }
            } else {
                @Suppress("DEPRECATION")
                val mv = Movie.decodeFile(f.path) ?: return false
                val dur = mv.duration()
                if (dur <= 0 || mv.width() <= 0 || mv.height() <= 0) return false
                val total = min(dur, MAX_MS)
                val count = min(MAX_FRAMES, max(2, total / 40))
                val step = total.toFloat() / count
                delay = step.toInt()
                val tmp = Bitmap.createBitmap(mv.width(), mv.height(), Bitmap.Config.ARGB_8888)
                val cv = Canvas(tmp)
                for (k in 0 until count) {
                    mv.setTime((k * step).toInt())
                    tmp.eraseColor(0xFF000000.toInt())
                    mv.draw(cv, 0f, 0f)
                    val b = cover(tmp)
                    File(d, "f$n.jpg").outputStream().use { b.compress(Bitmap.CompressFormat.JPEG, 85, it) }
                    b.recycle()
                    n++
                }
                tmp.recycle()
            }
        } catch (_: Throwable) {
            return false
        }
        if (n < 2) return false
        Prefs.setInt(act, "banner_delay", delay.coerceIn(40, 400))
        Prefs.setInt(act, "banner_frames", n)
        return true
    }
}
