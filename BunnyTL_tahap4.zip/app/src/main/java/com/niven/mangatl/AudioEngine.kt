package com.niven.mangatl

import android.content.Context
import android.os.Handler
import android.os.Looper
import org.json.JSONArray
import org.json.JSONObject

// ---------- definisi parameter (sesuai desain Audio Engine) ----------

sealed class P(val name: String, val desc: String, val show: ((FloatArray) -> Boolean)?)

class PNum(
    name: String, val unit: String, val min: Float, val max: Float, val def: Float, desc: String,
    show: ((FloatArray) -> Boolean)? = null
) : P(name, desc, show)

class PSel(
    name: String, val opts: List<String>, val def: Int, desc: String,
    show: ((FloatArray) -> Boolean)? = null
) : P(name, desc, show)

class PTog(
    name: String, val def: Boolean, desc: String, val supported: Boolean = true,
    show: ((FloatArray) -> Boolean)? = null
) : P(name, desc, show)

/** Nilai hidup (hanya tampil, tidak diubah). */
class PMeter(name: String, desc: String) : P(name, desc, null)

class Feature(
    val id: String, val title: String, val desc: String, val params: List<P>,
    val quick: IntArray, val defaultOn: Boolean
)

/**
 * Pusat pengaturan Audio Engine. Dipakai UI (thread utama) dan rantai DSP (thread audio).
 * Nilai disimpan sebagai FloatArray per fitur: slider = nilainya, pilihan = indeks, saklar = 0/1.
 */
object AudioEngine {

    const val EQ = "Equalizer"
    const val BASS = "Bass"
    const val SPATIAL = "Spatial"
    const val HIRES = "HiRes"
    const val REVERB = "Reverb"
    const val VOCAL = "Vocal"
    const val STEREO = "Stereo"
    const val COMP = "Compressor"
    const val LIMIT = "Limiter"
    const val NORM = "Normalization"
    const val XFEED = "Crossfeed"
    const val VIS = "Visualizer"

    const val EQ_MAX_BANDS = 31
    private const val EQ_ATTR = 5 // freq, gain, q, tipe, slope

    private val onOff = listOf("Off", "2×", "4×", "8×")
    private val isManualMap: (FloatArray) -> Boolean = { it[12].toInt() == 1 }

    val features: List<Feature> = listOf(
        Feature(
            EQ, "Equalizer", "Keseimbangan frekuensi untuk membentuk karakter suara.",
            listOf(
                PSel("Band Count", listOf("5", "10", "15", "20", "31", "Parametrik"), 1, "Jumlah band yang tampil"),
                PNum("Frequency", "Hz", 20f, 20000f, 125f, "Frekuensi yang diubah (band terpilih)"),
                PNum("Gain", "dB", -24f, 24f, 0f, "Angkat atau kurangi frekuensi (band terpilih)"),
                PNum("Q Factor", "", 0.1f, 20f, 1f, "Kecil = area lebar, besar = sempit. Dipakai Peak, Shelf, Band Pass, Notch"),
                PSel("Filter Type", listOf("Peak", "Low Shelf", "High Shelf", "Low Pass", "High Pass", "Band Pass", "Notch"), 0, "Bentuk filter band"),
                PSel("Slope", listOf("6", "12", "18", "24", "36", "48"), 3, "Kecuraman Low Pass / High Pass, dB/oct. Tidak berpengaruh pada tipe lain"),
                PNum("Preamp", "dB", -24f, 24f, 0f, "Turunkan agar tidak clipping saat boost"),
                PSel("Channel", listOf("Stereo", "Left", "Right"), 0, "Kanal yang diproses"),
                PSel("Phase", listOf("Normal", "Invert"), 0, "Polaritas sinyal")
            ),
            intArrayOf(), true
        ),
        Feature(
            BASS, "Bass Boost", "Memperkuat bass dan sub-bass.",
            listOf(
                PNum("Gain", "dB", 0f, 24f, 0f, "Seberapa kuat bass diangkat"),
                PNum("Center Frequency", "Hz", 20f, 250f, 80f, "Titik pusat area bass"),
                PNum("Q Factor", "", 0.1f, 10f, 0.7f, "Kecil = lebar, besar = sempit"),
                PNum("Cutoff", "Hz", 10f, 100f, 20f, "Batas bawah sub-bass (high-pass)"),
                PSel("Filter Type", listOf("Shelf", "Peak"), 0, "Bentuk kurva penguatan"),
                PNum("Harmonic Enhancement", "%", 0f, 100f, 0f, "Harmonik agar bass terdengar di speaker kecil"),
                PTog("Distortion Compensation", false, "Turunkan level otomatis saat boost besar"),
                PNum("Dry/Wet", "%", 0f, 100f, 100f, "Campuran sinyal asli dan hasil efek")
            ),
            intArrayOf(0, 1), true
        ),
        Feature(
            SPATIAL, "3D Spatial Audio", "Kesan ruang, kedalaman, posisi, dimensi.",
            listOf(
                PNum("Intensity", "%", 0f, 100f, 0f, "Kekuatan efek spatial"),
                PNum("Width", "%", 0f, 200f, 100f, "Lebar panggung suara"),
                PNum("Depth", "%", 0f, 100f, 50f, "Kesan jarak depan-belakang"),
                PNum("Height", "%", 0f, 100f, 0f, "Kesan ketinggian"),
                PNum("Azimuth", "°", -180f, 180f, 0f, "Arah horizontal sumber suara"),
                PNum("Elevation", "°", -90f, 90f, 0f, "Arah vertikal sumber suara"),
                PSel("HRTF Profile", listOf("Generik", "Kecil", "Besar"), 0, "Ukuran kepala model HRTF (model bola, bukan data HRTF terukur)"),
                PTog("Head Tracking", false, "Tidak didukung: butuh headset dengan sensor kepala", false),
                PTog("Room Simulation", false, "Simulasi ruangan (pantulan awal)"),
                PNum("Direct Sound", "%", 0f, 100f, 100f, "Level suara langsung"),
                PNum("Reflections", "%", 0f, 100f, 0f, "Level pantulan. Aktif jika Room Simulation menyala")
            ),
            intArrayOf(0, 1), false
        ),
        Feature(
            HIRES, "Hi-Res Audio", "Resolusi, jalur output, pemrosesan digital.",
            listOf(
                PSel("Sample Rate", listOf("Auto", "44.1", "48", "88.2", "96", "176.4", "192"), 0, "kHz. Dibatasi kemampuan perangkat output"),
                PSel("Bit Depth", listOf("Auto", "16", "24", "32"), 0, "Resolusi per sampel"),
                PSel("Output Format", listOf("PCM"), 0, "Hanya PCM. Passthrough/DSD tidak didukung jalur ini"),
                PSel("DAC Selection", listOf("Default perangkat", "DAC eksternal"), 0, "DAC USB yang terdeteksi"),
                PSel("Output Mode", listOf("Standard", "Direct", "Exclusive"), 0, "Direct = kirim ke DAC terpilih. Exclusive tidak tersedia di Android lewat jalur ini"),
                PTog("Bit-perfect", false, "Aktif jika jalur output kompatibel (Android 14+, DAC USB). Mematikan semua efek"),
                PSel("Upsampling", onOff, 0, "Dipakai saat Sample Rate = Auto. Tidak menambah detail audio baru"),
                PSel("Oversampling", onOff, 0, "Dipakai di blok nonlinear (harmonik bass/vokal) agar alias berkurang"),
                PSel("Digital Filter", listOf("Linear", "Minimum phase"), 0, "Filter resampler (linear-phase atau minimum-phase)"),
                PSel("Dither", listOf("Off", "TPDF"), 0, "Noise halus saat bit depth turun"),
                PSel("Buffer Size", listOf("Auto", "10 ms", "20 ms", "40 ms"), 0, "Besar = stabil, kecil = latency rendah. Berlaku setelah pemutar disambung ulang"),
                PMeter("Latency", "Perkiraan, tidak diubah langsung"),
                PSel("Channel Mapping", listOf("Auto", "Manual"), 0, "Manual: pilih sumber tiap kanal output"),
                PSel("Kanal Kiri dari", listOf("Kiri", "Kanan", "Campuran"), 0, "Sumber kanal output kiri", isManualMap),
                PSel("Kanal Kanan dari", listOf("Kanan", "Kiri", "Campuran"), 0, "Sumber kanal output kanan", isManualMap)
            ),
            intArrayOf(0, 1, 4, 5), false
        ),
        Feature(
            REVERB, "Reverb", "Simulasi pantulan ruangan dan ambience.",
            listOf(
                PNum("Room Size", "%", 0f, 100f, 30f, "Ukuran ruang"),
                PNum("Decay Time", "s", 0.1f, 10f, 1.5f, "Lama gema memudar"),
                PNum("Pre-delay", "ms", 0f, 200f, 10f, "Jeda sebelum gema"),
                PNum("Early Reflection", "%", 0f, 100f, 20f, "Pantulan awal"),
                PNum("Late Reflection", "%", 0f, 100f, 30f, "Pantulan akhir"),
                PNum("Diffusion", "%", 0f, 100f, 50f, "Kepadatan gema"),
                PNum("Damping", "%", 0f, 100f, 50f, "Peredaman nada tinggi"),
                PNum("Low Cut", "Hz", 20f, 1000f, 20f, "Potong bass dari gema"),
                PNum("High Cut", "kHz", 1f, 20f, 16f, "Potong treble dari gema"),
                PNum("Wet", "%", 0f, 100f, 15f, "Level efek"),
                PNum("Dry", "%", 0f, 100f, 100f, "Level suara asli"),
                PNum("Width", "%", 0f, 200f, 100f, "Lebar stereo gema")
            ),
            intArrayOf(9, 1), false
        ),
        Feature(
            VOCAL, "Vocal Enhancer", "Memperjelas vokal dan presence.",
            listOf(
                PNum("Vocal Gain", "dB", -12f, 12f, 0f, "Level vokal (pita vokal di tengah)"),
                PNum("Center Frequency", "Hz", 500f, 8000f, 3000f, "Frekuensi fokus vokal"),
                PNum("Presence", "dB", -12f, 12f, 0f, "Vokal lebih maju"),
                PNum("Clarity", "%", 0f, 100f, 0f, "Kejernihan"),
                PNum("Intensity", "%", 0f, 100f, 0f, "Kekuatan efek"),
                PNum("Vocal Width", "%", 0f, 200f, 100f, "Lebar vokal"),
                PNum("Harmonic Enhancement", "%", 0f, 100f, 0f, "Tambah harmonik"),
                PNum("De-esser Frequency", "Hz", 2000f, 12000f, 6000f, "Frekuensi desis"),
                PNum("De-esser Amount", "%", 0f, 100f, 0f, "Kekuatan peredam desis"),
                PNum("Dry/Wet", "%", 0f, 100f, 100f, "Campuran asli dan efek")
            ),
            intArrayOf(0, 2), false
        ),
        Feature(
            STEREO, "Stereo Width", "Lebar stereo tanpa efek spatial penuh.",
            listOf(
                PNum("Width", "%", 0f, 200f, 100f, "0% = mono, 200% = sangat lebar"),
                PNum("Mid Gain", "dB", -12f, 12f, 0f, "Level tengah"),
                PNum("Side Gain", "dB", -12f, 12f, 0f, "Level samping"),
                PNum("Balance", "", -100f, 100f, 0f, "-100 kiri, +100 kanan"),
                PNum("Center Focus", "%", 0f, 100f, 0f, "Pusatkan suara tengah"),
                PTog("Mono Compatibility", true, "Jaga suara tetap aman bila di-mono"),
                PMeter("Phase Correlation", "Meter -1 sampai +1"),
                PTog("Frequency-dependent Width", false, "Bass lebih sempit, treble lebih lebar")
            ),
            intArrayOf(), false
        ),
        Feature(
            COMP, "Compressor", "Mengendalikan dinamika volume.",
            listOf(
                PNum("Threshold", "dB", -60f, 0f, -18f, "Level mulai dikompres"),
                PNum("Ratio", ":1", 1f, 20f, 2f, "Kekuatan kompresi"),
                PNum("Attack", "ms", 0.1f, 200f, 10f, "Kecepatan bereaksi"),
                PNum("Release", "ms", 10f, 2000f, 100f, "Kecepatan melepas"),
                PNum("Knee", "dB", 0f, 24f, 6f, "Kelembutan transisi"),
                PNum("Makeup Gain", "dB", 0f, 24f, 0f, "Kompensasi level"),
                PNum("Sidechain HPF", "Hz", 20f, 20000f, 20f, "Off pada 20 Hz"),
                PSel("Detector", listOf("Peak", "RMS"), 0, "Cara mengukur level"),
                PNum("Stereo Linking", "%", 0f, 100f, 100f, "Kopel kiri-kanan"),
                PNum("Mix", "%", 0f, 100f, 100f, "Campuran asli dan hasil")
            ),
            intArrayOf(), false
        ),
        Feature(
            LIMIT, "Limiter", "Membatasi peak agar tidak clipping.",
            listOf(
                PNum("Threshold", "dB", -24f, 0f, -1f, "Level mulai dibatasi"),
                PNum("Ceiling", "dBTP", -12f, 0f, -1f, "Batas puncak maksimum"),
                PNum("Attack", "ms", 0.01f, 100f, 1f, "Kecepatan bereaksi"),
                PNum("Release", "ms", 10f, 1000f, 100f, "Kecepatan melepas"),
                PNum("Lookahead", "ms", 0f, 20f, 1f, "Antisipasi peak"),
                PNum("Knee", "dB", 0f, 12f, 0f, "Kelembutan transisi"),
                PSel("Oversampling", onOff, 2, "Deteksi true peak"),
                PNum("Stereo Linking", "%", 0f, 100f, 100f, "Kopel kiri-kanan"),
                PNum("Input Gain", "dB", -24f, 24f, 0f, "Level masuk"),
                PNum("Output Gain", "dB", -24f, 24f, 0f, "Level keluar")
            ),
            intArrayOf(), true
        ),
        Feature(
            NORM, "Volume Normalization", "Menyeimbangkan kenyaringan antar-lagu.",
            listOf(
                PNum("Target Loudness", "LUFS", -30f, -5f, -14f, "Target kenyaringan"),
                PNum("True Peak Limit", "dBTP", -6f, 0f, -1f, "Batas puncak"),
                PNum("Gain Range", "dB", 0f, 24f, 12f, "Rentang koreksi maks ±"),
                PSel("Mode", listOf("Track", "Album"), 0, "Per lagu atau per album"),
                PSel("Algorithm", listOf("ReplayGain", "EBU R128"), 1, "ReplayGain: persentil-95 RMS 50 ms. EBU R128: integrated loudness bergerbang"),
                PTog("Dynamic Normalization", false, "Koreksi sepanjang lagu"),
                PTog("Clipping Prevention", true, "Cegah clipping setelah gain"),
                PSel("Loudness Meter", listOf("LUFS", "RMS", "Peak"), 0, "Jenis meter"),
                PMeter("Gain Adjustment", "Koreksi yang sedang berjalan")
            ),
            intArrayOf(0), true
        ),
        Feature(
            XFEED, "Crossfeed", "Headphone terdengar seperti speaker di depan.",
            listOf(
                PNum("Level", "%", 0f, 100f, 15f, "Seberapa banyak bocor ke sisi lain"),
                PNum("Center Frequency", "Hz", 100f, 1500f, 700f, "Pusat kompensasi bass"),
                PNum("Cutoff Frequency", "Hz", 100f, 2000f, 700f, "Batas frekuensi crossfeed"),
                PNum("Delay", "ms", 0f, 1f, 0.3f, "Jeda antar-telinga"),
                PNum("Attenuation", "dB", -24f, 0f, -6f, "Redaman sinyal silang"),
                PNum("Angle", "°", 0f, 90f, 30f, "Sudut speaker virtual"),
                PSel("Filter Type", listOf("Butterworth", "Linkwitz"), 0, "Filter yang didukung"),
                PNum("Channel Mixing", "%", 0f, 100f, 0f, "Campuran kanal"),
                PTog("Phase Compensation", true, "Koreksi level bass akibat crossfeed")
            ),
            intArrayOf(), false
        ),
        Feature(
            VIS, "Visualizer", "Visual musik real-time.",
            listOf(
                PSel("FFT Size", listOf("256", "512", "1024", "2048", "4096", "8192"), 3, "Besar = detail frekuensi, lebih berat"),
                PSel("Frequency Range", listOf("20 Hz–20 kHz"), 0, "Rentang tampilan"),
                PNum("Number of Bars", "", 8f, 256f, 64f, "Jumlah batang"),
                PNum("Smoothing", "%", 0f, 100f, 60f, "Kehalusan gerak"),
                PNum("Sensitivity", "%", 0f, 100f, 50f, "Kepekaan"),
                PNum("Attack", "ms", 1f, 500f, 30f, "Kecepatan naik"),
                PNum("Decay", "ms", 10f, 2000f, 250f, "Kecepatan turun"),
                PNum("Frame Rate", "FPS", 15f, 120f, 60f, "Rendah = hemat baterai"),
                PNum("Peak Hold", "ms", 0f, 3000f, 500f, "Lama puncak tertahan"),
                PSel("Frequency Scale", listOf("Linear", "Logaritmik"), 1, "Skala sumbu frekuensi"),
                PSel("Channel Mode", listOf("Stereo", "Mono"), 0, "Stereo: batang kiri-kanan dipisah. Mono: gabungan"),
                PNum("Waveform Resolution", "sampel", 256f, 8192f, 2048f, "Detail garis gelombang"),
                PSel("Rendering Quality", listOf("Rendah", "Sedang", "Tinggi"), 2, "Kualitas gambar")
            ),
            intArrayOf(), false
        )
    )

    fun feature(id: String): Feature = features.first { it.id == id }
    fun index(id: String): Int = features.indexOfFirst { it.id == id }

    // ---------- keadaan ----------

    private val values = HashMap<String, FloatArray>()
    private val ons = HashMap<String, Boolean>()
    @Volatile var master = true
        private set

    /** Naik tiap ada perubahan; rantai DSP memeriksa ini di awal tiap buffer. */
    @Volatile var version = 0
        private set

    /** Naik kalau perubahan butuh jalur output dibuat ulang (Hi-Res). */
    @Volatile var outputVersion = 0
        private set

    // equalizer per band
    val eqBands = FloatArray(EQ_MAX_BANDS * EQ_ATTR)
    @Volatile var eqSel = 0

    @Volatile var currentTrackId: Long = -1L
    @Volatile var currentAlbumId: Long = -1L

    private var ctx: Context? = null
    private val h = Handler(Looper.getMainLooper())
    private val saver = Runnable { saveWork() }
    private var ready = false

    fun init(c: Context) {
        if (ready) return
        ctx = c.applicationContext
        for (f in features) {
            values[f.id] = defaults(f)
            ons[f.id] = f.defaultOn
        }
        resetEqBands(1)
        loadWork()
        ready = true
    }

    private fun defaults(f: Feature): FloatArray = FloatArray(f.params.size) { i -> defOf(f.params[i]) }

    private fun defOf(p: P): Float = when (p) {
        is PNum -> p.def
        is PSel -> p.def.toFloat()
        is PTog -> if (p.def) 1f else 0f
        is PMeter -> 0f
    }

    /** Array nilai mentah satu fitur (dipakai DSP). */
    fun raw(id: String): FloatArray = values[id] ?: FloatArray(0)

    fun isOn(id: String): Boolean = master && (ons[id] == true)
    fun featureOn(id: String): Boolean = ons[id] == true

    fun setMaster(v: Boolean) {
        master = v
        bump(false); scheduleSave()
    }

    fun setOn(id: String, v: Boolean) {
        ons[id] = v
        bump(id == HIRES); scheduleSave()
    }

    // ---------- baca / tulis parameter ----------

    private fun isBandParam(fid: String, idx: Int) = fid == EQ && idx in 1..5

    fun get(fid: String, idx: Int): Float {
        if (isBandParam(fid, idx)) return eqBands[eqSel * EQ_ATTR + (idx - 1)]
        return values[fid]?.getOrNull(idx) ?: 0f
    }

    fun def(fid: String, idx: Int): Float {
        if (isBandParam(fid, idx)) {
            val count = eqCount()
            return when (idx) {
                1 -> eqGrid(count).getOrElse(eqSel) { 1000f }
                2 -> 0f
                3 -> eqDefQ(count)
                4 -> 0f
                else -> 3f
            }
        }
        return defOf(feature(fid).params[idx])
    }

    fun set(fid: String, idx: Int, v: Float) {
        val p = feature(fid).params[idx]
        val c = when (p) {
            is PNum -> v.coerceIn(p.min, p.max)
            is PSel -> v.toInt().coerceIn(0, p.opts.size - 1).toFloat()
            is PTog -> if (v >= 0.5f && p.supported) 1f else 0f
            is PMeter -> 0f
        }
        if (isBandParam(fid, idx)) {
            eqBands[eqSel * EQ_ATTR + (idx - 1)] = c
        } else {
            values[fid]?.set(idx, c)
            if (fid == EQ && idx == 0) resetEqBands(c.toInt())
        }
        bump(fid == HIRES && idx != 7 && idx != 11)
        scheduleSave()
    }

    fun resetParam(fid: String, idx: Int) = set(fid, idx, def(fid, idx))

    fun resetFeature(fid: String) {
        val f = feature(fid)
        values[fid] = defaults(f)
        if (fid == EQ) resetEqBands(1)
        bump(fid == HIRES); scheduleSave()
    }

    fun resetAll() {
        for (f in features) {
            values[f.id] = defaults(f)
            ons[f.id] = f.defaultOn
        }
        master = true
        resetEqBands(1)
        bump(true); scheduleSave()
    }

    /** Dipanggil (thread utama, ditunda) saat pengaturan jalur output berubah. */
    var outputListener: (() -> Unit)? = null
    private val outRun = Runnable { outputListener?.invoke() }

    private fun bump(output: Boolean) {
        version++
        if (output) {
            outputVersion++
            h.removeCallbacks(outRun)
            h.postDelayed(outRun, 450)
        }
    }

    // ---------- equalizer ----------

    fun eqCount(): Int = when (values[EQ]?.get(0)?.toInt() ?: 1) {
        0 -> 5; 1 -> 10; 2 -> 15; 3 -> 20; 4 -> 31; else -> 8
    }

    fun eqGrid(count: Int): FloatArray = when (count) {
        10 -> floatArrayOf(31f, 62f, 125f, 250f, 500f, 1000f, 2000f, 4000f, 8000f, 16000f)
        31 -> floatArrayOf(
            20f, 25f, 31.5f, 40f, 50f, 63f, 80f, 100f, 125f, 160f, 200f, 250f, 315f, 400f, 500f, 630f,
            800f, 1000f, 1250f, 1600f, 2000f, 2500f, 3150f, 4000f, 5000f, 6300f, 8000f, 10000f,
            12500f, 16000f, 20000f
        )
        else -> FloatArray(count) { i ->
            val f = 30.0 * Math.pow(16000.0 / 30.0, i.toDouble() / (count - 1))
            (Math.round(f * 10.0) / 10.0).toFloat()
        }
    }

    fun eqDefQ(count: Int): Float = when (count) {
        5 -> 0.8f; 15 -> 1.4f; 20 -> 2f; 31 -> 3f; else -> 1f
    }

    /** Ganti jumlah band: kurva lama diinterpolasi ke grid baru (skala log-frekuensi). */
    private fun resetEqBands(sel: Int) {
        val oldCount = if (eqBands[0] == 0f && eqBands[1] == 0f) 0 else lastCount
        val oldF = FloatArray(oldCount) { eqBands[it * EQ_ATTR] }
        val oldG = FloatArray(oldCount) { eqBands[it * EQ_ATTR + 1] }
        val count = when (sel) {
            0 -> 5; 1 -> 10; 2 -> 15; 3 -> 20; 4 -> 31; else -> 8
        }
        val grid = eqGrid(count)
        val q = eqDefQ(count)
        for (i in 0 until EQ_MAX_BANDS) {
            val b = i * EQ_ATTR
            if (i < count) {
                eqBands[b] = grid[i]
                eqBands[b + 1] = if (oldCount > 1) interpGain(oldF, oldG, grid[i]) else 0f
                eqBands[b + 2] = q
                eqBands[b + 3] = 0f
                eqBands[b + 4] = 3f
            } else {
                eqBands[b] = 1000f; eqBands[b + 1] = 0f; eqBands[b + 2] = q; eqBands[b + 3] = 0f; eqBands[b + 4] = 3f
            }
        }
        lastCount = count
        if (eqSel >= count) eqSel = 0
    }

    private var lastCount = 10

    private fun interpGain(f: FloatArray, g: FloatArray, x: Float): Float {
        if (x <= f[0]) return g[0]
        if (x >= f[f.size - 1]) return g[g.size - 1]
        for (i in 0 until f.size - 1) {
            if (x >= f[i] && x <= f[i + 1]) {
                val t = (Math.log((x / f[i]).toDouble()) / Math.log((f[i + 1] / f[i]).toDouble())).toFloat()
                return g[i] + (g[i + 1] - g[i]) * t
            }
        }
        return 0f
    }

    fun selectEqBand(i: Int) {
        eqSel = i.coerceIn(0, eqCount() - 1)
    }

    // ---------- meter hidup (diisi rantai DSP) ----------

    @Volatile var meterGainDb = 0f
    @Volatile var meterLufs = -70f
    @Volatile var meterRmsDb = -90f
    @Volatile var meterPeakDb = -90f
    @Volatile var meterCorr = 0f
    @Volatile var meterLatencyMs = 0f
    @Volatile var meterBufferMs = 0f
    @Volatile var normStatus = ""

    fun meterText(fid: String, idx: Int): String = when (fid) {
        HIRES -> {
            val dsp = String.format(java.util.Locale.US, "%.1f", meterLatencyMs)
            val buf = if (meterBufferMs > 0f) String.format(java.util.Locale.US, "%.0f", meterBufferMs) else "?"
            "DSP $dsp ms + buffer ≈$buf ms"
        }
        STEREO -> String.format(java.util.Locale.US, "%+.2f", meterCorr)
        NORM -> {
            val g = String.format(java.util.Locale.US, "%+.1f dB", meterGainDb)
            if (normStatus.isEmpty()) g else "$g · $normStatus"
        }
        else -> ""
    }

    fun normMeterText(): String {
        val m = raw(NORM)
        return when (m.getOrNull(7)?.toInt() ?: 0) {
            1 -> String.format(java.util.Locale.US, "%.1f dB RMS", meterRmsDb)
            2 -> String.format(java.util.Locale.US, "%.1f dBFS peak", meterPeakDb)
            else -> String.format(java.util.Locale.US, "%.1f LUFS", meterLufs)
        }
    }

    // ---------- penyimpanan ----------

    private fun prefs() = ctx!!.getSharedPreferences("audio_engine", Context.MODE_PRIVATE)

    private fun scheduleSave() {
        h.removeCallbacks(saver)
        h.postDelayed(saver, 500)
    }

    private fun toJson(): String {
        val o = JSONObject()
        o.put("master", master)
        val fx = JSONObject()
        for (f in features) {
            val e = JSONObject()
            e.put("on", ons[f.id] == true)
            val a = JSONArray()
            values[f.id]?.forEach { a.put(it.toDouble()) }
            e.put("v", a)
            fx.put(f.id, e)
        }
        o.put("fx", fx)
        val eq = JSONObject()
        eq.put("sel", eqSel)
        eq.put("count", eqCount())
        val b = JSONArray()
        for (x in eqBands) b.put(x.toDouble())
        eq.put("bands", b)
        o.put("eq", eq)
        return o.toString()
    }

    private fun fromJson(s: String): Boolean {
        try {
            val o = JSONObject(s)
            master = o.optBoolean("master", true)
            val fx = o.optJSONObject("fx")
            if (fx != null) {
                for (f in features) {
                    val e = fx.optJSONObject(f.id) ?: continue
                    ons[f.id] = e.optBoolean("on", f.defaultOn)
                    val a = e.optJSONArray("v") ?: continue
                    val cur = values[f.id] ?: continue
                    for (i in 0 until minOf(a.length(), cur.size)) {
                        val p = f.params[i]
                        val x = a.optDouble(i, defOf(p.let { it }).toDouble()).toFloat()
                        cur[i] = when (p) {
                            is PNum -> x.coerceIn(p.min, p.max)
                            is PSel -> x.toInt().coerceIn(0, p.opts.size - 1).toFloat()
                            is PTog -> if (x >= 0.5f && p.supported) 1f else 0f
                            is PMeter -> 0f
                        }
                    }
                }
            }
            val eq = o.optJSONObject("eq")
            if (eq != null) {
                val b = eq.optJSONArray("bands")
                if (b != null) {
                    for (i in 0 until minOf(b.length(), eqBands.size)) eqBands[i] = b.optDouble(i, 0.0).toFloat()
                }
                lastCount = eqCount()
                eqSel = eq.optInt("sel", 0).coerceIn(0, eqCount() - 1)
            }
            return true
        } catch (e: Exception) {
            return false
        }
    }

    private fun saveWork() {
        try {
            prefs().edit().putString("work", toJson()).apply()
        } catch (e: Exception) {
        }
    }

    private fun loadWork() {
        val s = prefs().getString("work", null) ?: return
        fromJson(s)
    }

    /** Simpan ke slot "Simpan". */
    fun saveSlot(): Boolean = try {
        prefs().edit().putString("slot", toJson()).apply()
        true
    } catch (e: Exception) {
        false
    }

    fun hasSlot(): Boolean = prefs().getString("slot", null) != null

    /** Muat dari slot "Simpan". */
    fun loadSlot(): Boolean {
        val s = prefs().getString("slot", null) ?: return false
        val ok = fromJson(s)
        if (ok) {
            bump(true); scheduleSave()
        }
        return ok
    }
}
