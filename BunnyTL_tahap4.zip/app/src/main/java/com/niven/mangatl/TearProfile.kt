package com.niven.mangatl

import android.content.Context

/**
 * Profil zig-zag sobekan (dibuat bersama gambar res/drawable-nodpi/tear_edge.png).
 * Satuan: piksel gambar, tinggi gambar = IMG_H. Dipakai oleh tiga hal supaya selalu pas satu sama lain:
 *  - gl  : batas atas poligon penutup di GL (badan Karin berhenti di sini)
 *  - cut : garis potong daftar chat (di bawah tepi putih)
 *  - gambar tear_edge.png sendiri (tepi putih berserat)
 */
class TearProfile(val n: Int, val gl: FloatArray, val cut: FloatArray) {
    companion object {
        const val IMG_H = 250f
        const val HEIGHT_DP = 48f   // harus sama dengan tinggi ImageView tearEdge di layout

        @Volatile private var cache: TearProfile? = null

        fun get(ctx: Context): TearProfile {
            cache?.let { return it }
            synchronized(this) {
                cache?.let { return it }
                val lines = ctx.resources.openRawResource(R.raw.tear_profile).bufferedReader().readLines()
                    .filter { it.isNotBlank() }
                val n = lines.size
                val gl = FloatArray(n)
                val cut = FloatArray(n)
                for (i in 0 until n) {
                    val p = lines[i].trim().split(' ')
                    gl[i] = p[0].toFloat()
                    cut[i] = p[1].toFloat()
                }
                return TearProfile(n, gl, cut).also { cache = it }
            }
        }
    }
}
