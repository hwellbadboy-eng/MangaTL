package com.niven.mangatl

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.Point
import android.graphics.Rect
import android.graphics.Typeface
import android.net.Uri
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.TextRecognizer
import com.google.mlkit.vision.text.chinese.ChineseTextRecognizerOptions
import com.google.mlkit.vision.text.japanese.JapaneseTextRecognizerOptions
import com.google.mlkit.vision.text.korean.KoreanTextRecognizerOptions
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import java.io.File
import java.util.Locale
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream

/**
 * Mesin Manga Translator: impor halaman (gambar / CBZ / ZIP), baca teks (ML Kit per bahasa),
 * gabungkan blok satu balon, tutup teks asli dengan warna latar, tulis terjemahan Indonesia.
 * Penerjemahnya sendiri (Gemma) dipanggil lewat lambda supaya mesin ini tidak bergantung ke model.
 */
object MangaEngine {

    val LANG_LABELS = listOf("Jepang (manga)", "Korea (manhwa)", "Mandarin (manhua)", "Inggris")
    val LANG_PROMPT = listOf("Japanese", "Korean", "Chinese", "English")

    internal const val STRIP_H = 1800

    /** Font terjemahan. Default Comic Relief Bold (gaya komik/scanlation, lisensi OFL, ada di assets/fonts). */
    private const val DEFAULT_FONT = "ComicRelief-Bold.ttf"
    internal var dialogFace: Typeface? = null

    /** Daftar font yang bisa dipilih di menu Manga Translator: (nama file di assets/fonts, nama tampil, keterangan). */
    val FONTS = listOf(
        Triple("ComicRelief-Bold.ttf", "Comic Relief Bold", "Gaya komik umum, bulat dan mudah dibaca (default)"),
        Triple("ComicNeue-Bold.ttf", "Comic Neue Bold", "Komik yang lebih ramping, muat banyak teks di balon kecil"),
        Triple("Bangers-Regular.ttf", "Bangers", "Tebal ala teriakan/efek suara, cocok untuk aksi"),
        Triple("system", "Font sistem HP", "Font bawaan HP, paling netral")
    )

    /** Mode huruf: 0 kapital semua (konsisten), 1 huruf biasa (konsisten), 2 otomatis (kapital, balon sempit pindah ke huruf biasa). */
    val CASE_LABELS = listOf(
        "Kapital semua (semua balon sama)",
        "Huruf biasa (semua balon sama)",
        "Otomatis (balon sempit pakai huruf biasa, bisa kelihatan campur)"
    )

    /** Muat Typeface dari nama file di FONTS. Gagal dimuat = font sistem tebal. */
    fun loadFace(context: Context, name: String): Typeface {
        val sys = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        if (name == "system") return sys
        return try { Typeface.createFromAsset(context.applicationContext.assets, "fonts/$name") } catch (_: Throwable) { sys }
    }

    /** Gaya lettering manhwa: huruf kapital + miring. Diatur lewat menu Manga Translator (SharedPreferences "manga"). */
    internal var caseMode = 0
    internal var capsOn = true
    internal var italicOn = true

    fun caseModePref(context: Context): Int {
        val sp = context.getSharedPreferences("manga", Context.MODE_PRIVATE)
        // Pengaturan lama "caps": false = huruf biasa; selain itu kapital konsisten (bukan lagi campur otomatis).
        return sp.getInt("case_mode", if (sp.getBoolean("caps", true)) 0 else 1).coerceIn(0, 2)
    }

    /**
     * Muat font terjemahan sekali sebelum render. Pilihan disimpan di SharedPreferences "manga" kunci "font"
     * (lihat FONTS). Kalau file font gagal dimuat, otomatis kembali ke font sistem tebal supaya render tidak pernah gagal.
     */
    fun initFonts(context: Context) {
        val sp = context.getSharedPreferences("manga", Context.MODE_PRIVATE)
        val name = sp.getString("font", DEFAULT_FONT) ?: DEFAULT_FONT
        caseMode = caseModePref(context)
        capsOn = caseMode != 1
        italicOn = sp.getBoolean("italic", true)
        dialogFace = loadFace(context, name)
    }

    /** Huruf terjemahan paling besar = tinggi huruf asli x angka ini (cegah teks raksasa & ukuran beda dalam satu balon). */
    internal const val SIZE_CAP = 1.35f

    /** Sudut minimum (derajat) supaya teks dianggap miring dan terjemahannya diputar. */
    internal const val TILT_MIN = 2f
    private val IMAGE_EXT = setOf("jpg", "jpeg", "png", "webp")

    // ------------------------------------------------------------------ folder & berkas

    fun root(ctx: Context): File = File(ctx.getExternalFilesDir(null), "manga").also { it.mkdirs() }

    fun srcDir(work: File) = File(work, "src")

    fun outDir(work: File) = File(work, "out")

    fun isImageName(name: String): Boolean =
        name.substringAfterLast('.', "").lowercase(Locale.ROOT) in IMAGE_EXT

    fun naturalCompare(a: String, b: String): Int {
        val re = Regex("\\d+|\\D+")
        val ra = re.findAll(a.lowercase(Locale.ROOT)).map { it.value }.toList()
        val rb = re.findAll(b.lowercase(Locale.ROOT)).map { it.value }.toList()
        for (i in 0 until minOf(ra.size, rb.size)) {
            val x = ra[i]
            val y = rb[i]
            val c = if (x[0].isDigit() && y[0].isDigit()) {
                val lx = x.trimStart('0')
                val ly = y.trimStart('0')
                if (lx.length != ly.length) lx.length.compareTo(ly.length) else lx.compareTo(ly)
            } else {
                x.compareTo(y)
            }
            if (c != 0) return c
        }
        return ra.size.compareTo(rb.size)
    }

    /** Halaman sumber, terurut alami (1, 2, 10 bukan 1, 10, 2). */
    fun pages(work: File): List<File> =
        srcDir(work).listFiles()
            ?.filter { it.isFile && isImageName(it.name) }
            ?.sortedWith { a, b -> naturalCompare(a.name, b.name) }
            ?: emptyList()

    fun doneCount(work: File): Int =
        outDir(work).listFiles()?.count { it.isFile && it.name.endsWith(".jpg") } ?: 0

    fun outFile(work: File, index: Int) = File(outDir(work), "%04d.jpg".format(Locale.US, index + 1))

    /** Halaman untuk dibaca/ekspor: hasil terjemahan; kalau belum ada / gagal, pakai gambar asli. */
    fun readPages(work: File): List<File> =
        pages(work).mapIndexed { i, f -> outFile(work, i).takeIf { it.exists() } ?: f }

    /** Salin satu gambar, atau isi satu CBZ/ZIP, ke folder src. Kembalikan jumlah gambar yang masuk. */
    fun importUri(ctx: Context, work: File, uri: Uri, displayName: String, idx: Int): Int {
        val dir = srcDir(work)
        dir.mkdirs()
        // Berkas kosong (0 byte) sisa impor yang gagal dibuang, supaya bisa disalin ulang.
        dir.listFiles()?.filter { it.isFile && it.length() == 0L }?.forEach { it.delete() }
        val existing = dir.listFiles()?.map { it.name.substringAfter('_') }?.toHashSet() ?: hashSetOf()
        val lower = displayName.lowercase(Locale.ROOT)
        fun safeName(n: String) = n.replace('/', '_').replace('\\', '_')

        if (lower.endsWith(".zip") || lower.endsWith(".cbz")) {
            // Baca lewat daftar isi (ZipFile) pada salinan sementara: lebih andal daripada ZipInputStream
            // untuk CBZ yang ukuran entri-nya baru tercatat di akhir berkas.
            val tmp = File(ctx.externalCacheDir ?: ctx.cacheDir, "import_${System.nanoTime()}.zip")
            try {
                ctx.contentResolver.openInputStream(uri)?.use { input -> tmp.outputStream().use { input.copyTo(it) } }
                var n = 0
                java.util.zip.ZipFile(tmp).use { zf ->
                    for (e in zf.entries().toList()) {
                        val leaf = e.name.substringAfterLast('/')
                        if (e.isDirectory || !isImageName(e.name) || leaf.startsWith(".")) continue
                        val safe = safeName(e.name)
                        if (safe !in existing) {
                            val f = File(dir, "%03d_%s".format(Locale.US, idx, safe))
                            zf.getInputStream(e).use { i -> f.outputStream().use { i.copyTo(it) } }
                            if (f.length() == 0L) { f.delete(); continue }
                        }
                        n++
                    }
                }
                return n
            } finally {
                tmp.delete()
            }
        }
        if (isImageName(displayName)) {
            val safe = safeName(displayName)
            if (safe in existing) return 1
            val f = File(dir, "%03d_%s".format(Locale.US, idx, safe))
            ctx.contentResolver.openInputStream(uri)?.use { input -> f.outputStream().use { input.copyTo(it) } }
            if (f.length() == 0L) { f.delete(); return 0 }
            return 1
        }
        return 0
    }

    fun exportCbz(work: File, target: File): Int {
        val files = readPages(work)
        ZipOutputStream(target.outputStream().buffered()).use { zos ->
            files.forEachIndexed { i, f ->
                zos.putNextEntry(ZipEntry("%04d.%s".format(Locale.US, i + 1, f.extension.lowercase(Locale.ROOT))))
                f.inputStream().use { it.copyTo(zos) }
                zos.closeEntry()
            }
        }
        return files.size
    }

    // ------------------------------------------------------------------ OCR

    class Block(
        val rect: Rect,
        val text: String,
        val angle: Float = 0f,
        val pts: List<Point> = emptyList(),
        /** Tinggi huruf asli (median tinggi baris OCR, piksel gambar asli). 0 = tidak diketahui. */
        val lineH: Int = 0
    )

    fun recognizer(lang: Int): TextRecognizer = when (lang) {
        0 -> TextRecognition.getClient(JapaneseTextRecognizerOptions.Builder().build())
        1 -> TextRecognition.getClient(KoreanTextRecognizerOptions.Builder().build())
        2 -> TextRecognition.getClient(ChineseTextRecognizerOptions.Builder().build())
        else -> TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
    }

    internal fun hasCjk(s: String) = s.any { it.isLetter() && it.code >= 0x2E80 }

    /** Dekode gambar jadi bitmap yang bisa digambar; dikecilkan kalau terlalu besar. */
    fun decode(file: File): Bitmap? {
        val o = BitmapFactory.Options()
        o.inJustDecodeBounds = true
        BitmapFactory.decodeFile(file.path, o)
        if (o.outWidth <= 0 || o.outHeight <= 0) return null
        var sample = 1
        while (o.outWidth / sample > 2400 ||
            (o.outWidth / sample).toLong() * (o.outHeight / sample) > 20_000_000L
        ) sample *= 2
        val o2 = BitmapFactory.Options()
        o2.inSampleSize = sample
        o2.inMutable = true
        o2.inPreferredConfig = Bitmap.Config.ARGB_8888
        return BitmapFactory.decodeFile(file.path, o2)
    }

    // ------------------------------------------------------------------ gabung blok satu balon

    // ------------------------------------------------------------------ gambar ulang

    internal fun colorDist(a: Int, b: Int): Int =
        Math.abs(Color.red(a) - Color.red(b)) + Math.abs(Color.green(a) - Color.green(b)) +
            Math.abs(Color.blue(a) - Color.blue(b))

    /** Tinggi huruf asli tengah (median) di halaman yang sedang dirender; dipakai supaya ukuran huruf antar balon seragam. */
    internal var pageRefH = 0f

    /**
     * Tulis terjemahan mengikuti BENTUK balon: cari bagian dalam balon (flood fill dari tengah teks asli yang sudah
     * dihapus), lalu bungkus kata baris demi baris sesuai lebar balon di tiap ketinggian dan pilih huruf terbesar yang muat.
     * Kembalikan false kalau gagal (pemanggil memakai jalur kotak biasa).
     */
    /** Ukuran huruf hasil typesetInBalloon terakhir yang berhasil (dipakai untuk memilih kapital vs huruf biasa). */
    internal var typesetSize = 0f

    // ------------------------------------------------------------------ satu halaman

    /** Proses satu halaman dan simpan hasilnya sebagai JPEG. Kembalikan jumlah blok teks yang diterjemahkan. */
    fun processPage(
        file: File,
        outFile: File,
        rec: TextRecognizer,
        lang: Int,
        translate: (List<String>) -> List<String>,
        onStep: (String) -> Unit,
        onTiming: (String) -> Unit = {},
        debugDir: File? = null
    ): Int {
        val bmp = decode(file) ?: throw IllegalStateException("Gambar tidak terbaca: ${file.name}")
        try {
            onStep("membaca teks")
            val t0 = System.currentTimeMillis()
            val dbg = if (debugDir != null) StringBuilder() else null
            val blocks = merge(readBlocks(rec, bmp, lang, dbg), lang)
            val t1 = System.currentTimeMillis()
            var t2 = t1
            var trOut: List<String> = emptyList()
            if (debugDir != null) {
                try { saveDebugImage(bmp, blocks, File(debugDir.apply { mkdirs() }, outFile.nameWithoutExtension + ".jpg")) } catch (_: Throwable) {}
            }
            if (blocks.isNotEmpty()) {
                onStep("menerjemahkan ${blocks.size} blok")
                val tr = translate(blocks.map { it.text })
                trOut = tr
                t2 = System.currentTimeMillis()
                onStep("menggambar")
                render(bmp, blocks, tr)
            }
            if (debugDir != null) {
                try {
                    debugDir.mkdirs()
                    File(debugDir, outFile.nameWithoutExtension + ".txt").writeText(buildString {
                        append("gambar ${bmp.width}x${bmp.height}, bahasa $lang, ${blocks.size} blok akhir\n\n")
                        append("--- keputusan pemisahan baris ---\n").append(dbg).append("\n--- blok akhir ---\n")
                        blocks.forEachIndexed { i, b ->
                            append("#$i rect=${b.rect.left},${b.rect.top},${b.rect.right},${b.rect.bottom} sudut=${"%.1f".format(b.angle)}\n  asli: ${b.text}\n  terjemah: ${trOut.getOrNull(i) ?: "-"}\n")
                        }
                    })
                } catch (_: Throwable) {}
            }
            onTiming("OCR ${t1 - t0}ms, terjemah ${t2 - t1}ms, gambar ${System.currentTimeMillis() - t2}ms")
            outFile.parentFile?.mkdirs()
            val tmp = File(outFile.parentFile, outFile.name + ".tmp")
            tmp.outputStream().use { bmp.compress(Bitmap.CompressFormat.JPEG, 92, it) }
            if (!tmp.renameTo(outFile)) {
                tmp.copyTo(outFile, true)
                tmp.delete()
            }
            return blocks.size
        } finally {
            bmp.recycle()
        }
    }
}

/** Supaya fungsi ekstensi di MangaOcr.kt / MangaRender.kt cukup menulis Block (kelas nested tidak terlihat dari luar objek). */
internal typealias Block = MangaEngine.Block
