package com.niven.mangatl

import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.exp
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow
import kotlin.math.sqrt
import kotlin.math.tanh

/** Dasar semua efek: baca parameter, proses blok stereo di tempat. */
abstract class DspFx {
    abstract fun update(sr: Int, os: Int)
    abstract fun process(l: FloatArray, r: FloatArray, n: Int)
    open fun reset() {}
    open val latencySamples: Int get() = 0
    @JvmField var active = false
}

/** Desain filter Butterworth LP/HP ke dalam array biquad mulai dari off. Mengembalikan jumlah seksi. */
fun designButter(arr: Array<Biquad>, off: Int, sr: Int, f: Double, order: Int, high: Boolean): Int {
    var used = 0
    for (i in 1..(order / 2)) {
        val q = if (order % 2 == 0) Dsg.butterQ(order, i) else 1.0 / (2.0 * kotlin.math.cos(PI * i / order))
        if (high) Dsg.highpass(arr[off + used], sr, f, q) else Dsg.lowpass(arr[off + used], sr, f, q)
        used++
    }
    if (order % 2 == 1) {
        if (high) Dsg.highpass1(arr[off + used], sr, f) else Dsg.lowpass1(arr[off + used], sr, f)
        used++
    }
    return used
}

// ======================================================================
// Equalizer: band independen, per kanal, preamp, polaritas
// ======================================================================
class EqFx : DspFx() {
    private val maxB = AudioEngine.EQ_MAX_BANDS
    private val bq = Array(2) { Array(maxB * 4) { Biquad() } }
    private val nSec = IntArray(maxB)
    private val act = IntArray(maxB)
    private var nAct = 0
    private var pre = 1.0
    private var chan = 0
    private var inv = false
    private val orders = intArrayOf(1, 2, 3, 4, 6, 8)

    override fun update(sr: Int, os: Int) {
        val v = AudioEngine.raw(AudioEngine.EQ)
        val count = AudioEngine.eqCount()
        pre = dbToLin(v[6].toDouble())
        chan = v[7].toInt()
        inv = v[8].toInt() == 1
        nAct = 0
        val e = AudioEngine.eqBands
        for (b in 0 until maxB) {
            nSec[b] = 0
            if (b >= count) continue
            val f = e[b * 5].toDouble()
            val g = e[b * 5 + 1].toDouble()
            val q = e[b * 5 + 2].toDouble()
            val t = e[b * 5 + 3].toInt()
            val sl = e[b * 5 + 4].toInt().coerceIn(0, 5)
            var used = 1
            when (t) {
                0 -> if (abs(g) < 0.01) used = 0 else for (c in 0..1) Dsg.peak(bq[c][b * 4], sr, f, g, q)
                1 -> if (abs(g) < 0.01) used = 0 else for (c in 0..1) Dsg.lowShelf(bq[c][b * 4], sr, f, g, q)
                2 -> if (abs(g) < 0.01) used = 0 else for (c in 0..1) Dsg.highShelf(bq[c][b * 4], sr, f, g, q)
                3, 4 -> {
                    for (c in 0..1) used = designButter(bq[c], b * 4, sr, f, orders[sl], t == 4)
                }
                5 -> for (c in 0..1) Dsg.bandpass(bq[c][b * 4], sr, f, q)
                else -> for (c in 0..1) Dsg.notch(bq[c][b * 4], sr, f, q)
            }
            nSec[b] = used
            if (used > 0) act[nAct++] = b
        }
        active = nAct > 0 || abs(pre - 1.0) > 1e-4 || inv
    }

    override fun process(l: FloatArray, r: FloatArray, n: Int) {
        if (!active) return
        val doL = chan != 2
        val doR = chan != 1
        val sg = if (inv) -1.0 else 1.0
        for (i in 0 until n) {
            if (doL) {
                var x = l[i] * pre
                for (a in 0 until nAct) {
                    val b = act[a]
                    for (s in 0 until nSec[b]) x = bq[0][b * 4 + s].process(x)
                }
                l[i] = (x * sg).toFloat()
            }
            if (doR) {
                var x = r[i] * pre
                for (a in 0 until nAct) {
                    val b = act[a]
                    for (s in 0 until nSec[b]) x = bq[1][b * 4 + s].process(x)
                }
                r[i] = (x * sg).toFloat()
            }
        }
    }

    override fun reset() {
        for (c in 0..1) for (b in bq[c]) b.reset()
    }
}

// ======================================================================
// Bass Boost: shelf/peak + high-pass sub-bass + harmonik
// ======================================================================
class BassFx : DspFx() {
    private val sh = Array(2) { Biquad() }
    private val hp = Array(2) { Biquad() }
    private val lpf = Biquad()
    private val hpf = Biquad()
    private val lp2 = Biquad()
    private var amt = 0.0
    private var wet = 1.0
    private var comp = 1.0
    private var gainDb = 0.0
    private var os: OsShaper? = null
    private var osF = 1

    override fun update(sr: Int, osMode: Int) {
        val v = AudioEngine.raw(AudioEngine.BASS)
        gainDb = v[0].toDouble()
        val fc = v[1].toDouble()
        val q = v[2].toDouble()
        for (c in 0..1) {
            if (v[4].toInt() == 0) Dsg.lowShelf(sh[c], sr, fc, gainDb, q) else Dsg.peak(sh[c], sr, fc, gainDb, q)
            Dsg.highpass(hp[c], sr, v[3].toDouble(), 0.7071)
        }
        amt = v[5] / 100.0
        wet = v[7] / 100.0
        comp = if (v[6].toInt() == 1) dbToLin(-0.5 * gainDb) else 1.0
        val f1 = (fc * 1.5).coerceIn(40.0, 200.0)
        Dsg.lowpass(lpf, sr, f1, 0.7071)
        Dsg.highpass(hpf, sr, f1 * 1.4, 0.7071)
        Dsg.lowpass(lp2, sr, 3500.0, 0.7071)
        val f = osMode
        if (f != osF || (f > 1 && os == null)) {
            osF = f
            os = if (f > 1) OsShaper(f) else null
        }
        active = gainDb > 0.01 || amt > 0.001
    }

    /** Tundaan jalur harmonik beroversampling; jalur kering dan linear ditunda sama besar agar fase sejajar. */
    private fun alignDelay(): Int {
        val o = os
        return if (amt > 0.001 && osF > 1 && o != null) o.delaySamples else 0
    }

    override val latencySamples: Int get() = alignDelay()

    private val dXl = DelayLine(64)
    private val dXr = DelayLine(64)
    private val dWl = DelayLine(64)
    private val dWr = DelayLine(64)

    override fun reset() {
        for (c in 0..1) { sh[c].reset(); hp[c].reset() }
        lpf.reset(); hpf.reset(); lp2.reset()
        os?.reset()
        dXl.clear(); dXr.clear(); dWl.clear(); dWr.clear()
    }

    override fun process(l: FloatArray, r: FloatArray, n: Int) {
        if (!active) return
        val o = os
        val dn = alignDelay()
        for (i in 0 until n) {
            val xl = l[i].toDouble()
            val xr = r[i].toDouble()
            var wl = hp[0].process(sh[0].process(xl))
            var wr = hp[1].process(sh[1].process(xr))
            var hh = 0.0
            if (amt > 0.001) {
                val b = lpf.process((xl + xr) * 0.5)
                val s = if (o != null) o.shape(b) { tanh(4.0 * it) } else tanh(4.0 * b)
                hh = lp2.process(hpf.process(s)) * amt * 0.8
            }
            // jalur harmonik tertunda dn sampel (oversampler): tunda kering dan linear sama besar
            dXl.write(xl); dXr.write(xr); dWl.write(wl); dWr.write(wr)
            val dl = if (dn > 0) dXl.readInt(dn) else xl
            val dr = if (dn > 0) dXr.readInt(dn) else xr
            if (dn > 0) { wl = dWl.readInt(dn); wr = dWr.readInt(dn) }
            wl += hh
            wr += hh
            wl *= comp
            wr *= comp
            l[i] = (dl * (1 - wet) + wl * wet).toFloat()
            r[i] = (dr * (1 - wet) + wr * wet).toFloat()
        }
    }
}

// ======================================================================
// Vocal Enhancer
// ======================================================================
class VocalFx : DspFx() {
    private val bandHp = Array(3) { Biquad() }
    private val bandLp = Array(3) { Biquad() }
    private val pres = Biquad()
    private val mud = Biquad()
    private val air = Biquad()
    private val exHp = Biquad()
    private val deBp = Biquad()
    private var gainM = 0.0
    private var presOn = false
    private var clar = 0.0
    private var harm = 0.0
    private var width = 1.0
    private var deAmt = 0.0
    private var wet = 1.0
    private var env = 0.0
    private var envA = 0.0
    private var envR = 0.0
    private var os: OsShaper? = null
    private var osF = 1

    override fun update(sr: Int, osMode: Int) {
        val v = AudioEngine.raw(AudioEngine.VOCAL)
        gainM = dbToLin(v[0].toDouble()) - 1.0
        val cf = v[1].toDouble()
        for (i in 0..2) {
            Dsg.highpass(bandHp[i], sr, 200.0, 0.7071)
            Dsg.lowpass(bandLp[i], sr, 6000.0, 0.7071)
        }
        presOn = abs(v[2]) > 0.01
        Dsg.peak(pres, sr, cf, v[2].toDouble(), 1.0)
        val inten = v[4] / 100.0
        clar = v[3] / 100.0 * inten
        harm = v[6] / 100.0 * inten
        Dsg.peak(mud, sr, 300.0, -4.0 * clar, 0.8)
        Dsg.highShelf(air, sr, 5000.0, 3.0 * clar, 0.7)
        Dsg.highpass(exHp, sr, 3000.0, 0.7071)
        width = v[5] / 100.0
        Dsg.bandpass(deBp, sr, v[7].toDouble(), 2.0)
        deAmt = v[8] / 100.0
        wet = v[9] / 100.0
        envA = exp(-1.0 / (0.001 * sr))
        envR = exp(-1.0 / (0.05 * sr))
        if (osMode != osF || (osMode > 1 && os == null)) {
            osF = osMode
            os = if (osMode > 1) OsShaper(osMode) else null
        }
        active = abs(gainM) > 1e-4 || presOn || clar > 0.001 || harm > 0.001 || abs(width - 1.0) > 1e-3 || deAmt > 0.001
    }

    private fun alignDelay(): Int {
        val o = os
        return if (harm > 0.001 && osF > 1 && o != null) o.delaySamples else 0
    }

    override val latencySamples: Int get() = alignDelay()

    private val dM = DelayLine(64)
    private val dS = DelayLine(64)
    private val dXl = DelayLine(64)
    private val dXr = DelayLine(64)

    override fun reset() {
        for (b in bandHp) b.reset()
        for (b in bandLp) b.reset()
        pres.reset(); mud.reset(); air.reset(); exHp.reset(); deBp.reset()
        env = 0.0
        os?.reset()
        dM.clear(); dS.clear(); dXl.clear(); dXr.clear()
    }

    override fun process(l: FloatArray, r: FloatArray, n: Int) {
        if (!active) return
        val o = os
        val thr = 0.03
        val dn = alignDelay()
        for (i in 0 until n) {
            val xl = l[i].toDouble()
            val xr = r[i].toDouble()
            var m = (xl + xr) * 0.5
            var s = (xl - xr) * 0.5
            val vb = bandLp[0].process(bandHp[0].process(m))
            if (abs(gainM) > 1e-4) m += gainM * vb
            if (presOn) m = pres.process(m)
            if (clar > 0.001) m = air.process(mud.process(m))
            if (abs(width - 1.0) > 1e-3) {
                val lb = bandLp[1].process(bandHp[1].process(xl))
                val rb = bandLp[2].process(bandHp[2].process(xr))
                s += (width - 1.0) * (lb - rb) * 0.5
            }
            // harmonik lewat oversampler tertunda dn sampel: selaraskan jalur kering/linear agar tidak comb filtering
            var sat = 0.0
            if (harm > 0.001) sat = if (o != null) o.shape(vb) { tanh(3.0 * it) } else tanh(3.0 * vb)
            dM.write(m); dS.write(s); dXl.write(xl); dXr.write(xr)
            var dl = xl
            var dr = xr
            if (dn > 0) { m = dM.readInt(dn); s = dS.readInt(dn); dl = dXl.readInt(dn); dr = dXr.readInt(dn) }
            if (harm > 0.001) m += exHp.process(sat) * harm * 0.3
            if (deAmt > 0.001) {
                val band = deBp.process(m)
                val a = abs(band)
                env = if (a > env) a + (env - a) * envA else a + (env - a) * envR
                if (env > thr) {
                    val ratio = 1.0 + deAmt * 7.0
                    val g = (env / thr).pow(1.0 / ratio - 1.0)
                    m += band * (g - 1.0)
                }
            }
            val pl = m + s
            val pr = m - s
            l[i] = (dl * (1 - wet) + pl * wet).toFloat()
            r[i] = (dr * (1 - wet) + pr * wet).toFloat()
        }
    }
}

// ======================================================================
// Stereo Width (mid/side)
// ======================================================================
class StereoFx : DspFx() {
    private var width = 1.0
    private var midG = 1.0
    private var sideG = 1.0
    private var gl = 1.0
    private var gr = 1.0
    private var focus = 0.0
    private var monoSafe = true
    private var freqDep = false
    private val sLow = Biquad()
    private var sLL = 1e-9
    private var sRR = 1e-9
    private var sLR = 0.0
    private var cc = 0.0
    private var corr = 0.0
    private var guard = 1.0
    private var cnt = 0

    override fun update(sr: Int, os: Int) {
        val v = AudioEngine.raw(AudioEngine.STEREO)
        width = v[0] / 100.0
        midG = dbToLin(v[1].toDouble())
        sideG = dbToLin(v[2].toDouble())
        val b = v[3] / 100.0
        gl = if (b > 0) 1 - b else 1.0
        gr = if (b < 0) 1 + b else 1.0
        focus = v[4] / 100.0
        monoSafe = v[5].toInt() == 1
        freqDep = v[7].toInt() == 1
        Dsg.lowpass1(sLow, sr, 250.0)
        cc = exp(-1.0 / (0.3 * sr))
        active = true
    }

    override fun reset() {
        sLow.reset()
        sLL = 1e-9; sRR = 1e-9; sLR = 0.0
        corr = 0.0; guard = 1.0; cnt = 0
    }

    private fun isNeutral() = abs(width - 1) < 1e-3 && abs(midG - 1) < 1e-4 && abs(sideG - 1) < 1e-4 &&
        gl == 1.0 && gr == 1.0 && focus < 1e-3

    override fun process(l: FloatArray, r: FloatArray, n: Int) {
        val neutral = isNeutral()
        for (i in 0 until n) {
            var a = l[i].toDouble()
            var b = r[i].toDouble()
            if (!neutral) {
                var m = (a + b) * 0.5 * midG
                var s = (a - b) * 0.5 * sideG
                var w = width
                if (w > 1.0 && monoSafe) w = 1.0 + (w - 1.0) * guard
                if (w > 1.0 && (monoSafe || freqDep)) {
                    val low = sLow.process(s)
                    val lowW = if (monoSafe) 1.0 else 1.0 + (w - 1.0) * 0.25
                    s = low * lowW + (s - low) * w
                } else {
                    s *= w
                }
                if (focus > 0) {
                    m *= 1.0 + 0.5 * focus
                    s *= 1.0 - 0.5 * focus
                }
                a = (m + s) * gl
                b = (m - s) * gr
                l[i] = a.toFloat()
                r[i] = b.toFloat()
            }
            sLL = sLL * cc + a * a * (1 - cc)
            sRR = sRR * cc + b * b * (1 - cc)
            sLR = sLR * cc + a * b * (1 - cc)
        }
        cnt += n
        if (cnt >= 2048) {
            cnt = 0
            corr = (sLR / sqrt(sLL * sRR + 1e-12)).coerceIn(-1.0, 1.0)
            guard = ((corr + 0.2) / 0.4).coerceIn(0.3, 1.0)
            AudioEngine.meterCorr = corr.toFloat()
        }
    }
}

// ======================================================================
// Crossfeed
// ======================================================================
class CrossFx : DspFx() {
    private val lp = Array(2) { Array(2) { Biquad() } }
    private val shelf = Array(2) { Biquad() }
    private val dl = DelayLine(512)
    private val dr = DelayLine(512)
    private var delaySamp = 0.0
    private var gain = 0.0
    private var mix = 0.0
    private var comp = false
    private var lr = false

    override fun update(sr: Int, os: Int) {
        val v = AudioEngine.raw(AudioEngine.XFEED)
        val level = v[0] / 100.0
        val angleK = kotlin.math.sin(Math.toRadians(v[5].toDouble())) / kotlin.math.sin(Math.toRadians(30.0))
        lr = v[6].toInt() == 1
        for (c in 0..1) {
            Dsg.lowpass(lp[c][0], sr, v[2].toDouble(), 0.7071)
            Dsg.lowpass(lp[c][1], sr, v[2].toDouble(), 0.7071)
        }
        delaySamp = (v[3] / 1000.0 * sr * angleK).coerceIn(0.0, 400.0)
        gain = dbToLin(v[4].toDouble()) * level * angleK.coerceIn(0.0, 2.0)
        mix = v[7] / 100.0
        comp = v[8].toInt() == 1
        // bass naik sekitar gain saat sinyal mono: kompensasi dengan low-shelf
        val lowRise = gain
        for (c in 0..1) {
            if (comp && lowRise > 1e-4) Dsg.lowShelf(shelf[c], sr, v[1].toDouble(), -20.0 * kotlin.math.log10(1.0 + lowRise), 0.7071)
            else shelf[c].pass()
        }
        active = level > 0.001 || mix > 0.001
    }

    override fun reset() {
        for (c in 0..1) { for (b in lp[c]) b.reset(); shelf[c].reset() }
        dl.clear(); dr.clear()
    }

    override fun process(l: FloatArray, r: FloatArray, n: Int) {
        if (!active) return
        for (i in 0 until n) {
            val a = l[i].toDouble()
            val b = r[i].toDouble()
            var cl = lp[0][0].process(a)
            var cr = lp[1][0].process(b)
            if (lr) {
                cl = lp[0][1].process(cl)
                cr = lp[1][1].process(cr)
            }
            dl.write(cl)
            dr.write(cr)
            val fromL = dl.read(delaySamp) * gain
            val fromR = dr.read(delaySamp) * gain
            var ol = shelf[0].process(a) + fromR
            var or = shelf[1].process(b) + fromL
            if (mix > 0.001) {
                val m = (ol + or) * 0.5
                ol = ol * (1 - mix) + m * mix
                or = or * (1 - mix) + m * mix
            }
            l[i] = ol.toFloat()
            r[i] = or.toFloat()
        }
    }
}

// ======================================================================
// Compressor
// ======================================================================
class CompFx : DspFx() {
    private val sc = Array(2) { Biquad() }
    private var scOn = false
    private var thr = -18.0
    private var ratio = 2.0
    private var knee = 6.0
    private var makeup = 0.0
    private var aC = 0.0
    private var rC = 0.0
    private var rms = false
    private var link = 1.0
    private var mix = 1.0
    private var rmsC = 0.0
    private var msL = 0.0
    private var msR = 0.0
    private var grL = 0.0
    private var grR = 0.0

    override fun update(sr: Int, os: Int) {
        val v = AudioEngine.raw(AudioEngine.COMP)
        thr = v[0].toDouble()
        ratio = v[1].toDouble()
        aC = 1.0 - exp(-1.0 / (v[2] * 0.001 * sr))
        rC = 1.0 - exp(-1.0 / (v[3] * 0.001 * sr))
        knee = v[4].toDouble()
        makeup = v[5].toDouble()
        scOn = v[6] > 20.5f
        if (scOn) for (c in 0..1) Dsg.highpass(sc[c], sr, v[6].toDouble(), 0.7071)
        rms = v[7].toInt() == 1
        link = v[8] / 100.0
        mix = v[9] / 100.0
        rmsC = exp(-1.0 / (0.01 * sr))
        active = true
    }

    override fun reset() {
        for (b in sc) b.reset()
        msL = 0.0; msR = 0.0; grL = 0.0; grR = 0.0
    }

    private fun gr(db: Double): Double {
        val over = db - thr
        val out = when {
            2 * over < -knee -> db
            knee > 0 && 2 * abs(over) <= knee -> db + (1.0 / ratio - 1.0) * (over + knee / 2) * (over + knee / 2) / (2 * knee)
            else -> thr + over / ratio
        }
        return out - db
    }

    override fun process(l: FloatArray, r: FloatArray, n: Int) {
        for (i in 0 until n) {
            val a = l[i].toDouble()
            val b = r[i].toDouble()
            val sa = if (scOn) sc[0].process(a) else a
            val sb = if (scOn) sc[1].process(b) else b
            val la: Double
            val lb: Double
            if (rms) {
                msL = msL * rmsC + sa * sa * (1 - rmsC)
                msR = msR * rmsC + sb * sb * (1 - rmsC)
                la = sqrt(msL)
                lb = sqrt(msR)
            } else {
                la = abs(sa)
                lb = abs(sb)
            }
            val mx = max(la, lb)
            val ea = la + link * (mx - la)
            val eb = lb + link * (mx - lb)
            val ta = gr(linToDb(ea))
            val tb = gr(linToDb(eb))
            grL += (ta - grL) * (if (ta < grL) aC else rC)
            grR += (tb - grR) * (if (tb < grR) aC else rC)
            val ya = a * dbToLin(grL + makeup)
            val yb = b * dbToLin(grR + makeup)
            l[i] = (a * (1 - mix) + ya * mix).toFloat()
            r[i] = (b * (1 - mix) + yb * mix).toFloat()
        }
    }
}

// ======================================================================
// Limiter: lookahead, deteksi true-peak (oversampling), knee, link
// ======================================================================
class LimitFx : DspFx() {
    private var inG = 1.0
    private var outG = 1.0
    private var thrDb = -1.0
    private var ceil = 0.89
    private var post = 1.0
    private var knee = 0.0
    private var aC = 0.0
    private var rC = 0.0
    private var link = 1.0
    private var look = 0
    private var dly = 0
    private var osN = 4
    private var sr = 48000

    // jendela min (monotonic deque) per kanal
    private var cap = 8
    private var dqIdx = Array(2) { LongArray(8) }
    private var dqVal = Array(2) { DoubleArray(8) }
    private val head = IntArray(2)
    private val tail = IntArray(2)
    private var counter = 0L
    private var dLine = Array(2) { DoubleArray(8) }
    private var dPos = 0
    private val sm = DoubleArray(2) { 1.0 }
    private val hist = Array(2) { DoubleArray(17) }
    private var hPos = 0
    private var tpTaps: Array<DoubleArray> = emptyArray()

    override val latencySamples: Int get() = dly

    /** Batas puncak keluaran (linear) yang dijamin oleh Limiter. */
    val ceilLin: Double get() = ceil

    override fun update(sr: Int, os: Int) {
        val v = AudioEngine.raw(AudioEngine.LIMIT)
        this.sr = sr
        thrDb = v[0].toDouble()
        val ceilDb = v[1].toDouble()
        ceil = dbToLin(ceilDb)
        post = dbToLin(ceilDb - thrDb)
        aC = 1.0 - exp(-1.0 / (max(v[2], 0.01f) * 0.001 * sr / 3.0))
        rC = 1.0 - exp(-1.0 / (v[3] * 0.001 * sr))
        look = (v[4] * 0.001 * sr).toInt()
        knee = v[5].toDouble()
        val mode = v[6].toInt()
        val nOs = if (mode == 0) 1 else 1 shl mode
        if (nOs != osN || tpTaps.isEmpty()) {
            osN = nOs
            buildTaps()
        }
        link = v[7] / 100.0
        inG = dbToLin(v[8].toDouble())
        outG = dbToLin(v[9].toDouble())
        dly = look + (if (osN > 1) 8 else 0)
        val need = dly + 2
        if (need != cap) {
            cap = need
            dqIdx = Array(2) { LongArray(cap) }
            dqVal = Array(2) { DoubleArray(cap) }
            dLine = Array(2) { DoubleArray(max(dly, 1)) }
            head[0] = 0; head[1] = 0; tail[0] = 0; tail[1] = 0
            counter = 0L
            dPos = 0
            sm[0] = 1.0; sm[1] = 1.0
        }
        active = true
    }

    /** Filter interpolasi 16 tap per fase untuk mengestimasi puncak di antara sampel. */
    private fun buildTaps() {
        if (osN <= 1) {
            tpTaps = Array(1) { DoubleArray(1) }
            return
        }
        val len = 16 * osN
        val proto = Win.kaiserSinc(len, 0.5 / osN * 0.95, osN.toDouble(), 7.0)
        tpTaps = Array(osN) { p -> DoubleArray(16) { k -> proto[p + k * osN] } }
    }

    private fun reduction(peak: Double): Double {
        if (peak < 1e-9) return 1.0
        val db = linToDb(peak) + 0.0
        val over = db - thrDb
        val r = when {
            2 * over < -knee -> 0.0
            knee > 0 && 2 * abs(over) <= knee -> (over + knee / 2) * (over + knee / 2) / (2 * knee)
            else -> over
        }
        return if (r <= 0.0) 1.0 else dbToLin(-r)
    }

    override fun reset() {
        for (c in 0..1) {
            java.util.Arrays.fill(dLine[c], 0.0)
            java.util.Arrays.fill(hist[c], 0.0)
        }
        sm[0] = 1.0; sm[1] = 1.0
        head[0] = 0; head[1] = 0; tail[0] = 0; tail[1] = 0
        counter = 0L
        dPos = 0
        hPos = 0
    }

    override fun process(l: FloatArray, r: FloatArray, n: Int) {
        val win = dly + 1
        val dLen = max(dly, 1)
        val gUp = max(outG, 1.0)
        val lim = ceil * min(outG, 1.0)
        for (i in 0 until n) {
            val x0 = l[i] * inG
            val x1 = r[i] * inG
            // puncak per kanal (sampel + estimasi antar-sampel)
            hPos = (hPos + 1) % 17
            hist[0][hPos] = x0
            hist[1][hPos] = x1
            var p0 = abs(x0)
            var p1 = abs(x1)
            if (osN > 1) {
                for (c in 0..1) {
                    var pk = if (c == 0) p0 else p1
                    for (ph in 1 until osN) {
                        var s = 0.0
                        val taps = tpTaps[ph]
                        for (k in 0 until 16) s += taps[k] * hist[c][((hPos - k) % 17 + 17) % 17]
                        val a = abs(s)
                        if (a > pk) pk = a
                    }
                    if (c == 0) p0 = pk else p1 = pk
                }
            }
            val mx = max(p0, p1)
            // Output Gain > 0 dB dihitung masuk ke deteksi: puncak akhir tetap <= ceiling (bukan ceiling * outG)
            val e0 = (p0 + link * (mx - p0)) * gUp
            val e1 = (p1 + link * (mx - p1)) * gUp
            val g0 = reduction(e0)
            val g1 = reduction(e1)
            val d0 = dLine[0][dPos]
            val d1 = dLine[1][dPos]
            dLine[0][dPos] = x0
            dLine[1][dPos] = x1
            dPos = (dPos + 1) % dLen
            // jendela minimum
            val gm0 = slideMin(0, g0, win)
            val gm1 = slideMin(1, g1, win)
            sm[0] += (gm0 - sm[0]) * (if (gm0 < sm[0]) aC else rC)
            sm[1] += (gm1 - sm[1]) * (if (gm1 < sm[1]) aC else rC)
            val o0 = if (dly > 0) d0 else x0
            val o1 = if (dly > 0) d1 else x1
            val y0 = (o0 * sm[0] * post * outG).coerceIn(-lim, lim)
            val y1 = (o1 * sm[1] * post * outG).coerceIn(-lim, lim)
            l[i] = y0.toFloat()
            r[i] = y1.toFloat()
            counter++
        }
    }

    private fun slideMin(c: Int, g: Double, win: Int): Double {
        val ix = dqIdx[c]
        val vl = dqVal[c]
        var t = tail[c]
        var h = head[c]
        // buang nilai lebih besar dari g di ujung belakang
        while (t != h && vl[(t - 1 + cap) % cap] >= g) t = (t - 1 + cap) % cap
        ix[t] = counter
        vl[t] = g
        t = (t + 1) % cap
        // buang yang keluar jendela
        while (h != t && ix[h] <= counter - win) h = (h + 1) % cap
        tail[c] = t
        head[c] = h
        return vl[h]
    }
}
