package com.niven.mangatl

import android.content.ContentValues
import android.content.Context
import android.media.MediaScannerConnection
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import android.util.Base64
import android.webkit.CookieManager
import android.webkit.MimeTypeMap
import android.webkit.URLUtil
import java.io.ByteArrayInputStream
import java.io.File
import java.io.FileOutputStream
import java.io.InputStream
import java.io.OutputStream
import java.net.HttpURLConnection
import java.net.URL

/**
 * Menyimpan file APA ADANYA dari tombol "Unduh" bawaan situs (semua format). Tujuan folder menurut jenis:
 * video -> Movies/BunnyTL (muncul di pemutar Video BunnyTL), audio -> Music/BunnyTL, gambar -> Pictures/BunnyTL,
 * lainnya (PDF, ZIP, APK, dokumen, ...) -> Download/BunnyTL. Terpisah dari mesin yt-dlp ("Unduh video ini").
 */
object FileDownloader {

    class Saved(val name: String, val mime: String, val bytes: Long, val where: String)

    private enum class Kind(val dirType: String, val label: String) {
        VIDEO(Environment.DIRECTORY_MOVIES, "Movies/BunnyTL"),
        AUDIO(Environment.DIRECTORY_MUSIC, "Music/BunnyTL"),
        IMAGE(Environment.DIRECTORY_PICTURES, "Pictures/BunnyTL"),
        FILE(Environment.DIRECTORY_DOWNLOADS, "Download/BunnyTL")
    }

    /** Panggil di thread latar. [url] boleh http(s) atau data:. [onProgress] (selesai, total atau -1). */
    fun download(
        ctx: Context, url: String, referer: String, ua: String,
        contentDisposition: String?, mimeHint: String?, nameHint: String?,
        onProgress: (Long, Long) -> Unit,
        cookieFor: ((String) -> String?)? = null
    ): Saved {
        if (url.startsWith("data:")) {
            val comma = url.indexOf(',')
            require(comma > 0) { "Data file tidak valid." }
            val head = url.substring(5, comma)
            val body = url.substring(comma + 1)
            val bytes = if (head.contains(";base64")) Base64.decode(body, Base64.DEFAULT) else Uri.decode(body).toByteArray()
            val mime = head.substringBefore(';').ifEmpty { mimeHint ?: "application/octet-stream" }
            val name = nameHint ?: URLUtil.guessFileName("file", null, mime)
            return write(ctx, ByteArrayInputStream(bytes), name, mime, bytes.size.toLong(), onProgress)
        }
        require(url.startsWith("http")) { "Link bukan http(s)." }
        val c = URL(url).openConnection() as HttpURLConnection
        try {
            c.connectTimeout = 20_000
            c.readTimeout = 60_000
            c.instanceFollowRedirects = true
            c.setRequestProperty("User-Agent", ua.ifEmpty { "Mozilla/5.0 (Linux; Android 13) AppleWebKit/537.36 Chrome/120 Mobile Safari/537.36" })
            c.setRequestProperty("Accept", "*/*")
            if (referer.startsWith("http")) c.setRequestProperty("Referer", referer)
            (cookieFor?.invoke(url) ?: CookieManager.getInstance().getCookie(url))?.takeIf { it.isNotBlank() }?.let { c.setRequestProperty("Cookie", it) }
            val code = c.responseCode
            check(code in 200..299) { "HTTP $code" }
            fun real(m: String?) = m?.substringBefore(';')?.trim()?.lowercase()
                ?.takeIf { it.isNotEmpty() && it != "application/octet-stream" && it != "binary/octet-stream" }
            val cd = c.getHeaderField("Content-Disposition") ?: contentDisposition
            var mime = real(c.contentType) ?: real(mimeHint)
            val guessed = URLUtil.guessFileName(url, cd, mime)
            if (mime == null) {
                mime = MimeTypeMap.getSingleton().getMimeTypeFromExtension(guessed.substringAfterLast('.', "").lowercase())
                    ?: "application/octet-stream"
            }
            val name = if (nameHint != null && !URLUtil.guessFileName(url, cd, null).contains('.')) nameHint else guessed
            return c.inputStream.use { write(ctx, it, name, mime, c.contentLengthLong, onProgress) }
        } finally {
            c.disconnect()
        }
    }

    private fun write(ctx: Context, input: InputStream, rawName: String, mime: String, total: Long, onProgress: (Long, Long) -> Unit): Saved {
        val kind = when {
            mime.startsWith("video/") -> Kind.VIDEO
            mime.startsWith("audio/") -> Kind.AUDIO
            mime.startsWith("image/") && !mime.contains("svg") -> Kind.IMAGE
            else -> Kind.FILE
        }
        val name = rawName.replace(Regex("[\\\\/:*?\"<>|\\u0000-\\u001F]"), "_").trim().trim('.').ifEmpty { "file" }.take(120)
        var done = 0L
        fun copy(out: OutputStream) {
            val buf = ByteArray(128 * 1024)
            while (true) {
                val r = input.read(buf)
                if (r < 0) break
                out.write(buf, 0, r)
                done += r
                onProgress(done, total)
            }
        }

        if (Build.VERSION.SDK_INT >= 29) {
            val vol = MediaStore.VOLUME_EXTERNAL_PRIMARY
            val coll = when (kind) {
                Kind.VIDEO -> MediaStore.Video.Media.getContentUri(vol)
                Kind.AUDIO -> MediaStore.Audio.Media.getContentUri(vol)
                Kind.IMAGE -> MediaStore.Images.Media.getContentUri(vol)
                Kind.FILE -> MediaStore.Downloads.getContentUri(vol)
            }
            val cv = ContentValues().apply {
                put(MediaStore.MediaColumns.DISPLAY_NAME, name)
                put(MediaStore.MediaColumns.MIME_TYPE, mime)
                put(MediaStore.MediaColumns.RELATIVE_PATH, kind.label)
                put(MediaStore.MediaColumns.IS_PENDING, 1)
                if (kind == Kind.AUDIO) put(MediaStore.Audio.Media.IS_MUSIC, 1)
            }
            val uri = ctx.contentResolver.insert(coll, cv) ?: throw IllegalStateException("Tidak bisa membuat file di penyimpanan.")
            try {
                ctx.contentResolver.openOutputStream(uri)?.use { copy(it) } ?: throw IllegalStateException("Tidak bisa menulis file.")
                ctx.contentResolver.update(uri, ContentValues().apply { put(MediaStore.MediaColumns.IS_PENDING, 0) }, null, null)
            } catch (t: Throwable) {
                runCatching { ctx.contentResolver.delete(uri, null, null) }
                throw t
            }
            return Saved(name, mime, done, kind.label)
        }

        val dir = File(Environment.getExternalStoragePublicDirectory(kind.dirType), "BunnyTL").apply { mkdirs() }
        var f = File(dir, name)
        var n = 1
        while (f.exists()) {
            f = File(dir, name.substringBeforeLast('.', name) + " ($n)" + (if (name.contains('.')) "." + name.substringAfterLast('.') else ""))
            n++
        }
        FileOutputStream(f).use { copy(it) }
        MediaScannerConnection.scanFile(ctx, arrayOf(f.absolutePath), arrayOf(mime), null)
        return Saved(f.name, mime, done, kind.label)
    }
}
