package com.niven.mangatl

import android.net.Uri
import android.widget.Toast
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata

// Layar Musik: menu satu lagu (info, pindah, hapus, playlist) dan memulai pemutaran / antrean.
// Fungsi ekstensi dari MusicActivity; keadaan dan siklus hidup layar tetap di MusicActivity.kt.

internal fun MusicActivity.trackMenu(t: Library.Track, d: Drill?) {
    val items = ArrayList<Sheet.Item?>()
    items.add(Sheet.Item("Pilih", R.drawable.ic_check) {
        startSelect(
            t.id, { shownIds }, { refresh(true) },
            { ids -> moveTracks(ids) }, { ids -> confirmDeleteTracks(ids) }
        )
    })
    items.add(null)
    items.add(Sheet.Item("Putar berikutnya", R.drawable.ic_next) { playNext(t) })
    items.add(Sheet.Item("Tambah ke antrean", R.drawable.ic_queue) { addToQueue(t) })
    if (MusicStore.isFav(this, t.id)) {
        items.add(Sheet.Item("Hapus dari favorit", R.drawable.ic_fav) {
            MusicStore.toggleFav(this, t.id); reloadDrill(); refresh(true)
        })
    } else {
        items.add(Sheet.Item("Tambah ke favorit", R.drawable.ic_fav_border) {
            MusicStore.toggleFav(this, t.id); reloadDrill(); refresh(true)
        })
    }
    items.add(Sheet.Item("Tambah ke playlist", R.drawable.ic_playlist) { pickPlaylist(t) })
    if (d != null && d.kind == 2 && d.playlist != null) {
        items.add(Sheet.Item("Hapus dari playlist", R.drawable.ic_playlist) {
            MusicStore.removeFrom(this, d.playlist, t.id)
            reloadDrill()
            refresh(true)
        })
    }
    items.add(null)
    items.add(Sheet.Item("Ganti nama", R.drawable.ic_edit) {
        renameDialog(t.uri, t.fileBase, t.ext, "lagu") { onMediaReady() }
    })
    items.add(Sheet.Item("Edit info", R.drawable.ic_music_note) { editInfo(t) })
    items.add(Sheet.Item("Pindahkan ke folder", R.drawable.ic_move) { moveTrack(t) })
    items.add(null)
    items.add(Sheet.Item("Hapus dari HP", R.drawable.ic_trash, true) { confirmDeleteTrack(t) })
    Sheet.menu(this, t.title, t.artist, items)
}

internal fun MusicActivity.editInfo(t: Library.Track) {
    val artist = if (t.artist == "Tidak diketahui") "" else t.artist
    Sheet.form(
        this, "Edit info lagu", null,
        listOf("Judul" to t.title, "Artis" to artist, "Album" to t.album), "Simpan"
    ) { f ->
        val v = android.content.ContentValues()
        v.put(android.provider.MediaStore.Audio.Media.TITLE, f[0].trim().ifEmpty { t.title })
        v.put(android.provider.MediaStore.Audio.Media.ARTIST, f[1].trim())
        v.put(android.provider.MediaStore.Audio.Media.ALBUM, f[2].trim())
        updateMedia(t.uri, v) { ok ->
            if (ok) {
                Toast.makeText(this, "Info lagu disimpan.", Toast.LENGTH_SHORT).show()
                onMediaReady()
            }
        }
    }
}

internal fun MusicActivity.moveTrack(t: Library.Track) {
    moveDialog(
        t.uri, t.rel, tracks.map { it.rel }.filter { it.isNotEmpty() },
        listOf("Music/", "Alarms/", "Notifications/", "Podcasts/", "Ringtones/", "Audiobooks/", "Recordings/"),
        "Music/"
    ) { onMediaReady() }
}

internal fun MusicActivity.confirmDeleteTrack(t: Library.Track) {
    Sheet.confirm(
        this, "Hapus lagu permanen?",
        "\"${t.title}\" akan dihapus dari HP dan tidak bisa dikembalikan.", "Hapus", true
    ) {
        deleteMedia(listOf(t.uri)) { ok ->
            if (ok) {
                drill?.let { d -> d.tracks = d.tracks.filter { it.id != t.id } }
                Toast.makeText(this, "Lagu dihapus.", Toast.LENGTH_SHORT).show()
                onMediaReady()
            }
        }
    }
}

internal fun MusicActivity.pickPlaylist(t: Library.Track) {
    val names = MusicStore.playlists(this).keys.toList()
    val items = ArrayList<Sheet.Item?>()
    for (n in names) {
        items.add(Sheet.Item(n, R.drawable.ic_playlist) {
            MusicStore.addTo(this, n, t.id)
            Toast.makeText(this, "Ditambahkan ke $n", Toast.LENGTH_SHORT).show()
            refresh(true)
        })
    }
    if (names.isNotEmpty()) items.add(null)
    items.add(Sheet.Item("Playlist baru", R.drawable.ic_add) { createPlaylistDialog(t) })
    Sheet.menu(this, "Tambah ke playlist", null, items)
}

internal fun MusicActivity.createPlaylistDialog(add: Library.Track?) {
    Sheet.input(this, "Playlist baru", "Nama playlist", "", "Buat") { raw ->
        val n = raw.trim()
        if (n.isNotEmpty()) {
            MusicStore.create(this, n)
            if (add != null) MusicStore.addTo(this, n, add.id)
            refresh(true)
        }
    }
}

internal fun MusicActivity.confirmDeletePlaylist(name: String) {
    Sheet.confirm(this, "Hapus playlist \"$name\"?", "Lagu di dalamnya tidak ikut terhapus dari HP.", "Hapus", true) {
        MusicStore.delete(this, name)
        refresh(true)
    }
}

internal fun MusicActivity.item(t: Library.Track): MediaItem {
    val art = Uri.parse("content://media/external/audio/albumart/${t.albumId}")
    return MediaItem.Builder()
        .setMediaId(t.id.toString())
        .setUri(t.uri)
        .setMediaMetadata(
            MediaMetadata.Builder()
                .setTitle(t.title)
                .setArtist(t.artist)
                .setAlbumTitle(t.album)
                .setArtworkUri(art)
                .build()
        )
        .build()
}

internal fun MusicActivity.playQueue(queue: List<Library.Track>, index: Int, shuffle: Boolean) {
    val c = controller ?: run {
        Toast.makeText(this, "Pemutar belum siap, coba lagi.", Toast.LENGTH_SHORT).show()
        return
    }
    queue.getOrNull(index)?.let { wheel.setPlayingKey(it.id, true) }
    c.shuffleModeEnabled = shuffle
    c.setMediaItems(queue.map { item(it) }, index, 0L)
    c.prepare()
    c.play()
}

internal fun MusicActivity.playNext(t: Library.Track) {
    val c = controller ?: return
    if (c.mediaItemCount == 0) {
        playQueue(listOf(t), 0, false)
    } else {
        c.addMediaItem(c.currentMediaItemIndex + 1, item(t))
        Toast.makeText(this, "Diputar berikutnya", Toast.LENGTH_SHORT).show()
    }
}

internal fun MusicActivity.addToQueue(t: Library.Track) {
    val c = controller ?: return
    if (c.mediaItemCount == 0) {
        playQueue(listOf(t), 0, false)
    } else {
        c.addMediaItem(item(t))
        Toast.makeText(this, "Masuk antrean", Toast.LENGTH_SHORT).show()
    }
}
