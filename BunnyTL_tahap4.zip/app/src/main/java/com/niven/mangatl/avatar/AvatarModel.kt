package com.niven.mangatl

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.opengl.GLES20
import android.opengl.GLUtils
import android.util.Log
import com.live2d.sdk.cubism.core.ICubismLogger
import com.live2d.sdk.cubism.framework.CubismFramework
import com.live2d.sdk.cubism.framework.ICubismLoadFileFunction
import com.live2d.sdk.cubism.framework.id.CubismId
import com.live2d.sdk.cubism.framework.math.CubismMatrix44
import com.live2d.sdk.cubism.framework.model.CubismUserModel
import com.live2d.sdk.cubism.framework.motion.CubismMotion
import com.live2d.sdk.cubism.framework.motion.CubismPhysicsUpdater
import com.live2d.sdk.cubism.framework.rendering.android.CubismRendererAndroid
import java.util.concurrent.Callable
import java.util.concurrent.Executors
import java.util.concurrent.Future

/** Menyalakan Cubism Framework sekali per proses. */
object AvatarCore {
    fun ensure(ctx: Context) {
        if (!CubismFramework.isStarted()) {
            val app = ctx.applicationContext
            val opt = CubismFramework.Option()
            opt.logFunction = ICubismLogger { msg -> Log.d("Avatar", msg) }
            opt.loadFileFunction = ICubismLoadFileFunction { path ->
                try {
                    ModelStore.open(app, path).use { it.readBytes() }
                } catch (e: Exception) {
                    Log.e("Avatar", "Gagal baca asset $path: ${e.message}")
                    ByteArray(0)
                }
            }
            CubismFramework.startUp(opt)
        }
        if (!CubismFramework.isInitialized()) CubismFramework.initialize()
    }
}

/**
 * Decode tekstur PNG di thread latar (paralel) supaya thread GL tidak tertahan.
 * prefetch() dipanggil sedini mungkin; take() mengambil hasilnya.
 */
object AvatarTex {
    private val pool = Executors.newFixedThreadPool(3) { r ->
        Thread(r, "avatar-tex").apply {
            isDaemon = true
            priority = Thread.NORM_PRIORITY - 1
        }
    }
    private val pending = HashMap<String, Future<Bitmap?>>()

    private fun decode(app: Context, path: String): Bitmap? {
        val opts = BitmapFactory.Options().apply { inPremultiplied = true }
        return ModelStore.open(app, path).use { BitmapFactory.decodeStream(it, null, opts) }
    }

    /** Mulai decode path-path ini. Decode model lain yang masih menggantung dibuang (hemat memori). */
    @Synchronized
    fun prefetch(ctx: Context, paths: List<String>) {
        val app = ctx.applicationContext
        val it = pending.entries.iterator()
        while (it.hasNext()) {
            val e = it.next()
            if (e.key !in paths) {
                e.value.cancel(true)
                try {
                    if (e.value.isDone && !e.value.isCancelled) e.value.get()?.recycle()
                } catch (_: Throwable) {
                }
                it.remove()
            }
        }
        for (p in paths) {
            if (pending.containsKey(p)) continue
            pending[p] = pool.submit(Callable<Bitmap?> {
                try {
                    decode(app, p)
                } catch (e: Throwable) {
                    Log.e("Avatar", "Decode gagal $p: ${e.message}")
                    null
                }
            })
        }
    }

    /** Ambil bitmap hasil prefetch (kalau belum ada, decode langsung). Pemanggil wajib recycle(). */
    fun take(ctx: Context, path: String): Bitmap? {
        val f = synchronized(this) { pending.remove(path) }
        return try {
            f?.get() ?: decode(ctx.applicationContext, path)
        } catch (e: Throwable) {
            decode(ctx.applicationContext, path)
        }
    }
}

/** Satu model Live2D (assets/models/<id>), diatur oleh ModelCfg. Semua fungsi dipanggil dari thread GL. */
class AvatarModel(private val ctx: Context, private val cfg: ModelCfg) : CubismUserModel() {

    private val texIds = ArrayList<Int>()
    private var loaded = false
    private var texCount = 0
    private var nextTex = 0

    private val idm = CubismFramework.getIdManager()
    private fun id(role: String): CubismId? {
        val n = cfg.params[role] ?: return null
        return if (n.isEmpty()) null else idm.getId(n)
    }

    private val pAngleX = id("angleX")
    private val pAngleY = id("angleY")
    private val pAngleZ = id("angleZ")
    private val pBodyX = id("bodyX")
    private val pBodyY = id("bodyY")
    private val pBodyZ = id("bodyZ")
    private val pEyeBallX = id("eyeX")
    private val pEyeBallY = id("eyeY")
    private val pEyeLOpen = id("eyeLOpen")
    private val pEyeROpen = id("eyeROpen")
    private val pEyeLSmile = id("eyeLSmile")
    private val pEyeRSmile = id("eyeRSmile")
    private val pBrowL = id("browL")
    private val pBrowR = id("browR")
    private val pMouthForm = id("mouthForm")
    private val pMouthOpen = id("mouthOpen")
    private val pBreath = id("breath")
    private val pCheek = id("cheek")
    private val pPosX = id("posX")
    private val pPosY = id("posY")
    private val extraMotions = ArrayList<com.live2d.sdk.cubism.framework.motion.CubismMotionManager>()

    private class Expr(val key: String, val items: List<Pair<CubismId, Float>>)

    private val exprs: List<Expr> = cfg.expressions.map { (k, list) ->
        Expr(k, list.map { idm.getId(it.first) to it.second })
    }

    private var hideIdx: IntArray? = null
    private val hairIds: List<Pair<CubismId, Float>> by lazy { cfg.hairCurve.map { idm.getId(it.first) to it.second } }

    private fun read(path: String): ByteArray = ModelStore.open(ctx, path).use { it.readBytes() }

    /**
     * Tahap 1: moc3, physics, motion efek, renderer (kompilasi shader). Tekstur diunggah per frame lewat step()
     * supaya tidak ada satu frame panjang. Harus dipanggil saat konteks GL aktif.
     */
    fun begin(w: Int, h: Int): Boolean {
        val paths = cfg.texturePaths()
        AvatarTex.prefetch(ctx, paths)   // kalau belum jalan, mulai decode sekarang

        loadModel(read(cfg.dir + cfg.moc))
        if (getModel() == null) return false

        if (cfg.physics.isNotEmpty()) {
            loadPhysics(read(cfg.dir + cfg.physics))
            if (physics != null) updateScheduler.addUpdatableList(CubismPhysicsUpdater(physics))
        }
        updateScheduler.sortUpdatableList()

        if (cfg.motion.isNotEmpty()) {
            try {
                val mo = CubismMotion.create(read(cfg.dir + cfg.motion))
                if (mo != null) {
                    mo.setLoop(true)
                    // Tanpa fade-in di tiap putaran: motion Standby Mikuela berupa tanjakan 0 -> ~6 selama ~10 dtk, jadi
                    // fade-in (bawaan 1 dtk, mulai dari nilai dasar) menjatuhkan parameter efek ke nol lalu menariknya naik lagi
                    // tiap kali mengulang = kesendat. Fade-in tetap dipakai sekali di awal.
                    mo.setLoopFadeIn(false)
                    // Mode V2 (bawaan SDK) menambah 1 frame ke durasi loop lalu meng-interpolasi titik akhir ke titik awal.
                    // Kurva Standby naik tepat 6 / 3 putaran (parameter emojiphy bertanda repeat, range 0..1), jadi interpolasi itu
                    // menyapu 6 putaran dalam ~16 ms di ujung loop = kesentak. Di V1, nilai 6 ≡ 0 pada parameter repeat -> mulus.
                    mo.setMotionBehavior(CubismMotion.MotionBehavior.MOTION_BEHAVIOR_V1)
                    motionManager.startMotionPriority(mo, 1)
                }
            } catch (t: Throwable) {
                Log.e("Avatar", "Motion gagal dimuat: ${t.message}")
            }
        }

        for (f in cfg.motions) {
            try {
                val mo = CubismMotion.create(read(cfg.dir + f)) ?: continue
                mo.setLoop(true)
                val mm = com.live2d.sdk.cubism.framework.motion.CubismMotionManager()
                mm.startMotionPriority(mo, 1)
                extraMotions.add(mm)
            } catch (t: Throwable) {
                Log.e("Avatar", "Motion tambahan gagal dimuat ($f): ${t.message}")
            }
        }

        setupRenderer(CubismRendererAndroid.create(w, h))
        setRenderTargetSize(w, h)
        getRenderer<CubismRendererAndroid>().isPremultipliedAlpha(true)
        if (cfg.maskSize > 0) {
            // Mask clipping lebih halus saat avatar di-zoom (tepi mata, rambut, dll. tidak bergerigi / bocor).
            val r = getRenderer<CubismRendererAndroid>()
            r.setDrawableClippingMaskBufferSize(cfg.maskSize.toFloat(), cfg.maskSize.toFloat())
            r.setOffscreenClippingMaskBufferSize(cfg.maskSize.toFloat(), cfg.maskSize.toFloat())
        }

        texCount = paths.size
        nextTex = 0
        return true
    }

    /** Tahap 2: unggah satu tekstur per panggilan. true = semua tekstur terpasang, model siap. */
    fun step(): Boolean {
        val paths = cfg.texturePaths()
        if (nextTex < texCount) {
            val id = upload(paths[nextTex])
            texIds.add(id)
            getRenderer<CubismRendererAndroid>().bindTexture(nextTex, id)
            nextTex++
        }
        if (nextTex >= texCount) {
            getModel().saveParameters()
            loaded = true
            return true
        }
        return false
    }

    fun setFade(a: Float) {
        getRenderer<CubismRendererAndroid>().setModelColor(1f, 1f, 1f, a)
    }

    private fun upload(path: String): Int {
        val bmp = AvatarTex.take(ctx, path)
            ?: throw IllegalStateException("Tekstur tidak terbaca: $path")
        val ids = IntArray(1)
        GLES20.glGenTextures(1, ids, 0)
        GLES20.glActiveTexture(GLES20.GL_TEXTURE0)
        GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, ids[0])
        GLUtils.texImage2D(GLES20.GL_TEXTURE_2D, 0, bmp, 0)
        GLES20.glGenerateMipmap(GLES20.GL_TEXTURE_2D)
        GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_MIN_FILTER, GLES20.GL_LINEAR_MIPMAP_LINEAR)
        GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_MAG_FILTER, GLES20.GL_LINEAR)
        bmp.recycle()
        return ids[0]
    }

    fun isLoaded() = loaded

    fun canvasRatio(): Float {
        val m = getModel()
        return m.canvasHeight / m.canvasWidth
    }

    private fun put(m: com.live2d.sdk.cubism.framework.model.CubismModel, id: CubismId?, v: Float) {
        if (id != null) m.setParameterValue(id, v)
    }

    /** Hitung parameter dari AvatarAnim, jalankan physics, lalu update model. */
    fun update(dtIn: Float, a: AvatarAnim) {
        val dt = dtIn.coerceIn(0.001f, 0.05f)   // dt besar (hitch) bikin physics rambut/dada loncat; batasi di sini untuk semuanya
        val m = getModel()
        m.loadParameters()
        // efek berulang dari file motion (air mata, bintang, dll). Tidak menyentuh parameter gerak kita.
        if (cfg.motion.isNotEmpty()) motionManager.updateMotion(m, dt)
        for (mm in extraMotions) mm.updateMotion(m, dt)
        a.step(dt)
        put(m, pAngleX, a.angleX)
        put(m, pAngleY, a.angleY)
        put(m, pAngleZ, a.angleZ)
        put(m, pBodyX, a.bodyX)
        put(m, pBodyY, a.bodyY)
        put(m, pBodyZ, a.bodyZ)
        put(m, pEyeBallX, a.eyeX)
        put(m, pEyeBallY, a.eyeY)
        put(m, pEyeLOpen, a.eyeOpenL)
        put(m, pEyeROpen, a.eyeOpenR)
        put(m, pEyeLSmile, a.smile)
        put(m, pEyeRSmile, a.smile)
        put(m, pBrowL, a.browL)
        put(m, pBrowR, a.browR)
        put(m, pMouthForm, a.mouthForm)
        put(m, pMouthOpen, a.mouthOpen)
        put(m, pBreath, a.breath)
        put(m, pCheek, a.cheek)
        put(m, pPosX, a.posX)
        put(m, pPosY, a.posY)
        // ekspresi: nilai 'Add' dikali bobot fade
        for (e in exprs) {
            val w = a.exprWeight(e.key)
            if (w <= 0f) continue
            for ((pid, v) in e.items) m.addParameterValue(pid, v * w)
        }
        updateScheduler.onLateUpdate(m, dt)
        val hc = a.hairCurve
        if (hc != 0f) for ((hid, hw) in hairIds) m.addParameterValue(hid, hc * hw)   // bias kepang ke dalam; goyangan fisika tetap jalan
        if (cfg.hideParts.isNotEmpty()) {
            var hi = hideIdx
            if (hi == null) {
                val l = ArrayList<Int>()
                for (pn in cfg.hideParts) {
                    val ix = m.getPartIndex(idm.getId(pn))
                    if (ix >= 0 && ix < m.getPartCount()) l.add(ix)
                }
                hi = l.toIntArray()
                hideIdx = hi
            }
            for (ix in hi) m.setPartOpacity(ix, 0f)
        }
        m.update()
    }

    fun draw(projection: CubismMatrix44) {
        CubismMatrix44.multiply(getModelMatrix().array, projection.array, projection.array)
        val r = getRenderer<CubismRendererAndroid>()
        r.setMvpMatrix(projection)
        r.drawModel()
    }

    /** glDelete = true kalau konteks GL yang lama masih aktif. */
    fun release(glDelete: Boolean) {
        loaded = false
        try {
            if (glDelete && texIds.isNotEmpty()) {
                GLES20.glDeleteTextures(texIds.size, texIds.toIntArray(), 0)
            }
        } catch (_: Throwable) {
        }
        texIds.clear()
        try {
            delete()
        } catch (_: Throwable) {
        }
    }
}
