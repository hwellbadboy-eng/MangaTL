package com.niven.mangatl

import android.graphics.Color
import android.graphics.PorterDuff
import android.graphics.drawable.GradientDrawable
import android.os.SystemClock
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.media3.common.Player
import com.google.android.material.bottomsheet.BottomSheetDialog

// Layar Sedang diputar: menu lainnya dan dialog (kecepatan, timer tidur, antrean, favorit).
// Fungsi ekstensi dari NowPlayingActivity; keadaan dan siklus hidup layar tetap di NowPlayingActivity.kt.

internal fun NowPlayingActivity.showMore() {
    val d = BottomSheetDialog(this)
    val col = LinearLayout(this)
    col.orientation = LinearLayout.VERTICAL
    col.background = GradientDrawable().apply {
        setColor(0xFF1A1A1E.toInt())
        val r = Ui.dp(this@showMore, 24).toFloat()
        cornerRadii = floatArrayOf(r, r, r, r, 0f, 0f, 0f, 0f)
    }
    col.setPadding(Ui.dp(this, 20), Ui.dp(this, 20), Ui.dp(this, 20), Ui.dp(this, 24))
    col.addView(AU.text(this, "Lainnya", 20f, Color.WHITE, true))

    class Item(val icon: Int, val label: String, val value: () -> String, val onClick: () -> Unit)
    val items = listOf(
        Item(R.drawable.ic_shuffle, "Acak", { if (controller?.shuffleModeEnabled == true) "Aktif" else "" }) {
            controller?.let { it.shuffleModeEnabled = !it.shuffleModeEnabled }
            Toast.makeText(this, if (controller?.shuffleModeEnabled == true) "Acak aktif" else "Acak mati", Toast.LENGTH_SHORT).show()
        },
        Item(R.drawable.ic_repeat, "Ulang", {
            when (controller?.repeatMode) {
                Player.REPEAT_MODE_ALL -> "Semua"
                Player.REPEAT_MODE_ONE -> "Satu lagu"
                else -> ""
            }
        }) {
            controller?.let {
                it.repeatMode = when (it.repeatMode) {
                    Player.REPEAT_MODE_OFF -> Player.REPEAT_MODE_ALL
                    Player.REPEAT_MODE_ALL -> Player.REPEAT_MODE_ONE
                    else -> Player.REPEAT_MODE_OFF
                }
            }
        },
        Item(R.drawable.ic_fav_border, "Suka", { if (isFavNow()) "Aktif" else "" }) { toggleFav() },
        Item(R.drawable.ic_lyrics, "Lirik", { "" }) {
            d.dismiss()
            lyricActionsSheet()
        },
        Item(R.drawable.ic_timer, "Timer tidur", {
            val left = (PlayerService.instance?.sleepEndAt ?: 0L) - SystemClock.elapsedRealtime()
            if (left > 0) "${(left / 60000) + 1} menit" else ""
        }) {
            d.dismiss()
            sleepDialog()
        },
        Item(R.drawable.ic_speed, "Kecepatan", {
            val sp = controller?.playbackParameters?.speed ?: 1f
            if (sp == 1f) "1x" else if (sp == sp.toInt().toFloat()) "${sp.toInt()}x" else "${sp}x"
        }) {
            d.dismiss()
            speedDialog()
        },
        Item(R.drawable.ic_queue, "Antrean", { "" }) {
            d.dismiss()
            queueDialog()
        }
    )
    val valueViews = ArrayList<TextView>()
    for (item in items) {
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL
        row.minimumHeight = Ui.dp(this, 56)
        val ic = ImageView(this)
        ic.setImageResource(item.icon)
        ic.setColorFilter(AU.MUT, PorterDuff.Mode.SRC_IN)
        row.addView(ic, LinearLayout.LayoutParams(Ui.dp(this, 22), Ui.dp(this, 22)))
        val lb = AU.text(this, item.label, 15f, Color.WHITE)
        lb.setPadding(Ui.dp(this, 12), 0, 0, 0)
        row.addView(lb, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        val vt = AU.text(this, item.value(), 12f, AU.MUT)
        valueViews.add(vt)
        row.addView(vt)
        row.setOnClickListener {
            item.onClick()
            for ((i, v) in valueViews.withIndex()) v.text = items[i].value()
            updateUi()
        }
        col.addView(row)
        val line = View(this)
        line.setBackgroundColor(0xFF1F1F23.toInt())
        col.addView(line, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 1))
    }
    d.setContentView(col)
    d.setOnShowListener {
        d.findViewById<View>(com.google.android.material.R.id.design_bottom_sheet)?.setBackgroundColor(Color.TRANSPARENT)
    }
    d.show()
}

internal fun NowPlayingActivity.darkSheet(title: String, sub: String? = null): Pair<BottomSheetDialog, LinearLayout> {
    val d = BottomSheetDialog(this)
    val col = LinearLayout(this)
    col.orientation = LinearLayout.VERTICAL
    col.background = GradientDrawable().apply {
        setColor(0xFF1A1A1E.toInt())
        val r = Ui.dp(this@darkSheet, 24).toFloat()
        cornerRadii = floatArrayOf(r, r, r, r, 0f, 0f, 0f, 0f)
    }
    col.setPadding(Ui.dp(this, 20), Ui.dp(this, 20), Ui.dp(this, 20), Ui.dp(this, 24))
    col.addView(AU.text(this, title, 20f, Color.WHITE, true))
    if (sub != null) {
        val t = AU.text(this, sub, 13f, AU.MUT)
        t.setPadding(0, Ui.dp(this, 6), 0, 0)
        col.addView(t)
    }
    d.setContentView(col)
    d.setOnShowListener {
        d.findViewById<View>(com.google.android.material.R.id.design_bottom_sheet)?.setBackgroundColor(Color.TRANSPARENT)
    }
    return Pair(d, col)
}

internal fun NowPlayingActivity.addChips(col: LinearLayout, labels: List<String>, selected: Int, onPick: (Int) -> Unit) {
    val g = com.google.android.material.chip.ChipGroup(this)
    g.chipSpacingHorizontal = Ui.dp(this, 8)
    g.chipSpacingVertical = Ui.dp(this, 8)
    for ((i, l) in labels.withIndex()) {
        val c = AU.chip(this, l, i == selected)
        c.setOnClickListener { onPick(i) }
        g.addView(c)
    }
    val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
    lp.topMargin = Ui.dp(this, 14)
    col.addView(g, lp)
}

internal fun NowPlayingActivity.speedDialog() {
    val c = controller ?: return
    val labels = speeds.map { if (it == it.toInt().toFloat()) "${it.toInt()}×" else "$it×" }
    val cur = speeds.indexOfFirst { it == c.playbackParameters.speed }
    val (d, col) = darkSheet("Kecepatan putar")
    addChips(col, labels, cur) { i ->
        c.setPlaybackSpeed(speeds[i])
        Toast.makeText(this, "Kecepatan: ${labels[i]}", Toast.LENGTH_SHORT).show()
        d.dismiss()
    }
    d.show()
}

internal fun NowPlayingActivity.sleepDialog() {
    val labels = listOf("Mati", "15 menit", "30 menit", "45 menit", "60 menit")
    val mins = intArrayOf(0, 15, 30, 45, 60)
    val left = (PlayerService.instance?.sleepEndAt ?: 0L) - SystemClock.elapsedRealtime()
    val sel = if (left <= 0) 0 else sleepPick
    val (d, col) = darkSheet("Timer tidur", "Musik berhenti otomatis setelah waktu dipilih.")
    addChips(col, labels, sel) { i ->
        sleepPick = i
        PlayerService.instance?.setSleepTimer(mins[i])
        Toast.makeText(
            this, if (mins[i] == 0) "Timer tidur: Mati" else "Timer tidur: ${labels[i]}", Toast.LENGTH_SHORT
        ).show()
        d.dismiss()
    }
    d.show()
}

internal fun NowPlayingActivity.queueDialog() {
    val c = controller ?: return
    val (d, col) = darkSheet("Antrean")
    val rowH = Ui.dp(this, 57)
    val cur = c.currentMediaItemIndex
    val list = LinearLayout(this)
    list.orientation = LinearLayout.VERTICAL
    for (i in 0 until c.mediaItemCount) {
        val name = (c.getMediaItemAt(i).mediaMetadata.title ?: "?").toString()
        val on = i == cur
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL
        val tv = AU.text(this, if (on) "▶ $name" else name, 15f, if (on) Color.WHITE else AU.SOFT, on)
        tv.maxLines = 1
        tv.ellipsize = android.text.TextUtils.TruncateAt.END
        row.addView(tv, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        row.setOnClickListener {
            c.seekTo(i, 0L)
            c.play()
            d.dismiss()
        }
        list.addView(row, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, rowH - 1))
        val line = View(this)
        line.setBackgroundColor(0xFF1F1F23.toInt())
        list.addView(line, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 1))
    }
    val sv = ScrollView(this)
    sv.addView(list)
    val h = minOf(maxOf(c.mediaItemCount, 1) * rowH, (npRoot.height * 0.5f).toInt())
    val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, h)
    lp.topMargin = Ui.dp(this, 8)
    col.addView(sv, lp)
    sv.post { sv.scrollTo(0, maxOf(0, cur * rowH - rowH)) }
    d.show()
}

internal fun NowPlayingActivity.toggleFav() {
    val id = controller?.currentMediaItem?.mediaId?.toLongOrNull() ?: return
    MusicStore.toggleFav(this, id)
    Toast.makeText(this, if (MusicStore.isFav(this, id)) "Ditambahkan ke Suka" else "Dihapus dari Suka", Toast.LENGTH_SHORT).show()
    updateUi()
}
