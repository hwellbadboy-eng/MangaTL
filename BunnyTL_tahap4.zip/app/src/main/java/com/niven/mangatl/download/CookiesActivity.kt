package com.niven.mangatl

import android.annotation.SuppressLint
import android.content.Intent
import kotlinx.coroutines.withContext
import kotlinx.coroutines.launch
import kotlinx.coroutines.Dispatchers
import androidx.lifecycle.lifecycleScope
import android.graphics.Color
import android.graphics.Typeface
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.webkit.CookieManager
import android.webkit.WebChromeClient
import android.webkit.ValueCallback
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebResourceRequest
import android.webkit.WebViewClient
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import com.google.android.material.button.MaterialButton

/**
 * Akun & cookies: untuk video yang minta login (anti-bot YouTube, batas umur, khusus member).
 * Dua cara: masuk lewat halaman web di dalam app, atau impor cookies.txt dari browser.
 */
class CookiesActivity : AppCompatActivity() {
    private lateinit var main: ScrollView
    private lateinit var bubble: WebBubble
    private var inWeb = false
    private var curUa = ""
    private lateinit var webView: WebView
    private lateinit var tvStatus: TextView
    private lateinit var etSite: EditText
    private var ua = ""
    private var popup: WebView? = null
    private var customView: View? = null
    private var customCb: WebChromeClient.CustomViewCallback? = null
    private var fileCb: ValueCallback<Array<Uri>>? = null
    private lateinit var dlPicker: DlPicker
    private var pendingDl: List<DlTask>? = null
    private val notifPerm = registerForActivityResult(ActivityResultContracts.RequestPermission()) {
        pendingDl?.let { goDl(it) }
    }
    private val webPrefs by lazy { getSharedPreferences("cookies_web", MODE_PRIVATE) }

    private val fileLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        val cb = fileCb
        fileCb = null
        cb?.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(r.resultCode, r.data))
    }

    /** true = dibuka langsung ke halaman login (dari tombol Login manual / galat minta login): selesai -> tutup layar. */
    private var direct = false

    // ----- akun Claude -----
    private var claudeSlot = -1
    private var claudeHadSession = false
    private var claudeSnapAt = 0L
    private var claudeGoogleTried = false

    companion object {
        const val EXTRA_AUTO_WEB = "auto_web"
        const val EXTRA_LOGIN_URL = "login_url"
        /** Nomor slot akun Claude (0..3) yang dibuka: cookies slot dipasang dulu, lalu claude.ai terbuka. */
        const val EXTRA_CLAUDE_SLOT = "claude_slot"

        /** Mengembalikan {urls:[terbaik..terkecil], video:bool} untuk elemen di titik (__X__, __Y__) (px CSS). */
        const val IMG_JS = """(function(x,y){try{
var els=document.elementsFromPoint?document.elementsFromPoint(x,y):[document.elementFromPoint(x,y)];
var seen={},urls=[],video=false;
function add(u){if(!u)return;try{u=new URL(u,location.href).href}catch(e){return}
if(!/^(https?:|data:image)/.test(u)||seen[u])return;seen[u]=1;urls.push(u);}
function srcset(s){if(!s)return;var a=s.split(',').map(function(p){p=p.trim().split(/\s+/);var d=p[1]||'';var w=parseFloat(d)||0;if(/x$/.test(d))w=w*1000;return{u:p[0],w:w}}).filter(function(o){return o.u});
a.sort(function(p,q){return q.w-p.w});a.forEach(function(o){add(o.u)});}
for(var i=0;i<els.length&&!urls.length;i++){var e=els[i];if(!e)continue;var t=e.tagName;
if(t==='IMG'){var pic=e.parentElement&&e.parentElement.tagName==='PICTURE'?e.parentElement:null;
if(pic){var ss=pic.querySelectorAll('source');for(var j=0;j<ss.length;j++)srcset(ss[j].srcset);}
var ds=e.dataset||{};add(ds.original);add(ds.fullSrc);add(ds.full);add(ds.largeSrc);
srcset(e.srcset||e.getAttribute('data-srcset'));add(e.currentSrc);add(e.src);add(ds.src);
var al=e.closest&&e.closest('a[href]');
if(al&&/\.(jpe?g|png|gif|webp|avif)([?#]|$)/i.test(al.href)){var n0=urls.length;add(al.href);if(urls.length>n0)urls.unshift(urls.pop());}
}else if(t==='VIDEO'){video=true;}
else if(t==='image'){add(e.getAttribute('href')||e.getAttributeNS('http://www.w3.org/1999/xlink','href'));}
else{var bg=getComputedStyle(e).backgroundImage;var m=bg&&bg.match(/url\((["']?)(.*?)\1\)/);if(m)add(m[2]);}
}
return{urls:urls,video:video&&!urls.length};
}catch(err){return null}})(__X__,__Y__)"""
    
    }

    private val picker = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        if (uri == null) return@registerForActivityResult
        runCatching { DlCookies.importFrom(this, uri) }
            .onSuccess { Toast.makeText(this, "$it cookie diimpor.", Toast.LENGTH_SHORT).show() }
            .onFailure { Toast.makeText(this, it.message ?: "Gagal mengimpor.", Toast.LENGTH_LONG).show() }
        refresh()
    }

    private fun dp(v: Int) = Ui.dp(this, v)
    private val muted = Color.parseColor("#8E8E93")

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // ----- halaman utama -----
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(12), dp(16), dp(24))
        }
        val bar = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        bar.addView(Ui.iconBtn(this, R.drawable.ic_back, "Kembali") { finish() }, LinearLayout.LayoutParams(dp(44), dp(44)))
        bar.addView(TextView(this).apply {
            text = "Akun & cookies"
            textSize = 22f
            setTextColor(Color.WHITE)
            typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
        }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { marginStart = dp(8) })
        col.addView(bar)

        col.addView(TextView(this).apply {
            text = "Dipakai kalau YouTube meminta verifikasi (anti-bot), video dibatasi umur, atau khusus member. " +
                "Cookies hanya disimpan di HP ini dan hanya dikirim ke situs saat mengunduh.\n\n" +
                "Saran: pakai akun cadangan. YouTube kadang menandai akun yang dipakai untuk mengunduh."
            textSize = 13f
            setTextColor(muted)
            setLineSpacing(0f, 1.15f)
            setPadding(dp(4), dp(14), dp(4), dp(10))
        })
        tvStatus = TextView(this).apply {
            textSize = 14f
            setTextColor(Color.WHITE)
            setPadding(dp(4), dp(4), dp(4), dp(12))
        }
        col.addView(tvStatus)

        webPrefs.getString("last", null)?.let { last ->
            col.addView(button("Lanjutkan browsing", false) { openWebUrl(last, DlCookies.siteFor(last)) },
                LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(48)).apply { bottomMargin = dp(14) })
        }

        col.addView(TextView(this).apply {
            text = "Login manual: ketuk situs, langsung buka halaman login."
            textSize = 13f
            setTextColor(Color.WHITE)
            setPadding(dp(4), dp(0), dp(4), dp(8))
        })
        col.addView(siteChips { site -> openWebUrl(site.loginUrl, site) })

        etSite = EditText(this).apply {
            setText("https://www.youtube.com")
            setTextColor(Color.WHITE)
            textSize = 14f
            maxLines = 1
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_URI
            setBackgroundResource(R.drawable.bg_field)
            setPadding(dp(14), dp(12), dp(14), dp(12))
        }
        col.addView(etSite, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        col.addView(button("Masuk lewat halaman web", false) { openWeb() },
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(48)).apply { topMargin = dp(10) })
        col.addView(button("Impor cookies.txt", true) { picker.launch(arrayOf("*/*")) },
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(48)).apply { topMargin = dp(8) })
        col.addView(Ui.switchRow(this, "Pakai cookies saat mengunduh", DlPrefs.useCookies(this)) {
            DlPrefs.setUseCookies(this, it)
        }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(10) })
        col.addView(button("Hapus cookies", true) {
            DlCookies.clear(this)
            refresh()
            Toast.makeText(this, "Cookies dihapus.", Toast.LENGTH_SHORT).show()
        }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(48)).apply { topMargin = dp(8) })

        main = ScrollView(this).apply { setBackgroundColor(Color.BLACK); addView(col) }

        // ----- halaman web -----
        webView = WebView(this)
        ua = WebSettings.getDefaultUserAgent(this).replace("; wv", "").replace(Regex("Version/\\d+\\.\\d+\\s"), "")
        webView.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            javaScriptCanOpenWindowsAutomatically = true
            setSupportMultipleWindows(true)
            userAgentString = ua
            mediaPlaybackRequiresUserGesture = false
            mixedContentMode = WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE
            cacheMode = WebSettings.LOAD_DEFAULT
            if (Build.VERSION.SDK_INT >= 23) offscreenPreRaster = true
            if (Build.VERSION.SDK_INT >= 26) safeBrowsingEnabled = false
        }
        webView.setLayerType(View.LAYER_TYPE_HARDWARE, null)
        webView.overScrollMode = View.OVER_SCROLL_NEVER
        webView.isVerticalScrollBarEnabled = false
        if (Build.VERSION.SDK_INT >= 26) webView.setRendererPriorityPolicy(WebView.RENDERER_PRIORITY_IMPORTANT, false)
        CookieManager.getInstance().setAcceptCookie(true)
        CookieManager.getInstance().setAcceptThirdPartyCookies(webView, true)
        webView.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                if (googleHint(view, request?.url)) return true
                return blockAppScheme(view, request?.url)
            }

            override fun onPageStarted(view: WebView?, url: String?, favicon: android.graphics.Bitmap?) {
                tunePerf(url)
                hookBlobs(url)
            }

            override fun onPageFinished(view: WebView?, url: String?) {
                hookBlobs(url)
                CookieManager.getInstance().flush()
                if (url != null && url.startsWith("http") && claudeSlot < 0) webPrefs.edit().putString("last", url).apply()
                claudeCheck(url)
            }
        }
        webView.addJavascriptInterface(BlobBridge(), "BunnyBlob")
        webView.addJavascriptInterface(ClaudeBridge(), "BunnyClaude")
        webView.setDownloadListener { url, _, cd, mime, _ -> onWebDownload(url, cd, mime) }
        webView.webChromeClient = object : WebChromeClient() {
            override fun onProgressChanged(view: WebView?, newProgress: Int) {
                if (::bubble.isInitialized) bubble.progress(newProgress)
            }

            // Popup login (Google/Facebook/X): harus jadi WebView terpisah yang tetap punya window.opener,
            // kalau tidak halaman TikTok tidak pernah menerima hasil login dan layar jadi putih.
            override fun onCreateWindow(view: WebView?, isDialog: Boolean, isUserGesture: Boolean, resultMsg: android.os.Message?): Boolean {
                if (resultMsg == null) return false
                closePopup()
                val pw = WebView(this@CookiesActivity)
                pw.settings.apply {
                    javaScriptEnabled = true
                    domStorageEnabled = true
                    javaScriptCanOpenWindowsAutomatically = true
                    setSupportMultipleWindows(true)
                    userAgentString = curUa
                }
                CookieManager.getInstance().setAcceptThirdPartyCookies(pw, true)
                pw.webViewClient = object : WebViewClient() {
                    // Popup yang mencoba membuka app (tiktok://, snssdk://, intent://, dst.) ditutup saja: kalau dibiarkan
                    // ia menutupi layar (putih/halaman awal) sementara video di bawahnya tetap bersuara.
                    override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                        val u = request?.url
                        if (googleHint(view, u)) return true
                        if (u != null && isAppScheme(u)) {
                            window.decorView.post { if (popup === view) closePopup() }
                            return true
                        }
                        return blockAppScheme(view, u)
                    }
                }
                pw.webChromeClient = object : WebChromeClient() {
                    override fun onCloseWindow(window: WebView?) { closePopup() }
                    override fun onCreateWindow(v: WebView?, d: Boolean, g: Boolean, m: android.os.Message?): Boolean {
                        if (m == null) return false
                        val t = m.obj as WebView.WebViewTransport
                        t.webView = pw
                        m.sendToTarget()
                        return true
                    }
                }
                popup = pw
                bubble.addPopup(pw)
                val transport = resultMsg.obj as WebView.WebViewTransport
                transport.webView = pw
                resultMsg.sendToTarget()
                return true
            }

            override fun onCloseWindow(window: WebView?) { closePopup() }

            override fun onShowCustomView(view: View?, callback: CustomViewCallback?) {
                if (view == null || customView != null) { callback?.onCustomViewHidden(); return }
                customView = view
                customCb = callback
                view.setBackgroundColor(Color.BLACK)
                bubble.addPopup(view)
            }

            override fun onHideCustomView() { hideCustom() }

            override fun onShowFileChooser(view: WebView?, cb: ValueCallback<Array<Uri>>?, params: FileChooserParams?): Boolean {
                fileCb?.onReceiveValue(null)
                fileCb = cb
                return try {
                    fileLauncher.launch(params!!.createIntent())
                    true
                } catch (e: Exception) {
                    fileCb = null
                    cb?.onReceiveValue(null)
                    false
                }
            }
        }
        curUa = ua
        dlPicker = DlPicker(this) { startDl(it) }
        bubble = WebBubble(
            this, webView,
            onSave = { saveFromWeb() },
            onSite = { s ->
                DlPrefs.setLastLogin(this, s.key)
                webView.loadUrl(s.loginUrl)
            },
            onGo = { u -> webView.loadUrl(u) },
            onDesktop = { on -> applyDesktop(on) },
            onBack = { if (webView.canGoBack()) webView.goBack() else bubble.toast("Sudah di halaman pertama") },
            onReload = { webView.reload() },
            onHome = { goHome() },
            onDownload = { downloadCurrent() }
        )
        setupLongPress()

        setContentView(main)
        refresh()

        val slotExtra = intent.getIntExtra(EXTRA_CLAUDE_SLOT, -1)
        if (slotExtra in 0 until ClaudeSlots.MAX_SLOTS) {
            startClaude(slotExtra)
        } else if (intent.getBooleanExtra(EXTRA_AUTO_WEB, false)) {
            direct = true
            val u = intent.getStringExtra(EXTRA_LOGIN_URL) ?: DlCookies.loginUrlFor(this, null)
            openWebUrl(u, DlCookies.siteFor(u))
        }
    }

    /** Baris tombol situs (YouTube, Instagram, ...) yang bisa digeser. */
    private fun siteChips(onPick: (LoginSite) -> Unit): View {
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        DlCookies.SITES.forEachIndexed { i, site ->
            row.addView(button(site.label, true) { onPick(site) },
                LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(44)).apply { if (i > 0) marginStart = dp(6) })
        }
        return android.widget.HorizontalScrollView(this).apply {
            isHorizontalScrollBarEnabled = false
            addView(row)
        }
    }

    private fun button(label: String, outlined: Boolean, onClick: () -> Unit) = MaterialButton(
        this, null,
        if (outlined) com.google.android.material.R.attr.materialButtonOutlinedStyle
        else com.google.android.material.R.attr.materialButtonStyle
    ).apply {
        text = label
        isAllCaps = false
        cornerRadius = dp(24)
        setOnClickListener { onClick() }
    }

    private fun refresh() {
        val n = DlCookies.count(this)
        tvStatus.text = if (n > 0) "Cookies tersimpan: $n" else "Belum ada cookies tersimpan."
    }

    private fun openWeb() {
        var u = etSite.text.toString().trim()
        if (u.isEmpty()) return
        if (!u.startsWith("http")) u = "https://$u"
        openWebUrl(u, DlCookies.siteFor(u))
    }

    private fun openWebUrl(u: String, site: LoginSite?) {
        val s = site ?: DlCookies.siteFor(u)
        s?.let { DlPrefs.setLastLogin(this, it.key) }
        bubble.setSite(s)
        inWeb = true
        setContentView(bubble.root)
        enterImmersive()
        webView.loadUrl(u)
        Toast.makeText(this, "Masuk dulu, lalu ketuk bubble > Simpan.", Toast.LENGTH_LONG).show()
    }

    private fun hideCustom() {
        val v = customView ?: return
        customView = null
        bubble.removePopup(v)
        customCb?.onCustomViewHidden()
        customCb = null
    }

    private fun closePopup() {
        val pw = popup ?: return
        popup = null
        bubble.removePopup(pw)
        pw.stopLoading()
        pw.destroy()
    }

    /**
     * Khusus Instagram: lapisan hardware paksa + pre-raster di luar layar dimatikan karena bikin scroll reels
     * patah-patah. Situs lain tetap memakai pengaturan awal (hardware + pre-raster).
     */
    private fun tunePerf(url: String?) {
        val host = runCatching { Uri.parse(url).host }.getOrNull()?.lowercase() ?: return
        val ig = host == "instagram.com" || host.endsWith(".instagram.com")
        webView.setLayerType(if (ig) View.LAYER_TYPE_NONE else View.LAYER_TYPE_HARDWARE, null)
        if (Build.VERSION.SDK_INT >= 23) webView.settings.offscreenPreRaster = !ig
    }

    /**
     * Unduh video yang sedang dibuka tanpa keluar dari browser: cookies sesi web ini disimpan dulu (supaya video
     * yang butuh login ikut bisa), lalu panel pilih kualitas muncul di atas halaman. Setelah Unduh, jalan di latar.
     */
    private fun downloadCurrent() {
        val u = webView.url
        if (u.isNullOrBlank() || !u.startsWith("http")) {
            bubble.toast("Belum ada halaman untuk diunduh")
            return
        }
        runCatching {
            DlCookies.exportFromWebView(this, listOf(u) + DlCookies.SITES.map { it.loginUrl })
            DlPrefs.setUserAgent(this, curUa)
        }
        dlPicker.load(u)
        bubble.showSheet(dlPicker.root)
    }

    /**
     * Tekan lama gambar / GIF di halaman -> menu Unduh muncul di dekat jari. Sentuhan tetap diteruskan ke halaman
     * (tidak dikonsumsi); kalau di titik itu tidak ada gambar (mis. video, teks) tidak terjadi apa-apa.
     */
    @SuppressLint("ClickableViewAccessibility")
    private fun setupLongPress() {
        val slop = android.view.ViewConfiguration.get(this).scaledTouchSlop
        val timeout = android.view.ViewConfiguration.getLongPressTimeout().toLong()
        var sx = 0f
        var sy = 0f
        val fire = Runnable { probeImage(sx, sy) }
        webView.setOnTouchListener { v, e ->
            when (e.actionMasked) {
                android.view.MotionEvent.ACTION_DOWN -> {
                    sx = e.x; sy = e.y
                    v.removeCallbacks(fire)
                    v.postDelayed(fire, timeout)
                }
                android.view.MotionEvent.ACTION_MOVE ->
                    if (kotlin.math.abs(e.x - sx) > slop || kotlin.math.abs(e.y - sy) > slop) v.removeCallbacks(fire)
                android.view.MotionEvent.ACTION_POINTER_DOWN,
                android.view.MotionEvent.ACTION_UP,
                android.view.MotionEvent.ACTION_CANCEL -> v.removeCallbacks(fire)
            }
            false
        }
    }

    /** Cari gambar di titik sentuh (termasuk yang tertutup lapisan transparan); kalau ada, tampilkan menu. */
    @Suppress("DEPRECATION")
    private fun probeImage(x: Float, y: Float) {
        val sc = webView.scale.takeIf { it > 0f } ?: resources.displayMetrics.density
        val js = IMG_JS.replace("__X__", (x / sc).toString()).replace("__Y__", (y / sc).toString())
        webView.evaluateJavascript(js) { res ->
            val obj = runCatching { org.json.JSONObject(res) }.getOrNull()
            val arr = obj?.optJSONArray("urls")
            val urls = (0 until (arr?.length() ?: 0)).map { arr!!.getString(it) }
            if (urls.isEmpty()) return@evaluateJavascript
            bubble.showImageMenu(x, y,
                onDownloadImg = { downloadImages(urls) },
                onCopy = {
                    val cm = getSystemService(CLIPBOARD_SERVICE) as android.content.ClipboardManager
                    cm.setPrimaryClip(android.content.ClipData.newPlainText("gambar", urls.first()))
                    bubble.toast("Link gambar disalin")
                })
        }
    }

    private fun downloadImages(urls: List<String>, nameHint: String? = null) {
        bubble.toast("Mengunduh gambar…", 8000)
        val ref = webView.url ?: ""
        val ctx = this
        lifecycleScope.launch {
            val r = withContext(Dispatchers.IO) { runCatching { ImgDownloader.download(ctx, urls, ref, curUa, nameHint) } }
            r.onSuccess {
                bubble.toast("Tersimpan: ${it.name} (${android.text.format.Formatter.formatShortFileSize(ctx, it.bytes)})", 3000)
            }.onFailure {
                bubble.toast("Gagal mengunduh gambar: ${(it.message ?: "galat").take(40)}", 3000)
            }
        }
    }

    // ---------------------------------------------------------------- tombol "Unduh" bawaan situs (mis. Pinterest)

    private var blobToken: String? = null
    private var blobName: String? = null
    private var lastDlUrl = ""
    private var lastDlAt = 0L

    /** Jembatan JS -> app untuk file blob:. Hanya menerima panggilan yang membawa token sekali pakai dari app. */
    private inner class BlobBridge {
        @android.webkit.JavascriptInterface
        fun save(token: String, dataUrl: String) {
            if (token != blobToken) return
            blobToken = null
            runOnUiThread {
                val mime = dataUrl.substring(5, dataUrl.indexOf(',').coerceAtLeast(5)).substringBefore(';')
                if (mime.startsWith("image/")) downloadImages(listOf(dataUrl), blobName)
                else saveFile(dataUrl, null, mime, blobName)
            }
        }

        @android.webkit.JavascriptInterface
        fun fail(token: String) {
            if (token != blobToken) return
            blobToken = null
            runOnUiThread { bubble.toast("Gagal membaca file dari halaman (mungkin terlalu besar)", 2800) }
        }
    }

    /** Simpan blob yang dibuat halaman (createObjectURL) supaya masih bisa dibaca setelah tombol Unduh ditekan. */
    private fun hookBlobs(url: String?) {
        val host = runCatching { Uri.parse(url).host }.getOrNull()?.lowercase() ?: return
        if (host == "instagram.com" || host.endsWith(".instagram.com")) return
        webView.evaluateJavascript(
            "(function(){if(window.__bbHook)return;window.__bbHook=1;window.__bbBlobs={};window.__bbKeys=[];" +
                "var o=URL.createObjectURL;URL.createObjectURL=function(b){var u=o.call(URL,b);" +
                "try{if(b instanceof Blob&&b.size<80e6){window.__bbBlobs[u]=b;window.__bbKeys.push(u);" +
                "if(window.__bbKeys.length>8)delete window.__bbBlobs[window.__bbKeys.shift()];}}catch(e){}return u}})()", null
        )
    }

    /**
     * WebView tidak mengunduh sendiri: tombol Unduh situs (link attachment / blob:) jatuh ke sini.
     * Gambar/GIF -> ImgDownloader (kualitas asli); video, audio, dan file lain -> FileDownloader (apa adanya).
     * Terpisah dari "Unduh video ini" (yt-dlp); link yang sama dalam 3 detik tidak diproses dua kali.
     */
    private fun onWebDownload(url: String, cd: String?, mime: String?) {
        val now = android.os.SystemClock.elapsedRealtime()
        if (url == lastDlUrl && now - lastDlAt < 3000) return
        lastDlUrl = url
        lastDlAt = now
        val name = android.webkit.URLUtil.guessFileName(url, cd, mime)
        if (url.startsWith("blob:")) {
            val token = java.util.UUID.randomUUID().toString()
            blobToken = token
            blobName = name
            bubble.toast("Mengunduh…", 8000)
            val u = org.json.JSONObject.quote(url)
            val t = org.json.JSONObject.quote(token)
            webView.evaluateJavascript(
                "(function(u,t){try{var b=window.__bbBlobs&&window.__bbBlobs[u];" +
                    "var p=b?Promise.resolve(b):fetch(u).then(function(r){return r.blob()});" +
                    "p.then(function(bl){if(bl.size>80e6){BunnyBlob.fail(t);return}" +
                    "var fr=new FileReader();fr.onload=function(){BunnyBlob.save(t,fr.result)};" +
                    "fr.onerror=function(){BunnyBlob.fail(t)};fr.readAsDataURL(bl)}).catch(function(){BunnyBlob.fail(t)})" +
                    "}catch(e){BunnyBlob.fail(t)}})($u,$t)", null
            )
            return
        }
        if (!url.startsWith("http")) return
        val m = (mime ?: "").lowercase()
        val isImg = m.startsWith("image/") ||
            Regex("\\.(jpe?g|png|gif|webp|avif|heic|bmp)$", RegexOption.IGNORE_CASE).containsMatchIn(name)
        if (isImg) downloadImages(listOf(url), name) else saveFile(url, cd, mime, null)
    }

    /** Simpan file apa adanya (semua format) dengan progres persen di toast. */
    private fun saveFile(url: String, cd: String?, mime: String?, nameHint: String?) {
        bubble.toast("Mengunduh file…", 8000)
        val ref = webView.url ?: ""
        val ctx = this
        var lastTick = 0L
        lifecycleScope.launch {
            val r = withContext(Dispatchers.IO) {
                runCatching {
                    FileDownloader.download(ctx, url, ref, curUa, cd, mime, nameHint) { done, total ->
                        val now = android.os.SystemClock.elapsedRealtime()
                        if (now - lastTick > 600) {
                            lastTick = now
                            val txt = if (total > 0) "Mengunduh… ${(done * 100 / total).toInt()}%"
                            else "Mengunduh… ${android.text.format.Formatter.formatShortFileSize(ctx, done)}"
                            runOnUiThread { bubble.toast(txt, 3000) }
                        }
                    }
                }
            }
            r.onSuccess {
                bubble.toast("Tersimpan di ${it.where}: ${it.name.take(30)} (${android.text.format.Formatter.formatShortFileSize(ctx, it.bytes)})", 3500)
            }.onFailure {
                bubble.toast("Gagal mengunduh: ${(it.message ?: "galat").take(40)}", 3000)
            }
        }
    }

    private fun startDl(tasks: List<DlTask>) {
        val needAsk = Build.VERSION.SDK_INT >= 33 && !DlPrefs.notifAsked(this) &&
            checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS) != android.content.pm.PackageManager.PERMISSION_GRANTED
        if (needAsk) {
            DlPrefs.setNotifAsked(this)
            pendingDl = tasks
            notifPerm.launch(android.Manifest.permission.POST_NOTIFICATIONS)
        } else {
            goDl(tasks)
        }
    }

    private fun goDl(tasks: List<DlTask>) {
        pendingDl = null
        tasks.forEach { DlQueue.enqueue(this, it) }
        bubble.hideSheet()
        bubble.toast(if (tasks.size == 1) "Mengunduh: ${tasks[0].title.take(26)}" else "${tasks.size} item masuk antrean", 2200)
    }

    /** Keluar browser langsung ke layar utama aplikasi (tanpa menyimpan cookies). */
    private fun goHome() {
        hideCustom()
        closePopup()
        setResult(RESULT_CANCELED)
        startActivity(
            Intent(this, MainActivity::class.java)
                .addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP)
        )
        finish()
    }

    private fun closeWeb() {
        hideCustom()
        closePopup()
        if (direct) { setResult(RESULT_CANCELED); finish(); return }
        inWeb = false
        bubble.closeAll()
        exitImmersive()
        setContentView(main)
        refresh()
    }

    /** Mode desktop: ganti User-Agent + tampilan lebar, lalu muat ulang halaman. */
    private fun applyDesktop(on: Boolean) {
        curUa = if (on) ua.replace(Regex("\\(Linux; Android[^)]*\\)"), "(X11; Linux x86_64)").replace(" Mobile", "") else ua
        webView.settings.apply {
            userAgentString = curUa
            useWideViewPort = on
            loadWithOverviewMode = on
        }
        popup?.settings?.userAgentString = curUa
        webView.reload()
    }

    /** Layar penuh tanpa bar status/navigasi (geser dari tepi untuk memunculkan sebentar). */
    private fun enterImmersive() {
        // isi sampai ke bawah area kamera/status bar: jangan sisakan jarak sistem (keyboard diurus WebBubble)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        if (Build.VERSION.SDK_INT >= 28) {
            val lp = window.attributes
            lp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
            window.attributes = lp
        }
        val c = WindowInsetsControllerCompat(window, window.decorView)
        c.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        c.hide(WindowInsetsCompat.Type.systemBars())
    }

    private fun exitImmersive() {
        WindowCompat.setDecorFitsSystemWindows(window, true)
        if (Build.VERSION.SDK_INT >= 28) {
            val lp = window.attributes
            lp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_DEFAULT
            window.attributes = lp
        }
        WindowInsetsControllerCompat(window, window.decorView).show(WindowInsetsCompat.Type.systemBars())
    }

    override fun onPause() {
        super.onPause()
        CookieManager.getInstance().flush()
        if (::bubble.isInitialized) bubble.pauseLogo()
    }

    override fun onResume() {
        super.onResume()
        if (::bubble.isInitialized) bubble.resumeLogo()
    }

    override fun onDestroy() {
        if (::bubble.isInitialized) bubble.releaseLogo()
        super.onDestroy()
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus && inWeb) enterImmersive()
    }

    private fun saveFromWeb() {
        if (claudeSlot >= 0) {
            claudeSnapshot(true)
            val s = ClaudeSlots.get(this, claudeSlot)
            Toast.makeText(this, if (s?.filled == true) "Akun ${claudeSlot + 1} tersimpan." else "Belum login ke Claude.", Toast.LENGTH_SHORT).show()
            if (s?.filled == true) { setResult(RESULT_OK); finish() }
            return
        }
        val current = webView.url ?: ""
        runCatching {
            DlCookies.exportFromWebView(
                this,
                (listOf(current, "https://www.youtube.com", "https://accounts.google.com", "https://www.google.com") +
                    DlCookies.SITES.map { it.loginUrl }).filter { it.isNotEmpty() }
            )
        }.onSuccess {
            DlPrefs.setUserAgent(this, curUa)
            Toast.makeText(this, "$it cookie disimpan.", Toast.LENGTH_SHORT).show()
            if (direct) { setResult(RESULT_OK); finish() } else closeWeb()
        }.onFailure { Toast.makeText(this, it.message ?: "Gagal menyimpan cookies.", Toast.LENGTH_LONG).show() }
    }

    // ---------------------------------------------------------------- akun Claude (slot)

    /** Buka slot [i]: slot terisi & sesi masih sah -> cookies dipasang, langsung masuk. Kosong/habis -> halaman login. */
    private fun startClaude(i: Int) {
        claudeSlot = i
        claudeGoogleTried = false
        direct = true
        ClaudeSlots.open(this, i)
        val s = ClaudeSlots.get(this, i)
        if (s != null && s.filled && !s.expired) {
            claudeHadSession = true
            ClaudeSlots.inject(s) { openWebUrl(ClaudeSlots.HOME, ClaudeSlots.SITE) }
        } else {
            claudeHadSession = false
            ClaudeSlots.expireWeb()
            openWebUrl(ClaudeSlots.LOGIN, ClaudeSlots.SITE)
            // langsung jelas akun mana yang diminta login ulang
            val who = s?.let { it.label.ifBlank { "Akun ${i + 1}" } + (if (it.email.isNotBlank()) " · ${it.email}" else "") }
            if (who != null) bubble.toast("Login ulang: $who", 4500)
        }
    }

    /** Isi kolom email halaman login Claude dengan email slot (tinggal lanjut / masukkan password). */
    private fun prefillClaudeEmail() {
        val email = ClaudeSlots.get(this, claudeSlot)?.email?.takeIf { it.isNotBlank() } ?: return
        webView.evaluateJavascript(
            "(function(e){function go(){var i=document.querySelector('input[type=email],input[name=email],input[autocomplete=email]');" +
                "if(!i)return false;var s=Object.getOwnPropertyDescriptor(HTMLInputElement.prototype,'value').set;" +
                "s.call(i,e);i.dispatchEvent(new Event('input',{bubbles:true}));return true}" +
                "if(!go()){var n=0;var t=setInterval(function(){if(go()||++n>10)clearInterval(t)},500)}})(" +
                org.json.JSONObject.quote(email) + ")", null
        )
    }

    /**
     * Slot Gmail yang minta login ulang: tekan otomatis tombol "Continue with Google" di halaman login Claude
     * (sekali per pembukaan slot), jadi lo langsung sampai ke langkah password Google. Password tetap diketik sendiri.
     */
    private fun autoGoogle() {
        if (claudeGoogleTried) return
        val email = ClaudeSlots.get(this, claudeSlot)?.email?.lowercase() ?: return
        if (!(email.endsWith("@gmail.com") || email.endsWith("@googlemail.com"))) return
        claudeGoogleTried = true
        webView.evaluateJavascript(
            "(function(){var n=0;var t=setInterval(function(){var els=document.querySelectorAll('button,a,[role=button]');" +
                "for(var i=0;i<els.length;i++){var x=(els[i].innerText||els[i].textContent||'').toLowerCase();" +
                "if(x.indexOf('google')>=0){clearInterval(t);els[i].click();return}}if(++n>12)clearInterval(t)},500)})()", null
        )
    }

    /**
     * Login Google dari Claude: tambahkan login_hint=email slot supaya Google langsung ke langkah password akun itu
     * (tanpa daftar pilihan akun). true = navigasi diganti.
     */
    private fun googleHint(view: WebView?, u: Uri?): Boolean {
        if (claudeSlot < 0 || view == null || u == null) return false
        if (u.host?.lowercase() != "accounts.google.com") return false
        if (u.getQueryParameter("login_hint") != null) return false
        val p = u.path ?: ""
        if (!(p.contains("/o/oauth2") || p.contains("/signin/oauth"))) return false
        val email = ClaudeSlots.get(this, claudeSlot)?.email?.takeIf { it.isNotBlank() } ?: return false
        view.loadUrl(u.buildUpon().appendQueryParameter("login_hint", email).build().toString())
        return true
    }

    /** Dipanggil tiap halaman selesai dimuat: kalau Claude menolak sesi (dilempar ke /login) tandai slot habis; kalau sudah masuk, rekam ulang cookies. */
    private fun claudeCheck(url: String?) {
        if (claudeSlot < 0 || url == null) return
        val u = Uri.parse(url)
        val host = u.host?.lowercase() ?: return
        if (!ClaudeSlots.isClaudeDomain(host)) return
        val path = u.path ?: "/"
        if (path.startsWith("/login") || path.startsWith("/logout") || path.startsWith("/signup")) {
            if (claudeHadSession) {
                claudeHadSession = false
                ClaudeSlots.get(this, claudeSlot)?.let { it.expired = true; ClaudeSlots.put(this, claudeSlot, it) }
                bubble.toast("Sesi akun ini habis, login ulang", 2800)
            }
            prefillClaudeEmail()
            autoGoogle()
            return
        }
        claudeSnapshot(false)
    }

    /** Rekam cookies claude.ai yang sekarang ke slot aktif (sesi Claude berputar, jadi disegarkan berkala). */
    private fun claudeSnapshot(force: Boolean) {
        val now = android.os.SystemClock.elapsedRealtime()
        if (!force && now - claudeSnapAt < 15_000) return
        val cookies = ClaudeSlots.readWebCookies(this)
        if (!ClaudeSlots.hasSession(cookies)) return
        claudeSnapAt = now
        val s = ClaudeSlots.get(this, claudeSlot) ?: ClaudeSlot()
        s.cookies = cookies
        s.expired = false
        ClaudeSlots.put(this, claudeSlot, s)
        if (s.email.isEmpty() || s.name.isEmpty()) fetchClaudeProfile()
    }

    /** Baca nama + email akun dari halaman claude.ai yang sedang terbuka (tanpa password). */
    private fun fetchClaudeProfile() {
        webView.evaluateJavascript(
            "(function(){function pick(o,ks){if(!o)return '';for(var i=0;i<ks.length;i++){if(o[ks[i]])return String(o[ks[i]])}return ''}" +
                "fetch('/api/account',{credentials:'include'}).then(function(r){return r.ok?r.json():null}).then(function(j){" +
                "var a=j&&(j.account||j)||null;" +
                "BunnyClaude.profile(JSON.stringify({e:pick(a,['email_address','email']),n:pick(a,['full_name','display_name','name'])}))" +
                "}).catch(function(){})})()", null
        )
    }

    private inner class ClaudeBridge {
        @android.webkit.JavascriptInterface
        fun profile(json: String) {
            runOnUiThread {
                val host = runCatching { Uri.parse(webView.url).host }.getOrNull()?.lowercase()
                if (host == null || !ClaudeSlots.isClaudeDomain(host) || claudeSlot < 0) return@runOnUiThread
                val o = runCatching { org.json.JSONObject(json) }.getOrNull() ?: return@runOnUiThread
                val e = o.optString("e").trim().take(120)
                val n = o.optString("n").trim().take(80)
                if (e.isEmpty() && n.isEmpty()) return@runOnUiThread
                val s = ClaudeSlots.get(this@CookiesActivity, claudeSlot) ?: return@runOnUiThread
                if (e.isNotEmpty()) s.email = e
                if (n.isNotEmpty()) s.name = n
                ClaudeSlots.put(this@CookiesActivity, claudeSlot, s)
            }
        }
    }

    /** true = skema selain web biasa (tiktok://, snssdk://, intent://, dst.). */
    private fun isAppScheme(u: Uri): Boolean = when (u.scheme?.lowercase()) {
        null, "http", "https", "about", "data", "blob", "javascript", "file" -> false
        else -> true
    }

    /**
     * Link bukan web (snssdk1180://, intent://, tiktok:// dst.) = situs mencoba membuka app-nya (terjadi di mode HP).
     * WebView tidak mengerti skema itu -> "ERR_UNKNOWN_URL_SCHEME". Di sini diblok saja; kalau link TikTok itu membawa
     * alamat web video (params_url), alamat web itulah yang dibuka. true = diblok.
     */
    private fun blockAppScheme(view: WebView?, u: Uri?): Boolean {
        if (u == null) return false
        when (u.scheme?.lowercase()) {
            null, "http", "https", "about", "data", "blob", "javascript", "file" -> return false
        }
        val web = runCatching { u.getQueryParameter("params_url") }.getOrNull()
        if (view != null && web != null && web.startsWith("http") && view.url != web) view.loadUrl(web)
        return true
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (inWeb) {
            if (bubble.closeAll()) return
            if (customView != null) { hideCustom(); return }
            if (popup != null) { closePopup(); return }
            if (webView.canGoBack()) webView.goBack() else closeWeb()
        } else {
            super.onBackPressed()
        }
    }
}
