package com.niven.mangatl

import android.annotation.SuppressLint
import android.graphics.Color
import android.graphics.Typeface
import android.net.Uri
import android.os.Bundle
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.webkit.CookieManager
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.button.MaterialButton

/**
 * Akun & cookies: untuk video yang minta login (anti-bot YouTube, batas umur, khusus member).
 * Dua cara: masuk lewat halaman web di dalam app, atau impor cookies.txt dari browser.
 */
class CookiesActivity : AppCompatActivity() {
    private lateinit var main: ScrollView
    private lateinit var web: LinearLayout
    private lateinit var webView: WebView
    private lateinit var tvStatus: TextView
    private lateinit var etSite: EditText
    private var ua = ""

    private val picker = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        if (uri == null) return@registerForActivityResult
        runCatching { DlCookies.importFrom(this, uri) }
            .onSuccess { Toast.makeText(this, "$it cookie diimpor.", Toast.LENGTH_SHORT).show() }
            .onFailure { Toast.makeText(this, it.message ?: "Gagal mengimpor.", Toast.LENGTH_LONG).show() }
        refresh()
    }

    private fun dp(v: Int) = Ui.dp(this, v)
    private val muted = Color.parseColor("#8E8E93")

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // ----- halaman utama -----
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(12), dp(16), dp(24))
        }
        val bar = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        bar.addView(Ui.iconBtn(this, R.drawable.ic_back, "Kembali") { finish() }, LinearLayout.LayoutParams(dp(44), dp(44)))
        bar.addView(TextView(this).apply {
            text = "Akun & cookies"
            textSize = 22f
            setTextColor(Color.WHITE)
            typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
        }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { marginStart = dp(8) })
        col.addView(bar)

        col.addView(TextView(this).apply {
            text = "Dipakai kalau YouTube meminta verifikasi (anti-bot), video dibatasi umur, atau khusus member. " +
                "Cookies hanya disimpan di HP ini dan hanya dikirim ke situs saat mengunduh.\n\n" +
                "Saran: pakai akun cadangan. YouTube kadang menandai akun yang dipakai untuk mengunduh."
            textSize = 13f
            setTextColor(muted)
            setLineSpacing(0f, 1.15f)
            setPadding(dp(4), dp(14), dp(4), dp(10))
        })
        tvStatus = TextView(this).apply {
            textSize = 14f
            setTextColor(Color.WHITE)
            setPadding(dp(4), dp(4), dp(4), dp(12))
        }
        col.addView(tvStatus)

        etSite = EditText(this).apply {
            setText("https://www.youtube.com")
            setTextColor(Color.WHITE)
            textSize = 14f
            maxLines = 1
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_URI
            setBackgroundResource(R.drawable.bg_field)
            setPadding(dp(14), dp(12), dp(14), dp(12))
        }
        col.addView(etSite, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        col.addView(button("Masuk lewat halaman web", false) { openWeb() },
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(48)).apply { topMargin = dp(10) })
        col.addView(button("Impor cookies.txt", true) { picker.launch(arrayOf("*/*")) },
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(48)).apply { topMargin = dp(8) })
        col.addView(Ui.switchRow(this, "Pakai cookies saat mengunduh", DlPrefs.useCookies(this)) {
            DlPrefs.setUseCookies(this, it)
        }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(10) })
        col.addView(button("Hapus cookies", true) {
            DlCookies.clear(this)
            refresh()
            Toast.makeText(this, "Cookies dihapus.", Toast.LENGTH_SHORT).show()
        }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(48)).apply { topMargin = dp(8) })

        main = ScrollView(this).apply { setBackgroundColor(Color.BLACK); addView(col) }

        // ----- halaman web -----
        webView = WebView(this)
        web = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.BLACK)
            addView(webView, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
            val row = LinearLayout(this@CookiesActivity).apply {
                orientation = LinearLayout.HORIZONTAL
                setPadding(dp(12), dp(8), dp(12), dp(8))
            }
            row.addView(button("Batal", true) { closeWeb() }, LinearLayout.LayoutParams(0, dp(48), 1f))
            row.addView(button("Selesai & simpan cookies", false) { saveFromWeb() },
                LinearLayout.LayoutParams(0, dp(48), 2f).apply { marginStart = dp(8) })
            addView(row)
        }

        ua = WebSettings.getDefaultUserAgent(this).replace("; wv", "").replace(Regex("Version/\\d+\\.\\d+\\s"), "")
        webView.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            javaScriptCanOpenWindowsAutomatically = true
            userAgentString = ua
        }
        CookieManager.getInstance().setAcceptCookie(true)
        CookieManager.getInstance().setAcceptThirdPartyCookies(webView, true)
        webView.webViewClient = WebViewClient()

        setContentView(main)
        refresh()
    }

    private fun button(label: String, outlined: Boolean, onClick: () -> Unit) = MaterialButton(
        this, null,
        if (outlined) com.google.android.material.R.attr.materialButtonOutlinedStyle
        else com.google.android.material.R.attr.materialButtonStyle
    ).apply {
        text = label
        isAllCaps = false
        cornerRadius = dp(24)
        setOnClickListener { onClick() }
    }

    private fun refresh() {
        val n = DlCookies.count(this)
        tvStatus.text = if (n > 0) "Cookies tersimpan: $n" else "Belum ada cookies tersimpan."
    }

    private fun openWeb() {
        var u = etSite.text.toString().trim()
        if (u.isEmpty()) return
        if (!u.startsWith("http")) u = "https://$u"
        setContentView(web)
        webView.loadUrl(u)
    }

    private fun closeWeb() {
        setContentView(main)
        refresh()
    }

    private fun saveFromWeb() {
        val current = webView.url ?: ""
        runCatching {
            DlCookies.exportFromWebView(
                this,
                listOf(current, "https://www.youtube.com", "https://accounts.google.com", "https://www.google.com")
                    .filter { it.isNotEmpty() }
            )
        }.onSuccess {
            DlPrefs.setUserAgent(this, ua)
            Toast.makeText(this, "$it cookie disimpan.", Toast.LENGTH_SHORT).show()
            closeWeb()
        }.onFailure { Toast.makeText(this, it.message ?: "Gagal menyimpan cookies.", Toast.LENGTH_LONG).show() }
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (web.parent != null && webView.canGoBack()) webView.goBack()
        else if (web.parent != null) closeWeb()
        else super.onBackPressed()
    }
}
