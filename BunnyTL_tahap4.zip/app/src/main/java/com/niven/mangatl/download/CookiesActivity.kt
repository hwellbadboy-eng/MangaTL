package com.niven.mangatl

import android.animation.ValueAnimator
import android.annotation.SuppressLint
import android.content.ClipboardManager
import android.content.Context
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.LayerDrawable
import android.os.Bundle
import android.text.InputType
import android.util.Patterns
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.webkit.CookieManager
import android.webkit.WebChromeClient
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat

/**
 * Browser login layar penuh: login ke situs, lalu ketuk Simpan untuk menyimpan cookies.
 * Tombol kecil di kanan bawah (atas ke bawah): Mode desktop, Akun (pindah situs), Browser (bar link), Simpan.
 * Impor/Hapus cookies dan saklar "Pakai cookies" ada di layar Unduh.
 */
class CookiesActivity : AppCompatActivity() {
    private lateinit var root: FrameLayout
    private lateinit var webView: WebView
    private lateinit var loadBar: View
    private lateinit var stack: LinearLayout
    private lateinit var caps: LinearLayout
    private lateinit var dim: View
    private lateinit var siteBtn: ImageView
    private lateinit var deskBtn: FrameLayout
    private lateinit var barBox: LinearLayout
    private lateinit var etUrl: EditText

    private var mobileUa = ""
    private var desktop = false
    private var barOpen = false
    private var capsOpen = false
    private var curSite: LoginSite? = null

    companion object {
        const val EXTRA_AUTO_WEB = "auto_web"
        const val EXTRA_LOGIN_URL = "login_url"
        private const val DESKTOP_UA =
            "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36"
    }

    private fun dp(v: Int) = Ui.dp(this, v)

    // ------------------------------------------------------------ gaya tombol
    /** Bulatan/pil hitam atau putih dengan garis tegas + bayangan keras kecil (komik tipis). */
    private fun comicBg(fill: Int, stroke: Int, shadow: Int, radiusDp: Int): LayerDrawable {
        fun shape(c: Int, s: Int?) = GradientDrawable().apply {
            setColor(c)
            cornerRadius = dp(radiusDp).toFloat()
            if (s != null) setStroke(dp(2), s)
        }
        val ring = if (fill == Color.WHITE) Color.BLACK else stroke
        val ld = LayerDrawable(arrayOf(shape(shadow, null), shape(fill, ring)))
        ld.setLayerInset(0, dp(2), dp(2), 0, 0)
        ld.setLayerInset(1, 0, 0, dp(2), dp(2))
        return ld
    }

    private fun pressFx(v: View) {
        v.setOnTouchListener { view, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> view.animate().translationX(dp(2).toFloat()).translationY(dp(2).toFloat()).setDuration(60).start()
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> view.animate().translationX(0f).translationY(0f).setDuration(80).start()
            }
            false
        }
    }

    private fun icon(res: Int, sizeDp: Int = 18, tint: Int = Color.WHITE) = ImageView(this).apply {
        setImageResource(res)
        setColorFilter(tint)
        layoutParams = FrameLayout.LayoutParams(dp(sizeDp), dp(sizeDp), Gravity.CENTER)
    }

    /** Tombol bulat 38dp berisi ikon; frame 40dp supaya bayangan tidak terpotong. */
    private fun roundBtn(res: Int, desc: String, onClick: () -> Unit): FrameLayout {
        return FrameLayout(this).apply {
            background = comicBg(Color.BLACK, Color.WHITE, Color.WHITE, 20)
            contentDescription = desc
            addView(icon(res))
            setOnClickListener { onClick() }
            pressFx(this)
        }
    }

    private fun siteIcon(site: LoginSite?): Int = when (site?.label) {
        "YouTube" -> R.drawable.ic_bw_yt
        "Instagram" -> R.drawable.ic_bw_ig
        "TikTok" -> R.drawable.ic_bw_tt
        "Facebook" -> R.drawable.ic_bw_fb
        "X" -> R.drawable.ic_bw_x
        else -> R.drawable.ic_bw_globe
    }

    // ------------------------------------------------------------ onCreate
    @SuppressLint("SetJavaScriptEnabled", "ClickableViewAccessibility")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // layar penuh: tanpa bar status/navigasi (geser dari tepi untuk memunculkan sementara)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        WindowInsetsControllerCompat(window, window.decorView).apply {
            systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            hide(WindowInsetsCompat.Type.systemBars())
        }

        root = FrameLayout(this).apply { setBackgroundColor(Color.BLACK) }

        // ----- halaman web penuh -----
        webView = WebView(this)
        root.addView(webView, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))

        mobileUa = WebSettings.getDefaultUserAgent(this).replace("; wv", "").replace(Regex("Version/\\d+\\.\\d+\\s"), "")
        webView.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            javaScriptCanOpenWindowsAutomatically = true
            userAgentString = mobileUa
            useWideViewPort = true
        }
        CookieManager.getInstance().setAcceptCookie(true)
        CookieManager.getInstance().setAcceptThirdPartyCookies(webView, true)
        webView.webViewClient = WebViewClient()
        webView.webChromeClient = object : WebChromeClient() {
            override fun onProgressChanged(view: WebView?, newProgress: Int) {
                loadBar.pivotX = 0f
                loadBar.scaleX = newProgress / 100f
                loadBar.alpha = if (newProgress >= 100) 0f else 1f
            }
        }

        // garis loading tipis di paling atas
        loadBar = View(this).apply { setBackgroundColor(Color.WHITE); scaleX = 0f }
        root.addView(loadBar, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(2), Gravity.TOP))

        // lapisan penutup: ketuk di luar popup untuk menutup
        dim = View(this).apply {
            visibility = View.GONE
            setOnClickListener { closeCaps() }
        }
        root.addView(dim, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))

        // ----- tumpukan tombol kanan bawah -----
        stack = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.END
        }
        val btnLp = { LinearLayout.LayoutParams(dp(42), dp(42)).apply { topMargin = dp(7) } }

        // 1) Mode desktop
        deskBtn = roundBtn(R.drawable.ic_bw_desktop, "Mode desktop") { toggleDesktop() }
        stack.addView(deskBtn, btnLp())

        // kapsul situs (muncul ke atas dari tombol Akun)
        caps = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.END
            visibility = View.GONE
        }
        stack.addView(caps, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT))

        // 2) Akun = ikon situs aktif
        siteBtn = ImageView(this)
        val siteFrame = FrameLayout(this).apply {
            background = comicBg(Color.BLACK, Color.WHITE, Color.WHITE, 20)
            contentDescription = "Pindah situs"
            addView(siteBtn.apply { setColorFilter(Color.WHITE); layoutParams = FrameLayout.LayoutParams(dp(18), dp(18), Gravity.CENTER) })
            setOnClickListener { if (capsOpen) closeCaps() else openCaps() }
            pressFx(this)
        }
        stack.addView(siteFrame, btnLp())

        // 3) Browser: bar link melebar ke kiri + tombol globe
        val browseRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        barBox = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            background = comicBg(Color.BLACK, Color.WHITE, Color.WHITE, 20)
            setPadding(dp(12), 0, dp(6), dp(2))
            visibility = View.GONE
        }
        etUrl = EditText(this).apply {
            hint = "Tempel link atau cari"
            setHintTextColor(Color.parseColor("#8E8E93"))
            setTextColor(Color.WHITE)
            textSize = 14f
            maxLines = 1
            background = null
            setPadding(0, 0, 0, 0)
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_URI
            imeOptions = EditorInfo.IME_ACTION_GO
            setOnEditorActionListener { _, _, _ -> goUrl(); true }
        }
        barBox.addView(etUrl, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f))
        barBox.addView(ImageView(this).apply {
            setImageResource(R.drawable.ic_bw_paste); setColorFilter(Color.parseColor("#C7C7CC"))
            setPadding(dp(6), dp(6), dp(6), dp(6))
            contentDescription = "Tempel"
            setOnClickListener { pasteUrl() }
        }, LinearLayout.LayoutParams(dp(30), dp(30)))
        barBox.addView(FrameLayout(this).apply {
            background = GradientDrawable().apply { setColor(Color.WHITE); cornerRadius = dp(15).toFloat() }
            contentDescription = "Buka"
            addView(icon(R.drawable.ic_bw_go, 16, Color.BLACK))
            setOnClickListener { goUrl() }
        }, LinearLayout.LayoutParams(dp(30), dp(30)).apply { marginStart = dp(4) })
        browseRow.addView(barBox, LinearLayout.LayoutParams(0, dp(42)))
        browseRow.addView(roundBtn(R.drawable.ic_bw_globe, "Browser") { toggleBar() }, LinearLayout.LayoutParams(dp(42), dp(42)))
        stack.addView(browseRow, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            .apply { topMargin = dp(7); gravity = Gravity.END })

        // 4) Simpan
        val save = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            background = comicBg(Color.WHITE, Color.BLACK, Color.parseColor("#8E8E93"), 21)
            setPadding(dp(12), 0, dp(17), dp(2))
            contentDescription = "Simpan cookies"
            addView(icon(R.drawable.ic_bw_check, 16, Color.BLACK), LinearLayout.LayoutParams(dp(16), dp(16)))
            addView(TextView(this@CookiesActivity).apply {
                text = "Simpan"
                textSize = 13f
                setTextColor(Color.BLACK)
                typeface = android.graphics.Typeface.create("sans-serif-medium", android.graphics.Typeface.BOLD)
            }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { marginStart = dp(6) })
            setOnClickListener { saveFromWeb() }
            pressFx(this)
        }
        stack.addView(save, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(42)).apply { topMargin = dp(7) })

        root.addView(stack, FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.BOTTOM or Gravity.END)
            .apply { setMargins(0, 0, dp(10), dp(14)) })

        // keyboard muncul -> tumpukan tombol naik
        ViewCompat.setOnApplyWindowInsetsListener(root) { _, insets ->
            val ime = insets.getInsets(WindowInsetsCompat.Type.ime()).bottom
            val sys = insets.getInsets(WindowInsetsCompat.Type.systemBars()).bottom
            (stack.layoutParams as FrameLayout.LayoutParams).bottomMargin = dp(14) + maxOf(ime, sys)
            stack.requestLayout()
            insets
        }

        setContentView(root)

        // ----- buka halaman login -----
        val u = intent.getStringExtra(EXTRA_LOGIN_URL) ?: DlCookies.loginUrlFor(this, null)
        openSite(DlCookies.siteFor(u), u)
        Toast.makeText(this, "Masuk dulu, lalu ketuk Simpan.", Toast.LENGTH_LONG).show()
    }

    // ------------------------------------------------------------ aksi
    private fun openSite(site: LoginSite?, url: String) {
        curSite = site
        site?.let { DlPrefs.setLastLogin(this, it.key) }
        siteBtn.setImageResource(siteIcon(site))
        webView.loadUrl(url)
    }

    private fun toggleDesktop() {
        desktop = !desktop
        webView.settings.userAgentString = if (desktop) DESKTOP_UA else mobileUa
        webView.settings.loadWithOverviewMode = desktop
        deskBtn.background = if (desktop) comicBg(Color.WHITE, Color.BLACK, Color.parseColor("#8E8E93"), 20)
        else comicBg(Color.BLACK, Color.WHITE, Color.WHITE, 20)
        (deskBtn.getChildAt(0) as ImageView).setColorFilter(if (desktop) Color.BLACK else Color.WHITE)
        webView.reload()
        Toast.makeText(this, if (desktop) "Mode desktop aktif" else "Mode desktop mati", Toast.LENGTH_SHORT).show()
    }

    private fun openCaps() {
        closeBar()
        caps.removeAllViews()
        DlCookies.SITES.reversed().forEach { site ->
            val on = site.key == curSite?.key
            val fg = if (on) Color.BLACK else Color.WHITE
            val chip = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                background = if (on) comicBg(Color.WHITE, Color.BLACK, Color.parseColor("#8E8E93"), 18)
                else comicBg(Color.BLACK, Color.WHITE, Color.WHITE, 18)
                setPadding(dp(10), 0, dp(14), dp(2))
                addView(icon(siteIcon(site), 18, fg), LinearLayout.LayoutParams(dp(18), dp(18)))
                addView(TextView(this@CookiesActivity).apply {
                    text = site.label; textSize = 13f; setTextColor(fg)
                }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { marginStart = dp(7) })
                setOnClickListener {
                    closeCaps()
                    openSite(site, site.loginUrl)
                    Toast.makeText(this@CookiesActivity, "Membuka ${site.label}…", Toast.LENGTH_SHORT).show()
                }
                pressFx(this)
            }
            caps.addView(chip, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(36)).apply { topMargin = dp(6) })
            chip.alpha = 0f
            chip.translationY = dp(8).toFloat()
            chip.animate().alpha(1f).translationY(0f).setDuration(160).start()
        }
        caps.visibility = View.VISIBLE
        dim.visibility = View.VISIBLE
        capsOpen = true
    }

    private fun closeCaps() {
        caps.visibility = View.GONE
        dim.visibility = View.GONE
        capsOpen = false
    }

    private fun toggleBar() { if (barOpen) closeBar() else openBar() }

    private fun openBar() {
        closeCaps()
        barOpen = true
        val target = minOf(resources.displayMetrics.widthPixels - dp(76), dp(320))
        barBox.visibility = View.VISIBLE
        ValueAnimator.ofInt(0, target).apply {
            duration = 220
            addUpdateListener {
                val lp = barBox.layoutParams as LinearLayout.LayoutParams
                lp.width = it.animatedValue as Int
                lp.weight = 0f
                barBox.layoutParams = lp
            }
            start()
        }
        etUrl.postDelayed({
            etUrl.requestFocus()
            (getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager).showSoftInput(etUrl, InputMethodManager.SHOW_IMPLICIT)
        }, 240)
    }

    private fun closeBar() {
        if (!barOpen) return
        barOpen = false
        (getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager).hideSoftInputFromWindow(etUrl.windowToken, 0)
        etUrl.clearFocus()
        val from = barBox.width
        ValueAnimator.ofInt(from, 0).apply {
            duration = 180
            addUpdateListener {
                val lp = barBox.layoutParams as LinearLayout.LayoutParams
                lp.width = it.animatedValue as Int
                lp.weight = 0f
                barBox.layoutParams = lp
            }
            addListener(object : android.animation.AnimatorListenerAdapter() {
                override fun onAnimationEnd(a: android.animation.Animator) { if (!barOpen) barBox.visibility = View.GONE }
            })
            start()
        }
        WindowInsetsControllerCompat(window, window.decorView).hide(WindowInsetsCompat.Type.systemBars())
    }

    private fun pasteUrl() {
        val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        val t = cm.primaryClip?.takeIf { it.itemCount > 0 }?.getItemAt(0)?.coerceToText(this)?.toString()
        if (t.isNullOrBlank()) Toast.makeText(this, "Clipboard kosong.", Toast.LENGTH_SHORT).show()
        else { etUrl.setText(t.trim()); etUrl.setSelection(etUrl.text.length) }
    }

    /** Link langsung dibuka; kalau bukan link, dicari lewat Google. */
    private fun goUrl() {
        val v = etUrl.text.toString().trim()
        if (v.isEmpty()) return
        val url = when {
            v.startsWith("http://", true) || v.startsWith("https://", true) -> v
            !v.contains(' ') && Patterns.WEB_URL.matcher(v).matches() -> "https://$v"
            else -> "https://www.google.com/search?q=" + android.net.Uri.encode(v)
        }
        closeBar()
        curSite = DlCookies.siteFor(url) ?: curSite
        siteBtn.setImageResource(siteIcon(curSite))
        webView.loadUrl(url)
    }

    private fun saveFromWeb() {
        val current = webView.url ?: ""
        runCatching {
            DlCookies.exportFromWebView(
                this,
                (listOf(current, "https://www.youtube.com", "https://accounts.google.com", "https://www.google.com") +
                    DlCookies.SITES.map { it.loginUrl }).filter { it.isNotEmpty() }
            )
        }.onSuccess {
            // UA yang tersimpan harus sama dengan UA saat login (mode desktop ikut tersimpan)
            DlPrefs.setUserAgent(this, if (desktop) DESKTOP_UA else mobileUa)
            Toast.makeText(this, "$it cookie disimpan.", Toast.LENGTH_SHORT).show()
            setResult(RESULT_OK)
            finish()
        }.onFailure { Toast.makeText(this, it.message ?: "Gagal menyimpan cookies.", Toast.LENGTH_LONG).show() }
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        when {
            capsOpen -> closeCaps()
            barOpen -> closeBar()
            webView.canGoBack() -> webView.goBack()
            else -> { setResult(RESULT_CANCELED); finish() }
        }
    }

    override fun onDestroy() {
        (webView.parent as? ViewGroup)?.removeView(webView)
        webView.destroy()
        super.onDestroy()
    }
}
