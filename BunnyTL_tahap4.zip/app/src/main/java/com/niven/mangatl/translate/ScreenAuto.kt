package com.niven.mangatl

import android.graphics.Bitmap
import android.os.SystemClock
import android.view.View
import android.widget.Toast

// Terjemah layar: ketukan tombol, mode otomatis (pantau perubahan layar), dan jadwal diam.
// Fungsi ekstensi dari ScreenService; keadaan dan siklus hidup service tetap di ScreenService.kt.

internal fun ScreenService.onTap() {
    // Mode auto: ketuk tombol = jeda / lanjut.
    if (autoOn) {
        autoPaused = !autoPaused
        if (autoPaused) {
            cap?.removeCallbacks(autoRun)
            clearResults()
        } else {
            lastSig = null
            candSig = null
            changingTicks = 0
            scheduleAuto(200)
        }
        fab?.text = fabIdleText()
        Toast.makeText(this, if (autoPaused) "Auto dijeda." else "Auto lanjut.", Toast.LENGTH_SHORT).show()
        return
    }
    if (busy) {
        Toast.makeText(this, "Masih memproses...", Toast.LENGTH_SHORT).show()
        return
    }
    // Hasil sedang tampil: tutup dulu. Mode 1 (tap berurutan) langsung lanjut terjemahkan layar berikutnya.
    val hadResult = overlayShown()
    if (hadResult) {
        clearResults()
        if (prefs().getInt("smode", 1) == 0) return
    }
    busy = true
    // Sembunyikan tombol supaya tidak ikut terbaca OCR.
    fab?.visibility = View.INVISIBLE
    cap?.postDelayed({ requestFrame() }, if (hadResult) 260L else 160L)
}

internal fun ScreenService.scheduleAuto(ms: Long) {
    cap?.removeCallbacks(autoRun)
    if (autoOn && !autoPaused) cap?.postDelayed(autoRun, ms)
}

/**
 * Jadwal pemeriksaan berikutnya. Kalau terjemahan sedang tampil, pemeriksaan berkala harus menyembunyikannya
 * sekejap (kedip), jadi dijarangkan atau dimatikan sesuai pilihan di Opsi.
 */
internal fun ScreenService.scheduleIdle() {
    if (!overlayShown()) {
        scheduleAuto(800)
        return
    }
    val ms = when (prefs().getInt("auto_poll", 0)) {
        1 -> 0L
        2 -> 4000L
        3 -> 2000L
        else -> if (recentTouch()) 8000L else 3000L
    }
    if (ms > 0L) scheduleAuto(ms)
}

/** Dipanggil saat layanan mulai dan saat pilihan mode di Opsi berubah. */
internal fun ScreenService.applyMode() {
    val auto = prefs().getInt("smode", 1) == 2
    if (auto != autoOn) {
        autoOn = auto
        cap?.removeCallbacks(autoRun)
        clearResults()
        if (auto) {
            autoPaused = false
            lastSig = null
            candSig = null
            changingTicks = 0
            scheduleAuto(600)
        }
    }
    if (!busy) fab?.text = fabIdleText()
}

/** Satu putaran auto (thread tangkap layar). touch = dipicu ketukan ke game. */
internal fun ScreenService.autoTick(touch: Boolean) {
    if (!autoOn) return
    try {
        if (autoPaused || busy || editor != null || menu != null) {
            if (touch) restoreOverlay()
            scheduleAuto(600)
            return
        }
        val s = realSize()
        dpi = s[2]
        if (ensureDisplay(s[0], s[1])) {
            scheduleAuto(500)
            return
        }
        if (overlayShown()) {
            val p = prefs().getInt("auto_poll", 0)
            if (!touch && (p == 1 || (p == 0 && recentTouch()))) {
                // Tidak perlu memeriksa (dan tidak perlu berkedip): tunggu ketukan berikutnya.
                scheduleIdle()
                return
            }
            if (touch) {
                // Hasil sudah disembunyikan saat ketukan terdeteksi.
                cap?.postDelayed({ autoCapture(touchHideAt, 0) }, 0)
            } else {
                val hideAt = SystemClock.uptimeMillis()
                main.post {
                    ov?.alpha = 0f
                    panel?.alpha = 0f
                }
                cap?.postDelayed({ autoCapture(hideAt, 0) }, 90)
            }
        } else {
            autoCapture(0L, 0)
        }
    } catch (_: Throwable) {
        restoreOverlay()
        scheduleAuto(1500)
    }
}

internal fun ScreenService.autoCapture(hideAt: Long, attempt: Int) {
    try {
        if (!autoOn) return
        if (hideAt > 0L && heldAt < hideAt + 30 && attempt < 6) {
            cap?.postDelayed({ autoCapture(hideAt, attempt + 1) }, 60)
            return
        }
        val bmp: Bitmap? = synchronized(heldLock) {
            val h = held
            if (h == null) {
                null
            } else {
                try {
                    toBitmap(h)
                } catch (_: Throwable) {
                    null
                }
            }
        }
        if (bmp == null) {
            restoreOverlay()
            scheduleIdle()
            return
        }
        val sig = areaSig(bmp)
        val base = lastSig
        // Kalau teks yang sama terus terbaca padahal piksel berubah (animasi), ambang dinaikkan supaya hemat.
        val thr = 3.0 + minOf(sameStreak * 1.5, 6.0)
        if (base != null && sigDiffPct(sig, base) <= thr) {
            candSig = null
            changingTicks = 0
            restoreOverlay()
            scheduleIdle()
            return
        }
        val cand = candSig
        val stable = cand != null && sigDiffPct(sig, cand) <= 2.5
        if (stable || changingTicks >= 6) {
            // Layar sudah berhenti berubah (teks selesai muncul): baca dan terjemahkan.
            candSig = null
            changingTicks = 0
            lastSig = sig
            busy = true
            process(bmp, true)
            return
        }
        // Masih berubah (mis. teks sedang diketik): hasil lama tetap tersembunyi, cek lagi sebentar lagi.
        candSig = sig
        changingTicks++
        scheduleAuto(350)
    } catch (_: Throwable) {
        restoreOverlay()
        scheduleAuto(1500)
    }
}
