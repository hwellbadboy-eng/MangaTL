package com.niven.mangatl

import android.graphics.Color
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.animation.AccelerateInterpolator
import android.view.animation.DecelerateInterpolator
import android.view.animation.OvershootInterpolator
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

// Layar Sedang diputar: tab fitur Audio Engine di bawah cover (tab, popup pengaturan, status Hi-Res).
// Fungsi ekstensi dari NowPlayingActivity; keadaan dan siklus hidup layar tetap di NowPlayingActivity.kt.

internal class Tab(val fid: String?, val label: String, val box: FrameLayout, val l1: TextView, val l2: TextView, val dot: View, val col: View)

internal fun NowPlayingActivity.buildTabs() {
    val defs = listOf(
        Pair("BASS", AudioEngine.BASS), Pair("3D", AudioEngine.SPATIAL), Pair("VOKAL", AudioEngine.VOCAL),
        Pair("REVERB", AudioEngine.REVERB), Pair("EFEK", null as String?)
    )
    for ((idx, def) in defs.withIndex()) {
        val (label, fid) = def
        val edge = when (idx) { 0 -> Gravity.START; defs.size - 1 -> Gravity.END; else -> Gravity.CENTER_HORIZONTAL }
        val box = FrameLayout(this)
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.gravity = Gravity.CENTER
        val l1 = TextView(this)
        l1.text = label
        l1.textSize = 13f
        l1.letterSpacing = 0.14f
        l1.gravity = Gravity.CENTER
        val l2 = TextView(this)
        l2.textSize = 11f
        l2.gravity = Gravity.CENTER
        col.addView(l1)
        col.addView(l2)
        // Tab pertama rata kiri, terakhir rata kanan (sejajar tepi waktu/seekbar); sisanya tetap di tengah kolom.
        // Teks bawah (0 dB / 5 aktif) tetap di tengah di bawah judulnya.
        if (edge == Gravity.CENTER_HORIZONTAL) {
            box.addView(col, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        } else {
            box.addView(col, FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.MATCH_PARENT, edge))
            // letterSpacing menambah jarak setelah huruf terakhir; geser supaya huruf "K" benar-benar rata kanan.
            if (edge == Gravity.END) l1.translationX = l1.textSize * l1.letterSpacing
        }
        val dot = View(this)
        dot.background = AU.shape(Color.WHITE, 2f, this)
        val dl = FrameLayout.LayoutParams(Ui.dp(this, 4), Ui.dp(this, 4), Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL)
        dl.bottomMargin = Ui.dp(this, 4)
        box.addView(dot, dl)
        // titik indikator mengikuti titik tengah teks, bukan tengah kolom
        col.addOnLayoutChangeListener { _, l, _, r, _, _, _, _, _ ->
            dot.translationX = (l + r) / 2f - box.width / 2f
        }
        val t = Tab(fid, label, box, l1, l2, dot, col)
        tabList.add(t)
        box.setOnClickListener {
            if (fid == null) startActivity(android.content.Intent(this, AudioEngineActivity::class.java))
            else togglePop(fid, box.x + col.left + col.width / 2f)
        }
        tabs.addView(box, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f))
    }
}

internal fun NowPlayingActivity.refreshTabs() {
    val d = resources.displayMetrics.density
    for (t in tabList) {
        val fid = t.fid
        if (fid == null) {
            t.l1.setTextColor(Color.WHITE)
            val n = AudioEngine.features.count { it.id != AudioEngine.AVATAR && AudioEngine.isOn(it.id) }
            t.l2.text = "$n aktif"
            t.l2.setTextColor(Color.WHITE)
            t.l2.alpha = 0.7f
            t.dot.visibility = View.GONE
            continue
        }
        val on = AudioEngine.isOn(fid)
        val f = AudioEngine.feature(fid)
        val qi = f.quick.firstOrNull() ?: 0
        val p = f.params[qi]
        t.l2.text = if (!on) "mati" else {
            val v = AudioEngine.get(fid, qi)
            if (p is PNum) AU.fmt(v) + (if (p.unit.isEmpty()) "" else " " + p.unit) else ""
        }
        t.l1.setTextColor(if (on) Color.WHITE else AU.MUT)
        t.l2.setTextColor(if (on) Color.WHITE else AU.MUT)
        t.l1.animate().translationY(if (on) -7 * d else 0f).setDuration(320).setInterpolator(OvershootInterpolator(1.4f)).start()
        t.l2.animate().translationY(if (on) -5 * d else 0f).alpha(if (on) 0.9f else 0.7f).setDuration(320)
            .setInterpolator(OvershootInterpolator(1.4f)).start()
        t.dot.visibility = if (on) View.VISIBLE else View.GONE
    }
}

internal fun NowPlayingActivity.hiResText(): String {
    if (!AudioEngine.isOn(AudioEngine.HIRES)) return "Hi-Res mati"
    val v = AudioEngine.raw(AudioEngine.HIRES)
    if (v.size > 5 && v[5].toInt() == 1) return if (OutputCaps.bitPerfectAvailable()) "Bit-perfect" else "Bit-perfect tidak tersedia"
    // format yang benar-benar dikirim ke Android (bukan sekadar pengaturan), kalau sudah ada aliran aktif
    val actual = AudioEngine.outputInfo
    if (actual.isNotEmpty()) return actual
    val rates = arrayOf("Auto", "44.1", "48", "88.2", "96", "176.4", "192")
    val r = v[0].toInt().coerceIn(0, 6)
    val b = v[1].toInt().coerceIn(0, 3)
    val rate = if (r == 0) "Auto" else rates[r] + " kHz"
    val bit = if (b == 0) "Auto" else "${intArrayOf(0, 16, 24, 32)[b]} bit"
    return "$bit / $rate"
}

internal fun NowPlayingActivity.updateHiState() {
    val on = AudioEngine.isOn(AudioEngine.HIRES)
    if (on) {
        tvHiBadge.background = AU.shape(Color.WHITE, 6f, this)
        tvHiBadge.setTextColor(Color.BLACK)
    } else {
        tvHiBadge.background = AU.shape(0, 6f, this, Color.WHITE, 2)
        tvHiBadge.setTextColor(Color.WHITE)
    }
    tvHiState.text = hiResText()
}

internal fun NowPlayingActivity.togglePop(fid: String, anchorX: Float) {
    if (popLayer.visibility == View.VISIBLE && popFid == fid && !popClosing) {
        hidePop()
        return
    }
    showPop(fid, anchorX)
}

internal fun NowPlayingActivity.clearPop() {
    popLayer.visibility = View.GONE
    popLayer.removeAllViews()
    popRows.clear()
    popFid = null
    popBody = null
    popClosing = false
}

/** Tutup popup: mengecil ke tombol tab (kebalikan animasi buka, seperti desain). */
internal fun NowPlayingActivity.hidePop() {
    if (popLayer.visibility != View.VISIBLE || popClosing) return
    val card = popLayer.getChildAt(0)
    if (card == null) {
        clearPop()
        return
    }
    popClosing = true
    card.animate().cancel()
    card.animate().alpha(0f).scaleX(0.04f).scaleY(0.04f).setDuration(300)
        .setInterpolator(AccelerateInterpolator(1.4f))
        .withEndAction { if (popLayer.getChildAt(0) === card) clearPop() }
        .start()
}

internal fun NowPlayingActivity.showPop(fid: String, anchorX: Float) {
    popLayer.getChildAt(0)?.animate()?.cancel()
    popLayer.removeAllViews()
    popRows.clear()
    popClosing = false
    popFid = fid
    val f = AudioEngine.feature(fid)
    val w = npRoot.width
    val cardW = minOf(Ui.dp(this, 304), w - Ui.dp(this, 24))
    val maxH = (npRoot.height * 0.42f).toInt()

    val card = LinearLayout(this)
    card.orientation = LinearLayout.VERTICAL
    card.background = AU.shape(0xFF1C1C20.toInt(), 22f, this, 0xFF2E2E34.toInt(), 1)
    card.isClickable = true
    card.elevation = Ui.dp(this, 12).toFloat()

    val head = LinearLayout(this)
    head.orientation = LinearLayout.HORIZONTAL
    head.gravity = Gravity.CENTER_VERTICAL
    head.setPadding(Ui.dp(this, 16), Ui.dp(this, 12), Ui.dp(this, 16), Ui.dp(this, 4))
    head.addView(AU.text(this, f.title, 15f, Color.WHITE, true), LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
    val reset = AU.text(this, "Reset", 13f, AU.MUT)
    reset.setPadding(Ui.dp(this, 8), Ui.dp(this, 8), Ui.dp(this, 12), Ui.dp(this, 8))
    reset.setOnClickListener {
        AudioEngine.resetFeature(fid)
        refreshAll()
    }
    head.addView(reset)
    head.addView(AU.switch(this, AudioEngine.featureOn(fid)) { v ->
        AudioEngine.setOn(fid, v)
        refreshAll()
    })
    card.addView(head)

    val sv = ScrollView(this)
    sv.isVerticalScrollBarEnabled = false
    val col = LinearLayout(this)
    col.orientation = LinearLayout.VERTICAL
    col.setPadding(Ui.dp(this, 16), 0, Ui.dp(this, 2), Ui.dp(this, 8))
    // semua parameter fitur (seperti desain), bukan hanya yang "quick"
    for (qi in f.params.indices) {
        val r = ParamRow(this, fid, qi, true) { refreshAll() }
        popRows.add(r)
        col.addView(r.view)
    }
    col.alpha = if (AudioEngine.featureOn(fid)) 1f else 0.45f
    popBody = col
    sv.addView(col)
    val rail = RailView(this, sv)
    sv.setOnScrollChangeListener { _, _, _, _, _ -> rail.invalidate() }
    val body = LinearLayout(this)
    body.orientation = LinearLayout.HORIZONTAL
    body.addView(sv, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f))
    val rl = LinearLayout.LayoutParams(Ui.dp(this, 28), ViewGroup.LayoutParams.MATCH_PARENT)
    rl.topMargin = Ui.dp(this, 6)
    rl.bottomMargin = Ui.dp(this, 10)
    body.addView(rail, rl)

    col.measure(
        View.MeasureSpec.makeMeasureSpec(cardW - Ui.dp(this, 28), View.MeasureSpec.EXACTLY),
        View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED)
    )
    head.measure(
        View.MeasureSpec.makeMeasureSpec(cardW, View.MeasureSpec.EXACTLY),
        View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED)
    )
    val bodyH = minOf(col.measuredHeight, maxH - head.measuredHeight).coerceAtLeast(Ui.dp(this, 80))
    // rail hanya muncul kalau isi memang bisa digulir
    rail.visibility = if (col.measuredHeight > bodyH + 1) View.VISIBLE else View.INVISIBLE
    card.addView(body, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, bodyH))

    // lapisan popup berhenti tepat di atas tab bar, jadi tab lain tetap bisa diketuk
    val tl = IntArray(2)
    val rl2 = IntArray(2)
    tabs.getLocationOnScreen(tl)
    npRoot.getLocationOnScreen(rl2)
    (popLayer.layoutParams as ViewGroup.MarginLayoutParams).bottomMargin = (rl2[1] + npRoot.height) - tl[1]
    popLayer.requestLayout()
    val lp = FrameLayout.LayoutParams(cardW, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL)
    lp.bottomMargin = Ui.dp(this, 6)
    popLayer.addView(card, lp)
    popLayer.visibility = View.VISIBLE
    card.alpha = 0f
    card.scaleX = 0.04f
    card.scaleY = 0.04f
    val anchorScreenX = tl[0] + anchorX
    card.post {
        card.pivotY = card.height.toFloat()
        card.pivotX = (anchorScreenX - card.left).coerceIn(0f, card.width.toFloat())
        card.animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(380)
            .setInterpolator(DecelerateInterpolator(1.6f)).start()
    }
}
