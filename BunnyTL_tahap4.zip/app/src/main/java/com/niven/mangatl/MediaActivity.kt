package com.niven.mangatl

import android.Manifest
import android.app.Activity
import android.app.RecoverableSecurityException
import android.net.Uri
import android.provider.MediaStore
import android.widget.Toast
import androidx.activity.result.IntentSenderRequest
import android.content.pm.PackageManager
import android.os.Build
import android.view.View
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity

/** Dasar layar pustaka: urus izin baca media. kind: 1 = musik, 2 = video. */
abstract class MediaActivity : AppCompatActivity() {

    protected abstract val kind: Int
    protected abstract fun onMediaReady()
    protected abstract fun deniedView(): TextView

    private val permLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) {
        if (hasMedia()) onMediaReady() else {
            deniedView().apply {
                text = "Izin baca media ditolak. Beri izin di Pengaturan HP > Aplikasi > BunnyTL > Izin."
                visibility = View.VISIBLE
            }
        }
    }

    // ----- hapus permanen (lagu / video) -----
    // Android 11+: sistem menampilkan satu dialog konfirmasi, lalu file benar-benar dihapus dari HP.
    private var pendingDelete: ((Boolean) -> Unit)? = null
    private var pendingUris: List<Uri> = emptyList()

    private val deleteLauncher = registerForActivityResult(
        ActivityResultContracts.StartIntentSenderForResult()
    ) { r ->
        val cb = pendingDelete
        pendingDelete = null
        if (cb == null) return@registerForActivityResult
        if (r.resultCode != Activity.RESULT_OK) {
            cb(false)
        } else if (Build.VERSION.SDK_INT == 29) {
            // Android 10: izin diberikan, hapus ulang sekarang.
            cb(try { pendingUris.sumOf { contentResolver.delete(it, null, null) } > 0 } catch (e: Exception) { false })
        } else {
            cb(true)
        }
    }

    /** Hapus file media permanen. onDone(true) kalau terhapus. Konfirmasi "Yakin?" ditampilkan pemanggil dulu. */
    protected fun deleteMedia(uris: List<Uri>, onDone: (Boolean) -> Unit) {
        if (uris.isEmpty()) {
            onDone(false)
            return
        }
        try {
            if (Build.VERSION.SDK_INT >= 30) {
                val pi = MediaStore.createDeleteRequest(contentResolver, uris)
                pendingDelete = onDone
                pendingUris = uris
                deleteLauncher.launch(IntentSenderRequest.Builder(pi.intentSender).build())
            } else {
                val n = uris.sumOf { contentResolver.delete(it, null, null) }
                onDone(n > 0)
            }
        } catch (e: SecurityException) {
            if (Build.VERSION.SDK_INT == 29 && e is RecoverableSecurityException) {
                pendingDelete = onDone
                pendingUris = uris
                deleteLauncher.launch(IntentSenderRequest.Builder(e.userAction.actionIntent.intentSender).build())
            } else {
                Toast.makeText(this, "Gagal menghapus: tidak ada izin.", Toast.LENGTH_LONG).show()
                onDone(false)
            }
        } catch (e: Exception) {
            Toast.makeText(this, "Gagal menghapus: ${e.message}", Toast.LENGTH_LONG).show()
            onDone(false)
        }
    }

    private fun need(): List<String> =
        if (Build.VERSION.SDK_INT >= 33) {
            if (kind == 1) listOf(Manifest.permission.READ_MEDIA_AUDIO)
            else listOf(Manifest.permission.READ_MEDIA_VIDEO)
        } else listOf(Manifest.permission.READ_EXTERNAL_STORAGE)

    private fun hasMedia() = need().all {
        checkSelfPermission(it) == PackageManager.PERMISSION_GRANTED
    }

    protected fun ensureMedia() {
        if (hasMedia()) {
            onMediaReady()
        } else {
            val p = ArrayList(need())
            if (kind == 1 && Build.VERSION.SDK_INT >= 33) p.add(Manifest.permission.POST_NOTIFICATIONS)
            permLauncher.launch(p.toTypedArray())
        }
    }
}
