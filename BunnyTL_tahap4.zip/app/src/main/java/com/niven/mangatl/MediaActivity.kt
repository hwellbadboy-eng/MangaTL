package com.niven.mangatl

import android.Manifest
import android.app.Activity
import android.app.RecoverableSecurityException
import android.content.ContentValues
import android.net.Uri
import android.provider.MediaStore
import android.widget.Toast
import androidx.activity.result.IntentSenderRequest
import android.content.pm.PackageManager
import android.os.Build
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.LinearLayout
import androidx.activity.OnBackPressedCallback
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity

/** Dasar layar pustaka: urus izin baca media. kind: 1 = musik, 2 = video. */
abstract class MediaActivity : AppCompatActivity() {

    protected abstract val kind: Int
    protected abstract fun onMediaReady()
    protected abstract fun deniedView(): TextView

    private val permLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) {
        if (hasMedia()) onMediaReady() else {
            deniedView().apply {
                text = "Izin baca media ditolak. Beri izin di Pengaturan HP > Aplikasi > BunnyTL > Izin."
                visibility = View.VISIBLE
            }
        }
    }

    // ----- hapus permanen (lagu / video) -----
    // Android 11+: sistem menampilkan satu dialog konfirmasi, lalu file benar-benar dihapus dari HP.
    private var pendingDelete: ((Boolean) -> Unit)? = null
    private var pendingUris: List<Uri> = emptyList()

    private val deleteLauncher = registerForActivityResult(
        ActivityResultContracts.StartIntentSenderForResult()
    ) { r ->
        val cb = pendingDelete
        pendingDelete = null
        if (cb == null) return@registerForActivityResult
        if (r.resultCode != Activity.RESULT_OK) {
            cb(false)
        } else if (Build.VERSION.SDK_INT == 29) {
            // Android 10: izin diberikan, hapus ulang sekarang.
            cb(try { pendingUris.sumOf { contentResolver.delete(it, null, null) } > 0 } catch (e: Exception) { false })
        } else {
            cb(true)
        }
    }

    /** Hapus file media permanen. onDone(true) kalau terhapus. Konfirmasi "Yakin?" ditampilkan pemanggil dulu. */
    protected fun deleteMedia(uris: List<Uri>, onDone: (Boolean) -> Unit) {
        if (uris.isEmpty()) {
            onDone(false)
            return
        }
        try {
            if (Build.VERSION.SDK_INT >= 30) {
                val pi = MediaStore.createDeleteRequest(contentResolver, uris)
                pendingDelete = onDone
                pendingUris = uris
                deleteLauncher.launch(IntentSenderRequest.Builder(pi.intentSender).build())
            } else {
                val n = uris.sumOf { contentResolver.delete(it, null, null) }
                onDone(n > 0)
            }
        } catch (e: SecurityException) {
            if (Build.VERSION.SDK_INT == 29 && e is RecoverableSecurityException) {
                pendingDelete = onDone
                pendingUris = uris
                deleteLauncher.launch(IntentSenderRequest.Builder(e.userAction.actionIntent.intentSender).build())
            } else {
                Toast.makeText(this, "Gagal menghapus: tidak ada izin.", Toast.LENGTH_LONG).show()
                onDone(false)
            }
        } catch (e: Exception) {
            Toast.makeText(this, "Gagal menghapus: ${e.message}", Toast.LENGTH_LONG).show()
            onDone(false)
        }
    }


    // ----- ubah nama / pindah folder / edit info -----
    private var pendingWrite: (() -> Unit)? = null

    private val writeLauncher = registerForActivityResult(
        ActivityResultContracts.StartIntentSenderForResult()
    ) { r ->
        val cb = pendingWrite
        pendingWrite = null
        if (r.resultCode == Activity.RESULT_OK) cb?.invoke()
    }

    /** Ubah kolom MediaStore satu file (nama, folder, judul...). Minta izin tulis ke sistem kalau perlu. */
    protected fun updateMedia(uri: Uri, values: ContentValues, onDone: (Boolean) -> Unit) =
        updateMediaBatch(listOf(uri), values, onDone)

    protected fun updateMediaBatch(uris: List<Uri>, values: ContentValues, onDone: (Boolean) -> Unit) {
        var asked = false
        fun doUpdate() {
            try {
                var ok = true
                for (u in uris) if (contentResolver.update(u, values, null, null) <= 0) ok = false
                if (!ok) Toast.makeText(this, "Gagal mengubah file.", Toast.LENGTH_LONG).show()
                onDone(ok)
            } catch (e: SecurityException) {
                if (Build.VERSION.SDK_INT == 29 && e is RecoverableSecurityException && !asked) {
                    asked = true
                    pendingWrite = { doUpdate() }
                    writeLauncher.launch(IntentSenderRequest.Builder(e.userAction.actionIntent.intentSender).build())
                } else {
                    Toast.makeText(this, "Gagal: tidak ada izin.", Toast.LENGTH_LONG).show()
                    onDone(false)
                }
            } catch (e: IllegalArgumentException) {
                Toast.makeText(this, "Folder tujuan tidak diizinkan untuk jenis file ini.", Toast.LENGTH_LONG).show()
                onDone(false)
            } catch (e: Exception) {
                Toast.makeText(this, "Gagal: ${e.message}", Toast.LENGTH_LONG).show()
                onDone(false)
            }
        }
        if (Build.VERSION.SDK_INT >= 30) {
            try {
                val pi = MediaStore.createWriteRequest(contentResolver, uris)
                pendingWrite = { doUpdate() }
                writeLauncher.launch(IntentSenderRequest.Builder(pi.intentSender).build())
            } catch (e: Exception) {
                Toast.makeText(this, "Gagal: ${e.message}", Toast.LENGTH_LONG).show()
                onDone(false)
            }
        } else {
            doUpdate()
        }
    }

    protected fun cleanName(s: String) = s.replace(Regex("[\\\\/:*?\"<>|]"), "").trim().trim('.')

    protected fun renameDialog(uri: Uri, base: String, ext: String, noun: String, onDone: () -> Unit) {
        Sheet.input(this, "Ganti nama $noun", "Nama file", base, "Simpan") { raw ->
            val n = cleanName(raw)
            if (n.isEmpty() || n == base) return@input
            val v = ContentValues()
            v.put(MediaStore.MediaColumns.DISPLAY_NAME, if (ext.isEmpty()) n else "$n.$ext")
            updateMedia(uri, v) { ok ->
                if (ok) {
                    Toast.makeText(this, "Nama diganti.", Toast.LENGTH_SHORT).show()
                    onDone()
                }
            }
        }
    }

    /** existing = folder relatif yang sudah ada, allowed = awalan folder yang boleh, newBase = induk folder baru. */
    protected fun moveDialog(
        uri: Uri, currentRel: String, existing: List<String>,
        allowed: List<String>, newBase: String, onDone: () -> Unit
    ) = moveMany(listOf(uri), currentRel, existing, allowed, newBase, "Pindahkan ke", onDone)

    protected fun moveMany(
        uris: List<Uri>, currentRel: String, existing: List<String>,
        allowed: List<String>, newBase: String, title: String, onDone: () -> Unit
    ) {
        if (Build.VERSION.SDK_INT < 29) {
            Toast.makeText(this, "Pindah folder butuh Android 10 ke atas.", Toast.LENGTH_LONG).show()
            return
        }
        fun moveTo(dir: String) {
            val v = ContentValues()
            v.put(MediaStore.MediaColumns.RELATIVE_PATH, dir)
            updateMediaBatch(uris, v) { ok ->
                if (ok) {
                    Toast.makeText(this, "Dipindahkan ke $dir", Toast.LENGTH_SHORT).show()
                    onDone()
                }
            }
        }
        val dirs = (existing + newBase).filter { d -> allowed.any { d.startsWith(it) } }.distinct().sorted()
        val items = ArrayList<Sheet.Item?>()
        for (d in dirs) {
            val name = d.trimEnd('/').substringAfterLast('/')
            items.add(
                Sheet.Item(name, R.drawable.ic_folder, false, if (d == currentRel) "folder sekarang" else d) {
                    if (d != currentRel) moveTo(d)
                }
            )
        }
        items.add(null)
        items.add(Sheet.Item("Folder baru", R.drawable.ic_add) {
            Sheet.input(this, "Folder baru", "Nama folder", "", "Pindahkan") { raw ->
                val n = cleanName(raw)
                if (n.isNotEmpty()) moveTo("$newBase$n/")
            }
        })
        Sheet.menu(this, title, null, items)
    }


    // ----- pilih banyak item -----
    protected val picked = LinkedHashSet<Long>()
    private var selBar: LinearLayout? = null
    private var selText: TextView? = null
    private var selBack: OnBackPressedCallback? = null
    private var selRefresh: () -> Unit = {}
    private var selAll: () -> List<Long> = { emptyList() }

    protected val selecting: Boolean get() = selBar != null

    protected fun startSelect(
        first: Long, all: () -> List<Long>, refresh: () -> Unit,
        onMove: (List<Long>) -> Unit, onDelete: (List<Long>) -> Unit
    ) {
        if (selBar != null) exitSelect()
        picked.clear()
        picked.add(first)
        selAll = all
        selRefresh = refresh
        val bar = LinearLayout(this)
        bar.orientation = LinearLayout.HORIZONTAL
        bar.gravity = Gravity.CENTER_VERTICAL
        bar.setBackgroundResource(R.drawable.bg_popup)
        bar.setPadding(Ui.dp(this, 6), Ui.dp(this, 4), Ui.dp(this, 6), Ui.dp(this, 4))
        fun tv(label: String, color: Int, weight: Float, click: () -> Unit): TextView {
            val t = TextView(this)
            t.text = label
            t.textSize = 13f
            t.setTextColor(color)
            t.gravity = Gravity.CENTER
            t.setPadding(Ui.dp(this, 8), Ui.dp(this, 12), Ui.dp(this, 8), Ui.dp(this, 12))
            t.layoutParams = LinearLayout.LayoutParams(
                if (weight > 0f) 0 else ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT, weight
            )
            t.setOnClickListener { click() }
            return t
        }
        val soft = android.graphics.Color.parseColor("#C7C7CC")
        bar.addView(tv("Batal", soft, 0f) { exitSelect() })
        val count = tv("1 dipilih", android.graphics.Color.WHITE, 1f) {}
        selText = count
        bar.addView(count)
        bar.addView(tv("Semua", soft, 0f) {
            picked.clear()
            picked.addAll(selAll())
            updateSelBar()
            selRefresh()
        })
        bar.addView(tv("Pindahkan", android.graphics.Color.WHITE, 0f) { onMove(picked.toList()) })
        bar.addView(tv("Hapus", android.graphics.Color.parseColor("#FF6B6B"), 0f) { onDelete(picked.toList()) })
        val lp = FrameLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.BOTTOM
        )
        lp.setMargins(Ui.dp(this, 12), 0, Ui.dp(this, 12), Ui.dp(this, 16))
        findViewById<ViewGroup>(android.R.id.content).addView(bar, lp)
        selBar = bar
        val cb = object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() = exitSelect()
        }
        selBack = cb
        onBackPressedDispatcher.addCallback(this, cb)
        selRefresh()
    }

    private fun updateSelBar() {
        selText?.text = "${picked.size} dipilih"
    }

    protected fun toggleSelect(id: Long) {
        if (!picked.remove(id)) picked.add(id)
        if (picked.isEmpty()) {
            exitSelect()
        } else {
            updateSelBar()
            selRefresh()
        }
    }

    protected fun exitSelect() {
        selBar?.let { (it.parent as? ViewGroup)?.removeView(it) }
        selBar = null
        selText = null
        selBack?.remove()
        selBack = null
        picked.clear()
        selRefresh()
    }

    private fun need(): List<String> =
        if (Build.VERSION.SDK_INT >= 33) {
            if (kind == 1) listOf(Manifest.permission.READ_MEDIA_AUDIO)
            else listOf(Manifest.permission.READ_MEDIA_VIDEO)
        } else listOf(Manifest.permission.READ_EXTERNAL_STORAGE)

    private fun hasMedia() = need().all {
        checkSelfPermission(it) == PackageManager.PERMISSION_GRANTED
    }

    protected fun ensureMedia() {
        if (hasMedia()) {
            onMediaReady()
        } else {
            val p = ArrayList(need())
            if (kind == 1 && Build.VERSION.SDK_INT >= 33) p.add(Manifest.permission.POST_NOTIFICATIONS)
            permLauncher.launch(p.toTypedArray())
        }
    }
}
