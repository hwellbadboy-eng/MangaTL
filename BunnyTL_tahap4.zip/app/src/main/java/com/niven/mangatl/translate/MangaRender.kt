package com.niven.mangatl

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.Rect
import android.graphics.RectF
import android.graphics.Typeface
import android.text.Layout
import android.text.StaticLayout
import android.text.TextPaint
import java.io.File
import java.util.Locale

// Manga Translator: menutup teks asli dengan warna latar dan menulis terjemahan (termasuk teks miring) ke dalam balon.
// Fungsi ekstensi dari MangaEngine; keadaan dan API publik tetap di MangaEngine.kt.

internal class MangaPlan(val box: Rect, val erase: Rect, val bg: Int)

internal fun MangaEngine.clampRect(r: Rect, bmp: Bitmap): Rect {
    val c = Rect(r)
    if (!c.intersect(0, 0, bmp.width, bmp.height)) return Rect(0, 0, 1, 1)
    return c
}

/**
 * Hapus hanya goresan teks (piksel yang beda dari warna latar) di [r], lalu isi dengan warna latar.
 * Kembalikan false kalau areanya terlalu "penuh" (bukan teks di atas latar rata); pemanggil lalu menutup satu kotak.
 */
internal fun MangaEngine.eraseInk(bmp: Bitmap, r: Rect, bg: Int): Boolean {
    val w = r.width()
    val h = r.height()
    if (w < 2 || h < 2) return false
    val px = IntArray(w * h)
    bmp.getPixels(px, 0, w, r.left, r.top, w, h)
    val ink = BooleanArray(w * h)
    var cnt = 0L
    val dist = IntArray(w * h)
    for (i in px.indices) { dist[i] = colorDist(px[i], bg); if (dist[i] > 90) { ink[i] = true; cnt++ } }
    if (cnt > w.toLong() * h / 2) return false
    // Tepi huruf yang pudar (abu-abu tipis hasil anti-alias) juga tinta, tapi hanya kalau dekat tinta kuat.
    // Dengan begitu tidak ada garis hantu, sedangkan titik screentone yang jauh dari huruf tidak ikut terhapus.
    val strongNear = dilate(ink, w, h, 7)
    for (i in px.indices) if (!ink[i] && strongNear[i] && dist[i] > 18) { ink[i] = true; cnt++ }
    if (cnt > w.toLong() * h * 3 / 4) return false
    val rad = (minOf(w, h) * 0.04f).toInt().coerceIn(2, 5)
    val a = BooleanArray(w * h)
    val pre = IntArray(maxOf(w, h) + 1)
    for (y in 0 until h) {
        for (x in 0 until w) pre[x + 1] = pre[x] + if (ink[y * w + x]) 1 else 0
        for (x in 0 until w) a[y * w + x] = pre[minOf(w, x + rad + 1)] - pre[maxOf(0, x - rad)] > 0
    }
    val e = BooleanArray(w * h)
    for (x in 0 until w) {
        for (y in 0 until h) pre[y + 1] = pre[y] + if (a[y * w + x]) 1 else 0
        for (y in 0 until h) if (pre[minOf(h, y + rad + 1)] - pre[maxOf(0, y - rad)] > 0) e[y * w + x] = true
    }
    // Isi bekas teks dari piksel terdekat kiri dan kanan di baris yang sama (latar gradasi tetap mulus).
    // Kalau tidak ada tetangga atau warnanya jauh dari latar, pakai warna latar rata seperti sebelumnya.
    val left = IntArray(w)
    val right = IntArray(w)
    val orig = px.copyOf()
    for (y in 0 until h) {
        var last = -1
        for (x in 0 until w) { if (!e[y * w + x]) last = x; left[x] = last }
        last = -1
        for (x in w - 1 downTo 0) { if (!e[y * w + x]) last = x; right[x] = last }
        for (x in 0 until w) {
            if (!e[y * w + x]) continue
            val l = left[x]
            val rr = right[x]
            var col = bg
            if (l >= 0 && rr >= 0) {
                val c1 = orig[y * w + l]
                val c2 = orig[y * w + rr]
                val t = (x - l).toFloat() / maxOf(1, rr - l)
                val cr = (Color.red(c1) * (1 - t) + Color.red(c2) * t).toInt()
                val cg = (Color.green(c1) * (1 - t) + Color.green(c2) * t).toInt()
                val cb = (Color.blue(c1) * (1 - t) + Color.blue(c2) * t).toInt()
                val mix = Color.rgb(cr, cg, cb)
                if (colorDist(mix, bg) <= 120) col = mix
            }
            px[y * w + x] = col
        }
    }
    bmp.setPixels(px, 0, w, r.left, r.top, w, h)
    return true
}

/** Batas ukuran huruf terjemahan untuk satu blok: tidak lebih dari 1,35x huruf asli DAN tidak jauh di atas median halaman. */
internal fun MangaEngine.sizeCap(b: Block): Float {
    if (b.lineH <= 0) return 64f
    val own = b.lineH * SIZE_CAP
    val cap = if (pageRefH > 0f) minOf(own, pageRefH * 1.6f) else own
    return cap.coerceIn(10f, 64f)
}

internal fun MangaEngine.render(bmp: Bitmap, blocks: List<Block>, trIn: List<String>) {
    val tr = if (capsOn) trIn.map { it.uppercase(java.util.Locale("id", "ID")) } else trIn
    val n = minOf(blocks.size, tr.size)
    if (n == 0) return
    val hs = (0 until n).map { blocks[it].lineH }.filter { it > 0 }.sorted()
    pageRefH = if (hs.isEmpty()) 0f else hs[hs.size / 2].toFloat()

    // Ambil warna latar SEBELUM ada yang digambar, supaya blok tetangga tidak ikut mempengaruhi.
    val plans = ArrayList<MangaPlan>()
    for (i in 0 until n) {
        val r = blocks[i].rect
        val ex = maxOf(4, (r.width() * 0.05f).toInt())
        val ey = maxOf(4, (r.height() * 0.05f).toInt())
        val base = clampRect(Rect(r.left - ex, r.top - ey, r.right + ex, r.bottom + ey), bmp)
        val bg = TextUtil.sampleBg(bmp, base) or (0xFF shl 24)
        var box = base
        // Teks vertikal (kolom sempit): lebarkan kotak terjemahan kalau latar sekitarnya sama.
        if (base.height() > base.width() * 2) {
            val extra = (base.width() * 0.6f).toInt()
            val wide = clampRect(Rect(base.left - extra, base.top, base.right + extra, base.bottom), bmp)
            val hitsOther = (0 until n).any { j -> j != i && Rect.intersects(wide, blocks[j].rect) }
            if (!hitsOther && colorDist(bg, TextUtil.sampleBg(bmp, wide)) < 60) box = wide
        }
        plans.add(MangaPlan(box, base, bg))
    }

    val c = Canvas(bmp)
    val fill = Paint(Paint.ANTI_ALIAS_FLAG)
    fill.style = Paint.Style.FILL
    val tp = TextPaint(Paint.ANTI_ALIAS_FLAG)
    tp.typeface = dialogFace ?: Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
    if (italicOn) tp.textSkewX = -0.22f

    for (i in 0 until n) {
        val p = plans[i]
        val box = p.box
        if (box.width() < 8 || box.height() < 8 || blocks[i].pts.isNotEmpty()) continue
        // Hapus semua teks asli dulu; terjemahan digambar sesudahnya supaya tidak tertimpa blok tetangga.
        if (!eraseInk(bmp, p.erase, p.bg)) {
            fill.color = p.bg
            val rad = minOf(box.width(), box.height()) * 0.12f
            c.drawRoundRect(RectF(box), rad, rad, fill)
        }
    }
    for (i in 0 until n) {
        val p = plans[i]
        val box = p.box
        if (box.width() < 8 || box.height() < 8 || blocks[i].pts.isNotEmpty()) continue
        val capsText = tr[i].trim()
        if (capsText.isEmpty()) continue
        // Huruf kapital lebih lebar. Kalau balon sempit dan hasilnya jadi kecil, pakai huruf biasa.
        var text = capsText
        if (caseMode == 2) {
            val plain = trIn[i].trim()
            val okCaps = typesetInBalloon(bmp, c, tp, blocks, i, capsText, p.bg, n, draw = false)
            val sCaps = typesetSize
            if (!okCaps || sCaps < 14f) {
                val okPlain = typesetInBalloon(bmp, c, tp, blocks, i, plain, p.bg, n, draw = false)
                val sPlain = typesetSize
                if (okPlain && (!okCaps || sCaps < sPlain * 0.85f)) text = plain
                else if (!okCaps) text = plain
            }
        }
        if (typesetInBalloon(bmp, c, tp, blocks, i, text, p.bg, n)) continue
        val pad = maxOf(2, (minOf(box.width(), box.height()) * 0.06f).toInt())
        val w = box.width() - 2 * pad
        val h = box.height() - 2 * pad
        if (w < 6 || h < 6) continue

        tp.color = if (TextUtil.luminance(p.bg) > 128) Color.parseColor("#111111") else Color.WHITE
        var size = minOf(h * 0.8f, 90f).coerceAtLeast(9f)
        if (blocks[i].lineH > 0) size = minOf(size, sizeCap(blocks[i])).coerceAtLeast(9f)
        var layout = layoutOf(text, tp, size, w)
        while (layout.height > h && size > 9f) {
            size = maxOf(9f, size * 0.93f)
            layout = layoutOf(text, tp, size, w)
        }
        // Kata tidak boleh terpotong: kecilkan lagi (sampai batas bawah) kalau kata terpanjang tidak muat.
        val words = text.split(Regex("\\s+"))
        while (words.any { tp.measureText(it) > w } && size > 6f) {
            size = maxOf(6f, size * 0.93f)
            layout = layoutOf(text, tp, size, w)
        }
        c.save()
        c.translate((box.left + pad).toFloat(), box.top + pad + (h - layout.height) / 2f)
        layout.draw(c)
        c.restore()
    }
    renderTilted(bmp, c, tp, blocks, tr, n)
}

internal fun MangaEngine.typesetInBalloon(
    bmp: Bitmap, c: Canvas, tp: TextPaint, blocks: List<Block>, i: Int, text: String, bg: Int, n: Int,
    draw: Boolean = true
): Boolean {
    val r = blocks[i].rect
    val m = maxOf(r.width(), r.height()) + 40
    val win = clampRect(Rect(r.left - m, r.top - m, r.right + m, r.bottom + m), bmp)
    var yMin = win.top
    var yMax = win.bottom
    // balon yang dipakai bersama blok lain di atas/bawahnya: bagi dua di tengah celah
    for (j in 0 until n) {
        if (j == i) continue
        val o = blocks[j].rect
        val ox = minOf(o.right, r.right) - maxOf(o.left, r.left)
        if (ox > 0.3f * minOf(o.width(), r.width())) {
            if (o.centerY() < r.centerY()) yMin = maxOf(yMin, (o.bottom + r.top) / 2)
            else yMax = minOf(yMax, (r.bottom + o.top) / 2)
        }
    }
    yMin = minOf(yMin, r.top)
    yMax = maxOf(yMax, r.bottom)
    // Tetangga yang ada di sekitar jendela ini. Tiap piksel hanya boleh dipakai blok yang kotak
    // aslinya PALING DEKAT (Voronoi), jadi teks tidak pernah meluber ke area blok lain,
    // baik ke atas/bawah maupun ke samping (kotak narasi yang berdempetan, balon bersebelahan).
    val near = ArrayList<Rect>()
    for (j in 0 until n) {
        if (j == i) continue
        val o = blocks[j].rect
        if (o.right >= win.left && o.left <= win.right && o.bottom >= win.top && o.top <= win.bottom) near.add(o)
    }
    fun d2(o: Rect, x: Int, y: Int): Long {
        val dx = maxOf(maxOf(o.left - x, x - o.right), 0).toLong()
        val dy = maxOf(maxOf(o.top - y, y - o.bottom), 0).toLong()
        return dx * dx + dy * dy
    }
    val ww = win.width()
    val wh = win.height()
    if (ww < 8 || wh < 8) return false
    val px = IntArray(ww * wh)
    bmp.getPixels(px, 0, ww, win.left, win.top, ww, wh)
    val sx = r.centerX() - win.left
    val sy = r.centerY() - win.top
    if (sx !in 0 until ww || sy !in 0 until wh) return false
    if (colorDist(px[sy * ww + sx], bg) > 60) return false
    val y0 = maxOf(0, yMin - win.top)
    val y1 = minOf(wh - 1, yMax - win.top)
    // Batas keras area balon: tidak lebih dari ~1,9x kotak teks asli, jadi isian tidak bisa bocor lewat
    // celah garis balon / ekor balon ke area lain.
    val limX = maxOf(10, (r.width() * 0.45f).toInt())
    val limY = maxOf(10, (r.height() * 0.45f).toInt())
    val lx0 = maxOf(0, r.left - limX - win.left)
    val lx1 = minOf(ww - 1, r.right + limX - win.left)
    val ly0 = maxOf(y0, r.top - limY - win.top)
    val ly1 = minOf(y1, r.bottom + limY - win.top)
    fun owned(k: Int): Boolean {
        val kx = k % ww
        val ky = k / ww
        if (kx < lx0 || kx > lx1 || ky < ly0 || ky > ly1) return false
        if (near.isEmpty()) return true
        val x = win.left + k % ww
        val y = win.top + k / ww
        val mine = d2(r, x, y)
        for (o in near) if (d2(o, x, y) < mine) return false
        return true
    }
    val inReg = BooleanArray(ww * wh)
    val stack = IntArray(ww * wh)
    var sp = 0
    stack[sp++] = sy * ww + sx
    inReg[sy * ww + sx] = true
    while (sp > 0) {
        val q = stack[--sp]
        val x = q % ww
        val y = q / ww
        if (x > 0) { val k = q - 1; if (!inReg[k] && colorDist(px[k], bg) <= 60 && owned(k)) { inReg[k] = true; stack[sp++] = k } }
        if (x < ww - 1) { val k = q + 1; if (!inReg[k] && colorDist(px[k], bg) <= 60 && owned(k)) { inReg[k] = true; stack[sp++] = k } }
        if (y > y0) { val k = q - ww; if (!inReg[k] && colorDist(px[k], bg) <= 60 && owned(k)) { inReg[k] = true; stack[sp++] = k } }
        if (y < y1) { val k = q + ww; if (!inReg[k] && colorDist(px[k], bg) <= 60 && owned(k)) { inReg[k] = true; stack[sp++] = k } }
    }
    val words = text.split(Regex("\\s+")).filter { it.isNotEmpty() }
    if (words.isEmpty()) return true
    val maxW = r.width() * 1.5f + 20f
    val ext = FloatArray(2) // lebar, titik tengah pada baris y (koordinat window)
    fun extentAt(y: Int): Boolean {
        if (y < y0 || y > y1) return false
        val base = y * ww
        if (!inReg[base + sx]) return false
        var l = sx
        while (l > 0 && inReg[base + l - 1]) l--
        var rr = sx
        while (rr < ww - 1 && inReg[base + rr + 1]) rr++
        ext[0] = minOf((rr - l + 1) * 0.84f, maxW)
        ext[1] = (l + rr) / 2f
        return true
    }
    tp.color = if (TextUtil.luminance(bg) > 128) Color.parseColor("#111111") else Color.WHITE
    val capSize = sizeCap(blocks[i]).toInt()
    for (sizeI in capSize downTo 9) {
        val size = sizeI.toFloat()
        tp.textSize = size
        val lh = size * 1.18f
        var wordTooLong = false
        for (nl in 1..14) {
            val totalH = nl * lh
            val top = sy - totalH / 2f
            if (top < y0 || top + totalH > y1) break
            val lines = ArrayList<String>()
            val centers = ArrayList<Float>()
            var wi = 0
            var ok = true
            for (k in 0 until nl) {
                val yTop = top + k * lh
                var wMin = Float.MAX_VALUE
                var ctr = 0f
                for (f in 0..4) {
                    val yy = when (f) { 0 -> yTop + 2f; 1 -> yTop + lh * 0.25f; 2 -> yTop + lh * 0.5f; 3 -> yTop + lh * 0.75f; else -> yTop + lh - 2f }
                    if (!extentAt(yy.toInt())) { ok = false; break }
                    wMin = minOf(wMin, ext[0])
                    if (f == 2) ctr = ext[1]
                }
                if (!ok) break
                var line = ""
                while (wi < words.size) {
                    val cand = if (line.isEmpty()) words[wi] else line + " " + words[wi]
                    if (tp.measureText(cand) <= wMin) { line = cand; wi++ }
                    else if (line.isEmpty()) { wordTooLong = true; break }
                    else break
                }
                if (line.isEmpty()) { ok = false; break }
                lines.add(line)
                centers.add(ctr)
            }
            if (wordTooLong) break
            if (!ok || wi < words.size) continue
            // Cek akhir: ujung kiri/kanan tiap baris (plus condong huruf miring) harus tepat di dalam area balon.
            var inside = true
            val slant = if (italicOn) size * 0.2f else 0f
            for (k in lines.indices) {
                val wLine = tp.measureText(lines[k])
                val ix0 = (centers[k] - wLine / 2f).toInt()
                val ix1 = (centers[k] + wLine / 2f + slant).toInt()
                val yTop = top + k * lh
                for (yy in floatArrayOf(yTop + 2f, yTop + lh * 0.5f, yTop + lh - 2f)) {
                    val iy = yy.toInt()
                    if (iy < y0 || iy > y1 || ix0 < 1 || ix1 > ww - 2 || !inReg[iy * ww + ix0] || !inReg[iy * ww + ix1]) { inside = false; break }
                }
                if (!inside) break
            }
            if (!inside) continue
            // muat: gambar (teks selalu dijaga tetap di dalam gambar, mis. balon di tepi halaman)
            typesetSize = size
            if (draw) {
                for (k in lines.indices) {
                    val wLine = tp.measureText(lines[k])
                    val x = (win.left + centers[k] - wLine / 2f).coerceIn(0f, maxOf(0f, bmp.width - wLine))
                    c.drawText(lines[k], x, win.top + top + k * lh + size * 0.95f, tp)
                }
            }
            return true
        }
    }
    return false
}

internal fun MangaEngine.dilate(src: BooleanArray, w: Int, h: Int, rad: Int): BooleanArray {
    val a = BooleanArray(w * h)
    val pre = IntArray(maxOf(w, h) + 1)
    for (y in 0 until h) {
        for (x in 0 until w) pre[x + 1] = pre[x] + if (src[y * w + x]) 1 else 0
        for (x in 0 until w) a[y * w + x] = pre[minOf(w, x + rad + 1)] - pre[maxOf(0, x - rad)] > 0
    }
    val out = BooleanArray(w * h)
    for (x in 0 until w) {
        for (y in 0 until h) pre[y + 1] = pre[y] + if (a[y * w + x]) 1 else 0
        for (y in 0 until h) out[y * w + x] = pre[minOf(h, y + rad + 1)] - pre[maxOf(0, y - rad)] > 0
    }
    return out
}

/**
 * Teks miring (layar HP/tablet): hapus goresan teks hanya di dalam poligon baris (ikut kemiringan),
 * isi dari piksel sekitar terdekat (4 arah), lalu tulis terjemahan dengan sudut yang sama.
 */
internal fun MangaEngine.renderTilted(bmp: Bitmap, c: Canvas, tp: TextPaint, blocks: List<Block>, tr: List<String>, n: Int) {
    for (i in 0 until n) {
        val b = blocks[i]
        if (b.pts.size < 4) continue
        var minX = Int.MAX_VALUE
        var minY = Int.MAX_VALUE
        var maxX = Int.MIN_VALUE
        var maxY = Int.MIN_VALUE
        for (p in b.pts) { minX = minOf(minX, p.x); minY = minOf(minY, p.y); maxX = maxOf(maxX, p.x); maxY = maxOf(maxY, p.y) }
        val reg = clampRect(Rect(minX - 8, minY - 8, maxX + 8, maxY + 8), bmp)
        val w = reg.width()
        val h = reg.height()
        if (w < 8 || h < 8) continue
        val px = IntArray(w * h)
        bmp.getPixels(px, 0, w, reg.left, reg.top, w, h)

        // mask = poligon tiap baris (sedikit dilebarkan)
        val mbmp = Bitmap.createBitmap(w, h, Bitmap.Config.ALPHA_8)
        val mc = Canvas(mbmp)
        val mp = Paint(Paint.ANTI_ALIAS_FLAG)
        mp.color = Color.WHITE
        mp.style = Paint.Style.FILL_AND_STROKE
        mp.strokeWidth = 8f
        var k = 0
        while (k + 3 < b.pts.size) {
            val path = Path()
            path.moveTo((b.pts[k].x - reg.left).toFloat(), (b.pts[k].y - reg.top).toFloat())
            for (q in 1..3) path.lineTo((b.pts[k + q].x - reg.left).toFloat(), (b.pts[k + q].y - reg.top).toFloat())
            path.close()
            mc.drawPath(path, mp)
            k += 4
        }
        val mpx = IntArray(w * h)
        mbmp.getPixels(mpx, 0, w, 0, 0, w, h)
        mbmp.recycle()
        val inMask = BooleanArray(w * h) { (mpx[it] ushr 24) > 0 }

        // warna latar = median piksel di dalam mask (goresan teks adalah minoritas)
        val rs = ArrayList<Int>()
        val gs = ArrayList<Int>()
        val bs = ArrayList<Int>()
        for (q in px.indices) if (inMask[q]) { rs.add(Color.red(px[q])); gs.add(Color.green(px[q])); bs.add(Color.blue(px[q])) }
        if (rs.size < 20) continue
        rs.sort(); gs.sort(); bs.sort()
        val bg = Color.rgb(rs[rs.size / 2], gs[gs.size / 2], bs[bs.size / 2])
        val ink = BooleanArray(w * h)
        for (q in px.indices) if (inMask[q] && colorDist(px[q], bg) > 90) ink[q] = true
        val dil = dilate(ink, w, h, 3)

        val out = px.copyOf()
        for (y in 0 until h) for (x in 0 until w) {
            val q = y * w + x
            if (!dil[q]) continue
            var sr = 0f
            var sg = 0f
            var sb = 0f
            var sw = 0f
            for (d in 0 until 4) {
                var st = 1
                while (st <= 24) {
                    val xx = x + (if (d == 0) st else if (d == 1) -st else 0)
                    val yy = y + (if (d == 2) st else if (d == 3) -st else 0)
                    if (xx < 0 || yy < 0 || xx >= w || yy >= h) break
                    val qq = yy * w + xx
                    if (!dil[qq]) {
                        val wt = 1f / st
                        sr += Color.red(px[qq]) * wt; sg += Color.green(px[qq]) * wt; sb += Color.blue(px[qq]) * wt; sw += wt
                        break
                    }
                    st++
                }
            }
            out[q] = if (sw > 0f) Color.rgb((sr / sw).toInt(), (sg / sw).toInt(), (sb / sw).toInt()) else bg
        }
        bmp.setPixels(out, 0, w, reg.left, reg.top, w, h)

        val text = tr[i].trim()
        if (text.isEmpty()) continue
        // ukuran teks dalam bingkai yang sudah "ditegakkan" (diputar balik sebesar sudutnya)
        val cx = b.pts.sumOf { it.x }.toFloat() / b.pts.size
        val cy = b.pts.sumOf { it.y }.toFloat() / b.pts.size
        val th = Math.toRadians(b.angle.toDouble())
        val cs = Math.cos(th).toFloat()
        val sn = Math.sin(th).toFloat()
        var rminX = Float.MAX_VALUE
        var rmaxX = -Float.MAX_VALUE
        var rminY = Float.MAX_VALUE
        var rmaxY = -Float.MAX_VALUE
        for (p in b.pts) {
            val dx = p.x - cx
            val dy = p.y - cy
            val rx = dx * cs + dy * sn
            val ry = -dx * sn + dy * cs
            rminX = minOf(rminX, rx); rmaxX = maxOf(rmaxX, rx); rminY = minOf(rminY, ry); rmaxY = maxOf(rmaxY, ry)
        }
        val bw = (rmaxX - rminX).toInt() + 8
        val bh = (rmaxY - rminY).toInt() + 8
        if (bw < 6 || bh < 6) continue
        tp.color = if (TextUtil.luminance(bg) > 128) Color.parseColor("#111111") else Color.WHITE
        var size = minOf(bh * 0.8f, 90f).coerceAtLeast(9f)
        if (b.lineH > 0) size = minOf(size, maxOf(10f, b.lineH * SIZE_CAP))
        var layout = layoutOf(text, tp, size, bw)
        while (layout.height > bh && size > 9f) {
            size = maxOf(9f, size * 0.93f)
            layout = layoutOf(text, tp, size, bw)
        }
        val words = text.split(Regex("\\s+"))
        while (words.any { tp.measureText(it) > bw } && size > 8f) {
            size = maxOf(8f, size * 0.93f)
            layout = layoutOf(text, tp, size, bw)
        }
        c.save()
        c.rotate(b.angle, cx, cy)
        c.translate(cx - bw / 2f, cy - layout.height / 2f)
        layout.draw(c)
        c.restore()
    }
}

internal fun MangaEngine.layoutOf(text: String, tp: TextPaint, size: Float, width: Int): StaticLayout {
    tp.textSize = size
    return StaticLayout.Builder.obtain(text, 0, text.length, tp, width)
        .setAlignment(Layout.Alignment.ALIGN_CENTER)
        .setIncludePad(false)
        .build()
}

/** Gambar halaman asli dengan kotak merah + nomor untuk tiap blok yang dibaca (bahan debug). */
internal fun MangaEngine.saveDebugImage(bmp: Bitmap, blocks: List<Block>, target: File) {
    val copy = bmp.copy(Bitmap.Config.ARGB_8888, true)
    try {
        val cv = Canvas(copy)
        val pnt = Paint()
        pnt.style = Paint.Style.STROKE
        pnt.strokeWidth = 3f
        pnt.color = Color.RED
        val tx = Paint(Paint.ANTI_ALIAS_FLAG)
        tx.color = Color.BLUE
        tx.textSize = 30f
        blocks.forEachIndexed { i, b ->
            cv.drawRect(RectF(b.rect), pnt)
            cv.drawText("$i", b.rect.left + 3f, b.rect.top + 28f, tx)
        }
        target.outputStream().use { copy.compress(Bitmap.CompressFormat.JPEG, 75, it) }
    } finally {
        copy.recycle()
    }
}
