package com.niven.mangatl

import android.os.Bundle
import android.speech.SpeechRecognizer
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import android.os.Handler
import android.os.Looper
import android.view.ViewGroup
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class ChatActivity : AppCompatActivity() {

    companion object {
        // Riwayat tetap ada selama app hidup, walau layar chat ditutup lalu dibuka lagi.
        private val store = ArrayList<Msg>()
    }

    internal lateinit var web: ChatWebView
    internal var webReady = false
    internal var lastState = ""
    internal var hitRects = FloatArray(0)    // daerah milik tampilan chat: sentuhan di sini bukan untuk avatar
    internal var sending = false
    internal var streaming = false           // jawaban sudah mulai muncul
    internal var recognizer: SpeechRecognizer? = null
    internal var listening = false
    internal var micStatus: String? = null
    internal var micInfoShown = false
    internal var whisperFailed = false // kalau Whisper error, sisa sesi pakai mic bawaan
    internal var live = false
    internal var turn = 0
    internal val handler = Handler(Looper.getMainLooper())

    // Layar penuh + latar chat pilihan pengguna (lihat ChatBg.kt)
    internal var insetTop = 0                // tinggi bar status (px)
    internal var insetBottom = 0             // tinggi bar navigasi (px), 0 saat keyboard muncul
    internal var bgPlayer: androidx.media3.exoplayer.ExoPlayer? = null
    internal var bgGen = 0                   // penanda pemuatan latar; yang kedaluwarsa dibuang
    internal var bgMw = 0                    // ukuran asli media latar
    internal var bgMh = 0
    internal var bgFixW = 0
    internal var bgFixH = 0
    internal var bgS = 1f                    // zoom 1..4
    internal var bgFx = 0f                   // geser (pecahan lebar / tinggi layar)
    internal var bgFy = 0f
    internal var bgDark = 18                 // 0..90 persen gelap
    internal var bgBlur = 0                  // 0..100 buram
    internal var bgEditing = false
    internal val pickBg = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) importBg(uri)
    }
    internal val pickImage = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) onImagePicked(uri)
    }
    internal val pickText = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) onTextPicked(uri)
    }
    internal val pickZip = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) onZipPicked(uri)
    }
    internal val saveText = registerForActivityResult(ActivityResultContracts.CreateDocument("text/plain")) { uri ->
        if (uri != null) onSaveTarget(uri)
    }

    // Avatar Live2D (tubuh AI): gerak mengikuti keadaan chat. Model dipilih di menu avatar (chat.html).
    internal var avatar: AvatarView? = null
    internal lateinit var cfg: ModelCfg
    internal lateinit var rootFrame: AvatarDragLayout
    internal lateinit var bgHost: ViewGroup
    internal var avatarWanted = true
    internal var bubblesOn = true            // false = bubble chat disembunyikan (layar bersih, avatar saja)
    internal var keyboardUp = false
    internal var avatarErrorShown = false
    internal var lastFullRootH = 0   // tinggi layar TANPA keyboard (nilai terbesar yang pernah terlihat)
    internal var uiActive = false
    internal fun prefs() = getSharedPreferences("mangatl", MODE_PRIVATE)
    private val avatarTick = object : Runnable {
        override fun run() {
            val k = avatar
            if (k != null && k.isShown) {
                k.anim.state = when {
                    Voice.playing -> AvatarState.SPEAKING
                    sending || Voice.speaking -> AvatarState.THINKING
                    listening -> AvatarState.LISTENING
                    else -> AvatarState.IDLE
                }
            }
            pushState()
            handler.postDelayed(this, 120)
        }
    }

    internal val micPerm = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { ok ->
        if (ok) startListening()
        else {
            if (live) setLive(false)
            Toast.makeText(this, "Izin mikrofon ditolak.", Toast.LENGTH_SHORT).show()
        }
    }

    internal var modelsCache: List<Pair<String, String>>? = null
    internal val models: List<Pair<String, String>>
        get() = modelsCache ?: ModelCfg.list(this).also { modelsCache = it }

    /** Tombol Kembali HP menutup menu / panel prompt dulu. */
    internal val backCallback = object : OnBackPressedCallback(false) {
        override fun handleOnBackPressed() {
            if (bgEditing) endBgEdit(true) else js("back()")
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_chat)
        onBackPressedDispatcher.addCallback(this, backCallback)
        setupWeb()
        setupAvatar()
        setupEdgeToEdge()
        setupBgEdit()
        if (Voice.autoSpeak(this)) Voice.preload(this)
        if (Ear.available(this)) Ear.preload(this)
    }

    /** Halaman chat selesai dimuat. */
    internal fun onWebReady() {
        webReady = true
        lastState = ""
        pushInsets()
        pushState()
        sendHistory(store)
    }

    internal fun messageById(id: Int): Msg? = store.firstOrNull { it.id == id }

    internal fun submit(text: String) {
        val t = text.trim()
        if (sending || t.isEmpty()) return
        val before = store.size
        send(t)
        if (store.size > before) setInput("")   // kalau gagal dikirim, teks tetap di kolom
    }

    internal fun stopReply() {
        if (!sending) return
        if (live) setLive(false)
        Voice.stop()
        Gemma.chatCancel()
    }

    internal fun toggleVoice() {
        val on = !Voice.autoSpeak(this)
        if (on && Voice.findVoice(this) == null) {
            Toast.makeText(
                this,
                "Model suara belum ada. Salin folder model Supertonic ke:\n${getExternalFilesDir(null)}",
                Toast.LENGTH_LONG
            ).show()
            return
        }
        Voice.setAutoSpeak(this, on)
        if (!on) Voice.stop()
        pushState()
    }

    internal fun explainPage() {
        if (sending) {
            Toast.makeText(this, "Tunggu jawaban selesai dulu.", Toast.LENGTH_SHORT).show()
        } else if (Gemma.lastPage.isEmpty()) {
            Toast.makeText(this, "Terjemahkan satu halaman dulu.", Toast.LENGTH_SHORT).show()
        } else {
            send(
                "Jelaskan halaman manga yang terakhir tadi: emosi dan nada tiap karakter, " +
                    "idiom/slang/makna tersembunyi yang tidak boleh diterjemahkan harfiah, " +
                    "dan kasih alternatif terjemahan yang lebih natural untuk baris yang menurutmu kurang pas."
            )
        }
    }

    internal fun clearChat() {
        if (sending) {
            Toast.makeText(this, "Tunggu jawaban selesai dulu.", Toast.LENGTH_SHORT).show()
            return
        }
        store.clear()
        js("clear()")
    }

    internal fun loadCfg(id: String?): ModelCfg =
        try {
            ModelCfg.load(this, id ?: "jian")
        } catch (_: Throwable) {
            ModelCfg.load(this, "jian")
        }

    // ------------------------------------------------------------ batas pudar chat

    internal fun chatTopFrac(): Float = prefs().getFloat("chat_top_${cfg.id}", cfg.chatTop)
    internal fun chatFadeDp(): Float = prefs().getFloat("chat_fade_${cfg.id}", cfg.fadeDp)

    override fun onStart() {
        super.onStart()
        applyBg()
    }

    override fun onResume() {
        super.onResume()
        uiActive = true
        avatar?.onResume()
        web.onResume()
        handler.removeCallbacks(avatarTick)
        handler.post(avatarTick)
    }

    override fun onPause() {
        uiActive = false
        handler.removeCallbacks(avatarTick)
        avatar?.onPause()
        web.onPause()
        super.onPause()
    }

    /** Keluar dari halaman chat (app lain / layar mati): mikrofon jangan tetap mendengarkan. */
    override fun onStop() {
        if (listening) stopListening()
        if (bgEditing) endBgEdit(true)
        releaseBg()
        super.onStop()
    }

    override fun finish() {
        super.finish()
        overridePendingTransition(R.anim.fade_in_soft, R.anim.slide_out_right)
    }

    // ------------------------------------------------------------ suara -> teks

    internal fun send(text: String) {
        Voice.stop()
        val model = Gemma.findModel(this)
        if (model == null) {
            Toast.makeText(this, "Model .litertlm belum ada.", Toast.LENGTH_LONG).show()
            if (live) setLive(false)
            return
        }
        val prefs = getSharedPreferences("mangatl", MODE_PRIVATE)
        val glossary = prefs.getString("glossary", "") ?: ""
        val nick = prefs.getString("nick", "") ?: ""
        val notes = prefs.getString("notes", "") ?: ""

        val hist = store.filter { it.text.isNotBlank() }.map { Pair(it.isUser, it.text) }
        store.add(Msg(true, text))
        val ai = Msg(false, "")
        store.add(ai)

        sending = true
        streaming = false
        jsAdd(store[store.size - 2])
        jsAdd(ai)
        pushState()
        val myTurn = ++turn
        val wantVoice = (Voice.autoSpeak(this) || live) && Voice.findVoice(this) != null

        // Suara ikut streaming: model suara dimuat sekarang (selagi AI mikir), lalu tiap kalimat
        // dibacakan begitu teksnya muncul.
        val stream: Voice.Stream? =
            if (wantVoice) {
                Voice.startStream(this) { e ->
                    runOnUiThread {
                        if (e != null) Toast.makeText(this, "Suara gagal: $e", Toast.LENGTH_LONG).show()
                        // Mode live: suara selesai -> giliran pengguna ngomong lagi.
                        if (live && myTurn == turn && !sending) relisten(450)
                    }
                }
            } else {
                null
            }

        Gemma.chat(
            this, model, hist, text, glossary, nick, notes, live,
            onChunk = { chunk ->
                runOnUiThread {
                    ai.text += chunk
                    // Emoji di balasan AI memicu ekspresi avatar (pipi merah, marah, air mata, dll).
                    Emotion.scan(ai.text, ai.text.length - chunk.length - 24)?.let { key ->
                        avatar?.anim?.triggerExpr(key, 4f)
                    }
                    stream?.feed(chunk)
                    streaming = true
                    jsChunk(ai, chunk)
                    pushState()
                }
            },
            onFinish = { err ->
                runOnUiThread {
                    sending = false
                    streaming = false
                    var plain = false   // teks galat / kosong dibuat di sini, bukan dari aliran AI
                    if (err != null) {
                        ai.text = if (ai.text.isBlank()) "Gagal: $err" else ai.text + "\n\n(Gagal: $err)"
                        plain = true
                    } else if (ai.text.isBlank()) {
                        ai.text = "(tidak ada jawaban)"
                        plain = true
                    }
                    jsDone(ai, plain)
                    pushState()
                    if (err == null) stream?.finish() else stream?.cancel()
                    // Tanpa suara: langsung dengar lagi.
                    if (stream == null && live && myTurn == turn) relisten(300)
                }
            }
        )
    }

    override fun onDestroy() {
        live = false
        handler.removeCallbacksAndMessages(null)
        stopListening()
        Voice.release()
        Ear.release()
        if (sending) Gemma.chatCancel()
        webReady = false
        web.onRawTouch = null
        web.removeJavascriptInterface("Bunny")
        (web.parent as? android.view.ViewGroup)?.removeView(web)
        web.destroy()
        super.onDestroy()
    }

}
