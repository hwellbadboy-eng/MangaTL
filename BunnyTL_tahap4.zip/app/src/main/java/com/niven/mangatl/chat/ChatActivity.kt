package com.niven.mangatl

import android.os.Bundle
import android.speech.SpeechRecognizer
import androidx.activity.result.contract.ActivityResultContracts
import android.text.Editable
import android.text.TextWatcher
import android.view.View
import android.view.animation.OvershootInterpolator
import android.os.Handler
import android.os.Looper
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

class ChatActivity : AppCompatActivity() {

    companion object {
        // Riwayat tetap ada selama app hidup, walau layar chat ditutup lalu dibuka lagi.
        private val store = ArrayList<Msg>()

        /** Berapa kali judul "Chat AI" harus diketuk beruntun untuk menyembunyikan/menampilkan avatar (2 atau 3). */
        internal const val TITLE_TAPS = 2
    }

    internal lateinit var list: RecyclerView
    internal lateinit var input: EditText
    private lateinit var btnSend: Button
    private lateinit var adapter: MsgAdapter
    internal var sending = false
    internal lateinit var btnMic: Button
    internal lateinit var btnVoice: Button
    internal var recognizer: SpeechRecognizer? = null
    internal var listening = false
    internal var micStatus: String? = null
    internal var micInfoShown = false
    internal var whisperFailed = false // kalau Whisper error, sisa sesi pakai mic bawaan
    internal var live = false
    internal var turn = 0
    internal val handler = Handler(Looper.getMainLooper())

    // Avatar Live2D (tubuh AI): gerak mengikuti keadaan chat. Model dipilih lewat tahan-lama judul "Chat AI".
    internal var avatar: AvatarView? = null
    internal lateinit var cfg: ModelCfg
    internal lateinit var rootFrame: AvatarDragLayout
    internal lateinit var bgHost: ViewGroup
    internal lateinit var frontHost: ViewGroup
    internal lateinit var body: BodyLayout
    internal lateinit var inputBar: View
    internal lateinit var chatRoot: ViewGroup
    internal lateinit var chipRow: View
    internal var avatarWanted = true
    internal var avatarFront = false
    internal var keyboardUp = false
    internal var avatarErrorShown = false
    internal var titleTaps = 0
    internal var lastFullRootH = 0   // tinggi layar TANPA keyboard (nilai terbesar yang pernah terlihat)
    internal var lastFullBodyH = 0
    internal var lastTitleTap = 0L
    internal var uiActive = false
    internal fun prefs() = getSharedPreferences("mangatl", MODE_PRIVATE)
    private val avatarTick = object : Runnable {
        override fun run() {
            val k = avatar
            if (k != null && k.isShown) {
                k.anim.state = when {
                    Voice.playing -> AvatarState.SPEAKING
                    sending || Voice.speaking -> AvatarState.THINKING
                    listening -> AvatarState.LISTENING
                    else -> AvatarState.IDLE
                }
            }
            updateHoles()
            handler.postDelayed(this, 120)
        }
    }

    internal val micPerm = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { ok ->
        if (ok) startListening()
        else {
            if (live) setLive(false)
            Toast.makeText(this, "Izin mikrofon ditolak.", Toast.LENGTH_SHORT).show()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_chat)
        Fx.enter(this, findViewById(R.id.chatRoot))

        list = findViewById(R.id.list)
        setupAvatar()
        input = findViewById(R.id.input)
        btnSend = findViewById(R.id.btnSend)
        btnMic = findViewById(R.id.btnMic)
        for (v in listOf<View>(input, btnMic, btnSend)) v.addOnLayoutChangeListener { _, _, _, _, _, _, _, _, _ -> updateHoles() }
        btnMic.setOnClickListener { onMic() }
        btnMic.setOnLongClickListener { onMicLong() }
        btnVoice = findViewById(R.id.btnVoice)
        updateVoiceButton()
        input.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}
            override fun onTextChanged(s: CharSequence?, st: Int, b: Int, c: Int) {}
            override fun afterTextChanged(s: Editable?) {
                updateSlot()
            }
        })
        if (Voice.autoSpeak(this)) Voice.preload(this)
        if (Ear.available(this)) Ear.preload(this)
        btnVoice.setOnClickListener {
            val on = !Voice.autoSpeak(this)
            if (on && Voice.findVoice(this) == null) {
                Toast.makeText(
                    this,
                    "Model suara belum ada. Salin folder model Supertonic ke:\n${getExternalFilesDir(null)}",
                    Toast.LENGTH_LONG
                ).show()
                return@setOnClickListener
            }
            Voice.setAutoSpeak(this, on)
            if (!on) Voice.stop()
            updateVoiceButton()
        }

        adapter = MsgAdapter(store) { m -> speakMsg(m) }
        list.layoutManager = LinearLayoutManager(this).apply { stackFromEnd = true }
        list.adapter = adapter
        if (store.isNotEmpty()) list.scrollToPosition(store.size - 1)

        btnSend.setOnClickListener {
            if (sending) {
                if (live) setLive(false)
                Voice.stop()
                Gemma.chatCancel()
            } else {
                val t = input.text.toString().trim()
                if (t.isNotEmpty()) {
                    send(t)
                    input.setText("")
                }
            }
        }

        input.setOnEditorActionListener { _, actionId, _ ->
            if (actionId == EditorInfo.IME_ACTION_SEND) {
                btnSend.performClick()
                true
            } else {
                false
            }
        }

        findViewById<Button>(R.id.btnExplain).setOnClickListener {
            if (sending) return@setOnClickListener
            if (Gemma.lastPage.isEmpty()) {
                Toast.makeText(this, "Terjemahkan satu halaman dulu.", Toast.LENGTH_SHORT).show()
            } else {
                send(
                    "Jelaskan halaman manga yang terakhir tadi: emosi dan nada tiap karakter, " +
                        "idiom/slang/makna tersembunyi yang tidak boleh diterjemahkan harfiah, " +
                        "dan kasih alternatif terjemahan yang lebih natural untuk baris yang menurutmu kurang pas."
                )
            }
        }

        findViewById<Button>(R.id.btnPrompt).setOnClickListener { PromptSlots.show(this) }

        findViewById<Button>(R.id.btnClear).setOnClickListener {
            if (sending) return@setOnClickListener
            store.clear()
            adapter.notifyDataSetChanged()
        }
    }

    internal fun loadCfg(id: String?): ModelCfg =
        try {
            ModelCfg.load(this, id ?: "jian")
        } catch (_: Throwable) {
            ModelCfg.load(this, "jian")
        }

    internal var lastHoles = FloatArray(0)
    private var holesPending = false

    /** Lubangi avatar (mode depan) tepat di atas kolom input dan tombol Mic / Kirim. Hanya menyentuh GL kalau posisinya benar-benar berubah. */
    internal fun updateHoles() {
        val k = avatar ?: return
        if (!::input.isInitialized || !::btnMic.isInitialized || !::btnSend.isInitialized) return
        if (!(avatarFront && avatarWanted)) {
            if (lastHoles.isNotEmpty()) {
                lastHoles = FloatArray(0)
                k.setHoles(lastHoles)
            }
            return
        }
        if (holesPending) return
        holesPending = true
        rootFrame.post {
            holesPending = false
            val kk = avatar ?: return@post
            val kl = IntArray(2)
            kk.getLocationOnScreen(kl)
            val r = 24 * resources.displayMetrics.density
            val out = ArrayList<Float>()
            for (v in listOf<View>(input, if (btnSend.visibility == View.VISIBLE) btnSend else btnMic)) {
                if (!v.isShown || v.width == 0) continue
                val vl = IntArray(2)
                v.getLocationOnScreen(vl)
                val l = (vl[0] - kl[0]).toFloat()
                val t = (vl[1] - kl[1]).toFloat()
                out.add(l); out.add(t); out.add(l + v.width); out.add(t + v.height); out.add(r)
            }
            val arr = out.toFloatArray()
            if (!arr.contentEquals(lastHoles)) {
                lastHoles = arr
                kk.setHoles(arr)
            }
        }
    }

    // ------------------------------------------------------------ batas pudar chat (mode di belakang)

    internal fun chatTopFrac(): Float = prefs().getFloat("chat_top_${cfg.id}", cfg.chatTop)
    internal fun chatFadeDp(): Float = prefs().getFloat("chat_fade_${cfg.id}", cfg.fadeDp)

    override fun onResume() {
        super.onResume()
        uiActive = true
        avatar?.onResume()
        handler.removeCallbacks(avatarTick)
        handler.post(avatarTick)
    }

    override fun onPause() {
        uiActive = false
        handler.removeCallbacks(avatarTick)
        avatar?.onPause()
        super.onPause()
    }

    /** Keluar dari halaman chat (app lain / layar mati): mikrofon jangan tetap mendengarkan. */
    override fun onStop() {
        if (listening) stopListening()
        super.onStop()
    }

    private var slotSend = false

    /** Satu slot di kanan: kolom kosong = Mic, ada teks (atau sedang menjawab) = Kirim/Berhenti. */
    private fun updateSlot() {
        val wantSend = sending || input.text.isNotBlank()
        if (wantSend == slotSend) return
        slotSend = wantSend
        val show = if (wantSend) btnSend else btnMic
        val hide = if (wantSend) btnMic else btnSend
        hide.animate().cancel()
        show.animate().cancel()
        hide.animate().alpha(0f).scaleX(0.6f).scaleY(0.6f)
            .rotation(if (wantSend) -60f else 60f).setDuration(160)
            .withEndAction { if (slotSend == wantSend) hide.visibility = View.GONE }.start()
        show.visibility = View.VISIBLE
        show.alpha = 0f
        show.scaleX = 0.6f
        show.scaleY = 0.6f
        show.rotation = if (wantSend) 60f else -60f
        show.animate().alpha(1f).scaleX(1f).scaleY(1f).rotation(0f).setDuration(240)
            .setInterpolator(OvershootInterpolator(1.4f)).start()
    }

    override fun finish() {
        super.finish()
        overridePendingTransition(R.anim.fade_in_soft, R.anim.slide_out_right)
    }

    // ------------------------------------------------------------ suara -> teks

    internal fun send(text: String) {
        Voice.stop()
        val model = Gemma.findModel(this)
        if (model == null) {
            Toast.makeText(this, "Model .litertlm belum ada.", Toast.LENGTH_LONG).show()
            if (live) setLive(false)
            return
        }
        val prefs = getSharedPreferences("mangatl", MODE_PRIVATE)
        val glossary = prefs.getString("glossary", "") ?: ""
        val nick = prefs.getString("nick", "") ?: ""
        val notes = prefs.getString("notes", "") ?: ""

        val hist = store.filter { it.text.isNotBlank() }.map { Pair(it.isUser, it.text) }
        store.add(Msg(true, text))
        val ai = Msg(false, "")
        store.add(ai)
        adapter.notifyItemRangeInserted(store.size - 2, 2)
        list.scrollToPosition(store.size - 1)

        sending = true
        btnSend.text = "Berhenti"; updateSlot()
        val myTurn = ++turn
        val wantVoice = (Voice.autoSpeak(this) || live) && Voice.findVoice(this) != null

        // Suara ikut streaming: model suara dimuat sekarang (selagi AI mikir), lalu tiap kalimat
        // dibacakan begitu teksnya muncul.
        val stream: Voice.Stream? =
            if (wantVoice) {
                Voice.startStream(this) { e ->
                    runOnUiThread {
                        if (e != null) Toast.makeText(this, "Suara gagal: $e", Toast.LENGTH_LONG).show()
                        // Mode live: suara selesai -> giliran pengguna ngomong lagi.
                        if (live && myTurn == turn && !sending) relisten(450)
                    }
                }
            } else {
                null
            }

        Gemma.chat(
            this, model, hist, text, glossary, nick, notes, live,
            onChunk = { chunk ->
                runOnUiThread {
                    ai.text += chunk
                    // Emoji di balasan AI memicu ekspresi avatar (pipi merah, marah, air mata, dll).
                    Emotion.scan(ai.text, ai.text.length - chunk.length - 24)?.let { key ->
                        avatar?.anim?.triggerExpr(key, 4f)
                    }
                    stream?.feed(chunk)
                    val pos = store.indexOf(ai)
                    if (pos >= 0) {
                        adapter.notifyItemChanged(pos)
                        list.scrollToPosition(store.size - 1)
                    }
                }
            },
            onFinish = { err ->
                runOnUiThread {
                    sending = false
                    btnSend.text = "Kirim"; updateSlot()
                    if (err != null) {
                        ai.text = if (ai.text.isBlank()) "Gagal: $err" else ai.text + "\n\n(Gagal: $err)"
                    } else if (ai.text.isBlank()) {
                        ai.text = "(tidak ada jawaban)"
                    }
                    val pos = store.indexOf(ai)
                    if (pos >= 0) adapter.notifyItemChanged(pos)
                    if (err == null) stream?.finish() else stream?.cancel()
                    // Tanpa suara: langsung dengar lagi.
                    if (stream == null && live && myTurn == turn) relisten(300)
                }
            }
        )
    }

    override fun onDestroy() {
        live = false
        handler.removeCallbacksAndMessages(null)
        stopListening()
        Voice.release()
        Ear.release()
        if (sending) Gemma.chatCancel()
        super.onDestroy()
    }

}
