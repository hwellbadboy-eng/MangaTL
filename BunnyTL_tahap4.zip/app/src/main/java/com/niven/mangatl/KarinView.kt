package com.niven.mangatl

import android.annotation.SuppressLint
import android.content.Context
import android.opengl.GLES20
import android.opengl.GLSurfaceView
import android.util.AttributeSet
import android.util.Log
import android.view.MotionEvent
import com.live2d.sdk.cubism.framework.math.CubismMatrix44
import com.live2d.sdk.cubism.framework.rendering.android.CubismOffscreenManagerAndroid
import com.live2d.sdk.cubism.framework.rendering.android.CubismShaderAndroid
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.FloatBuffer
import javax.microedition.khronos.egl.EGLConfig
import javax.microedition.khronos.opengles.GL10

/**
 * Karin (Live2D) sebagai tubuh AI di chat. Latar digambar sewarna latar app (#09090A).
 * Digambar 30 fps (hemat baterai); berhenti total saat layar di-pause.
 */
class KarinView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : GLSurfaceView(context, attrs) {

    val anim = KarinAnim()

    /** Dipanggil di thread utama kalau model gagal dimuat. */
    var onError: ((String) -> Unit)? = null

    private val rend = KarinRenderer(context.applicationContext, anim) { msg -> post { onError?.invoke(msg) } }
    private var ticking = false
    private val tick = object : Runnable {
        override fun run() {
            if (!ticking) return
            requestRender()
            postDelayed(this, FRAME_MS)
        }
    }

    init {
        setEGLContextClientVersion(2)
        setEGLConfigChooser(8, 8, 8, 8, 16, 0)
        // Jangan buang konteks GL saat app ke latar: kembali dari app lain = langsung jalan, tanpa muat ulang tekstur.
        preserveEGLContextOnPause = true
        rend.reservePx = (BOTTOM_RESERVE_DP * resources.displayMetrics.density).toInt()
        setRenderer(rend)
        renderMode = RENDERMODE_WHEN_DIRTY
    }

    override fun onResume() {
        super.onResume()
        ticking = true
        removeCallbacks(tick)
        post(tick)
    }

    override fun onPause() {
        ticking = false
        removeCallbacks(tick)
        super.onPause()
    }

    /** Zig-zag sobekan: badan Karin berhenti tepat di garis ini. heightPx = tinggi gambar sobekan di layar. */
    fun setTear(p: TearProfile, heightPx: Float) {
        rend.setTear(p, heightPx)
        requestRender()
    }

    /** Muat ulang model kalau tadi dilepas (lihat releaseModel). */
    fun ensureModel() {
        rend.wantModel = true
        requestRender()
    }

    /** Lepas model + tekstur dari memori GPU (dipakai saat Karin dimatikan). onDone jalan di thread utama. */
    fun releaseModel(onDone: () -> Unit) {
        queueEvent {
            rend.releaseModel()
            post { onDone() }
        }
        requestRender()
    }

    @SuppressLint("ClickableViewAccessibility")
    override fun onTouchEvent(e: MotionEvent): Boolean {
        val w = width.coerceAtLeast(1)
        val h = height.coerceAtLeast(1)
        val nx = (e.x / w * 2f - 1f).coerceIn(-1f, 1f)
        val ny = (1f - e.y / h * 2f).coerceIn(-1f, 1f)
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN, MotionEvent.ACTION_MOVE -> anim.touch(nx, ny, true)
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> anim.touch(nx, ny, false)
        }
        return true
    }

    companion object {
        private const val FRAME_MS = 33L

        /** Karin digambar naik sekian dp dari dasar area, supaya dasar kanvas (potongan badan) tersembunyi
         *  di bawah sobekan kertas dan dadanya tetap kelihatan penuh. Sesuaikan dengan tinggi sobekan (48dp). */
        const val BOTTOM_RESERVE_DP = 14f
    }
}

private class KarinRenderer(
    private val appCtx: Context,
    private val anim: KarinAnim,
    private val fail: (String) -> Unit
) : GLSurfaceView.Renderer {

    @Volatile var wantModel = true
    @Volatile var reservePx = 0
    private var model: KarinModel? = null
    private var loading: KarinModel? = null
    private var w = 0
    private var h = 0
    private var last = 0L
    private var fadeStart = 0L
    private var failed = false
    private val proj = CubismMatrix44.create()

    // Poligon penutup: menimpa semua yang ada di bawah zig-zag sobekan dengan warna latar,
    // sehingga badan Karin "terpotong" mengikuti sobekan (bukan garis lurus).
    @Volatile private var tear: TearProfile? = null
    @Volatile private var tearPx = 0f
    private var coverDirty = true
    private var coverProg = 0
    private var coverPos = -1
    private var coverCol = -1
    private var coverBuf: FloatBuffer? = null
    private var coverCount = 0

    init {
        KarinCore.ensure(appCtx)
    }

    fun setTear(p: TearProfile, px: Float) {
        tear = p
        tearPx = px
        coverDirty = true
    }

    private fun compile(type: Int, src: String): Int {
        val sh = GLES20.glCreateShader(type)
        GLES20.glShaderSource(sh, src)
        GLES20.glCompileShader(sh)
        val ok = IntArray(1)
        GLES20.glGetShaderiv(sh, GLES20.GL_COMPILE_STATUS, ok, 0)
        if (ok[0] == 0) {
            val log = GLES20.glGetShaderInfoLog(sh)
            GLES20.glDeleteShader(sh)
            throw IllegalStateException(log)
        }
        return sh
    }

    private fun initCover() {
        coverProg = 0
        try {
            val vs = compile(GLES20.GL_VERTEX_SHADER, "attribute vec2 a;void main(){gl_Position=vec4(a,0.0,1.0);}")
            val fs = compile(GLES20.GL_FRAGMENT_SHADER, "precision mediump float;uniform vec4 c;void main(){gl_FragColor=c;}")
            val pr = GLES20.glCreateProgram()
            GLES20.glAttachShader(pr, vs)
            GLES20.glAttachShader(pr, fs)
            GLES20.glLinkProgram(pr)
            val ok = IntArray(1)
            GLES20.glGetProgramiv(pr, GLES20.GL_LINK_STATUS, ok, 0)
            if (ok[0] == 0) throw IllegalStateException(GLES20.glGetProgramInfoLog(pr))
            coverProg = pr
            coverPos = GLES20.glGetAttribLocation(pr, "a")
            coverCol = GLES20.glGetUniformLocation(pr, "c")
        } catch (t: Throwable) {
            Log.e("Karin", "Poligon penutup gagal dibuat: ${t.message}")
            coverProg = 0
        }
        coverDirty = true
    }

    private fun buildCover() {
        val p = tear ?: return
        if (w <= 0 || h <= 0 || tearPx <= 0f) return
        val n = p.n
        val buf = ByteBuffer.allocateDirect(n * 4 * 4).order(ByteOrder.nativeOrder()).asFloatBuffer()
        for (i in 0 until n) {
            val x = -1f + 2f * i / (n - 1f)
            val yPx = tearPx * (1f - p.gl[i] / TearProfile.IMG_H)   // tinggi garis sobekan dari dasar view
            val ny = -1f + 2f * yPx / h
            buf.put(x).put(ny).put(x).put(-1f)
        }
        buf.position(0)
        coverBuf = buf
        coverCount = n * 2
        coverDirty = false
    }

    private fun drawCover() {
        if (coverProg == 0) return
        if (coverDirty) buildCover()
        val buf = coverBuf ?: return
        GLES20.glViewport(0, 0, w, h)
        GLES20.glDisable(GLES20.GL_DEPTH_TEST)
        GLES20.glDisable(GLES20.GL_CULL_FACE)
        GLES20.glDisable(GLES20.GL_SCISSOR_TEST)
        GLES20.glDisable(GLES20.GL_STENCIL_TEST)
        GLES20.glDisable(GLES20.GL_BLEND)
        GLES20.glBindBuffer(GLES20.GL_ARRAY_BUFFER, 0)
        GLES20.glUseProgram(coverProg)
        GLES20.glUniform4f(coverCol, 9f / 255f, 9f / 255f, 10f / 255f, 1f)
        GLES20.glEnableVertexAttribArray(coverPos)
        GLES20.glVertexAttribPointer(coverPos, 2, GLES20.GL_FLOAT, false, 0, buf)
        GLES20.glDrawArrays(GLES20.GL_TRIANGLE_STRIP, 0, coverCount)
        GLES20.glDisableVertexAttribArray(coverPos)
        GLES20.glEnable(GLES20.GL_BLEND)
        GLES20.glBlendFunc(GLES20.GL_SRC_ALPHA, GLES20.GL_ONE_MINUS_SRC_ALPHA)
    }

    override fun onSurfaceCreated(gl: GL10?, config: EGLConfig?) {
        // Konteks GL baru: semua resource GL yang lama sudah tidak berlaku.
        model?.release(false)
        model = null
        loading?.release(false)
        loading = null
        failed = false
        CubismOffscreenManagerAndroid.releaseInstance()
        try {
            CubismShaderAndroid.getInstance().releaseInvalidShaderProgram()
        } catch (_: Throwable) {
        }
        CubismShaderAndroid.deleteInstance()
        GLES20.glEnable(GLES20.GL_BLEND)
        GLES20.glBlendFunc(GLES20.GL_SRC_ALPHA, GLES20.GL_ONE_MINUS_SRC_ALPHA)
        last = 0L
        fadeStart = 0L
        initCover()
        if (wantModel) KarinTex.prefetch(appCtx)   // mulai decode tekstur lebih awal
    }

    override fun onSurfaceChanged(gl: GL10?, width: Int, height: Int) {
        val changed = width != w || height != h
        w = width
        h = height
        GLES20.glViewport(0, 0, width, height)
        if (changed) {
            model?.setRenderTargetSize(width, height)
            coverDirty = true
        }
    }

    fun releaseModel() {
        wantModel = false
        loading?.release(true)
        loading = null
        model?.release(true)
        model = null
    }

    override fun onDrawFrame(gl: GL10?) {
        GLES20.glClearColor(9f / 255f, 9f / 255f, 10f / 255f, 1f)
        GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT or GLES20.GL_DEPTH_BUFFER_BIT)
        if (w <= 0 || h <= 0) return

        // Muat bertahap: frame 1 = moc3 + shader, lalu satu tekstur per frame (tidak ada frame panjang).
        if (model == null) {
            if (!wantModel || failed) return
            try {
                val l = loading
                if (l == null) {
                    val n = KarinModel(appCtx)
                    if (n.begin(w, h)) {
                        loading = n
                    } else {
                        n.release(true)
                        failed = true
                        fail("model tidak terbentuk (cek file .moc3)")
                    }
                } else if (l.step()) {
                    model = l
                    loading = null
                    last = 0L
                    fadeStart = 0L
                }
            } catch (t: Throwable) {
                failed = true
                loading?.release(true)
                loading = null
                Log.e("Karin", "Gagal muat model", t)
                fail(t.message ?: t::class.java.simpleName)
            }
            return
        }
        val m = model ?: return

        val now = System.nanoTime()
        val dt = if (last == 0L) 0.033f else ((now - last) / 1_000_000_000f).coerceIn(0.001f, 0.1f)
        last = now
        if (fadeStart == 0L) fadeStart = now
        val f = ((now - fadeStart) / 450_000_000f).coerceIn(0f, 1f)
        m.setFade(f * f * (3f - 2f * f))   // muncul halus, bukan tiba-tiba

        // Area gambar = seluruh view dikurangi 'reservePx' di dasar (tertutup sobekan kertas).
        val vw = w
        val vh = (h - reservePx).coerceAtLeast(1)
        GLES20.glViewport(0, reservePx, vw, vh)

        val offscreen = CubismOffscreenManagerAndroid.getInstance()
        offscreen.beginFrameProcess()

        // Pas: seluruh badan atas Karin muat penuh di area. Titik asal koordinat model sudah di tengah kanvas,
        // jadi TIDAK perlu setCenterPosition (itu yang bikin Karin melorot ke pojok kiri-bawah).
        val aspect = vw.toFloat() / vh.toFloat()
        val displayRatio = vh.toFloat() / vw.toFloat()
        proj.loadIdentity()
        if (m.canvasRatio() < displayRatio) {
            m.getModelMatrix().setWidth(2.0f)
            proj.scale(1.0f, aspect)
        } else {
            m.getModelMatrix().setHeight(2.0f)
            proj.scale(1.0f / aspect, 1.0f)
        }

        m.update(dt, anim)
        m.draw(proj)

        offscreen.endFrameProcess()
        offscreen.releaseStaleRenderTextures()

        drawCover()
    }
}
