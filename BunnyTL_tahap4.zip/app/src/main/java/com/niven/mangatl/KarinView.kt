package com.niven.mangatl

import android.annotation.SuppressLint
import android.content.Context
import android.opengl.GLES20
import android.opengl.GLSurfaceView
import android.util.AttributeSet
import android.util.Log
import android.view.MotionEvent
import com.live2d.sdk.cubism.framework.math.CubismMatrix44
import com.live2d.sdk.cubism.framework.rendering.android.CubismOffscreenManagerAndroid
import com.live2d.sdk.cubism.framework.rendering.android.CubismShaderAndroid
import javax.microedition.khronos.egl.EGLConfig
import javax.microedition.khronos.opengles.GL10

/**
 * Karin (Live2D) sebagai tubuh AI di chat. Latar digambar sewarna latar app (#09090A).
 * Digambar 30 fps (hemat baterai); berhenti total saat layar di-pause.
 */
class KarinView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : GLSurfaceView(context, attrs) {

    val anim = KarinAnim()

    /** Dipanggil di thread utama kalau model gagal dimuat. */
    var onError: ((String) -> Unit)? = null

    private val rend = KarinRenderer(context.applicationContext, anim) { msg -> post { onError?.invoke(msg) } }
    private var ticking = false
    private val tick = object : Runnable {
        override fun run() {
            if (!ticking) return
            requestRender()
            postDelayed(this, FRAME_MS)
        }
    }

    init {
        setEGLContextClientVersion(2)
        setEGLConfigChooser(8, 8, 8, 8, 16, 0)
        setRenderer(rend)
        renderMode = RENDERMODE_WHEN_DIRTY
    }

    override fun onResume() {
        super.onResume()
        ticking = true
        removeCallbacks(tick)
        post(tick)
    }

    override fun onPause() {
        ticking = false
        removeCallbacks(tick)
        super.onPause()
    }

    /** Muat ulang model kalau tadi dilepas (lihat releaseModel). */
    fun ensureModel() {
        rend.wantModel = true
        requestRender()
    }

    /** Lepas model + tekstur dari memori GPU (dipakai saat Karin dimatikan). onDone jalan di thread utama. */
    fun releaseModel(onDone: () -> Unit) {
        queueEvent {
            rend.releaseModel()
            post { onDone() }
        }
        requestRender()
    }

    @SuppressLint("ClickableViewAccessibility")
    override fun onTouchEvent(e: MotionEvent): Boolean {
        val w = width.coerceAtLeast(1)
        val h = height.coerceAtLeast(1)
        val nx = (e.x / w * 2f - 1f).coerceIn(-1f, 1f)
        val ny = (1f - e.y / h * 2f).coerceIn(-1f, 1f)
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN, MotionEvent.ACTION_MOVE -> anim.touch(nx, ny, true)
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> anim.touch(nx, ny, false)
        }
        return true
    }

    companion object {
        private const val FRAME_MS = 33L
    }
}

private class KarinRenderer(
    private val appCtx: Context,
    private val anim: KarinAnim,
    private val fail: (String) -> Unit
) : GLSurfaceView.Renderer {

    @Volatile var wantModel = true
    private var model: KarinModel? = null
    private var w = 0
    private var h = 0
    private var last = 0L
    private var failed = false
    private val proj = CubismMatrix44.create()

    init {
        KarinCore.ensure(appCtx)
    }

    override fun onSurfaceCreated(gl: GL10?, config: EGLConfig?) {
        // Konteks GL baru: semua resource GL yang lama sudah tidak berlaku.
        model?.release(false)
        model = null
        failed = false
        CubismOffscreenManagerAndroid.releaseInstance()
        try {
            CubismShaderAndroid.getInstance().releaseInvalidShaderProgram()
        } catch (_: Throwable) {
        }
        CubismShaderAndroid.deleteInstance()
        GLES20.glEnable(GLES20.GL_BLEND)
        GLES20.glBlendFunc(GLES20.GL_SRC_ALPHA, GLES20.GL_ONE_MINUS_SRC_ALPHA)
        last = 0L
    }

    override fun onSurfaceChanged(gl: GL10?, width: Int, height: Int) {
        w = width
        h = height
        GLES20.glViewport(0, 0, width, height)
        model?.setRenderTargetSize(width, height)
    }

    fun releaseModel() {
        wantModel = false
        model?.release(true)
        model = null
    }

    override fun onDrawFrame(gl: GL10?) {
        GLES20.glClearColor(9f / 255f, 9f / 255f, 10f / 255f, 1f)
        GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT or GLES20.GL_DEPTH_BUFFER_BIT)
        if (w <= 0 || h <= 0) return

        if (model == null && wantModel && !failed) {
            try {
                val m = KarinModel(appCtx)
                if (m.load(w, h)) {
                    model = m
                } else {
                    m.release(true)
                    failed = true
                    fail("model tidak terbentuk (cek file .moc3)")
                }
            } catch (t: Throwable) {
                failed = true
                Log.e("Karin", "Gagal muat model", t)
                fail(t.message ?: t::class.java.simpleName)
            }
            last = 0L
        }
        val m = model ?: return

        val now = System.nanoTime()
        val dt = if (last == 0L) 0.033f else ((now - last) / 1_000_000_000f).coerceIn(0.001f, 0.1f)
        last = now

        val offscreen = CubismOffscreenManagerAndroid.getInstance()
        offscreen.beginFrameProcess()

        // Pas: seluruh badan atas Karin muat penuh di area, diposisikan di tengah.
        val aspect = w.toFloat() / h.toFloat()
        val displayRatio = h.toFloat() / w.toFloat()
        proj.loadIdentity()
        if (m.canvasRatio() < displayRatio) {
            m.getModelMatrix().setWidth(2.0f)
            proj.scale(1.0f, aspect)
        } else {
            m.getModelMatrix().setHeight(2.0f)
            proj.scale(1.0f / aspect, 1.0f)
        }
        m.getModelMatrix().setCenterPosition(0f, 0f)

        m.update(dt, anim)
        m.draw(proj)

        offscreen.endFrameProcess()
        offscreen.releaseStaleRenderTextures()
    }
}
