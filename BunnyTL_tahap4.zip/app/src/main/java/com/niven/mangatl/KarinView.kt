package com.niven.mangatl

import android.annotation.SuppressLint
import android.content.Context
import android.opengl.GLES20
import android.os.SystemClock
import android.opengl.GLSurfaceView
import android.graphics.PixelFormat
import android.util.Log
import android.view.MotionEvent
import com.live2d.sdk.cubism.framework.math.CubismMatrix44
import com.live2d.sdk.cubism.framework.rendering.android.CubismOffscreenManagerAndroid
import com.live2d.sdk.cubism.framework.rendering.android.CubismShaderAndroid
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.FloatBuffer
import javax.microedition.khronos.egl.EGLConfig
import javax.microedition.khronos.opengles.GL10

/**
 * Karin (Live2D) sebagai tubuh AI di chat. Latar digambar sewarna latar app (#09090A).
 * Digambar 30 fps (hemat baterai); berhenti total saat layar di-pause.
 */
class KarinView(
    context: Context,
    private val cfg: ModelCfg,
    /** true = digambar DI ATAS chat (permukaan transparan, sentuhan diteruskan ke chat). false = di belakang. */
    private val front: Boolean
) : GLSurfaceView(context) {

    val anim = KarinAnim()

    /** Dipanggil di thread utama kalau model gagal dimuat. */
    var onError: ((String) -> Unit)? = null

    private val rend = KarinRenderer(context.applicationContext, cfg, anim, front) { msg -> post { onError?.invoke(msg) } }
    private var ticking = false
    private val tick = object : Runnable {
        override fun run() {
            if (!ticking) return
            requestRender()
            postDelayed(this, cfg.frameMs())
        }
    }

    init {
        setEGLContextClientVersion(2)
        setEGLConfigChooser(8, 8, 8, 8, 16, 0)
        // Jangan buang konteks GL saat app ke latar: kembali dari app lain = langsung jalan, tanpa muat ulang tekstur.
        preserveEGLContextOnPause = true
        if (front) {
            // Di depan chat: permukaan di atas jendela dan transparan, jadi chat tetap terlihat di sekitar badan avatar.
            setZOrderOnTop(true)
            holder.setFormat(PixelFormat.TRANSLUCENT)
        }
        anim.usePos = !cfg.params["posX"].isNullOrEmpty() && !cfg.params["posY"].isNullOrEmpty()
        // Mode panggung (bust + sobekan): badan digambar naik sedikit dari dasar. Full body: pakai seluruh area.
        rend.reservePx = if (cfg.full) 0 else (BOTTOM_RESERVE_DP * resources.displayMetrics.density).toInt()
        setRenderer(rend)
        renderMode = RENDERMODE_WHEN_DIRTY
    }

    override fun onResume() {
        super.onResume()
        ticking = true
        removeCallbacks(tick)
        post(tick)
    }

    override fun onPause() {
        ticking = false
        removeCallbacks(tick)
        super.onPause()
    }

    // ---- geser avatar (mode di depan chat) ----
    fun dragX() = rend.dragX
    fun dragY() = rend.dragY

    fun setDrag(x: Float, y: Float) {
        rend.dragX = x.coerceIn(-1.6f, 1.6f)
        rend.dragY = y.coerceIn(-1.6f, 1.6f)
        requestRender()
    }

    private var lastDragT = 0L

    /** Geser dalam piksel layar (jari). Kecepatan geser diteruskan ke animasi supaya badan/rambut/ekor ikut terayun. */
    fun dragBy(dxPx: Float, dyPx: Float) {
        val w = width.coerceAtLeast(1)
        val h = height.coerceAtLeast(1)
        val now = SystemClock.uptimeMillis()
        val dt = (now - lastDragT).coerceIn(8L, 100L) / 1000f
        lastDragT = now
        anim.dragMove(dxPx / w * 2f / dt, -dyPx / h * 2f / dt)
        setDrag(rend.dragX + dxPx / w * 2f, rend.dragY - dyPx / h * 2f)
    }

    val isFront: Boolean get() = front

    // ---- zoom dua jari ----
    fun userScale() = rend.userScale

    fun setUserScale(sc: Float) {
        rend.userScale = sc.coerceIn(0.35f, 3.5f)
        requestLayout()
        requestRender()
    }

    /** Zoom sebesar 'factor' dengan titik fokus (x, y) piksel view tetap diam (seperti zoom foto). */
    fun pinchBy(factor: Float, fx: Float, fy: Float) {
        val old = rend.userScale
        val ns = (old * factor).coerceIn(0.35f, 3.5f)
        if (ns == old) return
        val f = rend.xf
        val w = width.coerceAtLeast(1).toFloat()
        val h = height.coerceAtLeast(1).toFloat()
        val cx = fx / w * 2f - 1f
        val cy = if (f != null && f[7] > 0f) ((h - fy) - f[6]) / f[7] * 2f - 1f else 1f - fy / h * 2f
        val r = ns / old
        rend.userScale = ns
        setDrag(cx - (cx - rend.dragX) * r, cy - (cy - rend.dragY) * r)
    }

    fun setDragging(on: Boolean) {
        anim.setDragging(on)
    }

    /**
     * Tinggi layar 'seolah' tanpa keyboard (px). Avatar digambar seukuran ini dan menempel di atas, jadi saat keyboard muncul
     * dan permukaan mengecil, avatar tidak ikut mengecil / terdorong ke atas. 0 = ikuti ukuran permukaan.
     */
    fun setVirtualHeight(px: Int) {
        rend.virtualH = px.coerceAtLeast(0)
        requestRender()
    }

    /**
     * Di depan chat: daerah (px view; l, t, r, b, radius per lubang) yang dilubangi transparan SETELAH avatar digambar,
     * supaya kolom input & tombol Mic tetap kelihatan dan avatar boleh menjulur sampai dasar layar.
     */
    fun setHoles(a: FloatArray) {
        rend.holes = a
        requestRender()
    }

    /** Di depan chat: sisakan 'px' di dasar (kolom input) tetap di luar permukaan avatar, tanpa mengubah ukuran avatar. */
    fun setBottomExtra(px: Int) {
        rend.reservePx = -px.coerceAtLeast(0)
        requestRender()
    }

    /** Titik layar (piksel view) -> pecahan kanvas model (0..1 dari kiri-atas). null kalau belum digambar. */
    fun canvasFrac(x: Float, y: Float): FloatArray? {
        val f = rend.xf ?: return null
        val sx = f[0]
        val sy = f[1]
        val tx = f[2]
        val ty = f[3]
        val cw = f[4]
        val ch = f[5]
        val vy = f[6]
        val vh = f[7]
        val h = f[8]
        val w = f[9]
        if (sx == 0f || sy == 0f || vh <= 0f || w <= 0f) return null
        val cx = x / w * 2f - 1f
        val cy = ((h - y) - vy) / vh * 2f - 1f
        val xm = (cx - tx) / sx
        val ym = (cy - ty) / sy
        return floatArrayOf(xm / cw + 0.5f, 0.5f - ym / ch)
    }

    /** Dipanggil (thread utama) tiap ketukan di avatar: nama zona yang kena ("-" kalau di luar zona) dan koordinat kanvas 0..1. */
    var onZone: ((String, Float, Float) -> Unit)? = null

    /** Sentuhan di titik (x, y): kalau kena zona tubuh model (dada, paha, dll.) picu reaksinya. true = ada reaksi. */
    fun pokeAt(x: Float, y: Float): Boolean {
        val f = canvasFrac(x, y) ?: return false
        for (z in cfg.touch) {
            if (f[0] in z.x0..z.x1 && f[1] in z.y0..z.y1) {
                anim.poke(z.react, z.strength)
                if (z.expr.isNotEmpty()) anim.triggerExpr(z.expr, 3f)
                onZone?.invoke(z.name, f[0], f[1])
                return true
            }
        }
        onZone?.invoke("-", f[0], f[1])
        return false
    }

    /** Apakah piksel (x, y) di view ini bagian badan avatar (alpha > 0)? Dijawab asynchronous, hasil di thread utama. */
    fun probeHit(x: Float, y: Float, cb: (Boolean) -> Unit) {
        rend.probeCb = { hit -> post { cb(hit) } }
        rend.probe = floatArrayOf(x, y)
        requestRender()
    }

    /** Zig-zag sobekan: badan Karin berhenti tepat di garis ini. heightPx = tinggi gambar sobekan di layar. */
    fun setTear(p: TearProfile, heightPx: Float) {
        rend.setTear(p, heightPx)
        requestRender()
    }

    /** Muat ulang model kalau tadi dilepas (lihat releaseModel). */
    fun ensureModel() {
        rend.wantModel = true
        requestRender()
    }

    /** Lepas model + tekstur dari memori GPU (dipakai saat Karin dimatikan). onDone jalan di thread utama. */
    fun releaseModel(onDone: () -> Unit) {
        queueEvent {
            rend.releaseModel()
            post { onDone() }
        }
        requestRender()
    }

    @SuppressLint("ClickableViewAccessibility")
    override fun onTouchEvent(e: MotionEvent): Boolean {
        if (front) return false   // di depan chat: sentuhan diteruskan ke daftar chat di bawahnya
        val w = width.coerceAtLeast(1)
        val h = height.coerceAtLeast(1)
        val nx = (e.x / w * 2f - 1f).coerceIn(-1f, 1f)
        val ny = (1f - e.y / h * 2f).coerceIn(-1f, 1f)
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN, MotionEvent.ACTION_MOVE -> anim.touch(nx, ny, true)
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> anim.touch(nx, ny, false)
        }
        return true
    }

    companion object {
        /** Karin digambar naik sekian dp dari dasar area, supaya dasar kanvas (potongan badan) tersembunyi
         *  di bawah sobekan kertas dan dadanya tetap kelihatan penuh. Sesuaikan dengan tinggi sobekan (48dp). */
        const val BOTTOM_RESERVE_DP = 14f
    }
}

private class KarinRenderer(
    private val appCtx: Context,
    private val cfg: ModelCfg,
    private val anim: KarinAnim,
    private val front: Boolean,
    private val fail: (String) -> Unit
) : GLSurfaceView.Renderer {

    @Volatile var wantModel = true
    @Volatile var reservePx = 0
    @Volatile var holes: FloatArray = FloatArray(0)
    @Volatile var virtualH = 0
    private var rtW = 0
    private var rtH = 0
    @Volatile var dragX = 0f
    @Volatile var dragY = 0f
    @Volatile var userScale = 1f
    @Volatile var xf: FloatArray? = null
    @Volatile var probe: FloatArray? = null
    @Volatile var probeCb: ((Boolean) -> Unit)? = null
    private var model: KarinModel? = null
    private var loading: KarinModel? = null
    private var w = 0
    private var h = 0
    private var last = 0L
    private var fadeStart = 0L
    private var failed = false
    private val proj = CubismMatrix44.create()

    // Poligon penutup: menimpa semua yang ada di bawah zig-zag sobekan dengan warna latar,
    // sehingga badan Karin "terpotong" mengikuti sobekan (bukan garis lurus).
    @Volatile private var tear: TearProfile? = null
    @Volatile private var tearPx = 0f
    private var coverDirty = true
    private var coverProg = 0
    private var coverPos = -1
    private var coverCol = -1
    private var coverBuf: FloatBuffer? = null
    private var coverCount = 0

    init {
        KarinCore.ensure(appCtx)
    }

    fun setTear(p: TearProfile, px: Float) {
        tear = p
        tearPx = px
        coverDirty = true
    }

    private fun compile(type: Int, src: String): Int {
        val sh = GLES20.glCreateShader(type)
        GLES20.glShaderSource(sh, src)
        GLES20.glCompileShader(sh)
        val ok = IntArray(1)
        GLES20.glGetShaderiv(sh, GLES20.GL_COMPILE_STATUS, ok, 0)
        if (ok[0] == 0) {
            val log = GLES20.glGetShaderInfoLog(sh)
            GLES20.glDeleteShader(sh)
            throw IllegalStateException(log)
        }
        return sh
    }

    private fun initCover() {
        coverProg = 0
        try {
            val vs = compile(GLES20.GL_VERTEX_SHADER, "attribute vec2 a;void main(){gl_Position=vec4(a,0.0,1.0);}")
            val fs = compile(GLES20.GL_FRAGMENT_SHADER, "precision mediump float;uniform vec4 c;void main(){gl_FragColor=c;}")
            val pr = GLES20.glCreateProgram()
            GLES20.glAttachShader(pr, vs)
            GLES20.glAttachShader(pr, fs)
            GLES20.glLinkProgram(pr)
            val ok = IntArray(1)
            GLES20.glGetProgramiv(pr, GLES20.GL_LINK_STATUS, ok, 0)
            if (ok[0] == 0) throw IllegalStateException(GLES20.glGetProgramInfoLog(pr))
            coverProg = pr
            coverPos = GLES20.glGetAttribLocation(pr, "a")
            coverCol = GLES20.glGetUniformLocation(pr, "c")
        } catch (t: Throwable) {
            Log.e("Karin", "Poligon penutup gagal dibuat: ${t.message}")
            coverProg = 0
        }
        coverDirty = true
    }

    private fun buildCover() {
        val p = tear ?: return
        if (w <= 0 || h <= 0 || tearPx <= 0f) return
        val n = p.n
        val buf = ByteBuffer.allocateDirect(n * 4 * 4).order(ByteOrder.nativeOrder()).asFloatBuffer()
        for (i in 0 until n) {
            val x = -1f + 2f * i / (n - 1f)
            val yPx = tearPx * (1f - p.gl[i] / TearProfile.IMG_H)   // tinggi garis sobekan dari dasar view
            val ny = -1f + 2f * yPx / h
            buf.put(x).put(ny).put(x).put(-1f)
        }
        buf.position(0)
        coverBuf = buf
        coverCount = n * 2
        coverDirty = false
    }

    private fun drawCover() {
        if (coverProg == 0) return
        if (coverDirty) buildCover()
        val buf = coverBuf ?: return
        GLES20.glViewport(0, 0, w, h)
        GLES20.glDisable(GLES20.GL_DEPTH_TEST)
        GLES20.glDisable(GLES20.GL_CULL_FACE)
        GLES20.glDisable(GLES20.GL_SCISSOR_TEST)
        GLES20.glDisable(GLES20.GL_STENCIL_TEST)
        GLES20.glDisable(GLES20.GL_BLEND)
        GLES20.glBindBuffer(GLES20.GL_ARRAY_BUFFER, 0)
        GLES20.glUseProgram(coverProg)
        GLES20.glUniform4f(coverCol, 9f / 255f, 9f / 255f, 10f / 255f, 1f)
        GLES20.glEnableVertexAttribArray(coverPos)
        GLES20.glVertexAttribPointer(coverPos, 2, GLES20.GL_FLOAT, false, 0, buf)
        GLES20.glDrawArrays(GLES20.GL_TRIANGLE_STRIP, 0, coverCount)
        GLES20.glDisableVertexAttribArray(coverPos)
        GLES20.glEnable(GLES20.GL_BLEND)
        GLES20.glBlendFunc(GLES20.GL_SRC_ALPHA, GLES20.GL_ONE_MINUS_SRC_ALPHA)
    }

    override fun onSurfaceCreated(gl: GL10?, config: EGLConfig?) {
        // Konteks GL baru: semua resource GL yang lama sudah tidak berlaku.
        model?.release(false)
        model = null
        loading?.release(false)
        loading = null
        failed = false
        CubismOffscreenManagerAndroid.releaseInstance()
        try {
            CubismShaderAndroid.getInstance().releaseInvalidShaderProgram()
        } catch (_: Throwable) {
        }
        CubismShaderAndroid.deleteInstance()
        GLES20.glEnable(GLES20.GL_BLEND)
        GLES20.glBlendFunc(GLES20.GL_SRC_ALPHA, GLES20.GL_ONE_MINUS_SRC_ALPHA)
        last = 0L
        fadeStart = 0L
        initCover()
        if (wantModel) KarinTex.prefetch(appCtx, cfg.texturePaths())   // mulai decode tekstur lebih awal
    }

    override fun onSurfaceChanged(gl: GL10?, width: Int, height: Int) {
        val changed = width != w || height != h
        w = width
        h = height
        GLES20.glViewport(0, 0, width, height)
        if (changed) {
            rtW = 0   // paksa sinkron ulang ukuran render target pada frame berikutnya
            rtH = 0
            coverDirty = true
        }
    }

    fun releaseModel() {
        wantModel = false
        loading?.release(true)
        loading = null
        model?.release(true)
        model = null
    }

    override fun onDrawFrame(gl: GL10?) {
        if (front) GLES20.glClearColor(0f, 0f, 0f, 0f) else GLES20.glClearColor(9f / 255f, 9f / 255f, 10f / 255f, 1f)
        GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT or GLES20.GL_DEPTH_BUFFER_BIT)
        if (w <= 0 || h <= 0) return

        // Muat bertahap: frame 1 = moc3 + shader, lalu satu tekstur per frame (tidak ada frame panjang).
        if (model == null) {
            probe?.let {
                probe = null
                probeCb?.invoke(false)
                probeCb = null
            }
            if (!wantModel || failed) return
            try {
                val l = loading
                if (l == null) {
                    val n = KarinModel(appCtx, cfg)
                    if (n.begin(w, h)) {
                        loading = n
                    } else {
                        n.release(true)
                        failed = true
                        fail("model tidak terbentuk (cek file .moc3)")
                    }
                } else if (l.step()) {
                    model = l
                    loading = null
                    last = 0L
                    fadeStart = 0L
                }
            } catch (t: Throwable) {
                failed = true
                loading?.release(true)
                loading = null
                Log.e("Karin", "Gagal muat model", t)
                fail(t.message ?: t::class.java.simpleName)
            }
            return
        }
        val m = model ?: return

        val now = System.nanoTime()
        val dt = if (last == 0L) 0.033f else ((now - last) / 1_000_000_000f).coerceIn(0.001f, 0.1f)
        last = now
        if (fadeStart == 0L) fadeStart = now
        val f = ((now - fadeStart) / 450_000_000f).coerceIn(0f, 1f)
        m.setFade(f * f * (3f - 2f * f))   // muncul halus, bukan tiba-tiba

        // Area gambar = seluruh view dikurangi 'reservePx' di dasar (tertutup sobekan kertas).
        // Kalau virtualH > tinggi permukaan (keyboard muncul / kolom input di depan), avatar tetap digambar seukuran virtualH.
        val rsv = if (virtualH > h) -(virtualH - h) else reservePx
        val vw = w
        val vh = (h - rsv).coerceAtLeast(1)
        GLES20.glViewport(0, rsv, vw, vh)
        // Render target offscreen (blend mode / mask) HARUS sama dengan area gambar, kalau tidak lapisan blend meleset
        // dan muncul tepi putih di sekitar mulut / hidung.
        if (vw != rtW || vh != rtH) {
            m.setRenderTargetSize(vw, vh)
            rtW = vw
            rtH = vh
        }

        val offscreen = CubismOffscreenManagerAndroid.getInstance()
        offscreen.beginFrameProcess()

        // Pas: seluruh badan atas Karin muat penuh di area. Titik asal koordinat model sudah di tengah kanvas,
        // jadi TIDAK perlu setCenterPosition (itu yang bikin Karin melorot ke pojok kiri-bawah).
        val aspect = vw.toFloat() / vh.toFloat()
        val displayRatio = vh.toFloat() / vw.toFloat()
        proj.loadIdentity()
        val z = cfg.zoom * userScale
        if (m.canvasRatio() < displayRatio) {
            m.getModelMatrix().setWidth(2.0f * z)
            proj.scale(1.0f, aspect)
        } else {
            m.getModelMatrix().setHeight(2.0f * z)
            proj.scale(1.0f / aspect, 1.0f)
        }
        if (cfg.offsetY != 0f || dragX != 0f || dragY != 0f) proj.translate(dragX, cfg.offsetY + dragY)   // geser dalam satuan layar (2.0 = tinggi penuh)

        m.update(dt, anim)
        m.draw(proj)
        // simpan transformasi akhir (kanvas -> layar) untuk menerjemahkan sentuhan ke bagian tubuh
        val ar = proj.array
        val cm = m.getModel()
        xf = floatArrayOf(ar[0], ar[5], ar[12], ar[13], cm.canvasWidth, cm.canvasHeight, rsv.toFloat(), vh.toFloat(), h.toFloat(), w.toFloat())

        offscreen.endFrameProcess()
        offscreen.releaseStaleRenderTextures()

        drawCover()
        punchHoles()
        answerProbe()
    }

    /** Mode depan: hapus piksel avatar di atas kolom input / tombol (bentuk pil), jadi yang tampil lagi adalah kolom input di bawahnya. */
    private fun punchHoles() {
        val hs = holes
        if (!front || hs.size < 5) return
        GLES20.glBindFramebuffer(GLES20.GL_FRAMEBUFFER, 0)
        GLES20.glViewport(0, 0, w, h)
        GLES20.glEnable(GLES20.GL_SCISSOR_TEST)
        GLES20.glClearColor(0f, 0f, 0f, 0f)
        fun clr(x0: Float, y0: Float, x1: Float, y1: Float) {
            val ix0 = x0.toInt().coerceIn(0, w)
            val ix1 = x1.toInt().coerceIn(0, w)
            val iy0 = y0.toInt().coerceIn(0, h)
            val iy1 = y1.toInt().coerceIn(0, h)
            if (ix1 <= ix0 || iy1 <= iy0) return
            GLES20.glScissor(ix0, h - iy1, ix1 - ix0, iy1 - iy0)
            GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT)
        }
        var i = 0
        while (i + 4 < hs.size) {
            val l = hs[i]; val t = hs[i + 1]; val r = hs[i + 2]; val b = hs[i + 3]
            val rad = minOf(hs[i + 4], (b - t) / 2f, (r - l) / 2f)
            clr(l, t + rad, r, b - rad)
            val step = maxOf(4f, rad / 4f)
            var y = 0f
            while (y < rad) {
                val dy = rad - (y + step / 2f)
                val inset = rad - Math.sqrt((rad * rad - dy * dy).coerceAtLeast(0f).toDouble()).toFloat()
                clr(l + inset, t + y, r - inset, t + y + step)
                clr(l + inset, b - y - step, r - inset, b - y)
                y += step
            }
            i += 5
        }
        GLES20.glDisable(GLES20.GL_SCISSOR_TEST)
    }

    /** Jawab pertanyaan "apakah piksel ini badan avatar?" dengan membaca satu piksel dari frame yang baru digambar. */
    private fun answerProbe() {
        val pr = probe ?: return
        probe = null
        val cb = probeCb
        probeCb = null
        var hit = false
        try {
            GLES20.glBindFramebuffer(GLES20.GL_FRAMEBUFFER, 0)
            val buf = ByteBuffer.allocateDirect(4).order(ByteOrder.nativeOrder())
            val px = pr[0].toInt().coerceIn(0, w - 1)
            val py = (h - 1 - pr[1].toInt()).coerceIn(0, h - 1)
            GLES20.glReadPixels(px, py, 1, 1, GLES20.GL_RGBA, GLES20.GL_UNSIGNED_BYTE, buf)
            hit = (buf.get(3).toInt() and 0xff) > 10
        } catch (_: Throwable) {
        }
        cb?.invoke(hit)
    }
}
