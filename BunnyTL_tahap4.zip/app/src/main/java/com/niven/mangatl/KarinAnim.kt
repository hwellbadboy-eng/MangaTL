package com.niven.mangatl

import kotlin.math.PI
import kotlin.math.exp
import kotlin.math.sin
import kotlin.random.Random

/** Keadaan Karin. Diatur dari ChatActivity. */
enum class KarinState { IDLE, THINKING, LISTENING, SPEAKING }

/**
 * Pengatur gerak Karin. Model tidak punya file motion, jadi semua nilai parameter
 * (kepala, mata, alis, mulut, napas, kedip) dihitung di sini tiap frame.
 * Dipanggil dari thread GL lewat step(); yang diubah dari luar hanya state / touch / levelSource.
 */
class KarinAnim {
    @Volatile var state = KarinState.IDLE

    /** Sumber tingkat suara 0..1 (dipanggil tiap frame saat SPEAKING), untuk gerak mulut. */
    @Volatile var levelSource: (() -> Float)? = null

    @Volatile private var touching = false
    @Volatile private var touchHold = 0f
    @Volatile private var touchX = 0f
    @Volatile private var touchY = 0f

    // ---- hasil akhir (dibaca KarinModel) ----
    var angleX = 0f; var angleY = 0f; var angleZ = 0f
    var bodyX = 0f; var bodyY = 0f; var bodyZ = 0f
    var eyeX = 0f; var eyeY = 0f
    var eyeOpenL = 1f; var eyeOpenR = 1f
    var browL = 0f; var browR = 0f
    var mouthOpen = 0f; var mouthForm = 0f
    var smile = 0f
    var cheek = 0f
    var breath = 0f

    // ---- target pose (diganti tiap beberapa detik) ----
    private var tHeadX = 0f; private var tHeadY = 0f; private var tHeadZ = 0f
    private var tEyeX = 0f; private var tEyeY = 0f
    private var tBrow = 0f; private var tSmile = 0f; private var tMouthForm = 0f

    // ---- nilai halus yang mengejar target ----
    private var sHeadX = 0f; private var sHeadY = 0f; private var sHeadZ = 0f
    private var sEyeX = 0f; private var sEyeY = 0f
    private var sBrow = 0f; private var sSmile = 0f; private var sMouthForm = 0f

    private var t = 0f
    private var poseTimer = 0f
    private var lastState = KarinState.IDLE
    private var side = 1f
    private var nodT = -1f

    // ---- kedip ----
    private var blinkTimer = 2.5f
    private var blinkT = -1f
    private var pendingDouble = false

    /** Sentuhan: Karin menoleh dan menatap ke arah jari. nx, ny dalam -1..1 (y naik = atas). */
    fun touch(nx: Float, ny: Float, down: Boolean) {
        touchX = nx
        touchY = ny
        if (down) {
            touching = true
        } else {
            touching = false
            touchHold = 1.2f
        }
    }

    private fun rr(a: Float, b: Float): Float = a + Random.nextFloat() * (b - a)

    private fun pickPose(s: KarinState) {
        when (s) {
            KarinState.IDLE -> {
                poseTimer = rr(2.5f, 5.5f)
                tHeadX = rr(-6f, 6f); tHeadY = rr(-3f, 4f); tHeadZ = rr(-3f, 3f)
                if (Random.nextFloat() < 0.3f) {
                    // melirik sebentar, kepala ikut sedikit
                    tEyeX = rr(-0.6f, 0.6f); tEyeY = rr(-0.3f, 0.4f)
                    tHeadX = tHeadX * 0.5f + tEyeX * 10f
                } else {
                    tEyeX = rr(-0.1f, 0.1f); tEyeY = rr(-0.05f, 0.1f)
                }
                tBrow = 0f; tSmile = 0.15f; tMouthForm = 0.2f
            }
            KarinState.THINKING -> {
                if (Random.nextFloat() < 0.22f) {
                    // diam sebentar, mata ke atas
                    poseTimer = rr(0.8f, 1.4f)
                    tHeadX = 0f; tHeadY = rr(5f, 9f); tHeadZ = 0f
                    tEyeX = 0f; tEyeY = 0.6f
                } else {
                    // noleh kiri <-> kanan bergantian
                    poseTimer = rr(1.3f, 2.4f)
                    side = -side
                    tHeadX = side * rr(12f, 20f); tHeadY = rr(1f, 8f); tHeadZ = side * rr(3f, 7f)
                    tEyeX = side * rr(0.6f, 0.95f); tEyeY = rr(0.25f, 0.6f)
                }
                tBrow = rr(0.25f, 0.5f); tSmile = 0f; tMouthForm = 0f
            }
            KarinState.LISTENING -> {
                poseTimer = rr(1.8f, 3.5f)
                if (Random.nextFloat() < 0.3f) side = -side
                tHeadX = rr(-3f, 3f); tHeadY = rr(0f, 3f); tHeadZ = side * rr(4f, 7f)
                tEyeX = rr(-0.08f, 0.08f); tEyeY = rr(0f, 0.1f)
                tBrow = 0.2f; tSmile = 0.25f; tMouthForm = 0.3f
                if (Random.nextFloat() < 0.35f) nodT = 0f
            }
            KarinState.SPEAKING -> {
                poseTimer = rr(1.2f, 2.8f)
                tHeadX = rr(-5f, 5f); tHeadY = rr(-2f, 3f); tHeadZ = rr(-3f, 3f)
                if (Random.nextFloat() < 0.25f) {
                    tEyeX = rr(-0.4f, 0.4f); tEyeY = rr(-0.2f, 0.3f)
                } else {
                    tEyeX = rr(-0.08f, 0.08f); tEyeY = rr(-0.03f, 0.08f)
                }
                tBrow = 0.1f; tSmile = 0.2f; tMouthForm = 0.25f
            }
        }
    }

    private fun follow(cur: Float, target: Float, k: Float, dt: Float): Float =
        cur + (target - cur) * (1f - exp(-k * dt))

    fun step(dtIn: Float) {
        val dt = dtIn.coerceIn(0.001f, 0.1f)
        t += dt

        val s = state
        if (s != lastState) {
            lastState = s
            poseTimer = 0f
            nodT = -1f
        }
        poseTimer -= dt
        if (poseTimer <= 0f) pickPose(s)

        if (!touching && touchHold > 0f) touchHold -= dt
        val touched = touching || touchHold > 0f

        var hx = tHeadX; var hy = tHeadY; var hz = tHeadZ
        var ex = tEyeX; var ey = tEyeY
        var br = tBrow; var sm = tSmile; var mf = tMouthForm
        if (touched) {
            hx = touchX * 18f; hy = touchY * 10f; hz = -touchX * 4f
            ex = touchX; ey = touchY * 0.8f
            br = 0.2f; sm = 0.4f; mf = 0.35f
        }

        val kHead = if (touched) 7f else if (s == KarinState.THINKING) 4.5f else 3f
        sHeadX = follow(sHeadX, hx, kHead, dt)
        sHeadY = follow(sHeadY, hy, kHead, dt)
        sHeadZ = follow(sHeadZ, hz, kHead * 0.8f, dt)
        sEyeX = follow(sEyeX, ex, 12f, dt)
        sEyeY = follow(sEyeY, ey, 12f, dt)
        sBrow = follow(sBrow, br, 6f, dt)
        sSmile = follow(sSmile, sm, 4f, dt)
        sMouthForm = follow(sMouthForm, mf, 5f, dt)

        // mulut: ikut suara kalau sedang bicara
        val level = if (s == KarinState.SPEAKING) (levelSource?.invoke() ?: 0f).coerceIn(0f, 1f) else 0f
        mouthOpen = follow(mouthOpen, level, if (level > mouthOpen) 28f else 14f, dt)

        // anggukan kecil saat mendengar
        var nod = 0f
        if (nodT >= 0f) {
            nodT += dt
            val d = 0.7f
            if (nodT >= d) nodT = -1f else nod = -7f * sin(PI.toFloat() * nodT / d)
        }

        // kedip acak
        if (blinkT < 0f) {
            blinkTimer -= dt
            if (blinkTimer <= 0f) blinkT = 0f
        } else {
            blinkT += dt
            if (blinkT >= 0.2f) {
                blinkT = -1f
                if (pendingDouble) {
                    pendingDouble = false
                    blinkTimer = 0.1f
                } else {
                    blinkTimer = rr(2.6f, 6f)
                    pendingDouble = Random.nextFloat() < 0.15f
                }
            }
        }
        val closed = when {
            blinkT < 0f -> 0f
            blinkT < 0.08f -> blinkT / 0.08f
            else -> 1f - (blinkT - 0.08f) / 0.12f
        }.coerceIn(0f, 1f)

        // gabungkan: pose + goyangan halus (napas, melayang)
        angleX = sHeadX + 1.2f * sin(t * 0.55f)
        angleY = sHeadY + 1.0f * sin(t * 1.3f) + mouthOpen * 2.2f + nod
        angleZ = sHeadZ + 0.9f * sin(t * 0.45f + 1f)
        bodyX = sHeadX * 0.35f + 1.2f * sin(t * 0.6f + 0.5f)
        bodyY = sHeadY * 0.25f + 0.8f * sin(t * 1.5f)
        bodyZ = sHeadZ * 0.3f + 0.6f * sin(t * 0.5f)
        eyeX = sEyeX
        eyeY = sEyeY
        eyeOpenL = 1f - closed
        eyeOpenR = 1f - closed
        browL = sBrow + mouthOpen * 0.25f
        browR = sBrow + mouthOpen * 0.25f
        smile = sSmile
        mouthForm = sMouthForm
        cheek = sSmile * 0.5f
        breath = 0.5f + 0.5f * sin(t * 1.5f)
    }
}
