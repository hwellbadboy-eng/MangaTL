package com.niven.mangatl

import android.os.SystemClock
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.ConcurrentLinkedQueue
import kotlin.math.PI
import kotlin.math.exp
import kotlin.math.sin
import kotlin.random.Random

/** Keadaan Karin. Diatur dari ChatActivity. */
enum class KarinState { IDLE, THINKING, LISTENING, SPEAKING }

/**
 * Pengatur gerak Karin. Model tidak punya file motion, jadi semua nilai parameter
 * (kepala, mata, alis, mulut, napas, kedip) dihitung di sini tiap frame.
 * Dipanggil dari thread GL lewat step(); yang diubah dari luar hanya state / touch / levelSource.
 */
class KarinAnim {
    @Volatile var state = KarinState.IDLE

    /** Sumber tingkat suara 0..1 (dipanggil tiap frame saat SPEAKING), untuk gerak mulut. */
    @Volatile var levelSource: (() -> Float)? = null

    // ---- ekspresi (pipi merah, marah, dll). Dipicu dari emoji atau dialog; di-fade halus tiap frame. ----
    private class Slot {
        @Volatile var until = 0L      // uptimeMillis sampai kapan menyala
        @Volatile var hold = false    // ditahan manual (dari dialog)
        @Volatile var w = 0f          // bobot saat ini 0..1
    }
    private val slots = ConcurrentHashMap<String, Slot>()

    /** Nyalakan ekspresi sementara. Ekspresi emosi lain dimatikan dulu supaya tidak bertumpuk. */
    fun triggerExpr(key: String, seconds: Float) {
        if (Emotion.isEmotion(key)) {
            for ((k, sl) in slots) if (k != key && Emotion.isEmotion(k)) sl.until = 0L
        }
        slots.getOrPut(key) { Slot() }.until = SystemClock.uptimeMillis() + (seconds * 1000).toLong()
    }

    fun setExprHold(key: String, on: Boolean) {
        slots.getOrPut(key) { Slot() }.hold = on
    }

    fun isExprHeld(key: String): Boolean = slots[key]?.hold == true

    fun exprWeight(key: String): Float = slots[key]?.w ?: 0f

    @Volatile private var touching = false
    @Volatile private var touchHold = 0f
    @Volatile private var touchX = 0f
    @Volatile private var touchY = 0f

    // ---- reaksi fisik: pegas (mantul), geseran, sentuhan ----
    /** true kalau model punya parameter posisi (ParamAnglePX/PY); kalau tidak, dorongan dialihkan ke sudut kepala. */
    @Volatile var usePos = false

    private class Spring {
        var x = 0f
        var v = 0f
    }
    private val spPX = Spring()
    private val spPY = Spring()
    private val spAY = Spring()
    private val spAZ = Spring()
    private val spBR = Spring()
    private class Poke(val kind: String, val strength: Float)
    private val pokes = ConcurrentLinkedQueue<Poke>()

    /** Sentuhan pada bagian tubuh: "bounce" (dada), "sway" (pinggang), "jiggle" (paha), "pat" (kepala). Aman dipanggil dari thread mana pun. */
    fun poke(kind: String, strength: Float) {
        pokes.add(Poke(kind, strength))
    }

    @Volatile private var tvx = 0f
    @Volatile private var tvy = 0f
    @Volatile private var lastMoveMs = 0L
    private var mvx = 0f
    private var mvy = 0f

    /** Kecepatan geseran avatar (satuan layar per detik). Dipanggil tiap jari bergerak. */
    fun dragMove(vx: Float, vy: Float) {
        tvx = vx
        tvy = vy
        lastMoveMs = SystemClock.uptimeMillis()
    }

    private fun spring(sp: Spring, dt: Float, k: Float, c: Float) {
        val a = -k * sp.x - c * sp.v
        sp.v += a * dt
        sp.x += sp.v * dt
        if (kotlin.math.abs(sp.x) < 0.0005f && kotlin.math.abs(sp.v) < 0.005f) {
            sp.x = 0f
            sp.v = 0f
        }
    }

    // ---- hasil akhir (dibaca KarinModel) ----
    var posX = 0f; var posY = 0f
    var angleX = 0f; var angleY = 0f; var angleZ = 0f
    var bodyX = 0f; var bodyY = 0f; var bodyZ = 0f
    var eyeX = 0f; var eyeY = 0f
    var eyeOpenL = 1f; var eyeOpenR = 1f
    var browL = 0f; var browR = 0f
    var mouthOpen = 0f; var mouthForm = 0f
    var smile = 0f
    var cheek = 0f
    var breath = 0f

    // ---- target pose (diganti tiap beberapa detik) ----
    private var tHeadX = 0f; private var tHeadY = 0f; private var tHeadZ = 0f
    private var tEyeX = 0f; private var tEyeY = 0f
    private var tBrow = 0f; private var tSmile = 0f; private var tMouthForm = 0f

    // ---- nilai halus yang mengejar target ----
    private var sHeadX = 0f; private var sHeadY = 0f; private var sHeadZ = 0f
    private var sEyeX = 0f; private var sEyeY = 0f
    private var sBrow = 0f; private var sSmile = 0f; private var sMouthForm = 0f

    private var t = 0f
    private var poseTimer = 0f
    private var lastState = KarinState.IDLE
    private var side = 1f
    private var nodT = -1f

    // ---- kedip ----
    private var blinkTimer = 2.5f
    private var blinkT = -1f
    private var pendingDouble = false

    /** Sentuhan: Karin menoleh dan menatap ke arah jari. nx, ny dalam -1..1 (y naik = atas). */
    fun touch(nx: Float, ny: Float, down: Boolean) {
        touchX = nx
        touchY = ny
        if (down) {
            touching = true
        } else {
            touching = false
            touchHold = 1.2f
        }
    }

    private fun rr(a: Float, b: Float): Float = a + Random.nextFloat() * (b - a)

    private fun pickPose(s: KarinState) {
        when (s) {
            KarinState.IDLE -> {
                poseTimer = rr(2.5f, 5.5f)
                tHeadX = rr(-6f, 6f); tHeadY = rr(-3f, 4f); tHeadZ = rr(-3f, 3f)
                if (Random.nextFloat() < 0.3f) {
                    // melirik sebentar, kepala ikut sedikit
                    tEyeX = rr(-0.6f, 0.6f); tEyeY = rr(-0.3f, 0.4f)
                    tHeadX = tHeadX * 0.5f + tEyeX * 10f
                } else {
                    tEyeX = rr(-0.1f, 0.1f); tEyeY = rr(-0.05f, 0.1f)
                }
                tBrow = 0f; tSmile = 0.15f; tMouthForm = 0.2f
            }
            KarinState.THINKING -> {
                if (Random.nextFloat() < 0.22f) {
                    // diam sebentar, mata ke atas
                    poseTimer = rr(0.8f, 1.4f)
                    tHeadX = 0f; tHeadY = rr(5f, 9f); tHeadZ = 0f
                    tEyeX = 0f; tEyeY = 0.6f
                } else {
                    // noleh kiri <-> kanan bergantian
                    poseTimer = rr(1.3f, 2.4f)
                    side = -side
                    tHeadX = side * rr(12f, 20f); tHeadY = rr(1f, 8f); tHeadZ = side * rr(3f, 7f)
                    tEyeX = side * rr(0.6f, 0.95f); tEyeY = rr(0.25f, 0.6f)
                }
                tBrow = rr(0.25f, 0.5f); tSmile = 0f; tMouthForm = 0f
            }
            KarinState.LISTENING -> {
                poseTimer = rr(1.8f, 3.5f)
                if (Random.nextFloat() < 0.3f) side = -side
                tHeadX = rr(-3f, 3f); tHeadY = rr(0f, 3f); tHeadZ = side * rr(4f, 7f)
                tEyeX = rr(-0.08f, 0.08f); tEyeY = rr(0f, 0.1f)
                tBrow = 0.2f; tSmile = 0.25f; tMouthForm = 0.3f
                if (Random.nextFloat() < 0.35f) nodT = 0f
            }
            KarinState.SPEAKING -> {
                poseTimer = rr(1.2f, 2.8f)
                tHeadX = rr(-5f, 5f); tHeadY = rr(-2f, 3f); tHeadZ = rr(-3f, 3f)
                if (Random.nextFloat() < 0.25f) {
                    tEyeX = rr(-0.4f, 0.4f); tEyeY = rr(-0.2f, 0.3f)
                } else {
                    tEyeX = rr(-0.08f, 0.08f); tEyeY = rr(-0.03f, 0.08f)
                }
                tBrow = 0.1f; tSmile = 0.2f; tMouthForm = 0.25f
            }
        }
    }

    private fun follow(cur: Float, target: Float, k: Float, dt: Float): Float =
        cur + (target - cur) * (1f - exp(-k * dt))

    fun step(dtIn: Float) {
        val dt = dtIn.coerceIn(0.001f, 0.1f)
        t += dt

        val s = state
        if (s != lastState) {
            lastState = s
            poseTimer = 0f
            nodT = -1f
        }
        poseTimer -= dt
        if (poseTimer <= 0f) pickPose(s)

        if (!touching && touchHold > 0f) touchHold -= dt
        val touched = touching || touchHold > 0f

        var hx = tHeadX; var hy = tHeadY; var hz = tHeadZ
        var ex = tEyeX; var ey = tEyeY
        var br = tBrow; var sm = tSmile; var mf = tMouthForm
        if (touched) {
            hx = touchX * 18f; hy = touchY * 10f; hz = -touchX * 4f
            ex = touchX; ey = touchY * 0.8f
            br = 0.2f; sm = 0.4f; mf = 0.35f
        }

        val kHead = if (touched) 7f else if (s == KarinState.THINKING) 4.5f else 3f
        sHeadX = follow(sHeadX, hx, kHead, dt)
        sHeadY = follow(sHeadY, hy, kHead, dt)
        sHeadZ = follow(sHeadZ, hz, kHead * 0.8f, dt)
        sEyeX = follow(sEyeX, ex, 12f, dt)
        sEyeY = follow(sEyeY, ey, 12f, dt)
        sBrow = follow(sBrow, br, 6f, dt)
        sSmile = follow(sSmile, sm, 4f, dt)
        sMouthForm = follow(sMouthForm, mf, 5f, dt)

        // mulut: ikut suara kalau sedang bicara
        val level = if (s == KarinState.SPEAKING) (levelSource?.invoke() ?: 0f).coerceIn(0f, 1f) else 0f
        mouthOpen = follow(mouthOpen, level, if (level > mouthOpen) 28f else 14f, dt)

        // anggukan kecil saat mendengar
        var nod = 0f
        if (nodT >= 0f) {
            nodT += dt
            val d = 0.7f
            if (nodT >= d) nodT = -1f else nod = -7f * sin(PI.toFloat() * nodT / d)
        }

        // kedip acak
        if (blinkT < 0f) {
            blinkTimer -= dt
            if (blinkTimer <= 0f) blinkT = 0f
        } else {
            blinkT += dt
            if (blinkT >= 0.2f) {
                blinkT = -1f
                if (pendingDouble) {
                    pendingDouble = false
                    blinkTimer = 0.1f
                } else {
                    blinkTimer = rr(2.6f, 6f)
                    pendingDouble = Random.nextFloat() < 0.15f
                }
            }
        }
        val closed = when {
            blinkT < 0f -> 0f
            blinkT < 0.08f -> blinkT / 0.08f
            else -> 1f - (blinkT - 0.08f) / 0.12f
        }.coerceIn(0f, 1f)

        // bobot ekspresi
        val nowMs = SystemClock.uptimeMillis()
        for (sl in slots.values) {
            val target = if (sl.hold || nowMs < sl.until) 1f else 0f
            sl.w = follow(sl.w, target, if (target > sl.w) 7f else 3.5f, dt)
            if (target == 0f && sl.w < 0.003f) sl.w = 0f
        }

        // ---- sentuhan -> dorongan pegas (physics model yang membuatnya mantul) ----
        while (true) {
            val pk = pokes.poll() ?: break
            val sgn = if (Random.nextBoolean()) 1f else -1f
            val sv = pk.strength
            when (pk.kind) {
                "bounce" -> {            // dada: naik-turun beberapa kali
                    spPY.v += -230f * sv
                    spAY.v += -70f * sv
                    spBR.v += 6f * sv
                }
                "sway" -> {              // pinggang / pinggul: goyang samping
                    spPX.v += 210f * sv * sgn
                    spAZ.v += 90f * sv * -sgn
                    spPY.v += -60f * sv
                }
                "jiggle" -> {            // paha: goyang + sedikit memantul
                    spAZ.v += 170f * sv * sgn
                    spPY.v += -140f * sv
                    spPX.v += 80f * sv * -sgn
                }
                "pat" -> {               // kepala ditepuk: menunduk sebentar
                    spAY.v += -120f * sv
                    spAZ.v += 60f * sv * sgn
                }
            }
        }
        spring(spPX, dt, 300f, 6.5f)
        spring(spPY, dt, 300f, 6.5f)
        spring(spAY, dt, 260f, 7f)
        spring(spAZ, dt, 220f, 6f)
        spring(spBR, dt, 320f, 7f)

        // ---- geseran avatar -> kelembaman: badan, rambut, ekor ikut terayun ----
        val moving = SystemClock.uptimeMillis() - lastMoveMs < 90L
        mvx = follow(mvx, if (moving) tvx else 0f, 10f, dt)
        mvy = follow(mvy, if (moving) tvy else 0f, 10f, dt)
        val dragPX = (mvx * 14f).coerceIn(-28f, 28f)
        val dragPY = (mvy * 14f).coerceIn(-28f, 28f)

        // gabungkan: pose + goyangan halus (napas, melayang)
        angleX = sHeadX + 1.2f * sin(t * 0.55f)
        angleY = sHeadY + 1.0f * sin(t * 1.3f) + mouthOpen * 2.2f + nod
        angleZ = sHeadZ + 0.9f * sin(t * 0.45f + 1f)
        bodyX = sHeadX * 0.35f + 1.2f * sin(t * 0.6f + 0.5f)
        bodyY = sHeadY * 0.25f + 0.8f * sin(t * 1.5f)
        bodyZ = sHeadZ * 0.3f + 0.6f * sin(t * 0.5f)
        eyeX = sEyeX
        eyeY = sEyeY
        eyeOpenL = 1f - closed
        eyeOpenR = 1f - closed
        browL = sBrow + mouthOpen * 0.25f
        browR = sBrow + mouthOpen * 0.25f
        smile = sSmile
        mouthForm = sMouthForm
        cheek = sSmile * 0.5f
        breath = (0.5f + 0.5f * sin(t * 1.5f) + spBR.x).coerceIn(0f, 1f)

        // reaksi fisik ditumpuk di atas pose
        val px = spPX.x + dragPX
        val py = spPY.x + dragPY
        angleY += spAY.x
        angleZ += spAZ.x - mvx * 3f
        if (usePos) {
            posX = px.coerceIn(-30f, 30f)
            posY = py.coerceIn(-30f, 30f)
        } else {
            posX = 0f
            posY = 0f
            angleX += px * 0.35f
            angleY += py * 0.35f
        }
    }
}
