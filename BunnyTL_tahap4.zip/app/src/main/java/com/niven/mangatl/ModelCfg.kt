package com.niven.mangatl

import android.content.Context
import org.json.JSONObject

/**
 * Konfigurasi satu model Live2D: assets/models/<id>/model.json.
 * Menambah model baru = taruh folder baru + daftarkan id-nya di assets/models/index.json.
 *
 *  layout "stage": avatar di panggung atas dengan sobekan kertas (bust, mis. Karin)
 *  layout "full" : avatar full body di belakang/depan chat (mis. Jian)
 */
/** Zona sentuh pada kanvas model (pecahan 0..1 dari kiri-atas kanvas) beserta reaksinya. */
class TouchZone(
    val name: String,
    val x0: Float, val x1: Float,
    val y0: Float, val y1: Float,
    val react: String,
    val strength: Float,
    val expr: String
)

class ModelCfg(
    val id: String,
    val dir: String,
    val name: String,
    val full: Boolean,
    val fps: Int,
    val moc: String,
    val physics: String,
    val motion: String,
    val textures: List<String>,
    val zoom: Float,
    val offsetY: Float,
    val params: Map<String, String>,
    val expressions: Map<String, List<Pair<String, Float>>>,
    /** Mode full: garis tempat chat memudar & hilang, sebagai pecahan tinggi layar dari atas. */
    val chatTop: Float,
    /** Mode full: panjang pudar chat (dp) di bawah garis itu. */
    val fadeDp: Float,
    val touch: List<TouchZone>,
    /** Ukuran buffer mask clipping (px). 0 = bawaan SDK (256). Model rumit yang di-zoom butuh 1024. */
    val maskSize: Int
) {
    fun texturePaths(): List<String> = textures.map { dir + it }
    fun frameMs(): Long = (1000f / fps.coerceIn(10, 60)).toLong()

    companion object {
        /** Daftar (id, nama tampilan) semua model. */
        fun list(ctx: Context): List<Pair<String, String>> {
            val ids = org.json.JSONArray(ctx.assets.open("models/index.json").bufferedReader().readText())
            val out = ArrayList<Pair<String, String>>()
            for (i in 0 until ids.length()) {
                val id = ids.getString(i)
                try {
                    out.add(id to load(ctx, id).name)
                } catch (_: Throwable) {
                }
            }
            return out
        }

        fun load(ctx: Context, id: String): ModelCfg {
            val dir = "models/$id/"
            val j = JSONObject(ctx.assets.open(dir + "model.json").bufferedReader().readText())
            val tx = j.getJSONArray("textures")
            val textures = (0 until tx.length()).map { tx.getString(it) }
            val pj = j.getJSONObject("params")
            val params = HashMap<String, String>()
            for (k in pj.keys()) params[k] = pj.getString(k)
            val ej = j.optJSONObject("expressions")
            val ex = LinkedHashMap<String, List<Pair<String, Float>>>()
            if (ej != null) {
                for (k in ej.keys()) {
                    val arr = ej.getJSONArray(k)
                    ex[k] = (0 until arr.length()).map {
                        val p = arr.getJSONArray(it)
                        p.getString(0) to p.getDouble(1).toFloat()
                    }
                }
            }
            val tj = j.optJSONArray("touch")
            val zones = ArrayList<TouchZone>()
            if (tj != null) {
                for (i in 0 until tj.length()) {
                    val z = tj.getJSONObject(i)
                    val xs = z.getJSONArray("x")
                    val ys = z.getJSONArray("y")
                    zones.add(
                        TouchZone(
                            z.optString("name", "zone$i"),
                            xs.getDouble(0).toFloat(), xs.getDouble(1).toFloat(),
                            ys.getDouble(0).toFloat(), ys.getDouble(1).toFloat(),
                            z.optString("react", "bounce"),
                            z.optDouble("strength", 1.0).toFloat(),
                            z.optString("expr", "")
                        )
                    )
                }
            }
            val fr = j.optJSONObject("frame")
            return ModelCfg(
                id = id,
                dir = dir,
                name = j.optString("name", id),
                full = j.optString("layout", "stage") == "full",
                fps = j.optInt("fps", 30),
                moc = j.getString("moc"),
                physics = j.optString("physics", ""),
                motion = j.optString("motion", ""),
                textures = textures,
                zoom = fr?.optDouble("zoom", 1.0)?.toFloat() ?: 1f,
                offsetY = fr?.optDouble("offsetY", 0.0)?.toFloat() ?: 0f,
                params = params,
                expressions = ex,
                chatTop = j.optDouble("chatTop", 0.44).toFloat(),
                fadeDp = j.optDouble("fadeDp", 90.0).toFloat(),
                touch = zones,
                maskSize = j.optInt("maskSize", 0)
            )
        }
    }
}
