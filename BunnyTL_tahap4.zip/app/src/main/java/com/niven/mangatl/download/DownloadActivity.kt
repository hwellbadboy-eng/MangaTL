package com.niven.mangatl

import android.Manifest
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.ConnectivityManager
import android.os.Build
import android.os.Bundle
import android.text.InputType
import android.text.TextUtils
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.ViewOutlineProvider
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.google.android.material.button.MaterialButton
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/** Layar Unduh (dari menu utama): tempel link, pilih kualitas, lihat antrean, perbarui mesin. */
class DownloadActivity : AppCompatActivity() {
    private lateinit var etUrl: EditText
    private lateinit var pickerBox: LinearLayout
    private lateinit var tabBox: LinearLayout
    private lateinit var listBox: LinearLayout
    /** 0 = Unduh (berjalan/antre/gagal), 1 = Musik selesai, 2 = Video selesai. */
    private var tab = 0
    private var loginTask: DlTask? = null
    private lateinit var tvEngine: TextView
    private lateinit var picker: DlPicker
    private var pending: List<DlTask>? = null

    private val refresh: () -> Unit = { renderTasks() }

    private val loginResult = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        val t = loginTask
        loginTask = null
        if (r.resultCode == RESULT_OK && t != null) DlQueue.retry(this, t)
    }

    private val notifPerm = registerForActivityResult(ActivityResultContracts.RequestPermission()) {
        pending?.let { go(it) }
    }

    private fun dp(v: Int) = Ui.dp(this, v)
    private val soft = Color.parseColor("#C7C7CC")
    private val muted = Color.parseColor("#8E8E93")
    private val green = Color.parseColor("#34C759")
    private val red = Color.parseColor("#FF453A")

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        DlQueue.init(this)

        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(12), dp(16), dp(24))
        }

        // bar atas
        val bar = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        bar.addView(Ui.iconBtn(this, R.drawable.ic_back, "Kembali") { finish() },
            LinearLayout.LayoutParams(dp(44), dp(44)))
        bar.addView(TextView(this).apply {
            text = "Unduh"
            textSize = 22f
            setTextColor(Color.WHITE)
            typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
        }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { marginStart = dp(8) })
        col.addView(bar)

        // kolom link
        etUrl = EditText(this).apply {
            hint = "Tempel link video atau musik"
            setHintTextColor(Color.parseColor("#6E6E73"))
            setTextColor(Color.WHITE)
            textSize = 14f
            maxLines = 2
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_URI
            setBackgroundResource(R.drawable.bg_field)
            setPadding(dp(14), dp(12), dp(14), dp(12))
        }
        col.addView(etUrl, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            .apply { topMargin = dp(14) })

        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        row.addView(button("Tempel", outlined = true) { paste() },
            LinearLayout.LayoutParams(0, dp(48), 1f))
        row.addView(button("Cari kualitas", outlined = false) { search() },
            LinearLayout.LayoutParams(0, dp(48), 1.4f).apply { marginStart = dp(8) })
        col.addView(row, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            .apply { topMargin = dp(10) })

        // panel pilih kualitas
        picker = DlPicker(this) { start(it) }
        pickerBox = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundResource(R.drawable.bg_card)
            setPadding(dp(14), dp(14), dp(14), dp(14))
            visibility = View.GONE
            addView(picker.root)
        }
        col.addView(pickerBox, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            .apply { topMargin = dp(14) })

        // kategori: Unduh / Musik / Video
        tabBox = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        col.addView(tabBox, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            .apply { topMargin = dp(18); bottomMargin = dp(10) })
        listBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        col.addView(listBox)

        // mesin
        tvEngine = TextView(this).apply {
            textSize = 12f
            setTextColor(muted)
            setPadding(dp(4), dp(20), 0, dp(6))
        }
        col.addView(tvEngine)
        col.addView(button("Perbarui mesin unduh", outlined = true) { updateEngine() },
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(46)))
        col.addView(button("Login manual (langsung buka web login)", outlined = false) { openLogin() },
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(46)).apply { topMargin = dp(8) })
        col.addView(button("Akun & cookies", outlined = true) {
            startActivity(Intent(this, CookiesActivity::class.java))
        }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(46)).apply { topMargin = dp(8) })

        setContentView(ScrollView(this).apply {
            setBackgroundColor(Color.BLACK)
            isFillViewport = true
            addView(col)
        })

        intent.getStringExtra("url")?.let { etUrl.setText(it) }
        showEngine()
        prewarm()
    }

    override fun onStart() {
        super.onStart()
        DlQueue.addListener(refresh)
        renderTasks()
    }

    override fun onStop() {
        DlQueue.removeListener(refresh)
        super.onStop()
    }

    // ---------------------------------------------------------------- aksi

    private fun button(label: String, outlined: Boolean, onClick: () -> Unit) = MaterialButton(
        this, null,
        if (outlined) com.google.android.material.R.attr.materialButtonOutlinedStyle
        else com.google.android.material.R.attr.materialButtonStyle
    ).apply {
        text = label
        isAllCaps = false
        cornerRadius = dp(24)
        setOnClickListener { onClick() }
    }

    private fun paste() {
        val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        val t = cm.primaryClip?.takeIf { it.itemCount > 0 }?.getItemAt(0)?.coerceToText(this)?.toString()
        if (t.isNullOrBlank()) Toast.makeText(this, "Clipboard kosong.", Toast.LENGTH_SHORT).show()
        else etUrl.setText(t.trim())
    }

    /** Tombol login manual: langsung ke web login situs dari link di kolom (kalau kosong: situs terakhir, lalu YouTube). */
    private fun openLogin() {
        val u = DlUrl.extract(Intent().putExtra(Intent.EXTRA_TEXT, etUrl.text.toString()))
        startActivity(
            Intent(this, CookiesActivity::class.java)
                .putExtra(CookiesActivity.EXTRA_AUTO_WEB, true)
                .putExtra(CookiesActivity.EXTRA_LOGIN_URL, DlCookies.loginUrlFor(this, u))
        )
    }

    private fun search() {
        val i = Intent().putExtra(Intent.EXTRA_TEXT, etUrl.text.toString())
        val u = DlUrl.extract(i)
        if (u == null) {
            Toast.makeText(this, "Isi dulu link yang benar (http/https).", Toast.LENGTH_SHORT).show()
            return
        }
        pickerBox.visibility = View.VISIBLE
        picker.load(u)
    }

    private fun start(tasks: List<DlTask>) {
        val needAsk = Build.VERSION.SDK_INT >= 33 && !DlPrefs.notifAsked(this) &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        if (needAsk) {
            DlPrefs.setNotifAsked(this)
            pending = tasks
            notifPerm.launch(Manifest.permission.POST_NOTIFICATIONS)
        } else {
            go(tasks)
        }
    }

    private fun go(tasks: List<DlTask>) {
        pending = null
        tasks.forEach { DlQueue.enqueue(this, it) }
        pickerBox.visibility = View.GONE
        etUrl.setText("")
        tab = 0
        renderTasks()
        Toast.makeText(this,
            if (tasks.size == 1) "Ditambahkan ke antrean" else "${tasks.size} item ditambahkan ke antrean",
            Toast.LENGTH_SHORT).show()
    }

    private fun showEngine() {
        tvEngine.text = if (DlEngine.version.isEmpty()) "Mesin unduh: yt-dlp (menyiapkan…)"
        else "Mesin unduh: yt-dlp ${DlEngine.version}"
    }

    /** Siapkan mesin di latar begitu layar dibuka, dan perbarui otomatis tiap ~12 jam kalau bukan kuota. */
    private fun prewarm() {
        lifecycleScope.launch(Dispatchers.IO) {
            runCatching { DlEngine.ensureReady(this@DownloadActivity) }
            withContext(Dispatchers.Main) { showEngine() }
            val cm = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
            val stale = System.currentTimeMillis() - DlPrefs.lastUpdate(this@DownloadActivity) > 12L * 3600 * 1000
            if (DlEngine.version.isNotEmpty() && stale && !cm.isActiveNetworkMetered) {
                runCatching { DlUpdater.update(this@DownloadActivity) }
                DlPrefs.setLastUpdate(this@DownloadActivity, System.currentTimeMillis())
                withContext(Dispatchers.Main) { showEngine() }
            }
        }
    }

    private fun updateEngine() {
        Toast.makeText(this, "Memperbarui mesin unduh…", Toast.LENGTH_SHORT).show()
        lifecycleScope.launch {
            val msg = withContext(Dispatchers.IO) {
                runCatching {
                    DlEngine.ensureReady(this@DownloadActivity)
                    val r = DlUpdater.update(this@DownloadActivity)
                    DlPrefs.setLastUpdate(this@DownloadActivity, System.currentTimeMillis())
                    DlUpdater.message(r)
                }.getOrElse { DlEngine.friendlyError(it) }
            }
            showEngine()
            Toast.makeText(this@DownloadActivity, msg, Toast.LENGTH_LONG).show()
        }
    }

    // ---------------------------------------------------------------- daftar

    private fun rank(s: DlTask.State) = when (s) {
        DlTask.State.RUNNING -> 0
        DlTask.State.QUEUED -> 1
        DlTask.State.FAILED -> 2
        else -> 3
    }

    private fun renderTasks() {
        val all = DlQueue.tasks.toList()
        val dl = all.filter { it.state != DlTask.State.DONE }.sortedBy { rank(it.state) }
        val mus = all.filter { it.state == DlTask.State.DONE && it.audio }.sortedByDescending { it.finishedAt }
        val vid = all.filter { it.state == DlTask.State.DONE && !it.audio }.sortedByDescending { it.finishedAt }
        renderTabs(dl.size, mus.size, vid.size)

        listBox.removeAllViews()
        val shown = when (tab) { 0 -> dl; 1 -> mus; else -> vid }
        if (shown.isEmpty()) {
            listBox.addView(TextView(this).apply {
                text = when (tab) {
                    0 -> "Tidak ada unduhan berjalan. Tempel link video, musik, atau playlist di atas, atau bagikan link dari app lain ke BunnyTL."
                    1 -> "Belum ada musik yang selesai diunduh."
                    else -> "Belum ada video yang selesai diunduh."
                }
                textSize = 13f
                setTextColor(muted)
                setLineSpacing(0f, 1.15f)
                setPadding(dp(4), dp(4), dp(4), dp(4))
            })
            return
        }
        shown.forEach { listBox.addView(taskRow(it), LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
        ).apply { bottomMargin = dp(8) }) }
    }

    private fun renderTabs(nDl: Int, nMus: Int, nVid: Int) {
        tabBox.removeAllViews()
        val items = listOf("Unduh" to nDl, "Musik" to nMus, "Video" to nVid)
        items.forEachIndexed { i, (label, n) ->
            val sel = i == tab
            tabBox.addView(TextView(this).apply {
                text = if (n > 0) "$label · $n" else label
                textSize = 13f
                gravity = Gravity.CENTER
                typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
                setTextColor(if (sel) Color.BLACK else soft)
                background = GradientDrawable().apply {
                    cornerRadius = dp(18).toFloat()
                    setColor(if (sel) Color.WHITE else Color.parseColor("#1C1C1E"))
                }
                setPadding(dp(8), dp(9), dp(8), dp(9))
                isClickable = true
                setOnClickListener { tab = i; renderTasks() }
            }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { if (i > 0) marginStart = dp(8) })
        }
    }

    private fun thumbView(t: DlTask): View {
        val w = if (t.audio) dp(64) else dp(104)
        val h = if (t.audio) dp(64) else dp(58)
        val frame = FrameLayout(this).apply {
            background = GradientDrawable().apply { cornerRadius = dp(10).toFloat(); setColor(Color.parseColor("#1C1C1E")) }
            clipToOutline = true
            outlineProvider = ViewOutlineProvider.BACKGROUND
        }
        val u = t.thumb.ifEmpty { DlThumbs.guess(t.url) }
        val bmp = if (u.isEmpty()) null else DlThumbs.get(u)
        if (bmp != null) {
            frame.addView(ImageView(this).apply {
                scaleType = ImageView.ScaleType.CENTER_CROP
                setImageBitmap(bmp)
            }, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        } else {
            frame.addView(TextView(this).apply {
                text = if (t.audio) "♪" else "▶"
                textSize = 20f
                setTextColor(muted)
                gravity = Gravity.CENTER
            }, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
            if (u.isNotEmpty()) DlThumbs.fetch(u) { if (!isDestroyed) renderTasks() }
        }
        return frame.also { it.layoutParams = LinearLayout.LayoutParams(w, h) }
    }

    /** "MP4 · 1080p · H.264 · 48.2 MB" — ukuran pasti kalau sudah jadi, perkiraan (~) kalau belum. */
    private fun metaText(t: DlTask): String {
        val size = if (t.bytes > 0) DlOptions.sizeExact(t.bytes) else DlOptions.sizeText(t.estBytes)
        return listOf(t.fmt, t.quality, size).filter { it.isNotEmpty() }.joinToString(" · ")
    }

    private fun taskRow(t: DlTask): View {
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundResource(R.drawable.bg_card)
            setPadding(dp(10), dp(10), dp(10), dp(4))
        }
        val top = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        top.addView(thumbView(t))
        val info = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        info.addView(TextView(this).apply {
            text = t.title
            textSize = 14f
            setTextColor(Color.WHITE)
            maxLines = 2
            ellipsize = TextUtils.TruncateAt.END
        })
        val meta = metaText(t)
        if (meta.isNotEmpty()) info.addView(TextView(this).apply {
            text = meta
            textSize = 12f
            setTextColor(soft)
            maxLines = 1
            ellipsize = TextUtils.TruncateAt.END
            setPadding(0, dp(3), 0, 0)
        })
        fun status(text: String, color: Int, bold: Boolean = false) = info.addView(TextView(this).apply {
            this.text = text
            textSize = 12f
            setTextColor(color)
            if (bold) typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
            setPadding(0, dp(3), 0, 0)
        })
        val clock = DlOptions.clock(t.finishedAt)
        when (t.state) {
            DlTask.State.QUEUED -> status("Menunggu antrean", muted)
            DlTask.State.RUNNING -> {
                val pct = if (t.progress > 0f) " ${t.progress.toInt().coerceIn(0, 99)}%" else ""
                val eta = if (t.eta > 0) " · sisa ${DlOptions.duration(t.eta)}" else ""
                status("${t.note}$pct$eta", soft)
                val detail = listOf(DlOptions.progressText(t.doneBytes, t.totalBytes), DlOptions.speedText(t.speed))
                    .filter { it.isNotEmpty() }.joinToString(" · ")
                if (detail.isNotEmpty()) status(detail, muted)
            }
            DlTask.State.DONE -> status("✓ Selesai" + (if (clock.isNotEmpty()) " · $clock" else "") + (if (t.coverSkipped) " · tanpa cover" else ""), green, true)
            DlTask.State.FAILED -> {
                status("✕ Gagal" + if (clock.isNotEmpty()) " · $clock" else "", red, true)
                status(t.error ?: "tidak diketahui", Color.parseColor("#FF8A80"))
            }
            DlTask.State.CANCELED -> status("Dibatalkan", muted)
        }
        top.addView(info, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { marginStart = dp(12) })
        card.addView(top)

        if (t.state == DlTask.State.RUNNING) {
            card.addView(ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
                max = 100
                if (t.progress > 0f) { isIndeterminate = false; progress = t.progress.toInt().coerceIn(0, 100) }
                else isIndeterminate = true
            }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(6)).apply { topMargin = dp(8) })
        }
        val actions = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.END }
        fun act(label: String, onClick: () -> Unit) = actions.addView(
            TextView(this).apply {
                text = label
                textSize = 13f
                setTextColor(Color.WHITE)
                typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
                setPadding(dp(12), dp(8), dp(12), dp(8))
                isClickable = true
                setOnClickListener { onClick() }
            }
        )
        when (t.state) {
            DlTask.State.QUEUED, DlTask.State.RUNNING -> act("Batal") { DlQueue.cancel(t.id) }
            DlTask.State.DONE -> {
                act("Putar") { play(t) }
                act("Hapus") { DlQueue.remove(this, t) }
            }
            DlTask.State.FAILED -> {
                if (DlEngine.needsLogin(t.error)) act("Masuk akun") {
                    loginTask = t
                    loginResult.launch(
                        Intent(this, CookiesActivity::class.java)
                            .putExtra(CookiesActivity.EXTRA_AUTO_WEB, true)
                            .putExtra(CookiesActivity.EXTRA_LOGIN_URL, DlCookies.loginUrlFor(this, t.url))
                    )
                }
                act("Ulangi") { DlQueue.retry(this, t) }
                act("Hapus") { DlQueue.remove(this, t) }
            }
            DlTask.State.CANCELED -> act("Hapus") { DlQueue.remove(this, t) }
        }
        card.addView(actions)
        return card
    }

    private fun play(t: DlTask) {
        if (t.audio) {
            startActivity(Intent(this, MusicActivity::class.java))
            return
        }
        val uri = t.result ?: return
        runCatching {
            startActivity(
                Intent(Intent.ACTION_VIEW).setDataAndType(uri, "video/*")
                    .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            )
        }.onFailure { Toast.makeText(this, "Tidak bisa membuka video.", Toast.LENGTH_SHORT).show() }
    }
}
