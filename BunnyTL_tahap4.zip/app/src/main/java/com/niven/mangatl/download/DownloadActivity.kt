package com.niven.mangatl

import android.Manifest
import android.animation.ArgbEvaluator
import android.animation.ObjectAnimator
import android.animation.ValueAnimator
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.LayerDrawable
import android.net.ConnectivityManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.InputType
import android.text.SpannableStringBuilder
import android.text.Spanned
import android.text.TextUtils
import android.text.style.ForegroundColorSpan
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.ViewOutlineProvider
import android.view.animation.DecelerateInterpolator
import android.view.animation.LinearInterpolator
import android.view.animation.OvershootInterpolator
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.Locale
import kotlin.math.abs

/**
 * Layar Unduh (dari menu utama): hitam pekat, "Cari" putih di kanan bawah yang melebar jadi bar tempel link,
 * tiga tombol bulat kecil (cookies / perbarui mesin / login) menumpuk di atasnya, tab Unduh · Musik · Video sebagai chip.
 */
class DownloadActivity : AppCompatActivity() {
    private lateinit var root: FrameLayout
    private lateinit var etUrl: EditText
    private lateinit var pickerBox: LinearLayout
    private lateinit var tabBox: LinearLayout
    private lateinit var listBox: LinearLayout
    private lateinit var tvEngine: TextView
    private lateinit var tvStat: TextView
    private lateinit var picker: DlPicker

    private lateinit var dock: LinearLayout
    private lateinit var dockBg: GradientDrawable
    private lateinit var goBtn: LinearLayout
    private lateinit var goText: TextView
    private lateinit var pasteBtn: ImageView
    private lateinit var fabCk: ImageView
    private lateinit var fabUp: ImageView
    private lateinit var fabLg: ImageView
    private lateinit var popup: LinearLayout
    private lateinit var popupTitle: TextView
    private lateinit var claudePopup: LinearLayout
    private lateinit var toastView: TextView

    /** 0 = Unduh (berjalan/antre/gagal), 1 = Musik selesai, 2 = Video selesai. */
    private var tab = 0
    private var loginTask: DlTask? = null
    private var pending: List<DlTask>? = null
    private var dockOpen = false
    private var dockAnim: ValueAnimator? = null
    private var spin: ObjectAnimator? = null
    private var animateNext = true
    private var slide = 0
    private var tx = 0f
    private var ty = 0f
    private var tOk = false
    private var hideToast: Runnable? = null
    private val ui = Handler(Looper.getMainLooper())

    private val refresh: () -> Unit = { renderTasks() }

    private val loginResult = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        val t = loginTask
        loginTask = null
        if (r.resultCode == RESULT_OK && t != null) DlQueue.retry(this, t)
    }

    private val notifPerm = registerForActivityResult(ActivityResultContracts.RequestPermission()) {
        pending?.let { go(it) }
    }

    private fun dp(v: Int) = Ui.dp(this, v)
    private fun c(hex: String) = Color.parseColor(hex)
    private fun lp(w: Int, h: Int, weight: Float = 0f) = LinearLayout.LayoutParams(w, h, weight)
    private val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
    private val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT

    private val soft = Color.parseColor("#C7C7CC")
    private val muted = Color.parseColor("#8E8E93")
    private val dim = Color.parseColor("#6E6E73")
    private val red = Color.parseColor("#FF453A")
    private val med: Typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)

    private fun shape(fill: Int, radiusDp: Int, stroke: Int = 0, strokeDp: Int = 1) = GradientDrawable().apply {
        setColor(fill)
        cornerRadius = dp(radiusDp).toFloat()
        if (stroke != 0) setStroke(dp(strokeDp), stroke)
    }

    // ---------------------------------------------------------------- susun layar

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        DlQueue.init(this)

        root = FrameLayout(this).apply { setBackgroundColor(Color.BLACK) }

        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(12), dp(20), dp(280))
        }

        // bar atas
        val bar = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        bar.addView(Ui.iconBtn(this, R.drawable.ic_back, "Kembali") { onBackPressedDispatcher.onBackPressed() },
            lp(dp(44), dp(44)))
        bar.addView(TextView(this).apply {
            text = "Unduh"
            textSize = 22f
            setTextColor(Color.WHITE)
            typeface = med
        }, lp(0, WRAP, 1f).apply { marginStart = dp(8) })
        col.addView(bar)

        // ringkasan: versi mesin (kiri), jumlah file + ukuran (kanan)
        val sum = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(6), 0, dp(6), 0)
        }
        sum.addView(View(this).apply {
            background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(Color.WHITE) }
        }, lp(dp(6), dp(6)).apply { marginEnd = dp(7) })
        tvEngine = TextView(this).apply { textSize = 12f; setTextColor(muted) }
        sum.addView(tvEngine, lp(0, WRAP, 1f))
        tvStat = TextView(this).apply { textSize = 12f; setTextColor(muted) }
        sum.addView(tvStat)
        col.addView(sum, lp(MATCH, WRAP).apply { topMargin = dp(14) })

        // panel pilih kualitas (muncul setelah "Cari")
        picker = DlPicker(this) { start(it) }
        pickerBox = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundResource(R.drawable.bg_card)
            setPadding(dp(14), dp(14), dp(14), dp(14))
            visibility = View.GONE
            addView(picker.root)
        }
        col.addView(pickerBox, lp(MATCH, WRAP).apply { topMargin = dp(12) })

        // tab: Unduh / Musik / Video
        tabBox = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        col.addView(tabBox, lp(MATCH, WRAP).apply { topMargin = dp(12) })
        listBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        col.addView(listBox)

        val scroll = ScrollView(this).apply {
            isFillViewport = true
            isVerticalScrollBarEnabled = false
            addView(col)
            setOnTouchListener { _, e ->
                if (e.action == MotionEvent.ACTION_DOWN) tapOutside()
                false
            }
        }
        root.addView(scroll, FrameLayout.LayoutParams(MATCH, MATCH))

        buildPopup()
        buildToast()
        buildFabs()
        buildDock()
        setContentView(root)

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                when {
                    popup.visibility == View.VISIBLE || claudePopup.visibility == View.VISIBLE -> closePopup()
                    dockOpen -> closeDock()
                    else -> {
                        isEnabled = false
                        onBackPressedDispatcher.onBackPressed()
                    }
                }
            }
        })

        showEngine()
        refreshFabs()
        prewarm()
        intent.getStringExtra("url")?.let { u ->
            etUrl.setText(u)
            root.post { openDock() }
        }
    }

    override fun onStart() {
        super.onStart()
        DlQueue.addListener(refresh)
        renderTasks()
    }

    override fun onResume() {
        super.onResume()
        refreshFabs()
    }

    override fun onStop() {
        DlQueue.removeListener(refresh)
        super.onStop()
    }

    override fun onDestroy() {
        dockAnim?.cancel()
        spin?.cancel()
        ui.removeCallbacksAndMessages(null)
        super.onDestroy()
    }

    // ---------------------------------------------------------------- geser kiri/kanan = pindah kategori

    private fun inside(v: View, x: Float, y: Float): Boolean {
        if (v.visibility != View.VISIBLE) return false
        val l = IntArray(2)
        v.getLocationOnScreen(l)
        return x >= l[0] && x <= l[0] + v.width && y >= l[1] && y <= l[1] + v.height
    }

    override fun dispatchTouchEvent(ev: MotionEvent): Boolean {
        when (ev.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                tx = ev.rawX
                ty = ev.rawY
                tOk = !dockOpen && popup.visibility != View.VISIBLE && claudePopup.visibility != View.VISIBLE && !inside(pickerBox, ev.rawX, ev.rawY)
            }
            MotionEvent.ACTION_POINTER_DOWN, MotionEvent.ACTION_CANCEL -> tOk = false
            MotionEvent.ACTION_UP -> {
                if (tOk) {
                    val dx = ev.rawX - tx
                    val dy = ev.rawY - ty
                    if (abs(dx) > dp(80) && abs(dx) > abs(dy) * 1.8f) changeTab(if (dx < 0) 1 else -1)
                }
                tOk = false
            }
        }
        return super.dispatchTouchEvent(ev)
    }

    private fun changeTab(d: Int) {
        val n = (tab + d).coerceIn(0, 2)
        if (n == tab) return
        tab = n
        slide = d
        animateNext = false
        renderTasks()
    }

    private fun applySlide() {
        if (slide == 0) return
        val d = slide
        slide = 0
        listBox.animate().cancel()
        listBox.translationX = dp(48) * d.toFloat()
        listBox.alpha = 0f
        listBox.animate().translationX(0f).alpha(1f).setDuration(220).start()
    }

    // ---------------------------------------------------------------- tombol bulat + popup login

    private fun buildFabs() {
        fabLg = fab(R.drawable.ic_dl_login, "Login web", 80) { togglePopup() }
        fabUp = fab(R.drawable.ic_dl_update, "Perbarui yt-dlp", 134) { closePopup(); updateEngine() }
        fabCk = fab(R.drawable.ic_dl_cookie, "Cookies", 188) { toggleCookies() }
        listOf(fabLg, fabUp, fabCk).forEachIndexed { i, v ->
            v.alpha = 0f
            v.scaleX = 0.6f
            v.scaleY = 0.6f
            v.translationY = dp(24).toFloat()
            v.animate().alpha(1f).scaleX(1f).scaleY(1f).translationY(0f)
                .setStartDelay(50L + i * 70L).setDuration(500)
                .setInterpolator(OvershootInterpolator(1.3f)).start()
        }
    }

    private fun fab(res: Int, desc: String, bottomDp: Int, onClick: () -> Unit): ImageView {
        val v = ImageView(this).apply {
            setImageResource(res)
            scaleType = ImageView.ScaleType.CENTER
            contentDescription = desc
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(c("#101012"))
                setStroke(dp(1), c("#1F1F23"))
            }
            isClickable = true
            setOnClickListener { onClick() }
        }
        root.addView(v, FrameLayout.LayoutParams(dp(44), dp(44), Gravity.END or Gravity.BOTTOM).apply {
            marginEnd = dp(19)
            bottomMargin = dp(bottomDp)
        })
        return v
    }

    private fun buildPopup() {
        popup = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            visibility = View.GONE
            setPadding(dp(8), dp(8), dp(8), dp(8))
            background = shape(c("#0D0D0F"), 22, c("#26262A"))
            elevation = dp(6).toFloat()
        }
        popupTitle = TextView(this).apply {
            textSize = 12f
            setTextColor(muted)
            setPadding(dp(10), dp(6), dp(10), dp(6))
        }
        popup.addView(popupTitle)
        DlCookies.SITES.chunked(2).forEach { r ->
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                setPadding(dp(4), 0, dp(4), dp(6))
            }
            r.forEachIndexed { i, s ->
                row.addView(TextView(this).apply {
                    text = s.label
                    textSize = 13f
                    setTextColor(Color.WHITE)
                    setPadding(dp(14), dp(8), dp(14), dp(8))
                    background = shape(Color.TRANSPARENT, 16, c("#2A2A2E"))
                    isClickable = true
                    setOnClickListener { loginSite(s) }
                }, lp(WRAP, WRAP).apply { if (i > 0) marginStart = dp(6) })
            }
            popup.addView(row)
        }
        // Claude: ketuk = buka akun aktif, TAHAN = barisan slot akun
        val claudeRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(dp(4), 0, dp(4), dp(6))
        }
        claudeRow.addView(TextView(this).apply {
            text = "Claude"
            textSize = 13f
            setTextColor(Color.WHITE)
            setPadding(dp(14), dp(8), dp(14), dp(8))
            background = shape(Color.TRANSPARENT, 16, c("#2A2A2E"))
            isClickable = true
            setOnClickListener { openClaude() }
            setOnLongClickListener { showClaudePopup(); true }
        }, lp(WRAP, WRAP))
        popup.addView(claudeRow)
        popup.addView(View(this).apply { setBackgroundColor(c("#1C1C1F")) },
            lp(MATCH, dp(1)).apply { setMargins(dp(6), dp(4), dp(6), dp(4)) })
        val links = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(dp(10), dp(2), dp(10), dp(2))
        }
        links.addView(TextView(this).apply {
            text = "Kelola cookies"
            textSize = 12.5f
            setTextColor(soft)
            setPadding(0, dp(6), 0, dp(6))
            isClickable = true
            setOnClickListener {
                closePopup()
                startActivity(Intent(this@DownloadActivity, CookiesActivity::class.java))
            }
        }, lp(0, WRAP, 1f))
        links.addView(TextView(this).apply {
            text = "Hapus cookies"
            textSize = 12.5f
            setTextColor(muted)
            setPadding(0, dp(6), 0, dp(6))
            isClickable = true
            setOnClickListener { confirmClearCookies() }
        })
        popup.addView(links)
        root.addView(popup, FrameLayout.LayoutParams(dp(230), WRAP, Gravity.END or Gravity.BOTTOM).apply {
            marginEnd = dp(73)
            bottomMargin = dp(80)
        })
        buildClaudePopup()
    }

    // ---------------------------------------------------------------- slot akun Claude

    private fun buildClaudePopup() {
        claudePopup = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            visibility = View.GONE
            setPadding(dp(8), dp(6), dp(8), dp(4))
            background = shape(c("#0D0D0F"), 22, c("#26262A"))
            elevation = dp(6).toFloat()
        }
        // ukuran & posisi sama persis dengan popup login
        root.addView(claudePopup, FrameLayout.LayoutParams(dp(230), WRAP, Gravity.END or Gravity.BOTTOM).apply {
            marginEnd = dp(73)
            bottomMargin = dp(80)
        })
    }

    private fun openClaude() {
        val a = ClaudeSlots.active(this)
        if (a in 0 until ClaudeSlots.COUNT && ClaudeSlots.get(this, a)?.filled == true) openClaudeSlot(a) else showClaudePopup()
    }

    private fun openClaudeSlot(i: Int) {
        closePopup()
        startActivity(Intent(this, CookiesActivity::class.java).putExtra(CookiesActivity.EXTRA_CLAUDE_SLOT, i))
    }

    private fun showClaudePopup() {
        popup.animate().cancel()
        popup.visibility = View.GONE
        refreshClaudePopup()
        claudePopup.animate().cancel()
        claudePopup.alpha = 0f
        claudePopup.scaleX = 0.8f
        claudePopup.scaleY = 0.8f
        claudePopup.visibility = View.VISIBLE
        claudePopup.post {
            claudePopup.pivotX = claudePopup.width.toFloat()
            claudePopup.pivotY = claudePopup.height.toFloat()
            claudePopup.animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(240)
                .setInterpolator(OvershootInterpolator(1.3f)).start()
        }
    }

    private fun refreshClaudePopup() {
        claudePopup.removeAllViews()
        // header: judul + Reset tanda di ATAS (jauh dari daftar akun supaya tidak mudah kepencet)
        val head = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(8), 0, 0, dp(2))
        }
        head.addView(TextView(this).apply {
            text = "Claude · pilih akun"
            textSize = 12f
            setTextColor(muted)
        }, lp(0, WRAP, 1f))
        head.addView(TextView(this).apply {
            text = "Reset tanda"
            textSize = 11f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            setPadding(dp(10), 0, dp(10), 0)
            background = shape(Color.TRANSPARENT, 15, c("#3A3A40"))
            isClickable = true
            setOnClickListener {
                ClaudeSlots.resetDim(this@DownloadActivity)
                refreshClaudePopup()
                flash("Tanda direset")
            }
        }, lp(WRAP, dp(30)))
        claudePopup.addView(head)

        val act = ClaudeSlots.active(this)
        for (i in 0 until ClaudeSlots.COUNT) {
            claudePopup.addView(slotRow(i, ClaudeSlots.get(this, i), i == act),
                lp(MATCH, WRAP).apply { topMargin = dp(4) })
        }
        claudePopup.addView(View(this).apply { setBackgroundColor(c("#1C1C1F")) },
            lp(MATCH, dp(1)).apply { setMargins(dp(6), dp(8), dp(6), 0) })
        claudePopup.addView(TextView(this).apply {
            text = "Kelola"
            textSize = 12f
            setTextColor(muted)
            gravity = Gravity.CENTER_VERTICAL or Gravity.END
            setPadding(dp(10), 0, dp(10), 0)
            isClickable = true
            setOnClickListener { manageClaude() }
        }, lp(MATCH, dp(36)))
    }

    private fun slotRow(i: Int, s: ClaudeSlot?, isActive: Boolean): View {
        val sl = s ?: ClaudeSlot()
        val filled = sl.filled
        val expired = filled && sl.expired
        val isDim = filled && !isActive && !expired && sl.dim
        val titleColor = when { !filled -> soft; isDim -> muted; else -> Color.WHITE }
        val subColor = when { !filled -> muted; isDim -> muted; else -> soft }

        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            minimumHeight = dp(46)
            setPadding(dp(8), dp(4), dp(8), dp(4))
            background = when {
                !filled -> GradientDrawable().apply {
                    cornerRadius = dp(14).toFloat()
                    setStroke(dp(1), c("#3A3A40"), dp(4).toFloat(), dp(3).toFloat())
                }
                isActive -> shape(c("#1C1C20"), 14, Color.WHITE)
                expired -> shape(Color.TRANSPARENT, 14, c("#6B4A1E"))
                isDim -> shape(Color.TRANSPARENT, 14, c("#26262A"))
                else -> shape(Color.TRANSPARENT, 14, c("#2A2A2E"))
            }
            isClickable = true
            setOnClickListener { openClaudeSlot(i) }
        }
        val label = (if (filled) sl.name.ifBlank { sl.email } else "").trim()
        val initial = when { !filled -> "+"; label.isNotEmpty() -> label.take(1).uppercase(); else -> "${i + 1}" }
        row.addView(TextView(this).apply {
            text = initial
            textSize = 12f
            typeface = med
            gravity = Gravity.CENTER
            setTextColor(if (isActive) Color.BLACK else if (isDim || !filled) muted else Color.WHITE)
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(if (isActive) Color.WHITE else c("#26262A"))
            }
        }, lp(dp(28), dp(28)))

        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val title = SpannableStringBuilder(
            if (filled) sl.name.ifBlank { "Akun ${i + 1}" } else "Slot ${i + 1}"
        )
        if (expired) {
            val st = title.length
            title.append(" · login ulang")
            title.setSpan(ForegroundColorSpan(c("#F0A64A")), st, title.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
        }
        col.addView(TextView(this).apply {
            text = title
            textSize = 13f
            typeface = med
            setTextColor(titleColor)
            maxLines = 1
            ellipsize = TextUtils.TruncateAt.END
        })
        col.addView(TextView(this).apply {
            text = if (filled) sl.email.ifBlank { "Membaca profil…" } else "Kosong · ketuk untuk rekam"
            textSize = 11f
            setTextColor(subColor)
            maxLines = 1
            ellipsize = TextUtils.TruncateAt.END
        })
        row.addView(col, lp(0, WRAP, 1f).apply { marginStart = dp(9) })

        if (isActive || expired) {
            row.addView(TextView(this).apply {
                text = if (expired) "!" else "✓"
                textSize = 15f
                typeface = med
                setTextColor(if (expired) c("#F0A64A") else Color.WHITE)
            }, lp(WRAP, WRAP).apply { marginStart = dp(6) })
        }
        return row
    }

    /** Hapus akun dari slot (aksi terpisah dari Reset tanda). */
    private fun manageClaude() {
        closePopup()
        val idx = (0 until ClaudeSlots.COUNT).filter { ClaudeSlots.get(this, it)?.filled == true }
        if (idx.isEmpty()) { flash("Belum ada akun Claude tersimpan"); return }
        val labels = idx.map { i ->
            val s = ClaudeSlots.get(this, i)
            val who = s?.email?.takeIf { it.isNotBlank() } ?: s?.name?.takeIf { it.isNotBlank() } ?: "tanpa nama"
            "Akun ${i + 1} · $who"
        }.toTypedArray<CharSequence>()
        AlertDialog.Builder(this)
            .setTitle("Hapus akun Claude")
            .setItems(labels) { _, w ->
                val i = idx[w]
                AlertDialog.Builder(this)
                    .setTitle("Hapus Akun ${i + 1}?")
                    .setMessage("Login yang tersimpan di slot ini dihapus. Akun Claude-nya sendiri tidak terpengaruh.")
                    .setNegativeButton("Batal", null)
                    .setPositiveButton("Hapus") { _, _ ->
                        ClaudeSlots.clear(this, i)
                        flash("Slot ${i + 1} dihapus")
                    }
                    .show()
            }
            .setNegativeButton("Tutup", null)
            .show()
    }

    private fun togglePopup() {
        if (popup.visibility == View.VISIBLE || claudePopup.visibility == View.VISIBLE) { closePopup(); return }
        refreshFabs()
        popup.animate().cancel()
        popup.alpha = 0f
        popup.scaleX = 0.8f
        popup.scaleY = 0.8f
        popup.visibility = View.VISIBLE
        popup.post {
            popup.pivotX = popup.width.toFloat()
            popup.pivotY = popup.height.toFloat()
            popup.animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(240)
                .setInterpolator(OvershootInterpolator(1.3f)).start()
        }
    }

    private fun closePopup() {
        popup.animate().cancel()
        popup.visibility = View.GONE
        claudePopup.animate().cancel()
        claudePopup.visibility = View.GONE
    }

    private fun loginSite(s: LoginSite) {
        closePopup()
        flash("Membuka login web…")
        startActivity(
            Intent(this, CookiesActivity::class.java)
                .putExtra(CookiesActivity.EXTRA_AUTO_WEB, true)
                .putExtra(CookiesActivity.EXTRA_LOGIN_URL, s.loginUrl)
        )
    }

    private fun confirmClearCookies() {
        closePopup()
        if (DlCookies.count(this) == 0) { flash("Belum ada cookies"); return }
        AlertDialog.Builder(this)
            .setTitle("Hapus cookies?")
            .setMessage("Semua login situs yang tersimpan di BunnyTL dihapus.")
            .setNegativeButton("Batal", null)
            .setPositiveButton("Hapus") { _, _ ->
                DlCookies.clear(this)
                refreshFabs()
                flash("Cookies dihapus")
            }
            .show()
    }

    private fun toggleCookies() {
        closePopup()
        if (!DlCookies.has(this)) {
            flash("Belum ada cookies, login dulu")
            togglePopup()
            return
        }
        val on = !DlPrefs.useCookies(this)
        DlPrefs.setUseCookies(this, on)
        refreshFabs()
        flash(if (on) "Cookies aktif" else "Cookies dimatikan")
    }

    private fun refreshFabs() {
        fabCk.setImageResource(if (DlPrefs.useCookies(this)) R.drawable.ic_dl_cookie else R.drawable.ic_dl_cookie_off)
        popupTitle.text = "Login ke situs · ${DlCookies.count(this)} cookies"
    }

    private fun setFabsDim(dimmed: Boolean) {
        listOf(fabLg, fabUp, fabCk).forEach {
            it.animate().alpha(if (dimmed) 0.35f else 1f).setDuration(250).start()
            it.isEnabled = !dimmed
        }
    }

    // ---------------------------------------------------------------- dock "Cari" -> bar link

    private fun buildDock() {
        dockBg = shape(Color.WHITE, 24, Color.WHITE)
        dock = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL or Gravity.END
            background = dockBg
            clipToOutline = true
            outlineProvider = ViewOutlineProvider.BACKGROUND
            elevation = dp(4).toFloat()
        }
        etUrl = EditText(this).apply {
            hint = "Tempel link video atau musik"
            setHintTextColor(dim)
            setTextColor(Color.WHITE)
            textSize = 14f
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_URI
            isSingleLine = true
            imeOptions = EditorInfo.IME_ACTION_SEARCH
            setBackgroundColor(Color.TRANSPARENT)
            setPadding(dp(18), 0, dp(4), 0)
            visibility = View.GONE
            setOnEditorActionListener { _, id, _ ->
                if (id == EditorInfo.IME_ACTION_SEARCH) { search(); true } else false
            }
        }
        dock.addView(etUrl, lp(0, MATCH, 1f))
        pasteBtn = ImageView(this).apply {
            setImageResource(R.drawable.ic_dl_paste)
            scaleType = ImageView.ScaleType.CENTER
            contentDescription = "Tempel"
            visibility = View.GONE
            isClickable = true
            setOnClickListener { paste() }
        }
        dock.addView(pasteBtn, lp(dp(38), dp(38)))
        goBtn = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            background = shape(Color.WHITE, 24)
            isClickable = true
            contentDescription = "Cari kualitas"
            setOnClickListener { if (!dockOpen) openDock() else search() }
        }
        goBtn.addView(ImageView(this).apply { setImageResource(R.drawable.ic_dl_search_dark) }, lp(dp(22), dp(22)))
        goText = TextView(this).apply {
            text = "Cari"
            textSize = 15f
            setTextColor(Color.BLACK)
            typeface = Typeface.create("sans-serif-medium", Typeface.BOLD)
        }
        goBtn.addView(goText, lp(WRAP, WRAP).apply { marginStart = dp(8) })
        dock.addView(goBtn, lp(dp(114), dp(45)))
        root.addView(dock, FrameLayout.LayoutParams(dp(116), dp(47), Gravity.END or Gravity.BOTTOM).apply {
            marginEnd = dp(19)
            bottomMargin = dp(21)
        })
    }

    private fun setGo(open: Boolean) {
        val p = goBtn.layoutParams as LinearLayout.LayoutParams
        p.width = if (open) dp(39) else dp(114)
        p.height = if (open) dp(39) else dp(45)
        p.marginEnd = if (open) dp(3) else 0
        goBtn.layoutParams = p
        goText.visibility = if (open) View.GONE else View.VISIBLE
    }

    private fun animateDock(toW: Int, open: Boolean) {
        dockAnim?.cancel()
        val fromW = dock.layoutParams.width
        val fromFill = if (open) Color.WHITE else c("#0D0D0F")
        val toFill = if (open) c("#0D0D0F") else Color.WHITE
        val fromLine = if (open) Color.WHITE else c("#2E2E33")
        val toLine = if (open) c("#2E2E33") else Color.WHITE
        val ev = ArgbEvaluator()
        dockAnim = ValueAnimator.ofFloat(0f, 1f).apply {
            duration = 400
            interpolator = DecelerateInterpolator(1.4f)
            addUpdateListener { a ->
                val f = a.animatedValue as Float
                val p = dock.layoutParams
                p.width = (fromW + (toW - fromW) * f).toInt()
                dock.layoutParams = p
                dockBg.setColor(ev.evaluate(f, fromFill, toFill) as Int)
                dockBg.setStroke(dp(1), ev.evaluate(f, fromLine, toLine) as Int)
            }
            start()
        }
    }

    private fun openDock() {
        if (dockOpen) return
        dockOpen = true
        closePopup()
        setFabsDim(true)
        setGo(true)
        etUrl.visibility = View.VISIBLE
        pasteBtn.visibility = View.VISIBLE
        listOf<View>(etUrl, pasteBtn).forEach {
            it.alpha = 0f
            it.animate().alpha(1f).setStartDelay(150).setDuration(200).start()
        }
        animateDock(root.width - root.paddingLeft - root.paddingRight - dp(38), true)
        ui.postDelayed({
            if (dockOpen) {
                etUrl.requestFocus()
                (getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager)
                    .showSoftInput(etUrl, InputMethodManager.SHOW_IMPLICIT)
            }
        }, 250)
    }

    private fun closeDock() {
        if (!dockOpen) return
        dockOpen = false
        setFabsDim(false)
        hideKeyboard()
        etUrl.clearFocus()
        etUrl.animate().cancel()
        pasteBtn.animate().cancel()
        etUrl.visibility = View.GONE
        pasteBtn.visibility = View.GONE
        setGo(false)
        animateDock(dp(116), false)
    }

    private fun hideKeyboard() {
        (getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager)
            .hideSoftInputFromWindow(etUrl.windowToken, 0)
    }

    private fun tapOutside() {
        if (popup.visibility == View.VISIBLE || claudePopup.visibility == View.VISIBLE) closePopup()
        if (dockOpen && etUrl.text.isNullOrBlank()) closeDock()
    }

    // ---------------------------------------------------------------- toast putih di atas tab

    private fun buildToast() {
        toastView = TextView(this).apply {
            textSize = 15f
            setTextColor(Color.BLACK)
            gravity = Gravity.CENTER
            setPadding(dp(24), dp(12), dp(24), dp(12))
            maxWidth = dp(330)
            background = shape(Color.WHITE, 26)
            alpha = 0f
            visibility = View.GONE
        }
        root.addView(toastView, FrameLayout.LayoutParams(WRAP, WRAP, Gravity.TOP or Gravity.CENTER_HORIZONTAL).apply {
            topMargin = dp(150)
        })
    }

    private fun flash(msg: String, ms: Long = 1600) {
        val a = IntArray(2)
        val b = IntArray(2)
        tabBox.getLocationInWindow(a)
        root.getLocationInWindow(b)
        val top = if (tabBox.height > 0) a[1] - b[1] - dp(6) else dp(150)
        (toastView.layoutParams as FrameLayout.LayoutParams).topMargin = top.coerceAtLeast(dp(60))
        toastView.requestLayout()
        toastView.text = msg
        toastView.visibility = View.VISIBLE
        toastView.animate().cancel()
        toastView.animate().alpha(1f).setDuration(250).start()
        hideToast?.let { ui.removeCallbacks(it) }
        val r = Runnable {
            toastView.animate().alpha(0f).setDuration(250).withEndAction { toastView.visibility = View.GONE }.start()
        }
        hideToast = r
        ui.postDelayed(r, ms)
    }

    // ---------------------------------------------------------------- aksi

    private fun paste() {
        val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        val t = cm.primaryClip?.takeIf { it.itemCount > 0 }?.getItemAt(0)?.coerceToText(this)?.toString()
        if (t.isNullOrBlank()) {
            flash("Clipboard kosong.")
        } else {
            etUrl.setText(t.trim())
            etUrl.setSelection(etUrl.text.length)
            etUrl.requestFocus()
        }
    }

    private fun search() {
        val u = DlUrl.extract(Intent().putExtra(Intent.EXTRA_TEXT, etUrl.text.toString()))
        if (u == null) {
            flash(if (etUrl.text.isNullOrBlank()) "Tempel link dulu" else "Isi dulu link yang benar (http/https).")
            return
        }
        hideKeyboard()
        closeDock()
        pickerBox.visibility = View.VISIBLE
        picker.load(u)
    }

    private fun start(tasks: List<DlTask>) {
        val needAsk = Build.VERSION.SDK_INT >= 33 && !DlPrefs.notifAsked(this) &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        if (needAsk) {
            DlPrefs.setNotifAsked(this)
            pending = tasks
            notifPerm.launch(Manifest.permission.POST_NOTIFICATIONS)
        } else {
            go(tasks)
        }
    }

    private fun go(tasks: List<DlTask>) {
        pending = null
        tasks.forEach { DlQueue.enqueue(this, it) }
        pickerBox.visibility = View.GONE
        etUrl.setText("")
        tab = 0
        animateNext = true
        renderTasks()
        flash(if (tasks.size == 1) "Ditambahkan ke antrean" else "${tasks.size} item ditambahkan ke antrean")
    }

    private fun showEngine() {
        tvEngine.text = if (DlEngine.version.isEmpty()) "yt-dlp · menyiapkan…" else "yt-dlp ${DlEngine.version}"
    }

    /** Siapkan mesin di latar begitu layar dibuka, dan perbarui otomatis tiap ~12 jam kalau bukan kuota. */
    private fun prewarm() {
        lifecycleScope.launch(Dispatchers.IO) {
            runCatching { DlEngine.ensureReady(this@DownloadActivity) }
            withContext(Dispatchers.Main) { showEngine() }
            val cm = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
            val stale = System.currentTimeMillis() - DlPrefs.lastUpdate(this@DownloadActivity) > 12L * 3600 * 1000
            if (DlEngine.version.isNotEmpty() && stale && !cm.isActiveNetworkMetered) {
                runCatching { DlUpdater.update(this@DownloadActivity) }
                DlPrefs.setLastUpdate(this@DownloadActivity, System.currentTimeMillis())
                withContext(Dispatchers.Main) { showEngine() }
            }
        }
    }

    private fun updateEngine() {
        if (spin != null) return
        flash("Memperbarui mesin unduh…", 30000)
        spin = ObjectAnimator.ofFloat(fabUp, View.ROTATION, 0f, 360f).apply {
            duration = 900
            repeatCount = ValueAnimator.INFINITE
            interpolator = LinearInterpolator()
            start()
        }
        lifecycleScope.launch {
            val msg = withContext(Dispatchers.IO) {
                runCatching {
                    DlEngine.ensureReady(this@DownloadActivity)
                    val r = DlUpdater.update(this@DownloadActivity)
                    DlPrefs.setLastUpdate(this@DownloadActivity, System.currentTimeMillis())
                    DlUpdater.message(r)
                }.getOrElse { DlEngine.friendlyError(it) }
            }
            spin?.cancel()
            spin = null
            fabUp.rotation = 0f
            showEngine()
            flash(msg, 2600)
        }
    }

    // ---------------------------------------------------------------- daftar

    private fun rank(s: DlTask.State) = when (s) {
        DlTask.State.RUNNING -> 0
        DlTask.State.QUEUED -> 1
        DlTask.State.FAILED -> 2
        else -> 3
    }

    private fun renderTasks() {
        val all = DlQueue.tasks.toList()
        val dl = all.filter { it.state != DlTask.State.DONE }.sortedBy { rank(it.state) }
        val mus = all.filter { it.state == DlTask.State.DONE && it.audio }.sortedByDescending { it.finishedAt }
        val vid = all.filter { it.state == DlTask.State.DONE && !it.audio }.sortedByDescending { it.finishedAt }
        renderTabs(dl.size, mus.size, vid.size)

        val total = all.fold(0L) { acc, t -> acc + (if (t.bytes > 0) t.bytes else t.estBytes) }
        tvStat.text = if (all.isEmpty()) "Belum ada file"
        else "${all.size} file" + (if (total > 0) " · ${DlOptions.sizeExact(total)}" else "")

        listBox.removeAllViews()
        val shown = when (tab) { 0 -> dl; 1 -> mus; else -> vid }
        val anim = animateNext
        animateNext = false
        if (shown.isEmpty()) {
            listBox.addView(emptyView(when (tab) {
                0 -> "Belum ada unduhan.\nTempel link video, musik, atau playlist,\natau bagikan link dari app lain ke BunnyTL."
                1 -> "Belum ada musik yang selesai diunduh."
                else -> "Belum ada video yang selesai diunduh."
            }))
            applySlide()
            return
        }
        shown.forEachIndexed { i, t ->
            val v = taskRow(t)
            listBox.addView(v, lp(MATCH, WRAP).apply { topMargin = dp(7) })
            if (anim) {
                v.alpha = 0f
                v.translationY = dp(8).toFloat()
                v.animate().alpha(1f).translationY(0f).setStartDelay(i * 40L).setDuration(350).start()
            }
        }
        applySlide()
    }

    private fun renderTabs(nDl: Int, nMus: Int, nVid: Int) {
        tabBox.removeAllViews()
        listOf("Unduh" to nDl, "Musik" to nMus, "Video" to nVid).forEachIndexed { i, (label, n) ->
            val sel = i == tab
            val chip = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(dp(13), dp(6), dp(13), dp(6))
                background = shape(if (sel) c("#121214") else Color.TRANSPARENT, 12, if (sel) c("#2E2E33") else c("#1F1F23"))
                isClickable = true
                setOnClickListener {
                    if (i == tab) return@setOnClickListener
                    slide = if (i > tab) 1 else -1
                    tab = i
                    animateNext = false
                    renderTasks()
                }
            }
            chip.addView(TextView(this).apply {
                text = label
                textSize = 13f
                typeface = med
                setTextColor(if (sel) Color.WHITE else muted)
            })
            if (n > 0) chip.addView(TextView(this).apply {
                text = "$n"
                textSize = 12f
                typeface = med
                setTextColor(if (sel) soft else dim)
            }, lp(WRAP, WRAP).apply { marginStart = dp(7) })
            tabBox.addView(chip, lp(WRAP, WRAP).apply { if (i > 0) marginStart = dp(6) })
        }
    }

    private fun emptyView(msg: String): View {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(dp(16), dp(44), dp(16), dp(44))
        }
        val ring = FrameLayout(this).apply {
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(Color.TRANSPARENT)
                setStroke(dp(1), c("#2A2A2E"))
            }
        }
        ring.addView(ImageView(this).apply {
            setImageResource(R.drawable.ic_dl_download)
            setColorFilter(soft)
        }, FrameLayout.LayoutParams(dp(26), dp(26), Gravity.CENTER))
        box.addView(ring, lp(dp(68), dp(68)).apply { bottomMargin = dp(16) })
        box.addView(TextView(this).apply {
            text = msg
            textSize = 13f
            setTextColor(muted)
            gravity = Gravity.CENTER
            setLineSpacing(0f, 1.3f)
        })
        return box
    }

    private fun cardBg(tint: Int): LayerDrawable {
        val base = shape(c("#08080A"), 16, c("#26262A"))
        val glow = GradientDrawable(
            GradientDrawable.Orientation.LEFT_RIGHT,
            intArrayOf(Color.argb(51, Color.red(tint), Color.green(tint), Color.blue(tint)), Color.TRANSPARENT)
        ).apply { cornerRadius = dp(16).toFloat() }
        return LayerDrawable(arrayOf<Drawable>(base, glow))
    }

    private fun thumbView(t: DlTask): View {
        val done = t.state == DlTask.State.DONE
        val w = if (done && !t.audio) dp(96) else dp(54)
        val bg: GradientDrawable = when {
            done && t.audio -> GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,
                intArrayOf(c("#D6D9DE"), c("#5D636B")))
            done -> GradientDrawable(GradientDrawable.Orientation.TL_BR,
                intArrayOf(c("#7A2F1B"), c("#E49A4A"), c("#2B1B22")))
            else -> GradientDrawable().apply { setColor(c("#141416")) }
        }
        bg.cornerRadius = dp(11).toFloat()
        val frame = FrameLayout(this).apply {
            background = bg
            clipToOutline = true
            outlineProvider = ViewOutlineProvider.BACKGROUND
        }
        if (!done) {
            if (t.state == DlTask.State.FAILED) {
                frame.addView(TextView(this).apply {
                    text = "!"
                    textSize = 22f
                    setTextColor(muted)
                    gravity = Gravity.CENTER
                }, FrameLayout.LayoutParams(MATCH, MATCH))
            } else {
                frame.addView(ImageView(this).apply { setImageResource(R.drawable.ic_dl_download) },
                    FrameLayout.LayoutParams(dp(22), dp(22), Gravity.CENTER))
            }
            return frame.also { it.layoutParams = LinearLayout.LayoutParams(w, dp(54)) }
        }
        val u = t.thumb.ifEmpty { DlThumbs.guess(t.url) }
        val bmp = if (u.isEmpty()) null else DlThumbs.get(u)
        if (bmp != null) {
            frame.addView(ImageView(this).apply {
                scaleType = ImageView.ScaleType.CENTER_CROP
                setImageBitmap(bmp)
            }, FrameLayout.LayoutParams(MATCH, MATCH))
        } else {
            if (t.audio) {
                frame.addView(TextView(this).apply {
                    text = "♪"
                    textSize = 22f
                    setTextColor(Color.WHITE)
                    gravity = Gravity.CENTER
                }, FrameLayout.LayoutParams(MATCH, MATCH))
            } else {
                frame.addView(TextView(this).apply {
                    text = "▶"
                    textSize = 10f
                    setTextColor(Color.WHITE)
                    gravity = Gravity.CENTER
                    background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(c("#AA000000")) }
                }, FrameLayout.LayoutParams(dp(22), dp(22), Gravity.CENTER))
            }
            if (u.isNotEmpty()) DlThumbs.fetch(u) { if (!isDestroyed) renderTasks() }
        }
        val dur = DlOptions.duration(t.durationSec)
        if (dur.isNotEmpty()) {
            frame.addView(TextView(this).apply {
                text = dur
                textSize = 9.5f
                setTextColor(Color.WHITE)
                background = shape(c("#B3000000"), 6)
                setPadding(dp(5), 0, dp(5), 0)
            }, FrameLayout.LayoutParams(WRAP, WRAP, Gravity.BOTTOM or Gravity.END).apply {
                setMargins(0, 0, dp(3), dp(3))
            })
        }
        return frame.also { it.layoutParams = LinearLayout.LayoutParams(w, dp(54)) }
    }

    private fun speedId(b: Long): String = when {
        b <= 0 -> ""
        b >= 1024L * 1024 -> String.format(Locale("id", "ID"), "%.1f MB/dtk", b / 1048576.0)
        else -> String.format(Locale("id", "ID"), "%.0f KB/dtk", b / 1024.0)
    }

    private fun line(text: String, sp: Float, color: Int, topDp: Int, maxLines: Int = 1) = TextView(this).apply {
        this.text = text
        textSize = sp
        setTextColor(color)
        this.maxLines = maxLines
        ellipsize = TextUtils.TruncateAt.END
        setPadding(0, dp(topDp), 0, 0)
    }

    private fun pill(label: String, filled: Boolean, onClick: () -> Unit) = TextView(this).apply {
        text = label
        textSize = 12f
        setTextColor(if (filled) Color.BLACK else Color.WHITE)
        setPadding(dp(12), dp(5), dp(12), dp(5))
        background = if (filled) shape(Color.WHITE, 14, Color.WHITE) else shape(Color.TRANSPARENT, 14, c("#3A3A3F"))
        isClickable = true
        setOnClickListener { onClick() }
    }

    private fun taskRow(t: DlTask): View {
        val tint = when {
            t.state == DlTask.State.FAILED -> red
            t.state == DlTask.State.DONE && !t.audio -> c("#E49A4A")
            else -> c("#8A9099")
        }
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(8), dp(8), dp(8), dp(8))
            background = cardBg(tint)
            if (t.state == DlTask.State.DONE) {
                isClickable = true
                setOnClickListener { play(t) }
            }
        }
        card.addView(thumbView(t))

        val info = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        info.addView(TextView(this).apply {
            text = t.title
            textSize = 13f
            typeface = med
            setTextColor(Color.WHITE)
            maxLines = 1
            ellipsize = TextUtils.TruncateAt.END
        })
        when (t.state) {
            DlTask.State.QUEUED -> info.addView(line("Menunggu antrean", 11.5f, muted, 3))
            DlTask.State.CANCELED -> info.addView(line("Dibatalkan", 11.5f, muted, 3))
            DlTask.State.RUNNING -> {
                val pct = t.progress.toInt().coerceIn(0, 100)
                val track = LinearLayout(this).apply {
                    orientation = LinearLayout.HORIZONTAL
                    weightSum = 100f
                    background = shape(c("#222226"), 3)
                    clipToOutline = true
                    outlineProvider = ViewOutlineProvider.BACKGROUND
                }
                track.addView(View(this).apply { setBackgroundColor(Color.WHITE) }, lp(0, MATCH, pct.toFloat()))
                track.addView(View(this), lp(0, MATCH, (100 - pct).toFloat()))
                info.addView(track, lp(MATCH, dp(3)).apply { topMargin = dp(7) })
                val head = if (t.progress > 0f) "$pct%" else t.note.ifEmpty { "Menyiapkan…" }
                val meta = listOf(head, speedId(t.speed), if (t.eta > 0) "sisa ${DlOptions.duration(t.eta)}" else "")
                    .filter { it.isNotEmpty() }.joinToString(" · ")
                info.addView(line(meta, 11.5f, muted, 3))
                val detail = DlOptions.progressText(t.doneBytes, t.totalBytes)
                if (detail.isNotEmpty()) info.addView(line(detail, 11f, dim, 1))
            }
            DlTask.State.DONE -> {
                val size = if (t.bytes > 0) DlOptions.sizeExact(t.bytes) else DlOptions.sizeText(t.estBytes)
                val parts = (listOf(t.fmt) + t.quality.split(" · ") + listOf(size))
                    .map { it.trim() }.filter { it.isNotEmpty() }
                val chips = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
                parts.forEachIndexed { i, p ->
                    chips.addView(TextView(this).apply {
                        text = p
                        textSize = 10f
                        setTextColor(soft)
                        maxLines = 1
                        setPadding(dp(7), dp(1), dp(7), dp(1))
                        background = shape(Color.argb(8, 255, 255, 255), 9, c("#2E2E33"))
                    }, lp(WRAP, WRAP).apply { if (i > 0) marginStart = dp(4) })
                }
                info.addView(chips, lp(MATCH, WRAP).apply { topMargin = dp(6) })
                if (t.coverSkipped) info.addView(line("tanpa cover", 11f, dim, 3))
            }
            DlTask.State.FAILED -> {
                val needLogin = DlEngine.needsLogin(t.error)
                info.addView(line("Gagal · " + (if (needLogin) "perlu login" else (t.error ?: "tidak diketahui")),
                    11.5f, red, 3, 2))
                val acts = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
                if (needLogin) acts.addView(pill("Masuk akun", true) {
                    loginTask = t
                    loginResult.launch(
                        Intent(this, CookiesActivity::class.java)
                            .putExtra(CookiesActivity.EXTRA_AUTO_WEB, true)
                            .putExtra(CookiesActivity.EXTRA_LOGIN_URL, DlCookies.loginUrlFor(this, t.url))
                    )
                })
                acts.addView(pill("Ulangi", false) { DlQueue.retry(this, t) },
                    lp(WRAP, WRAP).apply { if (needLogin) marginStart = dp(6) })
                info.addView(acts, lp(WRAP, WRAP).apply { topMargin = dp(7) })
            }
        }
        card.addView(info, lp(0, WRAP, 1f).apply { marginStart = dp(11) })

        val cancel = t.state == DlTask.State.QUEUED || t.state == DlTask.State.RUNNING
        card.addView(
            Ui.iconBtn(this, if (cancel) R.drawable.ic_dl_close else R.drawable.ic_dl_trash,
                if (cancel) "Batalkan" else "Hapus") {
                if (cancel) DlQueue.cancel(t.id) else DlQueue.remove(this, t)
            }.apply { alpha = 0.55f },
            lp(dp(36), dp(36)).apply { marginStart = dp(4) }
        )
        return card
    }

    private fun play(t: DlTask) {
        if (t.audio) {
            startActivity(Intent(this, MusicActivity::class.java))
            return
        }
        val uri = t.result ?: return
        runCatching {
            startActivity(
                Intent(Intent.ACTION_VIEW).setDataAndType(uri, "video/*")
                    .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            )
        }.onFailure { flash("Tidak bisa membuka video.") }
    }
}
