package com.niven.mangatl

import android.Manifest
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.net.ConnectivityManager
import android.os.Build
import android.os.Bundle
import android.text.InputType
import android.text.TextUtils
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.google.android.material.button.MaterialButton
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/** Layar Unduh (dari menu utama): tempel link, pilih kualitas, lihat antrean, perbarui mesin. */
class DownloadActivity : AppCompatActivity() {
    private lateinit var etUrl: EditText
    private lateinit var pickerBox: LinearLayout
    private lateinit var listBox: LinearLayout
    private lateinit var tvEngine: TextView
    private lateinit var picker: DlPicker
    private var pending: List<DlTask>? = null

    private val refresh: () -> Unit = { renderTasks() }

    private val notifPerm = registerForActivityResult(ActivityResultContracts.RequestPermission()) {
        pending?.let { go(it) }
    }

    private fun dp(v: Int) = Ui.dp(this, v)
    private val soft = Color.parseColor("#C7C7CC")
    private val muted = Color.parseColor("#8E8E93")

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(12), dp(16), dp(24))
        }

        // bar atas
        val bar = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        bar.addView(Ui.iconBtn(this, R.drawable.ic_back, "Kembali") { finish() },
            LinearLayout.LayoutParams(dp(44), dp(44)))
        bar.addView(TextView(this).apply {
            text = "Unduh"
            textSize = 22f
            setTextColor(Color.WHITE)
            typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
        }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { marginStart = dp(8) })
        col.addView(bar)

        // kolom link
        etUrl = EditText(this).apply {
            hint = "Tempel link video atau musik"
            setHintTextColor(Color.parseColor("#6E6E73"))
            setTextColor(Color.WHITE)
            textSize = 14f
            maxLines = 2
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_URI
            setBackgroundResource(R.drawable.bg_field)
            setPadding(dp(14), dp(12), dp(14), dp(12))
        }
        col.addView(etUrl, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            .apply { topMargin = dp(14) })

        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        row.addView(button("Tempel", outlined = true) { paste() },
            LinearLayout.LayoutParams(0, dp(48), 1f))
        row.addView(button("Cari kualitas", outlined = false) { search() },
            LinearLayout.LayoutParams(0, dp(48), 1.4f).apply { marginStart = dp(8) })
        col.addView(row, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            .apply { topMargin = dp(10) })

        // panel pilih kualitas
        picker = DlPicker(this) { start(it) }
        pickerBox = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundResource(R.drawable.bg_card)
            setPadding(dp(14), dp(14), dp(14), dp(14))
            visibility = View.GONE
            addView(picker.root)
        }
        col.addView(pickerBox, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            .apply { topMargin = dp(14) })

        // antrean
        col.addView(TextView(this).apply {
            text = "Antrean & riwayat"
            textSize = 13f
            setTextColor(muted)
            setPadding(dp(4), dp(22), 0, dp(8))
        })
        listBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        col.addView(listBox)

        // mesin
        tvEngine = TextView(this).apply {
            textSize = 12f
            setTextColor(muted)
            setPadding(dp(4), dp(20), 0, dp(6))
        }
        col.addView(tvEngine)
        col.addView(button("Perbarui mesin unduh", outlined = true) { updateEngine() },
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(46)))
        col.addView(button("Akun & cookies (video yang butuh login)", outlined = true) {
            startActivity(Intent(this, CookiesActivity::class.java))
        }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(46)).apply { topMargin = dp(8) })

        setContentView(ScrollView(this).apply {
            setBackgroundColor(Color.BLACK)
            isFillViewport = true
            addView(col)
        })

        intent.getStringExtra("url")?.let { etUrl.setText(it) }
        showEngine()
        prewarm()
    }

    override fun onStart() {
        super.onStart()
        DlQueue.addListener(refresh)
        renderTasks()
    }

    override fun onStop() {
        DlQueue.removeListener(refresh)
        super.onStop()
    }

    // ---------------------------------------------------------------- aksi

    private fun button(label: String, outlined: Boolean, onClick: () -> Unit) = MaterialButton(
        this, null,
        if (outlined) com.google.android.material.R.attr.materialButtonOutlinedStyle
        else com.google.android.material.R.attr.materialButtonStyle
    ).apply {
        text = label
        isAllCaps = false
        cornerRadius = dp(24)
        setOnClickListener { onClick() }
    }

    private fun paste() {
        val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        val t = cm.primaryClip?.takeIf { it.itemCount > 0 }?.getItemAt(0)?.coerceToText(this)?.toString()
        if (t.isNullOrBlank()) Toast.makeText(this, "Clipboard kosong.", Toast.LENGTH_SHORT).show()
        else etUrl.setText(t.trim())
    }

    private fun search() {
        val i = Intent().putExtra(Intent.EXTRA_TEXT, etUrl.text.toString())
        val u = DlUrl.extract(i)
        if (u == null) {
            Toast.makeText(this, "Isi dulu link yang benar (http/https).", Toast.LENGTH_SHORT).show()
            return
        }
        pickerBox.visibility = View.VISIBLE
        picker.load(u)
    }

    private fun start(tasks: List<DlTask>) {
        val needAsk = Build.VERSION.SDK_INT >= 33 && !DlPrefs.notifAsked(this) &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        if (needAsk) {
            DlPrefs.setNotifAsked(this)
            pending = tasks
            notifPerm.launch(Manifest.permission.POST_NOTIFICATIONS)
        } else {
            go(tasks)
        }
    }

    private fun go(tasks: List<DlTask>) {
        pending = null
        tasks.forEach { DlQueue.enqueue(this, it) }
        pickerBox.visibility = View.GONE
        etUrl.setText("")
        Toast.makeText(this,
            if (tasks.size == 1) "Ditambahkan ke antrean" else "${tasks.size} item ditambahkan ke antrean",
            Toast.LENGTH_SHORT).show()
    }

    private fun showEngine() {
        tvEngine.text = if (DlEngine.version.isEmpty()) "Mesin unduh: yt-dlp (menyiapkan…)"
        else "Mesin unduh: yt-dlp ${DlEngine.version}"
    }

    /** Siapkan mesin di latar begitu layar dibuka, dan perbarui otomatis tiap ~12 jam kalau bukan kuota. */
    private fun prewarm() {
        lifecycleScope.launch(Dispatchers.IO) {
            runCatching { DlEngine.ensureReady(this@DownloadActivity) }
            withContext(Dispatchers.Main) { showEngine() }
            val cm = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
            val stale = System.currentTimeMillis() - DlPrefs.lastUpdate(this@DownloadActivity) > 12L * 3600 * 1000
            if (DlEngine.version.isNotEmpty() && stale && !cm.isActiveNetworkMetered) {
                runCatching { DlUpdater.update(this@DownloadActivity) }
                DlPrefs.setLastUpdate(this@DownloadActivity, System.currentTimeMillis())
                withContext(Dispatchers.Main) { showEngine() }
            }
        }
    }

    private fun updateEngine() {
        Toast.makeText(this, "Memperbarui mesin unduh…", Toast.LENGTH_SHORT).show()
        lifecycleScope.launch {
            val msg = withContext(Dispatchers.IO) {
                runCatching {
                    DlEngine.ensureReady(this@DownloadActivity)
                    val r = DlUpdater.update(this@DownloadActivity)
                    DlPrefs.setLastUpdate(this@DownloadActivity, System.currentTimeMillis())
                    DlUpdater.message(r)
                }.getOrElse { DlEngine.friendlyError(it) }
            }
            showEngine()
            Toast.makeText(this@DownloadActivity, msg, Toast.LENGTH_LONG).show()
        }
    }

    // ---------------------------------------------------------------- antrean

    private fun renderTasks() {
        listBox.removeAllViews()
        val tasks = DlQueue.tasks.toList()
        if (tasks.isEmpty()) {
            listBox.addView(TextView(this).apply {
                text = "Belum ada unduhan. Tempel link video, musik, atau playlist di atas, atau bagikan link dari app lain ke BunnyTL."
                textSize = 13f
                setTextColor(muted)
                setLineSpacing(0f, 1.15f)
                setPadding(dp(4), dp(4), dp(4), dp(4))
            })
            return
        }
        tasks.forEach { listBox.addView(taskRow(it), LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
        ).apply { bottomMargin = dp(8) }) }
    }

    private fun statusText(t: DlTask): String = when (t.state) {
        DlTask.State.QUEUED -> "Menunggu antrean"
        DlTask.State.RUNNING -> {
            val pct = if (t.progress > 0f) " ${t.progress.toInt().coerceIn(0, 100)}%" else ""
            val eta = if (t.eta > 0) " · sisa ${DlOptions.duration(t.eta)}" else ""
            "${t.note}$pct$eta"
        }
        DlTask.State.DONE -> "Selesai · ${DlStore.folderLabel(t.audio)}"
        DlTask.State.FAILED -> "Gagal: ${t.error ?: "tidak diketahui"}"
        DlTask.State.CANCELED -> "Dibatalkan"
    }

    private fun taskRow(t: DlTask): View {
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundResource(R.drawable.bg_card)
            setPadding(dp(14), dp(12), dp(14), dp(10))
        }
        card.addView(TextView(this).apply {
            text = (if (t.audio) "♪  " else "▶  ") + t.title
            textSize = 14f
            setTextColor(Color.WHITE)
            maxLines = 2
            ellipsize = TextUtils.TruncateAt.END
        })
        card.addView(TextView(this).apply {
            text = statusText(t)
            textSize = 12f
            setTextColor(if (t.state == DlTask.State.FAILED) Color.parseColor("#FF8A80") else soft)
            setPadding(0, dp(4), 0, 0)
        })
        if (t.state == DlTask.State.RUNNING) {
            card.addView(ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
                max = 100
                if (t.progress > 0f) { isIndeterminate = false; progress = t.progress.toInt().coerceIn(0, 100) }
                else isIndeterminate = true
            }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(8)).apply { topMargin = dp(8) })
        }
        val actions = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.END }
        fun act(label: String, onClick: () -> Unit) = actions.addView(
            TextView(this).apply {
                text = label
                textSize = 13f
                setTextColor(Color.WHITE)
                typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
                setPadding(dp(12), dp(8), dp(12), dp(8))
                isClickable = true
                setOnClickListener { onClick() }
            }
        )
        when (t.state) {
            DlTask.State.QUEUED, DlTask.State.RUNNING -> act("Batal") { DlQueue.cancel(t.id) }
            DlTask.State.DONE -> {
                act("Putar") { play(t) }
                act("Hapus") { DlQueue.remove(t) }
            }
            DlTask.State.FAILED -> {
                act("Ulangi") { DlQueue.retry(this, t) }
                act("Hapus") { DlQueue.remove(t) }
            }
            DlTask.State.CANCELED -> act("Hapus") { DlQueue.remove(t) }
        }
        card.addView(actions)
        return card
    }

    private fun play(t: DlTask) {
        if (t.audio) {
            startActivity(Intent(this, MusicActivity::class.java))
            return
        }
        val uri = t.result ?: return
        runCatching {
            startActivity(
                Intent(Intent.ACTION_VIEW).setDataAndType(uri, "video/*")
                    .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            )
        }.onFailure { Toast.makeText(this, "Tidak bisa membuka video.", Toast.LENGTH_SHORT).show() }
    }
}
