package com.niven.mangatl

import android.content.MutableContextWrapper
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.view.ViewGroup
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import java.lang.ref.WeakReference

/**
 * Menyimpan WebView browser login selama app hidup. Keluar browser (Home / Unduhan / Kembali) tidak lagi
 * membuang halaman: masuk lagi ke situs yang sama = lanjut persis di tempat terakhir (tanpa muat ulang).
 * Beda situs / akun Claude / "Masuk akun" dari galat = halaman baru (dimuat ulang seperti biasa).
 * Proses app dimatikan Android = hilang (itu batas wajar, sesi login tetap aman di cookies).
 *
 * Satu WebView disimpan PER PROFIL: profil Default (situs unduhan: YouTube dkk) dan profil Claude (lihat
 * [ClaudeSlots.PROFILES]). Slot Claude di profil berbeda punya cookies sendiri-sendiri, jadi dua akun Claude
 * bisa hidup bersamaan: pindah slot tidak mematikan halaman akun yang ditinggal (chat tetap jalan di latar).
 */
object WebKeeper {
    private const val DEFAULT = ""

    private class Entry(val id: String, val web: WebView) {
        var key: String? = null
        var ua: String? = null
        var desktop = false
        var lastUse = 0L
    }

    private val entries = LinkedHashMap<String, Entry>()
    private var cur: Entry? = null
    private var ownerRef: WeakReference<CookiesActivity>? = null

    /** Penanda halaman yang sedang disimpan ("site:<kunci>" atau "claude:<slot>") di WebView yang terakhir diambil. */
    var key: String?
        get() = cur?.key
        set(v) { cur?.key = v }

    /** User-Agent aktif & status mode desktop saat ditinggal (WebView yang terakhir diambil). */
    val ua: String? get() = cur?.ua
    val desktop: Boolean get() = cur?.desktop ?: false

    /** true = WebView yang dikembalikan [obtain] adalah simpanan lama (bukan buatan baru). */
    var reused = false
        private set

    val owner: CookiesActivity? get() = ownerRef?.get()
    fun setOwner(a: CookiesActivity?) { ownerRef = a?.let { WeakReference(it) } }

    /**
     * Pilih profil untuk slot Claude [slot].
     * - Slot ini sudah hidup di salah satu profil -> pakai profil itu (lanjut persis).
     * - [needsLogin] (slot kosong / sesi habis): selalu di profil rumah slot, supaya login Google
     *   tiap profil tidak melewati 10 akun. Kalau profil rumah dipakai slot lain, halamannya digantikan.
     * - Selain itu: profil rumah kalau bebas, lalu profil bebas lain, terakhir profil yang paling lama tidak dipakai.
     * Null = profil Default (HP tidak mendukung profil terpisah).
     */
    fun claudeProfile(slot: Int, needsLogin: Boolean): String? {
        if (!ClaudeSlots.multiProfile()) return null
        val k = "claude:$slot"
        ClaudeSlots.PROFILES.firstOrNull { entries[it]?.key == k }?.let { return it }
        val home = ClaudeSlots.homeProfile(slot)
        if (needsLogin) return home
        if (entries[home] == null) return home
        ClaudeSlots.PROFILES.firstOrNull { entries[it] == null }?.let { return it }
        return ClaudeSlots.PROFILES.minByOrNull { entries[it]?.lastUse ?: 0L } ?: home
    }

    /** Ambil WebView simpanan untuk [profile] (dipasang ke [a]) atau buat baru. Null = profil Default. */
    fun obtain(a: CookiesActivity, profile: String?): WebView {
        val id = profile ?: DEFAULT
        val old = entries[id]
        if (old != null) {
            (old.web.parent as? ViewGroup)?.removeView(old.web)
            (old.web.context as? MutableContextWrapper)?.baseContext = a
            old.web.onResume()
            old.lastUse = SystemClock.elapsedRealtime()
            cur = old
            reused = true
            return old.web
        }
        reused = false
        val w = WebView(MutableContextWrapper(a))
        // profil harus dipasang sebelum halaman apa pun dimuat
        if (profile != null) ClaudeSlots.applyProfile(w, profile)
        w.addJavascriptInterface(BlobProxy(id), "BunnyBlob")
        w.addJavascriptInterface(ClaudeProxy(id), "BunnyClaude")
        val e = Entry(id, w)
        e.lastUse = SystemClock.elapsedRealtime()
        entries[id] = e
        cur = e
        return w
    }

    /**
     * Dipanggil dari onDestroy activity: lepas WebView dari layar tapi jangan dibuang.
     * [ua] / [desktop] = keadaan browser saat ditinggal (desktop null = tidak diubah).
     */
    fun park(w: WebView, ua: String?, desktop: Boolean?) {
        val e = entries.values.firstOrNull { it.web === w }
        if (e != null) {
            if (ua != null) e.ua = ua
            if (desktop != null) e.desktop = desktop
            e.lastUse = SystemClock.elapsedRealtime()
        }
        (w.parent as? ViewGroup)?.removeView(w)
        val app = w.context.applicationContext
        (w.context as? MutableContextWrapper)?.baseContext = app
        // video/audio dihentikan supaya tidak bersuara di latar; halaman & posisi tetap
        w.evaluateJavascript("document.querySelectorAll('video,audio').forEach(function(m){try{m.pause()}catch(e){}})", null)
        // WebView akun Claude TIDAK di-pause: chat yang sedang menulis jawaban di slot itu tetap jalan di latar
        // selama slot lain dipakai. Situs unduhan tetap di-pause seperti dulu.
        if (e == null || e.id == DEFAULT) w.onPause()
        // lepas rujukan ke activity lama
        w.webViewClient = WebViewClient()
        w.webChromeClient = WebChromeClient()
        w.setDownloadListener(null)
    }

    /** Buang WebView profil Default (mis. setelah cookies situs unduhan dihapus). Tidak menyentuh yang sedang tampil / WebView Claude. */
    fun drop() = dropEntry(DEFAULT, null)

    /** Buang WebView slot Claude [slot] kalau sedang disimpan (mis. slot dikosongkan). */
    fun dropClaude(slot: Int) = dropEntry(null, "claude:$slot")

    private fun dropEntry(id: String?, key: String?) {
        Handler(Looper.getMainLooper()).post {
            val e = entries.values.firstOrNull { (id != null && it.id == id) || (key != null && it.key == key) }
                ?: return@post
            if (e.web.parent != null) return@post
            entries.remove(e.id)
            if (cur === e) cur = null
            e.web.stopLoading()
            e.web.destroy()
        }
    }

    /** Jembatan JS dipasang sekali per WebView; diteruskan ke activity yang sedang aktif HANYA kalau WebView ini yang tampil. */
    class BlobProxy(private val id: String) {
        private fun active(): CookiesActivity? = owner?.takeIf { it.webProfileId == id }
        @JavascriptInterface fun save(token: String, dataUrl: String) { active()?.bridgeBlobSave(token, dataUrl) }
        @JavascriptInterface fun fail(token: String) { active()?.bridgeBlobFail(token) }
    }

    class ClaudeProxy(private val id: String) {
        @JavascriptInterface fun profile(json: String) {
            owner?.takeIf { it.webProfileId == id }?.bridgeClaudeProfile(json)
        }
    }
}
