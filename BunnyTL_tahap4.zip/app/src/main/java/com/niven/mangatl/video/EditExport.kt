package com.niven.mangatl

import android.content.ContentValues
import android.content.res.ColorStateList
import android.graphics.Bitmap
import android.graphics.Color
import android.net.Uri
import android.os.Build
import android.provider.MediaStore
import android.view.Gravity
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView
import androidx.activity.result.IntentSenderRequest
import androidx.lifecycle.lifecycleScope
import androidx.media3.common.Effect
import androidx.media3.common.MediaItem
import androidx.media3.common.audio.AudioProcessor
import androidx.media3.common.audio.ChannelMixingAudioProcessor
import androidx.media3.common.audio.ChannelMixingMatrix
import androidx.media3.common.audio.SonicAudioProcessor
import androidx.media3.effect.Presentation
import androidx.media3.effect.SpeedChangeEffect
import androidx.media3.transformer.Composition
import androidx.media3.transformer.DefaultEncoderFactory
import androidx.media3.transformer.EditedMediaItem
import androidx.media3.transformer.EditedMediaItemSequence
import androidx.media3.transformer.Effects
import androidx.media3.transformer.ExportException
import androidx.media3.transformer.ExportResult
import androidx.media3.transformer.Transformer
import androidx.media3.transformer.VideoEncoderSettings
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

// Editor video: susun komposisi Media3 dan ekspor hasil (simpan sebagai baru / timpa asli).
// Fungsi ekstensi dari VideoEditActivity; keadaan editor (clips, segs, ovs, ...) tetap dimiliki activity.

internal fun VideoEditActivity.volumeProcessor(v: Float): AudioProcessor {
    val p = ChannelMixingAudioProcessor()
    p.putChannelMixingMatrix(ChannelMixingMatrix.create(1, 1).scaleBy(v))
    p.putChannelMixingMatrix(ChannelMixingMatrix.create(2, 2).scaleBy(v))
    return p
}

internal fun VideoEditActivity.blankImage(): Uri {
    val f = File(cacheDir, "blank.png")
    if (!f.exists()) {
        val bmp = Bitmap.createBitmap(16, 16, Bitmap.Config.ARGB_8888)
        bmp.eraseColor(Color.BLACK)
        f.outputStream().use { bmp.compress(Bitmap.CompressFormat.PNG, 100, it) }
        bmp.recycle()
    }
    return Uri.fromFile(f)
}

internal fun VideoEditActivity.buildComposition(total: Long): Composition {
    var ovSettings: OvSettings? = null
    val vItems = ArrayList<EditedMediaItem>()
    val useOv = ovs.any { minOf(it.dur(), total - it.start) >= 200L }
    val (outW, outH) = canvasSize()
    val needSize = useOv || canvasKey != "asli" || clips.any { it.fill } || clips.firstOrNull()?.photo == true
    for (c in clips) {
        if (c.photo) {
            val pve = ArrayList<Effect>()
            if (c.fadeIn > 0L || c.fadeOut > 0L) pve.add(FadeMatrix(c.dur(), c.fade()))
            if (needSize) pve.add(Presentation.createForWidthAndHeight(outW, outH, if (c.fill) Presentation.LAYOUT_SCALE_TO_FIT_WITH_CROP else Presentation.LAYOUT_SCALE_TO_FIT))
            vItems.add(
                EditedMediaItem.Builder(MediaItem.fromUri(c.uri))
                    .setDurationUs(c.photoMs * 1000L)
                    .setFrameRate(30)
                    .setEffects(Effects(emptyList(), pve))
                    .build()
            )
        } else {
            val cc = MediaItem.ClippingConfiguration.Builder()
                .setStartPositionMs(c.start)
                .setEndPositionMs(c.end)
                .build()
            val mi = MediaItem.Builder().setUri(c.uri).setClippingConfiguration(cc).build()
            val ap = ArrayList<AudioProcessor>()
            val ve = ArrayList<Effect>()
            if (c.speed != 1f) {
                ve.add(SpeedChangeEffect(c.speed))
                val sonic = SonicAudioProcessor()
                sonic.setSpeed(c.speed)
                sonic.setPitch(1f)
                ap.add(sonic)
            }
            if (origVol != 1f) ap.add(volumeProcessor(origVol))
            if (c.fadeIn > 0L || c.fadeOut > 0L) ve.add(FadeMatrix(c.dur(), c.fade()))
            if (needSize) ve.add(Presentation.createForWidthAndHeight(outW, outH, if (c.fill) Presentation.LAYOUT_SCALE_TO_FIT_WITH_CROP else Presentation.LAYOUT_SCALE_TO_FIT))
            vItems.add(EditedMediaItem.Builder(mi).setEffects(Effects(ap, ve)).build())
        }
    }
    val seqs = ArrayList<EditedMediaItemSequence>()
    val mainSeq = EditedMediaItemSequence.Builder(vItems).build()
    if (!useOv) {
        seqs.add(mainSeq)
    } else {
        // media3 menggambar input pertama (utama) paling atas dan menunggu semua input punya frame.
        // Jadi: input 0 = latar kosong tak terlihat (penentu waktu), lalu lapisan dari depan ke belakang,
        // dan video utama di paling belakang. Jeda diisi gambar pengisi karena gap video belum menghasilkan frame.
        val specs = ArrayList<OvSpec?>()
        val blank = blankImage()
        fun filler(ms: Long): EditedMediaItem =
            EditedMediaItem.Builder(MediaItem.Builder().setUri(blank).setMimeType("image/png").build())
                .setDurationUs(ms * 1000L)
                .setFrameRate(30)
                .build()

        seqs.add(EditedMediaItemSequence.Builder().addItem(filler(total)).build())
        specs.add(OvSpec(0L, total, TimelineView.Fade(0L, 0L, 0.5f, 0.5f, 0.5f, 0.5f), 0f, 0f, true))

        for (o in ovs.reversed()) {
            val len = minOf(o.dur(), total - o.start)
            if (len < 200L) continue
            val tw = maxOf(2, Math.round(o.wf * outW) / 2 * 2)
            val th = maxOf(2, Math.round(tw / o.aspect()) / 2 * 2)
            val size = Presentation.createForWidthAndHeight(tw, th, Presentation.LAYOUT_SCALE_TO_FIT)
            val sb = EditedMediaItemSequence.Builder()
            if (o.start >= 50L) sb.addItem(filler(o.start))
            if (o.photo) {
                sb.addItem(
                    EditedMediaItem.Builder(MediaItem.fromUri(o.uri))
                        .setDurationUs(len * 1000L)
                        .setFrameRate(30)
                        .setEffects(Effects(emptyList(), listOf<Effect>(size)))
                        .build()
                )
            } else {
                val cc = MediaItem.ClippingConfiguration.Builder()
                    .setStartPositionMs(o.srcStart)
                    .setEndPositionMs(o.srcStart + (len * o.speed).toLong())
                    .build()
                val mi = MediaItem.Builder().setUri(o.uri).setClippingConfiguration(cc).build()
                val ove = ArrayList<Effect>()
                if (o.speed != 1f) ove.add(SpeedChangeEffect(o.speed))
                ove.add(size)
                sb.addItem(
                    EditedMediaItem.Builder(mi)
                        .setRemoveAudio(true)
                        .setEffects(Effects(emptyList(), ove))
                        .build()
                )
            }
            val tail = total - o.start - len
            if (tail >= 50L) sb.addItem(filler(tail))
            seqs.add(sb.build())
            specs.add(OvSpec(o.start, len, o.fade(), o.cx * 2f - 1f, 1f - o.cy * 2f, false))
        }
        seqs.add(mainSeq)
        specs.add(null)
        ovSettings = OvSettings(specs, outW, outH)
    }

    val sUri = song
    if (sUri != null) {
        val sb = EditedMediaItemSequence.Builder()
        var cursor = 0L
        var added = 0
        for (sg in segs.sortedBy { it.start }) {
            val len = minOf(sg.len(), total - sg.start)
            if (len < 100L || sg.start < cursor) continue
            val fi = minOf(sg.fadeIn, len)
            val fo = minOf(sg.fadeOut, len - fi)
            val cc = MediaItem.ClippingConfiguration.Builder()
                .setStartPositionMs(sg.from)
                .setEndPositionMs(sg.from + len)
                .build()
            val mi = MediaItem.Builder().setUri(sUri).setClippingConfiguration(cc).build()
            val procs = ArrayList<AudioProcessor>()
            procs.add(volumeProcessor(songVol))
            if (fi > 0L || fo > 0L) procs.add(FadeVolume(len, TimelineView.Fade(fi, fo, sg.inX, sg.inY, sg.outX, sg.outY)))
            val ei = EditedMediaItem.Builder(mi)
                .setRemoveVideo(true)
                .setEffects(Effects(procs, emptyList()))
                .build()
            if (sg.start > cursor) sb.addGap((sg.start - cursor) * 1000L)
            sb.addItem(ei)
            cursor = sg.start + len
            added++
        }
        if (added > 0) seqs.add(sb.build())
    }
    val cb = Composition.Builder(seqs)
    ovSettings?.let { cb.setVideoCompositorSettings(it) }
    if (useOv) cb.experimentalSetForceAudioTrack(true)
    val hasPhoto = clips.any { it.photo }
    if (hasPhoto) cb.experimentalSetForceAudioTrack(true)
    val vids = clips.filter { !it.photo && it.w > 0 && it.h > 0 }
    val sizes = vids.map { it.w to it.h }.distinct()
    if (!needSize && (hasPhoto || sizes.size > 1)) {
        var w = if (vids.isNotEmpty()) vids[0].w else 1080
        var h = if (vids.isNotEmpty()) vids[0].h else 1920
        w -= w % 2
        h -= h % 2
        cb.setEffects(
            Effects(
                emptyList(),
                listOf<Effect>(Presentation.createForWidthAndHeight(w, h, Presentation.LAYOUT_SCALE_TO_FIT))
            )
        )
    }
    return cb.build()
}

internal fun VideoEditActivity.export(overwrite: Boolean) {
    val total = total()
    val comp = try {
        buildComposition(total)
    } catch (e: Exception) {
        toast("Gagal menyiapkan video: ${e.message}")
        return
    }
    val out = File(cacheDir, "edit_" + System.currentTimeMillis() + ".mp4")
    outFile = out
    exporting = true

    val br = clips.filter { !it.photo }.maxOfOrNull { it.bitrate } ?: 0
    val encBuilder = DefaultEncoderFactory.Builder(this)
    if (br > 0) {
        encBuilder.setRequestedVideoEncoderSettings(
            VideoEncoderSettings.Builder().setBitrate(br.coerceIn(2_000_000, 80_000_000)).build()
        )
    }

    val t = Transformer.Builder(this)
        .setEncoderFactory(encBuilder.build())
        .addListener(object : Transformer.Listener {
            override fun onCompleted(composition: Composition, exportResult: ExportResult) {
                onExportDone(out, overwrite)
            }

            override fun onError(
                composition: Composition, exportResult: ExportResult, exportException: ExportException
            ) {
                onExportFailed(out, exportException.message ?: "kesalahan tidak diketahui")
            }
        })
        .build()
    transformer = t

    progressDlg = Sheet.custom(this, "Menyimpan video\u2026") { p, close ->
        val pb = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal)
        pb.max = 100
        pb.progressTintList = ColorStateList.valueOf(Color.WHITE)
        progressBar = pb
        val pct = TextView(this)
        pct.text = "0%"
        pct.textSize = 13f
        pct.gravity = Gravity.CENTER
        pct.setTextColor(clr(R.color.text_soft))
        tvPct = pct
        p.addView(pb, LinearLayout.LayoutParams(-1, -2).apply { setMargins(dp(14), dp(8), dp(14), dp(4)) })
        p.addView(pct)
        p.addView(
            Sheet.buttonRow(
                this,
                Sheet.button(this, "Batal", false) {
                    t.cancel()
                    close()
                    stopProgress()
                    out.delete()
                    exporting = false
                }
            )
        )
    }
    progressDlg?.setCancelable(false)

    try {
        t.start(comp, out.absolutePath)
        handler.post(progressTick)
    } catch (e: Exception) {
        onExportFailed(out, e.message ?: "gagal memulai")
    }
}

internal fun VideoEditActivity.stopProgress() {
    handler.removeCallbacks(progressTick)
    transformer = null
    progressDlg?.dismiss()
    progressDlg = null
}

internal fun VideoEditActivity.onExportFailed(out: File, msg: String) {
    stopProgress()
    out.delete()
    exporting = false
    toast("Gagal menyimpan: $msg")
}

internal fun VideoEditActivity.onExportDone(out: File, overwrite: Boolean) {
    stopProgress()
    if (overwrite) {
        overwriteOriginal(out)
    } else {
        lifecycleScope.launch {
            val ok = withContext(Dispatchers.IO) { saveAsNew(out) }
            out.delete()
            exporting = false
            if (ok) {
                toast("Video baru disimpan.")
                finish()
            } else {
                toast("Gagal menyimpan ke galeri.")
            }
        }
    }
}

internal fun VideoEditActivity.saveAsNew(out: File): Boolean {
    val base = origName.substringBeforeLast('.')
    val name = base + "_edit.mp4"
    val allowed = listOf("DCIM/", "Movies/", "Pictures/")
    val rel = if (origRel.isNotEmpty() && allowed.any { origRel.startsWith(it) }) origRel else "Movies/BunnyTL/"
    fun insert(path: String?): Uri? {
        val v = ContentValues()
        v.put(MediaStore.Video.Media.DISPLAY_NAME, name)
        v.put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
        if (Build.VERSION.SDK_INT >= 29 && path != null) {
            v.put(MediaStore.Video.Media.RELATIVE_PATH, path)
            v.put(MediaStore.Video.Media.IS_PENDING, 1)
        }
        return contentResolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, v)
    }
    return try {
        val uri = try {
            insert(rel)
        } catch (e: Exception) {
            insert("Movies/BunnyTL/")
        } ?: return false
        contentResolver.openOutputStream(uri, "w")?.use { o -> out.inputStream().use { it.copyTo(o) } }
        if (Build.VERSION.SDK_INT >= 29) {
            val v = ContentValues()
            v.put(MediaStore.Video.Media.IS_PENDING, 0)
            contentResolver.update(uri, v, null, null)
        }
        true
    } catch (e: Exception) {
        false
    }
}

internal fun VideoEditActivity.overwriteOriginal(out: File) {
    fun copy() {
        lifecycleScope.launch {
            val ok = withContext(Dispatchers.IO) {
                try {
                    contentResolver.openOutputStream(origUri, "wt")?.use { o ->
                        out.inputStream().use { it.copyTo(o) }
                    }
                    true
                } catch (e: Exception) {
                    false
                }
            }
            out.delete()
            exporting = false
            if (ok) {
                toast("Video asli diganti.")
                finish()
            } else {
                toast("Gagal menimpa video asli.")
            }
        }
    }
    if (Build.VERSION.SDK_INT >= 30) {
        try {
            val pi = MediaStore.createWriteRequest(contentResolver, listOf(origUri))
            pendingWrite = { copy() }
            writeLauncher.launch(IntentSenderRequest.Builder(pi.intentSender).build())
        } catch (e: Exception) {
            exporting = false
            toast("Gagal: ${e.message}")
        }
    } else {
        copy()
    }
}
