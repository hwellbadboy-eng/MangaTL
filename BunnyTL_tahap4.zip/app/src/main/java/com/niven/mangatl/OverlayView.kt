package com.niven.mangatl

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Rect
import android.graphics.RectF
import android.text.Layout
import android.text.StaticLayout
import android.text.TextPaint
import android.text.TextUtils
import android.view.View

/**
 * Layar transparan penuh: menggambar terjemahan tepat di atas posisi teks aslinya.
 *
 * - Tinggi kotak = tinggi teks asli. Kalau terjemahan lebih panjang: huruf mengecil dulu, lalu kotak
 *   melebar ke samping hanya sejauh ruang kosong (setengah jarak ke kotak tetangga sebaris).
 * - Kalau tetap tidak muat, perilakunya mengikuti [overflowMode]:
 *   0 = teks bergulir ke kiri berulang (loop) supaya terbaca semua (teks satu baris),
 *   1 = huruf terus dikecilkan sampai muat,
 *   2 = kotak diperpanjang (ke samping sampai tepi layar, lalu ke bawah kalau perlu).
 */
class OverlayView(context: Context) : View(context) {

    /** [lines] = jumlah baris teks asli (untuk memperkirakan ukuran huruf aslinya). */
    class Item(val rect: Rect, val text: String, val bg: Int, val fg: Int, val lines: Int = 1)

    var items: List<Item> = emptyList()
        private set

    /** Keburaman latar kotak terjemahan, 0..255 (diatur dari Opsi). */
    var bgAlpha: Int = 255

    /** 0 = rata kiri, 1 = rata tengah. */
    var align: Int = 0

    /** 0 = bergulir (loop), 1 = mengecil, 2 = perpanjang kotak. */
    var overflowMode: Int = 0

    private val bgPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val tp = TextPaint(Paint.ANTI_ALIAS_FLAG)
    private val density = resources.displayMetrics.density
    private val t0 = System.nanoTime()

    fun setItems(list: List<Item>) {
        items = list
        invalidate()
    }

    private class Fit(val layout: StaticLayout, val size: Float, val truncated: Boolean)

    private fun layoutFor(text: String, w: Int, size: Float, maxLines: Int, ellipsize: Boolean): StaticLayout {
        tp.textSize = size
        val alignment = if (align == 1) Layout.Alignment.ALIGN_CENTER else Layout.Alignment.ALIGN_NORMAL
        val b = StaticLayout.Builder.obtain(text, 0, text.length, tp, w.coerceAtLeast(1))
            .setAlignment(alignment)
            .setIncludePad(false)
        if (ellipsize) {
            b.setMaxLines(maxLines.coerceAtLeast(1))
            b.setEllipsize(TextUtils.TruncateAt.END)
        }
        return b.build()
    }

    /** Ukuran huruf terbesar (antara minPx dan maxPx) yang masih muat di kotak w x h. */
    private fun fit(text: String, w: Int, h: Int, minPx: Float, maxPx: Float): Fit {
        var lo = minPx
        var hi = if (maxPx > minPx) maxPx else minPx
        if (layoutFor(text, w, lo, 0, false).height > h) {
            // Tidak muat walau huruf paling kecil: terpaksa dipotong.
            tp.textSize = lo
            val fm = tp.fontMetricsInt
            val lineH = (fm.descent - fm.ascent).coerceAtLeast(1)
            val maxLines = (h / lineH).coerceAtLeast(1)
            return Fit(layoutFor(text, w, lo, maxLines, true), lo, true)
        }
        if (layoutFor(text, w, hi, 0, false).height <= h) {
            return Fit(layoutFor(text, w, hi, 0, false), hi, false)
        }
        for (i in 0 until 7) {
            val mid = (lo + hi) / 2f
            if (layoutFor(text, w, mid, 0, false).height <= h) lo = mid else hi = mid
        }
        return Fit(layoutFor(text, w, lo, 0, false), lo, false)
    }

    /** Satu baris panjang (tanpa pembungkusan) dengan huruf terbesar yang tingginya masih muat di h. */
    private fun singleLine(text: String, h: Int, minPx: Float, maxPx: Float): StaticLayout {
        var lo = minPx
        var hi = if (maxPx > minPx) maxPx else minPx
        if (layoutFor(text, 20000, hi, 0, false).height <= h) return layoutFor(text, 20000, hi, 0, false)
        for (i in 0 until 7) {
            val mid = (lo + hi) / 2f
            if (layoutFor(text, 20000, mid, 0, false).height <= h) lo = mid else hi = mid
        }
        return layoutFor(text, 20000, lo, 0, false)
    }

    /** Ruang kosong di kanan kotak [i] sampai tetangga sebaris (jatah setengah jarak) atau tepi layar. */
    private fun freeRight(i: Int, r: RectF, rs: List<RectF>, edge: Float): Float {
        var best = edge - r.right
        for (j in rs.indices) {
            if (j == i) continue
            val o = rs[j]
            if (o.bottom <= r.top || o.top >= r.bottom) continue
            if (o.left >= r.right - 1f) best = Math.min(best, (o.left - r.right) / 2f)
        }
        return if (best > 0f) best else 0f
    }

    private fun freeLeft(i: Int, r: RectF, rs: List<RectF>, edge: Float): Float {
        var best = r.left - edge
        for (j in rs.indices) {
            if (j == i) continue
            val o = rs[j]
            if (o.bottom <= r.top || o.top >= r.bottom) continue
            if (o.right <= r.left + 1f) best = Math.min(best, (r.left - o.right) / 2f)
        }
        return if (best > 0f) best else 0f
    }

    override fun onDraw(canvas: Canvas) {
        if (items.isEmpty()) return
        val loc = IntArray(2)
        getLocationOnScreen(loc)
        val padX = 3f * density
        val padY = 1.5f * density
        val inner = 2f * density
        val margin = 4f * density
        val shrinkMin = 4f * density
        val minPx = if (overflowMode == 1) shrinkMin else 6f * density
        var animating = false

        val rs = ArrayList<RectF>()
        for (it in items) {
            rs.add(
                RectF(
                    (it.rect.left - loc[0]).toFloat(), (it.rect.top - loc[1]).toFloat(),
                    (it.rect.right - loc[0]).toFloat(), (it.rect.bottom - loc[1]).toFloat()
                )
            )
        }

        for (i in items.indices) {
            val item = items[i]
            val r = rs[i]
            val boxH = r.height() + 2f * padY
            val h = (boxH - 2f * inner).toInt().coerceAtLeast(1)
            val baseW = r.width() + 2f * padX
            val lines = item.lines.coerceAtLeast(1)
            // Perkiraan ukuran huruf asli: tinggi baris / 1.15. Terjemahan tidak perlu lebih besar dari itu.
            val pref = (r.height() / lines) / 1.15f
            val maxPx = Math.min(Math.max(pref * 1.1f, minPx), 40f * density)

            tp.color = item.fg
            var left = r.left - padX
            var boxW = baseW
            var drawH = boxH
            var f = fit(item.text, (baseW - 2f * inner).toInt(), h, minPx, maxPx)

            // 1) Lebarkan sedikit ke samping, hanya ke ruang kosong.
            if (f.size < maxPx * 0.85f) {
                val fr = freeRight(i, r, rs, width - margin)
                val room = if (align == 1) 2f * Math.min(fr, freeLeft(i, r, rs, margin)) else fr
                val maxExtra = Math.min(room, baseW * 0.6f)
                if (maxExtra > 2f * density) {
                    for (k in 1..6) {
                        val extra = maxExtra * k / 6f
                        val g = fit(item.text, (baseW + extra - 2f * inner).toInt(), h, minPx, maxPx)
                        if (g.size > f.size) {
                            f = g
                            boxW = baseW + extra
                            left = if (align == 1) r.left - padX - extra / 2f else r.left - padX
                        }
                        if (f.size >= maxPx * 0.9f) break
                    }
                }
            }

            // 2) Masih terlalu kecil / tidak muat: ikuti pilihan "teks kepanjangan".
            var marquee: StaticLayout? = null
            val tooSmall = f.truncated || f.size < maxPx * 0.6f
            if (tooSmall && overflowMode == 0) {
                if (lines == 1) {
                    marquee = singleLine(item.text, h, minPx, maxPx)
                } else {
                    // Teks beberapa baris tidak cocok digulir: kecilkan sampai muat.
                    f = fit(item.text, (boxW - 2f * inner).toInt(), h, shrinkMin, maxPx)
                }
            } else if (tooSmall && overflowMode == 2) {
                val readable = Math.max(minPx, maxPx * 0.8f)
                val roomR = width - margin - r.right
                val roomL = r.left - margin
                val room = Math.max(if (align == 1) 2f * Math.min(roomR, roomL) else roomR, 0f)
                for (k in 1..8) {
                    val extra = room * k / 8f
                    val g = fit(item.text, (baseW + extra - 2f * inner).toInt(), h, minPx, maxPx)
                    f = g
                    boxW = baseW + extra
                    left = if (align == 1) r.left - padX - extra / 2f else r.left - padX
                    if (!g.truncated && g.size >= readable) break
                }
                if (f.truncated) {
                    // Sudah selebar mungkin tapi belum muat: kotak boleh memanjang ke bawah.
                    val lay = layoutFor(item.text, (boxW - 2f * inner).toInt(), readable, 0, false)
                    f = Fit(lay, readable, false)
                    drawH = Math.max(boxH, lay.height + 2f * inner)
                }
            }

            if (left < 0f) {
                boxW += left
                left = 0f
            }
            if (left + boxW > width) boxW = (width - left).coerceAtLeast(1f)

            val top = r.top - padY
            bgPaint.color = (item.bg and 0x00FFFFFF) or (bgAlpha.coerceIn(0, 255) shl 24)
            canvas.drawRoundRect(RectF(left, top, left + boxW, top + drawH), 5f * density, 5f * density, bgPaint)

            canvas.save()
            canvas.clipRect(left, top, left + boxW, top + drawH)
            val m = marquee
            if (m != null) {
                val textW = m.getLineWidth(0)
                val innerW = boxW - 2f * inner
                if (textW <= innerW) {
                    canvas.translate(left + inner, top + (drawH - m.height) / 2f)
                    m.draw(canvas)
                } else {
                    // Teks bergulir ke kiri terus-menerus (loop), diam sebentar di awal tiap putaran.
                    val gap = 24f * density
                    val period = textW + gap
                    val speed = 45f * density
                    val pause = 1.2f
                    val cycle = period / speed + pause
                    val elapsed = (System.nanoTime() - t0) / 1_000_000_000f
                    val phase = elapsed % cycle
                    val off = if (phase < pause) 0f else (phase - pause) * speed
                    canvas.translate(left + inner - off, top + (drawH - m.height) / 2f)
                    m.draw(canvas)
                    canvas.translate(period, 0f)
                    m.draw(canvas)
                    animating = true
                }
            } else {
                val layout = f.layout
                canvas.translate(left + inner, top + (drawH - layout.height) / 2f)
                layout.draw(canvas)
            }
            canvas.restore()
        }
        if (animating) postInvalidateOnAnimation()
    }
}
