package com.niven.mangatl

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Rect
import android.widget.LinearLayout
import android.os.Build
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import androidx.activity.result.contract.ActivityResultContracts
import android.view.Gravity
import android.view.LayoutInflater
import android.text.Editable
import android.text.TextWatcher
import android.view.View
import android.view.animation.OvershootInterpolator
import android.view.WindowManager
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import android.widget.Button
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

class ChatActivity : AppCompatActivity() {

    class Msg(val isUser: Boolean, var text: String)

    companion object {
        // Riwayat tetap ada selama app hidup, walau layar chat ditutup lalu dibuka lagi.
        private val store = ArrayList<Msg>()

        /** Berapa kali judul "Chat AI" harus diketuk beruntun untuk menyembunyikan/menampilkan avatar (2 atau 3). */
        private const val TITLE_TAPS = 2
    }

    private lateinit var list: RecyclerView
    private lateinit var input: EditText
    private lateinit var btnSend: Button
    private lateinit var adapter: MsgAdapter
    private var sending = false
    private lateinit var btnMic: Button
    private lateinit var btnVoice: Button
    private var recognizer: SpeechRecognizer? = null
    private var listening = false
    private var micStatus: String? = null
    private var micInfoShown = false
    private var whisperFailed = false // kalau Whisper error, sisa sesi pakai mic bawaan
    private var live = false
    private var turn = 0
    private val handler = Handler(Looper.getMainLooper())

    // Avatar Live2D (tubuh AI): gerak mengikuti keadaan chat. Model dipilih lewat tahan-lama judul "Chat AI".
    private var karin: KarinView? = null
    private lateinit var cfg: ModelCfg
    private lateinit var rootFrame: AvatarDragLayout
    private lateinit var bgHost: ViewGroup
    private lateinit var frontHost: ViewGroup
    private lateinit var karinWrap: ViewGroup
    private lateinit var body: ViewGroup
    private lateinit var inputBar: View
    private lateinit var chatRoot: ViewGroup
    private lateinit var topStage: View
    private lateinit var chatArea: View
    private lateinit var tearEdge: View
    private lateinit var chipRow: View
    private var karinWanted = true
    private var avatarFront = false
    private var keyboardUp = false
    private var karinErrorShown = false
    private var titleTaps = 0
    private var lastExprKey = ""
    private var lastExprAt = 0L
    private var lastTitleTap = 0L
    private var uiActive = false
    private fun prefs() = getSharedPreferences("mangatl", MODE_PRIVATE)
    private val karinTick = object : Runnable {
        override fun run() {
            val k = karin
            if (k != null && k.isShown) {
                k.anim.state = when {
                    Voice.playing -> KarinState.SPEAKING
                    sending || Voice.speaking -> KarinState.THINKING
                    listening -> KarinState.LISTENING
                    else -> KarinState.IDLE
                }
            }
            handler.postDelayed(this, 120)
        }
    }

    private val micPerm = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { ok ->
        if (ok) startListening()
        else {
            if (live) setLive(false)
            Toast.makeText(this, "Izin mikrofon ditolak.", Toast.LENGTH_SHORT).show()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_chat)
        Fx.enter(this, findViewById(R.id.chatRoot))

        list = findViewById(R.id.list)
        setupKarin()
        input = findViewById(R.id.input)
        btnSend = findViewById(R.id.btnSend)
        btnMic = findViewById(R.id.btnMic)
        btnMic.setOnClickListener { onMic() }
        btnMic.setOnLongClickListener { onMicLong() }
        btnVoice = findViewById(R.id.btnVoice)
        updateVoiceButton()
        input.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}
            override fun onTextChanged(s: CharSequence?, st: Int, b: Int, c: Int) {}
            override fun afterTextChanged(s: Editable?) {
                updateSlot()
            }
        })
        if (Voice.autoSpeak(this)) Voice.preload(this)
        if (Ear.available(this)) Ear.preload(this)
        btnVoice.setOnClickListener {
            val on = !Voice.autoSpeak(this)
            if (on && Voice.findVoice(this) == null) {
                Toast.makeText(
                    this,
                    "Model suara belum ada. Salin folder model Supertonic ke:\n${getExternalFilesDir(null)}",
                    Toast.LENGTH_LONG
                ).show()
                return@setOnClickListener
            }
            Voice.setAutoSpeak(this, on)
            if (!on) Voice.stop()
            updateVoiceButton()
        }

        adapter = MsgAdapter(store) { m -> speakMsg(m) }
        list.layoutManager = LinearLayoutManager(this).apply { stackFromEnd = true }
        list.adapter = adapter
        if (store.isNotEmpty()) list.scrollToPosition(store.size - 1)

        btnSend.setOnClickListener {
            if (sending) {
                if (live) setLive(false)
                Voice.stop()
                Gemma.chatCancel()
            } else {
                val t = input.text.toString().trim()
                if (t.isNotEmpty()) {
                    send(t)
                    input.setText("")
                }
            }
        }

        input.setOnEditorActionListener { _, actionId, _ ->
            if (actionId == EditorInfo.IME_ACTION_SEND) {
                btnSend.performClick()
                true
            } else {
                false
            }
        }

        findViewById<Button>(R.id.btnExplain).setOnClickListener {
            if (sending) return@setOnClickListener
            if (Gemma.lastPage.isEmpty()) {
                Toast.makeText(this, "Terjemahkan satu halaman dulu.", Toast.LENGTH_SHORT).show()
            } else {
                send(
                    "Jelaskan halaman manga yang terakhir tadi: emosi dan nada tiap karakter, " +
                        "idiom/slang/makna tersembunyi yang tidak boleh diterjemahkan harfiah, " +
                        "dan kasih alternatif terjemahan yang lebih natural untuk baris yang menurutmu kurang pas."
                )
            }
        }

        findViewById<Button>(R.id.btnPrompt).setOnClickListener { PromptSlots.show(this) }

        findViewById<Button>(R.id.btnClear).setOnClickListener {
            if (sending) return@setOnClickListener
            store.clear()
            adapter.notifyDataSetChanged()
        }
    }

    private fun loadCfg(id: String?): ModelCfg =
        try {
            ModelCfg.load(this, id ?: "karin")
        } catch (_: Throwable) {
            ModelCfg.load(this, "karin")
        }

    private fun setupKarin() {
        rootFrame = findViewById(R.id.rootFrame)
        bgHost = findViewById(R.id.bgHost)
        frontHost = findViewById(R.id.frontHost)
        karinWrap = findViewById(R.id.karinWrap)
        body = findViewById(R.id.body)
        inputBar = findViewById(R.id.inputBar)
        chatRoot = findViewById(R.id.chatRoot)
        topStage = findViewById(R.id.topStage)
        chatArea = findViewById(R.id.chatArea)
        tearEdge = findViewById(R.id.tearEdge)
        chipRow = findViewById(R.id.chipRow)
        // Satu profil zig-zag dipakai bersama: potongan chat, tepi badan (GL), dan gambar sobekan (mode panggung).
        (list as TornRecyclerView).setTear(TearProfile.get(this), TearProfile.HEIGHT_DP * resources.displayMetrics.density)

        karinWanted = prefs().getBoolean("karin_on", true)
        avatarFront = prefs().getBoolean("avatar_front", false)
        cfg = loadCfg(prefs().getString("karin_model", "karin"))
        // Decode tekstur di thread latar sekarang juga, supaya siap saat layar GL dibuat.
        if (karinWanted) KarinTex.prefetch(this, cfg.texturePaths())

        // Ketuk judul "Chat AI" = tampil/sembunyikan avatar. Tahan lama = menu (model, posisi, ekspresi).
        val title = findViewById<View>(R.id.tvTitle)
        title.setOnClickListener {
            // Sembunyi/tampil avatar butuh KETUK BERUNTUN (TITLE_TAPS kali) supaya tidak mudah kepencet.
            val now = SystemClock.uptimeMillis()
            if (now - lastTitleTap > 450L) titleTaps = 0
            lastTitleTap = now
            if (++titleTaps >= TITLE_TAPS) {
                titleTaps = 0
                toggleKarin()
            }
        }
        title.setOnLongClickListener {
            showAvatarMenu()
            true
        }
        // Tata letak body (panggung / garis pudar chat) dihitung ulang tiap ukuran berubah.
        body.addOnLayoutChangeListener { _, _, _, _, _, _, _, _, _ -> layoutBody() }
        topStage.addOnLayoutChangeListener { _, _, _, _, _, _, _, _, _ -> layoutBody() }
        inputBar.addOnLayoutChangeListener { _, _, _, _, _, _, _, _, _ -> layoutBody() }
        rootFrame.pokeFilter = { rx, ry -> pokeAllowed(rx, ry) }
        // Keyboard muncul = avatar menyingkir sementara supaya daftar chat tetap lega.
        val decor = window.decorView
        decor.viewTreeObserver.addOnGlobalLayoutListener {
            val r = Rect()
            decor.getWindowVisibleDisplayFrame(r)
            val full = decor.rootView.height
            val up = full > 0 && (full - r.bottom) > full * 0.15f
            if (up != keyboardUp) {
                keyboardUp = up
                applyKarin()
            }
        }
        applyKarin()
    }

    private fun toggleKarin() {
        karinWanted = !karinWanted
        prefs().edit().putBoolean("karin_on", karinWanted).apply()
        applyKarin()
        Toast.makeText(this, if (karinWanted) "Avatar tampil" else "Avatar disembunyikan", Toast.LENGTH_SHORT).show()
    }

    /** Buat tampilan GL untuk model aktif dan pasang di tempat yang sesuai (panggung / belakang chat / depan chat). */
    private fun createKarin() {
        val front = cfg.full && avatarFront
        val v = KarinView(this, cfg, front)
        v.anim.levelSource = { Voice.mouthLevel() }
        v.onError = { msg ->
            if (!karinErrorShown) {
                karinErrorShown = true
                Toast.makeText(this, "Avatar gagal dimuat: $msg", Toast.LENGTH_LONG).show()
            }
        }
        val lp = FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
        when {
            !cfg.full -> {
                v.setTear(TearProfile.get(this), TearProfile.HEIGHT_DP * resources.displayMetrics.density)
                karinWrap.addView(v, lp)
            }
            front -> frontHost.addView(v, lp)
            else -> bgHost.addView(v, lp)
        }
        karin = v
        // Di depan chat: tahan lama badan avatar = geser bebas. Posisi terakhir diingat per model.
        rootFrame.target = v
        rootFrame.dragEnabled = front
        if (front) {
            v.setDrag(prefs().getFloat("avatar_dx_${cfg.id}", 0f), prefs().getFloat("avatar_dy_${cfg.id}", 0f))
            val mid = cfg.id
            rootFrame.onDragEnd = { x, y ->
                prefs().edit().putFloat("avatar_dx_$mid", x).putFloat("avatar_dy_$mid", y).apply()
            }
        }
        KarinTex.prefetch(this, cfg.texturePaths())
        if (uiActive) v.onResume()
    }

    /** Hancurkan tampilan GL (konteks + tekstur ikut lepas dari memori GPU). */
    private fun destroyKarin() {
        val k = karin ?: return
        rootFrame.target = null
        k.onPause()
        (k.parent as? ViewGroup)?.removeView(k)
        karin = null
        KarinTex.prefetch(this, emptyList())   // buang decode yang menggantung
    }

    private fun switchModel(id: String) {
        if (id == cfg.id) return
        prefs().edit().putString("karin_model", id).apply()
        destroyKarin()
        cfg = loadCfg(id)
        karinErrorShown = false
        if (!karinWanted) {
            karinWanted = true
            prefs().edit().putBoolean("karin_on", true).apply()
        }
        applyKarin()
        Toast.makeText(this, cfg.name, Toast.LENGTH_SHORT).show()
    }

    private fun toggleFront() {
        avatarFront = !avatarFront
        prefs().edit().putBoolean("avatar_front", avatarFront).apply()
        destroyKarin()
        applyKarin()
        Toast.makeText(
            this,
            if (avatarFront) "Avatar di depan chat. Tahan lama badan avatar untuk menggesernya" else "Avatar di belakang chat",
            Toast.LENGTH_LONG
        ).show()
    }

    private fun showAvatarMenu() {
        val items = ArrayList<String>()
        val acts = ArrayList<() -> Unit>()
        for ((id, name) in ModelCfg.list(this)) {
            items.add((if (id == cfg.id) "●  " else "○  ") + name)
            acts.add { switchModel(id) }
        }
        if (cfg.full) {
            items.add(if (avatarFront) "Posisi: di depan chat  →  pindah ke belakang" else "Posisi: di belakang chat  →  majukan ke depan")
            acts.add { toggleFront() }
            if (avatarFront && karin != null) {
                items.add("Kembalikan posisi avatar ke tengah")
                acts.add {
                    karin?.setDrag(0f, 0f)
                    prefs().edit().remove("avatar_dx_${cfg.id}").remove("avatar_dy_${cfg.id}").apply()
                }
            }
        }
        if (cfg.expressions.isNotEmpty() && karin != null) {
            items.add("Ekspresi…")
            acts.add { showExprDialog() }
            val on = prefs().getBoolean("expr_toast", true)
            items.add(if (on) "Notifikasi ekspresi: nyala  →  matikan" else "Notifikasi ekspresi: mati  →  nyalakan")
            acts.add { prefs().edit().putBoolean("expr_toast", !on).apply() }
        }
        items.add(if (karinWanted) "Sembunyikan avatar" else "Tampilkan avatar")
        acts.add { toggleKarin() }
        AlertDialog.Builder(this)
            .setTitle("Avatar")
            .setItems(items.toTypedArray()) { _, i -> acts[i]() }
            .show()
    }

    private fun showExprDialog() {
        val k = karin ?: return
        val keys = cfg.expressions.keys.toList()
        val checked = BooleanArray(keys.size) { k.anim.isExprHeld(keys[it]) }
        AlertDialog.Builder(this)
            .setTitle("Ekspresi (ditahan sampai dimatikan)")
            .setMultiChoiceItems(keys.map { Emotion.label(it) }.toTypedArray(), checked) { _, i, on ->
                k.anim.setExprHold(keys[i], on)
            }
            .setPositiveButton("Selesai", null)
            .show()
    }

    private fun applyKarin() {
        if (karinWanted && karin == null) createKarin()
        if (!karinWanted && karin != null) destroyKarin()

        val full = cfg.full
        val front = full && avatarFront
        val avatarOn = karinWanted && !keyboardUp

        // Keyboard muncul: avatar + tombol menyingkir, tinggal header.
        karinWrap.visibility = if (avatarOn && !full) View.VISIBLE else View.GONE
        bgHost.visibility = if (avatarOn && full && !front) View.VISIBLE else View.GONE
        frontHost.visibility = if (avatarOn && front) View.VISIBLE else View.GONE
        chipRow.visibility = if (keyboardUp) View.GONE else View.VISIBLE
        layoutBody()
    }

    /**
     * Mengatur tinggi panggung atas dan posisi atas daftar chat (tanpa weight / margin negatif):
     *  - mode panggung (bust + sobekan): panggung = separuh body, daftar chat naik setinggi sobekan menimpa dasarnya
     *  - mode full body: daftar chat mulai di garis cfg.chatTop dan memudar menghilang di garis itu
     *  - tanpa avatar / keyboard muncul: daftar chat langsung di bawah header dan tombol
     */
    private fun layoutBody() {
        val bh = body.height
        if (bh <= 0 || rootFrame.height <= 0) return
        val d = resources.displayMetrics.density
        val full = cfg.full
        val front = full && avatarFront
        val avatarOn = karinWanted && !keyboardUp
        val stageTall = avatarOn && !full
        val tearH = (TearProfile.HEIGHT_DP * d).toInt()

        val tsLp = topStage.layoutParams as FrameLayout.LayoutParams
        val caLp = chatArea.layoutParams as FrameLayout.LayoutParams
        val wantTsH: Int
        val wantCaTop: Int
        when {
            stageTall -> {
                wantTsH = bh / 2
                wantCaTop = bh / 2 - tearH
            }
            full && avatarOn -> {
                wantTsH = ViewGroup.LayoutParams.WRAP_CONTENT
                val lineY = (rootFrame.height * cfg.chatTop).toInt()
                wantCaTop = (lineY - body.top).coerceAtLeast(topStage.height + (4 * d).toInt())
            }
            else -> {
                wantTsH = ViewGroup.LayoutParams.WRAP_CONTENT
                wantCaTop = topStage.height + (4 * d).toInt()
            }
        }
        var changed = false
        if (tsLp.height != wantTsH) {
            tsLp.height = wantTsH
            topStage.layoutParams = tsLp
            changed = true
        }
        if (caLp.topMargin != wantCaTop) {
            caLp.topMargin = wantCaTop
            chatArea.layoutParams = caLp
            changed = true
        }

        tearEdge.visibility = if (stageTall) View.VISIBLE else View.GONE
        val tl = list as TornRecyclerView
        tl.setTearEnabled(stageTall)
        tl.setFadeTop(if (full && avatarOn) cfg.fadeDp * d else 0f)
        val padTop = if (stageTall) tearH else 0
        if (list.paddingTop != padTop) {
            list.setPadding(list.paddingLeft, padTop, list.paddingRight, list.paddingBottom)
        }

        // Di depan chat: kolom input (dan Mic) tetap di atas avatar. Permukaan avatar berhenti di atas kolom input,
        // tapi avatar digambar seukuran layar penuh (sama besar dengan di belakang chat).
        if (front && avatarOn && inputBar.top > 0) {
            val extra = (rootFrame.height - inputBar.top + (6 * d).toInt()).coerceAtLeast(0)
            val flp = frontHost.layoutParams as FrameLayout.LayoutParams
            if (flp.bottomMargin != extra) {
                flp.bottomMargin = extra
                frontHost.layoutParams = flp
            }
            karin?.setBottomExtra(extra)
        }
        if (changed) body.requestLayout()
    }

    private fun hitScreen(v: View, rx: Float, ry: Float): Boolean {
        if (!v.isShown) return false
        val l = IntArray(2)
        v.getLocationOnScreen(l)
        return rx >= l[0] && rx <= l[0] + v.width && ry >= l[1] && ry <= l[1] + v.height
    }

    /** Reaksi sentuh avatar tidak boleh ikut terpicu saat jari mengetuk tombol, kolom input, atau bubble chat (mode belakang). */
    private fun pokeAllowed(rx: Float, ry: Float): Boolean {
        if (avatarFront) return true
        if (hitScreen(inputBar, rx, ry) || hitScreen(chipRow, rx, ry) || hitScreen(findViewById(R.id.chatHeader), rx, ry)) return false
        if (hitScreen(list, rx, ry)) {
            val l = IntArray(2)
            list.getLocationOnScreen(l)
            return list.findChildViewUnder(rx - l[0], ry - l[1]) == null
        }
        return true
    }

    override fun onResume() {
        super.onResume()
        uiActive = true
        karin?.onResume()
        handler.removeCallbacks(karinTick)
        handler.post(karinTick)
    }

    override fun onPause() {
        uiActive = false
        handler.removeCallbacks(karinTick)
        karin?.onPause()
        super.onPause()
    }

    private var slotSend = false

    /** Satu slot di kanan: kolom kosong = Mic, ada teks (atau sedang menjawab) = Kirim/Berhenti. */
    private fun updateSlot() {
        val wantSend = sending || input.text.isNotBlank()
        if (wantSend == slotSend) return
        slotSend = wantSend
        val show = if (wantSend) btnSend else btnMic
        val hide = if (wantSend) btnMic else btnSend
        hide.animate().cancel()
        show.animate().cancel()
        hide.animate().alpha(0f).scaleX(0.6f).scaleY(0.6f)
            .rotation(if (wantSend) -60f else 60f).setDuration(160)
            .withEndAction { if (slotSend == wantSend) hide.visibility = View.GONE }.start()
        show.visibility = View.VISIBLE
        show.alpha = 0f
        show.scaleX = 0.6f
        show.scaleY = 0.6f
        show.rotation = if (wantSend) 60f else -60f
        show.animate().alpha(1f).scaleX(1f).scaleY(1f).rotation(0f).setDuration(240)
            .setInterpolator(OvershootInterpolator(1.4f)).start()
    }

    override fun finish() {
        super.finish()
        overridePendingTransition(R.anim.fade_in_soft, R.anim.slide_out_right)
    }

    private fun updateVoiceButton() {
        btnVoice.text = if (Voice.autoSpeak(this)) "Suara: nyala" else "Suara: mati"
    }

    /** Ketuk balon AI: bacakan (ketuk lagi saat sedang bicara untuk berhenti). */
    private fun speakMsg(m: Msg) {
        if (Voice.speaking) {
            Voice.stop()
            return
        }
        if (Voice.findVoice(this) == null) {
            Toast.makeText(this, "Model suara belum ada.", Toast.LENGTH_LONG).show()
            return
        }
        Toast.makeText(this, "Membaca...", Toast.LENGTH_SHORT).show()
        Voice.speak(this, m.text) { err ->
            if (err != null) runOnUiThread {
                Toast.makeText(this, "Suara gagal: $err", Toast.LENGTH_LONG).show()
            }
        }
    }

    // ------------------------------------------------------------ suara -> teks

    private fun updateMicLabel() {
        btnMic.text = micStatus ?: when {
            listening -> "Dengar..."
            live -> "Live"
            else -> "Mic"
        }
    }

    /** Ketuk Mic: sekali bicara. Ketuk saat mode live: keluar dari live. */
    private fun onMic() {
        if (live) {
            setLive(false)
            return
        }
        if (listening) {
            // Whisper: ketuk saat merekam = anggap sudah selesai ngomong, langsung dikenali.
            if (!Ear.finishNow()) stopListening()
            return
        }
        if (sending) {
            Toast.makeText(this, "Tunggu jawaban selesai dulu.", Toast.LENGTH_SHORT).show()
            return
        }
        beginListening()
    }

    /** Tahan Mic: mode live ngobrol (dengar -> jawab bersuara -> dengar lagi, terus sampai dimatikan). */
    private fun onMicLong(): Boolean {
        if (live) {
            setLive(false)
        } else {
            if (Voice.findVoice(this) == null) {
                Toast.makeText(this, "Mode live butuh model suara. Salin dulu model Supertonic.", Toast.LENGTH_LONG).show()
                return true
            }
            if (sending) {
                Toast.makeText(this, "Tunggu jawaban selesai dulu.", Toast.LENGTH_SHORT).show()
                return true
            }
            setLive(true)
            Voice.preload(this)
            Toast.makeText(this, "Mode live nyala. Ngobrol aja, ketuk Mic buat berhenti.", Toast.LENGTH_LONG).show()
            beginListening()
        }
        return true
    }

    private fun setLive(on: Boolean) {
        live = on
        if (on) {
            window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        } else {
            window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
            turn++
            stopListening()
            Voice.stop()
        }
        updateMicLabel()
    }

    private fun beginListening() {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            micPerm.launch(Manifest.permission.RECORD_AUDIO)
            return
        }
        startListening()
    }

    /** Dalam mode live: mulai dengar lagi setelah jeda singkat (biar ekor suara AI tidak ikut terekam). */
    private fun relisten(delayMs: Long) {
        val t = turn
        handler.postDelayed({
            if (live && t == turn && !sending && !listening && !isFinishing) beginListening()
        }, delayMs)
    }

    /** Mic offline Whisper (kalau model Whisper sudah dipasang). */
    private fun startListeningWhisper() {
        Voice.stop()
        listening = true
        micStatus = null
        updateMicLabel()
        input.setText("")
        Ear.listen(
            this,
            silenceMs = if (live) 1500 else 1300,
            onState = { s ->
                micStatus = when (s) {
                    "load" -> "Memuat..."
                    "think" -> "Proses..."
                    else -> null
                }
                updateMicLabel()
            }
        ) { text, err ->
            micStatus = null
            listening = false
            updateMicLabel()
            when {
                !text.isNullOrBlank() && !sending -> send(text.trim())
                err == Ear.NOSPEECH -> {
                    if (live) relisten(200)
                    else Toast.makeText(this, "Suaranya nggak kedengeran, coba lagi.", Toast.LENGTH_SHORT).show()
                }
                err != null -> {
                    whisperFailed = true
                    if (live) setLive(false)
                    Toast.makeText(
                        this, "Mic Whisper gagal ($err). Sementara pakai mic bawaan, ketuk Mic lagi.",
                        Toast.LENGTH_LONG
                    ).show()
                }
                live -> relisten(300)
            }
        }
    }

    private fun startListening() {
        if (!whisperFailed && Ear.available(this)) {
            if (!micInfoShown) {
                micInfoShown = true
                Toast.makeText(this, "Mic: Whisper (${Ear.findModel(this)?.name})", Toast.LENGTH_SHORT).show()
            }
            startListeningWhisper()
            return
        }
        if (!micInfoShown) {
            micInfoShown = true
            Toast.makeText(
                this,
                if (whisperFailed) "Mic: bawaan HP (Whisper error)" else "Mic: bawaan HP (folder Whisper tidak kebaca)",
                Toast.LENGTH_LONG
            ).show()
        }
        Voice.stop()
        val r = try {
            // Full offline: pengenal on-device dulu. Yang biasa cuma cadangan dan dipaksa offline.
            if (Build.VERSION.SDK_INT >= 33 && SpeechRecognizer.isOnDeviceRecognitionAvailable(this)) {
                SpeechRecognizer.createOnDeviceSpeechRecognizer(this)
            } else if (SpeechRecognizer.isRecognitionAvailable(this)) {
                SpeechRecognizer.createSpeechRecognizer(this)
            } else {
                null
            }
        } catch (_: Throwable) {
            null
        }
        if (r == null) {
            Toast.makeText(this, "Pengenal suara tidak tersedia di HP ini.", Toast.LENGTH_LONG).show()
            if (live) setLive(false)
            return
        }
        recognizer = r
        r.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) {}
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onEvent(eventType: Int, params: Bundle?) {}

            override fun onPartialResults(partialResults: Bundle?) {
                val t = partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
                if (!t.isNullOrBlank()) input.setText(t)
            }

            override fun onResults(results: Bundle?) {
                val t = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
                stopListening()
                if (!t.isNullOrBlank() && !sending) {
                    input.setText("")
                    send(t.trim())
                } else if (live) {
                    relisten(300)
                }
            }

            override fun onError(error: Int) {
                stopListening()
                if (live) {
                    when (error) {
                        // Diam / tidak ada ucapan / pengenal sibuk: dengar lagi diam-diam.
                        SpeechRecognizer.ERROR_NO_MATCH, SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> relisten(200)
                        SpeechRecognizer.ERROR_RECOGNIZER_BUSY -> relisten(800)
                        else -> {
                            setLive(false)
                            Toast.makeText(
                                this@ChatActivity,
                                "Mode live berhenti (kode $error). Cek izin mikrofon / paket suara.",
                                Toast.LENGTH_LONG
                            ).show()
                        }
                    }
                    return
                }
                val msg = when (error) {
                    6, 7 -> "Suaranya nggak kedengeran, coba lagi."
                    9 -> "Izin mikrofon belum ada."
                    12, 13 -> "Paket bahasa Indonesia untuk suara offline belum terpasang di HP."
                    2, 1, 4 -> "Pengenal suara butuh internet atau paket suara offline."
                    else -> "Gagal mendengar (kode $error)."
                }
                Toast.makeText(this@ChatActivity, msg, Toast.LENGTH_LONG).show()
            }
        })
        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE, "id-ID")
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "id-ID")
            .putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, packageName)
            .putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            .putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, true)
            .putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
            // Jeda lebih lega: bisik / ngomong pelan-pelan tidak langsung dianggap selesai.
            .putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS, 1800L)
            .putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_POSSIBLY_COMPLETE_SILENCE_LENGTH_MILLIS, 1500L)
            .putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_MINIMUM_LENGTH_MILLIS, 400L)
        listening = true
        updateMicLabel()
        input.setText("")
        try {
            r.startListening(i)
        } catch (t: Throwable) {
            stopListening()
            if (live) setLive(false)
            Toast.makeText(this, "Gagal mulai mendengar: ${t.message}", Toast.LENGTH_LONG).show()
        }
    }

    private fun stopListening() {
        Ear.cancel()
        micStatus = null
        listening = false
        updateMicLabel()
        try {
            recognizer?.cancel()
            recognizer?.destroy()
        } catch (_: Throwable) {
        }
        recognizer = null
    }

    private fun send(text: String) {
        Voice.stop()
        val model = Gemma.findModel(this)
        if (model == null) {
            Toast.makeText(this, "Model .litertlm belum ada.", Toast.LENGTH_LONG).show()
            if (live) setLive(false)
            return
        }
        val prefs = getSharedPreferences("mangatl", MODE_PRIVATE)
        val glossary = prefs.getString("glossary", "") ?: ""
        val nick = prefs.getString("nick", "") ?: ""
        val notes = prefs.getString("notes", "") ?: ""

        val hist = store.filter { it.text.isNotBlank() }.map { Pair(it.isUser, it.text) }
        store.add(Msg(true, text))
        val ai = Msg(false, "")
        store.add(ai)
        adapter.notifyItemRangeInserted(store.size - 2, 2)
        list.scrollToPosition(store.size - 1)

        sending = true
        btnSend.text = "Berhenti"; updateSlot()
        val myTurn = ++turn
        val wantVoice = (Voice.autoSpeak(this) || live) && Voice.findVoice(this) != null

        // Suara ikut streaming: model suara dimuat sekarang (selagi AI mikir), lalu tiap kalimat
        // dibacakan begitu teksnya muncul.
        val stream: Voice.Stream? =
            if (wantVoice) {
                Voice.startStream(this) { e ->
                    runOnUiThread {
                        if (e != null) Toast.makeText(this, "Suara gagal: $e", Toast.LENGTH_LONG).show()
                        // Mode live: suara selesai -> giliran pengguna ngomong lagi.
                        if (live && myTurn == turn && !sending) relisten(450)
                    }
                }
            } else {
                null
            }

        Gemma.chat(
            this, model, hist, text, glossary, nick, notes, live,
            onChunk = { chunk ->
                runOnUiThread {
                    ai.text += chunk
                    // Emoji di balasan AI memicu ekspresi avatar (pipi merah, marah, air mata, dll).
                    Emotion.scan(ai.text, ai.text.length - chunk.length - 24)?.let { key ->
                        karin?.anim?.triggerExpr(key, 4f)
                        // Notifikasi kecil nama ekspresi yang terdeteksi (untuk uji coba; bisa dimatikan di menu Avatar).
                        if (cfg.expressions.containsKey(key) && prefs().getBoolean("expr_toast", true)) {
                            val now = SystemClock.uptimeMillis()
                            if (key != lastExprKey || now - lastExprAt > 4000L) {
                                Toast.makeText(this, "Ekspresi: " + Emotion.label(key), Toast.LENGTH_SHORT).show()
                            }
                            lastExprKey = key
                            lastExprAt = now
                        }
                    }
                    stream?.feed(chunk)
                    val pos = store.indexOf(ai)
                    if (pos >= 0) {
                        adapter.notifyItemChanged(pos)
                        list.scrollToPosition(store.size - 1)
                    }
                }
            },
            onFinish = { err ->
                runOnUiThread {
                    sending = false
                    btnSend.text = "Kirim"; updateSlot()
                    if (err != null) {
                        ai.text = if (ai.text.isBlank()) "Gagal: $err" else ai.text + "\n\n(Gagal: $err)"
                    } else if (ai.text.isBlank()) {
                        ai.text = "(tidak ada jawaban)"
                    }
                    val pos = store.indexOf(ai)
                    if (pos >= 0) adapter.notifyItemChanged(pos)
                    if (err == null) stream?.finish() else stream?.cancel()
                    // Tanpa suara: langsung dengar lagi.
                    if (stream == null && live && myTurn == turn) relisten(300)
                }
            }
        )
    }

    override fun onDestroy() {
        live = false
        handler.removeCallbacksAndMessages(null)
        stopListening()
        Voice.release()
        Ear.release()
        if (sending) Gemma.chatCancel()
        super.onDestroy()
    }

    class MsgAdapter(
        private val items: List<Msg>,
        private val onTap: (Msg) -> Unit
    ) : RecyclerView.Adapter<MsgAdapter.VH>() {

        class VH(v: View) : RecyclerView.ViewHolder(v) {
            val bubble: TextView = v.findViewById(R.id.bubble)
        }

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
            val v = LayoutInflater.from(parent.context).inflate(R.layout.item_msg, parent, false)
            return VH(v)
        }

        override fun getItemCount(): Int = items.size

        override fun onBindViewHolder(holder: VH, position: Int) {
            val m = items[position]
            val b = holder.bubble
            val lp = b.layoutParams as FrameLayout.LayoutParams
            if (m.isUser) {
                lp.gravity = Gravity.END
                b.setBackgroundResource(R.drawable.bubble_user)
                b.setTextColor(0xFF000000.toInt())
                b.text = m.text
            } else {
                lp.gravity = Gravity.START
                b.setBackgroundResource(R.drawable.bubble_ai)
                b.setTextColor(0xFFEDEDED.toInt())
                b.text = if (m.text.isEmpty()) "..." else TextUtil.md(m.text)
            }
            b.layoutParams = lp
            b.setOnClickListener { if (!m.isUser && m.text.isNotBlank()) onTap(m) }
            b.setOnLongClickListener {
                val cm = b.context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                cm.setPrimaryClip(ClipData.newPlainText("chat", m.text))
                Toast.makeText(b.context, "Disalin", Toast.LENGTH_SHORT).show()
                true
            }
        }
    }
}
