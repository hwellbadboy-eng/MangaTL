package com.niven.mangatl

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Rect
import android.widget.LinearLayout
import android.os.Build
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import androidx.activity.result.contract.ActivityResultContracts
import android.view.Gravity
import android.view.LayoutInflater
import android.text.Editable
import android.text.TextWatcher
import android.view.View
import android.view.animation.OvershootInterpolator
import android.view.WindowManager
import android.os.Handler
import android.os.Looper
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import android.widget.Button
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

class ChatActivity : AppCompatActivity() {

    class Msg(val isUser: Boolean, var text: String)

    companion object {
        // Riwayat tetap ada selama app hidup, walau layar chat ditutup lalu dibuka lagi.
        private val store = ArrayList<Msg>()
    }

    private lateinit var list: RecyclerView
    private lateinit var input: EditText
    private lateinit var btnSend: Button
    private lateinit var adapter: MsgAdapter
    private var sending = false
    private lateinit var btnMic: Button
    private lateinit var btnVoice: Button
    private var recognizer: SpeechRecognizer? = null
    private var listening = false
    private var micStatus: String? = null
    private var micInfoShown = false
    private var whisperFailed = false // kalau Whisper error, sisa sesi pakai mic bawaan
    private var live = false
    private var turn = 0
    private val handler = Handler(Looper.getMainLooper())

    // Karin (tubuh AI): gerak mengikuti keadaan chat.
    private lateinit var karin: KarinView
    private lateinit var karinWrap: View
    private lateinit var topStage: View
    private lateinit var chatArea: View
    private lateinit var tearEdge: View
    private lateinit var chipRow: View
    private var karinWanted = true
    private var keyboardUp = false
    private var karinErrorShown = false
    private val karinTick = object : Runnable {
        override fun run() {
            if (karinWrap.visibility == View.VISIBLE) {
                karin.anim.state = when {
                    Voice.playing -> KarinState.SPEAKING
                    sending || Voice.speaking -> KarinState.THINKING
                    listening -> KarinState.LISTENING
                    else -> KarinState.IDLE
                }
            }
            handler.postDelayed(this, 120)
        }
    }

    private val micPerm = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { ok ->
        if (ok) startListening()
        else {
            if (live) setLive(false)
            Toast.makeText(this, "Izin mikrofon ditolak.", Toast.LENGTH_SHORT).show()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_chat)
        Fx.enter(this)

        list = findViewById(R.id.list)
        setupKarin()
        input = findViewById(R.id.input)
        btnSend = findViewById(R.id.btnSend)
        btnMic = findViewById(R.id.btnMic)
        btnMic.setOnClickListener { onMic() }
        btnMic.setOnLongClickListener { onMicLong() }
        btnVoice = findViewById(R.id.btnVoice)
        updateVoiceButton()
        input.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}
            override fun onTextChanged(s: CharSequence?, st: Int, b: Int, c: Int) {}
            override fun afterTextChanged(s: Editable?) {
                updateSlot()
            }
        })
        if (Voice.autoSpeak(this)) Voice.preload(this)
        if (Ear.available(this)) Ear.preload(this)
        btnVoice.setOnClickListener {
            val on = !Voice.autoSpeak(this)
            if (on && Voice.findVoice(this) == null) {
                Toast.makeText(
                    this,
                    "Model suara belum ada. Salin folder model Supertonic ke:\n${getExternalFilesDir(null)}",
                    Toast.LENGTH_LONG
                ).show()
                return@setOnClickListener
            }
            Voice.setAutoSpeak(this, on)
            if (!on) Voice.stop()
            updateVoiceButton()
        }

        adapter = MsgAdapter(store) { m -> speakMsg(m) }
        list.layoutManager = LinearLayoutManager(this).apply { stackFromEnd = true }
        list.adapter = adapter
        if (store.isNotEmpty()) list.scrollToPosition(store.size - 1)

        btnSend.setOnClickListener {
            if (sending) {
                if (live) setLive(false)
                Voice.stop()
                Gemma.chatCancel()
            } else {
                val t = input.text.toString().trim()
                if (t.isNotEmpty()) {
                    send(t)
                    input.setText("")
                }
            }
        }

        input.setOnEditorActionListener { _, actionId, _ ->
            if (actionId == EditorInfo.IME_ACTION_SEND) {
                btnSend.performClick()
                true
            } else {
                false
            }
        }

        findViewById<Button>(R.id.btnExplain).setOnClickListener {
            if (sending) return@setOnClickListener
            if (Gemma.lastPage.isEmpty()) {
                Toast.makeText(this, "Terjemahkan satu halaman dulu.", Toast.LENGTH_SHORT).show()
            } else {
                send(
                    "Jelaskan halaman manga yang terakhir tadi: emosi dan nada tiap karakter, " +
                        "idiom/slang/makna tersembunyi yang tidak boleh diterjemahkan harfiah, " +
                        "dan kasih alternatif terjemahan yang lebih natural untuk baris yang menurutmu kurang pas."
                )
            }
        }

        findViewById<Button>(R.id.btnPrompt).setOnClickListener { PromptSlots.show(this) }

        findViewById<Button>(R.id.btnClear).setOnClickListener {
            if (sending) return@setOnClickListener
            store.clear()
            adapter.notifyDataSetChanged()
        }
    }

    private fun setupKarin() {
        karin = findViewById(R.id.karin)
        karinWrap = findViewById(R.id.karinWrap)
        topStage = findViewById(R.id.topStage)
        chatArea = findViewById(R.id.chatArea)
        tearEdge = findViewById(R.id.tearEdge)
        // Satu profil zig-zag dipakai bersama: potongan chat, tepi badan Karin (GL), dan gambar sobekan.
        val tearPx = TearProfile.HEIGHT_DP * resources.displayMetrics.density
        val prof = TearProfile.get(this)
        (list as TornRecyclerView).setTear(prof, tearPx)
        karin.setTear(prof, tearPx)
        chipRow = findViewById(R.id.chipRow)
        karinWanted = getSharedPreferences("mangatl", MODE_PRIVATE).getBoolean("karin_on", true)
        // Decode tekstur Karin di thread latar sekarang juga, supaya siap saat layar GL dibuat.
        if (karinWanted) KarinTex.prefetch(this)
        karin.anim.levelSource = { Voice.mouthLevel() }
        karin.onError = { msg ->
            if (!karinErrorShown) {
                karinErrorShown = true
                Toast.makeText(this, "Karin gagal dimuat: $msg", Toast.LENGTH_LONG).show()
            }
        }
        // Ketuk judul "Chat AI" = tampil / sembunyikan Karin (sembunyi = memori GPU dilepas).
        findViewById<View>(R.id.tvTitle).setOnClickListener {
            karinWanted = !karinWanted
            getSharedPreferences("mangatl", MODE_PRIVATE).edit().putBoolean("karin_on", karinWanted).apply()
            applyKarin()
            Toast.makeText(this, if (karinWanted) "Karin tampil" else "Karin disembunyikan", Toast.LENGTH_SHORT).show()
        }
        // Keyboard muncul = Karin menyingkir sementara supaya daftar chat tetap lega.
        val decor = window.decorView
        decor.viewTreeObserver.addOnGlobalLayoutListener {
            val r = Rect()
            decor.getWindowVisibleDisplayFrame(r)
            val full = decor.rootView.height
            val up = full > 0 && (full - r.bottom) > full * 0.15f
            if (up != keyboardUp) {
                keyboardUp = up
                applyKarin()
            }
        }
        applyKarin()
    }

    private fun applyKarin() {
        val showStage = karinWanted && !keyboardUp

        // Karin dimatikan: lepas model + tekstur dari memori GPU. Dinyalakan lagi: muat ulang.
        if (!karinWanted) {
            if (karinWrap.tag != "off") {
                karinWrap.tag = "off"
                karin.releaseModel { }
            }
        } else if (karinWrap.tag == "off") {
            karinWrap.tag = null
            KarinTex.prefetch(this)
            karin.ensureModel()
        }

        // Keyboard muncul: Karin + tombol menyingkir, tinggal header. Karin mati: panggung mengecil seukuran tombol.
        karinWrap.visibility = if (showStage) View.VISIBLE else View.GONE
        chipRow.visibility = if (keyboardUp) View.GONE else View.VISIBLE
        val lp = topStage.layoutParams as LinearLayout.LayoutParams
        val wantH = if (showStage) 0 else ViewGroup.LayoutParams.WRAP_CONTENT
        val wantW = if (showStage) 1f else 0f
        if (lp.height != wantH || lp.weight != wantW) {
            lp.height = wantH
            lp.weight = wantW
            topStage.layoutParams = lp
        }

        // Mode sobekan hanya saat Karin tampil: daftar chat naik menimpa dasar panggung dan dipotong zig-zag.
        // Tanpa Karin: daftar chat biasa (tanpa potongan, tanpa gambar sobekan).
        val d = resources.displayMetrics.density
        val tearH = (TearProfile.HEIGHT_DP * d).toInt()
        tearEdge.visibility = if (showStage) View.VISIBLE else View.GONE
        (list as TornRecyclerView).setTearEnabled(showStage)
        val clp = chatArea.layoutParams as LinearLayout.LayoutParams
        val wantTop = if (showStage) -tearH else (4 * d).toInt()
        if (clp.topMargin != wantTop) {
            clp.topMargin = wantTop
            chatArea.layoutParams = clp
        }
        val padTop = if (showStage) tearH else 0
        if (list.paddingTop != padTop) {
            list.setPadding(list.paddingLeft, padTop, list.paddingRight, list.paddingBottom)
        }
    }

    override fun onResume() {
        super.onResume()
        karin.onResume()
        handler.removeCallbacks(karinTick)
        handler.post(karinTick)
    }

    override fun onPause() {
        handler.removeCallbacks(karinTick)
        karin.onPause()
        super.onPause()
    }

    private var slotSend = false

    /** Satu slot di kanan: kolom kosong = Mic, ada teks (atau sedang menjawab) = Kirim/Berhenti. */
    private fun updateSlot() {
        val wantSend = sending || input.text.isNotBlank()
        if (wantSend == slotSend) return
        slotSend = wantSend
        val show = if (wantSend) btnSend else btnMic
        val hide = if (wantSend) btnMic else btnSend
        hide.animate().cancel()
        show.animate().cancel()
        hide.animate().alpha(0f).scaleX(0.6f).scaleY(0.6f)
            .rotation(if (wantSend) -60f else 60f).setDuration(160)
            .withEndAction { if (slotSend == wantSend) hide.visibility = View.GONE }.start()
        show.visibility = View.VISIBLE
        show.alpha = 0f
        show.scaleX = 0.6f
        show.scaleY = 0.6f
        show.rotation = if (wantSend) 60f else -60f
        show.animate().alpha(1f).scaleX(1f).scaleY(1f).rotation(0f).setDuration(240)
            .setInterpolator(OvershootInterpolator(1.4f)).start()
    }

    override fun finish() {
        super.finish()
        overridePendingTransition(R.anim.fade_in_soft, R.anim.slide_out_right)
    }

    private fun updateVoiceButton() {
        btnVoice.text = if (Voice.autoSpeak(this)) "Suara: nyala" else "Suara: mati"
    }

    /** Ketuk balon AI: bacakan (ketuk lagi saat sedang bicara untuk berhenti). */
    private fun speakMsg(m: Msg) {
        if (Voice.speaking) {
            Voice.stop()
            return
        }
        if (Voice.findVoice(this) == null) {
            Toast.makeText(this, "Model suara belum ada.", Toast.LENGTH_LONG).show()
            return
        }
        Toast.makeText(this, "Membaca...", Toast.LENGTH_SHORT).show()
        Voice.speak(this, m.text) { err ->
            if (err != null) runOnUiThread {
                Toast.makeText(this, "Suara gagal: $err", Toast.LENGTH_LONG).show()
            }
        }
    }

    // ------------------------------------------------------------ suara -> teks

    private fun updateMicLabel() {
        btnMic.text = micStatus ?: when {
            listening -> "Dengar..."
            live -> "Live"
            else -> "Mic"
        }
    }

    /** Ketuk Mic: sekali bicara. Ketuk saat mode live: keluar dari live. */
    private fun onMic() {
        if (live) {
            setLive(false)
            return
        }
        if (listening) {
            // Whisper: ketuk saat merekam = anggap sudah selesai ngomong, langsung dikenali.
            if (!Ear.finishNow()) stopListening()
            return
        }
        if (sending) {
            Toast.makeText(this, "Tunggu jawaban selesai dulu.", Toast.LENGTH_SHORT).show()
            return
        }
        beginListening()
    }

    /** Tahan Mic: mode live ngobrol (dengar -> jawab bersuara -> dengar lagi, terus sampai dimatikan). */
    private fun onMicLong(): Boolean {
        if (live) {
            setLive(false)
        } else {
            if (Voice.findVoice(this) == null) {
                Toast.makeText(this, "Mode live butuh model suara. Salin dulu model Supertonic.", Toast.LENGTH_LONG).show()
                return true
            }
            if (sending) {
                Toast.makeText(this, "Tunggu jawaban selesai dulu.", Toast.LENGTH_SHORT).show()
                return true
            }
            setLive(true)
            Voice.preload(this)
            Toast.makeText(this, "Mode live nyala. Ngobrol aja, ketuk Mic buat berhenti.", Toast.LENGTH_LONG).show()
            beginListening()
        }
        return true
    }

    private fun setLive(on: Boolean) {
        live = on
        if (on) {
            window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        } else {
            window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
            turn++
            stopListening()
            Voice.stop()
        }
        updateMicLabel()
    }

    private fun beginListening() {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            micPerm.launch(Manifest.permission.RECORD_AUDIO)
            return
        }
        startListening()
    }

    /** Dalam mode live: mulai dengar lagi setelah jeda singkat (biar ekor suara AI tidak ikut terekam). */
    private fun relisten(delayMs: Long) {
        val t = turn
        handler.postDelayed({
            if (live && t == turn && !sending && !listening && !isFinishing) beginListening()
        }, delayMs)
    }

    /** Mic offline Whisper (kalau model Whisper sudah dipasang). */
    private fun startListeningWhisper() {
        Voice.stop()
        listening = true
        micStatus = null
        updateMicLabel()
        input.setText("")
        Ear.listen(
            this,
            silenceMs = if (live) 1500 else 1300,
            onState = { s ->
                micStatus = when (s) {
                    "load" -> "Memuat..."
                    "think" -> "Proses..."
                    else -> null
                }
                updateMicLabel()
            }
        ) { text, err ->
            micStatus = null
            listening = false
            updateMicLabel()
            when {
                !text.isNullOrBlank() && !sending -> send(text.trim())
                err == Ear.NOSPEECH -> {
                    if (live) relisten(200)
                    else Toast.makeText(this, "Suaranya nggak kedengeran, coba lagi.", Toast.LENGTH_SHORT).show()
                }
                err != null -> {
                    whisperFailed = true
                    if (live) setLive(false)
                    Toast.makeText(
                        this, "Mic Whisper gagal ($err). Sementara pakai mic bawaan, ketuk Mic lagi.",
                        Toast.LENGTH_LONG
                    ).show()
                }
                live -> relisten(300)
            }
        }
    }

    private fun startListening() {
        if (!whisperFailed && Ear.available(this)) {
            if (!micInfoShown) {
                micInfoShown = true
                Toast.makeText(this, "Mic: Whisper (${Ear.findModel(this)?.name})", Toast.LENGTH_SHORT).show()
            }
            startListeningWhisper()
            return
        }
        if (!micInfoShown) {
            micInfoShown = true
            Toast.makeText(
                this,
                if (whisperFailed) "Mic: bawaan HP (Whisper error)" else "Mic: bawaan HP (folder Whisper tidak kebaca)",
                Toast.LENGTH_LONG
            ).show()
        }
        Voice.stop()
        val r = try {
            // Full offline: pengenal on-device dulu. Yang biasa cuma cadangan dan dipaksa offline.
            if (Build.VERSION.SDK_INT >= 33 && SpeechRecognizer.isOnDeviceRecognitionAvailable(this)) {
                SpeechRecognizer.createOnDeviceSpeechRecognizer(this)
            } else if (SpeechRecognizer.isRecognitionAvailable(this)) {
                SpeechRecognizer.createSpeechRecognizer(this)
            } else {
                null
            }
        } catch (_: Throwable) {
            null
        }
        if (r == null) {
            Toast.makeText(this, "Pengenal suara tidak tersedia di HP ini.", Toast.LENGTH_LONG).show()
            if (live) setLive(false)
            return
        }
        recognizer = r
        r.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) {}
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onEvent(eventType: Int, params: Bundle?) {}

            override fun onPartialResults(partialResults: Bundle?) {
                val t = partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
                if (!t.isNullOrBlank()) input.setText(t)
            }

            override fun onResults(results: Bundle?) {
                val t = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
                stopListening()
                if (!t.isNullOrBlank() && !sending) {
                    input.setText("")
                    send(t.trim())
                } else if (live) {
                    relisten(300)
                }
            }

            override fun onError(error: Int) {
                stopListening()
                if (live) {
                    when (error) {
                        // Diam / tidak ada ucapan / pengenal sibuk: dengar lagi diam-diam.
                        SpeechRecognizer.ERROR_NO_MATCH, SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> relisten(200)
                        SpeechRecognizer.ERROR_RECOGNIZER_BUSY -> relisten(800)
                        else -> {
                            setLive(false)
                            Toast.makeText(
                                this@ChatActivity,
                                "Mode live berhenti (kode $error). Cek izin mikrofon / paket suara.",
                                Toast.LENGTH_LONG
                            ).show()
                        }
                    }
                    return
                }
                val msg = when (error) {
                    6, 7 -> "Suaranya nggak kedengeran, coba lagi."
                    9 -> "Izin mikrofon belum ada."
                    12, 13 -> "Paket bahasa Indonesia untuk suara offline belum terpasang di HP."
                    2, 1, 4 -> "Pengenal suara butuh internet atau paket suara offline."
                    else -> "Gagal mendengar (kode $error)."
                }
                Toast.makeText(this@ChatActivity, msg, Toast.LENGTH_LONG).show()
            }
        })
        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE, "id-ID")
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "id-ID")
            .putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, packageName)
            .putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            .putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, true)
            .putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
            // Jeda lebih lega: bisik / ngomong pelan-pelan tidak langsung dianggap selesai.
            .putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS, 1800L)
            .putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_POSSIBLY_COMPLETE_SILENCE_LENGTH_MILLIS, 1500L)
            .putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_MINIMUM_LENGTH_MILLIS, 400L)
        listening = true
        updateMicLabel()
        input.setText("")
        try {
            r.startListening(i)
        } catch (t: Throwable) {
            stopListening()
            if (live) setLive(false)
            Toast.makeText(this, "Gagal mulai mendengar: ${t.message}", Toast.LENGTH_LONG).show()
        }
    }

    private fun stopListening() {
        Ear.cancel()
        micStatus = null
        listening = false
        updateMicLabel()
        try {
            recognizer?.cancel()
            recognizer?.destroy()
        } catch (_: Throwable) {
        }
        recognizer = null
    }

    private fun send(text: String) {
        Voice.stop()
        val model = Gemma.findModel(this)
        if (model == null) {
            Toast.makeText(this, "Model .litertlm belum ada.", Toast.LENGTH_LONG).show()
            if (live) setLive(false)
            return
        }
        val prefs = getSharedPreferences("mangatl", MODE_PRIVATE)
        val glossary = prefs.getString("glossary", "") ?: ""
        val nick = prefs.getString("nick", "") ?: ""
        val notes = prefs.getString("notes", "") ?: ""

        val hist = store.filter { it.text.isNotBlank() }.map { Pair(it.isUser, it.text) }
        store.add(Msg(true, text))
        val ai = Msg(false, "")
        store.add(ai)
        adapter.notifyItemRangeInserted(store.size - 2, 2)
        list.scrollToPosition(store.size - 1)

        sending = true
        btnSend.text = "Berhenti"; updateSlot()
        val myTurn = ++turn
        val wantVoice = (Voice.autoSpeak(this) || live) && Voice.findVoice(this) != null

        // Suara ikut streaming: model suara dimuat sekarang (selagi AI mikir), lalu tiap kalimat
        // dibacakan begitu teksnya muncul.
        val stream: Voice.Stream? =
            if (wantVoice) {
                Voice.startStream(this) { e ->
                    runOnUiThread {
                        if (e != null) Toast.makeText(this, "Suara gagal: $e", Toast.LENGTH_LONG).show()
                        // Mode live: suara selesai -> giliran pengguna ngomong lagi.
                        if (live && myTurn == turn && !sending) relisten(450)
                    }
                }
            } else {
                null
            }

        Gemma.chat(
            this, model, hist, text, glossary, nick, notes, live,
            onChunk = { chunk ->
                runOnUiThread {
                    ai.text += chunk
                    stream?.feed(chunk)
                    val pos = store.indexOf(ai)
                    if (pos >= 0) {
                        adapter.notifyItemChanged(pos)
                        list.scrollToPosition(store.size - 1)
                    }
                }
            },
            onFinish = { err ->
                runOnUiThread {
                    sending = false
                    btnSend.text = "Kirim"; updateSlot()
                    if (err != null) {
                        ai.text = if (ai.text.isBlank()) "Gagal: $err" else ai.text + "\n\n(Gagal: $err)"
                    } else if (ai.text.isBlank()) {
                        ai.text = "(tidak ada jawaban)"
                    }
                    val pos = store.indexOf(ai)
                    if (pos >= 0) adapter.notifyItemChanged(pos)
                    if (err == null) stream?.finish() else stream?.cancel()
                    // Tanpa suara: langsung dengar lagi.
                    if (stream == null && live && myTurn == turn) relisten(300)
                }
            }
        )
    }

    override fun onDestroy() {
        live = false
        handler.removeCallbacksAndMessages(null)
        stopListening()
        Voice.release()
        Ear.release()
        if (sending) Gemma.chatCancel()
        super.onDestroy()
    }

    class MsgAdapter(
        private val items: List<Msg>,
        private val onTap: (Msg) -> Unit
    ) : RecyclerView.Adapter<MsgAdapter.VH>() {

        class VH(v: View) : RecyclerView.ViewHolder(v) {
            val bubble: TextView = v.findViewById(R.id.bubble)
        }

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
            val v = LayoutInflater.from(parent.context).inflate(R.layout.item_msg, parent, false)
            return VH(v)
        }

        override fun getItemCount(): Int = items.size

        override fun onBindViewHolder(holder: VH, position: Int) {
            val m = items[position]
            val b = holder.bubble
            val lp = b.layoutParams as FrameLayout.LayoutParams
            if (m.isUser) {
                lp.gravity = Gravity.END
                b.setBackgroundResource(R.drawable.bubble_user)
                b.setTextColor(0xFF000000.toInt())
                b.text = m.text
            } else {
                lp.gravity = Gravity.START
                b.setBackgroundResource(R.drawable.bubble_ai)
                b.setTextColor(0xFFEDEDED.toInt())
                b.text = if (m.text.isEmpty()) "..." else TextUtil.md(m.text)
            }
            b.layoutParams = lp
            b.setOnClickListener { if (!m.isUser && m.text.isNotBlank()) onTap(m) }
            b.setOnLongClickListener {
                val cm = b.context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                cm.setPrimaryClip(ClipData.newPlainText("chat", m.text))
                Toast.makeText(b.context, "Disalin", Toast.LENGTH_SHORT).show()
                true
            }
        }
    }
}
