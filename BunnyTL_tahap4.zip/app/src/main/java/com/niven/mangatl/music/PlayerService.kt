package com.niven.mangatl

import android.content.Intent
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import java.util.concurrent.Executors
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.session.MediaSession
import androidx.media3.session.MediaSessionService

/**
 * Pemutar musik di latar belakang (notifikasi + kontrol layar kunci) + sleep timer.
 */
class PlayerService : MediaSessionService() {

    companion object {
        @Volatile
        var instance: PlayerService? = null
    }

    private var session: MediaSession? = null
    private val h = Handler(Looper.getMainLooper())
    private var sleepRun: Runnable? = null

    /** Waktu (elapsedRealtime) timer habis; 0 = timer mati. */
    @Volatile
    var sleepEndAt = 0L
        private set

    fun setSleepTimer(minutes: Int) {
        sleepRun?.let { h.removeCallbacks(it) }
        sleepRun = null
        sleepEndAt = 0L
        if (minutes > 0) {
            val r = Runnable {
                session?.player?.pause()
                sleepEndAt = 0L
            }
            sleepRun = r
            sleepEndAt = SystemClock.elapsedRealtime() + minutes * 60_000L
            h.postDelayed(r, minutes * 60_000L)
        }
    }

    private var exo: ExoPlayer? = null
    private var chain: DspChain? = null
    private var builtBuf = -1
    private val bg = Executors.newSingleThreadExecutor()

    private val trackListener = object : Player.Listener {
        override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) {
            trackChanged()
        }
    }

    /** Beri tahu Audio Engine lagu mana yang sedang diputar (untuk normalisasi) dan analisis lagu berikutnya. */
    private fun trackChanged() {
        val p = exo ?: return
        val id = p.currentMediaItem?.mediaId?.toLongOrNull() ?: -1L
        AudioEngine.currentTrackId = id
        AudioEngine.currentAlbumId = -1L
        val nextIdx = p.nextMediaItemIndex
        val nextId = if (nextIdx >= 0 && nextIdx < p.mediaItemCount) p.getMediaItemAt(nextIdx).mediaId.toLongOrNull() else null
        val app = applicationContext
        bg.execute {
            try {
                if (id >= 0) AudioEngine.currentAlbumId = Library.track(app, id)?.albumId ?: -1L
                if (AudioEngine.isOn(AudioEngine.NORM)) {
                    if (id >= 0) LoudnessCache.request(app, id)
                    if (nextId != null) LoudnessCache.request(app, nextId)
                }
            } catch (e: Throwable) {
            }
        }
    }

    private fun buildPlayer(): ExoPlayer {
        val hiOn = AudioEngine.isOn(AudioEngine.HIRES)
        val buf = if (hiOn) AudioEngine.raw(AudioEngine.HIRES).getOrElse(10) { 0f }.toInt() else 0
        builtBuf = buf
        val p = ExoPlayer.Builder(this, DspRenderersFactory(applicationContext, Prefs.decoder(this), chain!!, buf))
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(C.USAGE_MEDIA)
                    .setContentType(C.AUDIO_CONTENT_TYPE_MUSIC)
                    .build(),
                true
            )
            .setHandleAudioBecomingNoisy(true)
            .build()
        p.addListener(trackListener)
        try {
            p.setPreferredAudioDevice(OutputCaps.targetDevice())
        } catch (e: Throwable) {
        }
        return p
    }

    /** Terapkan perubahan Hi-Res: perangkat, bit-perfect, buffer, dan susun ulang jalur audio. */
    private fun applyOutput() {
        val p = exo ?: return
        val hiOn = AudioEngine.isOn(AudioEngine.HIRES)
        val hv = AudioEngine.raw(AudioEngine.HIRES)
        OutputCaps.applyBitPerfect(hiOn && hv.size > 5 && hv[5].toInt() == 1)
        try {
            p.setPreferredAudioDevice(OutputCaps.targetDevice())
        } catch (e: Throwable) {
        }
        val buf = if (hiOn) hv.getOrElse(10) { 0f }.toInt() else 0
        if (buf != builtBuf) {
            rebuildPlayer()
            return
        }
        if (p.mediaItemCount > 0 && p.playbackState != Player.STATE_IDLE) {
            val idx = p.currentMediaItemIndex
            val pos = p.currentPosition
            val play = p.playWhenReady
            p.stop()
            p.seekTo(idx, pos)
            p.prepare()
            p.playWhenReady = play
        }
    }

    private fun rebuildPlayer() {
        val old = exo ?: return
        val items = ArrayList<MediaItem>()
        for (i in 0 until old.mediaItemCount) items.add(old.getMediaItemAt(i))
        val idx = old.currentMediaItemIndex
        val pos = old.currentPosition
        val play = old.playWhenReady
        val rep = old.repeatMode
        val shuf = old.shuffleModeEnabled
        val sp = old.playbackParameters.speed
        old.removeListener(trackListener)
        val np = buildPlayer()
        if (items.isNotEmpty()) {
            np.setMediaItems(items, idx, pos)
            np.repeatMode = rep
            np.shuffleModeEnabled = shuf
            np.setPlaybackSpeed(sp)
            np.prepare()
            np.playWhenReady = play
        }
        exo = np
        session?.player = np
        old.release()
        trackChanged()
    }

    override fun onCreate() {
        super.onCreate()
        instance = this
        AudioEngine.init(this)
        OutputCaps.init(this)
        chain = DspChain(applicationContext)
        val player = buildPlayer()
        exo = player
        session = MediaSession.Builder(this, player).build()
        AudioEngine.outputListener = { applyOutput() }
        val hv = AudioEngine.raw(AudioEngine.HIRES)
        if (AudioEngine.isOn(AudioEngine.HIRES) && hv.size > 5 && hv[5].toInt() == 1) OutputCaps.applyBitPerfect(true)
    }

    override fun onGetSession(controllerInfo: MediaSession.ControllerInfo): MediaSession? = session

    override fun onTaskRemoved(rootIntent: Intent?) {
        val p = session?.player
        if (p == null || !p.playWhenReady || p.mediaItemCount == 0) stopSelf()
    }

    override fun onDestroy() {
        sleepRun?.let { h.removeCallbacks(it) }
        instance = null
        AudioEngine.outputListener = null
        exo?.removeListener(trackListener)
        session?.run {
            player.release()
            release()
        }
        session = null
        exo = null
        bg.shutdown()
        super.onDestroy()
    }
}
