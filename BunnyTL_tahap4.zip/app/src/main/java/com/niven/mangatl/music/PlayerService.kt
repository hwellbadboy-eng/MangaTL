package com.niven.mangatl

import android.content.Intent
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import java.util.concurrent.Executors
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.session.MediaSession
import androidx.media3.session.MediaSessionService

/**
 * Pemutar musik di latar belakang (notifikasi + kontrol layar kunci) + sleep timer.
 */
class PlayerService : MediaSessionService() {

    companion object {
        @Volatile
        var instance: PlayerService? = null
    }

    private var session: MediaSession? = null
    private val h = Handler(Looper.getMainLooper())
    private var sleepRun: Runnable? = null

    /** Waktu (elapsedRealtime) timer habis; 0 = timer mati. */
    @Volatile
    var sleepEndAt = 0L
        private set

    fun setSleepTimer(minutes: Int) {
        sleepRun?.let { h.removeCallbacks(it) }
        sleepRun = null
        sleepEndAt = 0L
        if (minutes > 0) {
            val r = Runnable {
                session?.player?.pause()
                sleepEndAt = 0L
            }
            sleepRun = r
            sleepEndAt = SystemClock.elapsedRealtime() + minutes * 60_000L
            h.postDelayed(r, minutes * 60_000L)
        }
    }

    private var exo: ExoPlayer? = null
    private var chain: DspChain? = null
    private var builtBuf = -1
    private val bg = Executors.newSingleThreadExecutor()

    private var lastLoggedId = -1L
    private var tickN = 0

    private val trackListener = object : Player.Listener {
        override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) {
            lastLoggedId = -1L
            trackChanged()
            saveSoon()
        }

        override fun onIsPlayingChanged(isPlaying: Boolean) {
            h.removeCallbacks(tick)
            if (isPlaying) {
                h.postDelayed(tick, 5000)
            } else {
                saveSession()
            }
        }

        override fun onTimelineChanged(timeline: androidx.media3.common.Timeline, reason: Int) {
            saveSoon()
        }

        override fun onRepeatModeChanged(repeatMode: Int) {
            saveSoon()
        }

        override fun onShuffleModeEnabledChanged(shuffleModeEnabled: Boolean) {
            saveSoon()
        }
    }

    // Tiap 5 detik saat memutar: catat riwayat (setelah >= 4 detik) dan simpan sesi tiap 15 detik.
    private val tick = object : Runnable {
        override fun run() {
            val p = exo
            if (p != null && p.isPlaying) {
                val id = p.currentMediaItem?.mediaId?.toLongOrNull() ?: -1L
                if (id >= 0 && id != lastLoggedId && p.currentPosition >= 4000L) {
                    lastLoggedId = id
                    MusicStore.addHistory(applicationContext, id)
                }
                if (++tickN % 3 == 0) saveSession()
                h.postDelayed(this, 5000)
            }
        }
    }

    private val saveRun = Runnable { saveSession() }

    /** Simpan sesi sebentar lagi (digabung kalau banyak perubahan beruntun, misalnya saat antrean diisi). */
    private fun saveSoon() {
        h.removeCallbacks(saveRun)
        h.postDelayed(saveRun, 1500)
    }

    /** Simpan antrean + posisi + mode ulang/acak, supaya bisa dipulihkan walau aplikasi ditutup. */
    private fun saveSession() {
        val p = exo ?: return
        val n = p.mediaItemCount
        if (n == 0) return
        val ids = ArrayList<Long>(n)
        for (i in 0 until n) p.getMediaItemAt(i).mediaId.toLongOrNull()?.let { ids.add(it) }
        if (ids.size != n) return   // ada item bukan lagu (id bukan angka): jangan simpan setengah-setengah
        MusicStore.saveSession(
            applicationContext, ids, p.currentMediaItemIndex, p.currentPosition,
            p.repeatMode, p.shuffleModeEnabled
        )
    }

    /** Pulihkan antrean terakhir dalam keadaan JEDA (tidak langsung bunyi). Dibatalkan kalau pemutar sudah diisi. */
    private fun restoreSession() {
        if (!Prefs.resume(this)) return
        val ss = MusicStore.session(this) ?: return
        val app = applicationContext
        bg.execute {
            val items = ArrayList<MediaItem>(ss.ids.size)
            var idx = 0
            for ((k, id) in ss.ids.withIndex()) {
                val t = try {
                    Library.track(app, id)
                } catch (e: Throwable) {
                    null
                } ?: continue   // lagu sudah dihapus dari HP: lewati
                if (k == ss.index) idx = items.size
                items.add(mediaItemOf(t))
            }
            if (items.isEmpty()) return@execute
            h.post {
                val p = exo ?: return@post
                if (p.mediaItemCount != 0) return@post   // pengguna sudah memutar sesuatu
                val keepPos = if (ss.ids.getOrNull(ss.index)?.let { id -> items.getOrNull(idx)?.mediaId == id.toString() } == true) ss.pos else 0L
                p.repeatMode = ss.repeat
                p.shuffleModeEnabled = ss.shuffle
                p.setMediaItems(items, idx.coerceIn(0, items.size - 1), keepPos)
                p.prepare()
                p.playWhenReady = false
                lastLoggedId = items[idx.coerceIn(0, items.size - 1)].mediaId.toLongOrNull() ?: -1L
            }
        }
    }

    /** Beri tahu Audio Engine lagu mana yang sedang diputar (untuk normalisasi) dan analisis lagu berikutnya. */
    private fun trackChanged() {
        val p = exo ?: return
        val id = p.currentMediaItem?.mediaId?.toLongOrNull() ?: -1L
        AudioEngine.currentTrackId = id
        AudioEngine.currentAlbumId = -1L
        val nextIdx = p.nextMediaItemIndex
        val nextId = if (nextIdx >= 0 && nextIdx < p.mediaItemCount) p.getMediaItemAt(nextIdx).mediaId.toLongOrNull() else null
        val app = applicationContext
        bg.execute {
            try {
                if (id >= 0) AudioEngine.currentAlbumId = Library.track(app, id)?.albumId ?: -1L
                if (AudioEngine.isOn(AudioEngine.NORM)) {
                    if (id >= 0) LoudnessCache.request(app, id)
                    if (nextId != null) LoudnessCache.request(app, nextId)
                }
            } catch (e: Throwable) {
            }
        }
    }

    private fun buildPlayer(): ExoPlayer {
        val hiOn = AudioEngine.isOn(AudioEngine.HIRES)
        val buf = if (hiOn) AudioEngine.raw(AudioEngine.HIRES).getOrElse(10) { 0f }.toInt() else 0
        builtBuf = buf
        val p = ExoPlayer.Builder(this, DspRenderersFactory(applicationContext, Prefs.decoder(this), chain!!, buf))
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(C.USAGE_MEDIA)
                    .setContentType(C.AUDIO_CONTENT_TYPE_MUSIC)
                    .build(),
                true
            )
            .setHandleAudioBecomingNoisy(true)
            .build()
        p.addListener(trackListener)
        try {
            p.setPreferredAudioDevice(OutputCaps.targetDevice())
        } catch (e: Throwable) {
        }
        return p
    }

    /** Terapkan perubahan Hi-Res: perangkat, bit-perfect, buffer, dan susun ulang jalur audio. */
    private fun applyOutput() {
        val p = exo ?: return
        val hiOn = AudioEngine.isOn(AudioEngine.HIRES)
        val hv = AudioEngine.raw(AudioEngine.HIRES)
        OutputCaps.applyBitPerfect(hiOn && hv.size > 5 && hv[5].toInt() == 1)
        try {
            p.setPreferredAudioDevice(OutputCaps.targetDevice())
        } catch (e: Throwable) {
        }
        val buf = if (hiOn) hv.getOrElse(10) { 0f }.toInt() else 0
        if (buf != builtBuf) {
            rebuildPlayer()
            return
        }
        if (p.mediaItemCount > 0 && p.playbackState != Player.STATE_IDLE) {
            val idx = p.currentMediaItemIndex
            val pos = p.currentPosition
            val play = p.playWhenReady
            p.stop()
            p.seekTo(idx, pos)
            p.prepare()
            p.playWhenReady = play
        }
    }

    private fun rebuildPlayer() {
        val old = exo ?: return
        val items = ArrayList<MediaItem>()
        for (i in 0 until old.mediaItemCount) items.add(old.getMediaItemAt(i))
        val idx = old.currentMediaItemIndex
        val pos = old.currentPosition
        val play = old.playWhenReady
        val rep = old.repeatMode
        val shuf = old.shuffleModeEnabled
        val sp = old.playbackParameters.speed
        old.removeListener(trackListener)
        val np = buildPlayer()
        if (items.isNotEmpty()) {
            np.setMediaItems(items, idx, pos)
            np.repeatMode = rep
            np.shuffleModeEnabled = shuf
            np.setPlaybackSpeed(sp)
            np.prepare()
            np.playWhenReady = play
        }
        exo = np
        session?.player = np
        old.release()
        trackChanged()
    }

    override fun onCreate() {
        super.onCreate()
        instance = this
        AudioEngine.init(this)
        OutputCaps.init(this)
        chain = DspChain(applicationContext)
        val player = buildPlayer()
        exo = player
        session = MediaSession.Builder(this, player).build()
        AudioEngine.outputListener = { applyOutput() }
        val hv = AudioEngine.raw(AudioEngine.HIRES)
        if (AudioEngine.isOn(AudioEngine.HIRES) && hv.size > 5 && hv[5].toInt() == 1) OutputCaps.applyBitPerfect(true)
        restoreSession()
    }

    override fun onGetSession(controllerInfo: MediaSession.ControllerInfo): MediaSession? = session

    override fun onTaskRemoved(rootIntent: Intent?) {
        saveSession()
        val p = session?.player
        if (p == null || !p.playWhenReady || p.mediaItemCount == 0) stopSelf()
    }

    override fun onDestroy() {
        saveSession()   // sebelum player dilepas
        h.removeCallbacks(tick)
        h.removeCallbacks(saveRun)
        sleepRun?.let { h.removeCallbacks(it) }
        instance = null
        AudioEngine.outputListener = null
        exo?.removeListener(trackListener)
        session?.run {
            player.release()
            release()
        }
        session = null
        exo = null
        bg.shutdown()
        super.onDestroy()
    }
}

/** MediaItem untuk satu lagu (sama dengan yang dibuat layar Musik). */
internal fun mediaItemOf(t: Library.Track): MediaItem {
    val art = Uri.parse("content://media/external/audio/albumart/${t.albumId}")
    return MediaItem.Builder()
        .setMediaId(t.id.toString())
        .setUri(t.uri)
        .setMediaMetadata(
            MediaMetadata.Builder()
                .setTitle(t.title)
                .setArtist(t.artist)
                .setAlbumTitle(t.album)
                .setArtworkUri(art)
                .build()
        )
        .build()
}
