package com.niven.mangatl.download

import java.net.HttpURLConnection
import java.net.URL

/**
 * yt-dlp tidak punya ekstraktor untuk link bagikan Facebook (facebook.com/share/v/…, /share/r/…, fb.watch).
 * Link seperti itu jatuh ke ekstraktor Generic, yang cuma scrape HTML: hasilnya satu format tanpa resolusi,
 * tanpa uploader. Di sini link bagikan diubah dulu ke link kanonik (reel / watch?v= / videos/) supaya
 * ekstraktor Facebook yang menangani. Kalau gagal, kembalikan null dan pemanggil memakai link asli.
 */
object DlUrlResolver {
    private val UAS = listOf(
        "Mozilla/5.0 (Linux; Android 14; Pixel 8) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130.0.0.0 Mobile Safari/537.36",
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130.0.0.0 Safari/537.36"
    )

    /** Link Facebook yang SUDAH dikenali ekstraktor Facebook yt-dlp. */
    private val CANON = Regex(
        """https?://(?:[\w-]+\.)?facebook\.com/(?:reel/\d+|watch/?\?(?:[^#\s"'&]*&)*v=\d+|[^/?#\s"']+/videos/(?:[^/?#\s"']+/)?\d+|video\.php\?(?:[^#\s"'&]*&)*v=\d+)"""
    )
    private val ID_IN_PAGE = listOf(
        Regex(""""video_id"\s*:\s*"(\d{8,})""""),
        Regex(""""videoId"\s*:\s*"(\d{8,})""""),
        Regex("""facebook\.com/reel/(\d{8,})"""),
        Regex("""[?&]v=(\d{8,})""")
    )

    @Volatile var lastNote: String = ""
        private set

    fun needsResolve(url: String): Boolean {
        val u = runCatching { URL(url) }.getOrNull() ?: return false
        val host = u.host.lowercase()
        if (host == "fb.watch") return true
        return (host == "facebook.com" || host.endsWith(".facebook.com")) && u.path.startsWith("/share/")
    }

    /** Blokir (jaringan): panggil dari thread latar. */
    fun resolve(url: String): String? {
        lastNote = ""
        for (ua in UAS) {
            val r = runCatching { attempt(url, ua) }.getOrNull()
            if (r != null) return r
        }
        lastNote = "link share tidak bisa dialihkan"
        return null
    }

    private fun attempt(url: String, ua: String): String? {
        val c = URL(url).openConnection() as HttpURLConnection
        try {
            c.instanceFollowRedirects = true
            c.connectTimeout = 8000
            c.readTimeout = 8000
            c.setRequestProperty("User-Agent", ua)
            c.setRequestProperty("Accept", "text/html,application/xhtml+xml")
            c.setRequestProperty("Accept-Language", "en-US,en;q=0.9")
            c.connect()
            // 1) redirect HTTP langsung ke link kanonik
            val finalUrl = c.url.toString()
            CANON.find(finalUrl)?.let { lastNote = "link dialihkan (redirect)"; return it.value }
            if (c.responseCode !in 200..299) return null
            // 2) halaman bagikan berisi link/ID videonya
            val body = c.inputStream.use { input ->
                val buf = ByteArray(700_000)
                var n = 0
                while (n < buf.size) {
                    val k = input.read(buf, n, buf.size - n)
                    if (k < 0) break
                    n += k
                }
                String(buf, 0, n, Charsets.UTF_8)
            }.replace("\\/", "/")
            CANON.find(body)?.let { lastNote = "link dialihkan (halaman)"; return it.value }
            for (re in ID_IN_PAGE) {
                re.find(body)?.let { lastNote = "link dialihkan (id video)"; return "https://www.facebook.com/watch/?v=${it.groupValues[1]}" }
            }
            return null
        } finally {
            c.disconnect()
        }
    }
}
