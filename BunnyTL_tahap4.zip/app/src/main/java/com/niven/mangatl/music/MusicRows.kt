package com.niven.mangatl

import android.view.View
import android.widget.Toast

// Layar Musik: menyusun baris daftar (lagu, grup, playlist, favorit), masuk/keluar folder (Drill), dan aksi massal.
// Fungsi ekstensi dari MusicActivity; keadaan dan siklus hidup layar tetap di MusicActivity.kt.

/** kind: 0 biasa, 1 favorit, 2 playlist */
internal class Drill(val title: String, var tracks: List<Library.Track>, val kind: Int, val playlist: String?)

internal fun MusicActivity.refresh(keep: Boolean = false) {
    if (!loaded) return
    val q = etSearch.text.toString().trim().lowercase()
    val d = drill
    val out = ArrayList<Row>()
    if (d != null) {
        drillBar.visibility = View.VISIBLE
        tabScroll.visibility = View.GONE
        tvDrill.text = d.title
        out.addAll(trackRows(sortedTracks(d.tracks.filter { match(it, q) }), d))
    } else {
        drillBar.visibility = View.GONE
        tabScroll.visibility = View.VISIBLE
        when (curTab()) {
            0 -> out.addAll(trackRows(sortedTracks(tracks.filter { match(it, q) }), null))
            1 -> out.addAll(groupRows(albums, q, R.drawable.ic_album))
            2 -> out.addAll(groupRows(artists, q, R.drawable.ic_person))
            3 -> out.addAll(groupRows(folders, q, R.drawable.ic_folder))
            else -> out.addAll(playlistRows())
        }
    }
    updateBack()
    wheel.setRows(out, keep)
    tvEmpty.text = "Tidak ada hasil"
    tvEmpty.visibility = if (out.isEmpty()) View.VISIBLE else View.GONE
}

internal fun MusicActivity.trackRows(shown: List<Library.Track>, d: Drill?): List<Row> {
    shownIds = shown.map { it.id }
    return shown.mapIndexed { i, t ->
        Row(
            title = t.title,
            sub = t.artist,
            icon = R.drawable.ic_music_note,
            thumb = t.uri,
            selected = picked.contains(t.id),
            key = t.id,
            onLong = { if (selecting) toggleSelect(t.id) else trackMenu(t, d) },
            onClick = { if (selecting) toggleSelect(t.id) else playQueue(shown, i, false) }
        )
    }
}

internal fun MusicActivity.moveTracks(ids: List<Long>) {
    val uris = tracks.filter { it.id in ids }.map { it.uri }
    if (uris.isEmpty()) return
    moveMany(
        uris, "", tracks.map { it.rel }.filter { it.isNotEmpty() },
        listOf("Music/", "Alarms/", "Notifications/", "Podcasts/", "Ringtones/", "Audiobooks/", "Recordings/"),
        "Music/", "Pindahkan ${uris.size} lagu ke"
    ) {
        exitSelect()
        onMediaReady()
    }
}

internal fun MusicActivity.confirmDeleteTracks(ids: List<Long>) {
    val list = tracks.filter { it.id in ids }
    if (list.isEmpty()) return
    Sheet.confirm(
        this, "Hapus ${list.size} lagu permanen?",
        "Lagu akan dihapus dari HP dan tidak bisa dikembalikan.", "Hapus", true
    ) {
        deleteMedia(list.map { it.uri }) { ok ->
            if (ok) {
                Toast.makeText(this, "Lagu dihapus.", Toast.LENGTH_SHORT).show()
                exitSelect()
                onMediaReady()
            }
        }
    }
}

internal fun MusicActivity.favTracks(): List<Library.Track> {
    val f = MusicStore.favs(this)
    return tracks.filter { it.id in f }
}

internal fun MusicActivity.playlistRows(): List<Row> {
    val rows = ArrayList<Row>()
    val fav = favTracks()
    rows.add(
        Row(
            title = "Favorit", sub = "${fav.size} lagu", icon = R.drawable.ic_fav,
            thumbs = covers(fav), thumb = fav.firstOrNull()?.uri,
            onClick = {
                drill = Drill("Favorit", favTracks(), 1, null)
                refresh()
            }
        )
    )
    for (name in MusicStore.playlists(this).keys.toList()) {
        val l = playlistTracks(name)
        rows.add(
            Row(
                title = name, sub = "${l.size} lagu", icon = R.drawable.ic_playlist,
                thumbs = covers(l), thumb = l.firstOrNull()?.uri,
                onLong = { confirmDeletePlaylist(name) },
                onClick = {
                    drill = Drill(name, playlistTracks(name), 2, name)
                    refresh()
                }
            )
        )
    }
    rows.add(
        Row(
            title = "Buat playlist baru", sub = "", icon = R.drawable.ic_add,
            onClick = { createPlaylistDialog(null) }
        )
    )
    return rows
}

internal fun MusicActivity.reloadDrill() {
    val d = drill ?: return
    d.tracks = when (d.kind) {
        1 -> favTracks()
        2 -> playlistTracks(d.playlist ?: "")
        else -> d.tracks
    }
}
