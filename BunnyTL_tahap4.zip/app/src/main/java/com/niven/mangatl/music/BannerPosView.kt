package com.niven.mangatl

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.view.MotionEvent
import android.view.View

/**
 * Layar atur posisi banner: gambar utuh ditampilkan, kotak terang = bagian yang tampil di banner.
 * Geser kotak ke arah yang bisa digeser (kiri-kanan atau atas-bawah). Hasilnya [fx], [fy] 0..1.
 */
class BannerPosView(ctx: Context) : View(ctx) {
    var bmp: Bitmap? = null
        set(v) { field = v; invalidate() }

    /** lebar / tinggi area banner */
    var aspect = 1.3f
    var fx = 0.5f
    var fy = 0.5f

    private val dst = RectF()
    private val win = RectF()
    private val paint = Paint(Paint.FILTER_BITMAP_FLAG)
    private val dim = Paint().apply { color = Color.argb(160, 0, 0, 0) }
    private val stroke = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        style = Paint.Style.STROKE
        strokeWidth = 3f * resources.displayMetrics.density
    }

    /** true kalau ada bagian yang terpotong sehingga kotak bisa digeser. */
    fun canMove(): Boolean {
        val b = bmp ?: return false
        return kotlin.math.abs(b.width.toFloat() / b.height - aspect) > 0.01f
    }

    private fun layoutRects() {
        val b = bmp ?: return
        val s = minOf(width.toFloat() / b.width, height.toFloat() / b.height)
        val dw = b.width * s
        val dh = b.height * s
        val l = (width - dw) / 2f
        val t = (height - dh) / 2f
        dst.set(l, t, l + dw, t + dh)
        if (dw / dh > aspect) {
            val ww = dh * aspect
            val wl = l + (dw - ww) * fx
            win.set(wl, t, wl + ww, t + dh)
        } else {
            val wh = dw / aspect
            val wt = t + (dh - wh) * fy
            win.set(l, wt, l + dw, wt + wh)
        }
    }

    override fun onDraw(c: Canvas) {
        val b = bmp ?: return
        layoutRects()
        c.drawBitmap(b, null, dst, paint)
        c.drawRect(dst.left, dst.top, win.left, dst.bottom, dim)
        c.drawRect(win.right, dst.top, dst.right, dst.bottom, dim)
        c.drawRect(win.left, dst.top, win.right, win.top, dim)
        c.drawRect(win.left, win.bottom, win.right, dst.bottom, dim)
        c.drawRect(win, stroke)
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        if (bmp == null) return false
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN, MotionEvent.ACTION_MOVE -> {
                parent?.requestDisallowInterceptTouchEvent(true)
                layoutRects()
                val dw = dst.width()
                val dh = dst.height()
                if (dw / dh > aspect) {
                    val ww = win.width()
                    if (dw - ww > 1f) fx = ((e.x - dst.left - ww / 2f) / (dw - ww)).coerceIn(0f, 1f)
                } else {
                    val wh = win.height()
                    if (dh - wh > 1f) fy = ((e.y - dst.top - wh / 2f) / (dh - wh)).coerceIn(0f, 1f)
                }
                invalidate()
            }
        }
        return true
    }
}
