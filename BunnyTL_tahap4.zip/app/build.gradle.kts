plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.niven.mangatl"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.niven.mangatl"
        minSdk = 26
        targetSdk = 34
        versionCode = 14
        versionName = "1.4"

        ndk {
            abiFilters += listOf("arm64-v8a")
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = false
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
}

kotlin {
    compilerOptions {
        jvmTarget.set(org.jetbrains.kotlin.gradle.dsl.JvmTarget.JVM_17)
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("androidx.activity:activity-ktx:1.9.3")
    implementation("com.google.android.material:material:1.12.0")
    implementation("com.google.mlkit:text-recognition:16.0.1")
    implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.8.7")
    implementation("androidx.recyclerview:recyclerview:1.3.2")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.8.1")

    // Gemma lewat LiteRT-LM
    implementation("com.google.ai.edge.litertlm:litertlm-android:0.19.1")

    // Model .gguf lewat llama.cpp (CPU)
    implementation("io.github.ljcamargo:llamacpp-kotlin:0.4.0")

    // Pemutar musik & video (Media3 = ExoPlayer + sesi media + UI)
    implementation("androidx.media3:media3-exoplayer:1.7.1")
    implementation("androidx.media3:media3-session:1.7.1")
    implementation("androidx.media3:media3-ui:1.7.1")
    // Decoder FFmpeg (software) untuk MKV/AC3/DTS/HEVC yang gagal di decoder bawaan HP. Lisensi GPL-3.0.
    implementation("io.github.anilbeesetti:nextlib-media3ext:1.7.1-0.9.0")
    // Ambil frame video lewat FFmpeg untuk thumbnail MKV yang gagal di decoder bawaan HP (versi sama dengan media3ext).
    implementation("io.github.anilbeesetti:nextlib-mediainfo:1.7.1-0.9.0")
    // Baca folder lirik (.lrc) yang dipilih lewat Storage Access Framework
    implementation("androidx.documentfile:documentfile:1.0.1")

    // Suara offline (Supertonic 3 lewat sherpa-onnx). AAR diunduh oleh build.yml ke app/libs/.
    implementation(files("libs/sherpa-onnx-2.0.1.aar"))

    // Karin (Live2D). Core = Live2DCubismCore.aar (sudah ada di app/libs/).
    // Kode Framework Java-nya ada di app/src/main/java/com/live2d/ (disalin dari Cubism SDK for Java 5-r.5).
    implementation(files("libs/Live2DCubismCore.aar"))
}