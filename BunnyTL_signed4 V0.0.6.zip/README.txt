BunnyTL: OCR + terjemahan AI offline (mode akurat, gaya bahasa, glosarium) + Chat AI.

Mesin AI bisa diganti-ganti. Taruh tiap model di foldernya sendiri (COPY, bukan Move):
Android/data/com.niven.mangatl/files/
    Ai 1/gemma-4-E2B-it.litertlm
    Ai 2/Qwen3.5-4B_mixed_int4.litertlm
    Ai 3/...

Nama folder bebas. File .litertlm langsung di folder files/ juga tetap terbaca.
Pilih mesin di menu Opsi > "Mesin AI". Pilihan tersimpan dan berlaku untuk
terjemah, mode game, dan Chat.

Cache: tiap mesin AI punya folder cache sendiri bernama "_cache" di dalam foldernya
(mis. Ai 1/_cache). Aman dihapus kalau mau; nanti dibuat ulang otomatis.

Chat suara: tombol "Mic" di layar Chat. Ketuk, bicara (bahasa Indonesia), jawaban terkirim otomatis.
Ketuk lagi untuk membatalkan. Untuk offline, pasang paket suara Indonesia di
Pengaturan HP > Google > pengenalan suara / Speech Services.

Suara AI (keluar), 100% offline: model Supertonic 3 (sherpa-onnx).
1. Unduh sherpa-onnx-supertonic-3-tts-int8-2026-05-11.tar.bz2 dari
   github.com/k2-fsa/sherpa-onnx/releases/tag/tts-models, lalu ekstrak.
2. Salin folder hasil ekstrak (isi: voice.bin, tts.json, unicode_indexer.bin,
   dan 4 file .onnx) ke Android/data/com.niven.mangatl/files/Suara 1/
3. Opsi > "Suara AI": pilih model suara, pilih Suara 1-10, tekan "Tes suara".
   Suara 1-5 biasanya cewek (urutan perkiraan, dengar sendiri). 
4. Di Chat: tombol "Suara: mati/nyala" = AI membacakan setiap jawaban.
   Ketuk balon jawaban untuk membacakan satu pesan.
Catatan build: build.yml mengunduh sherpa-onnx-2.0.1.aar ke app/libs/ saat build.

Tahap 4 (mode game lebih cepat):
- Terjemah layar memakai prompt pendek + streaming: hasil muncul bertahap, dialog utama (teks terpanjang) paling dulu.
- Cache per baris di memori: teks yang sama (menu, tombol, dialog berulang) langsung tampil tanpa memanggil model.
  Tombol Reset mengosongkan cache ini.
- Backend (GPU/CPU) yang berhasil diingat per model, jadi muat berikutnya tidak mencoba ulang yang gagal.
- Opsi: slider opasitas kotak terjemahan, dan pilihan ketuk saat hasil tampil
  (tutup + langsung terjemah layar berikutnya, atau cuma tutup).
