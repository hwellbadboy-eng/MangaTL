package com.niven.mangatl

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import com.k2fsa.sherpa.onnx.GenerationConfig
import com.k2fsa.sherpa.onnx.OfflineTts
import com.k2fsa.sherpa.onnx.OfflineTtsConfig
import com.k2fsa.sherpa.onnx.OfflineTtsModelConfig
import com.k2fsa.sherpa.onnx.OfflineTtsSupertonicModelConfig
import java.io.File
import java.util.concurrent.LinkedBlockingQueue
import java.util.concurrent.TimeUnit

/**
 * Suara keluar 100% offline (Supertonic 3 lewat sherpa-onnx).
 * Taruh folder model suara di folder data app, mis. files/Suara 1/ berisi
 * voice.bin, tts.json, unicode_indexer.bin, dan 4 file .onnx.
 */
object Voice {

    private const val PREF_FILE = "mangatl"
    private const val PREF_VOICE = "voice_dir"
    private const val PREF_SID = "voice_sid"
    private const val PREF_SPEAK = "voice_speak"

    private val END = FloatArray(0)

    private var tts: OfflineTts? = null
    private var ttsDir: String? = null
    private val genLock = Any()

    @Volatile
    private var generation = 0

    @Volatile
    private var track: AudioTrack? = null

    @Volatile
    var speaking = false
        private set

    // ------------------------------------------------------------ model & pilihan

    private fun isVoiceDir(d: File): Boolean =
        d.isDirectory && File(d, "voice.bin").isFile && File(d, "tts.json").isFile &&
            File(d, "unicode_indexer.bin").isFile && part(d, "vector_estimator") != null

    private fun part(dir: File, prefix: String): File? =
        dir.listFiles()?.firstOrNull { it.isFile && it.name.startsWith(prefix) && it.name.endsWith(".onnx") }

    fun listVoices(context: Context): List<File> {
        val root = context.getExternalFilesDir(null) ?: return emptyList()
        return root.walkTopDown().maxDepth(3).filter { isVoiceDir(it) }
            .sortedBy { rel(root, it).lowercase() }.toList()
    }

    fun rel(context: Context, d: File): String {
        val root = context.getExternalFilesDir(null) ?: return d.name
        return rel(root, d)
    }

    private fun rel(root: File, d: File): String =
        try {
            d.relativeTo(root).path.replace(File.separatorChar, '/')
        } catch (_: Throwable) {
            d.name
        }

    fun findVoice(context: Context): File? {
        val all = listVoices(context)
        if (all.isEmpty()) return null
        val want = prefs(context).getString(PREF_VOICE, null)
        return all.firstOrNull { rel(context, it) == want } ?: all.first()
    }

    fun selectVoice(context: Context, d: File) {
        prefs(context).edit().putString(PREF_VOICE, rel(context, d)).apply()
    }

    fun sid(context: Context): Int = prefs(context).getInt(PREF_SID, 0).coerceIn(0, 9)

    fun setSid(context: Context, sid: Int) {
        prefs(context).edit().putInt(PREF_SID, sid).apply()
    }

    fun autoSpeak(context: Context): Boolean = prefs(context).getBoolean(PREF_SPEAK, false)

    fun setAutoSpeak(context: Context, on: Boolean) {
        prefs(context).edit().putBoolean(PREF_SPEAK, on).apply()
    }

    private fun prefs(context: Context) = context.getSharedPreferences(PREF_FILE, Context.MODE_PRIVATE)

    // ---------------------------------------------------------------- muat model

    private fun ensureTts(dir: File): OfflineTts {
        synchronized(genLock) {
            val cur = tts
            if (cur != null && ttsDir == dir.absolutePath) return cur
            try {
                cur?.free()
            } catch (_: Throwable) {
            }
            tts = null
            fun p(name: String) = File(dir, name).absolutePath
            val cfg = OfflineTtsConfig(
                model = OfflineTtsModelConfig(
                    supertonic = OfflineTtsSupertonicModelConfig(
                        durationPredictor = part(dir, "duration_predictor")!!.absolutePath,
                        textEncoder = part(dir, "text_encoder")!!.absolutePath,
                        vectorEstimator = part(dir, "vector_estimator")!!.absolutePath,
                        vocoder = part(dir, "vocoder")!!.absolutePath,
                        ttsJson = p("tts.json"),
                        unicodeIndexer = p("unicode_indexer.bin"),
                        voiceStyle = p("voice.bin")
                    ),
                    numThreads = 4,
                    provider = "cpu"
                )
            )
            val t = OfflineTts(config = cfg)
            tts = t
            ttsDir = dir.absolutePath
            return t
        }
    }

    /** Lepas model dari memori (dipanggil saat tidak dipakai supaya RAM lega). */
    fun release() {
        stop()
        synchronized(genLock) {
            try {
                tts?.free()
            } catch (_: Throwable) {
            }
            tts = null
            ttsDir = null
        }
    }

    // ------------------------------------------------------------------ teks

    private fun cleanForSpeech(raw: String): String {
        var s = raw
        s = s.replace(Regex("(?s)```.*?```"), " ")
        s = s.replace(Regex("https?://\\S+"), " ")
        s = s.replace(Regex("\\[([^\\]]*)]\\([^)]*\\)"), "$1")
        s = s.replace(Regex("[*_#>`~|]+"), " ")
        s = s.replace(Regex("[\\p{So}\\p{Cs}\\p{Cn}]"), " ")
        s = s.replace(Regex("^\\s*[-•]\\s+", RegexOption.MULTILINE), "")
        return s.replace(Regex("[ \\t]+"), " ").trim()
    }

    private fun splitSentences(text: String): List<String> {
        val raw = text.split(Regex("(?<=[.!?…])\\s+|\\n+")).map { it.trim() }.filter { it.isNotEmpty() }
        val out = ArrayList<String>()
        var cur = StringBuilder()
        fun flush() {
            if (cur.isNotBlank()) out.add(cur.toString().trim())
            cur = StringBuilder()
        }
        for (piece in raw) {
            if (piece.length > 220) {
                flush()
                // pecah kalimat panjang di koma / spasi
                var rest = piece
                while (rest.length > 220) {
                    var cut = rest.lastIndexOf(',', 220)
                    if (cut < 60) cut = rest.lastIndexOf(' ', 220)
                    if (cut < 60) cut = 220
                    out.add(rest.substring(0, cut + 1).trim())
                    rest = rest.substring(cut + 1).trim()
                }
                if (rest.isNotEmpty()) out.add(rest)
                continue
            }
            if (cur.isNotEmpty()) cur.append(' ')
            cur.append(piece)
            if (cur.length >= 40) flush()
        }
        flush()
        return out
    }

    // ------------------------------------------------------------- bicara

    /**
     * Bacakan teks. onDone dipanggil dari thread latar: null = selesai/dihentikan, selain itu pesan error.
     * releaseAfter = lepas model dari memori setelah selesai.
     */
    fun speak(context: Context, text: String, releaseAfter: Boolean = false, onDone: (String?) -> Unit) {
        stop()
        val sentences = splitSentences(cleanForSpeech(text))
        if (sentences.isEmpty()) {
            onDone(null)
            return
        }
        val appCtx = context.applicationContext
        val my = ++generation
        speaking = true
        Thread {
            var err: String? = null
            var at: AudioTrack? = null
            try {
                val dir = findVoice(appCtx) ?: throw IllegalStateException("Model suara belum ada")
                val t = ensureTts(dir)
                val sr = t.sampleRate()
                val speakerId = sid(appCtx).coerceAtMost(maxOf(0, t.numSpeakers() - 1))
                val queue = LinkedBlockingQueue<FloatArray>(3)

                // Penghasil suara: kalimat berikutnya dibuat selagi kalimat sebelumnya diputar.
                val producer = Thread {
                    try {
                        for (s in sentences) {
                            if (generation != my) break
                            val audio = synchronized(genLock) {
                                if (tts !== t) return@synchronized null
                                t.generateWithConfig(
                                    s,
                                    GenerationConfig(
                                        sid = speakerId,
                                        speed = 1.0f,
                                        numSteps = 5,
                                        extra = mapOf("lang" to "id")
                                    )
                                )
                            } ?: break
                            var placed = false
                            while (!placed && generation == my) {
                                placed = queue.offer(audio.samples, 200, TimeUnit.MILLISECONDS)
                            }
                        }
                    } catch (_: Throwable) {
                    } finally {
                        var placed = false
                        while (!placed && generation == my) {
                            placed = queue.offer(END, 200, TimeUnit.MILLISECONDS)
                        }
                    }
                }
                producer.start()

                val minBuf = AudioTrack.getMinBufferSize(
                    sr, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_FLOAT
                )
                val track = AudioTrack.Builder()
                    .setAudioAttributes(
                        AudioAttributes.Builder()
                            .setUsage(AudioAttributes.USAGE_MEDIA)
                            .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                            .build()
                    )
                    .setAudioFormat(
                        AudioFormat.Builder()
                            .setEncoding(AudioFormat.ENCODING_PCM_FLOAT)
                            .setSampleRate(sr)
                            .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                            .build()
                    )
                    .setBufferSizeInBytes(maxOf(minBuf, sr * 4))
                    .setTransferMode(AudioTrack.MODE_STREAM)
                    .build()
                at = track
                Voice.track = track
                track.play()

                var frames = 0L
                while (generation == my) {
                    val chunk = queue.poll(200, TimeUnit.MILLISECONDS) ?: continue
                    if (chunk === END) break
                    var off = 0
                    while (off < chunk.size && generation == my) {
                        val n = track.write(chunk, off, chunk.size - off, AudioTrack.WRITE_BLOCKING)
                        if (n <= 0) break
                        off += n
                    }
                    frames += chunk.size
                }
                // Tunggu sisa suara di buffer selesai diputar.
                val deadline = System.currentTimeMillis() + 60_000
                while (generation == my && track.playbackHeadPosition < frames &&
                    System.currentTimeMillis() < deadline
                ) {
                    Thread.sleep(50)
                }
            } catch (t: Throwable) {
                err = t.message ?: t::class.java.simpleName
            } finally {
                try {
                    at?.stop()
                } catch (_: Throwable) {
                }
                try {
                    at?.release()
                } catch (_: Throwable) {
                }
                if (track === at) track = null
                if (generation == my) speaking = false
                if (releaseAfter && generation == my) release()
                onDone(err)
            }
        }.start()
    }

    /** Hentikan suara yang sedang diputar atau antre. */
    fun stop() {
        generation++
        speaking = false
        try {
            track?.pause()
            track?.flush()
            track?.stop()
        } catch (_: Throwable) {
        }
    }
}
