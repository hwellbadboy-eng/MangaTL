package com.niven.mangatl

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.provider.Settings
import androidx.core.content.ContextCompat
import android.net.Uri
import android.os.Bundle
import android.os.SystemClock
import android.animation.ObjectAnimator
import android.animation.ValueAnimator
import android.annotation.SuppressLint
import android.text.Editable
import android.text.TextWatcher
import android.transition.AutoTransition
import android.transition.TransitionManager
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.animation.AccelerateDecelerateInterpolator
import android.view.animation.DecelerateInterpolator
import android.view.animation.LinearInterpolator
import android.view.animation.OvershootInterpolator
import android.widget.ImageView
import java.io.File
import java.util.Locale
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.SeekBar
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.google.android.material.materialswitch.MaterialSwitch
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class MainActivity : AppCompatActivity() {

    private lateinit var status: TextView
    private lateinit var result: TextView
    private lateinit var btnPick: Button
    private lateinit var settingsPanel: View
    private lateinit var spStyle: Spinner
    private lateinit var spModel: Spinner
    private lateinit var spVoiceModel: Spinner
    private lateinit var spVoiceSid: Spinner
    private var voiceDirs: List<File> = emptyList()
    private var modelFiles: List<File> = emptyList()
    private lateinit var swAccurate: MaterialSwitch
    private lateinit var etGlossary: EditText

    private var busy = false
        set(value) {
            field = value
            runOnUiThread { onBusyChanged(value) }
        }
    private lateinit var ivLogo: ImageView
    private lateinit var ivRing: ImageView
    private var floatAnim: ObjectAnimator? = null
    private var ringAnim: ObjectAnimator? = null
    private var lastLines: List<String> = emptyList()
    private var lastTranslations: List<String?> = emptyList()

    private val prefs by lazy { getSharedPreferences("mangatl", MODE_PRIVATE) }

    private val HELP_TEXT: String =
        "Baca seluruh layar / setengah / sepertiga bawah: seberapa luas layar yang dibaca. Tidak dipakai kalau \"pakai kotak area\" dipilih.\n\n" +
            "Hasil: timpa teks asli, atau tampil di kotak atas/bawah layar.\n\n" +
            "Sekali tap: ketuk = terjemah, ketuk lagi = tutup.\n" +
            "Tap berurutan: satu ketukan menutup hasil lama lalu langsung menerjemahkan layar berikutnya.\n" +
            "Auto: terjemah sendiri saat teks berubah.\n\n" +
            "Area sekali tap / auto: kalau \"pakai kotak area\", hanya kotak yang kamu atur yang dibaca. Atur lewat tombol di bawahnya.\n\n" +
            "Periksa ulang (auto): seberapa sering layar dicek. Mode tiap 2/4 detik bikin kedip singkat.\n\n" +
            "Opasitas: kepekatan latar kotak terjemahan. 100% = teks asli tidak tembus.\n\n" +
            "Perataan teks: rata kiri atau tengah di dalam kotak.\n\n" +
            "Spasi blok teks: makin kecil, makin gampang teks dipecah jadi kotak terpisah.\n\n" +
            "Perbedaan ukuran teks: makin kecil, makin gampang teks besar dan kecil dipisah.\n\n" +
            "Daftar abaikan: teks yang tidak diterjemahkan (satu per baris, * = cocok sebagian).\n\n" +
            "Alat uji: pilih foto untuk melihat kotak hasil pembacaan dan atur slider di atas."

    private val pick = registerForActivityResult(
        ActivityResultContracts.GetContent()
    ) { uri ->
        uri?.let { runOcr(it) }
    }

    private var askedNotif = false
    private lateinit var swGame: MaterialSwitch
    private var syncAfter = 0L

    private val capture = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { r ->
        val d = r.data
        if (r.resultCode == RESULT_OK && d != null) {
            val i = Intent(this, ScreenService::class.java)
                .putExtra("code", r.resultCode)
                .putExtra("data", d)
            ContextCompat.startForegroundService(this, i)
            swGame.isChecked = true
            syncAfter = SystemClock.elapsedRealtime() + 4000
            swGame.postDelayed({ swGame.isChecked = ScreenService.running }, 4500)
            Toast.makeText(
                this, "Tombol TL aktif. Buka game, lalu ketuk tombol TL.", Toast.LENGTH_LONG
            ).show()
            moveTaskToBack(true)
        } else {
            swGame.isChecked = false
            Toast.makeText(this, "Izin rekam layar ditolak.", Toast.LENGTH_SHORT).show()
        }
    }

    private val notifPerm = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { startGameMode() }

    private fun startGameMode() {
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(
                this, "Aktifkan izin 'Tampil di atas aplikasi lain' untuk BunnyTL, lalu kembali dan tekan lagi.",
                Toast.LENGTH_LONG
            ).show()
            startActivity(
                Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
            )
            return
        }
        if (Build.VERSION.SDK_INT >= 33 && !askedNotif &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            askedNotif = true
            notifPerm.launch(Manifest.permission.POST_NOTIFICATIONS)
            return
        }
        if (Gemma.findModel(this) == null) {
            Toast.makeText(this, "Model .litertlm belum ada, terjemahan tidak akan jalan.", Toast.LENGTH_LONG).show()
        }
        val mpm = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        capture.launch(mpm.createScreenCaptureIntent())
    }

    private fun setupSpinner(sp: Spinner, key: String, labels: List<String>) {
        sp.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, labels)
        sp.setSelection(prefs.getInt(key, 0).coerceIn(0, labels.size - 1))
        sp.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(p: AdapterView<*>?, v: View?, pos: Int, id: Long) {
                prefs.edit().putInt(key, pos).apply()
            }

            override fun onNothingSelected(p: AdapterView<*>?) {}
        }
    }

    private fun modelLabel(f: File): String {
        val gb = f.length() / 1024.0 / 1024.0 / 1024.0
        val rel = Gemma.relName(this, f).removeSuffix(".litertlm").replace("/", "  /  ")
        return String.format(Locale.US, "%s (%.1f GB)", rel, gb)
    }

    /** Isi ulang daftar model dari folder data app; pilihan mengikuti Gemma.findModel. */
    private fun refreshModels() {
        val files = Gemma.listModels(this)
        if (files.map { it.absolutePath } != modelFiles.map { it.absolutePath }) {
            modelFiles = files
            val labels = if (files.isEmpty()) listOf("(belum ada file .litertlm)") else files.map { modelLabel(it) }
            spModel.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, labels)
        }
        val cur = Gemma.findModel(this)
        val idx = modelFiles.indexOfFirst { it.absolutePath == cur?.absolutePath }
        if (idx >= 0) spModel.setSelection(idx)
    }

    // ------------------------------------------------------------ suara AI

    private fun refreshVoices() {
        val dirs = Voice.listVoices(this)
        if (dirs.map { it.absolutePath } != voiceDirs.map { it.absolutePath }) {
            voiceDirs = dirs
            val labels = if (dirs.isEmpty()) listOf("(belum ada folder model suara)")
            else dirs.map { Voice.rel(this, it).replace("/", "  /  ") }
            spVoiceModel.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, labels)
        }
        val cur = Voice.findVoice(this)
        val idx = voiceDirs.indexOfFirst { it.absolutePath == cur?.absolutePath }
        if (idx >= 0) spVoiceModel.setSelection(idx)
    }

    private fun onModelPicked(pos: Int) {
        val f = modelFiles.getOrNull(pos) ?: return
        if (Gemma.findModel(this)?.absolutePath == f.absolutePath) return
        Gemma.selectModel(this, f)
        Gemma.resetContext()
        status.text = "Ganti mesin ke ${f.name}. Memuat..."
        Thread {
            try {
                Gemma.warmUp(applicationContext, f)
                runOnUiThread { if (!busy) status.text = "Model siap: ${f.name}. Backend: ${Gemma.backendName}" }
            } catch (t: Throwable) {
                runOnUiThread { if (!busy) status.text = "Model gagal dimuat: ${t.message}" }
            }
        }.start()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        setupUi()

        status = findViewById(R.id.status)
        result = findViewById(R.id.result)
        btnPick = findViewById(R.id.btnPick)
        settingsPanel = findViewById(R.id.settingsPanel)
        spStyle = findViewById(R.id.spStyle)
        spModel = findViewById(R.id.spModel)
        spVoiceModel = findViewById(R.id.spVoiceModel)
        spVoiceSid = findViewById(R.id.spVoiceSid)
        swAccurate = findViewById(R.id.swAccurate)
        etGlossary = findViewById(R.id.etGlossary)

        // Pengaturan tersimpan
        val styles = Gemma.Style.values()
        spStyle.adapter = ArrayAdapter(
            this, android.R.layout.simple_spinner_dropdown_item, styles.map { it.label }
        )
        spStyle.setSelection(prefs.getInt("style", 0).coerceIn(0, styles.size - 1))
        spStyle.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(p: AdapterView<*>?, v: View?, pos: Int, id: Long) {
                prefs.edit().putInt("style", pos).apply()
            }

            override fun onNothingSelected(p: AdapterView<*>?) {}
        }
        swAccurate.isChecked = prefs.getBoolean("accurate", true)
        swAccurate.setOnCheckedChangeListener { _, checked ->
            prefs.edit().putBoolean("accurate", checked).apply()
        }
        etGlossary.setText(prefs.getString("glossary", ""))

        btnPick.setOnClickListener {
            if (busy) {
                Toast.makeText(this, "Masih menerjemahkan...", Toast.LENGTH_SHORT).show()
            } else {
                saveGlossary()
                pick.launch("image/*")
            }
        }

        findViewById<Button>(R.id.btnChat).setOnClickListener {
            saveGlossary()
            startActivity(Intent(this, ChatActivity::class.java))
            overridePendingTransition(R.anim.slide_in_right, R.anim.fade_out_soft)
        }

        findViewById<Button>(R.id.btnMusic).setOnClickListener {
            startActivity(Intent(this, MusicActivity::class.java))
            overridePendingTransition(R.anim.slide_in_right, R.anim.fade_out_soft)
        }
        findViewById<Button>(R.id.btnVideo).setOnClickListener {
            startActivity(Intent(this, VideoFoldersActivity::class.java))
            overridePendingTransition(R.anim.slide_in_right, R.anim.fade_out_soft)
        }

        findViewById<Button>(R.id.btnSettings).setOnClickListener {
            TransitionManager.beginDelayedTransition(
                findViewById<ViewGroup>(R.id.content),
                AutoTransition().apply { duration = 280 }
            )
            settingsPanel.visibility =
                if (settingsPanel.visibility == View.VISIBLE) View.GONE else View.VISIBLE
        }

        findViewById<Button>(R.id.btnReset).setOnClickListener {
            Gemma.resetContext()
            Toast.makeText(this, "Konteks antar halaman direset.", Toast.LENGTH_SHORT).show()
        }

        findViewById<Button>(R.id.btnCopy).setOnClickListener {
            val text = lastTranslations.mapIndexedNotNull { i, t ->
                if (t == null) null else t.ifBlank { lastLines.getOrElse(i) { "" } }
            }.joinToString("\n")
            if (text.isBlank()) {
                Toast.makeText(this, "Belum ada hasil.", Toast.LENGTH_SHORT).show()
            } else {
                val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                cm.setPrimaryClip(ClipData.newPlainText("terjemahan", text))
                Toast.makeText(this, "Terjemahan disalin.", Toast.LENGTH_SHORT).show()
            }
        }

        setupSpinner(
            findViewById(R.id.spScan), "scan",
            listOf("Mode game: baca seluruh layar", "Mode game: baca setengah bawah", "Mode game: baca sepertiga bawah")
        )
        setupSpinner(
            findViewById(R.id.spPos), "pos",
            listOf(
                "Hasil: timpa teks asli (warna mengikuti latar)",
                "Hasil: kotak di atas layar",
                "Hasil: kotak di bawah layar"
            )
        )
        val spMode = findViewById<Spinner>(R.id.spMode)
        spMode.adapter = ArrayAdapter(
            this, android.R.layout.simple_spinner_dropdown_item,
            listOf(
                "Sekali tap: ketuk = terjemah, ketuk lagi = tutup hasil",
                "Tap berurutan: ketuk = tutup hasil + langsung terjemah layar berikutnya",
                "Auto: terjemah sendiri saat teks di layar berubah (ketuk tombol = jeda/lanjut)"
            )
        )
        spMode.setSelection(prefs.getInt("smode", 1).coerceIn(0, 2))
        spMode.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(p: AdapterView<*>?, v: View?, pos: Int, id: Long) {
                prefs.edit().putInt("smode", pos).apply()
            }

            override fun onNothingSelected(p: AdapterView<*>?) {}
        }
        setupSpinner(
            findViewById(R.id.spAreaTap), "area_tap_on",
            listOf(
                "Area sekali tap: ikut pilihan 'baca ...' di atas",
                "Area sekali tap: pakai kotak area (atur dengan tombol di bawah)"
            )
        )
        setupSpinner(
            findViewById(R.id.spAreaAuto), "area_auto_on",
            listOf(
                "Area auto: ikut pilihan 'baca ...' di atas",
                "Area auto: pakai kotak area (atur dengan tombol di bawah)"
            )
        )
        setupSpinner(
            findViewById(R.id.spAutoPoll), "auto_poll",
            listOf(
                "Auto, periksa ulang: otomatis (diam saat Anda mengetuk game, tanpa kedip)",
                "Auto, periksa ulang: hanya saat game diketuk (tanpa kedip, paling hemat)",
                "Auto, periksa ulang: tiap 4 detik (kedip singkat)",
                "Auto, periksa ulang: tiap 2 detik (kedip singkat, untuk game auto-play)"
            )
        )
        findViewById<Button>(R.id.btnAreaTap).setOnClickListener { openAreaEditor(0) }
        findViewById<Button>(R.id.btnAreaAuto).setOnClickListener { openAreaEditor(1) }
        val sbOpacity = findViewById<SeekBar>(R.id.sbOpacity)
        val tvOpacity = findViewById<TextView>(R.id.tvOpacity)
        // Kunci baru "ov_alpha2": default 100% (pekat penuh) supaya teks asli tidak tembus.
        val a0 = prefs.getInt("ov_alpha2", 100).coerceIn(30, 100)
        sbOpacity.progress = a0 - 30
        tvOpacity.text = "Opasitas kotak terjemahan: $a0%"
        sbOpacity.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                val v = p + 30
                tvOpacity.text = "Opasitas kotak terjemahan: $v%"
                prefs.edit().putInt("ov_alpha2", v).apply()
            }

            override fun onStartTrackingTouch(s: SeekBar?) {}

            override fun onStopTrackingTouch(s: SeekBar?) {}
        })

        // Perataan teks terjemahan di kotak.
        setupSpinner(
            findViewById(R.id.spAlign), "ov_align",
            listOf("Perataan teks: rata kiri", "Perataan teks: rata tengah")
        )

        // Pemecahan blok teks (dipakai juga oleh alat uji).
        val tvSpacing = findViewById<TextView>(R.id.tvSpacing)
        val sbSpacing = findViewById<SeekBar>(R.id.sbSpacing)
        val sp0 = prefs.getInt(Grouping.KEY_SPACING, Grouping.SPACING_DEFAULT).coerceIn(0, 20)
        sbSpacing.progress = sp0
        tvSpacing.text = String.format(
            Locale.US, "Spasi blok teks: pisah kalau jarak baris > %.1fx tinggi huruf", Grouping.spacingFactor(sp0)
        )
        sbSpacing.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                tvSpacing.text = String.format(
                    Locale.US, "Spasi blok teks: pisah kalau jarak baris > %.1fx tinggi huruf", Grouping.spacingFactor(p)
                )
                prefs.edit().putInt(Grouping.KEY_SPACING, p).apply()
            }

            override fun onStartTrackingTouch(s: SeekBar?) {}

            override fun onStopTrackingTouch(s: SeekBar?) {}
        })

        val tvSizeDiff = findViewById<TextView>(R.id.tvSizeDiff)
        val sbSizeDiff = findViewById<SeekBar>(R.id.sbSizeDiff)
        val sd0 = prefs.getInt(Grouping.KEY_SIZEDIFF, Grouping.SIZEDIFF_DEFAULT).coerceIn(10, 80)
        sbSizeDiff.progress = sd0 - 10
        tvSizeDiff.text = "Perbedaan ukuran teks: pisah kalau beda > $sd0%"
        sbSizeDiff.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                val v = p + 10
                tvSizeDiff.text = "Perbedaan ukuran teks: pisah kalau beda > $v%"
                prefs.edit().putInt(Grouping.KEY_SIZEDIFF, v).apply()
            }

            override fun onStartTrackingTouch(s: SeekBar?) {}

            override fun onStopTrackingTouch(s: SeekBar?) {}
        })

        // Daftar abaikan: tersimpan otomatis setiap diubah.
        val etIgnore = findViewById<EditText>(R.id.etIgnore)
        etIgnore.setText(prefs.getString(Grouping.KEY_IGNORE, "") ?: "")
        etIgnore.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}

            override fun onTextChanged(s: CharSequence?, st: Int, b: Int, c: Int) {}

            override fun afterTextChanged(s: Editable?) {
                prefs.edit().putString(Grouping.KEY_IGNORE, s?.toString() ?: "").apply()
            }
        })

        findViewById<TextView>(R.id.tvHelp).setOnClickListener {
            AlertDialog.Builder(this)
                .setTitle("Penjelasan pengaturan")
                .setMessage(HELP_TEXT)
                .setPositiveButton("Tutup", null)
                .show()
        }

        findViewById<Button>(R.id.btnBoxTest).setOnClickListener {
            startActivity(Intent(this, BoxTestActivity::class.java))
        }
        swGame = findViewById(R.id.swGame)
        swGame.isChecked = ScreenService.running
        swGame.setOnClickListener {
            if (swGame.isChecked) {
                // Nyalakan: kembalikan dulu ke mati, baru nyala sungguhan setelah semua izin beres.
                swGame.isChecked = false
                saveGlossary()
                startGameMode()
            } else {
                stopService(Intent(this, ScreenService::class.java))
                Toast.makeText(this, "Mode game dimatikan.", Toast.LENGTH_SHORT).show()
            }
        }

        // Suara AI (offline): pilih model suara, pilih suara 1-6, tombol tes.
        val sidLabels = (0..Voice.MAX_SID).map {
            if (it < 5) "Suara ${it + 1} (biasanya cewek)" else "Suara ${it + 1} (biasanya cowok)"
        }
        spVoiceSid.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, sidLabels)
        spVoiceSid.setSelection(Voice.sid(this))
        spVoiceSid.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(p: AdapterView<*>?, v: View?, pos: Int, id: Long) {
                Voice.setSid(this@MainActivity, pos)
            }

            override fun onNothingSelected(p: AdapterView<*>?) {}
        }
        val spSpeed = findViewById<Spinner>(R.id.spVoiceSpeed)
        spSpeed.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, Voice.MODE_LABELS)
        spSpeed.setSelection(Voice.mode(this))
        spSpeed.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(p: AdapterView<*>?, v: View?, pos: Int, id: Long) {
                Voice.setMode(this@MainActivity, pos)
            }

            override fun onNothingSelected(p: AdapterView<*>?) {}
        }
        // Jeda koma & titik (0-600 ms, kelipatan 10).
        fun bindPause(sbId: Int, tvId: Int, label: String, get: () -> Int, set: (Int) -> Unit) {
            val sb = findViewById<SeekBar>(sbId)
            val tv = findViewById<TextView>(tvId)
            val v0 = get()
            sb.progress = v0 / Voice.PAUSE_STEP_MS
            tv.text = "$label: $v0 ms"
            sb.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                    val v = p * Voice.PAUSE_STEP_MS
                    tv.text = "$label: $v ms"
                    set(v)
                }

                override fun onStartTrackingTouch(s: SeekBar?) {}

                override fun onStopTrackingTouch(s: SeekBar?) {}
            })
        }
        bindPause(R.id.sbPauseComma, R.id.tvPauseComma, "Jeda koma",
            { Voice.pauseComma(this) }, { Voice.setPauseComma(this, it) })
        bindPause(R.id.sbPausePeriod, R.id.tvPausePeriod, "Jeda titik",
            { Voice.pausePeriod(this) }, { Voice.setPausePeriod(this, it) })
        findViewById<Button>(R.id.btnVoiceReset).setOnClickListener {
            Voice.resetSpeechSettings(this)
            spSpeed.setSelection(Voice.mode(this))
            findViewById<SeekBar>(R.id.sbPauseComma).progress = Voice.pauseComma(this) / Voice.PAUSE_STEP_MS
            findViewById<SeekBar>(R.id.sbPausePeriod).progress = Voice.pausePeriod(this) / Voice.PAUSE_STEP_MS
            Toast.makeText(this, "Pengaturan suara dikembalikan ke default.", Toast.LENGTH_SHORT).show()
        }
        refreshVoices()
        spVoiceModel.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(p: AdapterView<*>?, v: View?, pos: Int, id: Long) {
                voiceDirs.getOrNull(pos)?.let { Voice.selectVoice(this@MainActivity, it) }
            }

            override fun onNothingSelected(p: AdapterView<*>?) {}
        }
        findViewById<Button>(R.id.btnVoiceTest).setOnClickListener {
            if (Voice.speaking) {
                Voice.stop()
                return@setOnClickListener
            }
            if (Voice.findVoice(this) == null) {
                Toast.makeText(
                    this, "Model suara belum ada. Salin folder model ke:\n${getExternalFilesDir(null)}",
                    Toast.LENGTH_LONG
                ).show()
                return@setOnClickListener
            }
            Toast.makeText(this, "Memuat suara...", Toast.LENGTH_SHORT).show()
            Voice.speak(
                this, "Halo, aku asisten kamu. Ini contoh suaraku untuk menguji jeda, jadi dengarkan baik-baik ya, apakah jedanya sudah pas. Kalau sudah cocok, pakai terus ya.",
                releaseAfter = true
            ) { err ->
                if (err != null) runOnUiThread {
                    Toast.makeText(this, "Suara gagal: $err", Toast.LENGTH_LONG).show()
                }
            }
        }

        refreshModels()
        spModel.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(p: AdapterView<*>?, v: View?, pos: Int, id: Long) {
                onModelPicked(pos)
            }

            override fun onNothingSelected(p: AdapterView<*>?) {}
        }

        val model = Gemma.findModel(this)
        if (model == null) {
            status.text = "Model belum ada. Salin file .litertlm ke:\n${getExternalFilesDir(null)}"
        } else {
            status.text = "Model ditemukan: ${model.name}. Memuat..."
            // Muat model sejak awal supaya terjemahan pertama langsung cepat.
            Thread {
                try {
                    Gemma.warmUp(applicationContext, model)
                    runOnUiThread {
                        if (!busy) status.text = "Model siap. Backend: ${Gemma.backendName}"
                    }
                } catch (t: Throwable) {
                    runOnUiThread {
                        if (!busy) status.text = "Model gagal dimuat: ${t.message}"
                    }
                }
            }.start()
        }
    }

    private fun openAreaEditor(which: Int) {
        if (!ScreenService.running) {
            Toast.makeText(this, "Nyalakan Mode game dulu, baru atur kotak area.", Toast.LENGTH_LONG).show()
            return
        }
        startService(
            Intent(this, ScreenService::class.java)
                .setAction(ScreenService.ACTION_EDIT_AREA)
                .putExtra("which", which)
        )
        Toast.makeText(this, "Atur kotak lalu tekan Simpan.", Toast.LENGTH_SHORT).show()
        moveTaskToBack(true)
    }

    override fun onResume() {
        super.onResume()
        // Area bisa berubah dari layar pengatur area (otomatis diaktifkan saat disimpan).
        findViewById<Spinner>(R.id.spMode).setSelection(prefs.getInt("smode", 1).coerceIn(0, 2))
        findViewById<Spinner>(R.id.spAreaTap).setSelection(prefs.getInt("area_tap_on", 0).coerceIn(0, 1))
        findViewById<Spinner>(R.id.spAreaAuto).setSelection(prefs.getInt("area_auto_on", 0).coerceIn(0, 1))
        refreshModels()
        refreshVoices()
        if (SystemClock.elapsedRealtime() >= syncAfter) swGame.isChecked = ScreenService.running
    }

    override fun onPause() {
        saveGlossary()
        super.onPause()
    }

    override fun onDestroy() {
        floatAnim?.cancel()
        ringAnim?.cancel()
        super.onDestroy()
    }

    // ------------------------------------------------------------ tampilan & animasi

    private fun dp(v: Float): Float = v * resources.displayMetrics.density

    private fun setupUi() {
        ivLogo = findViewById(R.id.ivLogo)
        ivRing = findViewById(R.id.ivRing)

        intArrayOf(R.id.header, R.id.btnPick, R.id.rowBento, R.id.rowChips, R.id.gameCard)
            .forEachIndexed { i, id ->
                val v = findViewById<View>(id)
                v.alpha = 0f
                v.translationY = dp(16f)
                v.animate().alpha(1f).translationY(0f)
                    .setStartDelay(80L + i * 70L).setDuration(520)
                    .setInterpolator(DecelerateInterpolator(2f)).start()
            }

        ivLogo.alpha = 0f
        ivLogo.scaleX = 0.55f
        ivLogo.scaleY = 0.55f
        ivLogo.rotation = -12f
        ivLogo.animate().alpha(1f).scaleX(1f).scaleY(1f).rotation(0f)
            .setStartDelay(120).setDuration(800)
            .setInterpolator(OvershootInterpolator(1.6f))
            .withEndAction { startFloat() }.start()
        ivLogo.setOnClickListener {
            ivLogo.animate().cancel()
            ivLogo.animate().rotation(-10f).scaleX(0.9f).scaleY(0.9f).setDuration(120).withEndAction {
                ivLogo.animate().rotation(0f).scaleX(1f).scaleY(1f).setDuration(380)
                    .setInterpolator(OvershootInterpolator(3f)).start()
            }.start()
        }

        intArrayOf(R.id.btnPick, R.id.btnChat, R.id.btnMusic, R.id.btnVideo,
            R.id.btnCopy, R.id.btnReset, R.id.btnSettings)
            .forEach { pressScale(findViewById(it)) }

        val res = findViewById<TextView>(R.id.result)
        val lab = findViewById<View>(R.id.tvResultLabel)
        res.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}
            override fun onTextChanged(s: CharSequence?, st: Int, b: Int, c: Int) {}
            override fun afterTextChanged(s: Editable?) {
                if (s.isNullOrBlank()) {
                    res.visibility = View.GONE
                    lab.visibility = View.GONE
                } else if (res.visibility != View.VISIBLE) {
                    res.alpha = 0f
                    res.visibility = View.VISIBLE
                    lab.visibility = View.VISIBLE
                    res.animate().alpha(1f).setDuration(300).start()
                }
            }
        })
    }

    private fun startFloat() {
        floatAnim = ObjectAnimator.ofFloat(ivLogo, View.TRANSLATION_Y, 0f, -dp(2.5f)).apply {
            duration = 2000
            repeatMode = ValueAnimator.REVERSE
            repeatCount = ValueAnimator.INFINITE
            interpolator = AccelerateDecelerateInterpolator()
            start()
        }
    }

    /** Cincin ungu berputar di sekitar logo selama proses terjemah. */
    private fun onBusyChanged(b: Boolean) {
        if (!::ivRing.isInitialized) return
        if (b) {
            ivRing.animate().cancel()
            ivRing.animate().alpha(1f).setDuration(250).start()
            if (ringAnim == null) {
                ringAnim = ObjectAnimator.ofFloat(ivRing, View.ROTATION, 0f, 360f).apply {
                    duration = 1000
                    repeatCount = ValueAnimator.INFINITE
                    interpolator = LinearInterpolator()
                    start()
                }
            }
        } else {
            ivRing.animate().cancel()
            ivRing.animate().alpha(0f).setDuration(300).withEndAction {
                if (!busy) {
                    ringAnim?.cancel()
                    ringAnim = null
                }
            }.start()
        }
    }

    @SuppressLint("ClickableViewAccessibility")
    private fun pressScale(v: View) {
        v.setOnTouchListener { view, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN ->
                    view.animate().scaleX(0.96f).scaleY(0.96f).setDuration(110).start()
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL ->
                    view.animate().scaleX(1f).scaleY(1f).setDuration(220)
                        .setInterpolator(OvershootInterpolator(2f)).start()
            }
            false
        }
    }

    private fun saveGlossary() {
        prefs.edit()
            .putString("glossary", etGlossary.text.toString())
            .apply()
    }

    private fun runOcr(uri: Uri) {
        result.text = ""

        val image = try {
            InputImage.fromFilePath(this, uri)
        } catch (e: Exception) {
            status.text = "Gagal membuka gambar: ${e.message}"
            return
        }

        status.text = "Membaca teks..."
        busy = true

        TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
            .process(image)
            .addOnSuccessListener { text ->
                val items = text.textBlocks.mapNotNull { b ->
                    val box = b.boundingBox
                    val t = b.text.replace("\n", " ").trim()
                    if (box == null || t.isEmpty()) null else Pair(box, t)
                }
                val lines = TextUtil.readingOrder(items)

                if (lines.isEmpty()) {
                    busy = false
                    status.text = "Tidak ada teks terdeteksi."
                    return@addOnSuccessListener
                }

                lastLines = lines
                lastTranslations = emptyList()
                show(lines, List(lines.size) { null })
                translate(lines)
            }
            .addOnFailureListener { e ->
                busy = false
                status.text = "OCR gagal: ${e.message}"
            }
    }

    private fun show(lines: List<String>, tr: List<String?>) {
        result.text = lines.indices.joinToString("\n\n") { i ->
            val t = tr.getOrNull(i)
            "${i + 1}. ${lines[i]}\n    -> ${t ?: "..."}"
        }
    }

    private fun translate(lines: List<String>) {
        val model = Gemma.findModel(this)

        if (model == null) {
            busy = false
            status.text = "Model belum ada. Salin file .litertlm ke:\n${getExternalFilesDir(null)}"
            return
        }

        val style = Gemma.Style.values()[spStyle.selectedItemPosition.coerceIn(0, Gemma.Style.values().size - 1)]
        val accurate = swAccurate.isChecked
        val glossary = etGlossary.text.toString()

        status.text = "Menerjemahkan ${lines.size} blok..."

        lifecycleScope.launch {
            val t0 = SystemClock.elapsedRealtime()

            val res = try {
                withContext(Dispatchers.IO) {
                    Gemma.translate(
                        this@MainActivity, model, lines, style, accurate, glossary,
                        onStatus = { s -> runOnUiThread { status.text = s } },
                        onProgress = { tr ->
                            runOnUiThread {
                                lastTranslations = tr
                                show(lines, tr)
                            }
                        }
                    )
                }
            } catch (t: Throwable) {
                busy = false
                status.text = "Gemma gagal: ${t::class.java.simpleName}: ${t.message}"
                return@launch
            }

            busy = false
            val sec = (SystemClock.elapsedRealtime() - t0) / 1000.0
            lastTranslations = res.lines
            show(lines, res.lines)

            status.text = "Selesai %.1f detik. Mode: %s. Backend: %s".format(
                sec,
                res.mode,
                Gemma.backendName
            )
        }
    }
}
